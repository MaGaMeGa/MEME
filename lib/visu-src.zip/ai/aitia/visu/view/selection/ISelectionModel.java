package ai.aitia.visu.view.selection;

import java.util.List;

public interface ISelectionModel {
	public boolean isEmpty();
	public List getSelectedObjects();
}