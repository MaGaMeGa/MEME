package ai.aitia.visu.view.ui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import ai.aitia.visu.utils.Interval;

public class IntervalTableColorMap implements ColorMap {

	//==================================================================================
	// inner classes
	
	//-------------------------------------------------------------------------
	// imported from MEME
	/** Generic representation of a pair. */
	public static class Pair<K, V> implements java.util.Map.Entry<K, V> {
		protected K	first;
		protected V	second;

		public Pair()						{ first = null; second = null; }
		public Pair(K first, V second)		{ this.first = first; this.second = second; }

		public K getKey()					{ return first; } 
		public K getFirst()					{ return first; }
		
		public V getValue()					{ return second; }
		public V getSecond()				{ return second; }
		
		public V setValue(V value)			{ V ans = second; second = value; return ans; }
		public V setSecond(V value)			{ V ans = second; second = value; return ans; }
		public void set(K key, V value)	{ first = key; second = value; }
		@Override public int hashCode()	{ return java.util.Arrays.hashCode(new Object[] {first,second}); }
		@Override
		public boolean equals(Object o) {
			if (o == this) return true;
			if (o instanceof java.util.Map.Entry) {
				java.util.Map.Entry other = (java.util.Map.Entry)o;
				return (getKey() == null ? other.getKey() == null : getKey().equals(other.getKey()))
						&& (getValue() == null ? other.getValue() == null : getValue().equals(other.getValue()));
			}
			return false;
		}
		@Override
		public String toString() {
			Object tmp[] = { first, second };
			return java.util.Arrays.toString(tmp);
		}
	}
	
	@SuppressWarnings("serial")
	public class EntryNotFoundException extends Exception {}
	
	//==================================================================================
	// members
	
	private List<Pair<Interval,Color>> map;
	private Color defaultColor;
	private double minLevel, maxLevel;
	private String name = "";
	
	//==================================================================================
	// methods
	
	//----------------------------------------------------------------------------------
	public IntervalTableColorMap() {
		map = new ArrayList<Pair<Interval,Color>>();
		this.defaultColor = Color.white;
	}
	
	//----------------------------------------------------------------------------------
	public void addEntry(Interval intv, Color color) {
		if (map.isEmpty()) {
			minLevel = intv.getLower();
			maxLevel = intv.getUpper();
		} else {
			if (intv.getLower() < minLevel) minLevel = intv.getLower();
			if (intv.getUpper() > maxLevel) maxLevel = intv.getUpper();
		}
		Pair<Interval,Color> p = new Pair<Interval,Color>(intv,color);
		if (map.contains(p)) {
			int index = map.indexOf(p);
			map.set(index,p);
		} else map.add(p);
	}
	
	//----------------------------------------------------------------------------------
	public boolean containsNotDefaultColor() {
		for (Pair<Interval,Color> p : map) {
			if (p.getValue() != null)
				return true;
		}
		return false;
	}
	
	//----------------------------------------------------------------------------------
	public List<Pair<Interval,Color>> getMap() { return map; }
	
	//----------------------------------------------------------------------------------
	public void setDefaultColor(Color defaultColor) { this.defaultColor = defaultColor;	}
	public void setName(String name) { this.name = name; }
	
	//----------------------------------------------------------------------------------
	public Color getColor(Interval intv) throws EntryNotFoundException {
		for (int i = map.size() - 1;i >= 0;--i) {
			if (map.get(i).getKey().equals(intv))
				return map.get(i).getValue();
		}
		throw new EntryNotFoundException();
	}
	
	//----------------------------------------------------------------------------------
	public boolean hasEntry(double level) {
		for (int i = map.size() - 1;i >= 0;--i) {
			Interval intv = map.get(i).getKey();
			if (intv.contains(level))
				return true;
		}
		return false;
	}
	
	//==================================================================================
	// implemented interfaces
	
	//----------------------------------------------------------------------------------
	public double defaultValue() { return minLevel;	}
	public int getAlpha(double level) { return getColor(level).getAlpha(); }
	public Color getDefaultColor() { return defaultColor; }
	public double getMaxLevel() { return maxLevel; }
	public double getMinLevel() { return minLevel; }
	public int getRGB(double level) { return getColor(level).getRGB(); }
	public boolean validLevel(double level) { return false;	}
	public String getName() { return name; }

	//----------------------------------------------------------------------------------
	public Color getColor(double level) {
		for (int i = map.size() - 1;i >= 0;--i) {
			Interval intv = map.get(i).getKey();
			if (intv.contains(level))
				return map.get(i).getValue() == null ? defaultColor : map.get(i).getValue();
		}
		return defaultColor;
	}

}