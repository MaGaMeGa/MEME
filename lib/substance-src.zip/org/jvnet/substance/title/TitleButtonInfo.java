/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.title;

import java.awt.event.ActionListener;

import org.jvnet.substance.SubstanceLookAndFeel;

/**
 * Contains information on a single title pane button. This class is part of
 * officially supported API.
 * 
 * @see SubstanceLookAndFeel#setRootPaneCustomTitleButtons(javax.swing.JRootPane,
 *      java.util.List)
 * @see SubstanceLookAndFeel#removeRootPaneCustomTitleButtons(javax.swing.JRootPane)
 * @author Kirill Grouchnikov
 */
public class TitleButtonInfo {
	/**
	 * Action listener to register on the corresponding title pane button.
	 */
	protected ActionListener actionListener;

	/**
	 * Callback for computing the icon for the corresponding title pane button.
	 */
	protected TitleButtonCallback buttonCallback;

	/**
	 * The tooltip text for the corresponding title pane button.
	 */
	protected String tooltipText;

	/**
	 * Indication whether the button should be toggle. If <code>true</code>,
	 * the icon and tooltip will be recomputed on every
	 * <code>model selected</code> event.
	 */
	protected boolean isToggle;

	/**
	 * Selected indication.
	 */
	protected boolean isSelected;

	/**
	 * Creates a new info object.
	 */
	public TitleButtonInfo() {
	}

	/**
	 * Returns the action listener to register on the corresponding title pane
	 * button.
	 * 
	 * @return The action listener to register on the corresponding title pane
	 *         button.
	 */
	public ActionListener getActionListener() {
		return actionListener;
	}

	/**
	 * Sets new action listener to register on the corresponding title pane
	 * button.
	 * 
	 * @param actionListener
	 *            New action listener to register on the corresponding title
	 *            pane button.
	 */
	public void setActionListener(ActionListener actionListener) {
		this.actionListener = actionListener;
	}

	/**
	 * Returns the callback for computing the icon for the corresponding title
	 * pane button.
	 * 
	 * @return The callback for computing the icon for the corresponding title
	 *         pane button.
	 */
	public TitleButtonCallback getButtonCallback() {
		return buttonCallback;
	}

	/**
	 * Sets new callback for computing the icon for the corresponding title pane
	 * button.
	 * 
	 * @param buttonCallback
	 *            New callback for computing the icon for the corresponding
	 *            title pane button.
	 */
	public void setButtonCallback(TitleButtonCallback buttonCallback) {
		this.buttonCallback = buttonCallback;
	}

	/**
	 * Returns the tooltip text for the corresponding title pane button.
	 * 
	 * @return The tooltip text for the corresponding title pane button.
	 */
	public String getTooltipText() {
		return tooltipText;
	}

	/**
	 * Sets the new tooltip text for the corresponding title pane button.
	 * 
	 * @param tooltip
	 *            The new tooltip text for the corresponding title pane button.
	 */
	public void setTooltipText(String tooltip) {
		this.tooltipText = tooltip;
	}

	/**
	 * Returns the toggle indication.
	 * 
	 * @return Indication whether the button should be toggle.
	 */
	public boolean isToggle() {
		return isToggle;
	}

	/**
	 * Sets the toggle indication.
	 * 
	 * @param isToggle
	 *            Indication whether the button should be toggle.
	 */
	public void setToggle(boolean isToggle) {
		this.isToggle = isToggle;
	}

	/**
	 * Returns the selection indication.
	 * 
	 * @return <code>true</code> if the button should be selected,
	 *         <code>false</code> otherwise.
	 */
	public boolean isSelected() {
		return isSelected;
	}

	/**
	 * Sets the selection indication.
	 * 
	 * @param isSelected
	 *            Indication whether the button should be selected.
	 */
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}
}
