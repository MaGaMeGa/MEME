package ai.aitia.visu.globalhandlers;

import java.awt.Frame;
import java.lang.Thread.UncaughtExceptionHandler;
import java.util.ConcurrentModificationException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/** Default implementation for the global uncaught exception handler. It creates a 
 *  message window to display the exception.
 */
public class DefaultExceptionHandler implements UncaughtExceptionHandler {

	/** Returns the active frame object if any. Otherwise returns <code>null</code>.
	 * @return the active frame or <code>null</code>
	 */
	private Frame findActiveFrame() {
		Frame[] frames = JFrame.getFrames();
	    for (int i = 0; i < frames.length; i++) {
	    	if (frames[i].isVisible()) {
	               return frames[i];
	        }
	    }
	    return null;
	}
	
	//-------------------------------------------------------------------------------
	/** Displays the exception in a message window which has a 'Strack Trace' button
	 *  to print the stack trace to the console (if any).
	 * @param t the given thread
	 * @param e the exception
	 */
	public void uncaughtException(Thread t, Throwable e) {
		if (e instanceof ConcurrentModificationException) {
			if (GlobalHandlers.getWarningManager().shouldDumpWarnings())
				e.printStackTrace();
			return;
		}
		Object[] options = { "OK", "Stack Trace" };
        int back = JOptionPane.showOptionDialog(findActiveFrame(),
	               								e.toString(),
	               								"Exception Occurred",
	               								JOptionPane.DEFAULT_OPTION,
	               								JOptionPane.WARNING_MESSAGE,
	               								null, options, options[0] );
       if ( 1 == back ) e.printStackTrace();
   } 
}
