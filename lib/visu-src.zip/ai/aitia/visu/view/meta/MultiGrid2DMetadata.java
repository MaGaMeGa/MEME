package ai.aitia.visu.view.meta;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ai.aitia.visu.view.ui.IFigureRenderer;

public class MultiGrid2DMetadata {

	//====================================================================================================
	// members
	
	private static final String DEFAULT_TITLE 			= "Untitled";
	private static final String DEFAULT_COLUMN_LABEL 	= "Column";
	private static final String DEFAULT_ROW_LABEL		= "Row";
	
	private String title = DEFAULT_TITLE;
	private String subtitle = null;
	private List<IFigureRenderer> figureRenderers = new ArrayList<IFigureRenderer>();
	private String columnLabel = DEFAULT_COLUMN_LABEL;
	private String rowLabel = DEFAULT_ROW_LABEL;
	private int environmentAppearance = Appearance.BASIC_APP;
	private CustomAppearance customAppearance = null;
	private String tooMany = "Sorry, the number of cells exceeds the drawing limit.";
	
	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public String getColumnLabel() { return columnLabel; }
	public boolean hasCustomAppearance() { return customAppearance != null; }
	public CustomAppearance getCustomAppearance() { return customAppearance; }
	public String getTooMany() { return tooMany; }
	public int getEnvironmentAppearance() {	return environmentAppearance; }
	public List<IFigureRenderer> getFigureRenderers() { return Collections.unmodifiableList(figureRenderers); }
	public String getRowLabel() { return rowLabel; }
	public String getSubtitle() { return subtitle; }
	public String getTitle() { return title; }
	
	//----------------------------------------------------------------------------------------------------
	public void setColumnLabel(String columnLabel) { this.columnLabel = columnLabel; }
	public void setCustomAppearance(CustomAppearance customAppearance) { this.customAppearance = customAppearance; }
	public void setTooMany(String tooMany) { this.tooMany = tooMany; }
	public void setEnvironmentAppearance(int environmentAppearance) { this.environmentAppearance = environmentAppearance; }
	public void addFigureRenderer(IFigureRenderer figureRenderer) { figureRenderers.add(figureRenderer); }
	public void addFigureRenderers(List<IFigureRenderer> figureRenderers) { this.figureRenderers.addAll(figureRenderers); }
	public void clearFigureRenderers() { figureRenderers.clear(); }
	public void setRowLabel(String rowLabel) { this.rowLabel = rowLabel; }
	public void setSubtitle(String subtitle) { this.subtitle = subtitle; }
	public void setTitle(String title) { this.title = title; }
}