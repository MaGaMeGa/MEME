/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs.assisttypes;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;

import javax.swing.AbstractAction;
import javax.swing.DefaultCellEditor;
import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;

/** Editor class to extend color, shape and element tables. */
public class NewValueEditor extends DefaultCellEditor {

	private static final long serialVersionUID = 1L;
	private JFormattedTextField ftf;
	
	//===============================================================================
	// additional members
	
	/** Format of the acceptable inputs. */
	private NumberFormat format;
	
	/** Formatter of the cell value. */
	private NumberFormatter formatter;
	
	/** List that contains the previous values of the table. It uses this to validate
	 *  that the added value is unique.
	 */
	List<Double> previousValues;
	
	//===============================================================================
	// methods
	
	/** Constructor. 
	 * @param previousValues list that contains the prvious values of the table
	 */
	public NewValueEditor(final List<Double> previousValues) {
		super(new JFormattedTextField());
		ftf = (JFormattedTextField)getComponent();
		this.previousValues = previousValues;
		
		format = NumberFormat.getNumberInstance(Locale.US);
		format.setMaximumFractionDigits(6);
		formatter = new NumberFormatter(format);
		formatter.setFormat(format);
		formatter.setValueClass(Double.class);
		
		ftf.setFormatterFactory(new DefaultFormatterFactory(formatter));
		ftf.setHorizontalAlignment(JTextField.TRAILING);
		ftf.setFocusLostBehavior(JFormattedTextField.PERSIST);
		ftf.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER,0),"check");
		ftf.getActionMap().put("check",new AbstractAction() {
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				try {
					if (ftf.isEditValid() && !previousValues.contains(formatter.stringToValue(ftf.getText()))) {
						ftf.commitEdit();
						//previousValues.add((Double)getCellEditorValue());
						ftf.postActionEvent();
					} else Toolkit.getDefaultToolkit().beep();
				} catch (ParseException ex) {}
			}
		});
	}
	
	//-------------------------------------------------------------------------------
	@Override
	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
												 int row, int column) {
		JFormattedTextField ftf = (JFormattedTextField)super.getTableCellEditorComponent(table, value, isSelected, row, column);
		ftf.setValue(value);
		return ftf;
	}
	
	//-------------------------------------------------------------------------------
	@Override
    public Object getCellEditorValue() {
        JFormattedTextField ftf = (JFormattedTextField)getComponent();
        Object o = ftf.getValue();
        if (o == null) return null;
        if (o instanceof Double) {
            return o;
        } else if (o instanceof Number) {
            return new Double(((Number)o).doubleValue());
        } else {
            try {
                return format.parseObject(o.toString());
            } catch (ParseException e) {
                return null;
            }
        }
    }

	//-------------------------------------------------------------------------------
	@Override
	public boolean stopCellEditing() {
        JFormattedTextField ftf = (JFormattedTextField)getComponent();
        try {
        	if (ftf.isEditValid() && !previousValues.contains(formatter.stringToValue(ftf.getText()))) {
                ftf.commitEdit();
                previousValues.add((Double)getCellEditorValue());
        	} else Toolkit.getDefaultToolkit().beep();
        } catch (java.text.ParseException e) { }
        return super.stopCellEditing();
    }
}
