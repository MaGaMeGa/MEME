package ai.aitia.visu.ds;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.jfree.data.general.Dataset;

import ai.aitia.visu.data.ExtendedHistogramDataset;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.event.IDataChangeListener;

public class ExtendedHistogramDatasetProducer implements IDataChangeListener,
														 IDatasetProducer {

	private ExtendedHistogramDataset dataset = null;
	
	private IDataProducer mainProducer = null;
	
	private int bins = 1;
	private IValueProducer binProducer = null;
	
	private double minValue = - Double.MAX_VALUE;
	private IValueProducer minValueProducer = null;
	
	private double maxValue = Double.MAX_VALUE;
	private IValueProducer maxValueProducer = null;
	
	private long time;
	boolean first = true;
	
	
	/** Constructor.
	 * 
	 *  The content of the list parameter must be the follow:<br>
	 *    - a value or series producer for the data of the histogram<br>
	 *    - an Integer value or a value producer for the number of bins<br>
	 *    - a Double value or a value producer for the min value of the histogram.
	 *      - Double.MAX_VALUE indicates this information is unknown<br>
	 *    - a Double value or a value producer for the max value of the histogram.
	 *      Double.MAX_VALUE indicates this information is unknown.<p>
	 */
	public ExtendedHistogramDatasetProducer(int type, int strategy, List<Object> data) throws DataSourceException {
		if (data.size() < 4)
			throw new DataSourceException("Missing input parameters.");
		
		dataset = new ExtendedHistogramDataset(type,strategy);
		
		if (data.get(0) instanceof IDataProducer) {
			mainProducer = (IDataProducer) data.get(0);
			mainProducer.addDataChangeListener(this);
		} else 
			throw new DataSourceException("Invalid histogram data.");
		if (data.get(1) instanceof Integer) {
			bins = (Integer) data.get(1);
			if (bins <= 0)
				throw new DataSourceException("Invalid value: number of bins.");
		} else if (data.get(1) instanceof IValueProducer) {
			binProducer = (IValueProducer) data.get(1);
			binProducer.addDataChangeListener(this);
		} else
			throw new DataSourceException("Invalid number of bins parameter.");
		if (data.get(2) instanceof Double)
			minValue = (Double) data.get(2);
		else if (data.get(2) instanceof IValueProducer) {
			minValueProducer = (IValueProducer) data.get(2);
			minValueProducer.addDataChangeListener(this);
		} else 
			throw new DataSourceException("Invalid minimum value parameter.");
		if (data.get(3) instanceof Double) 
			maxValue = (Double) data.get(3);
		else if (data.get(3) instanceof IValueProducer) {
			maxValueProducer = (IValueProducer) data.get(3);
			maxValueProducer.addDataChangeListener(this);
		} else
			throw new DataSourceException("Invalid maximum value parameter.");
	}
		
	public void dataChanged(DataChangeEvent event) {
		Object source = event.getSource();
		if (source.equals(binProducer)) {
			int tempBins = Math.max(1,(int)binProducer.produceValue());
			if (tempBins != bins) {
				bins = tempBins;
				time = binProducer.getTime();
				first = true;
			}
		} else if (source.equals(minValueProducer)) {
			double tempMinValue = minValueProducer.produceValue();
			if (tempMinValue != minValue) {
				minValue = tempMinValue;
				time = minValueProducer.getTime();
				first = true;
			}
		} else if (source.equals(maxValueProducer)) {
			double tempMaxValue = maxValueProducer.produceValue();
			if (tempMaxValue != maxValue) {
				maxValue = tempMaxValue;
				time = maxValueProducer.getTime();
				first = true;
			}
		} else if (source.equals(mainProducer)) {
			if (first) {
				String name = mainProducer.getName();
				if (minValue > maxValue) {
					double temp = minValue;
					minValue = maxValue;
					maxValue = temp;
				}
				dataset.addSeries(name, new ArrayList<Double>(0), bins, minValue, maxValue);
				first = false;
			}
			if (source instanceof IValueProducer) {
				IValueProducer p = (IValueProducer) mainProducer;
				dataset.addValue(p.produceValue());
				time = p.getTime();
			} else if (source instanceof ISeriesProducer) {
				ISeriesProducer p = (ISeriesProducer) source;
				dataset.replaceValues(p.produceSeries());
				time = p.getTime();
			}
		}
	}

	public Dataset produceDataset(Properties queryProperties) throws DataSourceException {
		return dataset;
	}

	public long getTime() {
		return time;
	}
}
