package ai.aitia.visu.globalhandlers;

/** Exception class to represents interrupt actions caused by the user. */
public class UserBreakException extends Exception {

	private static final long serialVersionUID = 1L;
	
	//================================================================================
	// methods
	
	/** Constructor.
	 * @param t cause this exception
	 */
	public UserBreakException(Throwable t) {
		super(t);
	}
	
	//--------------------------------------------------------------------------------
	
	/** Constructor.
	 * @param message description of the exception
	 */
	public UserBreakException(String message) {
		super(message);
	}
}
