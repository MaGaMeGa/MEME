package ai.aitia.visu.view.plot;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RectangularShape;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.jfree.chart.ClipPath;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.AxisChangeEvent;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.urls.XYURLGenerator;
import org.jfree.data.Range;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;
import org.jfree.util.ObjectUtilities;

import ai.aitia.visu.data.Grid2DDataset;
import ai.aitia.visu.view.entity.Grid2DEntity;
import ai.aitia.visu.view.labels.DefaultGrid2DToolTipGenerator;
import ai.aitia.visu.view.labels.Grid2DToolTipGenerator;
import ai.aitia.visu.view.ui.BlackAndWhiteColorMap;
import ai.aitia.visu.view.ui.ColorMap;
import ai.aitia.visu.view.ui.ColorMapCollection;
import ai.aitia.visu.view.ui.ColorMapFigureRenderer;
import ai.aitia.visu.view.ui.IFigureRenderer;
import ai.aitia.visu.view.ui.RainbowColorMap;
import ai.aitia.visu.view.ui.SimpleColorMap;

public class MultiGrid2DPlot extends Plot implements PropertyChangeListener {


	//====================================================================================================
	// members
	
	private static final long serialVersionUID = 1L;
	
	protected static final int MAXIMUM_NUMBER_OF_GRIDS = 20000;
	
    protected static final RectangleInsets DEFAULT_INSETS = new RectangleInsets(2.0, 2.0, 100.0, 10.0);

    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;

    private Grid2DDataset[] datasets;

//    private RectangleEdge colorBarLocation;
//    protected ColorBar colorBar = new ColorBar("Colors"); //TODO: hogyan, ha t�bb dataset van
    
    private boolean domainCrosshairVisible;
    private double domainCrosshairValue;
    private transient Stroke domainCrosshairStroke;
    private transient Paint domainCrosshairPaint;
    private boolean domainCrosshairLockedOnData = true;

    private boolean rangeCrosshairVisible;
    private double rangeCrosshairValue;
    private transient Stroke rangeCrosshairStroke;
    private transient Paint rangeCrosshairPaint;
    private boolean rangeCrosshairLockedOnData = true;

    private List<Marker> domainMarkers;
    private List<Marker> rangeMarkers;

    private Grid2DToolTipGenerator toolTipGenerator;
    private boolean needTooltip = false;
    
    private XYURLGenerator urlGenerator;

//    private boolean renderAsPoints = false; TODO: mire kell ez?
//    private double ptSizePct = 0.05;

    private transient ClipPath clipPath = null;
    private transient Paint missingPaint = null;

    protected static ResourceBundle localizationResources = ResourceBundle.getBundle("org.jfree.chart.plot.LocalizationBundle");

    protected IFigureRenderer[] figureRenderers = null;
    protected boolean isUpdateColorMap = false;
    protected List<Integer> updateableColorMapIndices = new ArrayList<Integer>();

    private double dataAreaRatio;
    
    protected String tooMany = "Sorry, the number of cells exceeds the drawing limit.";
    
	//====================================================================================================
	// methods

    //----------------------------------------------------------------------------------------------------
	public MultiGrid2DPlot(Grid2DDataset[] datasets, String columnLabel, String rowLabel, IFigureRenderer[] figureRenderers, boolean needTooltip) {
        super();
        setBackgroundPaint(Color.WHITE);
        if (figureRenderers.length < datasets.length)
        	throw new IllegalArgumentException("There are missing figure renderes.");
        
        this.datasets = datasets;
        this.figureRenderers = figureRenderers;
        this.needTooltip = needTooltip;
        
        int width = 0, height = 0;
        for (Grid2DDataset dataset : datasets) {
            dataset.addChangeListener(this);
            if (dataset.getWidth() > width)
            	width = dataset.getWidth();
            if (dataset.getHeight() > height)
            	height = dataset.getHeight();
        }

        NumberAxis xAxis = new NumberAxis(columnLabel);
        NumberAxis yAxis = new NumberAxis(rowLabel);
        	       	        
        xAxis.setRange(0.5, width+0.5);
        xAxis.setAutoRange(true);        
        xAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        
        yAxis.setRange(0.5, height+0.5);
        yAxis.setAutoRange(true);
        yAxis.setInverted(true);
        yAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        
        xAxis.setLowerMargin(0.0);
        xAxis.setUpperMargin(0.0);

        yAxis.setLowerMargin(0.0);
        yAxis.setUpperMargin(0.0);		        
        
        this.domainAxis = xAxis;
        if (domainAxis != null) {
            domainAxis.setPlot(this);
        }

        this.rangeAxis = yAxis;
        if (rangeAxis != null) {
            rangeAxis.setPlot(this);
        }
        
        dataAreaRatio = ((double)height / (double)width);
        
        if (needTooltip)
        	this.toolTipGenerator = new DefaultGrid2DToolTipGenerator();
        
        isUpdateColorMap = isUpdateColorMap();
        if (isUpdateColorMap) {
        	for (Integer i : updateableColorMapIndices)
        		datasetChanged(new DatasetChangeEvent(datasets[i],datasets[i]));
        }
        // itt kell csin�lni valamit a colorbarral, ha van
    }
    
    //----------------------------------------------------------------------------------------------------
	public MultiGrid2DPlot(Grid2DDataset[] datasets, String columnLabel, String rowLabel, IFigureRenderer[] figureRenderers, boolean needTooltip, String tooMany) {
    	this(datasets,columnLabel,rowLabel,figureRenderers,needTooltip);
    	this.tooMany = tooMany;
    }
	
	//----------------------------------------------------------------------------------------------------
//    public RectangleEdge getColorBarLocation() { return colorBarLocation; }
    public Grid2DDataset[] getDatasets() { return datasets; }
    public ValueAxis getDomainAxis() { return domainAxis; }
    public ValueAxis getRangeAxis() { return rangeAxis; }
    @Override public String getPlotType() { return localizationResources.getString("Contour_Plot"); }
//    public ColorBar getColorBar() { return colorBar; }
    public boolean isDomainCrosshairVisible() { return domainCrosshairVisible; }
    public boolean isDomainCrosshairLockedOnData() { return domainCrosshairLockedOnData; }
    public double getDomainCrosshairValue() { return domainCrosshairValue; }
    public Stroke getDomainCrosshairStroke() { return domainCrosshairStroke; }
    public Paint getDomainCrosshairPaint() { return domainCrosshairPaint; }
    public boolean isRangeCrosshairVisible() { return rangeCrosshairVisible; }
    public boolean isRangeCrosshairLockedOnData() { return rangeCrosshairLockedOnData; }
    public double getRangeCrosshairValue() { return rangeCrosshairValue; }
    public Stroke getRangeCrosshairStroke() { return rangeCrosshairStroke; }
    public Paint getRangeCrosshairPaint() { return rangeCrosshairPaint; }
    public boolean hasTooltip() { return needTooltip; }
    public Grid2DToolTipGenerator getToolTipGenerator() { return toolTipGenerator; }
    public XYURLGenerator getURLGenerator() { return urlGenerator; }
    public ClipPath getClipPath() { return clipPath; }
    public Paint getMissingPaint() { return missingPaint; }
    public boolean isDomainZoomable() { return false; }
    public boolean isRangeZoomable() {  return false; }

    //----------------------------------------------------------------------------------------------------
//    public void setColorBarLocation(RectangleEdge edge) {
//        this.colorBarLocation = edge;
//        notifyListeners(new PlotChangeEvent(this));    
//    }
    
    //----------------------------------------------------------------------------------------------------
	public void setDataset(Grid2DDataset dataset, int index) {
		if (index < 0 || index >= datasets.length)
			return;
        
        Grid2DDataset existing = datasets[index];
        
        if (existing != null) {
            existing.removeChangeListener(this);
        }

        datasets[index] = dataset;
        if (dataset != null) {
            setDatasetGroup(dataset.getGroup());
            dataset.addChangeListener(this);
        }

        // send a dataset change event to self...
        DatasetChangeEvent event = new DatasetChangeEvent(this,dataset);
        datasetChanged(event);
    }

	//----------------------------------------------------------------------------------------------------
    public void setDomainAxis(ValueAxis axis) {
        if (axis != null) {
            axis.setPlot(this);
            axis.addChangeListener(this);
        }

        // plot is likely registered as a listener with the existing axis...
        if (this.domainAxis != null)
            this.domainAxis.removeChangeListener(this);

        this.domainAxis = axis;
        notifyListeners(new PlotChangeEvent(this));
    }

    //----------------------------------------------------------------------------------------------------
    public void setRangeAxis(ValueAxis axis) {
        if (axis != null) {
            axis.setPlot(this);
            axis.addChangeListener(this);
        }

        // plot is likely registered as a listener with the existing axis...
        if (this.rangeAxis != null) 
            this.rangeAxis.removeChangeListener(this);

        this.rangeAxis = axis;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    //----------------------------------------------------------------------------------------------------
	public void setDomainCrosshairVisible(boolean flag) {
        if (domainCrosshairVisible != flag) {
            domainCrosshairVisible = flag;
            notifyListeners(new PlotChangeEvent(this));
        }
    }

	//----------------------------------------------------------------------------------------------------
	public void setDomainCrosshairLockedOnData(boolean flag) {
        if (domainCrosshairLockedOnData != flag) {
            domainCrosshairLockedOnData = flag;
            notifyListeners(new PlotChangeEvent(this));
        }
    }

	//----------------------------------------------------------------------------------------------------
    public void setDomainCrosshairValue(double value) { setDomainCrosshairValue(value,true); }
    public void setDomainCrosshairValue(double value, boolean notify) {
        domainCrosshairValue = value;
        if (domainCrosshairVisible && notify) 
            notifyListeners(new PlotChangeEvent(this));
    }

    //----------------------------------------------------------------------------------------------------
    public void setDomainCrosshairStroke(Stroke stroke) {
        domainCrosshairStroke = stroke;
        notifyListeners(new PlotChangeEvent(this));
    }

    //----------------------------------------------------------------------------------------------------
	public void setDomainCrosshairPaint(Paint paint) {
        domainCrosshairPaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }


	//----------------------------------------------------------------------------------------------------
	public void setRangeCrosshairVisible(boolean flag) {
        if (rangeCrosshairVisible != flag) {
            rangeCrosshairVisible = flag;
            notifyListeners(new PlotChangeEvent(this));
        }
    }

	//----------------------------------------------------------------------------------------------------
	public void setRangeCrosshairLockedOnData(boolean flag) {
        if (rangeCrosshairLockedOnData != flag) {
            rangeCrosshairLockedOnData = flag;
            notifyListeners(new PlotChangeEvent(this));
        }
    }

	//----------------------------------------------------------------------------------------------------
    public void setRangeCrosshairValue(double value) { setRangeCrosshairValue(value,true); }
    public void setRangeCrosshairValue(double value, boolean notify) {
        rangeCrosshairValue = value;
        if (rangeCrosshairVisible && notify) 
            notifyListeners(new PlotChangeEvent(this));
    }

    //----------------------------------------------------------------------------------------------------
	public void setRangeCrosshairStroke(Stroke stroke) {
        rangeCrosshairStroke = stroke;
        notifyListeners(new PlotChangeEvent(this));
    }

	//----------------------------------------------------------------------------------------------------
	public void setRangeCrosshairPaint(Paint paint) {
        rangeCrosshairPaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }
	
    //----------------------------------------------------------------------------------------------------
	public void setToolTipGenerator(Grid2DToolTipGenerator generator) { toolTipGenerator = generator; }
    public void setURLGenerator(XYURLGenerator urlGenerator) { this.urlGenerator = urlGenerator; }
    public void setClipPath(ClipPath clipPath) { this.clipPath = clipPath; }
    public void setMissingPaint(Paint paint) { missingPaint = paint; }

    //----------------------------------------------------------------------------------------------------
    public void addDomainMarker(Marker marker) {
        if (this.domainMarkers == null) 
            this.domainMarkers = new java.util.ArrayList<Marker>();
        this.domainMarkers.add(marker);
        notifyListeners(new PlotChangeEvent(this));
    }

    //----------------------------------------------------------------------------------------------------
	public void clearDomainMarkers() {
        if (this.domainMarkers != null) {
            this.domainMarkers.clear();
            notifyListeners(new PlotChangeEvent(this));
        }
    }

    //----------------------------------------------------------------------------------------------------
    public void addRangeMarker(Marker marker) {
        if (this.rangeMarkers == null) 
            this.rangeMarkers = new java.util.ArrayList<Marker>();
        this.rangeMarkers.add(marker);
        notifyListeners(new PlotChangeEvent(this));
    }

    //----------------------------------------------------------------------------------------------------
    public void clearRangeMarkers() {
        if (this.rangeMarkers != null) {
            this.rangeMarkers.clear();
            notifyListeners(new PlotChangeEvent(this));
        }
    }

    //----------------------------------------------------------------------------------------------------
	@Override
    public void draw(Graphics2D g2, Rectangle2D area, Point2D anchor, PlotState parentState, PlotRenderingInfo info) {
        // if the plot area is too small, just return...
        boolean b1 = area.getWidth() <= MINIMUM_WIDTH_TO_DRAW;
        boolean b2 = area.getHeight() <= MINIMUM_HEIGHT_TO_DRAW;
        if (b1 || b2) return;
        
        if (tooManyData()) {
        	Font font = g2.getFont().deriveFont(20.0f);
        	g2.setFont(font);
        	FontMetrics fm = g2.getFontMetrics();
       		g2.setPaint(Color.BLACK);
        	g2.drawString(tooMany,(int)(area.getX() + ((area.getWidth()- fm.stringWidth(tooMany)) /2)),(int)(area.getY() + area.getHeight() /2 + fm.getAscent()/2));
        	return;
        }

        // record the plot area...
        if (info != null) 
            info.setPlotArea(area);

        // adjust the drawing area for plot insets (if any)...
        RectangleInsets insets = getInsets();
        insets.trim(area);

        AxisSpace space = new AxisSpace();
        space = this.domainAxis.reserveSpace(g2,this,area,RectangleEdge.BOTTOM,space);
        space = this.rangeAxis.reserveSpace(g2,this,area,RectangleEdge.LEFT,space);

        /*Rectangle2D estimatedDataArea =*/ space.shrink(area,null);
        
        AxisSpace space2 = new AxisSpace();
        Rectangle2D adjustedPlotArea = space2.shrink(area,null);
        
        Rectangle2D dataArea = space.shrink(adjustedPlotArea,null);

//        Rectangle2D colorBarArea = space2.reserved(area,colorBarLocation);

        // additional dataArea modifications
        if (dataAreaRatio != 0.0) { //check whether modification is
            double ratio = dataAreaRatio;
            Rectangle2D tmpDataArea = (Rectangle2D) dataArea.clone();
            double h = tmpDataArea.getHeight();
            double w = tmpDataArea.getWidth();

            if (ratio > 0) { // ratio represents pixels
                if (w * ratio <= h) 
                    h = ratio * w;
                else
                    w = h / ratio;
            } else {  // ratio represents axis units
                ratio *= -1.0;
                double xLength = domainAxis.getRange().getLength();
                double yLength = rangeAxis.getRange().getLength();
                double unitRatio = yLength / xLength;

                ratio = unitRatio * ratio;

                if (w * ratio <= h) 
                    h = ratio * w;
                else 
                    w = h / ratio;
            }

            dataArea.setRect(tmpDataArea.getX() + tmpDataArea.getWidth() / 2 - w / 2,
            				 tmpDataArea.getY(),w,h);
        }

        if (info != null) 
            info.setDataArea(dataArea);

        CrosshairState crosshairState = new CrosshairState();
        crosshairState.setCrosshairDistance(Double.POSITIVE_INFINITY);

        // draw the plot background...
        drawBackground(g2,dataArea);

        double cursor = dataArea.getMaxY();
        
        int width = 0, height = 0;
        for (Grid2DDataset dataset : datasets) {
        	if (dataset.getWidth() > width)
        		width = dataset.getWidth();
        	if (dataset.getHeight() > height)
        		height = dataset.getHeight();
        }
                
        if (domainAxis != null) {
        	domainAxis.setRange(0.5,width + 0.5);
            domainAxis.draw(g2,cursor,adjustedPlotArea,dataArea,RectangleEdge.BOTTOM,info);
        }
        
        if (rangeAxis != null) {
        	rangeAxis.setRange(0.5,height + 0.5);
            cursor = dataArea.getMinX();
            this.rangeAxis.draw(g2,cursor,adjustedPlotArea,dataArea,RectangleEdge.LEFT,info);
        }

        Shape originalClip = g2.getClip();
        Composite originalComposite = g2.getComposite();

        g2.clip(dataArea);
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,getForegroundAlpha()));
        render(g2,dataArea,info,crosshairState,width,height);

        if (domainMarkers != null) {
        	for (Marker marker : domainMarkers)
                drawDomainMarker(g2,this,domainAxis,marker,dataArea);
        }

        if (rangeMarkers != null) {
        	for (Marker marker : rangeMarkers)
                drawRangeMarker(g2,this,rangeAxis,marker,dataArea);
        }

        g2.setClip(originalClip);
        g2.setComposite(originalComposite);
        drawOutline(g2, dataArea);
    }

    //----------------------------------------------------------------------------------------------------
	public void render(Graphics2D g2, Rectangle2D dataArea, PlotRenderingInfo info, CrosshairState crosshairState, int width, int height) {

        // now get the data and plot it (the visual representation will depend
        // on the renderer that has been set)...
        
        for (int i = datasets.length - 1;i >= 0;--i) {
        
//            ColorBar zAxis = getColorBar();
            if (clipPath != null) {
                GeneralPath clipper = clipPath.draw(g2,dataArea,domainAxis,rangeAxis);
                if (clipPath.isClip()) 
                    g2.clip(clipper);
            }
            
            drawGrid(g2,dataArea,info,domainAxis,rangeAxis,datasets[i],crosshairState,width,height,i,i == datasets.length - 1);

            // draw vertical crosshair if required...
            setDomainCrosshairValue(crosshairState.getCrosshairX(),false);
            if (isDomainCrosshairVisible()) 
                drawVerticalLine(g2,dataArea,domainCrosshairValue,domainCrosshairStroke,domainCrosshairPaint);

            // draw horizontal crosshair if required...
            setRangeCrosshairValue(crosshairState.getCrosshairY(),false);
            if (isRangeCrosshairVisible()) 
                drawHorizontalLine(g2,dataArea,rangeCrosshairValue,rangeCrosshairStroke,rangeCrosshairPaint);

        }
    }

    //----------------------------------------------------------------------------------------------------
	public void drawGrid(Graphics2D g2, Rectangle2D dataArea, PlotRenderingInfo info, ValueAxis domainAxis,
                         ValueAxis rangeAxis, Grid2DDataset data, CrosshairState crosshairState, int width, int height, int index, boolean drawBackground) {
        // setup for collecting optional entity info...
		
		EntityCollection entities = null;
		RectangularShape entityArea = null;
		if (needTooltip && info != null) 
				entities = info.getOwner().getEntityCollection();

		Rectangle2D.Double rect = new Rectangle2D.Double();

        //turn off anti-aliasing when filling rectangles
        Object antiAlias = g2.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_OFF);
        
        double transX = 0.0, transDX = 0.0, transY = 0.0, transDY = 0.0;
        
        double sizeX = dataArea.getWidth() / width;
        double sizeY = dataArea.getHeight() / height;
        
        if (drawBackground) {
            g2.setPaint(getBackgroundPaint());
            g2.fill(dataArea);
        }
        
        for (double[] element : data.getValuesCollection()) {
        	if (element[2] == - Double.MAX_VALUE) continue;

        	transX = domainAxis.valueToJava2D(element[0] + 0.5, dataArea, RectangleEdge.BOTTOM);
            transY = rangeAxis.valueToJava2D(element[1] + 0.5, dataArea, RectangleEdge.LEFT);
            
            transDX = sizeX;
            transDY = sizeY;
            
            rect.setFrame(transX,transY,transDX,transDY);
            figureRenderers[index].render(g2,rect,element[2]);            
            
            entityArea = rect;
            
            // add an entity for the item...
            if (needTooltip && entities != null && rect.width >= 2 && rect.height >= 2) {
                String tip = null;
                if (toolTipGenerator != null) {
                    tip = toolTipGenerator.generateToolTip(data,(int)element[0],(int)element[1]);
                }
                Grid2DEntity entity = new Grid2DEntity((RectangularShape)entityArea.clone(),tip,null);
                entity.setX((int)element[0]);
                entity.setY((int)element[1]);
                entities.add(entity);
            }
        }
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,antiAlias);
    }

	//----------------------------------------------------------------------------------------------------
	@Override
    public void datasetChanged(final DatasetChangeEvent event) {
    	if (isUpdateColorMap) {
    		final Grid2DDataset ds = (Grid2DDataset) event.getDataset();
    		final IFigureRenderer renderer = findRenderer(ds);
    		if (renderer != null && renderer instanceof ColorMapFigureRenderer) {
    			final ColorMapFigureRenderer _renderer = (ColorMapFigureRenderer) renderer;
    			ColorMap colorMap = _renderer.getColorMap();
				final ColorMapUpdateOption updateOption = ColorMapUpdateOption.getOption(colorMap.getMinLevel(),colorMap.getMaxLevel());
				
				if (updateOption != ColorMapUpdateOption.NONE) {
		    		final double[][] values = ds.getValues();
		    		double min = Double.MAX_VALUE;
		    		double max = - Double.MAX_VALUE;
		    		for (int i = 0;i < ds.getWidth();++i) {
		    			for (int j = 0;j < ds.getHeight();++j) {
							if (values[i][j] != - Double.MAX_VALUE && values[i][j] < min)
								min = values[i][j];
							if (values[i][j] > max)
								max = values[i][j];
		    			}
		    		}
		    		
		    		if (colorMap instanceof RainbowColorMap) {
		    			final RainbowColorMap cm = (RainbowColorMap) colorMap;
		    			if (updateOption.contains(ColorMapUpdateOption.MIN))
		    				cm.setMinLevel(min);
		    			if (updateOption.contains(ColorMapUpdateOption.MAX))
		    				cm.setMaxLevel(max);
		    			//if (colorBar != null) colorBar.configure(cm);
		    		} else if (colorMap instanceof BlackAndWhiteColorMap) {
		    			final BlackAndWhiteColorMap cm = (BlackAndWhiteColorMap) colorMap;
		    			if (updateOption.contains(ColorMapUpdateOption.MIN))
		    				cm.setMinLevel(min);
		    			if (updateOption.contains(ColorMapUpdateOption.MAX))
		    				cm.setMaxLevel(max);
		    			//if (colorBar != null) colorBar.configure(cm);
		    		} else if (colorMap instanceof SimpleColorMap) {
		    			final SimpleColorMap cm = (SimpleColorMap) colorMap;
		       			if (!updateOption.contains(ColorMapUpdateOption.MIN))
		    				min = cm.getMinLevel();
		    			if (!updateOption.contains(ColorMapUpdateOption.MAX))
		    				max = cm.getMaxLevel();
		    			if (max >= min)
		    				cm.setLevels(min,max,cm.minColor,new Color(cm.maxRed,cm.maxGreen,cm.maxBlue));
		    			//if (colorBar != null) colorBar.configure(cm);
		    		} else if (colorMap instanceof ColorMapCollection) {
		    			final ColorMapCollection cm = (ColorMapCollection) colorMap;
		       			if (updateOption.contains(ColorMapUpdateOption.MIN))
		       				cm.setMinLevel(min);
		       			if (updateOption.contains(ColorMapUpdateOption.MAX))
		       				cm.setMaxLevel(max);
		    			//if (colorBar != null) colorBar.configure(cm);
		    		}
				}
    		}
    	}
        if (domainAxis != null) 
            domainAxis.configure();
        if (rangeAxis != null) {
            rangeAxis.configure();
        }
        super.datasetChanged(event);
    }
	
	//----------------------------------------------------------------------------------------------------
	public void drawDomainMarker(Graphics2D g2, MultiGrid2DPlot plot, ValueAxis domainAxis, Marker marker, Rectangle2D dataArea) {
        if (marker instanceof ValueMarker) {
            ValueMarker vm = (ValueMarker) marker;
            double value = vm.getValue();
            Range range = domainAxis.getRange();
            if (!range.contains(value)) return;
  
            double x = domainAxis.valueToJava2D(value,dataArea,RectangleEdge.BOTTOM);
            Line2D line = new Line2D.Double(x,dataArea.getMinY(),x,dataArea.getMaxY());
            Paint paint = marker.getOutlinePaint();
            Stroke stroke = marker.getOutlineStroke();
            g2.setPaint(paint != null ? paint : Plot.DEFAULT_OUTLINE_PAINT);
            g2.setStroke(stroke != null ? stroke : Plot.DEFAULT_OUTLINE_STROKE);
            g2.draw(line);
        }
    }

	//----------------------------------------------------------------------------------------------------
	public void drawRangeMarker(Graphics2D g2, MultiGrid2DPlot plot, ValueAxis rangeAxis, Marker marker, Rectangle2D dataArea) {
        if (marker instanceof ValueMarker) {
            ValueMarker vm = (ValueMarker) marker;
            double value = vm.getValue();
            Range range = rangeAxis.getRange();
            if (!range.contains(value)) return;

            double y = rangeAxis.valueToJava2D(value,dataArea,RectangleEdge.LEFT);
            Line2D line = new Line2D.Double(dataArea.getMinX(),y,dataArea.getMaxX(),y);
            Paint paint = marker.getOutlinePaint();
            Stroke stroke = marker.getOutlineStroke();
            g2.setPaint(paint != null ? paint : Plot.DEFAULT_OUTLINE_PAINT);
            g2.setStroke(stroke != null ? stroke : Plot.DEFAULT_OUTLINE_STROKE);
            g2.draw(line);
        }
    }

	//----------------------------------------------------------------------------------------------------
	@Override
	public void axisChanged(AxisChangeEvent event) {
//        Object source = event.getSource();
//        if (source.equals(this.rangeAxis) || source.equals(this.domainAxis)) {
//            ColorBar cba = this.colorBar;
//            if (this.colorBar.getAxis().isAutoRange()) {
//                cba.getAxis().configure();
//            }
//
//        }
//        super.axisChanged(event);
    }
 

	//----------------------------------------------------------------------------------------------------
    @SuppressWarnings("unchecked")
	@Override
	public Object clone() throws CloneNotSupportedException {
        MultiGrid2DPlot clone = (MultiGrid2DPlot) super.clone();
        
        if (domainAxis != null) {
            clone.domainAxis = (ValueAxis) domainAxis.clone();
            clone.domainAxis.setPlot(clone);
            clone.domainAxis.addChangeListener(clone);
        }
        if (rangeAxis != null) {
            clone.rangeAxis = (ValueAxis) this.rangeAxis.clone();
            clone.rangeAxis.setPlot(clone);
            clone.rangeAxis.addChangeListener(clone);
        }
        
        for (Grid2DDataset dataset : clone.datasets)
            dataset.addChangeListener(clone); 
    
//        if (colorBar != null) 
//            clone.colorBar = (ColorBar) colorBar.clone();

        clone.domainMarkers = (List) ObjectUtilities.deepClone(domainMarkers);
        clone.rangeMarkers = (List) ObjectUtilities.deepClone(rangeMarkers);

        if (clipPath != null) 
        	clone.clipPath = (ClipPath) clipPath.clone(); 

        return clone;
    }

	//====================================================================================================
	// implemented interfaces
	
	//----------------------------------------------------------------------------------------------------
	public void propertyChange(PropertyChangeEvent evt) {
		notifyListeners(new PlotChangeEvent(this));		
	}
	
	//====================================================================================================
	// private methods

	//----------------------------------------------------------------------------------------------------
    protected void drawVerticalLine(Graphics2D g2, Rectangle2D dataArea, double value, Stroke stroke, Paint paint) {
        double xx = domainAxis.valueToJava2D(value,dataArea,RectangleEdge.BOTTOM);
        Line2D line = new Line2D.Double(xx,dataArea.getMinY(),xx,dataArea.getMaxY());
        g2.setStroke(stroke);
        g2.setPaint(paint);
        g2.draw(line);
    }

    //----------------------------------------------------------------------------------------------------
	protected void drawHorizontalLine(Graphics2D g2, Rectangle2D dataArea, double value, Stroke stroke, Paint paint) {
        double yy = rangeAxis.valueToJava2D(value,dataArea,RectangleEdge.LEFT);
        Line2D line = new Line2D.Double(dataArea.getMinX(),yy,dataArea.getMaxX(),yy);
        g2.setStroke(stroke);
        g2.setPaint(paint);
        g2.draw(line);
    }
	
	//----------------------------------------------------------------------------------------------------
	private boolean tooManyData() {
		for (Grid2DDataset dataset : datasets) {
			if (dataset.getValuesCollection().size() > MAXIMUM_NUMBER_OF_GRIDS)
				return true;
		}
		return false;
	}
	
	//----------------------------------------------------------------------------------------------------
	private boolean isUpdateColorMap() {
		for (int i = 0;i < figureRenderers.length;++i) {
			if (figureRenderers[i] instanceof ColorMapFigureRenderer) {
				ColorMapFigureRenderer cr = (ColorMapFigureRenderer) figureRenderers[i];
				if (cr.getColorMap().getMinLevel() == - Double.MAX_VALUE || 
					cr.getColorMap().getMaxLevel() == Double.MAX_VALUE) {
					updateableColorMapIndices.add(i);
				}
			}
		}
		return updateableColorMapIndices.size() > 0;
	}
	
	//----------------------------------------------------------------------------------------------------
	private IFigureRenderer findRenderer(final Grid2DDataset ds) {
		int idx = -1;
		for (int i = 0; i < datasets.length;++i) {
			if (datasets[i] == ds) { 
				idx = i;
				break;
			}
		}
		if (idx == -1) return null;
		return figureRenderers[idx];
	}
}