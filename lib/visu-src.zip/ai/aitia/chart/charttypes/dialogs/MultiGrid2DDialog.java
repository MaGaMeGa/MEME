package ai.aitia.chart.charttypes.dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.Map.Entry;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;

import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.GridLayerDialog;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.ds.ConstantColorDataSourceProducer;
import ai.aitia.chart.ds.IGrid2DDatasetProducer;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.Utilities.IGridConstants;
import ai.aitia.chart.view.ui.AutomaticFigureRenderer;
import ai.aitia.chart.view.ui.ConstantColorMap;
import ai.aitia.chart.view.ui.UserDefinedFigureRenderer;
import ai.aitia.chart.view.ui.UserDefinedFigureRenderer.Triplet;
import ai.aitia.meme.utils.FormsUtils;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.utils.Interval;
import ai.aitia.visu.view.ui.BlackAndWhiteColorMap;
import ai.aitia.visu.view.ui.ColorMap;
import ai.aitia.visu.view.ui.ColorMapCollection;
import ai.aitia.visu.view.ui.ColorMapFigureRenderer;
import ai.aitia.visu.view.ui.IFigureRenderer;
import ai.aitia.visu.view.ui.IntervalTableColorMap;
import ai.aitia.visu.view.ui.RainbowColorMap;
import ai.aitia.visu.view.ui.SimpleColorMap;
import ai.aitia.visu.view.ui.IntervalTableColorMap.Pair;

public class MultiGrid2DDialog extends AbstractChartDialog implements ActionListener,
																	  FocusListener,
																	  MouseListener {

	//====================================================================================================
	// members
	
	private static final long serialVersionUID = 1L;
	
	private DefaultListModel listModel = null;
	private boolean greyScale = ChartConfigCollection.getColorAppearance() == ChartConstants.BLACK_AND_WHITE;
	
	//====================================================================================================
	// GUI members
	
	private JTabbedPane tabbed = new JTabbedPane();
	private JPanel layerPanel = null;
	private JList layerList = new JList();
	private JScrollPane layerListScr = new JScrollPane(layerList);
	private JButton addButton = new JButton("Add new layer...");
	private JButton editButton = new JButton("Edit layer...");
	private JButton moveUpButton = new JButton("Move up");
	private JButton moveDownButton = new JButton("Move down");
	private JButton removeButton = new JButton("Remove");
	
	private JPanel detailsPanel = null;
	private JTextField subtitleField = new JTextField();
	private JTextField rowLabelField = new JTextField();
	private JTextField columnLabelField = new JTextField();
	private JComboBox appearanceBox = null;
	
	private JPanel buttonPanel = null;
	private JButton cancelButton = new JButton("Cancel");
	
	private JPopupMenu contextMenu = new JPopupMenu();
	private AbstractAction addAction = null;
	private AbstractAction editAction = null;
	private AbstractAction moveUpAction = null;
	private AbstractAction moveDownAction = null;
	private AbstractAction removeAction = null;
	
	//====================================================================================================
	// methods

	//----------------------------------------------------------------------------------------------------
	public MultiGrid2DDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		listModel = new DefaultListModel();
		layoutGUI();
		initialize();
		setSettingsFromConfig();
	}

	//----------------------------------------------------------------------------------------------------
	@Override public boolean isUpdateable() { return !listModel.isEmpty(); }

	//----------------------------------------------------------------------------------------------------
	@Override
	public void updateChartConfig() {
 		config.clearAllDataSource();
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 3) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
	 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
	 		if (code[0].equals("B"))
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.BASIC_APP);
	 		else
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.NORMAL_APP);
	 		if (code[1].equals("BW"))
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.BLACK_AND_WHITE);
	 		else
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.COLORED);
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
		
		List<Properties> props = new ArrayList<Properties>();
		props.add(properties);
		for (int i = 0;i < listModel.size();++i) {
			GridLayer layer = (GridLayer) listModel.get(i);
			props.add(layer.createPropertiesAndRegistrateDataSources(config,greyScale));
		}
  		config.setChartProperties(ChartConstants.MULTIGRID2D,props);
	}
	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem) appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//====================================================================================================
	// implemented interfaces
	
	//----------------------------------------------------------------------------------------------------
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("ADD".equals(command)) {
			GridLayerDialog dlg = new GridLayerDialog(findActiveFrame(),config);
			if (dlg.showDialog() == GridLayerDialog.OK_OPTION) {
				GridLayer layer = dlg.getGridLayer();
				listModel.add(0,layer);
			}
			editButton.setEnabled(true);
			removeButton.setEnabled(true);
			displayButton.setEnabled(true);
			ChartDialogChangeCenter.fireSaveEnabled(this);
			if (listModel.size() > 1) {
				moveUpButton.setEnabled(true);
				moveDownButton.setEnabled(true);
			}
		} else if ("EDIT".equals(command)) {
			int index = layerList.getSelectedIndex();
			if (index != -1) {
				GridLayer selected = (GridLayer) layerList.getSelectedValue();
				layerList.clearSelection();
				GridLayerDialog dlg = new GridLayerDialog(findActiveFrame(),config,selected);
				if (dlg.showDialog() == GridLayerDialog.OK_OPTION) {
					GridLayer layer = dlg.getGridLayer();
					listModel.remove(index);
					listModel.add(index,layer);
				}
			}
		} else if ("DOWN".equals(command))
			move(1);
		else if ("UP".equals(command))
			move(-1);
		else if ("REMOVE".equals(command)) {
			int[] selected = layerList.getSelectedIndices();
			while (selected.length != 0) {
				listModel.remove(selected[0]);
				selected = layerList.getSelectedIndices();
			}
			if (listModel.getSize() < 2) {
				moveUpButton.setEnabled(false);
				moveDownButton.setEnabled(false);
			}
			if (listModel.getSize() == 0) {
				editButton.setEnabled(false);
				removeButton.setEnabled(false);
				displayButton.setEnabled(false);
				ChartDialogChangeCenter.fireSaveDisabled(this);
			}
		} else if ("TITLE".equals(command))
			subtitleField.grabFocus();
		else if ("SUBTITLE".equals(command))
			rowLabelField.grabFocus();
		else if ("ROW_LABEL".equals(command))
			columnLabelField.grabFocus();
		else if ("COLUMN_LABEL".equals(command))
			titleField.grabFocus();
		else if ("DISPLAY".equals(command))
			displayChart();
		else if ("SAVE".equals(command))
			saveCollection();
		else if ("CANCEL".equals(command))
			notifyForHide();
		else if ("EDITOR".equals(command))
			openEditor();
		else if ("APPEARANCE".equals(command)) {
			int index = appearanceBox.getSelectedIndex();
			String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
			if (0 <= index && index <= 3) {
				String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
				ChartConfigCollection.setEnvironmentAppearance("B".equals(code[0]) ? ChartConstants.BASIC_APP : ChartConstants.NORMAL_APP);
				if ("BW".equals(code[1])) {
					ChartConfigCollection.setColorAppearance(ChartConstants.BLACK_AND_WHITE);
					greyScale = true;
				} else {
					ChartConfigCollection.setColorAppearance(ChartConstants.COLORED);
					greyScale = false;
				}
			} else if ("_NEW".equals(appearanceCode)) {
				ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.NORMAL);
				int result = dlg.showDialog();
				if (result == ChartPropertiesDialog.OK_OPTION) {
					Element newTemplate = (Element) dlg.getTemplate();
					dlg.dispose();
					String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
					AbstractChart.templates.put(name,newTemplate);
					ChartDialogChangeCenter.fireTemplateChanged();
					appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
 				} else
 					appearanceBox.setSelectedIndex(0);
			} else if ("_EDIT".equals(appearanceCode)) {
				String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
				if (templates.length == 0) {
					JOptionPane.showMessageDialog(this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
					appearanceBox.setSelectedIndex(0);
					return;
				}
				String template = (String) JOptionPane.showInputDialog(this,"Select a template: ","Edit template",JOptionPane.PLAIN_MESSAGE,null,
																	   templates,templates[0]);
				if (template == null || "".equals(template))
					appearanceBox.setSelectedIndex(0);
				else {
					Element templateElement = AbstractChart.templates.get(template);
					ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,
																		  getLegends(),ChartKind.NORMAL);
					int result = dlg.showDialog();
					if (result == ChartPropertiesDialog.OK_OPTION) {
						Element newTemplate = (Element) dlg.getTemplate();
						dlg.dispose();
						String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
						AbstractChart.templates.put(name,newTemplate);
						ChartDialogChangeCenter.fireTemplateChanged();
						appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
					} else
						appearanceBox.setSelectedIndex(0);
				}
			} else if ("_REMOVE".equals(appearanceCode)) {
				String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
				if (templates.length == 0) {
					JOptionPane.showMessageDialog(this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
					appearanceBox.setSelectedIndex(0);
					return;
				}
				String template = (String) JOptionPane.showInputDialog(this,"Select a template: ","Delete template",JOptionPane.PLAIN_MESSAGE,null,
																	   templates,templates[0]);
				if (template != null && !"".equals(template)) {
					AbstractChart.templates.remove(template);
					File file = new File("Templates/" + template + ".xml");
					file.delete();
					ChartDialogChangeCenter.fireTemplateChanged();
				}
				appearanceBox.setSelectedIndex(0);
			}
		}
	}

	//----------------------------------------------------------------------------------------------------
	public void focusLost(FocusEvent e) {
		if (e.getSource().equals(titleField)) {
			properties.setProperty(ChartConstants.TITLE,titleField.getText());
			ChartDialogChangeCenter.fireTitleChanged(this);
		} else if (e.getSource().equals(subtitleField)) 
			properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
		else if (e.getSource().equals(rowLabelField))
			properties.setProperty(ChartConstants.ROW_LABEL,rowLabelField.getText());
		else if (e.getSource().equals(columnLabelField))
			properties.setProperty(ChartConstants.COLUMN_LABEL,columnLabelField.getText());
	}

	//----------------------------------------------------------------------------------------------------
	public void mouseReleased(MouseEvent e) {
		if (!SwingUtilities.isRightMouseButton(e))
			return;
		if (e.getComponent().isEnabled()) {
			editAction.setEnabled(listModel.getSize() > 0);
			moveUpAction.setEnabled(listModel.getSize() > 1);
			moveDownAction.setEnabled(listModel.getSize() > 1);
			removeAction.setEnabled(listModel.getSize() > 0);
			if (listModel.getSize() > 1) {
				moveUpAction.putValue("X",e.getX());
				moveUpAction.putValue("Y",e.getY());
				moveDownAction.putValue("X",e.getX());
				moveDownAction.putValue("Y",e.getY());
			}
			if (listModel.getSize() > 0) {
				editAction.putValue("X",e.getX());
				editAction.putValue("Y",e.getY());
				removeAction.putValue("X",e.getX());
				removeAction.putValue("Y",e.getY());
			}
			contextMenu.show(e.getComponent(),e.getX(),e.getY());
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void mouseClicked(MouseEvent e) {
		if (e.getComponent().isEnabled() && e.getClickCount() == 2) {
			int index = layerList.locationToIndex(e.getPoint());
			layerList.setSelectedIndex(index);
			editButton.doClick(0);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void focusGained(FocusEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	
	//====================================================================================================
	// GUI methods
	
	//----------------------------------------------------------------------------------------------------
	private void layoutGUI() {
		this.setLayout(new BorderLayout());
		
		layerPanel = FormsUtils.build("f:p:g ~ p",
									  "[DialogBorder]01||" +
									                "02||" +
									                "03||" +
									                "04||" +
									                "05|" +
									                "0_ p:g",
									                layerListScr,addButton,
									                editButton,
									                moveUpButton,
									                moveDownButton,
									                removeButton).getPanel();
		
		titleField = new JTextField(ChartConstants.MULTIGRID2D_NAME);
		
		// Appearance combobox
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox = new JComboBox(appearances);
		
		// Details panel
		detailsPanel = FormsUtils.build("l:p = p ~ p:g",
				   						"[DialogBorder]011 p|'|" +
				   									  "233|'|" +
				   									  "455|'|" +
				   									  "677|'|" +
				   									  "89_|" +
				   									  "___ p:g",
				   						"Title:",titleField,
				   						"Subtitle:",subtitleField,
				   						"Row label:",rowLabelField,
				   						"Column label:",columnLabelField,
				   						"Appearance:",appearanceBox).getPanel();
		
		// Tabbed pane
		tabbed.addTab("Main Settings",Utilities.icons.get(ChartConstants.MULTIGRID2D),layerPanel);
		tabbed.addTab("Details",detailsPanel);
		
		editorButton = new JButton("Create data sources...");
		displayButton = new JButton("Display");
		saveButton = new JButton("Save");
		
		// Button panel
		buttonPanel = FormsUtils.build("p:g d ' d ' d ' d ' p:g",
									   "-|_0123_|",
									   editorButton,
									   displayButton,
									   saveButton,
									   cancelButton).getPanel();
		
		
		this.setPreferredSize(new Dimension(609, 219)); //TODO: ideiglenes
		this.add(tabbed,BorderLayout.CENTER);
		this.add(buttonPanel,BorderLayout.SOUTH);
	}
	
	//----------------------------------------------------------------------------------------------------
	private void initialize() {
		layerList.setModel(listModel);
		layerList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		layerList.addMouseListener(this);
		
		layerListScr.setBorder(BorderFactory.createTitledBorder("Layers of the grid"));
		
		addButton.setMnemonic(KeyEvent.VK_A);
		addButton.setActionCommand("ADD");
		
		editButton.setEnabled(false);
		editButton.setMnemonic(KeyEvent.VK_E);
		editButton.setActionCommand("EDIT");
		
		moveDownButton.setEnabled(false);
		moveDownButton.setMnemonic(KeyEvent.VK_DOWN);
		moveDownButton.setActionCommand("DOWN");
		
		moveUpButton.setEnabled(false);
		moveUpButton.setMnemonic(KeyEvent.VK_UP);
		moveUpButton.setActionCommand("UP");
		
		removeButton.setEnabled(false);
		removeButton.setMnemonic(KeyEvent.VK_R);
		removeButton.setActionCommand("REMOVE");

		initializeContextMenu();
		
		titleField.setActionCommand("TITLE");
		titleField.addFocusListener(this);
		
		subtitleField.setActionCommand("SUBTITLE");
		subtitleField.addFocusListener(this);
		
		rowLabelField.setActionCommand("ROW_LABEL");
		rowLabelField.addFocusListener(this);
		
		columnLabelField.setActionCommand("COLUMN_LABEL");
		columnLabelField.addFocusListener(this);
		
		appearanceBox.setActionCommand("APPEARANCE");
		
		editorButton.setMnemonic(KeyEvent.VK_R);
		editorButton.setActionCommand("EDITOR");

		displayButton.setEnabled(false);
		displayButton.setMnemonic(KeyEvent.VK_D);
		displayButton.setActionCommand("DISPLAY");

		saveButton.setEnabled(false);
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setActionCommand("SAVE");
		
		cancelButton.setMnemonic(KeyEvent.VK_C);
		cancelButton.setActionCommand("CANCEL");

		Utilities.addActionListener(this,addButton,editButton,moveUpButton,moveDownButton,
									removeButton,titleField,subtitleField,rowLabelField,
									columnLabelField,editorButton,displayButton,saveButton,
									cancelButton,appearanceBox);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("serial")
	private void initializeContextMenu() {
		addAction = new AbstractAction() {
			{
				putValue(NAME,"Add new layer...");
				putValue(ACTION_COMMAND_KEY,"ADD");
			}
			public void actionPerformed(ActionEvent e) { MultiGrid2DDialog.this.actionPerformed(e); }
		};
		contextMenu.add(addAction);
		editAction = new AbstractAction() {
			{
				putValue(NAME,"Edit layer...");
				putValue(ACTION_COMMAND_KEY,"EDIT");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		contextMenu.add(editAction);
		moveUpAction = new AbstractAction() {
			{
				putValue(NAME,"Move up");
				putValue(ACTION_COMMAND_KEY,"UP");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		contextMenu.add(moveUpAction);
		moveDownAction = new AbstractAction() {
			{
				putValue(NAME,"Move down");
				putValue(ACTION_COMMAND_KEY,"DOWN");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		contextMenu.add(moveDownAction);
		removeAction = new AbstractAction() {
			{
				putValue(NAME,"Remove");
				putValue(ACTION_COMMAND_KEY,"REMOVE");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		contextMenu.add(removeAction);
	}
	
	//----------------------------------------------------------------------------------------------------
	private void contextEvent(AbstractAction action, ActionEvent event) {
		if (layerList.getSelectedIndex() == -1) {
			int x = (Integer) action.getValue("X");
			int y = (Integer) action.getValue("Y");
			int index = layerList.locationToIndex(new Point(x,y));
			layerList.setSelectedIndex(index);
		}
		actionPerformed(event);
	}
	
	//====================================================================================================
	// private methods
	
	//----------------------------------------------------------------------------------------------------
	private void move(int offset) {
		int[] selected = layerList.getSelectedIndices();
		
		List<int[]> intervals = new ArrayList<int[]>();
		int start = selected[0], end = -1, previous = selected[0] - 1;
		
		for (int i = 0;i < selected.length;++i) {
			if (selected[i] == previous + 1) previous = selected[i];
			else {
				end = previous;
				int[] intv = { start, end };
				intervals.add(intv);
				end = -1;
				start = previous = selected[i];
			}
		}
		intervals.add(new int[] { start, selected[selected.length - 1] });
		
		layerList.clearSelection();
		for (int[] intv : intervals) {
			int to = intv[0] + offset;
			if (0 <= intv[0] && 0 <= to && intv[1] + offset < listModel.size()) {
				moveInterval(intv[0],intv[1],to);
				layerList.getSelectionModel().addSelectionInterval(intv[0] + offset,intv[1] + offset);
			} else
				layerList.getSelectionModel().addSelectionInterval(intv[0],intv[1]);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	private void moveInterval(int start, int end, int to) {
		int temp = to;
		GridLayer[] layers = new GridLayer[end - start + 1];
		for (int i = start;i <= end;++i)
			layers[i - start] = (GridLayer) listModel.get(i);
		listModel.removeRange(start,end);
		for (int i = 0;i < layers.length;++i)
			listModel.add(temp++,layers[i]);
	}
	
	//------------------------------------------------------------------------------
	private List<String> getLegends() {	return new ArrayList<String>(); }

	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	@Override
	protected void setSettingsFromConfig() {
 		if (config.getChartProperties() instanceof List) { // List<Properties>
 			//set settings from the config
 			List<Properties> props = (List<Properties>) config.getChartProperties();
 			properties = props.get(0);
 			titleField.setText(properties.getProperty(ChartConstants.TITLE));
 			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
 			rowLabelField.setText(properties.getProperty(ChartConstants.ROW_LABEL));
 			columnLabelField.setText(properties.getProperty(ChartConstants.COLUMN_LABEL));
			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			boolean isBlackAndWhite = false;
			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
	 			String appearanceCode = "";
	 			appearanceCode += properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP) ? "N" : "B";
	 			isBlackAndWhite = properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE);
	 			appearanceCode += isBlackAndWhite ? "BW" : "C";
	 			for (int i = 0;i < appearanceBox.getItemCount();++i) {
	 				String id = ((ComboboxItem)appearanceBox.getItemAt(i)).getID().toString();
	 				if (id.equals(appearanceCode)) {
	 					appearanceBox.setSelectedIndex(i);
	 					break;
	 				}
	 			}
 			}
			for (int i = 1;i < props.size();++i) {
				GridLayer layer = GridLayer.createLayerFromProperties(config,props.get(i));
				listModel.addElement(layer);
			}
			editButton.setEnabled(true);
			removeButton.setEnabled(true);
			if (listModel.size() > 1) {
				moveUpButton.setEnabled(true);
				moveDownButton.setEnabled(true);
			}
 			displayButton.setEnabled(true);
 			saveButton.setEnabled(true);
 		} else {
 			// set the initial properties
 			properties.setProperty(ChartConstants.TITLE,ChartConstants.MULTIGRID2D_NAME);
 			properties.setProperty(ChartConstants.SUBTITLE,"");
 			properties.setProperty(ChartConstants.ROW_LABEL,"");
 			properties.setProperty(ChartConstants.COLUMN_LABEL,"");
 			int appIndex = 0;
 			appIndex += ChartConfigCollection.getColorAppearance().equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
 			appIndex += ChartConfigCollection.getEnvironmentAppearance().equals(ChartConstants.NORMAL_APP) ? 2 : 0;
 			appearanceBox.setSelectedIndex(appIndex);
 		}
	}
	
	//----------------------------------------------------------------------------------------------------
	@Override protected void setWidgetDisabled() {}

	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	@Override
	protected void displayPreview() throws Exception {
		updateChartConfig();
		DataSources ds = new DataSources(new SimpleDSPCollection());
		ChartConfig temp_config = new ChartConfig(ds);
		temp_config.setFireInitialEvent(true);
		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
		List<Properties> temp_prop = new ArrayList<Properties>();
		Properties common_prop = (Properties) properties.clone();
		common_prop.setProperty(ChartConstants.TITLE,common_prop.getProperty(ChartConstants.TITLE) + " (Preview illustration)");
		temp_prop.add(common_prop);
		
		List<Properties> original = (List<Properties>) config.getChartProperties();
		
		for (int i = 1; i < Math.min(3,original.size());++i) {
			Properties layer = (Properties) original.get(i).clone();
			if (layer.getProperty(ChartConstants.DATASOURCE).split(",").length == 1) {
				temp_config.addDataSource(dsl.get(2),ISeriesProducer.class);
				layer.setProperty(ChartConstants.DATASOURCE,"1");
				if (!Boolean.parseBoolean(layer.getProperty(ChartConstants.USER_DEFINED_WIDTH))) {
					layer.setProperty(ChartConstants.USER_DEFINED_WIDTH,"true");
					layer.setProperty(ChartConstants.WIDTH,"5");
				}
				if (!Boolean.parseBoolean(layer.getProperty(ChartConstants.USER_DEFINED_HEIGHT))) {
					layer.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"true");
					layer.setProperty(ChartConstants.HEIGHT,"4");
				}
			} else {
				temp_config.addDataSource(dsl.get(0),ISeriesProducer.class);
				temp_config.addDataSource(dsl.get(1),ISeriesProducer.class);
				temp_config.addDataSource(dsl.get(2),ISeriesProducer.class);
				layer.setProperty(ChartConstants.DATASOURCE,"1,2,3");
				if (!Boolean.parseBoolean(layer.getProperty(ChartConstants.USER_DEFINED_WIDTH))) {
					layer.setProperty(ChartConstants.USER_DEFINED_WIDTH,"true");
					layer.setProperty(ChartConstants.WIDTH,"");
				}	
				if (!Boolean.parseBoolean(layer.getProperty(ChartConstants.USER_DEFINED_HEIGHT))) {
					layer.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"true");
					layer.setProperty(ChartConstants.HEIGHT,"");
				}
			}
			temp_prop.add(layer);
		}
		temp_config.setChartProperties(ChartConstants.MULTIGRID2D,temp_prop);
		Utilities.displayPreview(temp_config);
	}
	
	//----------------------------------------------------------------------------------------------------
	@Override
	public void reloadDataSources() {
		List<GridLayer> deleted = new ArrayList<GridLayer>();
		List<IDataSourceProducer> allDataSources = config.getDSPCollection().getList(); 
		OUT : for (int i = 0;i < listModel.size();++i) {
			GridLayer layer = (GridLayer) listModel.get(i);
			GridDescriptor descriptor = layer.getDescriptor();
			for (final IDataSourceProducer dsp : descriptor.dataSources) {
				int idx = allDataSources.indexOf(dsp);
				if (idx == -1) {
					deleted.add(layer);
					break OUT;
				}
			}
			if (!descriptor.userDefinedWidth) {
				int idx = allDataSources.indexOf(descriptor.widthProducer);
				if (idx == -1) {
					deleted.add(layer);
					break;
				}
				descriptor.widthProducer = allDataSources.get(idx);
			}
			if (!descriptor.userDefinedHeight) {
				int idx = allDataSources.indexOf(descriptor.heightProducer);
				if (idx == -1) {
					deleted.add(layer);
					break;
				}
				descriptor.heightProducer = allDataSources.get(idx);
			}
		}
		for (GridLayer layer : deleted) 
			listModel.removeElement(layer);
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable())
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}
	
	
	//====================================================================================================
	// nested classes

	//----------------------------------------------------------------------------------------------------
	public static class GridLayer {
		
		//====================================================================================================
		// members
		
		final protected GridDescriptor descriptor;
		protected IFigureRenderer renderer;
		protected Properties optionalProps = null;
		
		//====================================================================================================
		// methods
		
		//----------------------------------------------------------------------------------------------------
		public GridLayer(GridDescriptor descriptor, IFigureRenderer renderer) {
			this.descriptor = descriptor;
			this.renderer = renderer;
		}
		
		//----------------------------------------------------------------------------------------------------
		public GridDescriptor getDescriptor() { return descriptor; }
		public IFigureRenderer getRenderer() { return renderer; }
		public Properties getRendererProperties() { return optionalProps; }
		
		//----------------------------------------------------------------------------------------------------
		public void setRenderer(IFigureRenderer renderer) { this.renderer = renderer; }
		public void setRendererProperties(Properties optionalProps) { this.optionalProps = optionalProps; }
		
		//----------------------------------------------------------------------------------------------------
		@Override public String toString() {
			return "{" + descriptor.toString() + "," + renderer.getName() + "}";
		}
		
		//----------------------------------------------------------------------------------------------------
		public Properties createPropertiesAndRegistrateDataSources(ChartConfig config, boolean greyScale) {
			Properties prop = descriptor.createPropertiesAndRegistrateDataSources(config);
			if (renderer instanceof ColorMapFigureRenderer) {
				ColorMapFigureRenderer _renderer = (ColorMapFigureRenderer) renderer;
				ColorMap colormap = _renderer.getColorMap();
				if (greyScale && (!(colormap instanceof IntervalTableColorMap) || !(colormap instanceof ConstantColorMap)))
					colormap = new BlackAndWhiteColorMap(colormap.getMinLevel(),colormap.getMaxLevel());
				StringBuilder settings = new StringBuilder();
				if (colormap instanceof RainbowColorMap ||
					colormap instanceof ColorMapCollection ||
					colormap instanceof BlackAndWhiteColorMap) {
					settings.append(colorMapTypeString(colormap)).append(",");
					settings.append(String.valueOf(colormap.getMinLevel())).append(",");
					settings.append(String.valueOf(colormap.getMaxLevel()));
				} else if (colormap instanceof SimpleColorMap) {
					SimpleColorMap _colormap = (SimpleColorMap) colormap; 
					Color maxColor = new Color(_colormap.maxRed,_colormap.maxGreen,_colormap.maxBlue,_colormap.maxAlpha);
					String min_str = String.format("#%06x",_colormap.minColor.getRGB() & 0xffffff); 
					String max_str = String.format("#%06x",maxColor.getRGB() & 0xffffff);
					settings.append(ChartConstants.SIMPLE).append(",");
					settings.append(String.valueOf(colormap.getMinLevel())).append(",");
					settings.append(String.valueOf(colormap.getMaxLevel())).append(",");
					settings.append(min_str).append(",").append(max_str);
				} else if (colormap instanceof IntervalTableColorMap) {
					IntervalTableColorMap tableColorMap = (IntervalTableColorMap) colormap;
					StringBuilder temp = new StringBuilder();
					temp.append(ChartConstants.TABLE).append(",");
					temp.append(tableColorMap.getName()).append(",");
					temp.append(String.format("#%06x",tableColorMap.getDefaultColor().getRGB() & 0xffffff)).append(","); 
					List<Pair<Interval,Color>> map = tableColorMap.getMap();
					for (Pair<Interval,Color> p : map) {
						temp.append(p.getKey().toString()).append(":");
						temp.append((p.getValue() == null ? "_" : String.format("#%06x",p.getValue().getRGB() & 0xffffff))).append(","); 
					}
					String tempStr = temp.toString(); 
					settings.append(tempStr.substring(0,tempStr.length() - 1));
				} else if (colormap instanceof ConstantColorMap) {
					final ConstantColorMap _colormap = (ConstantColorMap) colormap;
					final String color_str = String.format("#%06x",_colormap.getColor(42).getRGB() & 0xffffff);
					settings.append(ChartConstants.CONSTANT).append(",").append(String.valueOf(color_str));
				}
				prop.setProperty(ChartConstants.SHAPE_RENDERER,"");
				prop.setProperty(ChartConstants.COLORMAP,settings.toString());
				prop.setProperty(ChartConstants.GLOBAL_ALPHA,String.valueOf(_renderer.getGlobalAlpha()));
			} else {
				StringBuilder settings = new StringBuilder();
				if (renderer instanceof AutomaticFigureRenderer) {
					settings.append(ChartConstants.AUTO);
				} else if (renderer instanceof UserDefinedFigureRenderer) {
					StringBuilder temp = new StringBuilder();
					UserDefinedFigureRenderer userDefRenderer = (UserDefinedFigureRenderer) renderer;
					temp.append(ChartConstants.DEFINED).append(",").append(userDefRenderer.getName());
					temp.append(",").append(String.format("#%06x",userDefRenderer.getDefaultColor().getRGB() & 0xffffff)).append(","); // default color first
					List<Triplet<Interval,String,Color>> map = userDefRenderer.getMap();
					for (Triplet<Interval,String,Color> t : map) {
						temp.append(t.getKey().toString()).append(";");
						temp.append((t.getSecond() == null ? "_" : t.getSecond())).append("?");
						String color = t.getThird() == null ? "_" : String.format("#%06x",t.getThird().getRGB() & 0xffffff);
						temp.append(color).append(","); 
					}
					String tempStr = temp.toString();
					settings.append(tempStr.substring(0,tempStr.length()-1));
				} else {
					StringBuilder temp = new StringBuilder();
					temp.append("CUSTOM,").append(renderer.getClass().getName()).append(",");
					if (optionalProps != null) {
						for (Entry<Object,Object> e : optionalProps.entrySet()) 
							temp.append(e.getKey().toString()).append(":").append(e.getValue().toString()).append(",");
					} 
					String tempStr = temp.toString();
					settings.append(tempStr.substring(0,tempStr.length()-1));
				}
				prop.setProperty(ChartConstants.COLORMAP,"");
				prop.setProperty(ChartConstants.SHAPE_RENDERER,settings.toString());
			}
			return prop;
		}
		
		//----------------------------------------------------------------------------------------------------
		public static GridLayer createLayerFromProperties(ChartConfig config, Properties prop) {
			GridDescriptor descriptor = GridDescriptor.createDescriptorFromProperties(config,prop);
			String colormapStr = prop.getProperty(ChartConstants.COLORMAP,"");
			IFigureRenderer renderer = null;
			Properties p = null;
			if (colormapStr != null && !"".equals(colormapStr)) {
				ColorMap colormap = Utilities.createColorMapFromString(colormapStr);
				float globalAlpha = Float.parseFloat(prop.getProperty(ChartConstants.GLOBAL_ALPHA,"-1"));
				renderer = new ColorMapFigureRenderer(colormap,globalAlpha);
			} else {
				String rendererStr = prop.getProperty(ChartConstants.SHAPE_RENDERER);
				try {
					renderer = Utilities.createShapeRendererFromString(rendererStr);
					String[] split = rendererStr.split(",");
					if (!split[0].equals(ChartConstants.AUTO) && !split[0].equals(ChartConstants.DEFINED)) {
						p = new Properties();
						for (int i = 2;i < split.length;++i) {
							String[] parts = split[i].split(":");
							p.setProperty(parts[0],parts[1]);
						}
					}
				} catch (Exception e) {
					renderer = new AutomaticFigureRenderer();
				}
			}
			GridLayer layer = new GridLayer(descriptor,renderer);
			if (p != null)
				layer.setRendererProperties(p);
			return layer;
		}
		
		//----------------------------------------------------------------------------------------------------
		private String colorMapTypeString(ColorMap colormap) {
			if (colormap instanceof RainbowColorMap)
				return ChartConstants.RAINBOW;
			if (colormap instanceof ColorMapCollection) {
				ColorMapCollection _colormap = (ColorMapCollection) colormap;
				String current = null;
				switch (_colormap.getType()) {
				case ColorMapCollection.HEAT 	: current = ChartConstants.HEAT;
											   	  break;
				case ColorMapCollection.REAL 	: current = ChartConstants.REAL;
											   	  break;
				case ColorMapCollection.PASTEL 	: current = ChartConstants.PASTEL;
												  break;
				case ColorMapCollection.RANDOM 	: current = ChartConstants.RANDOM;
				}
				return current;
			}
			if (colormap instanceof BlackAndWhiteColorMap)
				return ChartConstants.BLACK_AND_WHITE_COLORMAP;
			if (colormap instanceof SimpleColorMap)
				return ChartConstants.SIMPLE; 
			if (colormap instanceof IntervalTableColorMap)
				return ChartConstants.TABLE;
			if (colormap instanceof ConstantColorMap)
				return ChartConstants.CONSTANT;
			return "";
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public static class GridDescriptor implements IGridConstants {
		
		//====================================================================================================
		// members
		
		public final int mode;
		
		public final List<IDataSourceProducer> dataSources = new ArrayList<IDataSourceProducer>(2);
		public Color constantColorDataSource = null;
		
		public boolean userDefinedWidth = false;
		public int width = -1;
		public IDataSourceProducer widthProducer = null;
		
		public boolean userDefinedHeight = false;
		public int height = -1;
		public IDataSourceProducer heightProducer = null;
		
		public boolean rowOrder = true;
		
		//====================================================================================================
		// methods
		
		//----------------------------------------------------------------------------------------------------
		public GridDescriptor(int mode, IDataSourceProducer ds) {
			if (mode < FULL_MODE || mode > DS_MODE)
				throw new IllegalArgumentException("'mode' is invalid");
			this.mode = mode;
			dataSources.add(ds);
		}
		
		//----------------------------------------------------------------------------------------------------
		public GridDescriptor(IDataSourceProducer xp, IDataSourceProducer yp, IDataSourceProducer vp) {
			this.mode = PARTIAL_MODE;
			dataSources.add(xp);
			dataSources.add(yp);
			dataSources.add(vp);
		}
		
		//----------------------------------------------------------------------------------------------------
		public GridDescriptor(final IDataSourceProducer xp, final IDataSourceProducer yp, final Color color) {
			this.mode = PARTIAL_MODE;
			dataSources.add(xp);
			dataSources.add(yp);
			this.constantColorDataSource = color;
		}
		
		//----------------------------------------------------------------------------------------------------
		protected GridDescriptor(int mode) {
			this.mode = mode;
		}
		
		//----------------------------------------------------------------------------------------------------
		public Properties createPropertiesAndRegistrateDataSources(ChartConfig config) {
			Properties prop = new Properties();
			int key = -1;
			if (mode == FULL_MODE || mode == DS_MODE) { // one datasource
	 			if (mode == DS_MODE)
	 			  key = config.addDataSource(dataSources.get(0),IGrid2DDatasetProducer.class);
	 			else if (dataSources.get(0).getSupportedIntfs().contains(ISeriesProducer.class))
	 			  key = config.addDataSource(dataSources.get(0),ISeriesProducer.class);
	 			else 
	 			  key = config.addDataSource(dataSources.get(0),IValueProducer.class);
	 			prop.setProperty(ChartConstants.DATASOURCE,String.valueOf(key));
	 		} else { // three datasources, partial mode
	 			StringBuilder ds = new StringBuilder();
	 			if (dataSources.get(0).getSupportedIntfs().contains(ISeriesProducer.class))
	 				key = config.addDataSource(dataSources.get(0),ISeriesProducer.class);
	 			else
	 				key = config.addDataSource(dataSources.get(0),IValueProducer.class);
	 			ds.append(String.valueOf(key)).append(",");
	 			if (dataSources.get(1).getSupportedIntfs().contains(ISeriesProducer.class))
	 				key = config.addDataSource(dataSources.get(1),ISeriesProducer.class);
	 			else
	 				key = config.addDataSource(dataSources.get(1),IValueProducer.class);
	 			ds.append(String.valueOf(key)).append(",");
	 			if (constantColorDataSource != null) 
	 				key = config.addDataSource(new ConstantColorDataSourceProducer(constantColorDataSource),ISeriesProducer.class);
	 			else {
		 			if (dataSources.get(2).getSupportedIntfs().contains(ISeriesProducer.class))
		 				key = config.addDataSource(dataSources.get(2),ISeriesProducer.class);
		 			else
		 				key = config.addDataSource(dataSources.get(2),IValueProducer.class);
	 			}
	 			ds.append(String.valueOf(key));
	 			prop.setProperty(ChartConstants.DATASOURCE,ds.toString());
	 		}
			prop.setProperty(ChartConstants.USER_DEFINED_WIDTH,String.valueOf(userDefinedWidth));
			if (userDefinedWidth)
				prop.setProperty(ChartConstants.WIDTH,String.valueOf(width));
			else {
				if (widthProducer.getSupportedIntfs().contains(IValueProducer.class))  
					key = config.addDataSource(widthProducer,IValueProducer.class);
				else // need emulation
					key = config.addDataSource(widthProducer,ISeriesProducer.class);
				prop.setProperty(ChartConstants.WIDTH,String.valueOf(key));
			}
			prop.setProperty(ChartConstants.USER_DEFINED_HEIGHT,String.valueOf(userDefinedHeight));
			if (userDefinedHeight)
				prop.setProperty(ChartConstants.HEIGHT,String.valueOf(height));
			else {
				if (heightProducer.getSupportedIntfs().contains(IValueProducer.class))  
					key = config.addDataSource(heightProducer,IValueProducer.class);
				else // need emulation
					key = config.addDataSource(heightProducer,ISeriesProducer.class);
				prop.setProperty(ChartConstants.HEIGHT,String.valueOf(key));
			}
			prop.setProperty(ChartConstants.ROW_ORDER,String.valueOf(rowOrder));
			return prop;
		}
		
		//----------------------------------------------------------------------------------------------------
		public static GridDescriptor createDescriptorFromProperties(ChartConfig config, Properties prop) {
 			int[] ds = Utilities.splitDatasourceAroundCommas(prop.getProperty(ChartConstants.DATASOURCE));
	 		GridDescriptor descriptor = null;
 			if (ds.length == 1) { // one datasource, full or ds mode
 				IDataSourceProducer dsp = config.getDataSource(ds[0]);
 				descriptor = new GridDescriptor(dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class) ? DS_MODE : FULL_MODE);
 				descriptor.dataSources.add(dsp);
 				descriptor.userDefinedWidth = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_WIDTH));
 				if (descriptor.userDefinedWidth) 
 					descriptor.width = Integer.parseInt(prop.getProperty(ChartConstants.WIDTH));
 				else 
 					descriptor.widthProducer = config.getDataSource(Integer.parseInt(prop.getProperty(ChartConstants.WIDTH)));
 				descriptor.userDefinedHeight = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
 				if (descriptor.userDefinedHeight) 
 					descriptor.height = Integer.parseInt(prop.getProperty(ChartConstants.HEIGHT));
 				else
 					descriptor.heightProducer = config.getDataSource(Integer.parseInt(prop.getProperty(ChartConstants.HEIGHT)));
	 		} else { // three datasources, partial mode
 				descriptor = new GridDescriptor(PARTIAL_MODE);
				descriptor.dataSources.add(config.getDataSource(ds[0]));
				descriptor.dataSources.add(config.getDataSource(ds[1]));
				if (config.getDataSource(ds[2]) instanceof ConstantColorDataSourceProducer) {
					ConstantColorDataSourceProducer ccdsp = (ConstantColorDataSourceProducer) config.getDataSource(ds[2]);
					descriptor.constantColorDataSource = ccdsp.getColor();
				} else
					descriptor.dataSources.add(config.getDataSource(ds[2]));
				
				descriptor.userDefinedWidth = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_WIDTH));
				if (descriptor.userDefinedWidth) 
					descriptor.width = Integer.parseInt(prop.getProperty(ChartConstants.WIDTH));
				else
 					descriptor.widthProducer = config.getDataSource(Integer.parseInt(prop.getProperty(ChartConstants.WIDTH)));
				descriptor.userDefinedHeight = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
				if (descriptor.userDefinedHeight) 
					descriptor.height = Integer.parseInt(prop.getProperty(ChartConstants.HEIGHT));
				else 
 					descriptor.heightProducer = config.getDataSource(Integer.parseInt(prop.getProperty(ChartConstants.HEIGHT)));
 			}
 			descriptor.rowOrder = Boolean.parseBoolean(prop.getProperty(ChartConstants.ROW_ORDER));
 			return  descriptor;
		}
		
		//----------------------------------------------------------------------------------------------------
		@Override
		public String toString() {
			switch (mode) {
			case FULL_MODE 	  :
			case DS_MODE   	  : return dataSources.get(0).toString();
			
			case PARTIAL_MODE : return "(" + dataSources.get(0) + "," + dataSources.get(1) + (dataSources.size() > 2 ? "," + dataSources.get(2) : "")
									   + ")"; 
			}
			throw new IllegalStateException();
		}
	}}