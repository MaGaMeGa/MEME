package ai.aitia.chart.util;

/** General interface for callback objects with one parameter. */
public interface IUnary<T> {

	/** Task of the callback object. */
	public void run(T arg);
}
