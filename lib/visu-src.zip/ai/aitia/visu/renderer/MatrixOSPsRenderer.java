package ai.aitia.visu.renderer;


import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.RectangleEdge;
import org.jfree.util.ShapeUtilities;

import ai.aitia.visu.axis.MatrixAxis;
import ai.aitia.visu.view.plot.MatrixOSPsPlot;

/**
 * A renderer that can be used with the {@link MatrixOSPsPlot} class.
 */
@SuppressWarnings("serial")
public class MatrixOSPsRenderer extends XYLineAndShapeRenderer{

	Shape itemShape;
	
	
    public void drawItem(Graphics2D g2,
                         XYItemRendererState state,
                         Rectangle2D dataArea,
                         PlotRenderingInfo info,
                         XYPlot plot,
                         ValueAxis domainAxis,
                         ValueAxis rangeAxis,
                         XYDataset dataset,
                         int series,
                         int item,
                         CrosshairState crosshairState,
                         int pass) {

        // do nothing if item is not visible
        if (!getItemVisible(series, item)) {
            return;   
        }

        EntityCollection entities = null;
        if (info != null) {
            entities = info.getOwner().getEntityCollection();
        }

        drawSecondaryPass(
            g2, plot, dataset, pass, series, item, domainAxis, dataArea,
            rangeAxis, crosshairState, entities
        );
    }
    
    
    /**
     * Draws the item shapes and adds chart entities (second pass). This method 
     * draws the shapes which mark the item positions. If <code>entities</code> 
     * is not <code>null</code> it will be populated with entity information.
     *
     * @param g2  the graphics device.
     * @param dataArea  the area within which the data is being drawn.
     * @param plot  the plot (can be used to obtain standard color 
     *              information etc).
     * @param domainAxis  the domain axis.
     * @param rangeAxis  the range axis.
     * @param dataset  the dataset.
     * @param pass  the pass.
     * @param series  the series index (zero-based).
     * @param item  the item index (zero-based).
     * @param crosshairState  the crosshair state.
     * @param entities the entity collection.
     */
    protected void drawSecondaryPass(Graphics2D g2, XYPlot plot, 
                                     XYDataset dataset,
                                     int pass, int series, int item,
                                     ValueAxis domainAxis, 
                                     Rectangle2D dataArea,
                                     ValueAxis rangeAxis, 
                                     CrosshairState crosshairState,
                                     EntityCollection entities) {
        @SuppressWarnings("unused")
		Shape entityArea = null;

        // get the data point...
        double x1 = dataset.getXValue(series, item);
        double y1 = dataset.getYValue(series, item);
        	
        //System.out.println(dataset.getSeriesCount());
        if (Double.isNaN(y1) || Double.isNaN(x1)) {
            return;
        }
        
        int num=(int)Math.sqrt(dataset.getSeriesCount()); 
        
        PlotOrientation orientation = plot.getOrientation();
        RectangleEdge xAxisLocation = plot.getDomainAxisEdge();
        RectangleEdge yAxisLocation = plot.getRangeAxisEdge();
        double transX1 = domainAxis.valueToJava2D(x1, dataArea, xAxisLocation);
        double transY1 = rangeAxis.valueToJava2D(y1, dataArea, yAxisLocation);
        double areaX=dataArea.getMinX();
        double areaY=dataArea.getMinY();
        transX1-=areaX;
        transY1-=areaY;
        
        transX1/=num;
        transY1/=num;
        
        transX1 +=(((double)dataArea.getWidth())/num)*(series%num);
        transY1 +=(((double)dataArea.getHeight())/num)*(Math.floor(series/num));
        
        transX1+=areaX;
        transY1+=areaY;
        
        if (getItemShapeVisible(series, item)) {
            Shape shape = getItemShape(series, item);
            //ShapeUtilities.
            if (orientation == PlotOrientation.HORIZONTAL) {
                shape = ShapeUtilities.createTranslatedShape(
                    shape, transY1, transX1
                );
            }
            else if (orientation == PlotOrientation.VERTICAL) {
                shape = ShapeUtilities.createTranslatedShape(
                    shape, transX1, transY1
                );
            }
            entityArea = shape;
            if (shape.intersects(dataArea)) {
                if (getItemShapeFilled(series, item)) {
                    if (this.getUseFillPaint()) {
                        g2.setPaint(getItemFillPaint(series, item));
                    }
                    else {
                        g2.setPaint(getItemPaint(series, item));
                    }
                    g2.fill(shape);
                }
                if (this.getDrawOutlines()) {
                    if (getUseOutlinePaint()) {
                        g2.setPaint(getItemOutlinePaint(series, item));
                    }
                    else {
                        g2.setPaint(getItemPaint(series, item));
                    }
                    g2.setStroke(getItemOutlineStroke(series, item));
                    g2.draw(shape);
                }
            }
        }
        
        updateCrosshairValues(
            crosshairState, x1, y1, transX1, transY1, plot.getOrientation()
        );

        
    }
    
    public void drawHistogram(Graphics2D g2, XYItemRendererState state,
			Rectangle2D dataArea, PlotRenderingInfo info,
			MatrixOSPsPlot plot, ValueAxis domainAxis,
            ValueAxis rangeAxis,
			XYDataset dataset, int series, CrosshairState crosshairState,
			int pass){
    	@SuppressWarnings("unused")
		Shape entityArea = null;
    	ArrayList<Double> xValues=new ArrayList<Double>();
    	ArrayList<Double> yValues=new ArrayList<Double>();
    	int num=(int)Math.sqrt(dataset.getSeriesCount()); 
    	MatrixAxis ma=(MatrixAxis)domainAxis;
        PlotOrientation orientation = plot.getOrientation();
        RectangleEdge xAxisLocation = plot.getDomainAxisEdge();
        int itemCount = dataset.getItemCount(series); 
        RectangleEdge yAxisLocation = plot.getRangeAxisEdge();
    	for (int item=0; item<itemCount; item++){
    		double x1 = dataset.getXValue(series, item);
            double y1 = dataset.getYValue(series, item);
            
            //System.out.println(dataset.getSeriesCount());
            if (Double.isNaN(y1) || Double.isNaN(x1)) {
                return;
            }
            
            
            //double transX1 = ((MatrixAxis)domainAxis).valueToJava2D(x1, dataArea, xAxisLocation);
            
            double transX1 = (ma).valueToJava2D(x1, dataArea, xAxisLocation,true);
            double transY1 = (rangeAxis).valueToJava2D(y1, dataArea, yAxisLocation);
            double areaX=dataArea.getMinX();
            double areaY=dataArea.getMinY();
            transX1-=areaX;
            transY1-=areaY;
            
            transX1/=num;
            transY1/=num;
            
            transX1 +=(((double)dataArea.getWidth())/num)*(series%num);
            transY1 +=(((double)dataArea.getHeight())/num)*(Math.floor(series/num));
            
            transX1+=areaX;
            transY1+=areaY;
            
            if (getItemShapeVisible(series, item)) {
                Shape shape = getItemShape(series, item);
                if (orientation == PlotOrientation.HORIZONTAL) {
                    shape = ShapeUtilities.createTranslatedShape(
                        shape, transY1, transX1
                    );
                }
                else if (orientation == PlotOrientation.VERTICAL) {
                    shape = ShapeUtilities.createTranslatedShape(
                        shape, transX1, transY1
                    );
                }
                entityArea = shape;
                if (shape.intersects(dataArea)) {
                	xValues.add(transX1);
                	yValues.add(transY1);
                	g2.setPaint(getItemPaint(series, item));
           
                }
            }
            
            updateCrosshairValues(
                crosshairState, x1, y1, transX1, transY1, plot.getOrientation()
            );	
            
    	}
    	
    	double xl=dataArea.getMinX();
    	double yl=dataArea.getMinY();
    	 
    	xl+=(((double)dataArea.getWidth())/num)*(series/num);
    	
    	yl+=(((double)dataArea.getHeight())/num)*((series/num));
        
        
    	int [] buckets=new int[itemCount];
    	for(int i=0; i<itemCount; i++){
    		buckets[i]=0;
    	}
    	double lover=xl;
    	double interval=((double)dataArea.getWidth()/num)/itemCount;
    	double high=((double)dataArea.getHeight()/num);
    	double higher=xl+interval;
    	for(int i=0; i<itemCount; i++){
    		for(int k=0; k<itemCount; k++){
    			if(k==0){
    				if(xValues.get(k)>=lover && xValues.get(k)<=higher){
    					buckets[i]++; 
    				}
    			}else{
    				if(xValues.get(k)>lover && xValues.get(k)<=higher){
    					buckets[i]++;
    					
    				}
    			}
    		}
    		lover=higher;
    		higher+=interval;
    	}
    	
    	int maxBucket=0;
    	for(int i=0; i<itemCount; i++){
    		if(buckets[i]>maxBucket){
    			maxBucket=buckets[i];
    		}
    	}
    	
    	for(int i=0; i<itemCount; i++){
    		if(buckets[i]!=0){
    			int x=(int)(xl+i*interval);
    			
    			int width=(int)interval;
    			int y = (int)(yl+high);
    			int height=(int)((buckets[i]*high) / maxBucket );
    			Rectangle rect=new Rectangle(x, y-height, width, height);
    			g2.fill(rect);
    			g2.draw(rect);
    			
    		}
    	}

    }
}
