/** This package extends the ai.aitia.visu.view.meta package with new classes for storing
 *  meta information. */
package ai.aitia.chart.view.meta;