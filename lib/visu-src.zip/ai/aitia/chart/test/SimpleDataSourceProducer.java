/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.test;

import java.util.List;
import java.util.Properties;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ImageIcon;

import org.w3c.dom.Node;

import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.ds.DefaultStringSeriesProducer;
import ai.aitia.chart.ds.IAdjacencyMatrixProducer;
import ai.aitia.chart.ds.IElementListProducer;
import ai.aitia.chart.ds.IGrid2DDatasetProducer;
import ai.aitia.chart.ds.IStringSeriesProducer;
import ai.aitia.chart.emulator.SimpleXYSeriesProducer;
import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.ds.IDataProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IXYSeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.event.IDataChangeListener;

/** A test implementation of the IDataSoruceProducer interface. */ 
public class SimpleDataSourceProducer implements IDataSourceProducer {

	/** Id of the data source. */
	private String id;
	
	/** Name of the data source. */
	private String name;
	
	/** Values of the data source. */
	private ArrayList<Comparable> values;
	
	//===============================================================================
	
	/** Constructor.
	 * @param id id of the data source
	 * @param name name of the data source
	 * @param values values of the data source
	 */
	public SimpleDataSourceProducer(String id, String name, ArrayList<Comparable> values) {
		this.id = id;
		this.name = name;
		this.values = values;
	}
	
	//-------------------------------------------------------------------------------
	/** It doesn't use this method, always returns <code>null</code>. */
	public IDataSourceProducer advancedSettingsDialog(java.awt.Component parent) {
		return null;
	}

	//-------------------------------------------------------------------------------
	/** Creates an IDataProducer object that actually reads the real data from the
	 *  data source. This object must implement the <code>intf</code> interface and
	 *  must belong to the group represented by <code>grp</code>.
	 * @param intf an IDataProducer-descendant interface, one of those returned by   
	 *  {@link #getSupportedIntfs() getSupportedIntfs()}.
	 * @param grp this implementation doesn't use this parameter.
	 */
	public IDataProducer createDataProducer(Class intf,IDataSourceProducer grp) {
		IDataProducer producer = null;
		if (intf.equals(ISeriesProducer.class) || intf.equals(IStringSeriesProducer.class)) {
			producer = new DefaultStringSeriesProducer(name,values.toArray());
		} else if (intf.equals(IXYSeriesProducer.class)) {
			Object[] temp = values.toArray();
			double[] data = new double[temp.length];
			for (int i=0;i<temp.length;++i) data[i] = ((Double)temp[i]).doubleValue();
			producer = new SimpleXYSeriesProducer(name,data);
		} else if (intf.equals(IValueProducer.class)) {
			final Object[] temp = values.toArray();
//			double[] data = new double[temp.length];
//			for (int i=0;i<temp.length;++i) data[i] = ((Double)temp[i]).doubleValue();
//			producer = new SimpleValueProducer(name,data);
			producer = new IValueProducer() {
				private List<IDataChangeListener> listeners = new ArrayList<IDataChangeListener>();
				@SuppressWarnings("unused")
				public double produceValue() {
					return ((Double)temp[0]).doubleValue();
				}
				public String getName() {
					return name;
				}
				public long getTime() {
					return System.currentTimeMillis();
				}
				public void addDataChangeListener(IDataChangeListener listener) {
					listeners.add(listener);
				}
				public void removeDataChangeListener(IDataChangeListener listener) {
					listeners.remove(listener);
				}
			};
		} else if (intf.equals(IGrid2DDatasetProducer.class) || intf.equals(IAdjacencyMatrixProducer.class)) {
			Object[] temp = values.toArray();
			double[] data = new double[temp.length];
			for (int i=0;i<temp.length;++i) data[i] = ((Double)temp[i]).doubleValue();
			producer = new TestGrid2DDatasetProducer(name,data,3);
		} else if (intf.equals(IElementListProducer.class)) {
			producer = new TestElementListProducer(name,values);
		}
		return producer;
	}
		
	//-------------------------------------------------------------------------------
	/** Get the list of disallowed types for the data source. This list can be used
	 *  to disallow the otherwise automatic emulation of some interfaces 
	 *  for this data source. Always returns an empty list. 
	 * @return List of Java class-objects of IDataProducer-descendant interfaces.
	 */
	public List<Class> getDisabledIntfs() {
		return new ArrayList<Class>();
	}

//	public String getDisplayName() {
//		return name;
//	}
	
	//-------------------------------------------------------------------------------
	/** Get the display-name for the data source.
	 * @return display-name of the data source
	 */
	public String toString() {
		return name;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the smallest and largest possible values for the data source, or
	 *  <code>null</code> if these are nonsensical or unknown for the data source.
	 * @return A two-element List that contains the required values or <code>null</code>
	 */
	public List<Double> getRange() {
		if (id.equals("id1")) return null;
		if (id.equals("id2")) return null;
		if (getSupportedIntfs().contains(IStringSeriesProducer.class)) {
			ArrayList<Double> bounds = new ArrayList<Double>();
			bounds.add(new Double(0));
			bounds.add(new Double(values.size()-1));
			return bounds;
		}
		if (getSupportedIntfs().contains(ISeriesProducer.class) ||
			getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
			ArrayList<Double> bounds = new ArrayList<Double>();
			double min,max;
			java.util.Iterator<Comparable> it = values.iterator();
			min = max = ((Double)it.next()).doubleValue();
			while(it.hasNext()) {
				double temp = ((Double)it.next()).doubleValue();
				if (temp<min) min = temp;
				if (temp>max) max = temp;
			}
			bounds.add(new Double(min));
			bounds.add(new Double(max));
			return bounds;
		} else return null;
		
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the possible values for the data source, or <code>null</code> if the
	 *  values cannot be enumerated. A number data source must return NumberStrPair
	 *  objects containing the number and the string representation of the possible values.    
	 *  A string data source must enumerate the text-number value pairs. <br>
	 *  If it returns <code>null</code>, those parts of the GUI in which the user can
	 *  assign things (like colors, shapes) to the different values of this data source
	 *  will be less useful, since the program cannot show the list of possible values.
	 *  In these cases the user can manually define possible values.<br>
	 * @return a List of NumberStrPair objects.
	 */
	public List<NumberStrPair> getElements() {
		if (id.equals("id3")) return null;
		List<NumberStrPair> result = new ArrayList<NumberStrPair>();
		if (getSupportedIntfs().contains(IStringSeriesProducer.class)) {
			int index = 0;
			Iterator<Comparable> it = values.iterator();
			while (it.hasNext()) {
				String str = (String)it.next();
				boolean hit = false;
				for (NumberStrPair o : result) {
					if (str.equals(o.toString())) {
						hit = true;
						break;
					}
				}
				if (!hit) {
					result.add(new NumberStrPair(new Double(index),str));
					index++;
				}
			}
			return result;
		}
		if (getSupportedIntfs().contains(ISeriesProducer.class) ||
			getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
			Iterator<Comparable> it = values.iterator();
			while (it.hasNext()) {
				Comparable num = it.next(); 
				NumberStrPair item = new NumberStrPair((Number)num);
				if (!result.contains(item)) result.add(item);
			}
			return result;
		} else return null;
	}
	
	//-------------------------------------------------------------------------------
	/** Get the list of data types that are directly supported by this data source.
	 * @return List of Java class-objects of IDataProducer-descendant interfaces.
	 */
	public List<Class> getSupportedIntfs() {
		ArrayList<Class> list = new ArrayList<Class>();
		if (id.equals("id6")) {
			list.add(ai.aitia.visu.ds.IXYSeriesProducer.class);
		} else if (id.equals("id4")) {
			list.add(ISeriesProducer.class);
			list.add(IStringSeriesProducer.class);
		} else if (id.equals("id5")) {
			list.add(IGrid2DDatasetProducer.class);
			list.add(IAdjacencyMatrixProducer.class);
		} else if (id.equals("id8") || id.equals("id9")) {
			list.add(IValueProducer.class);
		} else {
			list.add(ISeriesProducer.class);
			list.add(IElementListProducer.class);
		}
		return list;
	}

	//-------------------------------------------------------------------------------
	/** Returns whether the data source has custom settings possibilites or not. */ 
	public boolean hasAdvancedSettings() {
		if (id.equals("id1")) return true;
		return false;
	}

	//-------------------------------------------------------------------------------
	/** Save the access information of a data source into an XML node. The access
	 *  informations are implementation-dependent:
	 *    - id of the data source<br>
	 *    - name of the data source<br>
	 *    - type of the data source (STRING or DOUBLE)<br>
	 *    - values of the data source
	 * @param node destination XML node
	 */
	public void save(Node node) {
		Properties prop = new Properties();
		prop.setProperty("ID", id.toString());
		prop.setProperty("NAME", name);
		String val_string = "";
		if (id.equals("id4")) {
			val_string = "STRING,";
		} else {
			val_string = "DOUBLE,";
		}
		for (Comparable v : values) {
			val_string += v.toString() + ",";
		}
		prop.setProperty("VALUES",val_string.substring(0,val_string.length()-1));
		Utilities.writeProperties(node,prop);
	}
	
	//-------------------------------------------------------------------------------
	@Override
	public boolean equals(Object o) {
		if (o instanceof SimpleDataSourceProducer) {
			SimpleDataSourceProducer that = (SimpleDataSourceProducer)o;
			return this.id.equals(that.id);
		}
		return false;
	}

	//-------------------------------------------------------------------------------
	/** Returns the icon of the data source. <code>null</code> is permitted.
	 * @return icon of the data source 
	 */
	public ImageIcon getDisplayableIcon() {
		java.net.URL imgURL = SimpleDataSourceProducer.class.getResource("/icons/Forward16.gif");
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file.");
            return null;
        }
	}
}
