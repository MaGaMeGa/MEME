package ai.aitia.visu.utils;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;

/** �ltal�nos c�l� seg�df�ggv�nyeket tartalmaz� oszt�ly. */
public class Utils {

	/** A param�terben megadott komponenst tartalmaz� ablakot megfelel� m�don �jram�retezi.
	 * @author Mesz�ros R�bert
	 */
	public static void repack(java.awt.Component c) {
 		javax.swing.JRootPane root = javax.swing.SwingUtilities.getRootPane(c);
 		java.awt.Container p = (root == null) ? null : root.getParent();
 		if (p instanceof java.awt.Window)
 			((java.awt.Window)p).pack();
 		else if (p instanceof javax.swing.JInternalFrame)
 			((javax.swing.JInternalFrame)p).pack();
 	}
	
	//--------------------------------------------------------------------------------
	
	/** A param�terben megadott sztringben val�s sz�mot keres. Visszaadja a sz�m kezd�
	 *  karakter�nek index�t, vagy -1-et, ha nincs benne val�s sz�m.
	 * @param text a megadott sz�veg
	 * @param decimalSign a tizedesjelnek haszn�lt karakter
	 */
	public static int findRealNumber(String text, char decimalSign ) {
		Pattern p = Pattern.compile("[-]?[0-9]+[" + decimalSign + "]?[0-9]*");
		Matcher m = p.matcher(text);
		boolean b = m.find(); //m.lookingAt();
		if (b) return m.start();
		return -1;
	}
	
	//--------------------------------------------------------------------------------
	
	/** A param�terben megadott jelsz�t MD5-tel k�dolja, �s az eredm�nyt visszaadja. */
	public static String encodePassword(String password) {
		try {
			MessageDigest md = (MessageDigest)MessageDigest.getInstance("MD5").clone();
			md.update(password.getBytes());
			return Utils.convert(md.digest());
		} catch (NoSuchAlgorithmException e) {
			// van ilyen algoritmus
			return null;
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	//-------------------------------------------------------------------------------
	
	/** A param�terben megadott b�jtt�mb�t konvert�lja sztringg� a <code>convertDigit()
	 *  </code> met�dus felhaszn�l�s�val. 
	 */
	@SuppressWarnings("cast")
	public static String convert(byte bytes[]) {

        StringBuffer sb = new StringBuffer(bytes.length * 2);
        for (int i = 0; i < bytes.length; i++) {
            sb.append(convertDigit((int) (bytes[i] >> 4)));
            sb.append(convertDigit((int) (bytes[i] & 0x0f)));
        }
        return (sb.toString());

    }
    
	//-------------------------------------------------------------------------------
	
    /** A param�terben megadott eg�sz sz�mot konvert�lja karakterr�. */
	private static char convertDigit(int value) {

        value &= 0x0f;
        if (value >= 10)
            return ((char) (value - 10 + 'a'));
        else
            return ((char) (value + '0'));

    }
    
	//-------------------------------------------------------------------------------
	
	/** Bet�lti �s visszaadja a param�terben megadott k�pet. <code>null</code>-t ad 
	 *  vissza, ha nem tudja bet�lteni a k�pet.
	 */
    public static ImageIcon createImageIcon(String path) {
        java.net.URL imgURL = Utils.class.getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }
    
	// -------------------------------------------------------------------------
	/** Returns a new dimension with the larger width and the larger height. */
	public static Dimension max(Dimension a, Dimension b) {
		return new Dimension(Math.max(a.width, b.width), Math.max(a.height, b.height));
	}

	// -------------------------------------------------------------------------
	/** Returns a new dimension with the lesser width and the lesser height. */
	public static Dimension min(Dimension a, Dimension b) {
		return new Dimension(Math.min(a.width, b.width), Math.min(a.height, b.height));
	}
    
    //----------------------------------------------------------------------------------------------------
	public static Dimension getUseableScreenSize() {
		final Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		return new Dimension(d.width,getRelScrH(90));
	}
	
	//----------------------------------------------------------------------------------------------------
	public static Dimension getPreferredSize(final Component comp) {
		final Dimension useableScreenSize = getUseableScreenSize();
		final Dimension d = min(comp.getPreferredSize(),useableScreenSize);
		if (!d.equals(comp.getPreferredSize()))
			d.width = Math.min((int)(d.width * 1.1),useableScreenSize.width);
		return d;
	}

    //----------------------------------------------------------------------------------------------------
	/** Returns the 'percent' percent of the getScreenSize().width. */
    public static int getRelScrW(int percent)		{ return Toolkit.getDefaultToolkit().getScreenSize().width * percent / 100; }
    /** Returns the 'percent' percent of the getScreenSize().height. */
    public static int getRelScrH(int percent)		{ return Toolkit.getDefaultToolkit().getScreenSize().height * percent / 100; }
}