/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ai.aitia.chart.util.XMLLoadingException;

/** Common storage for data sources. */
public class DataSources {
	
	/** A DSElement object encapsulates a data source with other informations, such as
	 *  type, etc. . */
	public class DSElement {
		
		/** A data source. */
		private IDataSourceProducer dsp;
		
		/** A type. The {@link IDataSourceProducer#createDataProducer(Class,IDataSourceProducer)
		 *   createDataProducer()} method of the data source of this object
		 *  must create a data producer whose type is <code>type</code>.
		 */
		private Class<?> type;
		
		/** A reference counter that stores the number of chart configuration objects
		 *  that use this data source.
		 */
		private int refcnt;
	
		//===========================================================================
		// methods
		
		/** Constructor.
		 * @param dsp a data source
		 * @param type a type (an IDataProducer-descendant interface)
		 */
		public DSElement(IDataSourceProducer dsp, Class<?> type) {
			this.dsp = dsp;
			this.type = type;
			refcnt = 0;
		}

		//-------------------------------------------------------------------------------
		/** Returns the current value of the reference counter.
		 * @return the curren value of the reference counter
		 */
		public int getRefcnt() {
			return refcnt;
		}

		//-------------------------------------------------------------------------------
		/** Increments the value of the reference counter. */
		public void incRefcnt() {
			refcnt++;
		}
		
		//-------------------------------------------------------------------------------
		/** Decrements the value of the reference counter. */
		public void decRefcnt() {
			refcnt--;
		}
		
		//----------------------------------------------------------------------------------------------------
		public void setRefcnt(int refcnt) { this.refcnt = refcnt; }

		//-------------------------------------------------------------------------------
		/** Returns the data source.
		 * @return the data source 
		 */
		public IDataSourceProducer getDsp() {
			return dsp;
		}

		//-------------------------------------------------------------------------------
		/** Returns the type.
		 * @return the type
		 */
		public Class<?> getType() {
			return type;
		}
		
		//-------------------------------------------------------------------------------
		@Override
		public boolean equals(Object o) {
			if (o instanceof DSElement) {
				DSElement that = (DSElement)o;
				return (dsp.equals(that.getDsp()) && type.equals(that.getType())); 
			}
			return false;
		}
	}
	
	//===============================================================================
	// members
	
	/** A hashmap that contains (id,DSElement) pairs. A DSElement object encapsulates a
	 *  datasource with other informations.
	 */
	private HashMap<Integer,DSElement> dataSources = null;
	
	/** A collection of all available data sources. */
	private IDSPCollection dsp_collection = null;
	
	//===============================================================================
	// methods
	
	/** Constructor. It creates a hashmap for data sources and type of the data
	 *  sources.
	 * @param dsp_collection a collection of all available data sources
	 */
	public DataSources(IDSPCollection dsp_collection) {
		this.dsp_collection = dsp_collection;
		dataSources = new HashMap<Integer,DSElement>();
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the number of the stored data sources.
	 * @return the size of the storage
	 */
	public int getDataSourceCount() {
		return dataSources.size();
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the data source specified by <code>index</code>.
	 * @param index index of the data source
	 * @return the appropriate data source (or <code>null</code>)
	 */
	public IDataSourceProducer getDataSource(int index) {
		DSElement p = dataSources.get(new Integer(index));
		if (p!= null ) return p.getDsp();
		return null;
	}

	//-------------------------------------------------------------------------------
	/** Returns the type of the data source specified by <code>index</code>.
	 * @param index index of the data source
	 * @return the type of the data source (or <code>null</code>) 
	 */
	public Class<?> getDataSourceType(int index) {
		DSElement p = dataSources.get(new Integer(index));
		if (p != null) return p.getType();
		return null;
	}
	
	//-------------------------------------------------------------------------------
	/** This method adds a data source with type to the storage. If the storage
	 *  already contains this (data source,type) pair, it does nothing.
	 * @param dsp the data source
	 * @param type type of the data source
	 * @return the key of the data source
	 */
	public int addDataSource(IDataSourceProducer dsp, Class<?> type) {
		DSElement element = new DSElement(dsp,type);
		if (!dataSources.containsValue(element)) {
			Integer key = generateKey();
			dataSources.put(key,element);
			dataSources.get(key).incRefcnt();
			return key.intValue();
		}
		Integer key = find(dsp,type);
		dataSources.get(key).incRefcnt();
		return key.intValue();
	}

	//-------------------------------------------------------------------------------
	/** This method updates a data source with type to the storage. If the storage
	 *  already contains this (data source,type) pair, it exchanges the reference.
	 * @param dsp the data source
	 * @param type type of the data source
	 * @return the key of the data source
	 */
	public int updateDataSource(IDataSourceProducer dsp, Class<?> type) {
		DSElement element = new DSElement(dsp,type);
		if (!dataSources.containsValue(element)) {
			Integer key = generateKey();
			dataSources.put(key,element);
			dataSources.get(key).incRefcnt();
			return key.intValue();
		}
		Integer key = find(dsp,type);
		dataSources.get(key).dsp = dsp;
		dataSources.get(key).incRefcnt();
		return key.intValue();
	}

	//-------------------------------------------------------------------------------
	/** This method updates (increments) the reference counts of the data sources
	 *  used by <code>config</code>. It uses the 
	 *  {@link ChartConfig#getDataSourceIDs() getDataSourceIDs()} method.
	 * @param config configuration object
	 */
	public void updateRefCnt(ChartConfig config) {
		List<Integer> keys = config.getDataSourceIDs();
		for (Integer k : keys) {
			dataSources.get(k).incRefcnt();
		}
	}
	
	//-------------------------------------------------------------------------------
	/** This method decreases the reference counts of the data sources used by <code>
	 *  config</code>. If a reference count changes to zero, it deletes the data source.
	 *  It uses the {@link ChartConfig#getDataSourceIDs() getDataSourceIDs()} method. 
	 * @param config configuration object
	 */
	public void deleteDataSources(ChartConfig config) {
		List<Integer> keys = config.getDataSourceIDs();
		for (Integer k : keys) {
			if (dataSources.get(k) == null || dataSources.get(k).getRefcnt() <= 0) continue; // we don't delete the SHADOW(tm) datasources
			dataSources.get(k).decRefcnt();
			if (dataSources.get(k).getRefcnt() <= 0) {
				dataSources.remove(k);
			}
		}
	}

	//-------------------------------------------------------------------------------
	/** Returns the collection of all available data sources.
	 * @return the collection of all available data sources
	 */
	public IDSPCollection getDSPCollection() {
		return dsp_collection;
	}

	//-------------------------------------------------------------------------------
	/** This method saves the data sources into an XML node (this is usually the
	 *  root node). It uses the {@link IDataSourceProducer#save(Node) save()} method.
	 * 
	 * @param node destination XML node
	 */ 
	public void save(Node node) {
		Document document = node.getOwnerDocument();
		Element datasources = document.createElement("datasources");
		for (Entry<Integer,DSElement> e : dataSources.entrySet()) {
			Element datasource = document.createElement("datasource");
			datasource.setAttribute("id",e.getKey().toString());
			datasource.setAttribute("type",e.getValue().getType().getName());
			e.getValue().getDsp().save(datasource);
			datasources.appendChild(datasource);
		}
		node.appendChild(datasources);
	}
	
	//-------------------------------------------------------------------------------
	/** This factory method creates a data sources storage from an XML node and the
	 *  collection of all available data sources. It uses the 
	 *  {@link IDSPCollection#load(Node,Class) load()} method, so the result object
	 *  will be valid only if the available data sources are the same than when the
	 *  storage is saved.
	 * 
	 * @param node source XML node
	 * @param dsp_collection collection of all available data sources
	 * @return data source storage
	 * @throws XMLLoadingException if any problems occure during the process of the XML
	 *  document
	 * @throws Exception if any problem occure during the load
	 */
	public static DataSources load(Node node, IDSPCollection dsp_collection) 
			throws XMLLoadingException, Exception {
		DataSources ds = new DataSources(dsp_collection);
		if (!(node instanceof Element)) {
			throw new XMLLoadingException("Invalid XML-file!");
		}
		Element top = (Element)node;
		NodeList nodes = top.getElementsByTagName("datasources");
		if (nodes == null) {
			throw new XMLLoadingException("Invalid XML-file: missing <datasources> tag");
		}
		
		Element datasources = (Element)nodes.item(0);
		NodeList dsnodes = datasources.getElementsByTagName("datasource");
		if (dsnodes == null) {
			throw new XMLLoadingException("Invalid XML-file. No childs of node: <" +
										  datasources.getNodeName() + ">");
		}
		for (int i=0;i<dsnodes.getLength();++i) {
			Element element = (Element)dsnodes.item(i);
			Integer key = null;
			Class<?> type = null;
			String id_string = element.getAttribute("id");
			if (id_string.length() == 0) {
				throw new XMLLoadingException("Invalid XML-file. There is no 'id' attribute of the node <" 
											  + element.getNodeName() + "> (number " + String.valueOf(i) + ")");
			}
			try {
				key = new Integer(Integer.parseInt(id_string));
			} catch (NumberFormatException e) {
				throw new XMLLoadingException("Invalid XML-file. The 'id' of <" + element.getNodeName() + 
						                      "> (number " + String.valueOf(i) + ") is not an integer: " +
						                      id_string);
			}
			String type_string = element.getAttribute("type");
			if (type_string.equals("")) {
				throw new XMLLoadingException("Invalid XML-file. There is no 'type' attribute of the node <"
											  + element.getNodeName() + "> (number " + String.valueOf(i) + ")");
			}
			try {
				type = Class.forName(type_string);
			} catch (ClassNotFoundException e) {
				throw new XMLLoadingException("Invalid XML-file. The 'type' <" + element.getNodeName() + 
											  "> (number )" + String.valueOf(i) + ") cannot be located:" +
											  type_string);
			}
			IDataSourceProducer dsp = ds.dsp_collection.load(element,type);
			ds.dataSources.put(key,ds.new DSElement(dsp,type));
		}
		return ds;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the key of the data source specified by <code>dsp</code> and 
	 *   <code>type</code>. If the specified data source isn't in the storage, it 
	 *   returns -1.
	 *  @param dsp data source
	 *  @param type type of the data source
	 *  @return key of the data source
	 */
	public Integer find(IDataSourceProducer dsp, Class<?> type) { 
		DSElement element = new DSElement(dsp,type);
		if (!dataSources.containsValue(element)) return new Integer(-1);
		Integer[] keys = dataSources.keySet().toArray(new Integer[0]);
		for (int i=0;i<keys.length;++i) {
			if (dataSources.get(keys[i]).equals(element)) return keys[i];
		}
		return new Integer(-1);
	}
	
	//-------------------------------------------------------------------------------
	/** Assistant method that generates a unique id. It finds the top key and returns
	 *  the next integer value.
	 * @return a unique id
	 */
	protected Integer generateKey() {
		if (dataSources.isEmpty()) return new Integer(1);
		Iterator<Integer> it = dataSources.keySet().iterator();
		Integer max = it.next();
		while (it.hasNext()) {
			Integer temp = it.next();
			if (temp>max) max = temp;
		}
		return max+1;
	}
}
