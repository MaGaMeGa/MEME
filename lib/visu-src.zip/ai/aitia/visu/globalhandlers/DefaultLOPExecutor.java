package ai.aitia.visu.globalhandlers;

import java.beans.Expression;
import java.util.concurrent.Callable;

/** Default implementation for the global long operation handler. Simply calls the
 *  appropriate method that contains the task of the long operation. */
public class DefaultLOPExecutor implements ILOPExecutor {

	/** Executes the long operation <code>r</code> named <code>taskName</code>.
	 * @param taskName name of the long operation
	 * @param r task of the long operation
	 * @throws Exception never thrown
	 */
	public void execute(String taskName, Runnable r) throws Exception {
		r.run();
	}

	//--------------------------------------------------------------------------------
	/** Executes the long operation <code>r</code> named <code>taskName</code>. The
	 *  long operation returns a result and may throw an Exception.
	 * @param taskName name of the long operation
	 * @param r task of the long operation
	 * @return result of the long operation
	 * @throws Exception
	 */
	public Object execute(String taskName, Callable<Object> r) throws Exception {
		Object ans  = r.call();
		return ans;
	}

	//--------------------------------------------------------------------------------
	/** Executes a long operation creating a java.beans.Expression from the parameters.
	 * @param taskName name of the long operation
	 * @param target the owner of the method that contains the long operation
	 * @param methodName the name of the method that contains the long operation
	 * @param args the parameters of the method that conatins the long operation
	 * @return result of the long operation
	 * @throws Exception 
	 */
	public Object execute(String taskName, Object target, String methodName, Object... args) throws Exception {
		Expression ex = new Expression(target,methodName,args);
		return execute(taskName,ex);
	}

	//--------------------------------------------------------------------------------
	/** Executes a the long operation <code>ex</code> named <code>taskName</code>.
	 * @param taskName name of the long operation
	 * @param ex task of the long operation
	 * @return result of the long operation
	 * @throws Exception
	 */
	public Object execute(String taskName, Expression ex) throws Exception {
		return ex.getValue();
	}

	//--------------------------------------------------------------------------------
	/** Does nothing. */
	public void checkUserBreak() throws UserBreakException {}
		
	//--------------------------------------------------------------------------------
	/** Always returns false. */
	public boolean isUserBreak() {
		return false;
	}

	//--------------------------------------------------------------------------------
	/** Identical to <pre> checkUserBreak() </pre>. */
	public void progress(double current) throws UserBreakException {
		checkUserBreak();
	}

	//--------------------------------------------------------------------------------
	/** Does nothing. */
	public void progress(double current, double end) {}
	
	//----------------------------------------------------------------------------------------------------
	public void setAbortable(boolean abortable) {}
}
