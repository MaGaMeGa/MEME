package ai.aitia.visu.view.selection;

public interface ISelectionListener {
	public void selectionChanged(SelectionEvent e);
}
