package ai.aitia.visu.movie;

import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;

public class TestRun {

	public static void main(String[] args){
		Image image;
		image=Toolkit.getDefaultToolkit().createImage("c:/Movie/kuty/Kp 362.png");
		@SuppressWarnings("unused")
		ImageIcon iI=new ImageIcon(image);
		MovieMaker mM=new MovieMaker("c:/Movie/ppp.mov", 10);
		mM.run(image);
	}
}
