/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.emulator;

import ai.aitia.chart.ds.IStringListProducer;
import ai.aitia.chart.ds.IStringSeriesProducer;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDataProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IXYSeriesProducer;
import ai.aitia.visu.ds.IValueProducer;

import java.util.List;

/** This class is an assistant for creating charts. */
public class ProducerEmulator {
	
	/** This function returns a desired data producer. Currently it can be create:
	 *   - an IXYSeriesProducer from two ISeriesProducers<br>
	 *   - an IXYSeriesProducer from two IValueProducers<br>
	 *   - an IValueProducer from an ISeriesProducer<br>
	 *   - an ISeriesProducer from an IValueProducer<br>
	 *   - an 
	 *   {@link ai.aitia.chart.ds.IStringListProducer IStringListProducer}
	 *   from an
	 *   {@link ai.aitia.chart.ds.IStringSeriesProducer IStringSeriesProducer}.
	 *   
	 * @param producers list of IDataProducers
	 * @param new_producer type of the desired data producer.
	 * @return the desired dataproducer
	 * @throws DataSourceException it throws this exception if the input parameters are not adequare or in the case of unsupported emualtion
	 */ 
	public static IDataProducer createProducer(List<IDataProducer> producers, Class new_producer) throws DataSourceException {
		if (new_producer.equals(IXYSeriesProducer.class)) {
			// from two ISeriesProducers or IValueProducers to an IXYSeriesProducer
			if (producers.size()>=2) {
				try {
					SimpleXYSeriesProducer xySeriesProducer = null;
					if (producers.get(0) instanceof ISeriesProducer) {
						ISeriesProducer xs = (ISeriesProducer)producers.get(0);
						ISeriesProducer ys = (ISeriesProducer)producers.get(1);
						xySeriesProducer = new SimpleXYSeriesProducer(xs,ys);
					} else {
						IValueProducer xv = (IValueProducer)producers.get(0);
						IValueProducer yv = (IValueProducer)producers.get(1);
						xySeriesProducer = new SimpleXYSeriesProducer(xv,yv);
					}
					xySeriesProducer.registrateListeners();
					return xySeriesProducer;
				} catch (ClassCastException e) {
					throw new DataSourceException("Invalid input producer(s)",e);
				}
			} else throw new DataSourceException("Missing input producer(s)");
		} else if (new_producer.equals(IValueProducer.class)) {
			// from one ISeriesProducer to an IValueProducer
			if (producers.size() >= 1) {
				
				try {
					ISeriesProducer ys = (ISeriesProducer)producers.get(0);
					SimpleValueProducer valueProducer = new SimpleValueProducer(ys);
					valueProducer.registrateListener();
					return valueProducer;
				} catch (ClassCastException e) {
					throw new DataSourceException("Invalid input producer",e);
				}
			} else throw new DataSourceException("Missing input producer");
		
		} else if (new_producer.equals(ISeriesProducer.class)) {
			// from one IValueProducer to an ISeriesProducer
			if (producers.size() >= 1) {
				try {
					IValueProducer vp = (IValueProducer)producers.get(0);
					SimpleSeriesProducer seriesProducer = new SimpleSeriesProducer(vp);
					seriesProducer.registrateListener();
					return seriesProducer;
				} catch (ClassCastException e) {
					throw new DataSourceException("Invalid input producer",e);
				}
			} else throw new DataSourceException("Missiong input producer");
		} else if (new_producer.equals(IStringListProducer.class)) {
			// from one IStringSeriesProducer to an IStringListProducer
			if (producers.size() >= 1) {
				
				try {
					IStringSeriesProducer ss = (IStringSeriesProducer)producers.get(0);
					SimpleStringListProducer stringListProducer = new SimpleStringListProducer(ss);
					stringListProducer.registrateListener();
					return stringListProducer;
				} catch (ClassCastException e) {
					throw new DataSourceException("Invalid input producer",e);
				}
			} else throw new DataSourceException("Missing input producer");
		}
		throw new DataSourceException("Can't create this producer:" + new_producer.getName());
	}
	
	/** This function returns whether can produce from the list of types <code>from
	 *  </code> the desired type described by <code>to</code> or not.
	 * 
	 * @param from list of data producer types
	 * @param to desired data producer type
	 */
	public static boolean canProduce(List<Class> from, Class to) {
		if (to.equals(IXYSeriesProducer.class)) {
			// 2 ISeriesProducer or 2 IValueProducer => IXYSeriesProducer
			if (from.size()<2) return false;
			if (from.get(0).equals(ISeriesProducer.class) && 
				from.get(1).equals(ISeriesProducer.class)) return true;
			if (from.get(0).equals(IValueProducer.class) && 
				from.get(1).equals(IValueProducer.class)) return true;
			return false;
		} else if (to.equals(IValueProducer.class)) {
			// ISeriesProducer => IValueProducer
			if (from.size()<1) return false;
			if (!from.get(0).equals(ISeriesProducer.class)) return false;
			return true;
		} else if (to.equals(IStringListProducer.class)) {
			// IStringSeriesProducer => IStringListProducer
			if (from.size()<1) return false;
			if (!from.get(0).equals(IStringSeriesProducer.class)) return false;
			return true;
		} else if (to.equals(ISeriesProducer.class)) {
			// IValueProducer => ISeriesProducer
			if (from.size() < 1) return false;
			return from.get(0).equals(IValueProducer.class);
		}
		return false;
	}
	
	/** This function returns whether the type <code>from</code> can be the part
	 *  of an emulation of type <code>to</code> or not.
	 * @param from source data producer type
	 * @param to desired data producer type
	 */
	public static boolean canProduce(Class from, Class to) {
		if (from.equals(ISeriesProducer.class)) {
			if (to.equals(IXYSeriesProducer.class) ||
				to.equals(IValueProducer.class)) return true;
		} else if (from.equals(IValueProducer.class) && (to.equals(IXYSeriesProducer.class) ||
				   to.equals(ISeriesProducer.class))) return true;
		else if (from.equals(IStringSeriesProducer.class) && to.equals(IStringListProducer.class)) return true;
		return false;
	}
}
