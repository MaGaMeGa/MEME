package ai.aitia.visu.view.plot;

public enum ColorMapUpdateOption { 
	NONE, MIN, MAX, BOTH;
	
	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public static ColorMapUpdateOption getOption(final double minValue, final double maxValue) {
		if (minValue != - Double.MAX_VALUE) {
			if (maxValue != Double.MAX_VALUE)
				return NONE;
			else
				return MAX;
		}
		if (maxValue != Double.MAX_VALUE)
			return MIN;
		return BOTH;
	}
	
	//----------------------------------------------------------------------------------------------------
	public boolean contains(final ColorMapUpdateOption option) {
		switch (this) {
		case NONE : return option == NONE;
		case MIN  : return option == MIN;
		case MAX  : return option == MAX;
		case BOTH : return option != NONE;
		default   : throw new AssertionError();
		}
	}
}