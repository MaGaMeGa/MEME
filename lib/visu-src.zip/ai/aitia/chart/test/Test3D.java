package ai.aitia.chart.test;

import ai.aitia.visu.data.DefaultGrid3DDataset;
import ai.aitia.visu.data.DefaultGrid3DDataset_DiagramLayer;
import ai.aitia.visu.view.plot.Grid3DPlot;
import ai.aitia.chart.charttypes.*;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Color;

import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.view.ui.SimpleColorMap;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.util.List;
import java.util.ArrayList;
import java.util.Properties;


public class Test3D extends Applet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @param args
	 */
	static DefaultGrid3DDataset gridDataSet_DLayer = new DefaultGrid3DDataset_DiagramLayer(10, 15);
	static SimpleColorMap colorMap = new SimpleColorMap(0, 10, Color.red, Color.blue);
	//static Grid3DMetadata metadata = new Grid3DMetadata();
	static JPanel wrapPanel = new JPanel();
	
	static DefaultGrid3DDataset[] Datasets = new DefaultGrid3DDataset[3];
	
	static Grid3DPlot grid3D;// = new Grid3DPlot(gridDataSet_DLayer, "Y", "X",/*metadata.getColorMap()*/colorMap, metadata.noSelection(), false);
	
	//static Canvas3D c3D;
	
	static Grid3D Grid3D_type;
	
	static ChartConfig cc;
	
	public Test3D() {
     
	}
	
	private static void createAndShowGUI(){
		
		//build and show the frame
        JFrame frame = new JFrame("Test Grid3D"); 
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(wrapPanel, BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);
	}
	
	public static void main(String[] args) throws Exception {
		
		Grid3D_type = new Grid3D();
		
		SimpleDSPCollection simpleDSPCollection = new SimpleDSPCollection();
		DataSources ds = null;
		ds = new DataSources(simpleDSPCollection);
		List<IDataSourceProducer> list = simpleDSPCollection.getList();
		
		
		int key1 = ds.addDataSource(list.get(0),ISeriesProducer.class);
		int key2 = ds.addDataSource(list.get(2),ISeriesProducer.class);
		int key3 = ds.addDataSource(list.get(6),ISeriesProducer.class);
		int key4 = ds.addDataSource(list.get(4), ISeriesProducer.class);
		
		//X, Y, Zvalue, Color, Shape
		//String dataSourceString = key1 + "," + key2 + "," + key3 + "," + key3 + "," + key3;
		
		//FULL-MODE
		@SuppressWarnings("unused")
		String dataSourceString3 = key3 + "," + key2;
		String dataSourceString = key2 + "," + key2 + "," + key3 + "," + key4;
		String dataSourceString1 = key2 + "," + key3 + "," + key4;
		//PARTIAL-MODE
		@SuppressWarnings("unused")
		String dataSourceString5 = key1 + "," + key1 + "," + key2 + "," + key3 + "," + key4;
		@SuppressWarnings("unused")
		String dataSourceString4 = key1 + "," + key1 + "," + key2 + "," + key2 + "," + key3 + "," + key4;
		String dataSourceString2 = key1 + "," + key1 + "," + key3 + "," + key2;
		
		cc = new ChartConfig(ds);
		
		List<Properties> p = new ArrayList<Properties>();
		//Surface
		Properties p1 = new Properties();
		p1.setProperty(ChartConstants.DATASOURCE,dataSourceString2);
		p1.setProperty(ChartConstants.USER_DEFINED_WIDTH, "true");
		p1.setProperty(ChartConstants.USER_DEFINED_HEIGHT, "true");
		p1.setProperty(ChartConstants.TYPE, ChartConstants.SURFACE_LAYER);
		p1.setProperty(ChartConstants.RADIUS, "2");
		p1.setProperty(ChartConstants.PADDING, "3");
		p1.setProperty(ChartConstants.TRANSLATE, "-30");
		p1.setProperty(ChartConstants.SHOW_BASE, "TRUE");
		p1.setProperty(ChartConstants.WIDTH, "4");
		p1.setProperty(ChartConstants.HEIGHT, "-1");
		p1.setProperty(ChartConstants.TITLE, "Title");
		p1.setProperty(ChartConstants.ROW_LABEL, "Row_Surface");
		p1.setProperty(ChartConstants.COLUMN_LABEL, "Column_Surface");
		
		//Diagram
		Properties p2 = new Properties();
		p2.setProperty(ChartConstants.DATASOURCE,dataSourceString1);
		p2.setProperty(ChartConstants.TYPE, ChartConstants.DIAGRAM_LAYER);
		p2.setProperty(ChartConstants.USER_DEFINED_WIDTH, "true");
		p2.setProperty(ChartConstants.USER_DEFINED_HEIGHT, "true");
		p2.setProperty(ChartConstants.RADIUS, "2");
		p2.setProperty(ChartConstants.PADDING, "2");
		p2.setProperty(ChartConstants.TRANSLATE, "0");
		p2.setProperty(ChartConstants.SHOW_BASE, "TRUE");
		p2.setProperty(ChartConstants.WIDTH, "4");
		p2.setProperty(ChartConstants.HEIGHT, "-1");
		p2.setProperty(ChartConstants.ROW_LABEL, "Row_Diagram");
		p2.setProperty(ChartConstants.COLUMN_LABEL, "Column_Diagram");
		
		//Object
		Properties p3 = new Properties();
		p3.setProperty(ChartConstants.DATASOURCE,dataSourceString);
		p3.setProperty(ChartConstants.USER_DEFINED_WIDTH, "true");
		p3.setProperty(ChartConstants.USER_DEFINED_HEIGHT, "true");
		p3.setProperty(ChartConstants.TYPE, ChartConstants.OBJECT_LAYER);
		p3.setProperty(ChartConstants.RADIUS, "0");
		p3.setProperty(ChartConstants.PADDING, "3");
		p3.setProperty(ChartConstants.TRANSLATE, "30");
		p3.setProperty(ChartConstants.SHOW_BASE, "true");
		p3.setProperty(ChartConstants.WIDTH, "4");
		p3.setProperty(ChartConstants.HEIGHT, "-1");
		p3.setProperty(ChartConstants.ROW_LABEL, "Row_Object");
		p3.setProperty(ChartConstants.COLUMN_LABEL, "Column_Object");
		
		//Object
		/*Properties p4 = new Properties();
		p4.setProperty(ChartConstants.DATASOURCE,dataSourceString);
		p4.setProperty(ChartConstants.TYPE, ChartConstants.OBJECT_LAYER);
		p4.setProperty(ChartConstants.RADIUS, "1");
		p4.setProperty(ChartConstants.PADDING, "3");
		p4.setProperty(ChartConstants.TRANSLATE, "-45");
		p4.setProperty(ChartConstants.SHOW_BASE, "true");
		p4.setProperty(ChartConstants.WIDTH, "2");
		p4.setProperty(ChartConstants.HEIGHT, "2");
		p4.setProperty(ChartConstants.ROW_LABEL, "Row_Object2");
		p4.setProperty(ChartConstants.COLUMN_LABEL, "Column_Object2");*/
		
		p.add(p1);//alap hogy n�zzenek ki a layerek
		p.add(p1);//ez els� layer adatai
		p.add(p2);
		p.add(p3);
		//p.add(p4);
		
		cc.setChartProperties(Grid3D_type.getID(),p);
		cc.setFireInitialEvent(true);
		  
		wrapPanel = Grid3D_type.createChart(cc);
		
		createAndShowGUI();
	}

}
