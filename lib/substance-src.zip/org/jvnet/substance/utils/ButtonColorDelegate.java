/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.utils;

import java.awt.Color;
import java.awt.color.ColorSpace;

import javax.swing.AbstractButton;
import javax.swing.plaf.UIResource;

import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.theme.SubstanceTheme.ThemeKind;

/**
 * Helper extension of {@link Color} class that is based on the current visual
 * status of a delegate button.
 * 
 * @author Kirill Grouchnikov
 */
public class ButtonColorDelegate extends Color implements UIResource {
	/**
	 * The delegate button.
	 */
	protected AbstractButton button;

	/**
	 * Indicates whether <code>this</code> color is for the foreground.
	 */
	protected boolean isForeground;

	/**
	 * Creates new color extension.
	 * 
	 * @param button
	 *            The delegate button.
	 * @param isForeground
	 *            Indicates whether <code>this</code> color is for the
	 *            foreground.
	 */
	public ButtonColorDelegate(AbstractButton button, boolean isForeground) {
		super(isForeground ? button.getForeground().getRGB() : button
				.getBackground().getRGB());
		this.button = button;
		this.isForeground = isForeground;
	}

	/**
	 * Returns the delegate color corresponding to the current visual state of
	 * the delegate button.
	 * 
	 * @return Delegate color corresponding to the current visual state of the
	 *         delegate button.
	 */
	protected Color getDelegate() {
		ComponentState state = ComponentState.getState(button.getModel(),
				button);
		ComponentState.ColorSchemeKind kind = state.getColorSchemeKind();

		// compute color scheme
		SubstanceTheme theme = SubstanceCoreUtilities.getComponentTheme(button,
				kind);
		boolean isDark = SubstanceCoreUtilities.isThemeDark(theme)
				&& (theme.getKind() != ThemeKind.NEGATED);
		ColorScheme colorScheme = theme.getColorScheme();
		ColorScheme colorScheme2 = colorScheme;
		float cyclePos = state.getCycleCount();

		FadeTracker fadeTracker = FadeTracker.getInstance();
		if (fadeTracker.isTracked(button, FadeKind.SELECTION)) {
			boolean isActive = SubstanceCoreUtilities
					.isControlAlwaysPaintedActive(button);
			ColorScheme defaultScheme = SubstanceCoreUtilities
					.getDefaultScheme(button);
			if (state == ComponentState.DEFAULT) {
				// Came from selected state
				colorScheme = SubstanceCoreUtilities.getActiveScheme(button);
				colorScheme2 = isActive ? colorScheme : defaultScheme;
				cyclePos = fadeTracker.getFade10(button, FadeKind.SELECTION);
			}
			if (state == ComponentState.SELECTED) {
				// Came from default state
				colorScheme2 = colorScheme;
				colorScheme = isActive ? colorScheme : defaultScheme;
				cyclePos = 10 - fadeTracker.getFade10(button,
						FadeKind.SELECTION);
			}
		}
		if (fadeTracker.isTracked(button, FadeKind.ROLLOVER)) {
			boolean isActive = SubstanceCoreUtilities
					.isControlAlwaysPaintedActive(button);
			ColorScheme defaultScheme = SubstanceCoreUtilities
					.getDefaultScheme(button);
			if (state == ComponentState.DEFAULT) {
				// Came from rollover state
				colorScheme = SubstanceCoreUtilities.getActiveScheme(button);
				colorScheme2 = isActive ? colorScheme : defaultScheme;
				cyclePos = fadeTracker.getFade10(button, FadeKind.ROLLOVER);
			}
			if (state == ComponentState.ROLLOVER_UNSELECTED) {
				// Came from default state
				colorScheme2 = colorScheme;
				colorScheme = isActive ? colorScheme : defaultScheme;
				cyclePos = 10 - fadeTracker
						.getFade10(button, FadeKind.ROLLOVER);
			}
		}

		if (this.isForeground) {
			Color c1 = colorScheme.getForegroundColor();
			Color c2 = colorScheme2.getForegroundColor();
			return SubstanceColorUtilities.getInterpolatedColor(c1, c2,
					cyclePos / 10.);
		} else {
			Color c1 = isDark ? colorScheme.getUltraLightColor() : colorScheme
					.getDarkColor();
			Color c2 = isDark ? colorScheme2.getUltraLightColor()
					: colorScheme2.getDarkColor();
			return SubstanceColorUtilities.getInterpolatedColor(c1, c2,
					cyclePos / 10.);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getRGB()
	 */
	@Override
	public int getRGB() {
		return this.getDelegate().getRGB();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#brighter()
	 */
	@Override
	public Color brighter() {
		return this.getDelegate();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#darker()
	 */
	@Override
	public Color darker() {
		return new Color(0x0, true);
		// return this.getDelegate().darker();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getAlpha()
	 */
	@Override
	public int getAlpha() {
		return this.getDelegate().getAlpha();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getBlue()
	 */
	@Override
	public int getBlue() {
		return this.getDelegate().getBlue();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getColorComponents(java.awt.color.ColorSpace,
	 *      float[])
	 */
	@Override
	public float[] getColorComponents(ColorSpace cspace, float[] compArray) {
		return this.getDelegate().getColorComponents(cspace, compArray);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getColorComponents(float[])
	 */
	@Override
	public float[] getColorComponents(float[] compArray) {
		return this.getDelegate().getColorComponents(compArray);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getColorSpace()
	 */
	@Override
	public ColorSpace getColorSpace() {
		return this.getDelegate().getColorSpace();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getComponents(java.awt.color.ColorSpace, float[])
	 */
	@Override
	public float[] getComponents(ColorSpace cspace, float[] compArray) {
		return this.getDelegate().getComponents(cspace, compArray);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getComponents(float[])
	 */
	@Override
	public float[] getComponents(float[] compArray) {
		return this.getDelegate().getComponents(compArray);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getGreen()
	 */
	@Override
	public int getGreen() {
		return this.getDelegate().getGreen();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getRed()
	 */
	@Override
	public int getRed() {
		return this.getDelegate().getRed();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getRGBColorComponents(float[])
	 */
	@Override
	public float[] getRGBColorComponents(float[] compArray) {
		return this.getDelegate().getRGBColorComponents(compArray);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getRGBComponents(float[])
	 */
	@Override
	public float[] getRGBComponents(float[] compArray) {
		return this.getDelegate().getRGBComponents(compArray);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Color#getTransparency()
	 */
	@Override
	public int getTransparency() {
		return this.getDelegate().getTransparency();
	}
}
