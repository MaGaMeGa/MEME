/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.network;

import java.awt.Color;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.decorators.EdgeShape;
import edu.uci.ics.jung.graph.decorators.ToolTipFunctionAdapter;
import edu.uci.ics.jung.graph.decorators.VertexPaintFunction;
import edu.uci.ics.jung.graph.decorators.VertexShapeFunction;
import edu.uci.ics.jung.visualization.Layout;
import edu.uci.ics.jung.visualization.PickSupport;
import edu.uci.ics.jung.visualization.PickedState;
import edu.uci.ics.jung.visualization.PluggableRenderer;
import edu.uci.ics.jung.visualization.ShapePickSupport;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.contrib.KKLayout;
import edu.uci.ics.jung.visualization.control.AbstractGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.AnimatedPickingGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;
import edu.uci.ics.jung.visualization.control.LayoutScalingControl;
import edu.uci.ics.jung.visualization.control.PickingGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.RotatingGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.ScalingGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.ShearingGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.TranslatingGraphMousePlugin;

public class SubGraphUtils {
	
	private static AbstractGraphMousePlugin customScalingPlugin = null;
	private static final double LEVEL_0_SIZE=24;
	private static final double LEVEL_1_SIZE=18;
	private static final double LEVEL_DEF_SIZE=12;
	//private static final double vertexSizePercentage=100;
	
	public static void setCustomScalingPlugin(AbstractGraphMousePlugin customPlugin) {
		customScalingPlugin = customPlugin;
	}
	
	public static VisualizationViewer createVisualizationViewer(final IGraphSource graphSource, Vertex root, final double vertexSizePercentage) {
		
		Graph g = graphSource.getSubGraph(root);
		
        Layout l = new KKLayout(g);        
        PluggableRenderer r = new PluggableRenderer();
        r.setEdgeShapeFunction(new EdgeShape.Line());
        r.setVertexShapeFunction(new VertexShapeFunction() {
            public Shape getShape(Vertex v) {
            	
            	Integer level = (Integer) v.getUserDatum(IGraphSource.LEVEL);
//            	System.out.println(".createVisualizationViewer() " + level.intValue());
            	switch (level.intValue()) {
            		case 0:	
            		{
            			double level0Size=(LEVEL_0_SIZE*vertexSizePercentage)/100;
            			return new Ellipse2D.Double(-level0Size/2, -level0Size/2,level0Size, level0Size);
            		}
            		case 1:	
            		{
            			double level1Size=(LEVEL_1_SIZE*vertexSizePercentage)/100;
            			return new Ellipse2D.Double(-level1Size/2, -level1Size/2,level1Size, level1Size);
            		}	
            		default:	
            		{
            			double levelDefSize=(LEVEL_DEF_SIZE*vertexSizePercentage)/100;
            			return new Ellipse2D.Double(-levelDefSize/2, -levelDefSize/2,levelDefSize, levelDefSize);
            		}
            		/*case 0:	
            			return new Ellipse2D.Float(-12, -12, 24, 24);
            		case 1:
            			return new Ellipse2D.Float(-9, -9, 18, 18);
            		default:
            			return new Ellipse2D.Float(-6, -6, 12, 12);
            		*/        			
            	}
            }
        }); 

        r.setVertexPaintFunction(new VertexPaintFunction() {

			public Paint getFillPaint(Vertex v) {
            	Integer level = (Integer) v.getUserDatum(IGraphSource.LEVEL);
            	
            	switch (level.intValue()) {
            		case 0:	
            			return Color.red;
            		case 1:
            			return Color.green;
            		default:
            			return Color.yellow; 			
            	}
			}

			public Paint getDrawPaint(Vertex v) {
				return Color.BLACK;
			}
        	
        });
        
        VisualizationViewer v = new VisualizationViewer(l, r);
        
        v.setToolTipFunction(new ToolTipFunctionAdapter() {
            public String getToolTipText(Vertex v) {
                return (String)v.getUserDatum(IGraphSource.TOOLTIP);
            }
        });
        
		PickSupport pickSupport = new ShapePickSupport();
        v.setPickSupport(pickSupport);
        
        v.setBackground(Color.white);
        
        DefaultModalGraphMouse gm = new DefaultModalGraphMouse() {
        	
        	private GraphUpdaterPlugin graphUpdaterPlugin;
        	
            protected void loadPlugins() {
                pickingPlugin = new PickingGraphMousePlugin();
                animatedPickingPlugin = new AnimatedPickingGraphMousePlugin();
                translatingPlugin = new TranslatingGraphMousePlugin(InputEvent.BUTTON1_MASK);
                scalingPlugin = customScalingPlugin != null ? customScalingPlugin : new ScalingGraphMousePlugin(new LayoutScalingControl(),0,1.1f,0.9f);
                rotatingPlugin = new RotatingGraphMousePlugin();
                shearingPlugin = new ShearingGraphMousePlugin();
                graphUpdaterPlugin = new GraphUpdaterPlugin(graphSource);
                
                add(scalingPlugin);
                
                setTransformingMode();
            }
            
            protected void setPickingMode() { 
            	remove(translatingPlugin); 
            	remove(rotatingPlugin); 
            	remove(shearingPlugin); 
            	add(pickingPlugin); 
            	add(animatedPickingPlugin); 
            	add(graphUpdaterPlugin);
            }
            
            protected void setTransformingMode() { 
            	remove(pickingPlugin); 
            	remove(animatedPickingPlugin); 
            	add(translatingPlugin); 
            	add(rotatingPlugin); 
            	add(shearingPlugin); 
            	add(graphUpdaterPlugin); 
            }             
        };        
        
        v.setGraphMouse(gm);
                
		return v;
	}
	
	public static class GraphUpdaterPlugin extends AbstractGraphMousePlugin implements MouseListener {
		
		private IGraphSource source;
		
		public GraphUpdaterPlugin(IGraphSource source) {
			super(InputEvent.BUTTON1_MASK);
			this.source = source;
		}

		public void mouseClicked(MouseEvent e) {
			;			
		}

		public void mousePressed(MouseEvent e) {
			
			//down = e.getPoint();
			
	        VisualizationViewer vv = (VisualizationViewer)e.getSource();
	        PickSupport pickSupport = vv.getPickSupport();
	        PickedState pickedState = vv.getPickedState();
	        
	        Vertex vertex = null;
	        
	        if(pickSupport != null && pickedState != null) {
                Point2D p = e.getPoint();                
                Point2D ip = vv.inverseViewTransform(p);                
                vertex = pickSupport.getVertex(ip.getX(), ip.getY());
                
                if (vertex != null) {
                	
                	Integer level = (Integer) vertex.getUserDatum(IGraphSource.LEVEL);
                	
                	if (level.intValue() != 0)                	
                		updateGraph(vv, vertex);
                }
	        }
		}

		public void mouseReleased(MouseEvent e) {
			;
		}

		public void mouseEntered(MouseEvent e) {
			;
		}

		public void mouseExited(MouseEvent e) {
			;
		}
				
		
		private void updateGraph(VisualizationViewer vv, Vertex v) {
			Graph g = source.getSubGraph(v);
			
//			long begin = System.currentTimeMillis();
			Layout l = new KKLayout(g); 

            vv.stop();
            vv.setGraphLayout(l);
            vv.restart();
            
            
//          long end = System.currentTimeMillis();
            
//          System.out.println("updateGraph: " + (end-begin) +"ms");
		}
	}
	
}
