package ai.aitia.visu.axis;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.List;

import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTick;
import org.jfree.chart.axis.Tick;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.ValueTick;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.text.TextUtilities;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.TextAnchor;

@SuppressWarnings("serial")
public class MatrixAxis extends NumberAxis{

	public MatrixAxis(String label) {
        super(label);
    }
	
	public AxisState draw(Graphics2D g2, 
            double cursor,
            Rectangle2D plotArea, 
            Rectangle2D dataArea, 
            RectangleEdge edge,
            PlotRenderingInfo plotState,
            int rowCount) {
		
		AxisState state = null;
		// if the axis is not visible, don't draw it...
		if (!isVisible()) {
			state = new AxisState(cursor);
		// even though the axis is not visible, we need ticks for the 
		// gridlines...
			List ticks = refreshTicks(g2, state, dataArea, edge); 
			state.setTicks(ticks);
			return state;
		}

		// draw the tick marks and labels...
		
		state = drawTickMarksAndLabels(g2, cursor, plotArea, dataArea, edge, rowCount);
		
		
		state = drawLabel(getLabel(), g2, plotArea, dataArea, edge, state, rowCount);
		//state = drawLabel(g2, plotArea, dataArea, edge, state);
		
		return state;

	}
	
	protected AxisState drawLabel( String label,
            Graphics2D g2, 
            Rectangle2D plotArea, 
            Rectangle2D dataArea,
            RectangleEdge edge, 
            AxisState state, int rowCount) {

// it is unlikely that 'state' will be null, but check anyway...
		if (state == null) {
			throw new IllegalArgumentException("Null 'state' argument.");
		}	

		if (label == null) {
			return state;
		}

		Font font = getLabelFont();
		RectangleInsets insets = getLabelInsets();
		g2.setFont(font);
		g2.setPaint(getLabelPaint());
		FontMetrics fm = g2.getFontMetrics();

		if (edge == RectangleEdge.BOTTOM) {
			for(int i=0; i<rowCount; i++){
				//label="(" + Integer.toString(i+1) + ")";
				label="";
				Rectangle2D labelBounds = TextUtilities.getTextBounds(label, g2, fm);
				AffineTransform t = AffineTransform.getRotateInstance(
						getLabelAngle(), 
						labelBounds.getCenterX(), labelBounds.getCenterY()
				);
				Shape rotatedLabelBounds = t.createTransformedShape(labelBounds);
				labelBounds = rotatedLabelBounds.getBounds2D();
				//double labelx = dataArea.getCenterX() + i;
				
				double labelx = dataArea.getMinX() + (i+0.5)*(dataArea.getWidth()/rowCount);
				double labely = state.getCursor() 
				+ insets.getBottom() 
				+ labelBounds.getHeight() / 2.0;
				
				/*double labely = dataArea.getMinY() 
				- insets.getBottom() 
				- labelBounds.getHeight() / 2.0;*/
				
				TextUtilities.drawRotatedString(
						label, g2, (float) labelx, (float) labely,
						TextAnchor.CENTER, getLabelAngle(), TextAnchor.CENTER
				);
				if(i==(rowCount-1)){
					state.cursorUp(
							insets.getTop() + labelBounds.getHeight() + insets.getBottom()
					);	
				}
				
			}
			
			
		}
		
		else if (edge == RectangleEdge.LEFT) {
			for(int i=0; i<rowCount; i++){
				//label="(" + Integer.toString(i+1) + ")";
				label = "";
				Rectangle2D labelBounds = TextUtilities.getTextBounds(label, g2, fm);
				AffineTransform t = AffineTransform.getRotateInstance(
						getLabelAngle()+ Math.PI / 2.0, 
						labelBounds.getCenterX(), labelBounds.getCenterY()
				);
				Shape rotatedLabelBounds = t.createTransformedShape(labelBounds);
				labelBounds = rotatedLabelBounds.getBounds2D();
				//double labelx = dataArea.getCenterX() + i;
				
				//double labelx = dataArea.getMinX() + (i+0.5)*(dataArea.getWidth()/rowCount);
				double labelx = state.getCursor() 
				- insets.getLeft() - labelBounds.getWidth() / 2.0;
				/*double labely = state.getCursor() 
				+ insets.getBottom() 
				+ labelBounds.getHeight() / 2.0;
				*/
				double labely = dataArea.getMinY() + (i+0.5)*(dataArea.getHeight()/rowCount);
				
				/*double labely = dataArea.getMinY() 
				- insets.getBottom() 
				- labelBounds.getHeight() / 2.0;*/
				
				TextUtilities.drawRotatedString(
						label, g2, (float) labelx, (float) labely,
						TextAnchor.CENTER, getLabelAngle(), TextAnchor.CENTER
				);
				if(i==(rowCount-1)){
					state.cursorRight(
							insets.getLeft() + labelBounds.getWidth() + insets.getRight()
					);
				}
				
			}
			
		}
		
		return state;
		
	}
	
	
	protected AxisState drawTickMarksAndLabels(Graphics2D g2, 
            double cursor,
            Rectangle2D plotArea,
            Rectangle2D dataArea, 
            RectangleEdge edge,
            int rowCount) {
           
		AxisState state = new AxisState(cursor);

		if(edge == RectangleEdge.TOP || edge == RectangleEdge.RIGHT){
			return null;
		}
		
		if (isAxisLineVisible()) {
			drawAxisLine(g2, cursor, dataArea, edge, rowCount);
		}

		double ol = getTickMarkOutsideLength();
		double il = getTickMarkInsideLength();
		

		List ticks = refreshTicks(g2, state, dataArea, edge, rowCount);
		state.setTicks(ticks);
		g2.setFont(getTickLabelFont());
		//ValueTick t = (ValueTick) lis;
		//double hi=Math.ceil(this.calculateHighestVisibleTickValue());
		//double lo=Math.floor(this.calculateLowestVisibleTickValue());
		double hi=this.calculateHighestVisibleTickValue();
		double lo=this.calculateLowestVisibleTickValue();
		
		
		for(int i=0; i<rowCount; i++){
			Iterator iterator = ticks.iterator();
			while (iterator.hasNext()) {
				
				ValueTick tick = (ValueTick) iterator.next();
				if (isTickLabelsVisible()) {
					g2.setPaint(getTickLabelPaint());
					
					float[] anchorPoint = calculateAnchorPoint(
							tick, cursor, dataArea, edge,rowCount, i, hi, lo
					);
					TextUtilities.drawRotatedString(
							tick.getText(), g2, 
							anchorPoint[0], anchorPoint[1],
							tick.getTextAnchor(), 
							tick.getAngle(),
							tick.getRotationAnchor()
					);
				}
				
				if (isTickMarksVisible()) {
					
					Line2D mark = null;
					g2.setStroke(getTickMarkStroke());
					g2.setPaint(getTickMarkPaint());
					if (edge == RectangleEdge.LEFT) {
						double xx = valueToJava2D(
								//tick.getValue(), dataArea, edge
								(tick.getValue()-lo)/rowCount + lo + (i*(hi-lo))/rowCount
								, dataArea, edge
						);
						mark = new Line2D.Double(cursor - ol, xx, cursor+ il, xx);
					}
					/*else if (edge == RectangleEdge.RIGHT) {
						mark = new Line2D.Double(cursor + ol, xx, cursor - il, xx);
					}
					else if (edge == RectangleEdge.TOP) {
							mark = new Line2D.Double(xx, cursor - ol, xx, cursor + il);
					}*/
					else if (edge == RectangleEdge.BOTTOM) {
						float xx = (float) valueToJava2D(
								//tick.getValue(), dataArea, edge
								(tick.getValue()-lo)/rowCount + lo + (i*(hi-lo))/rowCount
								, dataArea, edge
						);
						mark = new Line2D.Double(xx, cursor + ol, xx, cursor - il);
					}
					g2.draw(mark);
				}
			}
		}
		

		// need to work out the space used by the tick labels...
		// so we can update the cursor...
		double used = 0.0;
		if (isTickLabelsVisible()) {
			if (edge == RectangleEdge.LEFT) {
				used += findMaximumTickLabelWidth(
						ticks, g2, plotArea, isVerticalTickLabels()
				);  
				state.cursorLeft(used);      
		}
		else if (edge == RectangleEdge.RIGHT) {
			used = findMaximumTickLabelWidth(
					ticks, g2, plotArea, isVerticalTickLabels()
			);
			state.cursorRight(used);      
		}
		else if (edge == RectangleEdge.TOP) {
			used = findMaximumTickLabelHeight(
					ticks, g2, plotArea, isVerticalTickLabels()
			);
			state.cursorUp(used);
		}
		else if (edge == RectangleEdge.BOTTOM) {
			used = findMaximumTickLabelHeight(
					ticks, g2, plotArea, isVerticalTickLabels()
			);
			state.cursorDown(used);
			}
		}

		return state;
	}
	
	protected float[] calculateAnchorPoint(ValueTick tick, 
            double cursor, 
            Rectangle2D dataArea, 
            RectangleEdge edge,int rowCount, int row, double hi, double lo) {

		RectangleInsets insets = getTickLabelInsets();
		float[] result = new float[2];
		/*if (edge == RectangleEdge.TOP) {
			result[0] = (float) valueToJava2D(tick.getValue(), dataArea, edge);
			result[1] = (float) (cursor - insets.getBottom() - 2.0);
		}*/
		
		
		if (edge == RectangleEdge.BOTTOM) {
			
			result[0] = (float) valueToJava2D((tick.getValue()-lo)/rowCount + lo + (row*(hi-lo))/rowCount , dataArea, edge);
			result[1] = (float) (cursor + insets.getTop() + 2.0); 
		}
		else if (edge == RectangleEdge.LEFT) {
			result[0] = (float) (cursor - insets.getLeft() - 2.0);    
			//result[1] = (float) valueToJava2D(tick.getValue(), dataArea, edge);
			result[1] = (float) valueToJava2D((tick.getValue()-lo)/rowCount + lo + (row*(hi-lo))/rowCount , dataArea, edge);
		}
		/*else if (edge == RectangleEdge.RIGHT) {
			result[0] = (float) (cursor + insets.getRight() + 2.0);    
			result[1] = (float) valueToJava2D(tick.getValue(), dataArea, edge);
		}*/	
	return result;
	}
	
	public List refreshTicks(Graphics2D g2, 
            AxisState state,
            Rectangle2D dataArea,
            RectangleEdge edge, int rowCount) {

		List result = new java.util.ArrayList();
		if (RectangleEdge.isTopOrBottom(edge)) {
			result = refreshTicksHorizontal(g2, dataArea, edge, rowCount);
		}
		else if (RectangleEdge.isLeftOrRight(edge)) {
			result = refreshTicksVertical(g2, dataArea, edge, rowCount);
		}
		return result;

	}
	
	@SuppressWarnings("unchecked")
	protected List refreshTicksHorizontal(Graphics2D g2,
            Rectangle2D dataArea,
            RectangleEdge edge, int rowCount) {

		List result = new java.util.ArrayList();

		Font tickLabelFont = getTickLabelFont();
		g2.setFont(tickLabelFont);

		if (isAutoTickUnitSelection()) {
			selectAutoTickUnit(g2, dataArea, edge);
		}

		double size = getTickUnit().getSize();
		int count = calculateVisibleTickCount();
		double lowestTickValue = calculateLowestVisibleTickValue();

		if (count <= ValueAxis.MAXIMUM_TICK_COUNT) {
			for (int i = rowCount; i < count; i+=rowCount) {
				double currentTickValue = lowestTickValue + (i * size);
				String tickLabel	;
				NumberFormat formatter = getNumberFormatOverride();
				if (formatter != null) {
					tickLabel = formatter.format(currentTickValue);
				}
				else {
					tickLabel = getTickUnit().valueToString(currentTickValue);
				}
				TextAnchor anchor = null;
				TextAnchor rotationAnchor = null;
				double angle = 0.0;
				if (isVerticalTickLabels()) {
					anchor = TextAnchor.CENTER_RIGHT;
					rotationAnchor = TextAnchor.CENTER_RIGHT;
					if (edge == RectangleEdge.TOP) {
						angle = Math.PI / 2.0;
					}
					else {
						angle = -Math.PI / 2.0;
					}
				}	
				else {
					if (edge == RectangleEdge.TOP) {
						anchor = TextAnchor.BOTTOM_CENTER;
						rotationAnchor = TextAnchor.BOTTOM_CENTER;
					}
					else {
						anchor = TextAnchor.TOP_CENTER;
						rotationAnchor = TextAnchor.TOP_CENTER;
					}
				}
				
				Tick tick = new NumberTick(
						new Double(currentTickValue), tickLabel, anchor, 
						rotationAnchor, angle	
				);
				result.add(tick);
			}
		}
		return result;

	}
	
	 @SuppressWarnings("unchecked")
	protected List refreshTicksVertical(Graphics2D g2,
             Rectangle2D dataArea,
             RectangleEdge edge, int rowCount) {

		 List result = new java.util.ArrayList();
		 result.clear();

		 Font tickLabelFont = getTickLabelFont();
		 g2.setFont(tickLabelFont);
		 if (isAutoTickUnitSelection()) {
			 selectAutoTickUnit(g2, dataArea, edge);
		 }

		 double size = getTickUnit().getSize();//*rowCount*10000;
		 int count = (calculateVisibleTickCount());///rowCount)/10000;
		 double lowestTickValue = calculateLowestVisibleTickValue();
		 if (count <= ValueAxis.MAXIMUM_TICK_COUNT) {
			 for (int i = rowCount; i < count; i+=rowCount) {
				 double currentTickValue = lowestTickValue + (i * size);
				 String tickLabel;
				 NumberFormat formatter = getNumberFormatOverride();
				 if (formatter != null) {
					 tickLabel = formatter.format(currentTickValue);
				 }
				 else {
					 tickLabel = getTickUnit().valueToString(currentTickValue);
				 }
				 
				 TextAnchor anchor = null;
				 TextAnchor rotationAnchor = null;
				 double angle = 0.0;
				 if (isVerticalTickLabels()) {
					 if (edge == RectangleEdge.LEFT) { 
						 
						 anchor = TextAnchor.BOTTOM_CENTER;
						 rotationAnchor = TextAnchor.BOTTOM_CENTER;
						 angle = -Math.PI / 2.0;
					 }
					 else {
						 
						 anchor = TextAnchor.BOTTOM_CENTER;
						 rotationAnchor = TextAnchor.BOTTOM_CENTER;
						 angle = Math.PI / 2.0;
					 }
				 }
				 else {
					 if (edge == RectangleEdge.LEFT) {
						 anchor = TextAnchor.CENTER_RIGHT;
						 rotationAnchor = TextAnchor.CENTER_RIGHT;
					 }
					 else {
						 
						 anchor = TextAnchor.CENTER_LEFT;
						 rotationAnchor = TextAnchor.CENTER_LEFT;
					 }
				 }
				 
				 Tick tick = new NumberTick(
						 new Double(currentTickValue), tickLabel, anchor, 
						 rotationAnchor, angle
				 );
				 result.add(tick);
			 }
		 }
		 /*List r = new java.util.ArrayList();
		 for(int i=0; i<rowCount; i++){
			 r.addAll(result);
		 }*/
		 return result;
		 //return r;
		 
	 }
	
	protected void drawAxisLine(Graphics2D g2, double cursor,
            Rectangle2D dataArea, RectangleEdge edge, int rowCount) {
		Line2D axisLine = null;
		if (edge == RectangleEdge.BOTTOM) {
			double cellHeight=dataArea.getHeight()/rowCount;
			g2.setPaint(getAxisLinePaint());
			g2.setStroke(getAxisLineStroke());
			for(int i=0; i<=rowCount; i++){
				axisLine = new Line2D.Double(
						//dataArea.getX(), cursor, dataArea.getMaxX(), cursor
						dataArea.getX(), cursor-i*cellHeight, dataArea.getMaxX(), cursor - i*cellHeight
				);	
				g2.draw(axisLine);
			}
			  
			
			
		}
		else if (edge == RectangleEdge.LEFT) {
			double cellWidth=dataArea.getWidth()/rowCount;
			g2.setPaint(getAxisLinePaint());
			g2.setStroke(getAxisLineStroke());
			for(int i=0; i<=rowCount; i++){
				axisLine = new Line2D.Double(
						cursor+i*cellWidth, dataArea.getY(), cursor+i*cellWidth, dataArea.getMaxY()
				);
				g2.draw(axisLine);
			}
			  
		}		
	}
	
	public double valueToJava2D(double value, Rectangle2D plotArea,
            RectangleEdge edge, boolean log) {
		 return super.valueToJava2D(value,plotArea,
		            edge);
	 }
}
