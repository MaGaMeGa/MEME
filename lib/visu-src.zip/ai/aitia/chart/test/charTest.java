/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.test;

import javax.swing.*;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.XMLFileFilter;
import ai.aitia.visu.globalhandlers.GlobalHandlers;

import java.awt.*;
import java.awt.event.*;
import java.io.File;


/** A test program for MEME's chart dialogs
 * 
 * @author Bocsi Rajmund (rbocsi@aitia.ai)
 *
 */
public class charTest {


	public static JPanel createContentPane(final JFrame parent) {
		final JPanel content = new JPanel();
		content.setLayout(new BoxLayout(content,BoxLayout.Y_AXIS));
		DataSources ds = null;
		try {
			ds = new DataSources(new SimpleDSPCollection());
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		ChartConfig config = new ChartConfig(ds);
		config.setChartProperties(ChartConstants.XYLINECHART,null);
		config.setFireInitialEvent(true);
		final Component chart = AbstractChart.find(ChartConstants.XYLINECHART).createDialog(config,null);
		content.add(chart);
		content.addComponentListener(new ComponentAdapter() {
			public void componentHidden(ComponentEvent e) {
				if (e.getSource() == chart)
					System.exit(0);
			}
		});
		JPanel buttons = new JPanel(new GridLayout(0,4));
		buttons.setBorder(BorderFactory.createTitledBorder("Chart"));
		JButton ldButton = new JButton("Load&Display...");
		ldButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File file = load(parent);
				if (file == null) return;
				ChartConfigCollection ccc = null;
				try {
					ccc = ChartConfigCollection.load(file.toURI(),new SimpleDSPCollection());
					for (Object o : ccc) {
						ChartConfig cc = (ChartConfig)o;
						Container panel = AbstractChart.display(cc);
						JFrame frame = new JFrame(cc.getChartType());
						frame.setContentPane(panel);
						frame.pack();
						frame.setVisible(true);
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		JButton lmButton = new JButton("Load&Modify...");
		lmButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File file = load(parent);
				if (file == null) return;
				ChartConfigCollection ccc = null;
				try {
					ccc = ChartConfigCollection.load(file.toURI(),new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if (ccc.getChartConfigCount() == 1) {
					Component new_chart = ccc.createDialog();
					content.remove(0);
					content.add(new_chart, 0);
					parent.pack();
			    } else {
			    	System.out.println("Sorry");
			    }
			} 
		});
		JButton xylcButton = new JButton("XYLineChart");
		xylcButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.XYLINECHART,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.XYLINECHART).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart,0);
				parent.pack();
			}
		});
		JButton spcButton = new JButton("ScatterPlotChart");
		spcButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.SCATTERPLOT,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.SCATTERPLOT).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart,0);
				parent.pack();
			}
		});
		JButton tscButton = new JButton("RealTimeSeries");
		tscButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.REALTIMESERIES,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.REALTIMESERIES).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart,0);
				parent.pack();
			}
		});
		JButton bcButton = new JButton("BarChart");
		bcButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.BARCHART,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.BARCHART).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart,0);
				parent.pack();
			}
		});
		JButton hcButton = new JButton("Histogram");
		hcButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.HISTOGRAM,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.HISTOGRAM).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart, 0);
				parent.pack();
			}
		});
		JButton racButton = new JButton("RectangleArea");
		racButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.RECTANGLEAREACHART,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.RECTANGLEAREACHART).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart,0);
				parent.pack();
			}
		});
		JButton g2dButton = new JButton("Grid2D");
		g2dButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.GRID2D,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.GRID2D).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart,0);
				parent.pack();
			}
		});
		JButton sg2dButton = new JButton("ShapeGrid2D");
		sg2dButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.SHAPEGRID2D,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.SHAPEGRID2D).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart,0);
				parent.pack();
			}
		});
		JButton cg2dButton = new JButton("CompositeGrid2D");
		cg2dButton.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.COMPOSITEGRID2D,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.COMPOSITEGRID2D).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart,0);
				parent.pack();
			}
		});
		
		JButton pcButton = new JButton("PieChart");
		pcButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.PIECHART,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.PIECHART).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart,0);
				parent.pack();
			}
		});
		
		JButton bpButton = new JButton("BoxPlot");
		bpButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DataSources ds = null;
				try {
					ds = new DataSources(new SimpleDSPCollection());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ChartConfig cc = new ChartConfig(ds);
				cc.setChartProperties(ChartConstants.BOXPLOT,null);
				cc.setFireInitialEvent(true);
				Component new_chart = AbstractChart.find(ChartConstants.BOXPLOT).createDialog(cc,null);
				content.remove(0);
				content.add(new_chart,0);
				parent.pack();
			}
		});
//		JButton rvButton = new JButton("RadViz");
//		rvButton.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				DataSources ds = null;
//				try {
//					ds = new DataSources(new SimpleDSPCollection());
//				} catch (Exception e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//				ChartConfig cc = new ChartConfig(ds);
//				cc.setChartProperties(ChartConstants.RADVIZ,null);
//				cc.setFireInitialEvent(true);
//				Component new_chart = AbstractChart.find(ChartConstants.RADVIZ).createDialog(cc,null);
//				content.remove(0);
//				content.add(new_chart,0);
//				parent.pack();
//			}
//		});
		buttons.add(ldButton);
		buttons.add(lmButton);
		buttons.add(xylcButton);
		buttons.add(spcButton);
		buttons.add(tscButton);
		buttons.add(bcButton);
		buttons.add(hcButton);
		buttons.add(racButton);
		buttons.add(g2dButton);
		buttons.add(sg2dButton);
		buttons.add(cg2dButton);
		buttons.add(pcButton);
		buttons.add(bpButton);
//		buttons.add(rvButton);
		content.add(buttons,BorderLayout.PAGE_END);
		return content;
	}
	
	public static File load(JFrame parent) {
		JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
		fc.setAcceptAllFileFilterUsed(false);
		fc.addChoosableFileFilter(new XMLFileFilter());
		int result = fc.showOpenDialog(parent);
		if (result == JFileChooser.APPROVE_OPTION) {
			GlobalHandlers.setLastDirectory(fc.getSelectedFile());
			return fc.getSelectedFile();
		} else return null;
		
	}
		
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				AbstractChart.registerAll();
				JFrame frame = new JFrame("TestChart");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setContentPane(charTest.createContentPane(frame));
				frame.setMaximumSize(new Dimension(609,1024));
				frame.pack();
				frame.setVisible(true);
			}
		});
	}
}
