/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.view.meta;

import java.awt.Color;

import ai.aitia.visu.view.meta.CustomAppearance;
import ai.aitia.visu.view.ui.ColorMap;

/** Metadata class for a network. */
public class GraphMetadata {
	
	/** Layout constant of the Fricherman Reingold layout. */
	public static final String FRUCHTERMAN_REINGOLD = "Fruchterman Reingold";

	/** Layout constant of the Kamada Kawai layout. */
	public static final String KAMADA_KAWAI = "Kamada Kawai";
	
	/** Layout constant of the three-dimensional Kamada Kawai layout. */
	public static final String KAMADA_KAWAI_3D = "Kamada Kawai 3D";
	
	/** Layout constant of the Meyers layout. */
    public static final String MEYERS = "Meyers";
    
	/** Layout constant of the circle layout. */
    public static final String CIRCLE = "Circle";
    
	/** Layout constant of the spring layout. */
    public static final String SPRING = "Spring";
	
    /** Default title of the graph. */
	private static final String DEFAULT_TITLE = "Untitled graph";
	
	/** Default vertex (node) color of the graph. */
	private static final Color VERTEX_COLOR = Color.RED;
	
	/** Default vertex (node) size of the graph. */
	@SuppressWarnings("unused")
	private static final double VERTEX_SIZE = 10;
	
	/** Title of the graph. */
	private String title;
	
	/** Subtitle of the graph. */
	private String subtitle;
	
	/** Has vertex labels or not? If the value is true, then one of datasources of
	 *  the graph produces the labels.
	 */
	private boolean hasVertexLabels;
	
	/** Layout of the graph */
	private String layout;
	
	/** Parameter of the Fruchterman-Reingold layout. */
	private double repulsion, attraction;
	
	/** Number of iterations to compute an incremental layout. */
	private int nrOfIterations = -1;
	
	/** Color of the vertices. */
	private Color color;
	private ColorMap colormap = null;
	
	private CustomAppearance customAppearance = null;
	
	//===============================================================================
	// methods
	
	/** Constructor. */
	public GraphMetadata() {
		title = DEFAULT_TITLE;
		subtitle = null;
		hasVertexLabels = false;
		layout = FRUCHTERMAN_REINGOLD;
		repulsion = attraction = 0.75;
		color = VERTEX_COLOR;
	}

	//-------------------------------------------------------------------------------
	/** Returns the attraction attribute of the Frucherman-Reingold layout.
	 * @return attraction
	 */
	public double getAttraction() {	return attraction; }

	//-------------------------------------------------------------------------------
	/** Returns the repulsion attribute of the Frucherman-Reingold layout.
	 * @return repulsion
	 */
	public double getRepulsion() { return repulsion; }
	
	//-------------------------------------------------------------------------------
	/** Returns the color of the vertices. 
	 * @return color of the vertieces
	 */
	public Color getColor() { return color; }

	//-------------------------------------------------------------------------------
	/** Returns the string id of the layout of the graph.
	 * @return string id of the layout
	 */
	public String getLayout() {	return layout; }
	
	//-------------------------------------------------------------------------------
	/** Returns the title of the graph. 
	 * @return the title of the graph
	 */
	public String getTitle() { return title; }
	
	//-------------------------------------------------------------------------------
	/** Returns the subtitle of the graph.
	 * @return the subtitle of the graph 
	 */
	public String getSubtitle() { return subtitle; }
	
	//-------------------------------------------------------------------------------
	/** Returns the flag that determines whether has labels on the vertices or not. */
	public boolean hasVertexLabels() { return hasVertexLabels; }
	
	//-------------------------------------------------------------------------------
	/** Returns the number of iterations. -1 indicates that the user doesn't define
	 *  this property.
	 * @return the number of iterations 
	 */
	public int getNrOfIterations() { return nrOfIterations; }
	
	//-------------------------------------------------------------------------------
	public boolean hasCustomAppearance() { return customAppearance != null; }
	public CustomAppearance getCustomAppearance() { return customAppearance; }
	public boolean hasColorMap() { return colormap != null; }
 	public ColorMap getColorMap() { return colormap; }
	
	//-------------------------------------------------------------------------------
	/** Sets the attraction attribute of the Fruchterman-Reingold layout.
	 * @param attraction the new attraction value 
	 */
	public void setAttraction(double attraction) { this.attraction = attraction; }
	
	//-------------------------------------------------------------------------------
	/** Sets the repulsion attribute of the Fruchterman-Reingold layout.
	 * @param repulsion the new repulsion value 
	 */
	public void setRepulsion(double repulsion) { this.repulsion = repulsion; }
	
	//-------------------------------------------------------------------------------
	/** Sets the color of the vertices.
	 * @param color the new color of the vertices
	 */
	public void setColor(Color color) {	this.color = color; }
	
	//-------------------------------------------------------------------------------
	/** Sets the layout of the graph.
	 * @param layout the string id of the new layout
	 */
	public void setLayout(String layout) { this.layout = layout; }

	//-------------------------------------------------------------------------------
	/** Sets the title of the graph.
	 * @param title the new title of the graph
	 */
	public void setTitle(String title) { this.title = title; }

	//-------------------------------------------------------------------------------
	/** Sets the subtitle of the graph.
	 * @param subtitle the new subtitle of the graph
	 */
	public void setSubtitle(String subtitle) { this.subtitle = subtitle; }
	
	//-------------------------------------------------------------------------------
	/** Sets the flag that determines whether has lables on the vertices or not.
	 * @param hasVertexLabels the new value of the flag
	 */
	public void setHasVertexLabels(boolean hasVertexLabels) { this.hasVertexLabels = hasVertexLabels; }
	
	//-------------------------------------------------------------------------------
	/** Sets the number of iterations.
	 * @param nrOfIterations the new number of iterations
	 */
	public void setNrOfIterations(int nrOfIterations) { this.nrOfIterations = nrOfIterations; }
	
	//-------------------------------------------------------------------------------
	public void setCustomAppearance(CustomAppearance customAppearance) { this.customAppearance = customAppearance; }
	public void setColorMap(ColorMap colormap) { this.colormap = colormap; }
}