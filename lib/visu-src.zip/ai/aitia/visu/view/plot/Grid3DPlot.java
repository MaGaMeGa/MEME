package ai.aitia.visu.view.plot;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.Serializable;
import java.util.Enumeration;

import javax.media.j3d.AmbientLight;
import javax.media.j3d.Appearance;
import javax.media.j3d.Background;
import javax.media.j3d.Behavior;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.DirectionalLight;
import javax.media.j3d.Font3D;
import javax.media.j3d.FontExtrusion;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.Material;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Text3D;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.WakeupCondition;
import javax.media.j3d.WakeupCriterion;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOr;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.ui.RectangleEdge;

import ai.aitia.visu.VisualisationException;
import ai.aitia.visu.data.DefaultGrid3DDataset_DiagramLayer;
import ai.aitia.visu.data.DefaultGrid3DDataset_ObjLayer;
import ai.aitia.visu.data.DefaultGrid3DDataset_SurfaceLayer;
import ai.aitia.visu.data.Grid3DDataset;
import ai.aitia.visu.data.ScalarMapGrid3DDataset_DiagramLayer;
import ai.aitia.visu.data.ScalarMapGrid3DDataset_ObjLayer;
import ai.aitia.visu.data.ScalarMapGrid3DDataset_SurfaceLayer;
import ai.aitia.visu.view.meta.Grid3DMetadata;
import ai.aitia.visu.view.ui.ColorBar;
import ai.aitia.visu.view.ui.ColorMap;

import com.sun.j3d.utils.behaviors.mouse.MouseRotate;
import com.sun.j3d.utils.behaviors.mouse.MouseWheelZoom;
import com.sun.j3d.utils.geometry.Box;
import com.sun.j3d.utils.geometry.Cylinder;
import com.sun.j3d.utils.geometry.GeometryInfo;
import com.sun.j3d.utils.geometry.NormalGenerator;
import com.sun.j3d.utils.geometry.Primitive;
import com.sun.j3d.utils.geometry.Sphere;
import com.sun.j3d.utils.image.TextureLoader;
import com.sun.j3d.utils.universe.SimpleUniverse;

public class Grid3DPlot extends DefaultInteractivePlot implements 
														PropertyChangeListener,
														Serializable,
														Cloneable{

	/** For serialization */
	private static final long serialVersionUID = -1695516149041277900L;
	
	protected static final int MAXIMUM_NUMBER_OF_GRIDS = 20000;
	
    /** The dataset. */
    private Grid3DDataset[] dataset;
    
    protected boolean noSelection = false;
    protected String tooMany = "Sorry, the number of cells exceeds the drawing limit.";
    protected boolean needTooltip = false;
    
    /** The domain axis (used for the x-values). */
    private ValueAxis domainAxis;

    /** The range axis (used for the y-values). */
    private ValueAxis rangeAxis;
    
    protected ColorMap colorMap = null;
    protected boolean isUpdateColorMap = false;
    
    protected ColorBar colorBar = new ColorBar("Colors");
    
    private Grid3DMetadata[] Metas;
    
//    private Grid2DToolTipGenerator toolTipGenerator;
    
    @SuppressWarnings("unused")
	private RectangleEdge colorBarLocation;
    
    protected SimpleUniverse plot3DUniverse = null;
    protected BranchGroup plot3DRootBranch = null;
    protected BranchGroup plot3DRootBranch_node = null;
    protected TransformGroup plot3DTransform = null;
    protected BufferedImage image2D = null;
    
    /**
     * Constructs a contour plot with the specified axes (other attributes take
     * default values).
     *
     * @param dataset  The dataset.
     * @param domainAxis  The domain axis.
     * @param rangeAxis  The range axis.
     * @param colorBar  The z-axis axis.
    */
    
    //TODO: Class for Objects on Grid
    /*
     * Create Class for the columns with different shapes
     * Make an abstract class, then the special class like Cylinder, Box, etc...
     */
    
    //Class for objects on surface
    //TODO: Maybe create a file loader, which load shape coordinates, from .3ds file, etc...
  
    public abstract class Graphic_Object
    {
    	protected Point3f Coords = new Point3f();
    	protected GeometryInfo Graphic_array;
    	protected Color3f Color = new Color3f(0f, 1f, 0f);
    	Shape3D BoxShape;
    	
    	public Graphic_Object() {};
    	
    	public void Set_Coords(float _x, float _y, float _z)
    	{
    		Coords.x = _x;
    		Coords.y = _y;
    		Coords.z = _z;
    	}
    	
    	public void Set_Coords(Point3f coord)
    	{
    		Coords.x = coord.x;
    		Coords.y = coord.y;
    		Coords.z = coord.z;
    	}
    	
    	public Point3f Get_Coords()
    	{
    		return Coords;
    	}
    	
    	public GeometryInfo Get_Geometry()
    	{
    		return Graphic_array;
    	}
    	
    	public Shape3D Get_Shape()
    	{
    		return BoxShape;
    	}
    }
    
    class My_Sphere extends Graphic_Object
    {
    	@SuppressWarnings("unused")
		private int R;
    	
    	public My_Sphere(Point3f coord, int _R)
    	{
    		Coords.x = coord.x;
    		Coords.y = coord.y;
    		Coords.z = coord.z;
    		R = _R;
    	}
    	
    	public My_Sphere(float _x, float _y, float _z, int _R)
    	{
    		Coords.x = _x;
    		Coords.y = _y;
    		Coords.z = _z;
    		R = _R;
    	}
    }
    
    class My_Box extends Graphic_Object
    {
    	@SuppressWarnings("unused")
		private float x_width;
    	@SuppressWarnings("unused")
		private float y_height;
    	@SuppressWarnings("unused")
		private float z_length;
    	
    	public My_Box(Point3f _coord, Color3f top_colors, Color3f bottom_colors, float _x_width, float _y_height, float _z_length)
    	{
    		Coords.x = _coord.x;
    		Coords.y = _coord.y;
    		Coords.z = _coord.z;
    		x_width = _x_width;
    		y_height = _y_height;
    		z_length = _z_length;
    		
    		Appearance App = new Appearance();
        	Material Mat = new Material();
        	Mat.setAmbientColor(new Color3f(0.2f,0.2f,0.2f));
        	Mat.setDiffuseColor(new Color3f(0.3f,0.3f,0.3f));
        	Mat.setSpecularColor(new Color3f(0.2f,0.2f,0.2f));
    		App.setMaterial(Mat);
    		Graphic_array = new GeometryInfo(GeometryInfo.QUAD_ARRAY);
    		// eight points of the Box
    		Point3f[] CubeCoords_array = new Point3f[8];
    		Color3f[] colors_array = new Color3f[24];
    		
    		for (int i = 0; i < 8; i++)
    		{
    			CubeCoords_array[i] = new Point3f();
    		}
    		//bal-lent-elulso
    		CubeCoords_array[0].x = Coords.x - _x_width / 2;
    		CubeCoords_array[0].y = Coords.y - _y_height / 2;
    		CubeCoords_array[0].z = Coords.z + _z_length / 2;
    		
    		//jobb-lent-elulso
    		CubeCoords_array[1].x = Coords.x + _x_width / 2;
    		CubeCoords_array[1].y = Coords.y - _y_height / 2;
    		CubeCoords_array[1].z = Coords.z + _z_length / 2;
    		
    		//jobb-fent-elulso
    		CubeCoords_array[2].x = Coords.x + _x_width / 2;
    		CubeCoords_array[2].y = Coords.y + _y_height / 2;
    		CubeCoords_array[2].z = Coords.z + _z_length / 2;
    		
    		//bal-fent-elulso
    		CubeCoords_array[3].x = Coords.x - _x_width / 2;
    		CubeCoords_array[3].y = Coords.y + _y_height / 2;
    		CubeCoords_array[3].z = Coords.z + _z_length / 2;
    		
    		//bal-fent-hatso
    		CubeCoords_array[4].x = Coords.x - _x_width / 2;
    		CubeCoords_array[4].y = Coords.y + _y_height / 2;
    		CubeCoords_array[4].z = Coords.z - _z_length / 2;
    		
    		//jobb-fent-hatso
    		CubeCoords_array[5].x = Coords.x + _x_width / 2;
    		CubeCoords_array[5].y = Coords.y + _y_height / 2;
    		CubeCoords_array[5].z = Coords.z - _z_length / 2;
    		
    		//jobb-lent-hatso
    		CubeCoords_array[6].x = Coords.x + _x_width / 2;
    		CubeCoords_array[6].y = Coords.y - _y_height / 2;
    		CubeCoords_array[6].z = Coords.z - _z_length / 2;
    		
    		//bal-lent-hatso
    		CubeCoords_array[7].x = Coords.x - _x_width / 2;
    		CubeCoords_array[7].y = Coords.y - _y_height / 2;
    		CubeCoords_array[7].z = Coords.z - _z_length / 2;
    		
    		Point3f[] Coords_array = new Point3f[24];
    		//Front side
    		Coords_array[0] = CubeCoords_array[0];
    		Coords_array[1] = CubeCoords_array[1];
    		Coords_array[2] = CubeCoords_array[2];
    		Coords_array[3] = CubeCoords_array[3];
    		
    		//Rear side
    		Coords_array[4] = CubeCoords_array[6];
    		Coords_array[5] = CubeCoords_array[7];
    		Coords_array[6] = CubeCoords_array[4];
    		Coords_array[7] = CubeCoords_array[5];
    		
    		//Right side
    		Coords_array[8] = CubeCoords_array[1];
    		Coords_array[9] = CubeCoords_array[6];
    		Coords_array[10] = CubeCoords_array[5];
    		Coords_array[11] = CubeCoords_array[2];
    		
    		//Left side
    		Coords_array[12] = CubeCoords_array[7];
    		Coords_array[13] = CubeCoords_array[0];
    		Coords_array[14] = CubeCoords_array[3];
    		Coords_array[15] = CubeCoords_array[4];
    		
    		//Top side
    		Coords_array[16] = CubeCoords_array[5];
    		Coords_array[17] = CubeCoords_array[4];
    		Coords_array[18] = CubeCoords_array[3];
    		Coords_array[19] = CubeCoords_array[2];
    		
    		//Bottom side
    		Coords_array[20] = CubeCoords_array[7];
    		Coords_array[21] = CubeCoords_array[6];
    		Coords_array[22] = CubeCoords_array[1];
    		Coords_array[23] = CubeCoords_array[0];
    		
    		/*for (int i = 0; i < 2; i++)
    		{
    			colors_array[i] = Color;
    			colors_array[i + 4] = Color;
    		}
    		*/
    		for (int i = 0; i < colors_array.length - 8; i += 4)
    		{
    			colors_array[i] = bottom_colors;
    			colors_array[i + 1] = bottom_colors;
    			colors_array[i + 2] = top_colors;
    			colors_array[i + 3] = top_colors;
    		}
    		//Top side
    		colors_array[16] = top_colors;
    		colors_array[17] = top_colors;
    		colors_array[18] = top_colors;
    		colors_array[19] = top_colors;
    		
    		//Bottom side
    		colors_array[20] = bottom_colors;
    		colors_array[21] = bottom_colors;
    		colors_array[22] = bottom_colors;
    		colors_array[23] = bottom_colors;
    		
    		Graphic_array.setCoordinates(Coords_array);
    		Graphic_array.setColors(colors_array);
    		
    		Graphic_array.recomputeIndices();
    		
    		NormalGenerator ng = new NormalGenerator();
    		ng.generateNormals(Graphic_array);
    		Graphic_array.recomputeIndices();
    		
    		BoxShape = new Shape3D(Graphic_array.getGeometryArray());
    		BoxShape.setAppearance(App);
    	}
    }
    
    class My_Column extends Graphic_Object
    {
    	@SuppressWarnings("unused")
		private int height;
    	@SuppressWarnings("unused")
		private int width;
    	
    	public My_Column(Point3f coord, int _width, int _height)
    	{
    		Coords.x = coord.x;
    		Coords.y = coord.y;
    		Coords.z = coord.z;
    		width = _width;
    		height = _height;
    	}
    	
    	public My_Column(float _x, float _y, float _z, int _width, int _height)
    	{
    		Coords.x = _x;
    		Coords.y = _y;
    		Coords.z = _z;
    		width = _width;
    		height = _height;
    	}
    }
    
    //Class for Grid table
    public class Grid_table
    {
    	private Boolean Is_visible = true;
    	private Box GridTable;
    	private float Grid_length = 1f;	//ezt is lehet param�terezni ha akarjuk - grid alap magassaga
    	private TransformGroup GridTable_tr;
    	
    	public Grid_table(float height, float width, Appearance App)
    	{
    	    GridTable = new Box(width, Grid_length, height, App);
    	    
    	    Transform3D translate = new Transform3D();
        	translate.setTranslation(new Vector3f(0, -Grid_length, 0));
        	GridTable_tr = new TransformGroup(translate);
        	
        	GridTable_tr.addChild(GridTable);
    	}
    	
    	public TransformGroup Get_GridTable()
    	{
    		return GridTable_tr;
    	}
    	
    	public float Get_Grid_length()
    	{
    		return Grid_length;
    	}
    	
    	public void Set_Visible(Boolean visible)
    	{
    		Is_visible = visible;
    	}
    	
    	public Boolean Get_Visible()
    	{
    		return Is_visible;
    	}
    }
    
    //Abstract layer class
    public class Layer
    {
    	protected Transform3D Translate; //z_height-be eltranszformalas
    	protected TransformGroup Tr_group;
    	protected float z_height = 0; //milyen magasan van a layerem
    	protected float Radius = 0.8f;
    	protected float Padding = 0.0f;
    	protected Grid_table Grid;
    	protected Graphic_Object Colorbar;
    	protected Grid3DMetadata Meta;
    	protected Grid3DDataset data;
    	
    	protected void CreateMetas()
    	{
    		Appearance Label_App = new Appearance();
        	Material Label_Mat = new Material();
        	Label_Mat.setAmbientColor(new Color3f(0.5f,0.5f,0.0f));
        	Label_Mat.setDiffuseColor(new Color3f(0.1f,0.1f,0.1f));
        	Label_Mat.setSpecularColor(new Color3f(0.0f,0.0f,0.0f));
        	Label_App.setMaterial(Label_Mat);
        	
        	My_Text ColumnLabel = new My_Text(new Text3D(new Font3D(new Font("ARIAL", Font.BOLD, 2),
        	        new FontExtrusion()), Meta.getColumnLabel()), new Point3f(-(Radius + Padding)*data.getWidth()/4, -Grid.Get_Grid_length()*3.5f, (Radius + Padding)*data.getHeight()), 0f, Label_App);
            
        	My_Text RowLabel = new My_Text(new Text3D(new Font3D(new Font("ARIAL", Font.BOLD, 2),
        	        new FontExtrusion()), Meta.getRowLabel()), new Point3f(-(Radius + Padding)*data.getWidth(), -Grid.Get_Grid_length()*3.5f, -(Radius + Padding)*data.getHeight()/4), -(float)Math.PI/2, Label_App);
        	
        	Tr_group.addChild(ColumnLabel.Get_TransGr());
        	Tr_group.addChild(RowLabel.Get_TransGr());
        	
        	if (Meta.isColorBarVisible())
        	{
            	ColorBar_3D cb = new ColorBar_3D(Radius, Padding, data, Meta, 16, Label_App);
            	Tr_group.addChild(cb.getColorBar3Dtr());
        	}
        	
        	if (Meta.getShowBase())
        	{
        		Tr_group.addChild(Grid.Get_GridTable());
        	}	
        	
        	//Axis
        	
        	if (Meta.getAxisVisible())	//t�l speci�lisak az axisok nem tudom oszt�lyba rakni, �gy egyszer�bb 
        	{
        		float axisOverFlow = 5.f;

        		//y axis
            	Cylinder yAxis = new Cylinder(0.2f, (float)data.getMaximum(0) + axisOverFlow, Label_App);

            	My_Text maxValue = new My_Text(new Text3D(new Font3D(new Font("ARIAL", Font.BOLD, 2),
            	        new FontExtrusion()), String.valueOf((float)data.getMaximum(0))), new Point3f(0f, (float)data.getMaximum(0)/2 - axisOverFlow/2, 3f), (float)Math.PI/2, Label_App);
            	
            	Transform3D translate = new Transform3D();
            	translate.setTranslation(new Vector3f(-data.getWidth()*(Meta.getRadius() + Meta.getPadding()), (float)data.getMaximum(0)/2 + axisOverFlow/2, data.getHeight()*(Meta.getRadius() + Meta.getPadding())));
            	TransformGroup Trans_gr_y = new TransformGroup(translate);

            	Trans_gr_y.addChild(yAxis);
            	Trans_gr_y.addChild(maxValue.Get_TransGr());
            	
            	//x axis
            	Cylinder xAxis = new Cylinder(0.2f, (data.getWidth()*(Meta.getRadius() + Meta.getPadding()))*2 + axisOverFlow, Label_App);

            	maxValue = new My_Text(new Text3D(new Font3D(new Font("ARIAL", Font.BOLD, 2),
            	        new FontExtrusion()), String.valueOf((data.getWidth()*(Meta.getRadius() + Meta.getPadding())))), new Point3f(0f, -(data.getWidth()*(Meta.getRadius() + Meta.getPadding())) + axisOverFlow/2, 3f), (float)Math.PI/2, Label_App);            	
            	
            	translate = new Transform3D();
            	translate.setTranslation(new Vector3f(axisOverFlow/2, 0f, +data.getHeight()*(Meta.getRadius() + Meta.getPadding())));
            	
            	Transform3D rotate = new Transform3D();
            	rotate.rotZ(Math.PI/2);
            	translate.mul(rotate);
            	TransformGroup Trans_gr_x = new TransformGroup(translate);

            	Trans_gr_x.addChild(xAxis);
            	Trans_gr_x.addChild(maxValue.Get_TransGr());

            	//z axis
            	Cylinder zAxis = new Cylinder(0.2f, (data.getHeight()*(Meta.getRadius() + Meta.getPadding()))*2 + axisOverFlow, Label_App);
            	
            	maxValue = new My_Text(new Text3D(new Font3D(new Font("ARIAL", Font.BOLD, 2),
            	        new FontExtrusion()), String.valueOf((data.getHeight()*(Meta.getRadius() + Meta.getPadding())))), new Point3f(-3f, -(data.getHeight()*(Meta.getRadius() + Meta.getPadding())) + axisOverFlow/2, 0.f), (float)Math.PI, Label_App);            	
            	
            	translate = new Transform3D();
            	translate.setTranslation(new Vector3f(-data.getWidth()*(Meta.getRadius() + Meta.getPadding()), 0f, -axisOverFlow/2));
            	
            	rotate = new Transform3D();
            	rotate.rotX(Math.PI/2);
            	translate.mul(rotate);
            	TransformGroup Trans_gr_z = new TransformGroup(translate);

            	Trans_gr_z.addChild(zAxis);
            	Trans_gr_z.addChild(maxValue.Get_TransGr());

            	Tr_group.addChild(Trans_gr_x);
            	Tr_group.addChild(Trans_gr_y);
            	Tr_group.addChild(Trans_gr_z);
        	} 
    	}
    	
    	public Grid_table Get_Grid()
    	{
    		return Grid;
    	}
    	
    	public TransformGroup Get_TransformGroup()
    	{
    		return Tr_group;
    	}
    	
    	public Graphic_Object GetColorbar()
    	{
    		return Colorbar;
    	}
    }
    
    //Class for 3D Colorbar
    
    public class ColorBar_3D
    {
    	private Graphic_Object ColorBar3D;
    	private TransformGroup ColorBar3Dtr;
    	
    	public ColorBar_3D(float Radius, float Padding, Grid3DDataset data, Grid3DMetadata Meta, int patterNum, Appearance textApp)
    	{
           	My_Text ColorBar_MaxValue = new My_Text(new Text3D(new Font3D(new Font("ARIAL", Font.BOLD, 2),
        	        new FontExtrusion()), String.valueOf(Meta.getColorMap().getMinLevel())), new Point3f(0, 0f, -(Radius + Padding)*data.getHeight() - 8f), (float)Math.PI/2, textApp);
        	
        	My_Text ColorBar_MinValue = new My_Text(new Text3D(new Font3D(new Font("ARIAL", Font.BOLD, 2),
        	        new FontExtrusion()), String.valueOf((Meta.getColorMap().getMaxLevel()))), new Point3f(0, 16f, -(Radius + Padding)*data.getHeight() - 8f), (float)Math.PI/2, textApp);

    		ColorBar3Dtr = new TransformGroup();
    		//patterNum mintav�tel az eredeti colorbar sz�neib�l
    		for (int i = patterNum; i > 1; i--)
    		{
    			ColorBar3D = new My_Box(new Point3f(0f, i*(16/patterNum), -(Radius + Padding)*data.getHeight() - 5f), new Color3f(Meta.getColorMap().getColor(Meta.getColorMap().getMaxLevel()*i/patterNum)), new Color3f(Meta.getColorMap().getColor(Meta.getColorMap().getMaxLevel()*(i-1)/patterNum)), 2f, 16/patterNum, 2f);
    			ColorBar3Dtr.addChild(ColorBar3D.Get_Shape());
    		}
    		
    		ColorBar3Dtr.addChild(ColorBar_MaxValue.Get_TransGr());
    		ColorBar3Dtr.addChild(ColorBar_MinValue.Get_TransGr());
    	}
    	
    	public TransformGroup getColorBar3Dtr()
    	{
    		return ColorBar3Dtr;
    	}
    }
    
    //Class for surface_layer
    
    public class Surface_layer extends Layer
    {
        private GeometryInfo Surface_Array = new GeometryInfo(GeometryInfo.TRIANGLE_STRIP_ARRAY);
        private int N;	//count of the points, that to be interpolated
        private Point3f coords[];	//Surface points
        private int[] stripCounts; //part of the surfaces
        private Color3f colors[];	//Surface colors
        private Shape3D Surface_shape;
        private Appearance Surface_app;
    	
    	public Surface_layer(Grid3DDataset _data, float _z_height, float _Radius, float _Padding, boolean _show_base, Appearance App, Appearance Grid_app, Grid3DMetadata _Meta) throws VisualisationException
    	{	
    		Surface_app = App;
    		Meta = _Meta;
    		data = _data;
    		Padding = _Padding;
    		Radius = _Radius;
    		
    		N = data.getHeight()*data.getWidth()*2 - data.getHeight()*2;
    		coords = new Point3f[N];
    		stripCounts = new int[data.getWidth() - 1];
    		for (int i = 0; i < data.getWidth() - 1; i++)
    		{
    			stripCounts[i] = data.getHeight()*2;
    		}
    		
    		colors = new Color3f[N];
    		
    		z_height = _z_height;
    		Grid = new Grid_table((Radius + Padding)*data.getHeight(), (Radius + Padding)*data.getWidth(), Grid_app);

    		int s_val = 0;
    		
        	for (int i = 0; i < data.getWidth(); i++)
        	{
        		for (int j = 0; j < data.getHeight(); j++)
        		{
        			if ( i < data.getWidth() - 1)
        			{
            			if (data.getValue(i, j, 0) == -Double.MAX_VALUE || data.getValue(i, j, 1) == -Double.MAX_VALUE)
            			{
            				coords[s_val] = new Point3f(-data.getWidth()*(Radius + Padding) + (Radius + Padding) + i*2.0f*(Radius + Padding), 0.5f, data.getHeight()*(Radius + Padding) - ((Radius + Padding) +j*2.0f*(Radius + Padding)));
            				colors[s_val] = new Color3f(Color.black);
            			}
            			else
            			{
            				coords[s_val] = new Point3f(-data.getWidth()*(Radius + Padding) + (Radius + Padding) + i*2.0f*(Radius + Padding), (float)data.getValue(i, j, 0), data.getHeight()*(Radius + Padding) - ((Radius + Padding) +j*2.0f*(Radius + Padding)));
            				colors[s_val] = new Color3f(Meta.getColorMap().getColor(data.getValue(i, j, 1)));
            			}
            			
            			if (data.getValue(i + 1, j, 0) == -Double.MAX_VALUE || data.getValue(i + 1, j, 1) == -Double.MAX_VALUE)
            			{
            				coords[s_val + 1] = new Point3f(-data.getWidth()*(Radius + Padding) + (Radius + Padding) + (i + 1)*2.0f*(Radius + Padding), 0.5f, data.getHeight()*(Radius + Padding) - ((Radius + Padding)+j*2.0f*(Radius + Padding)));
            				colors[s_val + 1] = new Color3f(Color.black);
            			}
            			else
            			{
            				coords[s_val + 1] = new Point3f(-data.getWidth()*(Radius + Padding) + (Radius + Padding) + (i + 1)*2.0f*(Radius + Padding), (float)data.getValue((i + 1), j, 0), data.getHeight()*(Radius + Padding) - ((Radius + Padding)+j*2.0f*(Radius + Padding)));
            				colors[s_val + 1] = new Color3f(Meta.getColorMap().getColor(data.getValue(i + 1, j, 1)));
            			}

        				s_val += 2;
        			}
        		}
        	}
        	
    		Surface_Array.setCoordinates(coords);
    		Surface_Array.setStripCounts(stripCounts);
    		Surface_Array.setColors(colors);
    		

    		Surface_Array.recomputeIndices();

        	
        	//Generate normals
        	NormalGenerator ng = new NormalGenerator();
        	ng.setCreaseAngle(Math.PI/2);	//performance-t lehet lenyomja, mivel ez teljes Smooth Shading, ha PI-vel sz�molok
            ng.generateNormals(Surface_Array);
            Surface_Array.recomputeIndices();
            
            Surface_shape = new Shape3D(Surface_Array.getGeometryArray());
            PolygonAttributes Surface_pa = new PolygonAttributes();
            Surface_pa.setCullFace(PolygonAttributes.CULL_NONE);
    		
            Surface_app.setPolygonAttributes(Surface_pa);
        	Surface_shape.setAppearance(Surface_app);
        	
        	Translate = new Transform3D();
        	Translate.setTranslation(new Vector3f(0, z_height, 0));
        	
        	Tr_group = new TransformGroup(Translate);
        	
        	Tr_group.addChild(Surface_shape);
        	
        	CreateMetas();
    	}
    	
    	public void SetCoord(int index, Point3f val)
    	{
    		coords[index] = val;
    	}

    	public void SetColor(int index, Color3f val)
    	{
    		colors[index] = val;
    	}
    	
    	public GeometryInfo Get_GeometryInfo()
    	{
    		return Surface_Array;
    	}
    	
    	public Shape3D Get_Surf_shape()
    	{
    		return Surface_shape;
    	}
    	
    	public void setCoords_StripCounts_Colors()
    	{
    		Surface_Array.setCoordinates(coords);
    		Surface_Array.setStripCounts(stripCounts);
    		Surface_Array.setColors(colors);
    		
    		Surface_Array.recomputeIndices();
        	
        	//Generate normals
        	NormalGenerator ng = new NormalGenerator();
        	ng.setCreaseAngle(Math.PI);	//performance-t lehet lenyomja, mivel ez teljes Smooth Shading, ha PI-vel sz�molok
            ng.generateNormals(Surface_Array);
            Surface_Array.recomputeIndices();
    	}
    }
    
    //Class for diagram_layer
    
    class Diagramm_layer extends Layer
    {
    	public Diagramm_layer(Grid3DDataset _data, float _z_height, float _Radius, float _Padding, boolean _show_base, Appearance Grid_app, Grid3DMetadata _Meta)
    	{
    		z_height = _z_height;
    		data = _data;
    		Meta = _Meta;
        	Translate = new Transform3D();
        	Translate.setTranslation(new Vector3f(0, z_height, 0));
        	Tr_group = new TransformGroup(Translate);
        	Radius = _Radius;
        	Padding = _Padding;
        	
    		Grid = new Grid_table((Radius + Padding)*data.getHeight(), (Radius + Padding)*data.getWidth(), Grid_app);
        	
    		for (int i = 0; i < data.getWidth(); i++)
        	{
        		for (int j = 0; j < data.getHeight(); j++)
        		{
        			if (data.getValue(i, j, 0) == -Double.MAX_VALUE || data.getValue(i, j, 1) == -Double.MAX_VALUE || data.getValue(i, j, 2) == -Double.MAX_VALUE)
        				continue;
        			//Create Columns
        			Appearance Column_app = new Appearance();
        			
        	    	Material Column_mat_R = new Material();

        			Color3f actColor = new Color3f(Meta.getColorMap().getColor(data.getValue(i, j, 1)));
        			
        	    	Column_mat_R.setAmbientColor(actColor);
        	    	Column_mat_R.setDiffuseColor(new Color3f(0.3f, 0.3f, 0.3f));
        	    	Column_mat_R.setSpecularColor(new Color3f(0.3f, 0.3f, 0.3f));

        			Column_app.setMaterial(Column_mat_R);
        			
        			if (data.getValue(i, j, 2) == 1)	//Cylinder
        			{
        				Tr_group.addChild(Trans_Column(CreateColumn_Cyl(Radius, (float)data.getValue(i, j, 0), Column_app), -data.getWidth()*(Radius + Padding)+ (Radius + Padding) + i*2.0f*(Radius + Padding),(float)data.getValue(i, j, 0)/2, data.getHeight()*(Radius + Padding) - ((Radius + Padding) +j*2.0f*(Radius + Padding))));
        			}
        			else if (data.getValue(i, j, 2) > 1)	//Box
        			{
        				Tr_group.addChild(Trans_Column(CreateColumn_Box(Radius, (float)data.getValue(i, j, 0), Column_app), -data.getWidth()*(Radius + Padding) + (Radius + Padding) + i*2.0f*(Radius + Padding),(float)data.getValue(i, j, 0)/2, data.getHeight()*(Radius + Padding) - ((Radius + Padding) +j*2.0f*(Radius + Padding))));
        			}
        			else
        			{
        				Tr_group.addChild(Trans_Column(CreateColumn_Cyl(Radius, 1, Column_app), -data.getWidth()*(Radius + Padding)+ (Radius + Padding) + i*2.0f*(Radius + Padding),0.5f, data.getHeight()*(Radius + Padding) - ((Radius + Padding) +j*2.0f*(Radius + Padding))));
        			}
        		}
        	}
    		
    		CreateMetas();
    	}
    	
        private Cylinder CreateColumn_Cyl(float Radius, float Height, Appearance App)
        {	
        	Cylinder Column = new Cylinder(Radius, Height, App);
        	return Column;
        }
        
        private Box CreateColumn_Box(float Radius, float Height, Appearance App)
        {
        	Box Column = new Box(Radius, Height/2, Radius, App);
        	return Column;
        }
        
        //Cylindert megadva parameterben visszaad egy transformgroupot, aminek a gyereke lesz a cylinder
        //�s a megadott 3 koordin�t�ba el lesz tolva
        private TransformGroup Trans_Column(Primitive C, float To_x, float To_y, float To_z)
        {
        	Transform3D translate = new Transform3D();
        	translate.setTranslation(new Vector3f(To_x, To_y, To_z));
        	TransformGroup Trans_gr = new TransformGroup(translate);
        	
        	Trans_gr.addChild(C);
        	
        	return Trans_gr;
        }
    }
    
    //Class for object_layer
    
    public class Object_layer extends Layer
    {
    	public Object_layer(Grid3DDataset _data, float _z_height, float _Radius, float _Padding, boolean _show_base, Appearance Grid_app, Grid3DMetadata _Meta)
    	{
    		data = _data;
    		Meta = _Meta;
    		Radius = _Radius;
    		Padding = _Padding;
    		z_height = _z_height;
    		Grid = new Grid_table((Radius + Padding)*data.getHeight(), (Radius + Padding)*data.getWidth(), Grid_app);
    		
    		Translate = new Transform3D();
        	Translate.setTranslation(new Vector3f(0, z_height, 0));
        	Tr_group = new TransformGroup(Translate);
    		
    		for (int i = 0; i < data.getWidth(); i++)
        	{
        		for (int j = 0; j < data.getHeight(); j++)
        		{
        			if (data.getValue(i, j, 0) == -Double.MAX_VALUE || data.getValue(i, j, 1) == -Double.MAX_VALUE || data.getValue(i, j, 2) == -Double.MAX_VALUE || data.getValue(i, j, 3) == -Double.MAX_VALUE)
        				continue;
        			
        			Appearance Obj_app = new Appearance();
        			
        	    	Material Obj_mat_R = new Material();

        			Color3f actColor = new Color3f(Meta.getColorMap().getColor(data.getValue(i, j, 1)));
        			
        	    	Obj_mat_R.setAmbientColor(actColor);
        	    	Obj_mat_R.setDiffuseColor(new Color3f(0.3f, 0.3f, 0.3f));
        	    	Obj_mat_R.setSpecularColor(new Color3f(0.3f, 0.3f, 0.3f));

        			Obj_app.setMaterial(Obj_mat_R);
        			Obj_on_Surf tmp_sph;
        			
        			if (data.getValue(i, j, 2) == 1)
        			{
        				tmp_sph = new Obj_Sphere(Radius + (float)data.getValue(i, j, 3)/2, Obj_app, new Point3f(-data.getWidth()*(Radius + Padding) + (Radius + Padding) + (Radius + Padding)*2*i,(float)data.getValue(i, j, 0), data.getHeight()*(Radius + Padding) - ((Radius + Padding) + j*2*(Radius + Padding))));
        			}
        			else if (data.getValue(i, j, 2) == 2)
        			{
        				tmp_sph = new Obj_Box(Radius + (float)data.getValue(i, j, 3)/2, Obj_app, new Point3f(-data.getWidth()*(Radius + Padding) + (Radius + Padding) + (Radius + Padding)*2*i,(float)data.getValue(i, j, 0), data.getHeight()*(Radius + Padding) - ((Radius + Padding) + j*2*(Radius + Padding))));
        			}
        			else
        			{
        				tmp_sph = new Obj_Sphere(Radius + (float)data.getValue(i, j, 3)/2, Obj_app, new Point3f(-data.getWidth()*(Radius + Padding) + (Radius + Padding) + (Radius + Padding)*2*i,(float)data.getValue(i, j, 0), data.getHeight()*(Radius + Padding) - ((Radius + Padding) + j*2*(Radius + Padding))));
        			}
        			
        			Tr_group.addChild(tmp_sph.Get_TransformGroup());
        		}
        	}
    		
    		CreateMetas();
    	}
    }
    
    public abstract class Obj_on_Surf
    {
    	protected Point3f coords = new Point3f();
    	protected TransformGroup tg;

    	public TransformGroup Get_TransformGroup()
    	{
    		return tg;
    	}
    }
    
    public class Obj_Box extends Obj_on_Surf
    {
    	private Box box;
    	
    	public Obj_Box(float Radius, Appearance app, Point3f _coords)
    	{
    		box = new Box(Radius, Radius, Radius, app);
    		box.setAppearance(app);
        	Transform3D translate = new Transform3D();
        	translate.setTranslation(new Vector3f(_coords.x, _coords.y, _coords.z));
        	
        	coords.x = _coords.x;
        	coords.y = _coords.y;
        	coords.z = _coords.z;
        	
        	tg = new TransformGroup(translate);

        	tg.addChild(box);
    	}
    }
    
    public class Obj_Sphere extends Obj_on_Surf
    {
    	private Sphere sph;
    	
    	public Obj_Sphere(float Radius, Appearance app, Point3f _coords)
    	{
    		sph = new Sphere(Radius, app);
    		sph.setAppearance(app);
        	Transform3D translate = new Transform3D();
        	translate.setTranslation(new Vector3f(_coords.x, _coords.y, _coords.z));
        	
        	coords.x = _coords.x;
        	coords.y = _coords.y;
        	coords.z = _coords.z;
        	
        	tg = new TransformGroup(translate);

        	tg.addChild(sph);
    	}
    }
    
    public class My_Text
    {
    	Shape3D TextShape;
    	Text3D Text;
    	TransformGroup Trans_gr;
    	
    	public My_Text(Text3D MyText, Appearance App)
    	{
    		MyText.setAlignment(Text3D.ALIGN_CENTER);
        	Shape3D textShape = new Shape3D();
        	textShape.setAppearance(App);
        	textShape.setGeometry(MyText);
        	
        	this.TextShape = textShape;
        	
        	Trans_gr = new TransformGroup();
        	
        	Trans_gr.addChild(this.TextShape);
    	}
    	
    	public My_Text(Text3D MyText, Point3f Point, float Rotate, Appearance App)
    	{
    		MyText.setAlignment(Text3D.ALIGN_CENTER);
        	Shape3D textShape = new Shape3D();
        	textShape.setAppearance(App);
        	textShape.setGeometry(MyText);
        	
        	this.TextShape = textShape;
        	
        	Transform3D translate = new Transform3D();
        	translate.setTranslation(new Vector3f(Point.x, Point.y, Point.z));
        	
        	Transform3D rotate = new Transform3D();
        	rotate.rotY(Rotate);
        	
        	translate.mul(rotate);
        	
        	Trans_gr = new TransformGroup(translate);
        	
        	Trans_gr.addChild(this.TextShape);
    	}
    	
    	public void SetCoords(Point3f Point, float Rotate)
    	{
    		Transform3D translate = new Transform3D();
        	translate.setTranslation(new Vector3f(Point.x, Point.y, Point.z));
        	
        	Transform3D rotate = new Transform3D();
        	rotate.rotY(Rotate);
        	
        	translate.mul(rotate);
        	
        	Trans_gr = new TransformGroup(translate);
    	}
        
    	public TransformGroup Get_TransGr() {return Trans_gr;}
    }
    
    //Class for move up and move down with keypress
    public class TranslateBehavior extends Behavior
    {
     private WakeupOnAWTEvent   wakeupOne = null;
     private WakeupCriterion[]  wakeupArray = new WakeupCriterion[1];
     private WakeupCondition    wakeupCondition = null;
     
     private final float        TRANSLATE_UP = -5f;
     private final float        TRANSLATE_DOWN = +5f;
     
     TransformGroup             m_TransformGroup = null;
     
     public TranslateBehavior( TransformGroup tg )
     {
      m_TransformGroup = tg;
      
      wakeupOne = new WakeupOnAWTEvent(KeyEvent.KEY_PRESSED);
      wakeupArray[0] = wakeupOne;
      wakeupCondition = new WakeupOr(wakeupArray);
     }
     
     //Override Behavior's initialize method to set up wakeup criteria
     public void initialize()
     {
      //Establish initial wakeup criteria
      wakeupOn(wakeupCondition);
     }
     
     //Override Behavior's stimulus method to handle the event.
     public void processStimulus(Enumeration criteria)
     {
      WakeupOnAWTEvent ev;
      WakeupCriterion genericEvt;
      AWTEvent[] events;
      
      while (criteria.hasMoreElements())
      {
       genericEvt = (WakeupCriterion) criteria.nextElement();
       
       if (genericEvt instanceof WakeupOnAWTEvent)
       {
        ev = (WakeupOnAWTEvent) genericEvt;
        events = ev.getAWTEvent();
        processAWTEvent(events);
       }
      }
      
      //Set wakeup criteria for next time
      wakeupOn(wakeupCondition);
     }
     
     //Process a keyboard event
     private void processAWTEvent(AWTEvent[] events)
     {
      for( int n = 0; n < events.length; n++)
      {
       if( events[n] instanceof KeyEvent)
       {
        KeyEvent eventKey = (KeyEvent) events[n];
        
        if( eventKey.getID() == KeyEvent.KEY_PRESSED )
        {
         int keyCode = eventKey.getKeyCode();
        // int keyChar = eventKey.getKeyChar();
         
         Vector3f translate = new Vector3f();
         
         Transform3D t3d = new Transform3D();
         m_TransformGroup.getTransform( t3d );
         t3d.get( translate );
         
         switch (keyCode)
         {
          case KeyEvent.VK_UP:
           translate.y += TRANSLATE_UP;
          break;
          
          case KeyEvent.VK_DOWN:
           translate.y += TRANSLATE_DOWN;
          break;
         }
         
         t3d.setTranslation( translate );
         m_TransformGroup.setTransform( t3d );
        }
       }
      }
     }
    }
    
    public void datasetChanged(DatasetChangeEvent event)
    {
    	//csak �jrarajzolni, mivel producer setvalues-ot m�r h�vta
    	//Grid2D-t megn�zni
		//double[][][] values = this.dataset[0].getValues();
		//double min = Double.MAX_VALUE;
		//double max = - Double.MAX_VALUE;
/*		for (int i=0;i<this.dataset[0].getWidth();++i) {
			for (int j=0;j<this.dataset[0].getHeight();++j) {
				if (values[i][j][] != - Double.MAX_VALUE && values[i][j] < min) min = values[i][j];
				if (values[i][j] > max) max = values[i][j];
			}
		}*/
    	Grid3DDataset[] data = getDataset();
    	try {
    		plot3DRootBranch_node.detach();
			plot3DRootBranch_node = createGrid3D(Metas, data );
        	plot3DRootBranch_node.setCapability(BranchGroup.ALLOW_DETACH);
        	plot3DRootBranch_node.compile();
        	
        	//musz�j detach-olni,mert addig nem tudok hozz�adni gyereket neki sem, de a lesz�rmazottjainak sem, aki most a plot3DTransform
			plot3DRootBranch.detach();
			plot3DTransform.addChild(plot3DRootBranch_node);
			
         	plot3DRootBranch_node.compile();
         	
         	plot3DUniverse.addBranchGraph(plot3DRootBranch);

         	try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (VisualisationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
		//super.datasetChanged(event);
    }
    
    public Grid3DPlot(Grid3DDataset[] dataset, Grid3DMetadata[] metaDatas) {

		super();
		
		this.dataset = dataset;
		if (dataset != null) {
			for (int i = 0; i < dataset.length; i++)
			{
				dataset[i].addChangeListener(this);
			}
		}
		
		this.Metas = new Grid3DMetadata[metaDatas.length];
		
		for (int i = 0; i < metaDatas.length; i++)
		{
			this.Metas[i] = new Grid3DMetadata();
			this.Metas[i] = metaDatas[i];
		}
	}
    
    public void draw(Graphics2D g2, Rectangle2D area, Point2D anchor,
            PlotState parentState,
            PlotRenderingInfo info) {
    	
    }
    
    public void draw(/*Combined*/Canvas3D cc3, Rectangle2D area, Point2D anchor,
            PlotState parentState,
            PlotRenderingInfo info) throws VisualisationException{
    	
    	//initialise plot3DUniverse, plot3DRootBranch
    	plot3DUniverse = new SimpleUniverse(cc3);
    	plot3DUniverse.getViewingPlatform().setNominalViewingTransform();
    	plot3DUniverse.getViewer().getView().setBackClipDistance(10000);
    	//plot3DUniverse.getViewer().getView().setMinimumFrameCycleTime(50);
   
       	Grid3DDataset[] data = getDataset();
    	if( data != null ){
        	plot3DRootBranch = new BranchGroup();
        	plot3DRootBranch.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
         	plot3DRootBranch.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
         	plot3DRootBranch.setCapability(BranchGroup.ALLOW_DETACH);
         	
         	Transform3D rotate = new Transform3D();
         	rotate.rotX(Math.PI/6);
         	Transform3D translate = new Transform3D();
         	translate.setTranslation(new Vector3f(0.f, 0.f, -250.f));
         	translate.mul(rotate);
         	
         	plot3DTransform = new TransformGroup(translate);
         	plot3DTransform.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
         	plot3DTransform.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
         	plot3DTransform.setCapability(TransformGroup.ALLOW_CHILDREN_READ);
         	plot3DTransform.setCapability(TransformGroup.ALLOW_CHILDREN_WRITE);
         	
        	plot3DRootBranch_node = createGrid3D(Metas, data );
        	plot3DRootBranch_node.setCapability(BranchGroup.ALLOW_DETACH);
        	plot3DRootBranch_node.compile();
         	//TODO:trans_back-et meg mouse rotate meg ezeket ide kirakni a branch el�!
         	//plot3DRootBranch_node.compile();
            
        	plot3DRootBranch.addChild(plot3DTransform);
    		plot3DTransform.addChild(plot3DRootBranch_node);
    		plot3DUniverse.addBranchGraph(plot3DRootBranch);
    		plot3DUniverse.addBranchGraph(createLightsandTitleandMouseInteract(plot3DTransform));
    	}
    }
    

    /** creates the 3D model of the plot 
     * @throws VisualisationException **/
    public BranchGroup createGrid3D(Grid3DMetadata[] metas, Grid3DDataset[] data) throws VisualisationException{    	
    	// Create the root of the branch graph
    	BranchGroup objRoot = new BranchGroup();
    	BoundingSphere boundsph = new BoundingSphere(new Point3d(0.0,0.0,0.0),500.0);	    	
    	
        // Then create a directional light with the given
        // direction and color
        DirectionalLight lightD = new DirectionalLight();//(new Color3f(1f, 1f, 0f), new Vector3f(0f, -1f, 0f));
        lightD.setInfluencingBounds(boundsph);
        
        AmbientLight lightA = null;
		lightA = new AmbientLight( );
		lightA.setColor( new Color3f(0.7f, 0.7f, 0.7f) );
		lightA.setInfluencingBounds( boundsph );
    	
    	// Set the background
		if (metas[0].getBackgroundFile() != null)
		{
			TextureLoader myLoader = new TextureLoader( metas[0].getBackgroundFile(), null );
			ImageComponent2D myImage = myLoader.getScaledImage(640, 480);
		
			Background backg = new Background(0f, 0.75f, 0.8f);
			backg.setImage(myImage);
			backg.setCapability(Background.ALLOW_COLOR_READ);
			backg.setCapability(Background.ALLOW_COLOR_WRITE);
			backg.setApplicationBounds(boundsph);
			
	    	objRoot.addChild(backg);
		}
    	
    	// Translate objects for better view
    	/*Transform3D translate = new Transform3D();
    	translate.set(new Vector3f(0.0f, -10f, -45.f));
    	//TransformGroup Trans_back = new TransformGroup();
    	
    	TransformGroup objSpin = new TransformGroup(translate);
    	objSpin.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
    	objSpin.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
    	
    	TranslateBehavior transBehav = new TranslateBehavior(objSpin);
    	transBehav.setSchedulingBounds(boundsph);
    	objRoot.addChild(transBehav);*/
    	
    	//Mouse interaction for rotate and zoom
    	
        /*MouseRotate myMouseRotate = new MouseRotate();
        myMouseRotate.setTransformGroup(objSpin);
        myMouseRotate.setSchedulingBounds(boundsph);
        
        MouseWheelZoom wheelZoom = new MouseWheelZoom();
        wheelZoom.setFactor(5);
        wheelZoom.setTransformGroup(objSpin);
        wheelZoom.setSchedulingBounds(boundsph);*/
    	
        // Create GridTable appearance
    	Appearance GridTable_app = new Appearance();
    	
    	Material Grid_mat = new Material();
    	Grid_mat.setAmbientColor(new Color3f(0.0f,0.0f,0.7f));
    	Grid_mat.setDiffuseColor(new Color3f(0.3f,0.3f,0.3f));
    	Grid_mat.setSpecularColor(new Color3f(0.3f,0.3f,0.3f));
    	//Grid_mat.setShininess(1.0f);
    	GridTable_app.setMaterial(Grid_mat);

    	// Create Drawing Tree

    	//objRoot.addChild(Trans_back);
    	
    	//objRoot.addChild(objSpin);
    	//Trans_back.addChild(keyNavBeh);
    	//objRoot.addChild(wheelZoom);
    	//objRoot.addChild(myMouseRotate);
    	//Trans_back.addChild(myMouseRotate);
    	//Trans_back.addChild(wheelZoom);
    	
    	//objRoot.addChild(lightA);	//ambient light
    	//objRoot.addChild(lightD);	//directional light
    	
    	//------------ Create Objects in this scene --------------
        
        Appearance Surface_app = new Appearance();
        
        Surface_app.setMaterial(new Material());     
        
        //Here create the layers
        
        Layer[] layers = new Layer[data.length];
        
        for (int i = 0; i < data.length; i++)
        {
        	if (data[i] instanceof DefaultGrid3DDataset_DiagramLayer || data[i] instanceof ScalarMapGrid3DDataset_DiagramLayer)
        	{
        		layers[i] = new Diagramm_layer(data[i], Metas[i + 1].getTranslate(), Metas[i + 1].getRadius(), Metas[i + 1].getPadding(), Metas[i + 1].getShowBase(), GridTable_app, Metas[i + 1]);
        	}
        	else if (data[i] instanceof DefaultGrid3DDataset_ObjLayer || data[i] instanceof ScalarMapGrid3DDataset_ObjLayer)
        	{
        		layers[i] = new Object_layer(data[i], Metas[i + 1].getTranslate(), Metas[i + 1].getRadius(), Metas[i + 1].getPadding(), Metas[i + 1].getShowBase(), GridTable_app, Metas[i + 1]);
        	}
        	else if (data[i] instanceof DefaultGrid3DDataset_SurfaceLayer || data[i] instanceof ScalarMapGrid3DDataset_SurfaceLayer)
        	{
        		layers[i] = new Surface_layer(data[i], Metas[i + 1].getTranslate(), Metas[i + 1].getRadius(), Metas[i + 1].getPadding(), Metas[i + 1].getShowBase(), Surface_app, GridTable_app, Metas[i + 1]);
        	}
        	
        	objRoot.addChild(layers[i].Get_TransformGroup());
        }
    	
    	// Let Java 3D perform optimizations on this scene graph.
        //objRoot.compile();

    	return objRoot;
    }
    
    public BranchGroup createLightsandTitleandMouseInteract(TransformGroup objSpin) throws VisualisationException{    	
    	// Create the root of the branch graph
    	BranchGroup objRoot = new BranchGroup();
    	BoundingSphere boundsph = new BoundingSphere(new Point3d(0.0,0.0,0.0),500.0);	    	
    	
        // Create GridTable appearance
    	Appearance GridTable_app = new Appearance();
    	
    	Material Grid_mat = new Material();
    	Grid_mat.setAmbientColor(new Color3f(0.0f,0.0f,0.7f));
    	Grid_mat.setDiffuseColor(new Color3f(0.3f,0.3f,0.3f));
    	Grid_mat.setSpecularColor(new Color3f(0.3f,0.3f,0.3f));
    	//Grid_mat.setShininess(1.0f);
    	GridTable_app.setMaterial(Grid_mat);
    	
        //Main Title
        My_Text Title = new My_Text(new Text3D(new Font3D(new Font("ARIAL", Font.PLAIN, 8),
    	        new FontExtrusion()), Metas[0].getTitle()), new Point3f(-25f, 33f, -50f), 0f, GridTable_app);
        
        objRoot.addChild(Title.Get_TransGr());
        
        // Then create a directional light with the given
        // direction and color
        DirectionalLight lightD = new DirectionalLight();//(new Color3f(1f, 1f, 0f), new Vector3f(0f, -1f, 0f));
        lightD.setInfluencingBounds(boundsph);
        
        AmbientLight lightA = null;
		lightA = new AmbientLight( );
		lightA.setColor( new Color3f(0.7f, 0.7f, 0.7f) );
		lightA.setInfluencingBounds( boundsph );
    	
    	TranslateBehavior transBehav = new TranslateBehavior(objSpin);
    	transBehav.setSchedulingBounds(boundsph);
    	objRoot.addChild(transBehav);
    	
    	//Mouse interaction for rotate and zoom
    	
        MouseRotate myMouseRotate = new MouseRotate();
        myMouseRotate.setTransformGroup(objSpin);
        myMouseRotate.setSchedulingBounds(boundsph);
        
        MouseWheelZoom wheelZoom = new MouseWheelZoom();
        wheelZoom.setFactor(5);
        wheelZoom.setTransformGroup(objSpin);
        wheelZoom.setSchedulingBounds(boundsph);
    	
       
    	// Create Drawing Tree
    	
    	objRoot.addChild(wheelZoom);
    	objRoot.addChild(myMouseRotate);
    	
    	objRoot.addChild(lightA);	//ambient light
    	objRoot.addChild(lightD);	//directional light
    	
    	// Let Java 3D perform optimizations on this scene graph.
        //objRoot.compile();

    	return objRoot;
    }
    

    
    public Grid3DDataset[] getDataset() {
        return this.dataset;
    }
    
	public void selectEntity(ChartEntity entity) {
//		if (entity instanceof Grid2DEntity) {
//			
//			Grid2DEntity e = (Grid2DEntity) entity;
//			
//			selectionModel.addObject(new Grid2DItem(e.getX(), e.getY()));
//		}		
	}

	@Override
	public String getPlotType() {
		// TODO Auto-generated method stub
		return null;
	}


	
    /**
     * Sets the color bar location and sends a {@link PlotChangeEvent} to all 
     * registered listeners.
     * 
     * @param edge  the location.
     */
    public void setColorBarLocation(RectangleEdge edge) {
        this.colorBarLocation = edge;
        notifyListeners(new PlotChangeEvent(this));    
    }
    
    public void setColorBar(ColorBar colorBar) { 
    	this.colorBar = colorBar;
    	notifyListeners(new PlotChangeEvent(this));    	   
    }  
    
    public ColorBar getColorBar() {
        return this.colorBar;
    }

	public ValueAxis getDomainAxis() {
        ValueAxis result = this.domainAxis;

        return result;
	}

	public ValueAxis getRangeAxis() {
        ValueAxis result = this.rangeAxis;

        return result;
	}

	public void propertyChange(PropertyChangeEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
