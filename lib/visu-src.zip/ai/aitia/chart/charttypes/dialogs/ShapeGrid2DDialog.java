/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.IShapeRendererUser;
import ai.aitia.chart.charttypes.dialogs.components.ShapeRendererPanel;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.ds.IGrid2DDatasetProducer;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;

/** GUI component of two-dimensional grids with shapes. */
public class ShapeGrid2DDialog extends AbstractChartDialog implements IShapeRendererUser {

	private static final long serialVersionUID = 1L;

	private ButtonGroup orderButtonGroup = null;
	private JTabbedPane tabbed = null;
	private JPanel mainPanel = null;
	private JPanel fullPanel = null;
	private JPanel firstPanel = null;
	private JPanel valuesPanel = null;
	private JComboBox valuesParam = null;
	private JButton advancedButton = null;
	private JPanel fSwitchPanel = null;
	private JButton fSwitchButton = null;
	private JPanel fDimensionPanel = null;
	private JLabel jLabel = null;
	private JTextField fWidthField = null;
	private JLabel jLabel1 = null;
	private JTextField fHeightField = null;
	private JPanel orderPanel = null;
	private JLabel jLabel2 = null;
	private JPanel orderButtonPanel = null;
	private JRadioButton rowRadioButton = null;
	private JRadioButton columnRadioButton = null;
	private JPanel partialPanel = null;
	private JPanel reqPanel = null;
	private JPanel xPanel = null;
	private JComboBox xParam = null;
	private JButton xAdvancedButton = null;
	private JPanel pSwitchPanel = null;
	private JButton pSwitchButton = null;
	private JPanel yPanel = null;
	private JComboBox yParam = null;
	private JButton yAdvancedButton = null;
	private JPanel shapePanel = null;
	private JComboBox shapeParam = null;
	private JButton shapeAdvancedButton = null;
	private JPanel optPanel = null;
	private JLabel jLabel3 = null;
	private JTextField pWidthField = null;
	private JLabel jLabel4 = null;
	private JTextField pHeightField = null;
	private JPanel detailsPanel = null;
	private JPanel titleLine = null;
	private JLabel jLabel5 = null;
	private JPanel subtitleLine = null;
	private JLabel jLabel6 = null;
	private JTextField subtitleField = null;
	private JPanel rowLabelLine = null;
	private JLabel jLabel7 = null;
	private JTextField rowLabelField = null;
	private JPanel columnLabelLine = null;
	private JLabel jLabel8 = null;
	private JTextField columnLabelField = null;
	private JPanel rendererPanel = null;
	private ShapeRendererPanel srp = null;
	private JPanel buttonPanel = null;
	private JButton cancelButton = null;
	private JPanel fWidthPanel = null;
	private JPanel fFixWidthPanel = null;
	private JButton fFixWidthButton = null;
	private JPanel fDsWidthPanel = null;
	private JLabel jLabel9 = null;
	private JComboBox fWidthParam = null;
	private JButton fDsWidthButton = null;
	private JPanel fHeightPanel = null;
	private JPanel fFixHeightPanel = null;
	private JButton fFixHeightButton = null;
	private JPanel fDsHeightPanel = null;
	private JLabel jLabel10 = null;
	private JComboBox fHeightParam = null;
	private JButton fDsHeightButton = null;
	private JPanel pWidthPanel = null;
	private JPanel pFixWidthPanel = null;
	private JButton pFixWidthButton = null;
	private JPanel pDsWidthPanel = null;
	private JLabel jLabel11 = null;
	private JComboBox pWidthParam = null;
	private JButton pDsWidthButton = null;
	private JPanel pHeightPanel = null;
	private JPanel pFixHeightPanel = null;
	private JButton pFixHeightButton = null;
	private JPanel pDsHeightPanel = null;
	private JLabel jLabel12 = null;
	private JComboBox pHeightParam = null;
	private JButton pDsHeightButton = null;
	private JPanel appearancePanel = null;
	private JLabel jLabel13 = null;
	private JComboBox appearanceBox = null;
	private JCheckBox tooltipBox = new JCheckBox("Generate tooltips");

	//============================================================================
	// additional members
	
	/** Constant label text for series producers. */
	private static final String DEFAULT_TEXT = "Dimensions (one of them is mandatory)";
	
	/** Constant label text for dataset producers. */
	private static final String SPECIAL_TEXT = "Dimensions from the complete grid";
	
	/** Flag that determines the kind of the width parameter in sequential mode. */
	private boolean user_defined_width = false;
	
	/** Flag that determines the kind of the height parameter in sequential mode. */
	private boolean user_defined_height = false;
		
	/** Flag that determines the kind of the width parameter in random mode. */
	private boolean r_user_defined_width = true;
	
	/** Flag that determines the kind of the height parameter in random mode. */
	private boolean r_user_defined_height = true;

	/** Flag that determines the mode of the chart (sequential or random). */
	private boolean is_full = true;
	
	//============================================================================
	// methods
	
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public ShapeGrid2DDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
	}

	//------------------------------------------------------------------------------
	/** This method initializes <code>this</code>. */
	private void initialize() {
		orderButtonGroup = new ButtonGroup();
		this.setSize(609, 219);
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.setPreferredSize(new Dimension(609, 219));
		this.setMinimumSize(new Dimension(609, 219));
		this.setMaximumSize(new Dimension(609, 219));
		this.add(getTabbed(), null);
		this.add(getButtonPanel(), null);
	}
	
	//------------------------------------------------------------------------------
	private JTabbedPane getTabbed() {
		if (tabbed == null) {
			tabbed = new JTabbedPane();
			tabbed.addTab("Main Settings",Utilities.icons.get(ChartConstants.SHAPEGRID2D), getMainPanel(), null);
			tabbed.addTab("Details", null, getDetailsPanel(), null);
			tabbed.addTab("Renderer", null, getRendererPanel(), null);
		}
		return tabbed;
	}

	//------------------------------------------------------------------------------
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(new CardLayout());
			mainPanel.add(getFullPanel(), getFullPanel().getName());
			mainPanel.add(getPartialPanel(), getPartialPanel().getName());
		}
		return mainPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getFullPanel() {
		if (fullPanel == null) {
			fullPanel = new JPanel();
			fullPanel.setLayout(new BoxLayout(getFullPanel(), BoxLayout.Y_AXIS));
			fullPanel.setName(ChartConstants.FULL);
			fullPanel.add(getFirstPanel(), null);
			fullPanel.add(Box.createRigidArea(new Dimension(0,5)));
			fullPanel.add(getFDimensionPanel(), null);
			fullPanel.add(getOrderPanel(), null);
		}
		return fullPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getFirstPanel() {
		if (firstPanel == null) {
			firstPanel = new JPanel();
			firstPanel.setLayout(new BoxLayout(getFirstPanel(), BoxLayout.X_AXIS));
			firstPanel.add(getValuesPanel(), null);
			firstPanel.add(getFSwitchPanel(), null);
		}
		return firstPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getValuesPanel() {
		if (valuesPanel == null) {
			valuesPanel = new JPanel();
			valuesPanel.setLayout(new BoxLayout(getValuesPanel(), BoxLayout.X_AXIS));
			valuesPanel.setBorder(BorderFactory.createTitledBorder(null, "Shape values / Complete grid", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			valuesPanel.add(getValuesParam(), null);
			valuesPanel.add(Box.createRigidArea(new Dimension(5,0)));
			valuesPanel.add(getAdvancedButton(), null);
		}
		return valuesPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getValuesParam() {
		if (valuesParam == null) {
			valuesParam = new JComboBox(getParamsToValues());
			valuesParam.setRenderer(new DataSourceComboBoxRenderer(valuesParam));
			valuesParam.setPreferredSize(new Dimension(100,26));
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
				valuesParam.setToolTipText(dsp.toString());
			}
			valuesParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
					valuesParam.setToolTipText(dsp.toString());
					advancedButton.setEnabled(dsp.hasAdvancedSettings());
					if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
						fDimensionPanel.setBorder(BorderFactory.createTitledBorder(null,SPECIAL_TEXT, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
						setEnabledDOWidgets(false);
						if (srp.hasDefinedRenderer()) {
							displayButton.setEnabled(true);
							ChartDialogChangeCenter.fireSaveEnabled(ShapeGrid2DDialog.this);
						}
					} else {
						fDimensionPanel.setBorder(BorderFactory.createTitledBorder(null,DEFAULT_TEXT, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
						setEnabledDOWidgets(true);
						boolean w_valid = (user_defined_width && is_valid(fWidthField.getText())) || (!user_defined_width && fWidthParam.getItemCount() > 0);
						boolean h_valid = (user_defined_height && is_valid(fHeightField.getText())) || (!user_defined_height && fHeightParam.getItemCount() > 0);
						if (!w_valid && !h_valid) {
							displayButton.setEnabled(false);
							ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
						}
					}
				}
			});
		}
		return valuesParam;
	}
	
	//------------------------------------------------------------------------------
	private JButton getAdvancedButton() {
		if (advancedButton == null) {
			advancedButton = new JButton();
			advancedButton.setEnabled(false);
			advancedButton.setText("Advanced...");
			advancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(ShapeGrid2DDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = valuesParam.getSelectedIndex();
						valuesParam.removeItemAt(index);
						valuesParam.insertItemAt(new_dsp,index);
						valuesParam.setSelectedIndex(index);
					}
				}
			});
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
				advancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return advancedButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getFSwitchPanel() {
		if (fSwitchPanel == null) {
			fSwitchPanel = new JPanel();
			fSwitchPanel.setLayout(new BoxLayout(getFSwitchPanel(), BoxLayout.X_AXIS));
			fSwitchPanel.setBorder(BorderFactory.createTitledBorder(null, "Grid filling mode: sequential", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			fSwitchPanel.add(Box.createHorizontalGlue());
			fSwitchPanel.add(getFSwitchButton(), null);
		}
		return fSwitchPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getFSwitchButton() {
		if (fSwitchButton == null) {
			fSwitchButton = new JButton();
			fSwitchButton.setText("Switch to random filling");
			fSwitchButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					CardLayout cl = (CardLayout) mainPanel.getLayout();
					cl.show(mainPanel,ChartConstants.PARTIAL);
					is_full = false;
					updateRowAndColumnLabels();
					if (xParam.getItemCount() > 0 && yParam.getItemCount() > 0 && shapeParam.getItemCount() > 0 && srp.hasDefinedRenderer()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(ShapeGrid2DDialog.this);
					}
				}
			});
		}
		return fSwitchButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getFDimensionPanel() {
		if (fDimensionPanel == null) {
			fDimensionPanel = new JPanel();
			fDimensionPanel.setLayout(new BoxLayout(getFDimensionPanel(), BoxLayout.X_AXIS));
			String text = DEFAULT_TEXT;
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
					text = SPECIAL_TEXT;
				}
			}
			fDimensionPanel.setBorder(BorderFactory.createTitledBorder(null, text, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			fDimensionPanel.add(getFWidthPanel(), null);
			fDimensionPanel.add(Box.createRigidArea(new Dimension(5,0)));
			fDimensionPanel.add(getFHeightPanel(), null);
		}
		return fDimensionPanel;
	}

	//------------------------------------------------------------------------------
	private JTextField getFWidthField() {
		if (fWidthField == null) {
			fWidthField = new JTextField();
			fWidthField.setHorizontalAlignment(JTextField.TRAILING);
			fWidthField.setText("10");
			fWidthField.addCaretListener(new javax.swing.event.CaretListener() {
				public void caretUpdate(javax.swing.event.CaretEvent e) {
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(ShapeGrid2DDialog.this);
					} else {
						if ((user_defined_height && !is_valid(fHeightField.getText())) ||
							(!user_defined_height && fHeightParam.getItemCount() == 0)) {
								displayButton.setEnabled(false);
								ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
						}
					}
				}
			});
			fWidthField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid(fWidthField.getText())) {
						fWidthField.setText("");
						if ((user_defined_height && !is_valid(fHeightField.getText())) ||
							(!user_defined_height && fHeightParam.getItemCount() == 0)) {
								displayButton.setEnabled(false);
								ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
						}
					}
				}
			});
		}
		return fWidthField;
	}

	//------------------------------------------------------------------------------
	private JTextField getFHeightField() {
		if (fHeightField == null) {
			fHeightField = new JTextField();
			fHeightField.setHorizontalAlignment(JTextField.TRAILING);
			fHeightField.setText("10");
			fHeightField.addCaretListener(new javax.swing.event.CaretListener() {
				public void caretUpdate(javax.swing.event.CaretEvent e) {
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(ShapeGrid2DDialog.this);
					} else {
						if ((user_defined_width && !is_valid(fWidthField.getText())) ||
							(!user_defined_width && fWidthParam.getItemCount() == 0)) {
								displayButton.setEnabled(false);
								ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
						}
					}
				}
			});
			fHeightField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid(fHeightField.getText())) {
						fHeightField.setText("");
						if ((user_defined_width && !is_valid(fWidthField.getText())) ||
							(!user_defined_width && fWidthParam.getItemCount() == 0)) {
								displayButton.setEnabled(false);
								ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
						}
					}
				}
			});
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
					fWidthField.setEnabled(false);
					fHeightField.setEnabled(false);
				}
			}
		}
		return fHeightField;
	}

	//------------------------------------------------------------------------------
	private JPanel getOrderPanel() {
		if (orderPanel == null) {
			jLabel2 = new JLabel();
			jLabel2.setText("  Filling order:  ");
			orderPanel = new JPanel();
			orderPanel.setLayout(new BoxLayout(getOrderPanel(), BoxLayout.X_AXIS));
			orderPanel.setPreferredSize(new Dimension(400, 35));
			orderPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
			orderPanel.setMaximumSize(new Dimension(32815, 35));
			orderPanel.add(jLabel2, null);
			orderPanel.add(getOrderButtonPanel(), null);
		}
		return orderPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getOrderButtonPanel() {
		if (orderButtonPanel == null) {
			orderButtonPanel = new JPanel();
			orderButtonPanel.setLayout(new BoxLayout(getOrderButtonPanel(), BoxLayout.X_AXIS));
			orderButtonPanel.add(getRowRadioButton(), null);
			orderButtonPanel.add(getColumnRadioButton(), null);
		}
		return orderButtonPanel;
	}

	//------------------------------------------------------------------------------
	private JRadioButton getRowRadioButton() {
		if (rowRadioButton == null) {
			rowRadioButton = new JRadioButton();
			rowRadioButton.setSelected(true);
			rowRadioButton.setText("Left-to-Right");
			rowRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.ROW_ORDER,"true");
				}
			});
			orderButtonGroup.add(rowRadioButton);
		}
		return rowRadioButton;
	}

	//------------------------------------------------------------------------------
	private JRadioButton getColumnRadioButton() {
		if (columnRadioButton == null) {
			columnRadioButton = new JRadioButton();
			columnRadioButton.setText("Top-to-Bottom");
			columnRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.ROW_ORDER,"false");
				}
			});
			orderButtonGroup.add(columnRadioButton);
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
					rowRadioButton.setEnabled(false);
					columnRadioButton.setEnabled(false);
				}
			}
		}
		return columnRadioButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getPartialPanel() {
		if (partialPanel == null) {
			partialPanel = new JPanel();
			partialPanel.setLayout(new BoxLayout(getPartialPanel(), BoxLayout.Y_AXIS));
			partialPanel.setName(ChartConstants.PARTIAL);
			partialPanel.add(getReqPanel(), null);
			partialPanel.add(getOptPanel(), null);
		}
		return partialPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getReqPanel() {
		if (reqPanel == null) {
			reqPanel = new JPanel();
			reqPanel.setLayout(new GridLayout(0, 2));
			reqPanel.add(getXPanel(), null);
			reqPanel.add(getPSwitchPanel(), null);
			reqPanel.add(getYPanel(), null);
			reqPanel.add(getShapePanel(), null);
		}
		return reqPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getXPanel() {
		if (xPanel == null) {
			xPanel = new JPanel();
			xPanel.setLayout(new BoxLayout(getXPanel(), BoxLayout.X_AXIS));
			xPanel.setBorder(BorderFactory.createTitledBorder(null, "X values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			xPanel.add(getXParam(), null);
			xPanel.add(Box.createRigidArea(new Dimension(5,0)));
			xPanel.add(getXAdvancedButton(), null);
		}
		return xPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getXParam() {
		if (xParam == null) {
			xParam = new JComboBox(getParamsToAll());
			xParam.setRenderer(new DataSourceComboBoxRenderer(xParam));
			xParam.setPreferredSize(new Dimension(100,26));
			if (xParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) xParam.getSelectedItem();
				xParam.setToolTipText(dsp.toString());
			}
			xParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) xParam.getSelectedItem();
					xParam.setToolTipText(dsp.toString());
					xAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
					updateRowAndColumnLabels();
				}
			});
		}
		return xParam;
	}

	//------------------------------------------------------------------------------
	private JButton getXAdvancedButton() {
		if (xAdvancedButton == null) {
			xAdvancedButton = new JButton();
			xAdvancedButton.setEnabled(false);
			xAdvancedButton.setText("Advanced...");
			xAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) xParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(ShapeGrid2DDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = xParam.getSelectedIndex();
						xParam.removeItemAt(index);
						xParam.insertItemAt(new_dsp,index);
						xParam.setSelectedIndex(index);
					}
				}
			});
			if (xParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) xParam.getSelectedItem();
				xAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return xAdvancedButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getPSwitchPanel() {
		if (pSwitchPanel == null) {
			pSwitchPanel = new JPanel();
			pSwitchPanel.setLayout(new BoxLayout(getPSwitchPanel(), BoxLayout.X_AXIS));
			pSwitchPanel.setBorder(BorderFactory.createTitledBorder(null, "Grid filling mode: random", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			pSwitchPanel.add(Box.createHorizontalGlue());
			pSwitchPanel.add(getPSwitchButton(), null);
		}
		return pSwitchPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getPSwitchButton() {
		if (pSwitchButton == null) {
			pSwitchButton = new JButton();
			pSwitchButton.setText("Switch to sequential filling");
			pSwitchButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					CardLayout cl = (CardLayout) mainPanel.getLayout();
					cl.show(mainPanel,ChartConstants.FULL);
					is_full = true;
					updateRowAndColumnLabels();
					if (valuesParam.getItemCount() > 0) {
						IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
						if (dsp.getSupportedIntfs().contains(ISeriesProducer.class)) {
							boolean w_valid = (user_defined_width && is_valid(fWidthField.getText())) || (!user_defined_width && fWidthParam.getItemCount() > 0);
							boolean h_valid = (user_defined_height && is_valid(fHeightField.getText())) || (!user_defined_height && fHeightParam.getItemCount() > 0);
							if (!w_valid && !h_valid) {
								displayButton.setEnabled(false);
								ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
							}
						}
					}
				}
			});
		}
		return pSwitchButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getYPanel() {
		if (yPanel == null) {
			yPanel = new JPanel();
			yPanel.setLayout(new BoxLayout(getYPanel(), BoxLayout.X_AXIS));
			yPanel.setBorder(BorderFactory.createTitledBorder(null, "Y values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			yPanel.add(getYParam(), null);
			yPanel.add(Box.createRigidArea(new Dimension(5,0)));
			yPanel.add(getYAdvancedButton(), null);
		}
		return yPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getYParam() {
		if (yParam == null) {
			yParam = new JComboBox(getParamsToAll());
			yParam.setRenderer(new DataSourceComboBoxRenderer(yParam));
			yParam.setPreferredSize(new Dimension(100,26));
			if (yParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) yParam.getSelectedItem();
				yParam.setToolTipText(dsp.toString());
			}
			yParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) yParam.getSelectedItem();
					yParam.setToolTipText(dsp.toString());
					yAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
					updateRowAndColumnLabels();
				}
			});
		}
		return yParam;
	}

	//------------------------------------------------------------------------------
	private JButton getYAdvancedButton() {
		if (yAdvancedButton == null) {
			yAdvancedButton = new JButton();
			yAdvancedButton.setEnabled(false);
			yAdvancedButton.setText("Advanced...");
			yAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dps = (IDataSourceProducer) yParam.getSelectedItem();
					IDataSourceProducer new_dps = dps.advancedSettingsDialog(ShapeGrid2DDialog.this.getRootPane().getParent());
					if (new_dps != null) {
						int index = yParam.getSelectedIndex();
						yParam.removeItemAt(index);
						yParam.insertItemAt(new_dps,index);
						yParam.setSelectedIndex(index);
					}
				}
			});
			if (yParam.getItemCount() > 0) {
				IDataSourceProducer dps = (IDataSourceProducer) yParam.getSelectedItem();
				yAdvancedButton.setEnabled(dps.hasAdvancedSettings());
			}
		}
		return yAdvancedButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getShapePanel() {
		if (shapePanel == null) {
			shapePanel = new JPanel();
			shapePanel.setLayout(new BoxLayout(getShapePanel(), BoxLayout.X_AXIS));
			shapePanel.setBorder(BorderFactory.createTitledBorder(null, "Shape values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			shapePanel.add(getShapeParam(), null);
			shapePanel.add(Box.createRigidArea(new Dimension(5,0)));
			shapePanel.add(getShapeAdvancedButton(), null);
		}
		return shapePanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getShapeParam() {
		if (shapeParam == null) {
			shapeParam = new JComboBox(getParamsToAll());
			shapeParam.setRenderer(new DataSourceComboBoxRenderer(shapeParam));
			shapeParam.setPreferredSize(new Dimension(100,26));
			if (shapeParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) shapeParam.getSelectedItem();
				shapeParam.setToolTipText(dsp.toString());
			}
			shapeParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) shapeParam.getSelectedItem();
					shapeParam.setToolTipText(dsp.toString());
					shapeAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
				}
			});
		}
		return shapeParam;
	}

	//------------------------------------------------------------------------------
	private JButton getShapeAdvancedButton() {
		if (shapeAdvancedButton == null) {
			shapeAdvancedButton = new JButton();
			shapeAdvancedButton.setEnabled(false);
			shapeAdvancedButton.setText("Advanced...");
			shapeAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) shapeParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(ShapeGrid2DDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = shapeParam.getSelectedIndex();
						shapeParam.removeItemAt(index);
						shapeParam.insertItemAt(new_dsp,index);
						shapeParam.setSelectedIndex(index);
					}
				}
			});
			if (shapeParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) shapeParam.getSelectedItem();
				shapeAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return shapeAdvancedButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getOptPanel() {
		if (optPanel == null) {
			optPanel = new JPanel();
			optPanel.setLayout(new BoxLayout(getOptPanel(), BoxLayout.X_AXIS));
			optPanel.setBorder(BorderFactory.createTitledBorder(null, "Dimensions (optional)", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			optPanel.add(getPWidthPanel(), null);
			optPanel.add(Box.createRigidArea(new Dimension(5,0)));
			optPanel.add(getPHeightPanel(), null);
		}
		return optPanel;
	}

	//------------------------------------------------------------------------------
	private JTextField getPWidthField() {
		if (pWidthField == null) {
			pWidthField = new JTextField();
			pWidthField.setHorizontalAlignment(JTextField.TRAILING);
			pWidthField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid(pWidthField.getText())) 
						pWidthField.setText("");
				}
			});
		}
		return pWidthField;
	}

	//------------------------------------------------------------------------------
	private JTextField getPHeightField() {
		if (pHeightField == null) {
			pHeightField = new JTextField();
			pHeightField.setHorizontalAlignment(JTextField.TRAILING);
			pHeightField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid(pHeightField.getText())) 
						pHeightField.setText("");
				}
			});
		}
		return pHeightField;
	}

	//------------------------------------------------------------------------------
	private JPanel getDetailsPanel() {
		if (detailsPanel == null) {
			detailsPanel = new JPanel();
			detailsPanel.setLayout(new BoxLayout(getDetailsPanel(), BoxLayout.Y_AXIS));
			detailsPanel.setBorder(BorderFactory.createTitledBorder(null, "Titles and labels of the chart", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			detailsPanel.add(getTitleLine(), null);
			detailsPanel.add(getSubtitleLine(), null);
			detailsPanel.add(getRowLabelLine(), null);
			detailsPanel.add(getColumnLabelLine(), null);
			JPanel temp = new JPanel();
			temp.setLayout(new BoxLayout(temp,BoxLayout.X_AXIS));
			JLabel dummy = new JLabel(" ");
			dummy.setPreferredSize(new Dimension(100,16));
			temp.add(dummy,null);
			temp.add(tooltipBox);
			temp.add(Box.createHorizontalGlue());
			detailsPanel.add(temp,null);
		}
		return detailsPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getTitleLine() {
		if (titleLine == null) {
			jLabel5 = new JLabel();
			jLabel5.setPreferredSize(new Dimension(100, 16));
			jLabel5.setText("  Title:  ");
			titleLine = new JPanel();
			titleLine.setLayout(new BoxLayout(getTitleLine(), BoxLayout.X_AXIS));
			titleLine.setPreferredSize(new Dimension(400, 20));
			titleLine.add(jLabel5, null);
			titleLine.add(getTitleField(), null);
		}
		return titleLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getTitleField() {
		if (titleField == null) {
			titleField = new JTextField();
			titleField.setPreferredSize(new Dimension(300, 20));
			titleField.setText(ChartConstants.SHAPEGRID2D_NAME);
			titleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.TITLE,titleField.getText());
					ChartDialogChangeCenter.fireTitleChanged(ShapeGrid2DDialog.this);
				}
			});
			titleField.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					subtitleField.grabFocus();
				}
			});
		}
		return titleField;
	}

	//------------------------------------------------------------------------------
	private JPanel getSubtitleLine() {
		if (subtitleLine == null) {
			jLabel6 = new JLabel();
			jLabel6.setPreferredSize(new Dimension(100, 16));
			jLabel6.setText("  Subtitle:  ");
			subtitleLine = new JPanel();
			subtitleLine.setLayout(new BoxLayout(getSubtitleLine(), BoxLayout.X_AXIS));
			subtitleLine.setPreferredSize(new Dimension(400, 20));
			subtitleLine.add(jLabel6, null);
			subtitleLine.add(getSubtitleField(), null);
		}
		return subtitleLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getSubtitleField() {
		if (subtitleField == null) {
			subtitleField = new JTextField();
			subtitleField.setPreferredSize(new Dimension(300, 20));
			subtitleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
				}
			});
		}
		return subtitleField;
	}

	//------------------------------------------------------------------------------
	private JPanel getRowLabelLine() {
		if (rowLabelLine == null) {
			jLabel7 = new JLabel();
			jLabel7.setPreferredSize(new Dimension(100, 16));
			jLabel7.setText("  Row label:  ");
			rowLabelLine = new JPanel();
			rowLabelLine.setLayout(new BoxLayout(getRowLabelLine(), BoxLayout.X_AXIS));
			rowLabelLine.setPreferredSize(new Dimension(400, 20));
			rowLabelLine.add(jLabel7, null);
			rowLabelLine.add(getRowLabelField(), null);
		}
		return rowLabelLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getRowLabelField() {
		if (rowLabelField == null) {
			rowLabelField = new JTextField();
			rowLabelField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.ROW_LABEL,rowLabelField.getText());
				}
			});
			rowLabelField.setPreferredSize(new Dimension(300, 20));
		}
		return rowLabelField;
	}

	//------------------------------------------------------------------------------
	private JPanel getColumnLabelLine() {
		if (columnLabelLine == null) {
			jLabel8 = new JLabel();
			jLabel8.setPreferredSize(new Dimension(100, 16));
			jLabel8.setText(" Column label:  ");
			columnLabelLine = new JPanel();
			columnLabelLine.setLayout(new BoxLayout(getColumnLabelLine(), BoxLayout.X_AXIS));
			columnLabelLine.setPreferredSize(new Dimension(400, 20));
			columnLabelLine.add(jLabel8, null);
			columnLabelLine.add(getColumnLabelField(), null);
		}
		return columnLabelLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getColumnLabelField() {
		if (columnLabelField == null) {
			columnLabelField = new JTextField();
			columnLabelField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.COLUMN_LABEL,columnLabelField.getText());
				}
			});
			columnLabelField.setPreferredSize(new Dimension(300, 20));
		}
		return columnLabelField;
	}

	//------------------------------------------------------------------------------
	private JPanel getRendererPanel() {
		if (rendererPanel == null) {
			rendererPanel = new JPanel();
			rendererPanel.setLayout(new BoxLayout(getRendererPanel(), BoxLayout.Y_AXIS));
			rendererPanel.setBorder(BorderFactory.createTitledBorder(null, "Renderer of the chart", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			srp = new ShapeRendererPanel(this);
			srp.setPreferredSize(new Dimension(609,56));
			srp.setMaximumSize(new Dimension(32831,60));
			rendererPanel.add(getAppearancePanel(), null);
			rendererPanel.add(srp,null);
		}
		return rendererPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = new JPanel();
			buttonPanel.setLayout(new FlowLayout());
			buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
			buttonPanel.add(getEditorButton(), null);
			buttonPanel.add(getDisplayButton(), null);
			buttonPanel.add(getSaveButton(), null);
			buttonPanel.add(getCancelButton(), null);
		}
		return buttonPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getDisplayButton() {
		if (displayButton == null) {
			displayButton = new JButton();
			displayButton.setText("Display");
			displayButton.setMnemonic(KeyEvent.VK_D);
			displayButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					displayChart();
				}
			});
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class) && srp.hasDefinedRenderer()) {
					displayButton.setEnabled(true);
				}
			}
		}
		return displayButton;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}

	//------------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setEnabled(false);
			saveButton.setText("Save");
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					saveCollection();
				}
			});
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class) && srp.hasDefinedRenderer()) {
					saveButton.setEnabled(true);
				}
			}
		}
		return saveButton;
	}

	//------------------------------------------------------------------------------
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMnemonic(KeyEvent.VK_C);
			cancelButton.setText("Cancel");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					notifyForHide();
				}
			});
		}
		return cancelButton;
	}
	
	//------------------------------------------------------------------------------
	private JPanel getFWidthPanel() {
		if (fWidthPanel == null) {
			fWidthPanel = new JPanel();
			fWidthPanel.setLayout(new CardLayout());
			fWidthPanel.add(getFDsWidthPanel(), getFDsWidthPanel().getName());
			fWidthPanel.add(getFFixWidthPanel(), getFFixWidthPanel().getName());
		}
		return fWidthPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getFFixWidthPanel() {
		if (fFixWidthPanel == null) {
			jLabel = new JLabel();
			jLabel.setText("  Width:  ");
			fFixWidthPanel = new JPanel();
			fFixWidthPanel.setLayout(new BoxLayout(getFFixWidthPanel(), BoxLayout.X_AXIS));
			fFixWidthPanel.setName("F_FIX_WIDTH");
			fFixWidthPanel.add(jLabel, null);
			fFixWidthPanel.add(getFWidthField(), null);
			fFixWidthPanel.add(Box.createRigidArea(new Dimension(5,0)));
			fFixWidthPanel.add(getFFixWidthButton(), null);
		}
		return fFixWidthPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getFFixWidthButton() {
		if (fFixWidthButton == null) {
			fFixWidthButton = new JButton();
			fFixWidthButton.setText("From data source");
			fFixWidthButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					user_defined_width = false;
					CardLayout cl = (CardLayout) fWidthPanel.getLayout();
					cl.show(fWidthPanel,"F_DS_WIDTH");
//					if (fWidthParam.getItemCount() > 0 && srp.hasDefinedRenderer()) {
//						displayButton.setEnabled(true);
//						ChartDialogChangeCenter.fireSaveEnabled(ShapeGrid2DDialog.this);
//					}
					if (isUpdateable() && srp.hasDefinedRenderer()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(ShapeGrid2DDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
					}
				}
			});
		}
		return fFixWidthButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getFDsWidthPanel() {
		if (fDsWidthPanel == null) {
			jLabel9 = new JLabel();
			jLabel9.setText("  Width:  ");
			fDsWidthPanel = new JPanel();
			fDsWidthPanel.setLayout(new BoxLayout(getFDsWidthPanel(), BoxLayout.X_AXIS));
			fDsWidthPanel.setName("F_DS_WIDTH");
			fDsWidthPanel.add(jLabel9, null);
			fDsWidthPanel.add(getFWidthParam(), null);
			fDsWidthPanel.add(Box.createRigidArea(new Dimension(5,0)));
			fDsWidthPanel.add(getFDsWidthButton(), null);
		}
		return fDsWidthPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getFWidthParam() {
		if (fWidthParam == null) {
			fWidthParam = new JComboBox(getParamsToDimensions());
			fWidthParam.setRenderer(new DataSourceComboBoxRenderer(fWidthParam));
			fWidthParam.setPreferredSize(new Dimension(100,26));
			if (fWidthParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) fWidthParam.getSelectedItem();
				fWidthParam.setToolTipText(dsp.toString());
			}
			fWidthParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) fWidthParam.getSelectedItem();
					fWidthParam.setToolTipText(dsp.toString());
				}
			});
		}
		return fWidthParam;
	}

	//------------------------------------------------------------------------------
	private JButton getFDsWidthButton() {
		if (fDsWidthButton == null) {
			fDsWidthButton = new JButton();
			fDsWidthButton.setText("From user input");
			fDsWidthButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					user_defined_width = true;
					CardLayout cl = (CardLayout) fWidthPanel.getLayout();
					cl.show(fWidthPanel,"F_FIX_WIDTH");
//					if (!isUpdateable()) {
//						displayButton.setEnabled(false);
//						ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
//					}
					if (isUpdateable() && srp.hasDefinedRenderer()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(ShapeGrid2DDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
					}
				}
			});
		}
		return fDsWidthButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getFHeightPanel() {
		if (fHeightPanel == null) {
			fHeightPanel = new JPanel();
			fHeightPanel.setLayout(new CardLayout());
			fHeightPanel.add(getFDsHeightPanel(), getFDsHeightPanel().getName());
			fHeightPanel.add(getFFixHeightPanel(), getFFixHeightPanel().getName());
		}
		return fHeightPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getFFixHeightPanel() {
		if (fFixHeightPanel == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("  Height:  ");
			fFixHeightPanel = new JPanel();
			fFixHeightPanel.setLayout(new BoxLayout(getFFixHeightPanel(), BoxLayout.X_AXIS));
			fFixHeightPanel.setName("F_FIX_HEIGHT");
			fFixHeightPanel.add(jLabel1, null);
			fFixHeightPanel.add(getFHeightField(), null);
			fFixHeightPanel.add(Box.createRigidArea(new Dimension(5,0)));
			fFixHeightPanel.add(getFFixHeightButton(), null);
		}
		return fFixHeightPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getFFixHeightButton() {
		if (fFixHeightButton == null) {
			fFixHeightButton = new JButton();
			fFixHeightButton.setText("From data source");
			fFixHeightButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					user_defined_height = false;
					CardLayout cl = (CardLayout) fHeightPanel.getLayout();
					cl.show(fHeightPanel,"F_DS_HEIGHT");
//					if (fHeightParam.getItemCount() > 0 && srp.hasDefinedRenderer()) {
//						displayButton.setEnabled(true);
//						ChartDialogChangeCenter.fireSaveEnabled(ShapeGrid2DDialog.this);
//					}
					if (isUpdateable() && srp.hasDefinedRenderer()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(ShapeGrid2DDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
					}
				}
			});
		}
		return fFixHeightButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getFDsHeightPanel() {
		if (fDsHeightPanel == null) {
			jLabel10 = new JLabel();
			jLabel10.setText("  Height:  ");
			fDsHeightPanel = new JPanel();
			fDsHeightPanel.setLayout(new BoxLayout(getFDsHeightPanel(), BoxLayout.X_AXIS));
			fDsHeightPanel.setName("F_DS_HEIGHT");
			fDsHeightPanel.add(jLabel10, null);
			fDsHeightPanel.add(getFHeightParam(), null);
			fDsHeightPanel.add(Box.createRigidArea(new Dimension(5,0)));
			fDsHeightPanel.add(getFDsHeightButton(), null);
		}
		return fDsHeightPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getFHeightParam() {
		if (fHeightParam == null) {
			fHeightParam = new JComboBox(getParamsToDimensions());
			fHeightParam.setRenderer(new DataSourceComboBoxRenderer(fHeightParam));
			fHeightParam.setPreferredSize(new Dimension(100,26));
			if (fHeightParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) fHeightParam.getSelectedItem();
				fHeightParam.setToolTipText(dsp.toString());
			}
			fHeightParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) fHeightParam.getSelectedItem();
					fHeightParam.setToolTipText(dsp.toString());
				}
			});
		}
		return fHeightParam;
	}

	//------------------------------------------------------------------------------
	private JButton getFDsHeightButton() {
		if (fDsHeightButton == null) {
			fDsHeightButton = new JButton();
			fDsHeightButton.setText("From user input");
			fDsHeightButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					user_defined_height = true;
					CardLayout cl = (CardLayout) fHeightPanel.getLayout();
					cl.show(fHeightPanel,"F_FIX_HEIGHT");
//					if (!isUpdateable()) {
//						displayButton.setEnabled(false);
//						ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
//					}
					if (isUpdateable() && srp.hasDefinedRenderer()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(ShapeGrid2DDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(ShapeGrid2DDialog.this);
					}
				}
			});
		}
		return fDsHeightButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getPWidthPanel() {
		if (pWidthPanel == null) {
			pWidthPanel = new JPanel();
			pWidthPanel.setLayout(new CardLayout());
			pWidthPanel.add(getPFixWidthPanel(), getPFixWidthPanel().getName());
			pWidthPanel.add(getPDsWidthPanel(), getPDsWidthPanel().getName());
		}
		return pWidthPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getPFixWidthPanel() {
		if (pFixWidthPanel == null) {
			jLabel3 = new JLabel();
			jLabel3.setText("  Width:  ");
			pFixWidthPanel = new JPanel();
			pFixWidthPanel.setLayout(new BoxLayout(getPFixWidthPanel(), BoxLayout.X_AXIS));
			pFixWidthPanel.setName("P_FIX_WIDTH");
			pFixWidthPanel.add(jLabel3, null);
			pFixWidthPanel.add(getPWidthField(), null);
			pFixWidthPanel.add(Box.createRigidArea(new Dimension(5,0)));
			pFixWidthPanel.add(getPFixWidthButton(), null);
		}
		return pFixWidthPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getPFixWidthButton() {
		if (pFixWidthButton == null) {
			pFixWidthButton = new JButton();
			pFixWidthButton.setText("From data source");
			pFixWidthButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					r_user_defined_width = false;
					CardLayout cl = (CardLayout) pWidthPanel.getLayout();
					cl.show(pWidthPanel,"P_DS_WIDTH");
				}
			});
		}
		return pFixWidthButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getPDsWidthPanel() {
		if (pDsWidthPanel == null) {
			jLabel11 = new JLabel();
			jLabel11.setText("  Width:  ");
			pDsWidthPanel = new JPanel();
			pDsWidthPanel.setLayout(new BoxLayout(getPDsWidthPanel(), BoxLayout.X_AXIS));
			pDsWidthPanel.setName("P_DS_WIDTH");
			pDsWidthPanel.add(jLabel11, null);
			pDsWidthPanel.add(getPWidthParam(), null);
			pDsWidthPanel.add(Box.createRigidArea(new Dimension(5,0)));
			pDsWidthPanel.add(getPDsWidthButton(), null);
		}
		return pDsWidthPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getPWidthParam() {
		if (pWidthParam == null) {
			pWidthParam = new JComboBox(getParamsToDimensions());
			pWidthParam.setRenderer(new DataSourceComboBoxRenderer(pWidthParam));
			pWidthParam.setPreferredSize(new Dimension(100,26));
			if (pWidthParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) pWidthParam.getSelectedItem();
				pWidthParam.setToolTipText(dsp.toString());
			}
			pWidthParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) pWidthParam.getSelectedItem();
					pWidthParam.setToolTipText(dsp.toString());
				}
			});
		}
		return pWidthParam;
	}

	//------------------------------------------------------------------------------
	private JButton getPDsWidthButton() {
		if (pDsWidthButton == null) {
			pDsWidthButton = new JButton();
			pDsWidthButton.setText("From user input");
			pDsWidthButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					r_user_defined_width = true;
					CardLayout cl = (CardLayout) pWidthPanel.getLayout();
					cl.show(pWidthPanel,"P_FIX_WIDTH");
				}
			});
		}
		return pDsWidthButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getPHeightPanel() {
		if (pHeightPanel == null) {
			pHeightPanel = new JPanel();
			pHeightPanel.setLayout(new CardLayout());
			pHeightPanel.add(getPFixHeightPanel(), getPFixHeightPanel().getName());
			pHeightPanel.add(getPDsHeightPanel(), getPDsHeightPanel().getName());
		}
		return pHeightPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getPFixHeightPanel() {
		if (pFixHeightPanel == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("  Height:  ");
			pFixHeightPanel = new JPanel();
			pFixHeightPanel.setLayout(new BoxLayout(getPFixHeightPanel(), BoxLayout.X_AXIS));
			pFixHeightPanel.setName("P_FIX_HEIGHT");
			pFixHeightPanel.add(jLabel4, null);
			pFixHeightPanel.add(getPHeightField(), null);
			pFixHeightPanel.add(Box.createRigidArea(new Dimension(5,0)));
			pFixHeightPanel.add(getPFixHeightButton(), null);
		}
		return pFixHeightPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getPFixHeightButton() {
		if (pFixHeightButton == null) {
			pFixHeightButton = new JButton();
			pFixHeightButton.setText("From data source");
			pFixHeightButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					r_user_defined_height = false;
					CardLayout cl = (CardLayout) pHeightPanel.getLayout();
					cl.show(pHeightPanel,"P_DS_HEIGHT");
				}
			});
		}
		return pFixHeightButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getPDsHeightPanel() {
		if (pDsHeightPanel == null) {
			jLabel12 = new JLabel();
			jLabel12.setText("  Height:  ");
			pDsHeightPanel = new JPanel();
			pDsHeightPanel.setLayout(new BoxLayout(getPDsHeightPanel(), BoxLayout.X_AXIS));
			pDsHeightPanel.setName("P_DS_HEIGHT");
			pDsHeightPanel.add(jLabel12, null);
			pDsHeightPanel.add(getPHeightParam(), null);
			pDsHeightPanel.add(Box.createRigidArea(new Dimension(5,0)));
			pDsHeightPanel.add(getPDsHeightButton(), null);
		}
		return pDsHeightPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getPHeightParam() {
		if (pHeightParam == null) {
			pHeightParam = new JComboBox(getParamsToDimensions());
			pHeightParam.setRenderer(new DataSourceComboBoxRenderer(pHeightParam));
			pHeightParam.setPreferredSize(new Dimension(100,26));
			if (pHeightParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) pHeightParam.getSelectedItem();
				pHeightParam.setToolTipText(dsp.toString());
			}
			pHeightParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) pHeightParam.getSelectedItem();
					pHeightParam.setToolTipText(dsp.toString());
				}
			});
		}
		return pHeightParam;
	}

	//------------------------------------------------------------------------------
	private JButton getPDsHeightButton() {
		if (pDsHeightButton == null) {
			pDsHeightButton = new JButton();
			pDsHeightButton.setText("From user input");
			pDsHeightButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					r_user_defined_height = true;
					CardLayout cl = (CardLayout) pHeightPanel.getLayout();
					cl.show(pHeightPanel,"P_FIX_HEIGHT");
				}
			});
		}
		return pDsHeightButton;
	}
	
	//------------------------------------------------------------------------------
	private JPanel getAppearancePanel() {
		if (appearancePanel == null) {
			jLabel13 = new JLabel();
			jLabel13.setText("  Appearance:  ");
			appearancePanel = new JPanel();
			appearancePanel.setLayout(new BoxLayout(getAppearancePanel(), BoxLayout.X_AXIS));
			appearancePanel.setMaximumSize(new Dimension(Integer.MAX_VALUE,25));
			appearancePanel.add(jLabel13, null);
			appearancePanel.add(Box.createRigidArea(new Dimension(51,0)));
			appearancePanel.add(getAppearanceBox(), null);
		}
		return appearancePanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getAppearanceBox() {
		if (appearanceBox == null) {
			Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
			appearances.add(new ComboboxItem( "B", "Basic"));
			appearances.add(new ComboboxItem( "N", "Normal"));
			for (String templateNames : AbstractChart.templates.keySet())
				appearances.add(new ComboboxItem("_" + templateNames,templateNames));
			appearances.add(new ComboboxItem("_NEW","New template..."));
			appearances.add(new ComboboxItem("_EDIT","Edit template..."));
			appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
			appearanceBox = new JComboBox(appearances);
			appearanceBox.setPreferredSize(new Dimension(154,25));
			appearanceBox.setMaximumSize(new Dimension(154,25));
			appearanceBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int index = appearanceBox.getSelectedIndex();
					String id = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
					if (index >= 0 && index <= 1) {
						if ("B".equals(id)) 
							ChartConfigCollection.setEnvironmentAppearance(ChartConstants.BASIC_APP);
						else 
							ChartConfigCollection.setEnvironmentAppearance(ChartConstants.NORMAL_APP);
					}  else if (id.equals("_NEW")) {
						ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.NORMAL);
						int result = dlg.showDialog();
						if (result == ChartPropertiesDialog.OK_OPTION) {
							Element newTemplate = (Element) dlg.getTemplate();
							dlg.dispose();
							String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
							AbstractChart.templates.put(name,newTemplate);
							ChartDialogChangeCenter.fireTemplateChanged();
							appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
						} else 
							appearanceBox.setSelectedIndex(0);
					} else if (id.equals("_EDIT")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(ShapeGrid2DDialog.this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String) JOptionPane.showInputDialog(ShapeGrid2DDialog.this,"Select a template: ","Edit template",
																	  		   JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template == null || "".equals(template)) 
							appearanceBox.setSelectedIndex(0);
						else {
							Element templateElement = AbstractChart.templates.get(template);
							ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(),ChartKind.NORMAL);
							int result = dlg.showDialog();
							if (result == ChartPropertiesDialog.OK_OPTION) {
								Element newTemplate = (Element) dlg.getTemplate();
								dlg.dispose();
								String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
								AbstractChart.templates.put(name,newTemplate);
								ChartDialogChangeCenter.fireTemplateChanged();
								appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
							} else 
								appearanceBox.setSelectedIndex(0);
						}
					} else if (id.equals("_REMOVE")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(ShapeGrid2DDialog.this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String) JOptionPane.showInputDialog(ShapeGrid2DDialog.this,"Select a template: ","Delete template",
																	  		   JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template != null && !"".equals(template)) { 
							AbstractChart.templates.remove(template);
							File file = new File("Templates/" + template + ".xml");
							file.delete();
							ChartDialogChangeCenter.fireTemplateChanged();
						}
						appearanceBox.setSelectedIndex(0);
					}
				}
			});
		}
		return appearanceBox;
	}
	
	//------------------------------------------------------------------------------
	private List<String> getLegends() {	return new ArrayList<String>(); }
	
	//============================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-generated functions                                                //
	////////////////////////////////////////////////////////////////////////////
	
	/** Returns the current data source of the shape values.
	 * @return the current data source of the shape values
	 */
	public IDataSourceProducer getShapeValueProducer() {
		IDataSourceProducer selected = (IDataSourceProducer)(is_full ? valuesParam.getSelectedItem() : shapeParam.getSelectedItem());
		return selected;
	}
	
	//----------------------------------------------------------------------------------------------------
	public void setUpdateStatus(boolean status) {
		boolean paramAvailable = /* valuesParam.getItemCount() > 0; */ isUpdateable();
		displayButton.setEnabled(paramAvailable && status);
		if (paramAvailable && status)
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}
	
	//------------------------------------------------------------------------------
	/** Returns whether the input string contains a valid positive integer or
	 *  not.
	 * @param text input string
	 */
	private boolean is_valid(String text) {
		Pattern p = Pattern.compile("^[1-9][0-9]*$"); // pattern for positive integers
		Matcher m = p.matcher(text.trim());
		if (m.matches()) {
			try {
				Integer.parseInt(text.trim());
				return true;
			} catch (NumberFormatException e) {}
		}
		return false;
	}
	
	//------------------------------------------------------------------------------
	/** It calls setEnabled on dimension and order widgets. */
	private void setEnabledDOWidgets(boolean enabled) {
		jLabel.setEnabled(enabled);
		fWidthField.setEnabled(enabled);
		fFixWidthButton.setEnabled(enabled);
		fDsWidthButton.setEnabled(enabled);
		jLabel9.setEnabled(enabled);
		fWidthParam.setEnabled(enabled && fWidthParam.getItemCount() > 0);
		fDsWidthButton.setEnabled(enabled);
		jLabel1.setEnabled(enabled);
		fHeightField.setEnabled(enabled);
		fFixHeightButton.setEnabled(enabled);
		jLabel10.setEnabled(enabled);
		fHeightParam.setEnabled(enabled && fHeightParam.getItemCount() > 0);
		fDsHeightButton.setEnabled(enabled);
		jLabel2.setEnabled(enabled);
		rowRadioButton.setEnabled(enabled);
		columnRadioButton.setEnabled(enabled);
	}
	
	//------------------------------------------------------------------------------
	@Override
	protected void setWidgetDisabled() {
		if (valuesParam.getItemCount() == 0) {
			valuesParam.setEnabled(false);
			shapeParam.setEnabled(false);
			xParam.setEnabled(false);
			yParam.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			advancedButton.setEnabled(false);
			shapeAdvancedButton.setEnabled(false);
			xAdvancedButton.setEnabled(false);
			yAdvancedButton.setEnabled(false);
			fDsWidthButton.setEnabled(false);
			fDsHeightButton.setEnabled(false);
		}
		if (shapeParam.getItemCount() == 0) {
			shapeParam.setEnabled(false);
			xParam.setEnabled(false);
			yParam.setEnabled(false);
			shapeAdvancedButton.setEnabled(false);
			xAdvancedButton.setEnabled(false);
			yAdvancedButton.setEnabled(false);
			pDsWidthButton.setEnabled(false);
			pDsHeightButton.setEnabled(false);
		}
		if (fWidthParam.getItemCount() == 0) {
			fFixWidthButton.setEnabled(false);
			fFixHeightButton.setEnabled(false);
			pFixWidthButton.setEnabled(false);
			pFixHeightButton.setEnabled(false);
			fWidthParam.setEnabled(false);
			fHeightParam.setEnabled(false);
			pWidthParam.setEnabled(false);
			pHeightParam.setEnabled(false);
//			pDsWidthButton.setEnabled(false);
//			pDsHeightButton.setEnabled(false);
		}
	}
	
	//------------------------------------------------------------------------------
	/** Returns the displayable names of the data sources for all (non-dimensional)
	 *  comboboxes (except <code>valuesParam</code>).
	 * @return array of data sources
	 */
 	private Object[] getParamsToAll() {
 		return getParams(new Class[] { ISeriesProducer.class, IValueProducer.class });
 	}
 	
	//------------------------------------------------------------------------------
 	/** Returns the displayable names of the data sources for <code>valuesParam</code>
 	 *  combobox.
 	 * @return array of data sources
 	 */
 	private Object[] getParamsToValues() {
		return getParams(new Class[] { ISeriesProducer.class, IValueProducer.class, IGrid2DDatasetProducer.class });
 	}
 	
 	//------------------------------------------------------------------------------
 	/** Returns the displayable names of the data sources for dimensional comboboxes.
 	 * @return array of data sources
 	 */
 	private Object[] getParamsToDimensions() {
 		return getParams(IValueProducer.class);
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	protected void setSettingsFromConfig() {
 		if (config.getChartProperties() instanceof Properties) {
 			//set settings from the config
 			properties = (Properties)config.getChartProperties();
 			String rowLabel = properties.getProperty(ChartConstants.ROW_LABEL);
 			String columnLabel = properties.getProperty(ChartConstants.COLUMN_LABEL);
 			
 			int[] ds = Utilities.splitDatasourceAroundCommas(properties.getProperty(ChartConstants.DATASOURCE));
 			if (ds.length==1) { // one datasource, full mode
 				is_full = true;
 				IDataSourceProducer dsp = config.getDataSource(ds[0]);
 				valuesParam.setSelectedItem(dsp);
				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
 					setEnabledDOWidgets(false);
 				}
 				user_defined_width = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_WIDTH));
				if (user_defined_width) {
 					CardLayout cl = (CardLayout) fWidthPanel.getLayout();
					cl.show(fWidthPanel,"F_FIX_WIDTH");
					fWidthField.setText(properties.getProperty(ChartConstants.WIDTH));
				} else {
 					IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.WIDTH)));
 					fWidthParam.setSelectedItem(vp);
 				}
 				user_defined_height = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
 				if (user_defined_height) {
 					CardLayout cl = (CardLayout) fHeightPanel.getLayout();
					cl.show(fHeightPanel,"F_FIX_HEIGHT");
 					fHeightField.setText(properties.getProperty(ChartConstants.HEIGHT));
 				} else {
 					IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.HEIGHT)));
 					fHeightParam.setSelectedItem(vp);
 				}
 			} else { // three datasources, partial mode
 				is_full = false;
 				CardLayout cl = (CardLayout) mainPanel.getLayout();
				cl.show(mainPanel,ChartConstants.PARTIAL);
				IDataSourceProducer dsp = config.getDataSource(ds[0]);
				xParam.setSelectedItem(dsp);
				dsp = config.getDataSource(ds[1]);
				yParam.setSelectedItem(dsp);
				dsp = config.getDataSource(ds[2]);
				shapeParam.setSelectedItem(dsp);
				r_user_defined_width = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_WIDTH));
				if (r_user_defined_width) 
					pWidthField.setText(properties.getProperty(ChartConstants.WIDTH));
				else {
					cl = (CardLayout) pWidthPanel.getLayout();
					cl.show(pWidthPanel,"P_DS_WIDTH");
 					IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.WIDTH)));
 					pWidthParam.setSelectedItem(vp);
				}
				r_user_defined_height = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
				if (r_user_defined_height) 
					pHeightField.setText(properties.getProperty(ChartConstants.HEIGHT));
				else {
					cl = (CardLayout) pHeightPanel.getLayout();
					cl.show(pHeightPanel,"P_DS_HEIGHT");
 					IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.HEIGHT)));
 					pHeightParam.setSelectedItem(vp);
				}
 			}
 			boolean row_order = Boolean.parseBoolean(properties.getProperty(ChartConstants.ROW_ORDER));
 			if (!row_order)
 				columnRadioButton.setSelected(true);
 			titleField.setText(properties.getProperty(ChartConstants.TITLE));
 			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
 			rowLabelField.setText(rowLabel);
 			columnLabelField.setText(columnLabel);
 			boolean tooltip = Boolean.parseBoolean(properties.getProperty(ChartConstants.TOOLTIP,"false"));
 			tooltipBox.setSelected(tooltip);
 			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
 			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
	 			int appIndex = (properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP)) ? 1 : 0;
	 			appearanceBox.setSelectedIndex(appIndex);
 			}
 			srp.settingsFromString(properties.getProperty(ChartConstants.SHAPE_RENDERER));
 			displayButton.setEnabled(true);
 			saveButton.setEnabled(true);
 		} else {
 			// set the initial properties
 			properties.setProperty(ChartConstants.USER_DEFINED_WIDTH,"false");
 			properties.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"false");
 			properties.setProperty(ChartConstants.ROW_ORDER,"true");
 			properties.setProperty(ChartConstants.TITLE,ChartConstants.SHAPEGRID2D_NAME);
 			properties.setProperty(ChartConstants.SUBTITLE,"");
 			properties.setProperty(ChartConstants.ROW_LABEL,"");
 			properties.setProperty(ChartConstants.COLUMN_LABEL,"");
 			properties.setProperty(ChartConstants.TOOLTIP,"false");
 			int appIndex = ChartConfigCollection.getEnvironmentAppearance().equals(ChartConstants.NORMAL_APP) ? 1 : 0;
 			appearanceBox.setSelectedIndex(appIndex);
 		}
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	public void updateChartConfig() {
 		config.clearAllDataSource();
 		if (is_full) { // one datasource, full mode
 			IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
			int key = -1;
 			if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) 
 				key = config.addDataSource(dsp,IGrid2DDatasetProducer.class);
 			else if (dsp.getSupportedIntfs().contains(ISeriesProducer.class)) 
 				key = config.addDataSource(dsp,ISeriesProducer.class);
 			else
 				key = config.addDataSource(dsp,IValueProducer.class);
 			properties.setProperty(ChartConstants.DATASOURCE,String.valueOf(key));
 			properties.setProperty(ChartConstants.USER_DEFINED_WIDTH,String.valueOf(user_defined_width));
 			if (user_defined_width)
 				properties.setProperty(ChartConstants.WIDTH,fWidthField.getText());
 			else {
 				dsp = (IDataSourceProducer) fWidthParam.getSelectedItem();
				if (dsp == null) {
 		 			properties.setProperty(ChartConstants.USER_DEFINED_WIDTH,"true");
 		 			properties.setProperty(ChartConstants.WIDTH,"");
 				} else {
 					if (dsp.getSupportedIntfs().contains(IValueProducer.class))  
 						key = config.addDataSource(dsp,IValueProducer.class);
 					else // need emulation
 						key = config.addDataSource(dsp,ISeriesProducer.class);
 					properties.setProperty(ChartConstants.WIDTH,String.valueOf(key));
 				}
 			}
 			properties.setProperty(ChartConstants.USER_DEFINED_HEIGHT,String.valueOf(user_defined_height));
 			if (user_defined_height)
 				properties.setProperty(ChartConstants.HEIGHT,fHeightField.getText());
 			else {
				dsp = (IDataSourceProducer) fHeightParam.getSelectedItem();
				if (dsp == null) {
 		 			properties.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"true");
 		 			properties.setProperty(ChartConstants.HEIGHT,"");
 				} else {
 					if (dsp.getSupportedIntfs().contains(IValueProducer.class))  
 						key = config.addDataSource(dsp,IValueProducer.class);
 					else // need emulation
 						key = config.addDataSource(dsp,ISeriesProducer.class);
 					properties.setProperty(ChartConstants.HEIGHT,String.valueOf(key));
 				}
 			}
 		} else { // three datasources, partial mode
 			String ds = "";
 			IDataSourceProducer dsp = (IDataSourceProducer) xParam.getSelectedItem();
 			int key = -1;
 			if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
 				key = config.addDataSource(dsp,ISeriesProducer.class);
 			else
 				key = config.addDataSource(dsp,IValueProducer.class);
 			ds = String.valueOf(key) + ",";
 			dsp = (IDataSourceProducer) yParam.getSelectedItem();
 			if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
 				key = config.addDataSource(dsp,ISeriesProducer.class);
 			else
 				key = config.addDataSource(dsp,IValueProducer.class);
 			ds += String.valueOf(key) + ",";
 			dsp = (IDataSourceProducer) shapeParam.getSelectedItem();
 			if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
 				key = config.addDataSource(dsp,ISeriesProducer.class);
 			else
 				key = config.addDataSource(dsp,IValueProducer.class);
 			ds += String.valueOf(key);
 			properties.setProperty(ChartConstants.DATASOURCE,ds);
 			properties.setProperty(ChartConstants.USER_DEFINED_WIDTH,String.valueOf(r_user_defined_width));
 			if (r_user_defined_width)
 				properties.setProperty(ChartConstants.WIDTH,pWidthField.getText());
 			else {
 				dsp = (IDataSourceProducer) pWidthParam.getSelectedItem();
 				if (dsp == null) {
 		 			properties.setProperty(ChartConstants.USER_DEFINED_WIDTH,"true");
 		 			properties.setProperty(ChartConstants.WIDTH,"");
 				} else {
	 				if (dsp.getSupportedIntfs().contains(IValueProducer.class))  
	 					key = config.addDataSource(dsp,IValueProducer.class);
	 				else // need emulation
	 					key = config.addDataSource(dsp,ISeriesProducer.class);
	 				properties.setProperty(ChartConstants.WIDTH,String.valueOf(key));
 				}
 			}
 			properties.setProperty(ChartConstants.USER_DEFINED_HEIGHT,String.valueOf(r_user_defined_height));
 			if (r_user_defined_height)
 				properties.setProperty(ChartConstants.HEIGHT,pHeightField.getText());
 			else {
				dsp = (IDataSourceProducer) pHeightParam.getSelectedItem();
 				if (dsp == null) {
 		 			properties.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"true");
 		 			properties.setProperty(ChartConstants.HEIGHT,"");
 				} else {
	 				if (dsp.getSupportedIntfs().contains(IValueProducer.class))  
	 					key = config.addDataSource(dsp,IValueProducer.class);
	 				else // need emulation
	 					key = config.addDataSource(dsp,ISeriesProducer.class);
	 				properties.setProperty(ChartConstants.HEIGHT,String.valueOf(key));
 				}
 			}
 		}
 		properties.setProperty(ChartConstants.TOOLTIP,String.valueOf(tooltipBox.isSelected()));
 		properties.setProperty(ChartConstants.SHAPE_RENDERER,srp.settingsToString());
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 1) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
			properties.setProperty(ChartConstants.ENV_APPEARANCE,(appearanceIndex == 0 ? ChartConstants.BASIC_APP : ChartConstants.NORMAL_APP));
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
 		config.setChartProperties(ChartConstants.SHAPEGRID2D,properties);
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	public boolean isUpdateable() {
 		if (!srp.hasDefinedRenderer()) return false;
 		if (is_full) {
 			if (valuesParam.getItemCount() == 0) return false;
 			IDataSourceProducer cdsp = (IDataSourceProducer) valuesParam.getSelectedItem();
 			if (cdsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) return true;
			boolean w_valid = (user_defined_width && is_valid(fWidthField.getText())) || (!user_defined_width && fWidthParam.getItemCount() > 0);
			boolean h_valid = (user_defined_height && is_valid(fHeightField.getText())) || (!user_defined_height && fHeightParam.getItemCount() > 0);
 			if (w_valid || h_valid) return true;
 		} else if (shapeParam.getItemCount() > 0) return true;
 		return false;
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	protected void displayPreview() throws Exception {
		DataSources ds = new DataSources(new SimpleDSPCollection());
		ChartConfig temp_config = new ChartConfig(ds);
		temp_config.setFireInitialEvent(true);
		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
		Properties temp_prop = (Properties) properties.clone();
		temp_prop.setProperty(ChartConstants.TITLE,temp_prop.getProperty(ChartConstants.TITLE) + " (Preview illustration)");
		if (is_full) {
			temp_config.addDataSource(dsl.get(2),ISeriesProducer.class);
			temp_prop.setProperty(ChartConstants.DATASOURCE,"1");
			if (!user_defined_width) {
				temp_prop.setProperty(ChartConstants.USER_DEFINED_WIDTH,"true");
				temp_prop.setProperty(ChartConstants.WIDTH,"3");
			}
			if (!user_defined_height) {
				temp_prop.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"true");
				temp_prop.setProperty(ChartConstants.HEIGHT,"4");
			}
		} else {
			temp_config.addDataSource(dsl.get(0),ISeriesProducer.class);
			temp_config.addDataSource(dsl.get(1),ISeriesProducer.class);
			temp_config.addDataSource(dsl.get(2),ISeriesProducer.class);
			temp_prop.setProperty(ChartConstants.DATASOURCE,"1,2,3");
			if (!r_user_defined_width) {
				temp_prop.setProperty(ChartConstants.USER_DEFINED_WIDTH,"true");
				temp_prop.setProperty(ChartConstants.WIDTH,"");
			}	
			if (!r_user_defined_height) {
				temp_prop.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"true");
				temp_prop.setProperty(ChartConstants.HEIGHT,"");
			}
		}
		temp_config.setChartProperties(ChartConstants.SHAPEGRID2D,temp_prop);
		Utilities.displayPreview(temp_config);
	}
 	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "B", "Basic"));
		appearances.add(new ComboboxItem( "N", "Normal"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem)appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		// reset widgets
		valuesParam.setEnabled(true);
		shapeParam.setEnabled(true);
		xParam.setEnabled(true);
		yParam.setEnabled(true);
		advancedButton.setEnabled(true);
		shapeAdvancedButton.setEnabled(true);
		xAdvancedButton.setEnabled(true);
		yAdvancedButton.setEnabled(true);
		fDsWidthButton.setEnabled(true);
		fDsHeightButton.setEnabled(true);
		pDsWidthButton.setEnabled(true);
		pDsHeightButton.setEnabled(true);
		fFixWidthButton.setEnabled(true);
		fFixHeightButton.setEnabled(true);
		pFixWidthButton.setEnabled(true);
		pFixHeightButton.setEnabled(true);
		fWidthParam.setEnabled(true);
		fHeightParam.setEnabled(true);
		pWidthParam.setEnabled(true);
		pHeightParam.setEnabled(true);
		
		Object valuesObject = valuesParam.getSelectedIndex() == -1 ? null : valuesParam.getSelectedItem();
		Object fWidthObject = fWidthParam.getSelectedIndex() == -1 ? null : fWidthParam.getSelectedItem();
		Object fHeightObject = fHeightParam.getSelectedIndex() == -1 ? null : fHeightParam.getSelectedItem();
		Object xObject = xParam.getSelectedIndex() == -1 ? null : xParam.getSelectedItem();
		Object yObject = yParam.getSelectedIndex() == -1 ? null : yParam.getSelectedItem();
		Object shapeObject = shapeParam.getSelectedIndex() == -1 ? null : shapeParam.getSelectedItem();
		Object pWidthObject = pWidthParam.getSelectedIndex() == -1 ? null : pWidthParam.getSelectedItem();
		Object pHeightObject = pHeightParam.getSelectedIndex() == -1 ? null : pHeightParam.getSelectedItem();
		
		DefaultComboBoxModel valuesModel = new DefaultComboBoxModel(getParamsToValues());
		valuesParam.setModel(valuesModel);
		DefaultComboBoxModel fDsWidthModel = new DefaultComboBoxModel(getParamsToDimensions());
		fWidthParam.setModel(fDsWidthModel);
		DefaultComboBoxModel fDsHeightModel = new DefaultComboBoxModel(getParamsToDimensions());
		fHeightParam.setModel(fDsHeightModel);
		DefaultComboBoxModel xModel = new DefaultComboBoxModel(getParamsToAll());
		xParam.setModel(xModel);
		DefaultComboBoxModel yModel = new DefaultComboBoxModel(getParamsToAll());
		yParam.setModel(yModel);
		DefaultComboBoxModel shapeModel = new DefaultComboBoxModel(getParamsToAll());
		shapeParam.setModel(shapeModel);
		DefaultComboBoxModel pDsWidthModel = new DefaultComboBoxModel(getParamsToDimensions());
		pWidthParam.setModel(pDsWidthModel);
		DefaultComboBoxModel pDsHeightModel = new DefaultComboBoxModel(getParamsToDimensions());
		pHeightParam.setModel(pDsHeightModel);

		if (valuesObject != null && findInComboBox(valuesModel,(IDataSourceProducer)valuesObject) != -1) {
			int idx = findInComboBox(valuesModel,(IDataSourceProducer)valuesObject);
			valuesParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (fWidthObject != null && findInComboBox(fDsWidthModel,(IDataSourceProducer)fWidthObject) != -1) {
			int idx = findInComboBox(fDsWidthModel,(IDataSourceProducer)fWidthObject);
			fWidthParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (fHeightObject != null && findInComboBox(fDsHeightModel,(IDataSourceProducer)fHeightObject) != -1) {
			int idx = findInComboBox(fDsHeightModel,(IDataSourceProducer)fHeightObject);
			fHeightParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (xObject != null && findInComboBox(xModel,(IDataSourceProducer)xObject) != -1) {
			int idx = findInComboBox(xModel,(IDataSourceProducer)xObject);
			xParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (yObject != null && findInComboBox(yModel,(IDataSourceProducer)yObject) != -1) {
			int idx = findInComboBox(yModel,(IDataSourceProducer)yObject);
			yParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (shapeObject != null && findInComboBox(shapeModel,(IDataSourceProducer)shapeObject) != -1) {
			int idx = findInComboBox(shapeModel,(IDataSourceProducer)shapeObject);
			shapeParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (pWidthObject != null && findInComboBox(pDsWidthModel,(IDataSourceProducer)pWidthObject) != -1) {
			int idx = findInComboBox(pDsWidthModel,(IDataSourceProducer)pWidthObject);
			pWidthParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (pHeightObject != null && findInComboBox(pDsHeightModel,(IDataSourceProducer)pHeightObject) != -1) {
			int idx = findInComboBox(pDsHeightModel,(IDataSourceProducer)pHeightObject);
			pHeightParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}		
		validate();
		setWidgetDisabled();
		
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}
	
	//-----------------------------------------------------------------------------
	/** Updates the labels of the row/column with the name of the x and y components 
	 * (only in random mode). If the user changes to sequential mode, the labels
	 *  return to the default settings (empty strings).
	 */ 
	private void updateRowAndColumnLabels() {
		if (is_full) {
			columnLabelField.setText("");
			rowLabelField.setText("");
		} else {
			columnLabelField.setText(xParam.getSelectedItem().toString());
			rowLabelField.setText(yParam.getSelectedItem().toString());
		}
		properties.setProperty(ChartConstants.COLUMN_LABEL,columnLabelField.getText());
		properties.setProperty(ChartConstants.ROW_LABEL,rowLabelField.getText());
	}
}