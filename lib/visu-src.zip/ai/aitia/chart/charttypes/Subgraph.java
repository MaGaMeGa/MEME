/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes;

import java.awt.Container;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.SubgraphDialog;
import ai.aitia.chart.ds.GraphDatasetProducer;
import ai.aitia.chart.ds.IStringListProducer;
import ai.aitia.chart.emulator.ProducerEmulator;
import ai.aitia.chart.networkpanel.NetworkPanel;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLLoadingException.TemplateLoadingException;
import ai.aitia.chart.view.meta.SubgraphMetadata;
import ai.aitia.visu.VisualisationException;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDataProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.ds.IXYSeriesProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.view.meta.Appearance;
import ai.aitia.visu.view.meta.CustomAppearance;

/** Interactive graph type. A graph is a set of items connected by edges. A subgraph
 *  shows only a part of a graph. The user can define an item and a depth value and
 *  the subgraph shows the given item and his neighbours in the given depth. The user
 *  can change dinamically the selected item, so complex graphs can be walked through
 *  in an interactive way.
 */ 
public class Subgraph extends AbstractChart {

	@Override
	public Container createChart(ChartConfig config) throws DataSourceException, VisualisationException {
		if (config.getChartProperties() instanceof Properties) {
			
			Properties properties = (Properties) config.getChartProperties();
			
			SubgraphMetadata meta = new SubgraphMetadata();
			meta.setTitle(properties.getProperty(ChartConstants.TITLE));
			meta.setSubtitle(properties.getProperty(ChartConstants.SUBTITLE));
			meta.setDepth(Integer.parseInt(properties.getProperty(ChartConstants.DEPTH)));
			meta.setRootIndex(Integer.parseInt(properties.getProperty(ChartConstants.ROOT_INDEX)));
			
			String templateName = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			boolean needDefault = true;
			if (templateName != null && !"".equals(templateName)) {
				Element template = templates.get(templateName);
				if (template != null) {
					try {
						CustomAppearance appearance = createCustomAppearance(template);
						meta.setCustomAppearance(appearance);
						needDefault = false;
					} catch (TemplateLoadingException e) {
						throw new VisualisationException(e);
					}
				}
			}
			if (needDefault) {
				int color = Appearance.COLORED;
				if (properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE))
					color = Appearance.BLACK_AND_WHITE;
				meta.setColorAppearance(color);
			}
			
			int nr_of_nodes = Integer.parseInt(properties.getProperty(ChartConstants.NR_OF_NODES));
			boolean user_defined_number = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_NUMBER,"true"));
		
			GraphDatasetProducer gdsp = null;
			IXYSeriesProducer xysp = null;
			IDataProducer lp = null;
			IValueProducer vp = null;
			List<Object> data = new ArrayList<Object>(3);
			
			String[] ds = properties.getProperty(ChartConstants.DATASOURCE).split(",");
			int[] eds = Utilities.splitDatasourceAroundSpace(ds[0]);
			if (eds.length == 1) { //IXYSeriesProducer supported
				IDataSourceProducer dsp = config.getDataSource(eds[0]);
				xysp = (IXYSeriesProducer)dsp.createDataProducer(config.getDataSourceType(eds[0]),null);
				data.add(xysp);
			} else { // only ISeriesProducer or IValueProducer supported
				IDataSourceProducer sdsp = config.getDataSource(eds[0]);
				IDataSourceProducer ddsp = config.getDataSource(eds[1]);
				IDataProducer sp = sdsp.createDataProducer(config.getDataSourceType(eds[0]),null);
				IDataProducer dp = ddsp.createDataProducer(config.getDataSourceType(eds[1]),null);
				List<IDataProducer> p = new ArrayList<IDataProducer>();
				p.add(sp);
				p.add(dp);
				xysp = (IXYSeriesProducer)ProducerEmulator.createProducer(p,IXYSeriesProducer.class);
				data.add(xysp);
			}
			if (user_defined_number)
				data.add(new Integer(nr_of_nodes));
			else {
				IDataSourceProducer ndsp = config.getDataSource(nr_of_nodes);
				IDataProducer idp = ndsp.createDataProducer(config.getDataSourceType(nr_of_nodes),null);
				if (idp instanceof IValueProducer)
					vp = (IValueProducer)idp;
				else {
					List<IDataProducer> p = new ArrayList<IDataProducer>();
					p.add(idp);
					vp = (IValueProducer)ProducerEmulator.createProducer(p,IValueProducer.class);
				}
				data.add(vp);
			}
			if (ds.length == 1) { // no labels
				meta.setHasVertexLabels(false);
				gdsp = new GraphDatasetProducer(data,false);
			} else { // has labels
				meta.setHasVertexLabels(true);
				IDataSourceProducer ldsp = config.getDataSource(Integer.parseInt(ds[1]));
				lp = ldsp.createDataProducer(config.getDataSourceType(Integer.parseInt(ds[1])),null);
				if (lp instanceof IStringListProducer) {
					data.add(lp);
					gdsp = new GraphDatasetProducer(data,false);
				} else {
					List<IDataProducer> p = new ArrayList<IDataProducer>();
					p.add(lp);
					IStringListProducer slp = (IStringListProducer)ProducerEmulator.createProducer(p,IStringListProducer.class);
					lp = slp;
					data.add(slp);
					gdsp = new GraphDatasetProducer(data,false);
				}
			}
			
			NetworkPanel panel = new NetworkPanel(gdsp,meta,Double.parseDouble(properties.getProperty(ChartConstants.VERTEX_SIZE_PERCENTAGE,"100")));
			if (config.isFireInitialEvent()) {
				gdsp.dataChanged(new DataChangeEvent(xysp));
				if (lp != null) gdsp.dataChanged(new DataChangeEvent(lp));
				if (vp != null) gdsp.dataChanged(new DataChangeEvent(vp));
			}
			return panel;
		}
		return null;
	}

	//-------------------------------------------------------------------------------
	@Override
	public Container createDialog(ChartConfig config, ChartConfigCollection collection) {
		return new SubgraphDialog(config,collection);
	}

	//-------------------------------------------------------------------------------
	@Override
	public String getID() {
		return ChartConstants.SUBGRAPH;
	}
	
	//-------------------------------------------------------------------------------
	@Override
	public String getDescription() {
		return "A graph is a set of items connected by edges. A subgraph shows only a" +
				" part of a graph. The user can define an item and a depth value and" +
				" the subgraph shows the given item and his neighbours in the given depth. The" +
				" user can change dinamically the selected item, so complex graphs can" +
				" be walked through in an interactive way.";
	}

	//-------------------------------------------------------------------------------
	@Override
	public String toString() {
		return ChartConstants.SUBGRAPH_NAME;
	}

	//-------------------------------------------------------------------------------
	@Override
	public List<Integer> getDataSourceIDs(ChartConfig config) {
		List<Integer> result = new ArrayList<Integer>();
		if (config.getChartProperties() instanceof Properties) {
			Properties prop = (Properties) config.getChartProperties();
			boolean user_defined_number = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_NUMBER,"true"));
			if (!user_defined_number) {
				int key = Integer.parseInt(prop.getProperty(ChartConstants.NR_OF_NODES));
				result.add(key);
			}
			String[] ds = prop.getProperty(ChartConstants.DATASOURCE).split(",");
			for (int i=0;i<ds.length;++i) {
				int[] ids = Utilities.splitDatasourceAroundSpace(ds[i]);
				for (int j=0;j<ids.length;++j) {
					Integer candidate = new Integer(ids[j]);
					result.add(candidate);
				}
			} 
		}
		return result;
	}
}
