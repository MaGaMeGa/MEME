/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.ds;


import java.util.List;
import java.util.Properties;

import org.jfree.data.general.Dataset;

import ai.aitia.chart.util.Utilities.IGridConstants;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDatasetProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.data.Grid2DDataset;
import ai.aitia.visu.data.DefaultGrid2DDataset;
import ai.aitia.visu.data.ScalarMapGrid2DDataset;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.event.IDataChangeListener;

/** Dataset producer for two-dimensional grids. */
public class Grid2DDatasetProducer implements IDatasetProducer,
											  IDataChangeListener,
											  IGridConstants {
	
	/** Time of the last update. */
	private long time;
	
	/** The dataset that this object produces. */
	private Grid2DDataset dataset = null;
	
	/** Series producer for color/shape values. */
	private ISeriesProducer values = null;
	
	/** The current produced values for colors/shapes. */ 
	private List<Double> values_series = null;
	
	/** Series producer for column indices (used only in random mode). */
	private ISeriesProducer xs = null;
	
	/** The current produced values for column indices (used only in random mode). */
	private List<Double> xs_series = null;
	
	/** Series producer for row indices (used only in random mode). */
	private ISeriesProducer ys = null;
	
	/** The current producer values for row indices (used only in random mode). */
	private List<Double> ys_series = null;
	
	/** Complete dataset producer (used only in dataset mode). */
	private IGrid2DDatasetProducer ds_producer = null;
	
	/** The current complete grid produced by <code>ds_producer</code>
	 * (used only in dataset mode). */
	private double[][] ds_producer_dataset = new double[0][0];
	
	/** Value producer for width of the grid. */
	private IValueProducer width_producer = null;
	
	/** The current produced value for width of the grid or a fix width value. */
	private int width = -1;
	
	/** Value producer for height of the grid. */
	private IValueProducer height_producer = null;
	
	/** The current produced value for height of the grid or a fix height value. */ 
	private int height = -1;
	
	/** Flag that determines whether uses row order (left-to-right or column order
	 *  (top-to-bottom) when it places the values (used only in sequential mode). */
	private boolean row_order = true;
	
	/** Mode of the dataset producer object. (FULL_MODE, PARTIAL_MODE or DS_MODE. */
	private int mode = -1;
	
	//===============================================================================
	// methods
	
	/** Constructor. It uses the ai.aitia.visu.data.DefaultGrid2DDataset implementation.
	 *  The content of the list parameter must be the follow:<br>
	 *    - a series producer that produces the color/shape values of the cells<br>
	 *    - an Integer value or a value producer for the width of the grid<br>
	 *    - an Integer value or a value producer for the height of the grid<p>
	 *    
	 *  If both width and height is a fix value then one of them must be non-negative. The 
	 *  other one can be computed from this one and the length of the series produced by
	 *  the series producer. If both of them are invalud then the constructor throws an
	 *  exception. 
	 *
	 * @param data list with contents described above
	 * @param row_order whether uses row order (left-to-right) or column order (top-to-bottom)
	 *        when it places the values
	 * @throws DataSourceException it throws this exception if it cannot construct the 
	 *         the dataset from the input parameters.
	 */
	public Grid2DDatasetProducer(List<Object> data, boolean row_order) throws DataSourceException {
		if (data.size() < 3) throw new DataSourceException("Missing input parameters!");
		
		time = System.currentTimeMillis();
		mode = FULL_MODE;
		dataset = new DefaultGrid2DDataset(0,0);
		this.row_order = row_order;
		if (data.get(0) instanceof ISeriesProducer) {
			this.values = (ISeriesProducer)data.get(0);
			this.values.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid color/shape values parameter!");
		if (data.get(1) instanceof Integer) this.width = ((Integer)data.get(1)).intValue();
		else if (data.get(1) instanceof IValueProducer) {
			this.width_producer = (IValueProducer)data.get(1);
			this.width_producer.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid width parameter!");
		if (data.get(2) instanceof Integer) this.height = ((Integer)data.get(2)).intValue();
		else if (data.get(2) instanceof IValueProducer) {
			this.height_producer = (IValueProducer)data.get(2);
			this.height_producer.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid height parameter!");
		if (width_producer == null && height_producer == null &&
			width < 0 && height < 0) throw new DataSourceException("Invalid dimension parameter(s)!");
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor. It uses the ai.aitia.visu.data.DefaultGrid2DDataset implementation.
	 * 
	 * @param ds_producer producer that produces a complete grid.
	 */
	public Grid2DDatasetProducer(IGrid2DDatasetProducer ds_producer) {
	  time = System.currentTimeMillis();
	  mode = DS_MODE;
	  dataset = new DefaultGrid2DDataset(0,0);
	  this.ds_producer = ds_producer;
	  this.ds_producer.addDataChangeListener(this);
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor. It uses the ai.aitia.visu.data.ScalarMapGrid2DDataset implementation.
	 *  The content of the list parameter must be the follow:<br>
	 *    - a series producer that produces the column indices of the valueable elements
	 *      of the grid<br>
	 *    - a series producer that produces the row indices of the valueable elements
	 *      of the grid<br>
	 *    - a series producer that produces the color/shape values of the cells<br>
	 *    - an Integer value or a value producer for the width of the grid<br>
	 *    - an Integer value or a value producer for the height of the grid<p>
	 *  
	 *  This implementation uses automatic dimensions in default case, but if the width
	 *  and/or height parameters are non-negative integers or value producers, it will
	 *  use the appropriate values. In this case the values with greater column index 
	 *  than <i>width value</i>-1 and/or with greater row index than <i>height value</i>
	 *  -1 will be ignored.
	 *
	 * @param data list with contents described above
	 * @throws DataSouceException it throws this exception if it cannot construct the 
	 *         the dataset from the input parameters. 
	 */
	public Grid2DDatasetProducer(List<Object> data) throws DataSourceException {
		if (data.size() < 5) throw new DataSourceException("Missing input parameters!");
		
		time = System.currentTimeMillis();
		mode = PARTIAL_MODE;
		
		dataset = new ScalarMapGrid2DDataset();
		if (data.get(0) instanceof ISeriesProducer) {
			this.xs = (ISeriesProducer)data.get(0);
			this.xs.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid column indices parameter!");
		if (data.get(1) instanceof ISeriesProducer) {
			this.ys = (ISeriesProducer)data.get(1);
			this.ys.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid row indices parameter!");
		if (data.get(2) instanceof ISeriesProducer) {
			this.values = (ISeriesProducer)data.get(2);
			this.values.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid color/shape values parameter!");
		if (data.get(3) instanceof Integer) this.width = ((Integer)data.get(3)).intValue();
		else if (data.get(3) instanceof IValueProducer) {
			this.width_producer = (IValueProducer)data.get(3);
			this.width_producer.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid width parameter!");
		if (data.get(4) instanceof Integer) this.height = ((Integer)data.get(4)).intValue();
		else if (data.get(4) instanceof IValueProducer) {
			this.height_producer = (IValueProducer)data.get(4);
			this.height_producer.addDataChangeListener(this);
		} else throw new DataSourceException("Invalud height parameter!");
		
		if (width_producer == null && width > 0) ((ScalarMapGrid2DDataset)dataset).setWidth(width);
		if (height_producer == null && height > 0) ((ScalarMapGrid2DDataset)dataset).setHeight(height);
		
		((ScalarMapGrid2DDataset)dataset).setDefaultValue(-Double.MAX_VALUE);
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the time of the last update. */
	public long getTime() {
		return time;
	}

	//-------------------------------------------------------------------------------
	/** Produces the dataset. This implementation of the method does not use the <code>
	 *  queryProperties</code> parameter and does not throw exception.
	 */  
	public Dataset produceDataset(Properties queryProperties)
			throws DataSourceException {
		return dataset;
	}
	
	//-------------------------------------------------------------------------------
	/** Updates the dataset. In full mode, if both width and height are valid
	 *  (produced or fix) values and the length of values' series is less than 
	 *  width x height then the method uses the default <code>- Double.MAX_VALUE</code>
	 *  value to fill the empty places.
	 * @param event event
	 */
	public void dataChanged(DataChangeEvent event) {
		Object source = event.getSource();
		if (source.equals(values)) {
			ISeriesProducer p = (ISeriesProducer)source; 
			values_series = p.produceSeries();
			if (p.equals(xs)) xs_series = values_series;
			if (p.equals(ys)) ys_series = values_series;
			time = p.getTime();
		} else if (source.equals(xs)) {
			ISeriesProducer p = (ISeriesProducer)source; 
			xs_series = p.produceSeries();
			if (p.equals(ys)) ys_series = xs_series;
			time = p.getTime();
		} else if (source.equals(ys)) {
			ISeriesProducer p = (ISeriesProducer)source; 
			ys_series = p.produceSeries();
			time = p.getTime();
		} else if (source.equals(width_producer)) {
			IValueProducer p = (IValueProducer)source;
			width = Math.abs((int)p.produceValue()); // get absolute value to avoid negative dimension
			if (width == 0) 
				throw new IllegalStateException("Illegal dimension value: zero");
			if (width_producer.equals(height_producer)) 
				height = width;
			time = p.getTime();
			if (dataset instanceof ScalarMapGrid2DDataset) {
				ScalarMapGrid2DDataset ds = (ScalarMapGrid2DDataset)dataset;
				ds.setWidth(width);
				if (width_producer.equals(height_producer)) 
					ds.setHeight(height);
			}
		} else if (source.equals(height_producer)) {
			IValueProducer p = (IValueProducer)source;
			height = Math.abs((int)p.produceValue()); // get absolute value to avoid negative dimension
			if (height == 0) 
				throw new IllegalStateException("Illegal dimension value: zero");
			if (dataset instanceof ScalarMapGrid2DDataset) {
				ScalarMapGrid2DDataset ds = (ScalarMapGrid2DDataset) dataset;
				ds.setHeight(height);
			}
		} else if (source.equals(ds_producer)) {
			IGrid2DDatasetProducer p = (IGrid2DDatasetProducer)source;
			try {
				ds_producer_dataset = ((Grid2DDataset)p.produceDataset(null)).getValues();
			} catch (DataSourceException e) {
				// wrong dataset => no update
				return;
			}
			time = p.getTime();
		} else return;
		
		if (mode == FULL_MODE) {
			if (values_series == null) return;
			int _width, _height;
			if (width<=0) {
				_height = height;
				_width = values_series.size()%_height == 0 ? values_series.size()/_height :
															 values_series.size()/_height+1;
			} else if (height<=0) {
				_width = width;
				_height = values_series.size()%_width == 0 ? values_series.size()/_width :
															 values_series.size()/_width+1;
			} else {
				_width = width;
				_height = height;
			}
			
			double[][] data = null;
			if (row_order) {
				data = new double[_width][_height];
				for (int i=0;i<_height;++i) {
					for (int j=0;j<_width;++j) {
						data[j][i] = (i*_width+j<values_series.size() ? values_series.get(i*_width+j).doubleValue()
																	  : - Double.MAX_VALUE);
					}
				}
			} else {
				data = new double[_width][_height];
				for (int i=0;i<_width;++i) {
					for (int j=0;j<_height;++j) {
						data[i][j] = (i*_height+j<values_series.size() ? values_series.get(i*_height+j).doubleValue()
																	   : - Double.MAX_VALUE);
					}
				}
			}
			((DefaultGrid2DDataset)dataset).setValues(data);
			((DefaultGrid2DDataset)dataset).fireDatasetChanged();
		} else if (mode == PARTIAL_MODE) {
			if (xs_series == null || ys_series == null || values_series == null) return;
			((ScalarMapGrid2DDataset)dataset).clear();
			int length = (xs_series.size() > ys_series.size() ? ys_series.size() : xs_series.size());
			if  (length > values_series.size()) length = values_series.size();
			for (int i=0;i<length;++i) {
				((ScalarMapGrid2DDataset)dataset).addItem(xs_series.get(i).intValue(),(int)ys_series.get(i).intValue(),values_series.get(i).doubleValue());
			}
			((ScalarMapGrid2DDataset)dataset).fireDatasetChanged();
		} else if (mode == DS_MODE) {
			((DefaultGrid2DDataset)dataset).setValues(ds_producer_dataset);
			((DefaultGrid2DDataset)dataset).fireDatasetChanged();
		}
	}
}