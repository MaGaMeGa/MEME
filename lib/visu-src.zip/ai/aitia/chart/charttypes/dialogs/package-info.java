/** This package contains the GUI component classes of the available chart types. */
package ai.aitia.chart.charttypes.dialogs;