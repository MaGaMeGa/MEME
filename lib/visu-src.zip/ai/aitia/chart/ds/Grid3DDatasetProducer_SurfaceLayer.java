package ai.aitia.chart.ds;

import java.util.List;

import ai.aitia.chart.ds.IGrid3DDatasetProducer;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.event.DataChangeEvent;

import ai.aitia.visu.data.DefaultGrid3DDataset;
import ai.aitia.visu.data.DefaultGrid3DDataset_SurfaceLayer;
import ai.aitia.visu.data.Grid3DDataset;
import ai.aitia.visu.data.ScalarMapGrid3DDataset_SurfaceLayer;

public class Grid3DDatasetProducer_SurfaceLayer extends Grid3DDatasetProducer  {
	
	/** The current produced values for shapes. */ 
//	private List<Double> shape_values_series = null;
	
	public Grid3DDatasetProducer_SurfaceLayer(List<Object> data, boolean row_order) throws DataSourceException {
		if (data.size() < 4) throw new DataSourceException("Missing input parameters!");
		
		
		time = System.currentTimeMillis();
		mode = FULL_MODE;
		dataset = new DefaultGrid3DDataset_SurfaceLayer(0,0);
		this.row_order = row_order;
		
		if (data.get(0) instanceof ISeriesProducer) {
			this.zvalue_values = (ISeriesProducer)data.get(0);
			this.zvalue_values.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid z value values parameter!");
		if (data.get(1) instanceof ISeriesProducer) {
			this.color_values = (ISeriesProducer)data.get(1);
			this.color_values.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid color values parameter!");
		
		if (data.get(2) instanceof Integer) this.width = ((Integer)data.get(2)).intValue();
		else if (data.get(2) instanceof IValueProducer) {
			this.width_producer = (IValueProducer)data.get(2);
			this.width_producer.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid width parameter!");
		if (data.get(3) instanceof Integer) this.height = ((Integer)data.get(3)).intValue();
		else if (data.get(3) instanceof IValueProducer) {
			this.height_producer = (IValueProducer)data.get(3);
			this.height_producer.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid height parameter!");
		if (width_producer == null && height_producer == null &&
			width < 0 && height < 0) throw new DataSourceException("Invalid dimension parameter(s)!");
	}
	
	public Grid3DDatasetProducer_SurfaceLayer(IGrid3DDatasetProducer ds_producer) {
		  time = System.currentTimeMillis();
		  mode = DS_MODE;
		  dataset = new DefaultGrid3DDataset_SurfaceLayer(0,0);
		  this.ds_producer = ds_producer;
		  this.ds_producer.addDataChangeListener(this);
		}
	
	public Grid3DDatasetProducer_SurfaceLayer(List<Object> data) throws DataSourceException {
		if (data.size() < 6) throw new DataSourceException("Missing input parameters!");
		
		
		time = System.currentTimeMillis();
		mode = PARTIAL_MODE;
		dataset = new ScalarMapGrid3DDataset_SurfaceLayer();
		if (data.get(0) instanceof ISeriesProducer) {
			this.xs = (ISeriesProducer)data.get(0);
			this.xs.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid column indices parameter!");
		if (data.get(1) instanceof ISeriesProducer) {
			this.ys = (ISeriesProducer)data.get(1);
			this.ys.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid row indices parameter!");
		
		if (data.get(2) instanceof ISeriesProducer) {
			this.zvalue_values = (ISeriesProducer)data.get(2);
			this.zvalue_values.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid zvalue values parameter!");
		if (data.get(3) instanceof ISeriesProducer) {
			this.color_values = (ISeriesProducer)data.get(3);
			this.color_values.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid color values parameter!");
		
		if (data.get(4) instanceof Integer) this.width = ((Integer)data.get(4)).intValue();
		else if (data.get(4) instanceof IValueProducer) {
			this.width_producer = (IValueProducer)data.get(4);
			this.width_producer.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid width parameter!");
		if (data.get(5) instanceof Integer) this.height = ((Integer)data.get(5)).intValue();
		else if (data.get(5) instanceof IValueProducer) {
			this.height_producer = (IValueProducer)data.get(5);
			this.height_producer.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid height parameter!");
		
		if (width_producer == null && width > 0) ((ScalarMapGrid3DDataset_SurfaceLayer)dataset).setWidth(width);
		if (height_producer == null && height > 0) ((ScalarMapGrid3DDataset_SurfaceLayer)dataset).setHeight(height);
		
		((ScalarMapGrid3DDataset_SurfaceLayer)dataset).setDefaultValue(-Double.MAX_VALUE);
	}
	


	@Override
	public void dataChanged(DataChangeEvent event) {
		Object source = event.getSource();
		if (source.equals(zvalue_values)) {
			ISeriesProducer p = (ISeriesProducer)source; 
			zvalue_values_series = p.produceSeries();
			if (p.equals(xs)) xs_series = zvalue_values_series;
			if (p.equals(ys)) ys_series = zvalue_values_series;
			if (p.equals(color_values)) color_values_series = zvalue_values_series;
			time = p.getTime();
		} else if (source.equals(color_values)) {
			ISeriesProducer p = (ISeriesProducer)source; 
			color_values_series = p.produceSeries();
			if (p.equals(xs)) xs_series = color_values_series;
			if (p.equals(ys)) ys_series = color_values_series;
			time = p.getTime();
		} else if (source.equals(xs)) {
			ISeriesProducer p = (ISeriesProducer)source; 
			xs_series = p.produceSeries();
			if (p.equals(ys)) ys_series = xs_series;
			time = p.getTime();
		} else if (source.equals(ys)) {
			ISeriesProducer p = (ISeriesProducer)source; 
			ys_series = p.produceSeries();
			time = p.getTime();
		} else if (source.equals(width_producer)) {
			IValueProducer p = (IValueProducer)source;
			width = Math.abs((int)p.produceValue()); // get absolute value to avoid negative dimension
			if (width == 0) 
				throw new IllegalStateException("Illegal dimension value: zero");
			if (width_producer.equals(height_producer)) 
				height = width;
			time = p.getTime();
			if (dataset instanceof ScalarMapGrid3DDataset_SurfaceLayer) {
				ScalarMapGrid3DDataset_SurfaceLayer ds = (ScalarMapGrid3DDataset_SurfaceLayer)dataset;
				ds.setWidth(width);
				if (width_producer.equals(height_producer)) 
					ds.setHeight(height);
			}
		} else if (source.equals(height_producer)) {
			IValueProducer p = (IValueProducer)source;
			height = Math.abs((int)p.produceValue()); // get absolute value to avoid negative dimension
			if (height == 0) 
				throw new IllegalStateException("Illegal dimension value: zero");
			if (dataset instanceof ScalarMapGrid3DDataset_SurfaceLayer) {
				ScalarMapGrid3DDataset_SurfaceLayer ds = (ScalarMapGrid3DDataset_SurfaceLayer) dataset;
				ds.setHeight(height);
			}
		} else if (source.equals(ds_producer)) {
			IGrid3DDatasetProducer p = (IGrid3DDatasetProducer)source;
			try {
				ds_producer_dataset = ((Grid3DDataset)p.produceDataset(null)).getValues();
			} catch (DataSourceException e) {
				// wrong dataset => no update
				return;
			}
			time = p.getTime();
		} else return;
		
		if (mode == FULL_MODE) {
			if (zvalue_values_series == null || color_values_series == null) return;
			int _width, _height;
			if (width<=0) {
				_height = height;
				_width = zvalue_values_series.size()%_height == 0 ? zvalue_values_series.size()/_height :
															 zvalue_values_series.size()/_height+1;
			} else if (height<=0) {
				_width = width;
				_height = zvalue_values_series.size()%_width == 0 ? zvalue_values_series.size()/_width :
															 zvalue_values_series.size()/_width+1;
			} else {
				_width = width;
				_height = height;
			}
			
			double[][][] data = null;
			if (row_order) {
				data = new double[_width][_height][3];
				for (int i=0;i<_height;++i) {
					for (int j=0;j<_width;++j) {
						data[j][i][0] = (i*_width+j<zvalue_values_series.size() ? zvalue_values_series.get(i*_width+j).doubleValue()
																	  : - Double.MAX_VALUE);
						data[j][i][1] = (i*_width+j<color_values_series.size() ? color_values_series.get(i*_width+j).doubleValue()
								  									  : - Double.MAX_VALUE);
					}
				}
			} else {
				data = new double[_width][_height][3];
				for (int i=0;i<_width;++i) {
					for (int j=0;j<_height;++j) {
						data[i][j][0] = (i*_height+j<zvalue_values_series.size() ? zvalue_values_series.get(i*_height+j).doubleValue()
								  									  : - Double.MAX_VALUE);
						data[i][j][1] = (i*_height+j<color_values_series.size() ? color_values_series.get(i*_height+j).doubleValue()
								  									  : - Double.MAX_VALUE);
					}
				}
			}
			((DefaultGrid3DDataset)dataset).setValues(data);
			((DefaultGrid3DDataset)dataset).fireDatasetChanged();
		} else if (mode == PARTIAL_MODE) {
			if (xs_series == null || ys_series == null || color_values_series == null || zvalue_values_series == null) return;
			((ScalarMapGrid3DDataset_SurfaceLayer)dataset).clear();
			int length = (xs_series.size() > ys_series.size() ? ys_series.size() : xs_series.size());
			if  (length > zvalue_values_series.size()) length = zvalue_values_series.size();
			if  (length > color_values_series.size()) length = color_values_series.size();
			for (int i=0;i<length;++i) {
				((ScalarMapGrid3DDataset_SurfaceLayer)dataset).addItem(xs_series.get(i).intValue(),(int)ys_series.get(i).intValue(),zvalue_values_series.get(i).doubleValue(),color_values_series.get(i).doubleValue());
			}
			((ScalarMapGrid3DDataset_SurfaceLayer)dataset).fireDatasetChanged();
		} else if (mode == DS_MODE) {
			((DefaultGrid3DDataset)dataset).setValues(ds_producer_dataset);
			((DefaultGrid3DDataset)dataset).fireDatasetChanged();
		}
	}
}
