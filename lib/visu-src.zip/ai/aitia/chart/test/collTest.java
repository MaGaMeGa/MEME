/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.test;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.skin.ModerateSkin;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.visu.utils.Utils;

/** A test program for MEME's chart dialogs.
 * 
 * @author Bocsi Rajmund (rbocsi@aitia.ai)
 *
 */
public class collTest {

	public static JPanel createContentPane(final JFrame parent) {
		final JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout());
		panel.setBorder(BorderFactory.createTitledBorder("Operations"));
		JButton newButton = new JButton("New");
		newButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					final JFrame frame = new JFrame("New Collection");
					frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					frame.addComponentListener(new ComponentAdapter() {
						@Override
						public void componentHidden(ComponentEvent e) {
							frame.dispose();
						}
					});
					DataSources ds = new DataSources(new SimpleDSPCollection());
					ChartConfigCollection ccc = new ChartConfigCollection(ds,false);
					ccc.setDefaultFireInitialEvent(true);
					Container panel = ccc.createDialog();
					final JScrollPane sp = new JScrollPane(panel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
					sp.setBorder(null);
					frame.setContentPane(sp);
					frame.pack();
					Dimension oldD = frame.getPreferredSize();
					frame.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
						             		     		 oldD.height + sp.getHorizontalScrollBar().getHeight()));
					sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
					sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
					oldD = frame.getPreferredSize();
					final Dimension newD = Utils.getPreferredSize(frame);
					if (!oldD.equals(newD)) 
						frame.setPreferredSize(newD);
					frame.pack();
					frame.setVisible(true);
				} catch (HeadlessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		JButton ldButton = new JButton("Load&Display...");
		ldButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File file = charTest.load(parent);
				if (file == null) return;
				ChartConfigCollection ccc = null;
				try {
					ccc = ChartConfigCollection.load(file.toURI(),new SimpleDSPCollection());
					for (Object o : ccc) {
						ChartConfig cc = (ChartConfig)o;
						Container panel = AbstractChart.display(cc);
						JFrame frame = new JFrame(cc.getChartType());
						final JScrollPane sp = new JScrollPane(panel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
						sp.setBorder(null);
						frame.setContentPane(sp);
						frame.pack();
						Dimension oldD = frame.getPreferredSize();
						frame.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
							             		     		 oldD.height + sp.getHorizontalScrollBar().getHeight()));
						sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
						sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
						oldD = frame.getPreferredSize();
						final Dimension newD = Utils.getPreferredSize(frame);
						if (!oldD.equals(newD)) 
							frame.setPreferredSize(newD);
						frame.pack();
						frame.setVisible(true);
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		JButton lmButton = new JButton("Load&Modify...");
		lmButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File file = charTest.load(parent);
				if (file == null) return;
				ChartConfigCollection ccc = null;
				try {
					ccc = ChartConfigCollection.load(file.toURI(),new SimpleDSPCollection());
					ccc.setDefaultFireInitialEvent(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				final JFrame frame = new JFrame("New Collection");
				frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				frame.addComponentListener(new ComponentAdapter() {
					@Override
					public void componentHidden(ComponentEvent e) {
						frame.dispose();
					}
				});
				Container panel = ccc.createDialog();
				final JScrollPane sp = new JScrollPane(panel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				sp.setBorder(null);
				frame.setContentPane(sp);
				frame.pack();
				Dimension oldD = frame.getPreferredSize();
				frame.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
					             		     		 oldD.height + sp.getHorizontalScrollBar().getHeight()));
				sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
				sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				oldD = frame.getPreferredSize();
				final Dimension newD = Utils.getPreferredSize(frame);
				if (!oldD.equals(newD)) 
					frame.setPreferredSize(newD);
				frame.pack();
				frame.setVisible(true);
			} 
		});
		panel.add(newButton);
		panel.add(ldButton);
		panel.add(lmButton);
		return panel;
	}
	
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				AbstractChart.registerAll();
				try {
					System.setProperty("substancelaf.noExtraElements", "");
					UIManager.setLookAndFeel(new SubstanceLookAndFeel());
					SubstanceLookAndFeel.setSkin(new ModerateSkin());
					System.setProperty("sun.awt.noerasebackground","true");
				} catch (UnsupportedLookAndFeelException e1) {
					e1.printStackTrace();
				}
				JFrame frame = new JFrame("TestCollection");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setContentPane(collTest.createContentPane(frame));
				frame.pack();
				frame.setVisible(true);
			}
		});
	}
}
