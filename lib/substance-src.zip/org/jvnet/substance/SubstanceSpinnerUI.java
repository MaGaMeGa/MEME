/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.Component;
import java.awt.Dimension;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashSet;
import java.util.Set;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicSpinnerUI;

import org.jvnet.substance.utils.FocusBorderListener;
import org.jvnet.substance.utils.SubstanceCoreUtilities;
import org.jvnet.substance.utils.SubstanceConstants.Side;

/**
 * UI for spinners in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceSpinnerUI extends BasicSpinnerUI {
	/**
	 * Focus listener.
	 */
	protected FocusBorderListener substanceFocusListener;

	/**
	 * Tracks changes to editor, removing the border as necessary.
	 */
	protected PropertyChangeListener substancePropertyChangeListener;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new SubstanceSpinnerUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSpinnerUI#createNextButton()
	 */
	@Override
	protected Component createNextButton() {
		JComponent c = new SubstanceSpinnerButton(this.spinner,
				SubstanceImageCreator.getArrowIcon(7, 5, SwingConstants.NORTH,
						SubstanceCoreUtilities.getActiveTheme(this.spinner,
								true)), SwingConstants.NORTH);
		c.setPreferredSize(new Dimension(16, 16));
		c.setMinimumSize(new Dimension(5, 5));

		Set<Side> openSides = new HashSet<Side>();
		openSides.add(Side.BOTTOM);
		c.putClientProperty(SubstanceLookAndFeel.BUTTON_OPEN_SIDE_PROPERTY,
				openSides);

		this.installNextButtonListeners(c);
		return c;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSpinnerUI#createPreviousButton()
	 */
	@Override
	protected Component createPreviousButton() {
		JComponent c = new SubstanceSpinnerButton(this.spinner,
				SubstanceImageCreator.getArrowIcon(7, 5, SwingConstants.SOUTH,
						SubstanceCoreUtilities.getActiveTheme(this.spinner,
								true)), SwingConstants.SOUTH);
		c.setPreferredSize(new Dimension(16, 16));
		c.setMinimumSize(new Dimension(5, 5));

		Set<Side> openSides = new HashSet<Side>();
		openSides.add(Side.TOP);
		c.putClientProperty(SubstanceLookAndFeel.BUTTON_OPEN_SIDE_PROPERTY,
				openSides);

		this.installPreviousButtonListeners(c);
		return c;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSpinnerUI#installDefaults()
	 */
	@Override
	protected void installDefaults() {
		super.installDefaults();
		JComponent editor = this.spinner.getEditor();
		if ((editor != null) && (editor instanceof JSpinner.DefaultEditor)) {
			JTextField tf = ((JSpinner.DefaultEditor) editor).getTextField();
			if (tf != null) {
				tf.setBorder(new EmptyBorder(0, 1, 0, 1));
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSpinnerUI#installListeners()
	 */
	@Override
	protected void installListeners() {
		super.installListeners();
		this.substanceFocusListener = new FocusBorderListener(this.spinner);
		this.spinner.addFocusListener(this.substanceFocusListener);

		this.substancePropertyChangeListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if ("editor".equals(evt.getPropertyName())) {
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							if (spinner == null)
								return;
							JComponent editor = spinner.getEditor();
							if ((editor != null)
									&& (editor instanceof JSpinner.DefaultEditor)) {
								JTextField tf = ((JSpinner.DefaultEditor) editor)
										.getTextField();
								if (tf != null) {
									tf.setBorder(new EmptyBorder(0, 1, 0, 1));
								}
							}
						}
					});
				}
			}
		};
		this.spinner
				.addPropertyChangeListener(this.substancePropertyChangeListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSpinnerUI#uninstallListeners()
	 */
	@Override
	protected void uninstallListeners() {
		this.substanceFocusListener.cancelAnimations();
		this.spinner.removeFocusListener(this.substanceFocusListener);
		this.substanceFocusListener = null;

		this.spinner
				.removePropertyChangeListener(this.substancePropertyChangeListener);
		this.substancePropertyChangeListener = null;

		super.uninstallListeners();
	}
}
