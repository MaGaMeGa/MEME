package ai.aitia.visu.view.ui;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public class ColorMapFigureRenderer implements IFigureRenderer {
	
	//====================================================================================================
	// members
	
	final protected ColorMap colormap;
	final protected float globalAlpha;
	
	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public ColorMapFigureRenderer(ColorMap colormap, float globalAlpha) {
		this.colormap = colormap;
		this.globalAlpha = globalAlpha;
	}
	
	//----------------------------------------------------------------------------------------------------
	public ColorMapFigureRenderer(ColorMap colormap) { this(colormap,-1f); }
	
	//----------------------------------------------------------------------------------------------------
	public ColorMap getColorMap() { return colormap; }
	public float getGlobalAlpha() { return globalAlpha; }
	
	//====================================================================================================
	// implemented interfaces
	
	//----------------------------------------------------------------------------------------------------
	public void render(Graphics2D g2d, Rectangle2D figureArea, double value) {
		Color color = colormap.getColor(value);
		Composite oldComposite = g2d.getComposite();
		float alpha = globalAlpha < 0 ?  color.getComponents(null)[3] : globalAlpha;
		g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,alpha));
		g2d.setColor(color);
		g2d.fill(figureArea);
		g2d.setComposite(oldComposite);
	}

	//----------------------------------------------------------------------------------------------------
	public String getName() { return colormap.getName(); }
}