package ai.aitia.visu.view.selection;

import org.jfree.data.xy.XYDataset;

public class XYItem {

    private XYDataset dataset;
    
    private int series;

    private int item;

    public XYItem(XYDataset dataset, int series, int item) {
    	this.dataset = dataset;
    	this.series = series;
    	this.item = item;
    }
    
	public XYDataset getDataset() {
		return dataset;
	}

	public void setDataset(XYDataset dataset) {
		this.dataset = dataset;
	}

	public int getItem() {
		return item;
	}

	public void setItem(int item) {
		this.item = item;
	}

	public int getSeries() {
		return series;
	}

	public void setSeries(int series) {
		this.series = series;
	}
  
    public boolean equals(Object obj) {
    	
        if (obj == this) {
            return true;      
        }
        
        if (obj instanceof XYItem) {
            XYItem ie = (XYItem) obj;
            if (this.series != ie.series) {
                return false;   
            }
            if (this.item != ie.item) {
                return false;   
            }
            return true;
        }
        return false;
    }	
    
    
    public int hashCode() {
    	return (new String(series +" " + item)).hashCode();
    }
}
