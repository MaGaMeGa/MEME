/** This package contains the FOBWizard specific classes and interfaces. */
package ai.aitia.fobwizard;