package ai.aitia.visu.view.plot;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.axis.AxisCollection;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.entity.XYItemEntity;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.SeriesRenderingOrder;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.RectangleEdge;

import ai.aitia.visu.axis.MatrixAxis;
import ai.aitia.visu.renderer.MatrixOSPsRenderer;
import ai.aitia.visu.view.selection.DefaultSelectionModel;
import ai.aitia.visu.view.selection.ISelectionListener;
import ai.aitia.visu.view.selection.SelectionEvent;

@SuppressWarnings("serial")
public class MatrixOSPsPlot extends org.jfree.chart.plot.XYPlot {
	private List listeners;	
	protected DefaultSelectionModel selectionModel;
    protected HashMap areaInfo;
    ArrayList <String> legendNames;
  
    public MatrixOSPsPlot(XYDataset dataset,
            
    		MatrixAxis domainAxis,
            MatrixAxis rangeAxis,
            MatrixOSPsRenderer renderer) {
    	super(dataset, domainAxis, rangeAxis, renderer);
		this.selectionModel = new DefaultSelectionModel();
		this.areaInfo = new HashMap();
		this.listeners = new ArrayList();
		legendNames= new ArrayList <String>();
		
    }
    
    public MatrixOSPsPlot(XYDataset dataset,
            ValueAxis domainAxis,
            ValueAxis rangeAxis,
            MatrixOSPsRenderer renderer) {
    	super(dataset, domainAxis, rangeAxis, renderer);
		this.selectionModel = new DefaultSelectionModel();
		this.areaInfo = new HashMap();
		this.listeners = new ArrayList();
    }
    public HashMap getAreaInfo() {
		return areaInfo;
	}
    
    public void selectEntity(ChartEntity entity) {
		
		if (entity instanceof XYItemEntity) {
			
			@SuppressWarnings("unused")
			XYItemEntity xyEntity = (XYItemEntity) entity;
		}		
	}
	
    public boolean render(Graphics2D g2, Rectangle2D dataArea, int index,
			PlotRenderingInfo info, CrosshairState crosshairState) {

		boolean foundData = false;
		XYDataset dataset = getDataset(index);
		if (!DatasetUtilities.isEmptyOrNull(dataset)) {
			foundData = true;
			ValueAxis xAxis = getDomainAxisForDataset(index);
			ValueAxis yAxis = getRangeAxisForDataset(index);
			XYItemRenderer renderer = getRenderer(index);
			if (renderer == null) {
				renderer = getRenderer();
			}

			XYItemRendererState state = renderer.initialise(g2, dataArea, this,
					dataset, info);
			int passCount = renderer.getPassCount();

			SeriesRenderingOrder seriesOrder = getSeriesRenderingOrder();
			if (seriesOrder == SeriesRenderingOrder.REVERSE) {
				//render series in reverse order
				for (int pass = 0; pass < passCount; pass++) {
					int seriesCount = dataset.getSeriesCount();
					int dec=(int)Math.sqrt(seriesCount)+1;
					int base=seriesCount - 1;
					for (int series = seriesCount - 1; series >= 0; series--) {
						int itemCount = dataset.getItemCount(series);
						
						
						if(series!=base){
							
						
							for (int item = 0; item < itemCount; item++) {
								renderer.drawItem(g2, state, dataArea, info, this,
										xAxis, yAxis, dataset, series, item,
										crosshairState, pass);
							}
							
						}else{
							base-=dec;
							((MatrixOSPsRenderer)renderer).drawHistogram(g2, state, dataArea, info, this,
									xAxis, yAxis, dataset, series, 
									crosshairState, pass);
						}
					}
				}
			}
		}
		
		renderSelection(g2);
		
		return foundData;
	}	
    
    public void fireSelectionChanged() {
    	notifyListeners(new SelectionEvent(selectionModel));
    }
    
    protected void notifyListeners(SelectionEvent e) {
    	
    	final int length = listeners.size();
    	
    	for (int i=0; i<length; i++) {
    		ISelectionListener l = (ISelectionListener) listeners.get(i);
    		l.selectionChanged(e);
    	}
    }
    
	@SuppressWarnings("unchecked")
	public void addSelectionListener(ISelectionListener listener) {
		listeners.add(listener);
	}
	
	public void removeSelectionListener(ISelectionListener listener) {
		listeners.remove(listener);
	}
    
	public DefaultSelectionModel getSelectionModel() {
		return selectionModel;
	}

	public void setSelectionModel(DefaultSelectionModel selectionModel) {
		this.selectionModel = selectionModel;
	}
	
    public void renderSelection(Graphics2D g2d) {
    	Rectangle2D frame = selectionModel.getFrame();
    	
    	if (frame != null) {
    		g2d.setColor(Color.GRAY);
    		g2d.draw(frame);
    	}
    	
    	
    	g2d.setColor(Color.RED);
    	
    	List list = selectionModel.getSelectedObjects();
    	for (int i=0; i<list.size(); i++) {
    	
    		Rectangle2D area = (Rectangle2D) areaInfo.get(list.get(i));  
    		
    		g2d.draw(area);
    		
    	
    		@SuppressWarnings("unused")
			double x = area.getX();
    		@SuppressWarnings("unused")
			double y = area.getY();
    		
    		@SuppressWarnings("unused")
			double width = area.getWidth();
    		@SuppressWarnings("unused")
			double height = area.getHeight();
    		
    		//for (double c=x; c<x + width; c+=3) 
    			//g2d.drawLine((int)c, (int)y, (int)c, (int)(y+height));
    	}
    }
    
    @SuppressWarnings("unchecked")
	protected Map drawAxes(Graphics2D g2,
            Rectangle2D plotArea,
            Rectangle2D dataArea,
            PlotRenderingInfo plotState) {
    	AxisCollection axisCollection = new AxisCollection();
    	
    	
    	// add domain axes to lists...
    	for (int index = 0; index < this.getDomainAxisCount(); index++) {
    		ValueAxis axis = (ValueAxis) this.getDomainAxis(index);
    		if (axis != null) {
    			axisCollection.add(axis, getDomainAxisEdge(index));
    		}
    	}

    	// add range axes to lists...
    	for (int index = 0; index < this.getRangeAxisCount(); index++) {
    		ValueAxis yAxis = (ValueAxis) this.getRangeAxis(index);
    		if (yAxis != null) {
    			axisCollection.add(yAxis, getRangeAxisEdge(index));
    		}
    	}

    	Map axisStateMap = new HashMap();

    	// draw the top axes
    	double cursor = (dataArea.getMinY() - this.getAxisOffset().calculateTopOutset(
    			dataArea.getHeight())
    	);
    	Iterator iterator = axisCollection.getAxesAtTop().iterator();
    	
    	int rowCount=(int)Math.sqrt(this.getSeriesCount());//(int)Math.sqrt(this.getDatasetCount());
    	// draw the bottom axes
    	cursor = dataArea.getMaxY()
    	+ this.getAxisOffset().calculateBottomOutset(dataArea.getHeight());
    	iterator = axisCollection.getAxesAtBottom().iterator();
    	while (iterator.hasNext()) {
    		MatrixAxis axis = (MatrixAxis) iterator.next();
    		//cursor =0;
    		AxisState info = axis.draw(
    				g2, cursor, plotArea, dataArea, RectangleEdge.BOTTOM, plotState,
    				rowCount
    		);
    		cursor = info.getCursor();
    		axisStateMap.put(axis, info);
    	}

    	// draw the left axes
    	cursor = dataArea.getMinX()
    	- this.getAxisOffset().calculateLeftOutset(dataArea.getWidth());
    	iterator = axisCollection.getAxesAtLeft().iterator();
    	while (iterator.hasNext()) {
    		MatrixAxis axis = (MatrixAxis) iterator.next();
    		AxisState info = axis.draw(
    				g2, cursor, plotArea, dataArea, RectangleEdge.LEFT, plotState,
    				rowCount
    		);
    		cursor = info.getCursor();
    		axisStateMap.put(axis, info);
    	}
    	
    	
    	
    	return axisStateMap;
    }
    
    /**
     * Returns the legend items for the plot.  Each legend item is generated by
     * the plot's renderer, since the renderer is responsible for the visual
     * representation of the data.
     *
     * @return The legend items.
     */
    public LegendItemCollection getLegendItems() {
        
        LegendItemCollection result = new LegendItemCollection();
        int count = this.getDatasetCount();
        for (int datasetIndex = 0; datasetIndex < count; datasetIndex++) {
            XYDataset dataset = getDataset(datasetIndex);
            if (dataset != null) {
                XYItemRenderer renderer = getRenderer(datasetIndex);
                if (renderer == null) {
                    renderer = getRenderer(0);
                }
                if (renderer != null) {
                    int seriesCount = dataset.getSeriesCount();
                    //int sqrt=(int)Math.sqrt(seriesCount);
                    for (int i = 0; i < seriesCount; i++) {
                        if (renderer.isSeriesVisible(i)
                                && renderer.isSeriesVisibleInLegend(i)) {
                            LegendItem item = renderer.getLegendItem(
                                datasetIndex, i
                            );
                            if (item != null) {
                                result.add(item);
                            }
                        }
                    }
                }
            }
        }
        return result;
    }
    
}