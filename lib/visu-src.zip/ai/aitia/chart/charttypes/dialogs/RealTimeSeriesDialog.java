/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedList;
import java.util.Properties;
import java.util.Vector;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.awt.Font;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.JTabbedPane;
import javax.swing.BorderFactory;
import javax.swing.border.TitledBorder;
import javax.swing.AbstractAction;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.Box;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JPopupMenu;
import javax.swing.JMenuItem;
import javax.swing.ListSelectionModel;
import javax.swing.DefaultListModel;
import javax.swing.SwingUtilities;

import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.AllDummyDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.ChildAdditionalPanel;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;

/** GUI component of the time series (with real time) chart. */
public class RealTimeSeriesDialog extends AbstractChartDialog implements MouseListener,
																		 ActionListener {

	private static final long serialVersionUID = 1L;
	private JTabbedPane tabbed = null;
	private JPanel mainPanel = null;
	private JPanel detailsPanel = null;
	private JPanel titleLine = null;
	private JLabel jLabel = null;
	private JPanel subtitleLine = null;
	private JLabel jLabel1 = null;
	private JTextField subtitleField = null;
	private JPanel timeLabelLine = null;
	private JLabel jLabel2 = null;
	private JTextField timeLabelField = null;
	private JPanel valueLabelLine = null;
	private JLabel jLabel3 = null;
	private JTextField valueLabelField = null;
	private JPanel buttonPanel = null;
	private JButton cancelButton = null;
	private JPanel paramPanel = null;
	private JComboBox params = null;
	private JButton advancedButton = null;
	private JPanel valuesPanel = null;
	private JPanel addButtonPanel = null;
	private JButton addButton = null;
	private JPanel selectedPanel = null;
	private JScrollPane scrList = null;
	private JList sourceList = null;
	private JPanel sortPanel = null;
	private JButton downButton = null;
	private JButton upButton = null;
	private JButton removeButton = null;
	private JPanel itemLine = null;
	private JLabel jLabel4 = null;
	private JTextField maxField = null;
	private JPopupMenu composeMenu = null;
	private JMenuItem mHistogram = null;
	private JMenuItem mScatterPlot = null;
	private JMenuItem mXYLineChart = null;
	private JMenuItem mTimeSeries = null;
	private JPanel appearancePanel = null;
	private JLabel jLabel5 = null;
	private JCheckBox showLegendBox = null;
	private JLabel jLabel6 = null;
	private JComboBox appearanceBox = null;

	private JPopupMenu sourcesContextMenu = new JPopupMenu();
	private AbstractAction removeAction = null;
	private AbstractAction upAction = null;
	private AbstractAction downAction = null;

	//============================================================================
	// additional members
	
	/** Model of the list of selected sources. */
	private DefaultListModel lmodel = null;
	
	/** List of the selected data source producers. */
	private List<IDataSourceProducer> sources = null;
	
	/** Special producer for 'All' combobox item. */
	private AllDummyDataSourceProducer allProducer = new AllDummyDataSourceProducer(); //  @jve:decl-index=0:
	
	//============================================================================
	// methods
	
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public RealTimeSeriesDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		lmodel = new DefaultListModel();
		sources = new LinkedList<IDataSourceProducer>();
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
	}

	//------------------------------------------------------------------------------
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted)
	 * @param child_panel panel that contains the GUI of the other charts in a multi-layered
	 *  chart. 
	 */
	public RealTimeSeriesDialog(ChartConfig config, ChartConfigCollection cc_collection, JPanel child_panel) {
		super(config,cc_collection);
		this.child_panel = child_panel;
		lmodel = new DefaultListModel();
		sources = new LinkedList<IDataSourceProducer>();
		initialize();
		this.scr = new JScrollPane();
		scr.setViewportView(this.child_panel);
		this.setPreferredSize(new Dimension(619,484));
		this.add(this.scr,1);
		setWidgetDisabled();
		setSettingsFromConfig();
	}
	
	//------------------------------------------------------------------------------
	/** This method initializes <code>this</code>.*/
	private void initialize() {
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.setMinimumSize(new Dimension(609, 219));
		this.add(getTabbed(), null);
		this.add(getButtonPanel(), null);
		initializeContextMenu();
	}

	//-------------------------------------------------------------------------------
	/** This method initializes the context menu of the selected sources list.*/
	@SuppressWarnings("serial")
	private void initializeContextMenu() {
		downAction = new AbstractAction() {
			{
				putValue(NAME,"Down");
				putValue(ACTION_COMMAND_KEY,"DOWN");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		sourcesContextMenu.add(downAction);
		upAction = new AbstractAction() {
			{
				putValue(NAME,"Up");
				putValue(ACTION_COMMAND_KEY,"UP");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		sourcesContextMenu.add(upAction);
		removeAction = new AbstractAction() {
			{
				putValue(NAME,"Remove");
				putValue(ACTION_COMMAND_KEY,"REMOVE");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		sourcesContextMenu.add(removeAction);
	}

	//-------------------------------------------------------------------------------
	/** Forwards the ActionEvent <code>e</code> to the general handler.
	 * @param action the action object 
	 * @param e the event
	 */
	private void contextEvent(AbstractAction action, ActionEvent e) {
		if (sourceList.getSelectedIndex() == -1) {
			int x = ((Integer)action.getValue("X")).intValue();
			int y = ((Integer)action.getValue("Y")).intValue();
			int index = sourceList.locationToIndex(new Point(x,y));
			sourceList.setSelectedIndex(index);
		}
		RealTimeSeriesDialog.this.actionPerformed(e);
	}

	//------------------------------------------------------------------------------
	private JTabbedPane getTabbed() {
		if (tabbed == null) {
			tabbed = new JTabbedPane();
			tabbed.setPreferredSize(new Dimension(609, 168));
			tabbed.addTab("Main Settings",Utilities.icons.get(ChartConstants.REALTIMESERIES), getMainPanel(), null);
			tabbed.addTab("Details", null, getDetailsPanel(), null);
		}
		return tabbed;
	}

	//------------------------------------------------------------------------------
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(new BoxLayout(getMainPanel(), BoxLayout.X_AXIS));
			mainPanel.add(getParamPanel(), null);
			mainPanel.add(getSelectedPanel(), null);
		}
		return mainPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getDetailsPanel() {
		if (detailsPanel == null) {
			detailsPanel = new JPanel();
			detailsPanel.setLayout(new BoxLayout(getDetailsPanel(), BoxLayout.Y_AXIS));
			detailsPanel.setBorder(BorderFactory.createTitledBorder(null, "Titles and axis labels of the chart", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			detailsPanel.add(getTitleLine(), null);
			detailsPanel.add(getSubtitleLine(), null);
			detailsPanel.add(getTimeLabelLine(), null);
			detailsPanel.add(getValueLabelLine(), null);
			detailsPanel.add(getAppearancePanel(), null);
		}
		return detailsPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getTitleLine() {
		if (titleLine == null) {
			jLabel = new JLabel();
			jLabel.setText("  Title:  ");
			jLabel.setPreferredSize(new Dimension(125, 16));
			titleLine = new JPanel();
			titleLine.setLayout(new BoxLayout(getTitleLine(), BoxLayout.X_AXIS));
			titleLine.setPreferredSize(new Dimension(400, 20));
			titleLine.add(jLabel, null);
			titleLine.add(getTitleField(), null);
		}
		return titleLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getTitleField() {
		if (titleField == null) {
			titleField = new JTextField();
			titleField.setPreferredSize(new Dimension(275, 20));
			titleField.setText(ChartConstants.REALTIMESERIES_NAME);
			final RealTimeSeriesDialog tthis = this;
			titleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.TITLE,titleField.getText());
					ChartDialogChangeCenter.fireTitleChanged(tthis);
				}
			});
			titleField.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					subtitleField.grabFocus();
				}
			});
		}
		return titleField;
	}

	//------------------------------------------------------------------------------
	private JPanel getSubtitleLine() {
		if (subtitleLine == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("  Subtitle:  ");
			jLabel1.setPreferredSize(new Dimension(125, 16));
			subtitleLine = new JPanel();
			subtitleLine.setLayout(new BoxLayout(getSubtitleLine(), BoxLayout.X_AXIS));
			subtitleLine.setPreferredSize(new Dimension(400, 20));
			subtitleLine.add(jLabel1, null);
			subtitleLine.add(getSubtitleField(), null);
		}
		return subtitleLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getSubtitleField() {
		if (subtitleField == null) {
			subtitleField = new JTextField();
			subtitleField.setPreferredSize(new Dimension(275, 20));
			subtitleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
				}
			});
		}
		return subtitleField;
	}

	//------------------------------------------------------------------------------
	private JPanel getTimeLabelLine() {
		if (timeLabelLine == null) {
			jLabel2 = new JLabel();
			jLabel2.setText("  Time-Axis label:  ");
			jLabel2.setPreferredSize(new Dimension(125, 16));
			timeLabelLine = new JPanel();
			timeLabelLine.setLayout(new BoxLayout(getTimeLabelLine(), BoxLayout.X_AXIS));
			timeLabelLine.setPreferredSize(new Dimension(400, 20));
			timeLabelLine.add(jLabel2, null);
			timeLabelLine.add(getTimeLabelField(), null);
		}
		return timeLabelLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getTimeLabelField() {
		if (timeLabelField == null) {
			timeLabelField = new JTextField();
			timeLabelField.setPreferredSize(new Dimension(275, 20));
			timeLabelField.setText("time");
			timeLabelField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.TIME_AXIS,timeLabelField.getText());
				}
			});
		}
		return timeLabelField;
	}

	//------------------------------------------------------------------------------
	private JPanel getValueLabelLine() {
		if (valueLabelLine == null) {
			jLabel3 = new JLabel();
			jLabel3.setText("  Value-Axis label:  ");
			jLabel3.setPreferredSize(new Dimension(125, 16));
			valueLabelLine = new JPanel();
			valueLabelLine.setLayout(new BoxLayout(getValueLabelLine(), BoxLayout.X_AXIS));
			valueLabelLine.setPreferredSize(new Dimension(400, 20));
			valueLabelLine.add(jLabel3, null);
			valueLabelLine.add(getValueLabelField(), null);
		}
		return valueLabelLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getValueLabelField() {
		if (valueLabelField == null) {
			valueLabelField = new JTextField();
			valueLabelField.setPreferredSize(new Dimension(275, 20));
			valueLabelField.setText("value");
			valueLabelField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.VALUE_AXIS,valueLabelField.getText());
				}
			});
		}
		return valueLabelField;
	}

	//------------------------------------------------------------------------------
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = new JPanel();
			buttonPanel.setLayout(new FlowLayout());
			buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
			buttonPanel.add(getEditorButton(), null);
			buttonPanel.add(getComposeButton(), null);
			buttonPanel.add(getDisplayButton(), null);
			buttonPanel.add(getSaveButton(), null);
			buttonPanel.add(getCancelButton(), null);
		}
		return buttonPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getDisplayButton() {
		if (displayButton == null) {
			displayButton = new JButton();
			displayButton.setEnabled(false);
			displayButton.setText("Display");
			displayButton.setMnemonic(KeyEvent.VK_D);
			displayButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					displayChart();
				}
			});
		}
		return displayButton;
	}

	//----------------------------------------------------------------------------------------------------
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}
	
	//------------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setEnabled(false);
			saveButton.setText("Save");
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					saveCollection();
				}
			});
		}
		return saveButton;
	}

	//------------------------------------------------------------------------------
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMnemonic(KeyEvent.VK_C);
			cancelButton.setText("Cancel");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					notifyForHide();
				}
			});
		}
		return cancelButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getParamPanel() {
		if (paramPanel == null) {
			paramPanel = new JPanel();
			paramPanel.setLayout(new BoxLayout(getParamPanel(), BoxLayout.Y_AXIS));
			paramPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
			paramPanel.add(getValuesPanel(), null);
			paramPanel.add(Box.createRigidArea(new Dimension(0,5)));
			paramPanel.add(getItemLine(), null);
			paramPanel.add(Box.createRigidArea(new Dimension(0,10)));
			paramPanel.add(getAddButtonPanel(), null);
		}
		return paramPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getParams() {
		if (params == null) {
			params = new JComboBox(getSources());
			params.setRenderer(new DataSourceComboBoxRenderer(params));
			params.setPreferredSize(new Dimension(100,26));
			if (params.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)params.getSelectedItem();
				params.setToolTipText(dsp.toString());
			}
			params.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)params.getSelectedItem();
					params.setToolTipText(dsp.toString());
					advancedButton.setEnabled(dsp.hasAdvancedSettings());
				}
			});
		}
		return params;
	}

	//------------------------------------------------------------------------------
	private JButton getAdvancedButton() {
		if (advancedButton == null) {
			advancedButton = new JButton();
			advancedButton.setEnabled(false);
			advancedButton.setText("Advanced...");
			final RealTimeSeriesDialog tthis = this;
			advancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)params.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(tthis.getRootPane().getParent());
					if (new_dsp != null) {
						int index = params.getSelectedIndex();
						params.removeItemAt(index);
						params.insertItemAt(new_dsp,index);
						params.setSelectedIndex(index);
					}
				}
			});
			
			if (params.getItemCount()>0) {
				IDataSourceProducer dsp = (IDataSourceProducer)params.getSelectedItem();
				advancedButton.setEnabled(dsp.hasAdvancedSettings());
			}

		}
		return advancedButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getValuesPanel() {
		if (valuesPanel == null) {
			valuesPanel = new JPanel();
			valuesPanel.setLayout(new BoxLayout(getValuesPanel(), BoxLayout.X_AXIS));
			valuesPanel.setBorder(BorderFactory.createTitledBorder(null, "Sources", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			valuesPanel.add(getParams(), null);
			valuesPanel.add(Box.createRigidArea(new Dimension(5,0)));
			valuesPanel.add(getAdvancedButton(), null);
		}
		return valuesPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getAddButtonPanel() {
		if (addButtonPanel == null) {
			addButtonPanel = new JPanel();
			addButtonPanel.setLayout(new FlowLayout());
			addButtonPanel.add(getAddButton(), null);
		}
		return addButtonPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getAddButton() {
		if (addButton == null) {
			addButton = new JButton();
			addButton.setMnemonic(KeyEvent.VK_A);
			addButton.setText("Add");
			addButton.setIcon(Utilities.getIcon("RIGHT ARROW"));
			addButton.setIconTextGap(2);
			addButton.setHorizontalTextPosition(JButton.LEADING);
			final RealTimeSeriesDialog tthis = this;
			addButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)params.getSelectedItem();
					if (dsp.equals(allProducer)) {
						// special data source
						for (int i=0;i<params.getItemCount();++i) {
							IDataSourceProducer p = (IDataSourceProducer)params.getItemAt(i);
							if (p.equals(allProducer) || sources.contains(p)) continue;
							sources.add(p);
							lmodel.addElement(p.toString());
						}
					} else {
						if (sources.contains(dsp)) return; //repeated source
						sources.add(dsp); // add new source
						lmodel.addElement(dsp.toString()); // display it in the list
					}
					updateValueAxisLabel();
					
					// enable the buttons (if need)
					if (sources.size()>0) {
						removeButton.setEnabled(true);
						if (isUpdateable()) {
							displayButton.setEnabled(true);
							ChartDialogChangeCenter.fireSaveEnabled(tthis);
						}
						if (chartDialogParent != null) childStatusChanged();
					}
					if (sources.size()>1) {
						downButton.setEnabled(true);
						upButton.setEnabled(true);
					}
				}
			});
		}
		return addButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getSelectedPanel() {
		if (selectedPanel == null) {
			selectedPanel = new JPanel();
			selectedPanel.setLayout(new BoxLayout(getSelectedPanel(), BoxLayout.Y_AXIS));
			selectedPanel.setBorder(BorderFactory.createTitledBorder(null, "Selected sources", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			selectedPanel.setPreferredSize(new Dimension(150, 100));
			selectedPanel.setMinimumSize(new Dimension(150, 100));
			selectedPanel.add(getScrList(), null);
			selectedPanel.add(getSortPanel(), null);
		}
		return selectedPanel;
	}

	//------------------------------------------------------------------------------
	private JScrollPane getScrList() {
		if (scrList == null) {
			scrList = new JScrollPane();
			scrList.setAutoscrolls(true);
			scrList.setViewportView(getSourceList());
			scrList.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			scrList.setWheelScrollingEnabled(true);
		}
		return scrList;
	}

	//------------------------------------------------------------------------------
	private JList getSourceList() {
		if (sourceList == null) {
			sourceList = new JList(lmodel);
			sourceList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			sourceList.setAutoscrolls(true);
			sourceList.addMouseListener(this);
		}
		return sourceList;
	}

	//------------------------------------------------------------------------------
	private JPanel getSortPanel() {
		if (sortPanel == null) {
			sortPanel = new JPanel();
			sortPanel.setLayout(new FlowLayout());
			sortPanel.setPreferredSize(new Dimension(150, 36));
			sortPanel.setMinimumSize(new Dimension(150, 36));
			sortPanel.add(getDownButton(), null);
			sortPanel.add(getUpButton(), null);
			sortPanel.add(getRemoveButton(), null);
		}
		return sortPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getDownButton() {
		if (downButton == null) {
			downButton = new JButton();
			downButton.setEnabled(false);
			downButton.setText("Down");
			downButton.setMnemonic(KeyEvent.VK_DOWN);
			downButton.setActionCommand("DOWN");
			downButton.addActionListener(this);
		}
		return downButton;
	}

	//------------------------------------------------------------------------------
	private JButton getUpButton() {
		if (upButton == null) {
			upButton = new JButton();
			upButton.setEnabled(false);
			upButton.setMnemonic(KeyEvent.VK_UP);
			upButton.setText("Up");
			upButton.setActionCommand("UP");
			upButton.setMaximumSize(new Dimension(66, 26));
			upButton.addActionListener(this);
		}
		return upButton;
	}

	//------------------------------------------------------------------------------
	private JButton getRemoveButton() {
		if (removeButton == null) {
			removeButton = new JButton();
			removeButton.setMnemonic(KeyEvent.VK_R);
			removeButton.setEnabled(false);
			removeButton.setText("Remove");
			removeButton.setActionCommand("REMOVE");
			removeButton.addActionListener(this);
		}
		return removeButton;
	}
	
	//------------------------------------------------------------------------------
	private JPanel getItemLine() {
		if (itemLine == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("  Max. count of displayed items:  ");
			itemLine = new JPanel();
			itemLine.setLayout(new BoxLayout(getItemLine(), BoxLayout.X_AXIS));
			itemLine.add(jLabel4, null);
			itemLine.add(getMaxField(), null);
		}
		return itemLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getMaxField() {
		if (maxField == null) {
			maxField = new JTextField();
			maxField.setText("100");
			maxField.setMaximumSize(new Dimension(160, 30));
			maxField.setHorizontalAlignment(JTextField.TRAILING);
			maxField.setPreferredSize(new Dimension(75, 30));
			maxField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					Pattern p = Pattern.compile("^[1-9][0-9]*$");
					Matcher positive = p.matcher(maxField.getText().trim());
					try {
						if (!positive.matches())
							throw new NumberFormatException();
						Integer.parseInt(maxField.getText().trim());
					} catch (NumberFormatException ee) {
						JOptionPane.showMessageDialog(RealTimeSeriesDialog.this,"Invalid value in field 'Max. count of displayed items'.","Warning",JOptionPane.WARNING_MESSAGE,null);
						maxField.setText("100");
						maxField.grabFocus();
						maxField.selectAll();
					}
					properties.setProperty(ChartConstants.NR_OF_DISPLAYED_ITEMS,maxField.getText());
				}
			});
		}
		return maxField;
	}
	
	//------------------------------------------------------------------------------
	private JPanel getAppearancePanel() {
		if (appearancePanel == null) {
			jLabel6 = new JLabel();
			jLabel6.setText("  Appearance:  ");
			jLabel5 = new JLabel();
			jLabel5.setText(" ");
			jLabel5.setPreferredSize(new Dimension(125, 16));
			appearancePanel = new JPanel();
			appearancePanel.setLayout(new BoxLayout(getAppearancePanel(), BoxLayout.X_AXIS));
			appearancePanel.add(jLabel5, null);
			appearancePanel.add(getShowLegendBox(), null);
			appearancePanel.add(Box.createRigidArea(new Dimension(10,0)));
			appearancePanel.add(jLabel6, null);
			appearancePanel.add(getAppearanceBox(), null);
		}
		return appearancePanel;
	}

	//------------------------------------------------------------------------------
	private JCheckBox getShowLegendBox() {
		if (showLegendBox == null) {
			showLegendBox = new JCheckBox();
			showLegendBox.setSelected(true);
			showLegendBox.setText("Show legend");
			showLegendBox.addItemListener(new java.awt.event.ItemListener() {
				public void itemStateChanged(java.awt.event.ItemEvent e) {
					properties.setProperty(ChartConstants.SHOW_LEGEND,String.valueOf(showLegendBox.isSelected()));
				}
			});
		}
		return showLegendBox;
	}

	//------------------------------------------------------------------------------
	private JComboBox getAppearanceBox() {
		if (appearanceBox == null) {
			Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
			appearances.add(new ComboboxItem( "BC", "Basic, colored"));
			appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
			appearances.add(new ComboboxItem( "NC", "Normal, colored"));
			appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
			for (String templateNames : AbstractChart.templates.keySet())
				appearances.add(new ComboboxItem("_" + templateNames,templateNames));
			appearances.add(new ComboboxItem("_NEW","New template..."));
			appearances.add(new ComboboxItem("_EDIT","Edit template..."));
			appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
			appearanceBox = new JComboBox(appearances);
			appearanceBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int index = appearanceBox.getSelectedIndex();
					String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
					if (index >= 0 && index <= 3) {
				 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
				 		if (code[0].equals("B"))
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.BASIC_APP);
				 		else
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.NORMAL_APP);
				 		if (code[1].equals("BW"))
				 			ChartConfigCollection.setColorAppearance(ChartConstants.BLACK_AND_WHITE);
				 		else
				 			ChartConfigCollection.setColorAppearance(ChartConstants.COLORED);
					}  else if (appearanceCode.equals("_NEW")) {
						ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.NORMAL);
						int result = dlg.showDialog();
						if (result == ChartPropertiesDialog.OK_OPTION) {
							Element newTemplate = (Element) dlg.getTemplate();
							dlg.dispose();
							String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
							AbstractChart.templates.put(name,newTemplate);
							ChartDialogChangeCenter.fireTemplateChanged();
							appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
						} else 
							appearanceBox.setSelectedIndex(0);
					} else if (appearanceCode.equals("_EDIT")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(RealTimeSeriesDialog.this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(RealTimeSeriesDialog.this,"Select a template: ","Edit template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template == null || "".equals(template)) 
							appearanceBox.setSelectedIndex(0);
						else {
							Element templateElement = AbstractChart.templates.get(template);
							ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(),ChartKind.NORMAL);
							int result = dlg.showDialog();
							if (result == ChartPropertiesDialog.OK_OPTION) {
								Element newTemplate = (Element) dlg.getTemplate();
								dlg.dispose();
								String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
								AbstractChart.templates.put(name,newTemplate);
								ChartDialogChangeCenter.fireTemplateChanged();
								appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
							} else 
								appearanceBox.setSelectedIndex(0);
						}
					} else if (appearanceCode.equals("_REMOVE")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(RealTimeSeriesDialog.this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(RealTimeSeriesDialog.this,"Select a template: ","Delete template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template != null && !"".equals(template)) { 
							AbstractChart.templates.remove(template);
							File file = new File("Templates/" + template + ".xml");
							file.delete();
							ChartDialogChangeCenter.fireTemplateChanged();
						}
						appearanceBox.setSelectedIndex(0);
					}
				}
			});
		}
		return appearanceBox;
	}

	//------------------------------------------------------------------------------
	private List<String> getLegends() {
		List<String> result = new ArrayList<String>(lmodel.size());
		for (int i = 0;i < lmodel.size();++i)
			result.add(lmodel.get(i).toString());
		return result;
	}
	
	//------------------------------------------------------------------------------
	private JButton getComposeButton() {
		if (composeButton == null) {
			composeButton = new JButton();
			composeButton.setText("Compose...");
			composeButton.setMnemonic(KeyEvent.VK_M);
			composeButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					getComposeMenu().show(composeButton,45,5);
				}
			});
		}
		return composeButton;
	}

	//------------------------------------------------------------------------------
	private JPopupMenu getComposeMenu() {
		if (composeMenu == null) {
			composeMenu = new JPopupMenu();
			composeMenu.add(getMHistogram());
			composeMenu.add(getMScatterPlot());
			composeMenu.add(getMTimeSeries());
			composeMenu.add(getMXYLineChart());
		}
		return composeMenu;
	}

	//------------------------------------------------------------------------------
	private JMenuItem getMHistogram() {
		if (mHistogram == null) {
			mHistogram = new JMenuItem();
			mHistogram.setText(ChartConstants.HISTOGRAM_NAME);
			mHistogram.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.HISTOGRAM);
				}
			});
		}
		return mHistogram;
	}

	//------------------------------------------------------------------------------
	private JMenuItem getMScatterPlot() {
		if (mScatterPlot == null) {
			mScatterPlot = new JMenuItem();
			mScatterPlot.setText(ChartConstants.SCATTERPLOT_NAME);
			mScatterPlot.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.SCATTERPLOT);
				}
			});
		}
		return mScatterPlot;
	}

	//------------------------------------------------------------------------------
	private JMenuItem getMXYLineChart() {
		if (mXYLineChart == null) {
			mXYLineChart = new JMenuItem();
			mXYLineChart.setText(ChartConstants.XYLINECHART_NAME);
			mXYLineChart.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.XYLINECHART);
				}
			});
		}
		return mXYLineChart;
	}

	//------------------------------------------------------------------------------
	private JMenuItem getMTimeSeries() {
		if (mTimeSeries == null) {
			mTimeSeries = new JMenuItem();
			mTimeSeries.setText(ChartConstants.TIMESERIES_NAME);
			mTimeSeries.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.TIMESERIES);
				}
			});
		}
		return mTimeSeries;
	}

	//=============================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-generated functions                                                //
	////////////////////////////////////////////////////////////////////////////
	
	@Override
	protected void setWidgetDisabled() {
		if (params.getItemCount() == 0) {
			params.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			advancedButton.setEnabled(false);
			addButton.setEnabled(false);
			if (cc_collection.getComposeMode()) composeButton.setEnabled(false);
		}
	}
	
	//------------------------------------------------------------------------------
	/** Returns the displayable names of the data sources.
	 * @return array of data sources
	 */
 	private Object[] getSources() {
 		Object[] res = getParams(IValueProducer.class);
 		if (res.length != 0) {
 			List<Object> resPlus = new ArrayList<Object>(Arrays.asList(res));
 			resPlus.add(allProducer);
 			return resPlus.toArray();
 		}
 		return res;
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	protected void setSettingsFromConfig() {
 		if (config.getChartProperties() instanceof Properties) {
 			// set settings from the config
 			properties = (Properties)config.getChartProperties();
 			String valueAxis = properties.getProperty(ChartConstants.VALUE_AXIS);
 			
 			int[] ds = Utilities.splitDatasourceAroundCommas(properties.getProperty(ChartConstants.DATASOURCE));
 			for (int i=0;i<ds.length;++i) {
 				IDataSourceProducer dsp = config.getDataSource(ds[i]);
 	 			sources.add(dsp);
 	 			lmodel.addElement(dsp.toString());
 			}
 			IDataSourceProducer dsp = config.getDataSource(ds[ds.length-1]);
 			params.setSelectedItem(dsp);
 			maxField.setText(properties.getProperty(ChartConstants.NR_OF_DISPLAYED_ITEMS));
 			titleField.setText(properties.getProperty(ChartConstants.TITLE));
 			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
 			timeLabelField.setText(properties.getProperty(ChartConstants.TIME_AXIS));
 			valueLabelField.setText(valueAxis);
 			showLegendBox.setSelected(Boolean.parseBoolean(properties.getProperty(ChartConstants.SHOW_LEGEND,"true")));
 			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
 			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
 				String appearanceCode = "";
 				appearanceCode += properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP) ? "N" : "B";
 				appearanceCode += properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE) ? "BW" : "C";
 				for (int i = 0;i < appearanceBox.getItemCount();++i) {
 					String id = ((ComboboxItem)appearanceBox.getItemAt(i)).getID().toString();
 					if (id.equals(appearanceCode)) {
 						appearanceBox.setSelectedIndex(i);
 						break;
 					}
 				}
 			}
 			if (sources.size() > 0) {
 				displayButton.setEnabled(true);
 				saveButton.setEnabled(true);
 				removeButton.setEnabled(true);
 			}
 			if (sources.size() > 1) {
 				downButton.setEnabled(true);
 				upButton.setEnabled(true);
 			}
 		} else {
 			// set the initial properties
 			properties.setProperty(ChartConstants.TITLE,ChartConstants.REALTIMESERIES_NAME);
 			properties.setProperty(ChartConstants.SUBTITLE,"");
 			properties.setProperty(ChartConstants.TIME_AXIS,"time");
 			properties.setProperty(ChartConstants.VALUE_AXIS,"value");
 			properties.setProperty(ChartConstants.SHOW_LEGEND,"true");
			properties.setProperty(ChartConstants.NR_OF_DISPLAYED_ITEMS,"100");
 			int appIndex = 0;
 			appIndex += ChartConfigCollection.getColorAppearance().equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
 			appIndex += ChartConfigCollection.getEnvironmentAppearance().equals(ChartConstants.NORMAL_APP) ? 2 : 0;
 			appearanceBox.setSelectedIndex(appIndex);
  		}
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	public void updateChartConfig() {
 		config.clearAllDataSource();
 		Iterator<IDataSourceProducer> it = sources.iterator();
 		String ds = "";
 		while (it.hasNext()) {
 			IDataSourceProducer dsp = it.next();
 			if (dsp.getSupportedIntfs().contains(IValueProducer.class)) { // source supports the IValueProducer
 				int key = config.addDataSource(dsp,IValueProducer.class);
 				ds += String.valueOf(key) + ",";
 			} else { // source supports ISeriesProducer
 				int key = config.addDataSource(dsp,ISeriesProducer.class);
 				ds += String.valueOf(key) + ",";
 			}
 		}
 		properties.setProperty(ChartConstants.DATASOURCE,ds.substring(0,ds.length()-1));
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 3) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
	 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
	 		if (code[0].equals("B"))
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.BASIC_APP);
	 		else
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.NORMAL_APP);
	 		if (code[1].equals("BW"))
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.BLACK_AND_WHITE);
	 		else
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.COLORED);
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
 		config.setChartProperties(ChartConstants.REALTIMESERIES,properties);
 		if (config.isMultiLayerChart()) {
 			for (int i = 1;i < child_panel.getComponentCount();i += 2)
 				((AbstractChartDialog)child_panel.getComponent(i)).updateChartConfig();
 		}
 		
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	public boolean isUpdateable() {
 		if (!config.isMultiLayerChart()) return !sources.isEmpty();
 		boolean update = !sources.isEmpty();
 		for (int i=1;i<child_panel.getComponentCount();i+=2) {
 			if (!update) break;
 			update = update && ((AbstractChartDialog)child_panel.getComponent(i)).isUpdateable();
 		}
 		return update;
 	}
 	
	//------------------------------------------------------------------------------
 	/** Removes the buttons and disables appropriate parts (title, subtitle and
 	 *  time-axis) of the details panel.
	  */
 	@Override
	public void setChildMode(boolean realTimeSeriesParent) {
		this.remove(buttonPanel);
		jLabel.setEnabled(false);
		titleField.setText("");
		titleField.setEnabled(false);
		jLabel1.setEnabled(false);
		subtitleField.setEnabled(false);
		showLegendBox.setEnabled(false);
		jLabel6.setEnabled(false);
		appearanceBox.setEnabled(false);
		cap = new ChildAdditionalPanel(this,properties,AbstractChart.find(config.getChartType()).toString());
		add(cap,0);
 	}
	
	//------------------------------------------------------------------------------
 	@Override
 	protected void removeChild(AbstractChartDialog who) {
 		config.removeChild(who.config);
 		child_panel.remove(who);
 		int count = child_panel.getComponentCount();
 		for (int i=0;i<count-1;++i) {
 			if (child_panel.getComponent(i) instanceof JSeparator && 
 				child_panel.getComponent(i+1) instanceof JSeparator) {
 				child_panel.remove(i);
 				break;
 			}
		}
 		count = child_panel.getComponentCount();
 		if (child_panel.getComponent(count-1) instanceof JSeparator)
 			child_panel.remove(count-1);
		if (!config.isMultiLayerChart()) {
			scr.setVisible(false);
			this.setPreferredSize(new Dimension(609,219));
 			child_panel = null;
 		}
		Utilities.repack(this);
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
	/** Sets the compose button to invisible or visible. */
	public void setComposeButton(boolean invisibled) {
		composeButton.setVisible(!invisibled);
	}
	
	//------------------------------------------------------------------------------
 	@Override
 	protected void setSelectedAxis(AbstractChartDialog who) {
 		for (int i=1;i<child_panel.getComponentCount();i+=2) {
 			if (!child_panel.getComponent(i).equals(who))
 				((AbstractChartDialog)child_panel.getComponent(i)).cap.setAxisDisabled();
 		}
 	}

	//------------------------------------------------------------------------------
	@Override
	protected void displayPreview() throws Exception {
		DataSources ds = new DataSources(new SimpleDSPCollection());
		ChartConfig temp_config = new ChartConfig(ds);
		temp_config.setFireInitialEvent(true);
		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
		Properties temp_prop = (Properties)properties.clone();
		temp_config.addDataSource(dsl.get(1),ISeriesProducer.class);
		temp_config.addDataSource(dsl.get(2),ISeriesProducer.class);
		temp_prop.setProperty(ChartConstants.DATASOURCE,"1,2");
		temp_prop.setProperty(ChartConstants.TITLE,temp_prop.getProperty(ChartConstants.TITLE) + " (Preview Illustration)");
		temp_config.setChartProperties(ChartConstants.REALTIMESERIES,temp_prop);
		Utilities.displayPreview(temp_config);
	}
	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem)appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		// reset widgets
		params.setEnabled(true);
		advancedButton.setEnabled(true);
		addButton.setEnabled(true);
		if (cc_collection.getComposeMode()) composeButton.setEnabled(true);
		
		Object object = params.getSelectedIndex() == -1 ? null : params.getSelectedItem();
		
		DefaultComboBoxModel paramsModel = new DefaultComboBoxModel(getSources());
		params.setModel(paramsModel);
		
		if (object != null && findInComboBox(paramsModel,(IDataSourceProducer)object) != -1) {
			int idx = findInComboBox(paramsModel,(IDataSourceProducer)object);
			params.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		
		List<IDataSourceProducer> newSources = new ArrayList<IDataSourceProducer>();
		for (IDataSourceProducer prod : sources) {
			int idx = findInComboBox(paramsModel,prod);
			if (idx != -1) 
				newSources.add((IDataSourceProducer)paramsModel.getElementAt(idx));
		}
		sources = newSources;
		lmodel.clear();
		for (IDataSourceProducer prod : newSources) 
			lmodel.addElement(prod.toString());
		downButton.setEnabled(sources.size() >= 2);
		upButton.setEnabled(sources.size() >= 2);
		removeButton.setEnabled(sources.size() != 0);
		
		validate();
		setWidgetDisabled();
		
		if (config.isMultiLayerChart()) {
			for (int i = 1;i < child_panel.getComponentCount();i += 2) 
				((AbstractChartDialog)child_panel.getComponent(i)).reloadDataSources();
		}
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
		if (chartDialogParent != null)
			childStatusChanged();
	}
	
	//------------------------------------------------------------------------------
	/** Updates the label of the value axis with the name of the first data source.
	 *  If there isn't any data source, the label return to its default setting.
	 */ 
	private void updateValueAxisLabel() {
		if (sources.size()==0) valueLabelField.setText("value");
		else valueLabelField.setText(sources.get(0).toString());
		properties.setProperty(ChartConstants.VALUE_AXIS,valueLabelField.getText());
	}

	//------------------------------------------------------------------------------
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}

	//-------------------------------------------------------------------------------
	/** This method haldles all released mouse events of the panel. It is public 
	 *  because of implementation side effect. Do not call or override.
	 * @param e event
	 */
	public void mouseReleased(MouseEvent e) {
		if (!SwingUtilities.isRightMouseButton(e))
			return;
		if (e.getComponent().isEnabled()) {
			downAction.setEnabled(sourceList.getModel().getSize() > 1);
			upAction.setEnabled(sourceList.getModel().getSize() > 1);
			removeAction.setEnabled(sourceList.getModel().getSize() != 0);
			if (sourceList.getModel().getSize() > 1) {
				downAction.putValue("X",e.getX());
				downAction.putValue("Y",e.getY());
				upAction.putValue("X",e.getX());
				upAction.putValue("Y",e.getY());
			}
			if (sourceList.getModel().getSize() != 0) {
				removeAction.putValue("X",e.getX());
				removeAction.putValue("Y",e.getY());
			}
			sourcesContextMenu.show(e.getComponent(),e.getX(),e.getY());
		}
	}

 	//-------------------------------------------------------------------------------
 	/** This method handles all ActionEvent-s of the panel. It is public because of
 	 *  implementation side effect. Do not call or override.
 	 * @param event event
 	 */
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if (cmd.equals("DOWN")) {
			move(1);
		} else if (cmd.equals("UP")) {
			move(-1);
		} else if (cmd.equals("REMOVE")) {
			int[] selected = sourceList.getSelectedIndices();
			while (selected.length != 0) {
				sources.remove(selected[0]);
				lmodel.remove(selected[0]);
				selected = sourceList.getSelectedIndices();
			}
			updateValueAxisLabel();

			// disable the buttons (if need)
			if (sources.size() < 2) {
				downButton.setEnabled(false);
				upButton.setEnabled(false);
			}
			if (sources.size() == 0) {
				removeButton.setEnabled(false);
				displayButton.setEnabled(false);
				ChartDialogChangeCenter.fireSaveDisabled(this);
				if (chartDialogParent != null) childStatusChanged();
			}
		}
	}
	
	//-----------------------------------------------------------------------------
	/** Moves the selected elements in the selected sources list.
	 * @param offset the direction of the move (possible values: -1,1)
	 */
	private void move(int offset) {
		int[] selected = sourceList.getSelectedIndices();
		
		List<int[]> intervals = new ArrayList<int[]>();
		int start = selected[0], end = -1, previous = selected[0] - 1;

		for (int i=0;i<selected.length;++i) {
				if (selected[i] == previous + 1) previous = selected[i];
				else {
					end = previous;
					int[] intv = { start, end };
					intervals.add(intv);
					end = -1;
					start = previous = selected[i];
				}
		}
		intervals.add(new int[] { start, selected[selected.length-1] });
		
		sourceList.clearSelection();
		for (int[] intv : intervals) {
			int to = intv[0] + offset;
			if (0 <= intv[0] && 0 <= to && intv[1] + offset < lmodel.size()) {
				moveInterval(intv[0],intv[1],to);
				sourceList.getSelectionModel().addSelectionInterval(intv[0] + offset,intv[1] + offset);
			} else 
				sourceList.getSelectionModel().addSelectionInterval(intv[0],intv[1]);
		}
		updateValueAxisLabel();
	}
	
	//-------------------------------------------------------------------------------
	/** Moves the elements in the selected sources list. The indices of the moved
	 *  elements are in the interval [<code>start</code>,<code>end</code>]. 
	 * @param to the new index of the first element
	 */
	private void moveInterval(int start, int end, int to) {
		int temp = to;
		String[] path = new String[end - start + 1];
		IDataSourceProducer[] dsps = new IDataSourceProducer[end - start + 1];
		for (int i = start;i <= end; ++i) {
			path[i - start] = (String)lmodel.get(i);
			dsps[i - start] = sources.get(i);
		}
		lmodel.removeRange(start,end);
		sources.removeAll(Arrays.asList(dsps));
		for (int i = 0;i < path.length;++i) {
			lmodel.add(temp,path[i]);
			sources.add(temp++,dsps[i]);
		}
	}
}