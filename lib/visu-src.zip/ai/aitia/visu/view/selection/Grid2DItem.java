package ai.aitia.visu.view.selection;


public class Grid2DItem {
    
    private int x;
    private int y;

    public Grid2DItem(int x, int y) {
    	this.x = x;
    	this.y = y;
    }
  
    public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public boolean equals(Object obj) {
    	
        if (obj == this) {
            return true;      
        }
        
        if (obj instanceof Grid2DItem) {
            Grid2DItem ie = (Grid2DItem) obj;
            if (this.x != ie.x) {
                return false;   
            }
            if (this.y != ie.y) {
                return false;   
            }
            return true;
        }
        return false;
    }	
    
    
    public int hashCode() {
    	return (new String(x +" " + y)).hashCode();
    }
}
