/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.view.ui;

import java.awt.Color;

public class RainbowColorMap implements ColorMap {
	
	//====================================================================================================
	// members
	
    protected double maxLevel = 0;
    protected double minLevel = 0;	
    
    private Color defaultColor = Color.BLACK;
	
    /** The red values. */
    private int[] red = {255,   0, 120, 115, 111, 106, 102,  97,  
                          93,  88,  84,  79,  75,  70,  66,  61,
                          57,  52,  48,  43,  39,  34,  30,  25, 
                          21,  16,  12,   7,   3,   0,   0,   0,
                           0,   0,   0,   0,   0,   0,   0,   0, 
                           0,   0,   0,   0,   0,   0,   0,   0,
                           0,   0,   0,   0,   0,   0,   0,   0, 
                           0,   0,   0,   0,   0,   0,   0,   0,
                           0,   0,   0,   0,   0,   0,   0,   0, 
                           0,   0,   0,   0,   0,   0,   0,   0,
                           0,   0,   0,   0,   0,   0,   0,   0, 
                           0,   0,   0,   0,   0,   0,   0,   0,
                           0,   0,   0,   0,   0,   0,   0,   0, 
                           0,   0,   0,   0,   0,   0,   0,   0,
                           0,   0,   0,   0,   0,   0,   0,   0, 
                           0,   0,   0,   0,   0,   0,   0,   0,
                           0,   0,   0,   0,   0,   0,   0,   0, 
                           0,   0,   0,   0,   0,   0,   1,   5,
                          10,  14,  19,  23,  28,  32,  37,  41, 
                          46,  50,  55,  59,  64,  68,  73,  77,
                          82,  86,  91,  95, 100, 104, 109, 113, 
                         118, 123, 127, 132, 136, 141, 145, 150,
                         154, 159, 163, 168, 172, 177, 181, 186, 
                         190, 195, 199, 204, 208, 213, 217, 222,
                         226, 231, 235, 240, 244, 249, 253, 255, 
                         255, 255, 255, 255, 255, 255, 255, 255,
                         255, 255, 255, 255, 255, 255, 255, 255, 
                         255, 255, 255, 255, 255, 255, 255, 255,
                         255, 255, 255, 255, 255, 255, 255, 255, 
                         255, 255, 255, 255, 255, 255, 255, 255,
                         255, 255, 255, 255, 255, 255, 255, 255, 
                         255, 255, 255, 255, 255, 255, 255, 255};

    /** The green values. */
    private int[] green = {255,   0,   0,   0,   0,   0,   0,   0,
                             0,   0,   0,   0,   0,   0,   0,   0,
                             0,   0,   0,   0,   0,   0,   0,   0,
                             0,   0,   0,   0,   0,   2,   6,  11,
                            15,  20,  24,  29,  33,  38,  42,  47,
                            51,  56,  60,  65,  69,  74,  78,  83,
                            87,  92,  96, 101, 105, 110, 114, 119,
                           123, 128, 132, 137, 141, 146, 150, 155,
                           159, 164, 168, 173, 177, 182, 186, 191, 
                           195, 200, 204, 209, 213, 218, 222, 227,
                           231, 236, 241, 245, 250, 254, 255, 255, 
                           255, 255, 255, 255, 255, 255, 255, 255,
                           255, 255, 255, 255, 255, 255, 255, 255, 
                           255, 255, 255, 255, 255, 255, 255, 255,
                           255, 255, 255, 255, 255, 255, 255, 255, 
                           255, 255, 255, 255, 255, 255, 255, 255,
                           255, 255, 255, 255, 255, 255, 255, 255, 
                           255, 255, 255, 255, 255, 255, 255, 255,
                           255, 255, 255, 255, 255, 255, 255, 255, 
                           255, 255, 255, 255, 255, 255, 255, 255,
                           255, 255, 255, 255, 255, 255, 255, 255, 
                           255, 255, 255, 255, 255, 255, 255, 255,
                           255, 255, 255, 255, 255, 255, 255, 255, 
                           255, 255, 255, 255, 255, 255, 255, 255,
                           255, 255, 255, 255, 255, 255, 255, 252, 
                           248, 243, 239, 234, 230, 225, 221, 216,
                           212, 207, 203, 198, 194, 189, 185, 180, 
                           176, 171, 167, 162, 158, 153, 149, 144,
                           140, 135, 131, 126, 122, 117, 113, 108, 
                           104,  99,  95,  90,  86,  81,  77,  72,
                            68,  63,  59,  54,  50,  45,  41,  36,  
                            32,  27,  23,  18,  14,   9,   5,   0};

    /** The blue values. */
    private int[] blue = {255,   0, 255, 255, 255, 255, 255, 255, 
                          255, 255, 255, 255, 255, 255, 255, 255,
                          255, 255, 255, 255, 255, 255, 255, 255, 
                          255, 255, 255, 255, 255, 255, 255, 255,
                          255, 255, 255, 255, 255, 255, 255, 255, 
                          255, 255, 255, 255, 255, 255, 255, 255,
                          255, 255, 255, 255, 255, 255, 255, 255, 
                          255, 255, 255, 255, 255, 255, 255, 255,
                          255, 255, 255, 255, 255, 255, 255, 255, 
                          255, 255, 255, 255, 255, 255, 255, 255,
                          255, 255, 255, 255, 255, 255, 251, 247, 
                          242, 238, 233, 229, 224, 220, 215, 211,
                          206, 202, 197, 193, 188, 184, 179, 175, 
                          170, 166, 161, 157, 152, 148, 143, 139,
                          134, 130, 125, 121, 116, 112, 107, 103,  
                          98,  94,  89,  85,  80,  76,  71,  67,
                           62,  58,  53,  49,  44,  40,  35,  31,  
                           26,  22,  17,  13,   8,   4,   0,   0,
                            0,   0,   0,   0,   0,   0,   0,   0,   
                            0,   0,   0,   0,   0,   0,   0,   0,
                            0,   0,   0,   0,   0,   0,   0,   0,   
                            0,   0,   0,   0,   0,   0,   0,   0,
                            0,   0,   0,   0,   0,   0,   0,   0,   
                            0,   0,   0,   0,   0,   0,   0,   0,
                            0,   0,   0,   0,   0,   0,   0,   0,  
                            0,   0,   0,   0,   0,   0,   0,   0,
                            0,   0,   0,   0,   0,   0,   0,   0,   
                            0,   0,   0,   0,   0,   0,   0,   0,
                            0,   0,   0,   0,   0,   0,   0,   0,  
                            0,   0,   0,   0,   0,   0,   0,   0,
                            0,   0,   0,   0,   0,   0,   0,   0,  
                            0,   0,   0,   0,   0,   0,   0,   0};	

    //====================================================================================================
	// methods
    
    //----------------------------------------------------------------------------------------------------
    public RainbowColorMap(double minLevel, double maxLevel) {
    	this.minLevel = minLevel;
    	this.maxLevel = maxLevel;
    }
    
    //----------------------------------------------------------------------------------------------------
	public void setMinLevel(double minLevel) { this.minLevel = minLevel; }
	public void setMaxLevel(double maxLevel) { this.maxLevel = maxLevel; }
	public void setDefaultColor(Color defaultColor) { this.defaultColor = defaultColor; }
	
	//====================================================================================================
	// implemented interfaces
    
    //----------------------------------------------------------------------------------------------------
	public int getRGB(double value) { return getColor(value).getRGB(); }
	public int getAlpha(double value) { return getColor(value).getAlpha(); }
	public double defaultValue() { return minLevel; }
	public double getMinLevel() { return minLevel; }
	public double getMaxLevel() { return maxLevel; }
	public Color getDefaultColor() { return defaultColor; }
	
    //----------------------------------------------------------------------------------------------------
	public Color getColor(double value) {		
        int izV = (int) (253 * (value - this.minLevel) 
                / (this.maxLevel - this.minLevel)) + 2;
        if (izV < 0 || izV > 255) return defaultColor;
        return new Color(this.red[izV],this.green[izV],this.blue[izV]);
	}

	//----------------------------------------------------------------------------------------------------
	public boolean validLevel(double value) {
        return (value <= maxLevel && value >= minLevel);            
	}

	//----------------------------------------------------------------------------------------------------
	public String getName() {
		StringBuilder result = new StringBuilder("Rainbow colormap");
		if (minLevel != - Double.MAX_VALUE || maxLevel != Double.MAX_VALUE) {
			result.append(" [");
			result.append(minLevel == - Double.MAX_VALUE ? "" : String.valueOf(minLevel));
			result.append("..");
			result.append(maxLevel == Double.MAX_VALUE ? "" : String.valueOf(maxLevel));
			result.append("]");
		}
		return result.toString();
	}
}