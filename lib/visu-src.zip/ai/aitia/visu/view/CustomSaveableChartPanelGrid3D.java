package ai.aitia.visu.view;

import java.awt.event.ActionEvent;

public class CustomSaveableChartPanelGrid3D {
	
	/**
     * Creates a popup menu for the panel.
     *
     * @param properties  include a menu item for the chart property editor.
     * @param save  include a menu item for saving the chart.
     * @param print  include a menu item for printing the chart.
     * @param zoom  include menu items for zooming.
     *
     * @return The popup menu.
     */
   /* protected JPopupMenu createPopupMenu(boolean properties, 
                                         boolean save, 
                                         boolean print,
                                         boolean zoom) {
        JPopupMenu result = super.createPopupMenu(properties, save, print, zoom);
        
        result.addSeparator();
        JMenuItem saveDataItem = new JMenuItem("Save Data");
        saveDataItem.setActionCommand("SAVE_DATA");
        saveDataItem.addActionListener(this);
        result.add(saveDataItem);
        
        result.addSeparator();
        
        if (NEED_MOVIE) {
	        JMenuItem makeMovie = new JMenuItem("Make Movie...");
			makeMovie.setActionCommand("MOVIE");
			makeMovie.addActionListener(this);
			result.add(makeMovie);
			
			result.addSeparator();
	        finishMovie = new JMenuItem("Finish Movie...");
			finishMovie.setActionCommand("FINISHMOVIE");
			finishMovie.addActionListener(this);
			finishMovie.setEnabled(false);
			result.add(finishMovie);
			
			
            
			if(this.getChart().getPlot().getClass().equals(org.jfree.chart.plot.XYPlot.class)){
				XYPlot pl=(XYPlot)this.getChart().getPlot();
				if((pl.getDataset().getClass().equals(TimeSeriesCollection.class)) ||
						(pl.getDataset().getClass().equals(XYSeriesCollection.class))	){
					result.addSeparator();
			        JMenuItem maxItemCount = new JMenuItem("Set max item count");
			        maxItemCount.setActionCommand("MAX_ITEM_COUNT");
					maxItemCount.addActionListener(this);
					result.add(maxItemCount);
				}
						
			}
		}
        return result;

    }*/
    
    public void actionPerformed(ActionEvent event) {
    	
    	String command = event.getActionCommand();
        if (command.equals("MOVIE")) {
            doMakeMovie();
        }
        if (command.equals("FINISH_MOVIE")) {
            doFinishMovie();
        }
        if (command.equals("MAX_ITEM_COUNT")) {
            doSetMaxItemCount();
        }
        if (command.equals("SAVE_DATA")) {
			doSaveData();
		}
    }
    
    private void doMakeMovie()
    {
    	
    }
    
    private void doFinishMovie()
    {
    	
    }
    
    private void doSetMaxItemCount()
    {
    	
    }
    
    private void doSaveData()
    {
    	
    }

}
