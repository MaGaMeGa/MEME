package ai.aitia.chart.view.ui;

import java.awt.Color;

import ai.aitia.visu.view.ui.ColorMap;

public class ConstantColorMap implements ColorMap {
	
	//====================================================================================================
	// members
	
	private final Color color;
	private final Color defaultColor;

	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public ConstantColorMap(final Color color) { this(color,Color.BLACK); }
	
	//----------------------------------------------------------------------------------------------------
	public ConstantColorMap(final Color color, final Color defaultColor) {
		this.color = color;
		this.defaultColor = defaultColor;
	}

	//====================================================================================================
	// implemented interfaces

	//----------------------------------------------------------------------------------------------------
	public double defaultValue() { return - Double.MAX_VALUE; }
	public Color getDefaultColor() { return defaultColor; }
	public String getName() { return "Constant colormap (#" + Integer.toHexString(color.getRGB()) + ")"; }
	public boolean validLevel(double level) { return true; }
	
	//----------------------------------------------------------------------------------------------------
	public int getAlpha(final double level) {
		if (level == - Double.MAX_VALUE)
			return defaultColor.getAlpha();
		return color.getAlpha();
	}

	//----------------------------------------------------------------------------------------------------
	public Color getColor(final double level) {
		if (level == - Double.MAX_VALUE)
			return defaultColor;
		return color;
	}

	//----------------------------------------------------------------------------------------------------
	public double getMaxLevel() { 
		return Double.longBitsToDouble(Double.doubleToLongBits(Double.MAX_VALUE) - Double.doubleToLongBits(Double.MIN_VALUE));
	}

	//----------------------------------------------------------------------------------------------------
	public double getMinLevel() {
		return - Double.longBitsToDouble(Double.doubleToLongBits(Double.MAX_VALUE) - Double.doubleToLongBits(Double.MIN_VALUE));
	}

	//----------------------------------------------------------------------------------------------------
	public int getRGB(final double level) {
		if (level ==  - Double.MAX_VALUE)
			return defaultColor.getRGB();
		return color.getRGB();
	}
}