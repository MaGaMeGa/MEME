/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.ColorMapPanel;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.IColorMapUser;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.ds.IGrid2DDatasetProducer;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.globalhandlers.UserBreakException;

/** GUI component of the two-dimesional grids. */
public class OneDSeriesDialog extends AbstractChartDialog implements IColorMapUser {

	private static final long serialVersionUID = 1L;
	
	private JTabbedPane tabbed = null;
	private JPanel buttonPanel = null;
	private JButton cancelButton = null;
	private JPanel mainPanel = null;
	private JPanel detailsPanel = null;
	private JPanel fullPanel = null;
	private JPanel partialPanel = null;
	private JPanel firstPanel = null;
	private JPanel valuesPanel = null;
	private JComboBox valuesParam = null;
	private JButton advancedButton = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	
	private ButtonGroup orderButtonGroup = null;
	private JPanel orderPanel = null;
	private JRadioButton rowRadioButton = null;
	private JRadioButton columnRadioButton = null;
	private JLabel jLabel2 = null;
	private JPanel orderButtonPanel = null;
	private JPanel reqPanel = null;
	private JPanel optPanel = null;
	private JPanel colorPanel = null;
	private JComboBox colorParam = null;
	private JButton colorAdvancedButton = null;
	
//	private JLabel jLabel3 = null;
	
	private JLabel jLabel4 = null;
	
	private JPanel titleLine = null;
	private JPanel subtitleLine = null;
	private JPanel rowLabelLine = null;
	private JPanel columnLabelLine = null;
	private JLabel jLabel5 = null;
	private JLabel jLabel6 = null;
	private JTextField subtitleField = null;
	private JLabel jLabel7 = null;
	private JTextField rowLabelField = null;
	private JLabel jLabel8 = null;
	private JTextField columnLabelField = null;
	private JPanel colormapPanel = null;
	private ColorMapPanel cmp = null;
	private JPanel colorbarLine = null;
	private JLabel jLabel9 = null;
	private JPanel colorbarButtonPanel = null;
	private JRadioButton showRadioButton = null;
	private JRadioButton hideRadioButton = null;
	private ButtonGroup colorbarButtonGroup = null; 
	
	private JLabel jLabel10 = null;
	private JButton fFixWidthButton = null;
	
//	private JLabel jLabel12 = null;
	private JComboBox pWidthParam = null;
	private JButton pDsWidthButton = null;
//	private JPanel pHeightPanel = null;
//	private JPanel pFixHeightPanel = null;
	private JButton pFixHeightButton = null;
//	private JPanel pDsHeightPanel = null;
//	private JLabel jLabel13 = null;
	private JComboBox pHeightParam = null;
	private JButton pDsHeightButton = null;
	private JPanel appearancePanel = null;
	private JLabel jLabel14 = null;
	private JComboBox appearanceBox = null;
	private JCheckBox tooltipBox = new JCheckBox("Generate tooltips");
	private JTextField maxField = null;
	private JPanel itemLine = null;

	//==============================================================================
	// additional members
	
	/** Constant label text for series producers. */
//	private static final String DEFAULT_TEXT = "Dimensions (one of them is mandatory)";
	
	/** Constant label text for dataset producers. */
//	private static final String SPECIAL_TEXT = "Dimensions from the complete grid";  //  @jve:decl-index=0:

	/** Flag that determines the mode of the chart (sequential or random). */
	private boolean is_full = true;
	
	/** Flag that determines the kind of the width parameter in sequential mode. */
	private boolean user_defined_width = false;
	
	/** Flag that determines the kind of the height parameter in sequential mode. */
	private boolean user_defined_height = false;
	
	/** Flag that determines the kind of the width parameter in random mode. */
	private boolean r_user_defined_width = false;
	
	/** Flag that determines the kind of the height parameter in random mode. */
	private boolean r_user_defined_height = false;

	//==============================================================================
	// methods
	
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public OneDSeriesDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
	}

	//------------------------------------------------------------------------------
	/**
	 * This method initializes <code>this</code>.
	 */
	private void initialize() {
		orderButtonGroup = new ButtonGroup();
		colorbarButtonGroup = new ButtonGroup();
		this.setSize(609, 219);
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.setPreferredSize(new Dimension(609, 219));
		this.setMinimumSize(new Dimension(609, 219));
		this.add(getTabbed(), null);
		this.add(getButtonPanel(), null);
	}

	//------------------------------------------------------------------------------
	private JTabbedPane getTabbed() {
		if (tabbed == null) {
			tabbed = new JTabbedPane();
			tabbed.addTab("Main Settings",Utilities.icons.get(ChartConstants.ONEDSERIES), getMainPanel(), null);
			tabbed.addTab("Details", null, getDetailsPanel(), null);
			tabbed.addTab("Colors", null, getColormapPanel(), null);
		}
		return tabbed;
	}

	//------------------------------------------------------------------------------
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = new JPanel();
			buttonPanel.setLayout(new FlowLayout());
			buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
			buttonPanel.add(getEditorButton(), null);
			buttonPanel.add(getDisplayButton(), null);
			buttonPanel.add(getSaveButton(), null);
			buttonPanel.add(getCancelButton(), null);
		}
		return buttonPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getDisplayButton() {
		if (displayButton == null) {
			displayButton = new JButton();
			displayButton.setText("Display");
			displayButton.setMnemonic(KeyEvent.VK_D);
			displayButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					displayChart();
				}
			});
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)valuesParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)
					&& cmp.hasDefinedColormap()) {
					displayButton.setEnabled(true);
				}
			}
		}
		return displayButton;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}

	//------------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setEnabled(false);
			saveButton.setText("Save");
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					saveCollection();
				}
			});
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)valuesParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class) && cmp.hasDefinedColormap()) {
					saveButton.setEnabled(true);
				}
			}
		}
		return saveButton;
	}

	//------------------------------------------------------------------------------
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMnemonic(KeyEvent.VK_C);
			cancelButton.setText("Cancel");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					notifyForHide();
				}
			});
		}
		return cancelButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(new CardLayout());
			mainPanel.add(getFullPanel(), getFullPanel().getName());
			mainPanel.add(getPartialPanel(), getPartialPanel().getName());
		}
		return mainPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getDetailsPanel() {
		if (detailsPanel == null) {
			detailsPanel = new JPanel();
			detailsPanel.setLayout(new BoxLayout(getDetailsPanel(), BoxLayout.Y_AXIS));
			detailsPanel.setBorder(BorderFactory.createTitledBorder(null, "Titles and labels of the chart", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			detailsPanel.add(getTitleLine(), null);
			detailsPanel.add(getSubtitleLine(), null);
			detailsPanel.add(getRowLabelLine(), null);
			detailsPanel.add(getColumnLabelLine(), null);
			JPanel temp = new JPanel();
			temp.setLayout(new BoxLayout(temp,BoxLayout.X_AXIS));
			JLabel dummy = new JLabel(" ");
			dummy.setPreferredSize(new Dimension(100,16));
			temp.add(dummy,null);
			temp.add(tooltipBox);
			temp.add(Box.createHorizontalGlue());
			detailsPanel.add(temp,null);
		}
		return detailsPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getFullPanel() {
		if (fullPanel == null) {
			fullPanel = new JPanel();
			fullPanel.setLayout(new BoxLayout(getFullPanel(), BoxLayout.Y_AXIS));
			fullPanel.setName(ChartConstants.FULL);
			fullPanel.add(getFirstPanel(), null);
			fullPanel.add(Box.createRigidArea(new Dimension(0,5)));
			fullPanel.add(getItemLine(), null);
			fullPanel.add(getOrderPanel(), null);
		}
		return fullPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getPartialPanel() {
		if (partialPanel == null) {
			partialPanel = new JPanel();
			partialPanel.setLayout(new BoxLayout(getPartialPanel(), BoxLayout.Y_AXIS));
			partialPanel.setName(ChartConstants.PARTIAL);
			partialPanel.add(getReqPanel(), null);
			partialPanel.add(getOptPanel(), null);
		}
		return partialPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getFirstPanel() {
		if (firstPanel == null) {
			firstPanel = new JPanel();
			firstPanel.setLayout(new BoxLayout(getFirstPanel(), BoxLayout.X_AXIS));
			firstPanel.add(getValuesPanel(), null);
			//firstPanel.add(getFSwitchPanel(), null);
		}
		return firstPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getValuesPanel() {
		if (valuesPanel == null) {
			valuesPanel = new JPanel();
			valuesPanel.setLayout(new BoxLayout(getValuesPanel(), BoxLayout.X_AXIS));
			valuesPanel.setBorder(BorderFactory.createTitledBorder(null, "Color values / Complete grid", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			valuesPanel.add(getValuesParam(), null);
			valuesPanel.add(Box.createRigidArea(new Dimension(5,0)));
			valuesPanel.add(getAdvancedButton(), null);
		}
		return valuesPanel;
	}
	private JPanel getItemLine() {
		if (itemLine == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("  Max. count of displayed items:  ");
			itemLine = new JPanel();
			itemLine.setLayout(new BoxLayout(getItemLine(), BoxLayout.X_AXIS));
			itemLine.add(jLabel4, null);
			itemLine.add(getMaxField(), null);
			properties.setProperty(ChartConstants.NR_OF_DISPLAYED_ITEMS,maxField.getText());
		}
		return itemLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getMaxField() {
		if (maxField == null) {
			maxField = new JTextField();
			maxField.setText("10");
			maxField.setMaximumSize(new Dimension(160, 30));
			maxField.setHorizontalAlignment(JTextField.TRAILING);
			maxField.setPreferredSize(new Dimension(75, 30));
			maxField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					Pattern p = Pattern.compile("^[1-9][0-9]*$");
					Matcher positive = p.matcher(maxField.getText().trim());
					try {
						if (!positive.matches())
							throw new NumberFormatException();
						Integer.parseInt(maxField.getText().trim());
					} catch (NumberFormatException ee) {
						JOptionPane.showMessageDialog(OneDSeriesDialog.this,"Invalid value in field 'Max. count of displayed items'.","Warning",JOptionPane.WARNING_MESSAGE,null);
						maxField.setText("100");
						maxField.grabFocus();
						maxField.selectAll();
					}
					properties.setProperty(ChartConstants.NR_OF_DISPLAYED_ITEMS,maxField.getText());
				}
			});
		}
		return maxField;
	}

	//------------------------------------------------------------------------------
	private JComboBox getValuesParam() {
		if (valuesParam == null) {
			valuesParam = new JComboBox(getParamsToValues());
			valuesParam.setRenderer(new DataSourceComboBoxRenderer(valuesParam));
			valuesParam.setPreferredSize(new Dimension(100,26));
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)valuesParam.getSelectedItem();
				valuesParam.setToolTipText(dsp.toString());
			}
			valuesParam.addActionListener(new java.awt.event.ActionListener() {
				@SuppressWarnings("unchecked")
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) valuesParam.getSelectedItem();
					valuesParam.setToolTipText(dsp.toString());
					advancedButton.setEnabled(dsp.hasAdvancedSettings());
					/*if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
						fDimensionPanel.setBorder(BorderFactory.createTitledBorder(null,SPECIAL_TEXT, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
						setEnabledDOWidgets(false);
						if (cmp.hasDefinedColormap()) {
							displayButton.setEnabled(true);
							ChartDialogChangeCenter.fireSaveEnabled(OneDSeriesDialog.this);
						}
					} else {
						fDimensionPanel.setBorder(BorderFactory.createTitledBorder(null,DEFAULT_TEXT, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
						setEnabledDOWidgets(true);
						boolean w_valid = (user_defined_width && is_valid(fWidthField.getText())) || (!user_defined_width && fWidthParam.getItemCount() > 0);
						boolean h_valid = (user_defined_height && is_valid(fHeightField.getText())) || (!user_defined_height && fHeightParam.getItemCount() > 0);
						if (!w_valid && !h_valid) {
							displayButton.setEnabled(false);
							ChartDialogChangeCenter.fireSaveDisabled(OneDSeriesDialog.this);
						}
					}*/
					
					try {
						// Begins a long operation
						List<Double> list = (List<Double>)ChartConfigCollection.
						getLOPExecutor().execute("Calculating minimum/maximum values",
								   				 dsp,"getRange");
						setMinMax(list);
					} catch (UserBreakException e1) { 
						setMinMax(null);
					} catch (Throwable t) {
						ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
					}
				}
			});
		}
		return valuesParam;
	}
	
	//------------------------------------------------------------------------------
	private JButton getAdvancedButton() {
		if (advancedButton == null) {
			advancedButton = new JButton();
			advancedButton.setEnabled(false);
			advancedButton.setText("Advanced...");
			advancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)valuesParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(OneDSeriesDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = valuesParam.getSelectedIndex();
						valuesParam.removeItemAt(index);
						valuesParam.insertItemAt(new_dsp,index);
						valuesParam.setSelectedIndex(index);
					}
				}
			});
			if (valuesParam.getItemCount()>0) {
				IDataSourceProducer dsp = (IDataSourceProducer)valuesParam.getSelectedItem();
				advancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return advancedButton;
	}

	/*
	//------------------------------------------------------------------------------
	private JPanel getFDimensionPanel() {
		if (fDimensionPanel == null) {
			fDimensionPanel = new JPanel();
			fDimensionPanel.setLayout(new BoxLayout(getFDimensionPanel(), BoxLayout.X_AXIS));
			String text = DEFAULT_TEXT;
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)valuesParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
					text = SPECIAL_TEXT;
				}
			}
			fDimensionPanel.setBorder(BorderFactory.createTitledBorder(null,text, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			fDimensionPanel.add(getFWidthPanel(), null);
			fDimensionPanel.add(Box.createRigidArea(new Dimension(5,0)));
			fDimensionPanel.add(getFHeightPanel(), null);
		}
		return fDimensionPanel;
	}
*/
	
	//------------------------------------------------------------------------------
	private JPanel getOrderPanel() {
		if (orderPanel == null) {
			jLabel2 = new JLabel();
			jLabel2.setText("  Filling order:  ");
			orderPanel = new JPanel();
			orderPanel.setLayout(new BoxLayout(getOrderPanel(), BoxLayout.X_AXIS));
			orderPanel.setPreferredSize(new Dimension(400, 35));
			orderPanel.setMaximumSize(new Dimension(32831,35));
			orderPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
			orderPanel.add(jLabel2, null);
			orderPanel.add(getOrderButtonPanel(), null);
		}
		return orderPanel;
	}

	//------------------------------------------------------------------------------
	private JRadioButton getRowRadioButton() {
		if (rowRadioButton == null) {
			rowRadioButton = new JRadioButton();
			rowRadioButton.setSelected(true);
			rowRadioButton.setText("Left-to-Right");
			rowRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.ROW_ORDER,"true");
				}
			});
			orderButtonGroup.add(rowRadioButton);
		}
		return rowRadioButton;
	}

	//------------------------------------------------------------------------------
	private JRadioButton getColumnRadioButton() {
		if (columnRadioButton == null) {
			columnRadioButton = new JRadioButton();
			columnRadioButton.setText("Top-to-Bottom");
			columnRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.ROW_ORDER,"false");
				}
			});
			orderButtonGroup.add(columnRadioButton);
			if (valuesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)valuesParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
					rowRadioButton.setEnabled(false);
					columnRadioButton.setEnabled(false);
				}
			}
		}
		return columnRadioButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getOrderButtonPanel() {
		if (orderButtonPanel == null) {
			orderButtonPanel = new JPanel();
			orderButtonPanel.setLayout(new BoxLayout(getOrderButtonPanel(), BoxLayout.X_AXIS));
			orderButtonPanel.add(getRowRadioButton(), null);
			orderButtonPanel.add(getColumnRadioButton(), null);
		}
		return orderButtonPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getReqPanel() {
		if (reqPanel == null) {
			GridLayout gridLayout = new GridLayout(0,2);
			reqPanel = new JPanel();
			reqPanel.setLayout(gridLayout);
			//reqPanel.add(getXPanel(), null);
			//reqPanel.add(getPSwitchPanel(), null);
			//reqPanel.add(getYPanel(), null);
			reqPanel.add(getColorPanel(), null);
		}
		return reqPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getOptPanel() {
		if (optPanel == null) {
			optPanel = new JPanel();
			optPanel.setLayout(new BoxLayout(getOptPanel(), BoxLayout.X_AXIS));
			optPanel.setBorder(BorderFactory.createTitledBorder(null, "Dimensions (optional)", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			
			optPanel.add(Box.createRigidArea(new Dimension(5,0)));
			
		}
		return optPanel;
	}

	//------------------------------------------------------------------------------
	/*private JPanel getXPanel() {
		if (xPanel == null) {
			xPanel = new JPanel();
			xPanel.setLayout(new BoxLayout(getXPanel(), BoxLayout.X_AXIS));
			xPanel.setBorder(BorderFactory.createTitledBorder(null, "X values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			xPanel.add(getXParam(), null);
			xPanel.add(Box.createRigidArea(new Dimension(5,0)));
			xPanel.add(getXAdvancedButton(), null);
		}
		return xPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getXParam() {
		if (xParam == null) {
			xParam = new JComboBox(getParamsToAll());
			xParam.setRenderer(new DataSourceComboBoxRenderer(xParam));
			xParam.setPreferredSize(new Dimension(100,26));
			if (xParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)xParam.getSelectedItem();
				xParam.setToolTipText(dsp.toString());
			}
			xParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)xParam.getSelectedItem();
					xParam.setToolTipText(dsp.toString());
					xAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
					updateRowAndColumnLabels();
				}
			});
		}
		return xParam;
	}

	//------------------------------------------------------------------------------
	private JButton getXAdvancedButton() {
		if (xAdvancedButton == null) {
			xAdvancedButton = new JButton();
			xAdvancedButton.setEnabled(false);
			xAdvancedButton.setText("Advanced...");
			xAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)xParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(OneDSeriesDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = xParam.getSelectedIndex();
						xParam.removeItemAt(index);
						xParam.insertItemAt(new_dsp,index);
						xParam.setSelectedIndex(index);
					}
				}
			});
			if (xParam.getItemCount()>0) {
				IDataSourceProducer dsp = (IDataSourceProducer)xParam.getSelectedItem();
				xAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return xAdvancedButton;
	}

	

	
	//------------------------------------------------------------------------------
	private JPanel getYPanel() {
		if (yPanel == null) {
			yPanel = new JPanel();
			yPanel.setLayout(new BoxLayout(getYPanel(), BoxLayout.X_AXIS));
			yPanel.setBorder(BorderFactory.createTitledBorder(null, "Y values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			yPanel.add(getYParam(), null);
			yPanel.add(Box.createRigidArea(new Dimension(5,0)));
			yPanel.add(getYAdvancedButton(), null);
		}
		return yPanel;
	}
	*/
	//------------------------------------------------------------------------------
	private JPanel getColorPanel() {
		if (colorPanel == null) {
			colorPanel = new JPanel();
			colorPanel.setLayout(new BoxLayout(getColorPanel(), BoxLayout.X_AXIS));
			colorPanel.setBorder(BorderFactory.createTitledBorder(null, "Color values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			colorPanel.add(getColorParam(), null);
			colorPanel.add(Box.createRigidArea(new Dimension(5,0)));
			colorPanel.add(getColorAdvancedButton(), null);
		}
		return colorPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getColorParam() {
		if (colorParam == null) {
			colorParam = new JComboBox(getParamsToAll());
			colorParam.setRenderer(new DataSourceComboBoxRenderer(colorParam));
			colorParam.setPreferredSize(new Dimension(100,26));
			if (colorParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)colorParam.getSelectedItem();
				colorParam.setToolTipText(dsp.toString());
			}
			colorParam.addActionListener(new java.awt.event.ActionListener() {
				@SuppressWarnings("unchecked")
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)colorParam.getSelectedItem();
					colorParam.setToolTipText(dsp.toString());
					colorAdvancedButton.setEnabled(dsp.hasAdvancedSettings());

					try {
						// Begins a long operations
						List<Double> list = (List<Double>)ChartConfigCollection.
						getLOPExecutor().execute("Calculating minimum/maximum values",
									             dsp,"getRange");
						setMinMax(list);
					} catch (UserBreakException e1) { 
						setMinMax(null);
					} catch (Throwable t) {
						ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
					}
				}
			});
		}
		return colorParam;
	}

	//------------------------------------------------------------------------------
	private JButton getColorAdvancedButton() {
		if (colorAdvancedButton == null) {
			colorAdvancedButton = new JButton();
			colorAdvancedButton.setEnabled(false);
			colorAdvancedButton.setText("Advanced...");
			colorAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)colorParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(OneDSeriesDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = colorParam.getSelectedIndex();
						colorParam.removeItemAt(index);
						colorParam.insertItemAt(dsp,index);
						colorParam.setSelectedIndex(index);
					}
				}
			});
			if (colorParam.getItemCount()>0) {
				IDataSourceProducer dsp = (IDataSourceProducer)colorParam.getSelectedItem();
				colorAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}

		}
		return colorAdvancedButton;
	}

	

	//------------------------------------------------------------------------------
	private JPanel getTitleLine() {
		if (titleLine == null) {
			jLabel5 = new JLabel();
			jLabel5.setText("  Title:  ");
			jLabel5.setPreferredSize(new Dimension(100, 16));
			titleLine = new JPanel();
			titleLine.setLayout(new BoxLayout(getTitleLine(), BoxLayout.X_AXIS));
			titleLine.setPreferredSize(new Dimension(400, 20));
			titleLine.add(jLabel5, null);
			titleLine.add(getTitleField(), null);
		}
		return titleLine;
	}

	//------------------------------------------------------------------------------
	private JPanel getSubtitleLine() {
		if (subtitleLine == null) {
			jLabel6 = new JLabel();
			jLabel6.setText("  Subtitle:  ");
			jLabel6.setPreferredSize(new Dimension(100, 16));
			subtitleLine = new JPanel();
			subtitleLine.setLayout(new BoxLayout(getSubtitleLine(), BoxLayout.X_AXIS));
			subtitleLine.setPreferredSize(new Dimension(400, 20));
			subtitleLine.add(jLabel6, null);
			subtitleLine.add(getSubtitleField(), null);
		}
		return subtitleLine;
	}

	//------------------------------------------------------------------------------
	private JPanel getRowLabelLine() {
		if (rowLabelLine == null) {
			jLabel7 = new JLabel();
			jLabel7.setText("  Row label:  ");
			jLabel7.setPreferredSize(new Dimension(100, 16));
			rowLabelLine = new JPanel();
			rowLabelLine.setLayout(new BoxLayout(getRowLabelLine(), BoxLayout.X_AXIS));
			rowLabelLine.setPreferredSize(new Dimension(400, 20));
			rowLabelLine.add(jLabel7, null);
			rowLabelLine.add(getRowLabelField(), null);
		}
		return rowLabelLine;
	}

	//------------------------------------------------------------------------------
	private JPanel getColumnLabelLine() {
		if (columnLabelLine == null) {
			jLabel8 = new JLabel();
			jLabel8.setText(" Column label:  ");
			jLabel8.setPreferredSize(new Dimension(100, 16));
			columnLabelLine = new JPanel();
			columnLabelLine.setLayout(new BoxLayout(getColumnLabelLine(), BoxLayout.X_AXIS));
			columnLabelLine.setPreferredSize(new Dimension(400, 20));
			columnLabelLine.add(jLabel8, null);
			columnLabelLine.add(getColumnLabelField(), null);
		}
		return columnLabelLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getTitleField() {
		if (titleField == null) {
			titleField = new JTextField();
			titleField.setPreferredSize(new Dimension(300, 20));
			titleField.setText(ChartConstants.ONEDSERIES_NAME);
			titleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.TITLE,titleField.getText());
					ChartDialogChangeCenter.fireTitleChanged(OneDSeriesDialog.this);
				}
			});
			titleField.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					subtitleField.grabFocus();
				}
			});
		}
		return titleField;
	}

	//------------------------------------------------------------------------------
	private JTextField getSubtitleField() {
		if (subtitleField == null) {
			subtitleField = new JTextField();
			subtitleField.setPreferredSize(new Dimension(300, 20));
			subtitleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
				}
			});
		}
		return subtitleField;
	}

	//------------------------------------------------------------------------------
	private JTextField getRowLabelField() {
		if (rowLabelField == null) {
			rowLabelField = new JTextField();
			rowLabelField.setPreferredSize(new Dimension(300, 20));
			rowLabelField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.ROW_LABEL,rowLabelField.getText());
				}
			});
		}
		return rowLabelField;
	}

	//------------------------------------------------------------------------------
	private JTextField getColumnLabelField() {
		if (columnLabelField == null) {
			columnLabelField = new JTextField();
			columnLabelField.setPreferredSize(new Dimension(300, 20));
			columnLabelField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.COLUMN_LABEL,columnLabelField.getText());
				}
			});
		}
		return columnLabelField;
	}

	//------------------------------------------------------------------------------
	private JPanel getColormapPanel() {
		if (colormapPanel == null) {
			colormapPanel = new JPanel();
			colormapPanel.setLayout(new BoxLayout(getColormapPanel(), BoxLayout.Y_AXIS));
			colormapPanel.setBorder(BorderFactory.createTitledBorder(null, "Colors of the chart", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			cmp = new ColorMapPanel(this);
			cmp.setPreferredSize(new Dimension(609,28));
			cmp.setMaximumSize(new Dimension(32831,36));
			colormapPanel.add(getAppearancePanel(), null);
			colormapPanel.add(cmp,null);
			colormapPanel.add(getColorbarLine(), null);
		}
		return colormapPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getColorbarLine() {
		if (colorbarLine == null) {
			jLabel9 = new JLabel();
			jLabel9.setPreferredSize(new Dimension(100, 16));
			jLabel9.setText("  Colorbar:  ");
			colorbarLine = new JPanel();
			colorbarLine.setLayout(new BoxLayout(getColorbarLine(), BoxLayout.X_AXIS));
			colorbarLine.setPreferredSize(new Dimension(400, 28));
			colorbarLine.setMaximumSize(new Dimension(32831, 28));
			colorbarLine.add(jLabel9, null);
			colorbarLine.add(Box.createRigidArea(new Dimension(35,0)));
			colorbarLine.add(getColorbarButtonPanel(), null);
		}
		return colorbarLine;
	}

	//------------------------------------------------------------------------------
	private JPanel getColorbarButtonPanel() {
		if (colorbarButtonPanel == null) {
			colorbarButtonPanel = new JPanel();
			colorbarButtonPanel.setLayout(new BoxLayout(getColorbarButtonPanel(), BoxLayout.X_AXIS));
			colorbarButtonPanel.add(getShowRadioButton(), null);
			colorbarButtonPanel.add(getHideRadioButton(), null);
		}
		return colorbarButtonPanel;
	}

	//------------------------------------------------------------------------------
	private JRadioButton getShowRadioButton() {
		if (showRadioButton == null) {
			showRadioButton = new JRadioButton();
			showRadioButton.setText("Show colorbar");
			showRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.COLORBAR,"true");
				}
			});
			colorbarButtonGroup.add(showRadioButton);
		}
		return showRadioButton;
	}

	//------------------------------------------------------------------------------
	private JRadioButton getHideRadioButton() {
		if (hideRadioButton == null) {
			hideRadioButton = new JRadioButton();
			hideRadioButton.setText("Hide colorbar");
			hideRadioButton.setSelected(true);
			hideRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.COLORBAR,"false");
				}
			});
			colorbarButtonGroup.add(hideRadioButton);
		}
		return hideRadioButton;
	}

	
	
	//------------------------------------------------------------------------------
	private JPanel getAppearancePanel() {
		if (appearancePanel == null) {
			jLabel14 = new JLabel();
			jLabel14.setText("  Appearance:  ");
			appearancePanel = new JPanel();
			appearancePanel.setLayout(new BoxLayout(getAppearancePanel(), BoxLayout.X_AXIS));
			appearancePanel.setMaximumSize(new Dimension(Integer.MAX_VALUE,25));
			appearancePanel.add(jLabel14, null);
			appearancePanel.add(Box.createRigidArea(new Dimension(26,0)));
			appearancePanel.add(getAppearanceBox(), null);
		}
		return appearancePanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getAppearanceBox() {
		if (appearanceBox == null) {
			Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
			appearances.add(new ComboboxItem( "BC", "Basic, colored"));
			appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
			appearances.add(new ComboboxItem( "NC", "Normal, colored"));
			appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
			for (String templateNames : AbstractChart.templates.keySet())
				appearances.add(new ComboboxItem("_" + templateNames,templateNames));
			appearances.add(new ComboboxItem("_NEW","New template..."));
			appearances.add(new ComboboxItem("_EDIT","Edit template..."));
			appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
			appearanceBox = new JComboBox(appearances);
			appearanceBox.setPreferredSize(new Dimension(154,25));
			appearanceBox.setMaximumSize(new Dimension(154,25));
			appearanceBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int index = appearanceBox.getSelectedIndex();
					String id = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
					if (index >= 0 && index <= 3) {
				 		String[] code = new String[] { id.substring(0,1), id.substring(1) };
				 		if (code[0].equals("B"))
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.BASIC_APP);
				 		else
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.NORMAL_APP);
				 		if (code[1].equals("BW")) {
				 			ChartConfigCollection.setColorAppearance(ChartConstants.BLACK_AND_WHITE);
				 			cmp.reloadCombobox(true,cmp.getColorMapType().toString());
				 		} else {
				 			ChartConfigCollection.setColorAppearance(ChartConstants.COLORED);
				 			cmp.reloadCombobox(false,cmp.getColorMapType().toString());
				 		}
					} else if (id.equals("_NEW")) {
						ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.NORMAL);
						int result = dlg.showDialog();
						if (result == ChartPropertiesDialog.OK_OPTION) {
							Element newTemplate = (Element) dlg.getTemplate();
							dlg.dispose();
							String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
							AbstractChart.templates.put(name,newTemplate);
							ChartDialogChangeCenter.fireTemplateChanged();
							appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
						} else 
							appearanceBox.setSelectedIndex(0);
					} else if (id.equals("_EDIT")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(OneDSeriesDialog.this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(OneDSeriesDialog.this,"Select a template: ","Edit template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template == null || "".equals(template)) 
							appearanceBox.setSelectedIndex(0);
						else {
							Element templateElement = AbstractChart.templates.get(template);
							ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(),ChartKind.NORMAL);
							int result = dlg.showDialog();
							if (result == ChartPropertiesDialog.OK_OPTION) {
								Element newTemplate = (Element) dlg.getTemplate();
								dlg.dispose();
								String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
								AbstractChart.templates.put(name,newTemplate);
								ChartDialogChangeCenter.fireTemplateChanged();
								appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
							} else 
								appearanceBox.setSelectedIndex(0);
						}
					} else if (id.equals("_REMOVE")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(OneDSeriesDialog.this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(OneDSeriesDialog.this,"Select a template: ","Delete template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template != null && !"".equals(template)) { 
							AbstractChart.templates.remove(template);
							File file = new File("Templates/" + template + ".xml");
							file.delete();
							ChartDialogChangeCenter.fireTemplateChanged();
						}
						appearanceBox.setSelectedIndex(0);
					}
				}
			});
		}
		return appearanceBox;
	}
	
	//------------------------------------------------------------------------------
	private List<String> getLegends() {	return new ArrayList<String>(); }

	//==============================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-generated functions                                                //
	////////////////////////////////////////////////////////////////////////////
	
	//----------------------------------------------------------------------------------------------------
	/** Returns the current data source of the color values.
	 * @return the current data source of the color value
	 */
	public IDataSourceProducer getColorValueProducer() {
		IDataSourceProducer selected = (IDataSourceProducer)(is_full ? valuesParam.getSelectedItem() : colorParam.getSelectedItem());
		return selected;
	}
	
	//----------------------------------------------------------------------------------------------------
	public void setUpdateStatus(boolean status) {
		boolean paramsAvailable = /*valuesParam.getItemCount() > 0; */ isUpdateable();
		displayButton.setEnabled(paramsAvailable && status);
		if (paramsAvailable && status)
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}

	//------------------------------------------------------------------------------
	/** Returns whether the input string contains a valid positive integer or
	 *  not.
	 * @param text input string
	 */
	@SuppressWarnings("unused")
	private boolean is_valid(String text) {
		Pattern p = Pattern.compile("^[1-9][0-9]*$"); // pattern for positive integers
		Matcher m = p.matcher(text.trim());
		if (m.matches()) {
			try {
				Integer.parseInt(text.trim());
				return true;
			} catch (NumberFormatException e) {}
		}
		return false;
	}
	
	//------------------------------------------------------------------------------
	/** It calls setEnabled on dimension and order widgets. */
	private void setEnabledDOWidgets(boolean enabled) {
		jLabel.setEnabled(enabled);
		
		jLabel10.setEnabled(enabled);
		jLabel1.setEnabled(enabled);
		jLabel2.setEnabled(enabled);
		rowRadioButton.setEnabled(enabled);
		columnRadioButton.setEnabled(enabled);
	}
	
	//------------------------------------------------------------------------------
	@Override
	protected void setWidgetDisabled() {
		if (valuesParam.getItemCount() == 0) {
			valuesParam.setEnabled(false);
			colorParam.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			advancedButton.setEnabled(false);
			colorAdvancedButton.setEnabled(false);
		}
		if (colorParam.getItemCount() == 0) {
			colorParam.setEnabled(false);
			
			colorAdvancedButton.setEnabled(false);
			
		}
	}
	
	//------------------------------------------------------------------------------
	/** Returns the displayable names of the data sources for all (non-dimensional)
	 *  comboboxes (except <code>valuesParam</code>).
	 * @return array of data sources
	 */
 	private Object[] getParamsToAll() {
 		return getParams(new Class[] { ISeriesProducer.class, IValueProducer.class});
 	}
 	
	//------------------------------------------------------------------------------
 	/** Returns the displayable names of the data sources for <code>valuesParam</code>
 	 *  combobox.
 	 * @return array of data sources
 	 */
 	private Object[] getParamsToValues() {
 		return getParams(new Class[]{ISeriesProducer.class, IValueProducer.class, IGrid2DDatasetProducer.class});
 	}
 	
 	//------------------------------------------------------------------------------
 	/** Returns the displayable names of the data sources for dimensional comboboxes.
 	 * @return array of data sources
 	 */
 	@SuppressWarnings("unused")
	private Object[] getParamsToDimensions() {
 		return getParams(IValueProducer.class);
 	}
 	               
	//------------------------------------------------------------------------------
 	@Override
 	protected void setSettingsFromConfig() {
 		if (config.getChartProperties() instanceof Properties) {
 			//set settings from the config
 			properties = (Properties) config.getChartProperties();
 			maxField.setText(properties.getProperty(ChartConstants.NR_OF_DISPLAYED_ITEMS));
 			int[] ds = Utilities.splitDatasourceAroundCommas(properties.getProperty(ChartConstants.DATASOURCE));
 			if (ds.length==1) { // one datasource, full mode
 				is_full = true;
 				IDataSourceProducer dsp = config.getDataSource(ds[0]);
 				valuesParam.setSelectedItem(dsp);
 				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
 					setEnabledDOWidgets(false);
 				}
 			}/* else { // three datasources, partial mode
 				is_full = false;
 				CardLayout cl = (CardLayout)mainPanel.getLayout();
				cl.show(mainPanel,ChartConstants.PARTIAL);
				IDataSourceProducer dsp = config.getDataSource(ds[0]);
				xParam.setSelectedItem(dsp);
				dsp = config.getDataSource(ds[1]);
				yParam.setSelectedItem(dsp);
				dsp = config.getDataSource(ds[2]);
				colorParam.setSelectedItem(dsp);
				r_user_defined_width = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_WIDTH));
				if (r_user_defined_width) {
 					cl = (CardLayout)pWidthPanel.getLayout();
					cl.show(pWidthPanel,"P_FIX_WIDTH");
					pWidthField.setText(properties.getProperty(ChartConstants.WIDTH));
				} else {
 					IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.WIDTH)));
 					pWidthParam.setSelectedItem(vp);
				}
				r_user_defined_height = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
				if (r_user_defined_height) {
					cl = (CardLayout)pHeightPanel.getLayout();
					cl.show(pHeightPanel,"P_FIX_HEIGHT");
					pHeightField.setText(properties.getProperty(ChartConstants.HEIGHT));
				} else {
 					IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.HEIGHT)));
 					pHeightParam.setSelectedItem(vp);
				}
 			}*/
 			boolean row_order = Boolean.parseBoolean(properties.getProperty(ChartConstants.ROW_ORDER));
 			if (!row_order) columnRadioButton.setSelected(true);
 			titleField.setText(properties.getProperty(ChartConstants.TITLE));
 			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
 			rowLabelField.setText(properties.getProperty(ChartConstants.ROW_LABEL));
 			columnLabelField.setText(properties.getProperty(ChartConstants.COLUMN_LABEL));
 			boolean tooltip = Boolean.parseBoolean(properties.getProperty(ChartConstants.TOOLTIP,"false"));
 			tooltipBox.setSelected(tooltip);
 			
			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			boolean isBlackAndWhite = false;
			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
	 			String appearanceCode = "";
	 			appearanceCode += properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP) ? "N" : "B";
	 			isBlackAndWhite = properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE);
	 			appearanceCode += isBlackAndWhite ? "BW" : "C";
	 			for (int i = 0;i < appearanceBox.getItemCount();++i) {
	 				String id = ((ComboboxItem)appearanceBox.getItemAt(i)).getID().toString();
	 				if (id.equals(appearanceCode)) {
	 					appearanceBox.setSelectedIndex(i);
	 					break;
	 				}
	 			}
 			}
 			cmp.settingsFromString(properties.getProperty(ChartConstants.COLORMAP),isBlackAndWhite);
 			boolean colorbar = Boolean.parseBoolean(properties.getProperty(ChartConstants.COLORBAR));
 			if (colorbar) showRadioButton.setSelected(true);
 			displayButton.setEnabled(true);
 			saveButton.setEnabled(true);
 		} else {
 			// set the initial properties
 			properties.setProperty(ChartConstants.USER_DEFINED_WIDTH,"false");
 			properties.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"false");
 			properties.setProperty(ChartConstants.ROW_ORDER,"true");
 			properties.setProperty(ChartConstants.TITLE,ChartConstants.ONEDSERIES_NAME);
 			properties.setProperty(ChartConstants.SUBTITLE,"");
 			properties.setProperty(ChartConstants.ROW_LABEL,"");
 			properties.setProperty(ChartConstants.COLUMN_LABEL,"");
 			properties.setProperty(ChartConstants.TOOLTIP,"false");
 			properties.setProperty(ChartConstants.COLORBAR,"false");
 			properties.setProperty(ChartConstants.NR_OF_DISPLAYED_ITEMS,"10");
 			int appIndex = 0;
 			appIndex += ChartConfigCollection.getColorAppearance().equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
 			appIndex += ChartConfigCollection.getEnvironmentAppearance().equals(ChartConstants.NORMAL_APP) ? 2 : 0;
 			appearanceBox.setSelectedIndex(appIndex);
 		}
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	public void updateChartConfig() {
 		config.clearAllDataSource();
 		if (is_full) { // one datasource, full mode
 			IDataSourceProducer dsp = (IDataSourceProducer)valuesParam.getSelectedItem();
 			int key = -1;
 			if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
 			  key = config.addDataSource(dsp,IGrid2DDatasetProducer.class);
 			} else if (dsp.getSupportedIntfs().contains(ISeriesProducer.class)){
 			  key = config.addDataSource(dsp,ISeriesProducer.class);
 			} else { 
 			  key = config.addDataSource(dsp,IValueProducer.class);
 			}
 			properties.setProperty(ChartConstants.DATASOURCE,String.valueOf(key));
 			properties.setProperty(ChartConstants.USER_DEFINED_WIDTH,String.valueOf(user_defined_width));
 			
 		} /*else { // three datasources, partial mode
 			String ds = "";
 			IDataSourceProducer dsp = (IDataSourceProducer)xParam.getSelectedItem();
 			int key = -1;
 			if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
 				key = config.addDataSource(dsp,ISeriesProducer.class);
 			else key = config.addDataSource(dsp,IValueProducer.class);
 			ds = String.valueOf(key) + ",";
 			dsp = (IDataSourceProducer)yParam.getSelectedItem();
 			if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
 				key = config.addDataSource(dsp,ISeriesProducer.class);
 			else key = config.addDataSource(dsp,IValueProducer.class);
 			ds += String.valueOf(key) + ",";
 			dsp = (IDataSourceProducer)colorParam.getSelectedItem();
 			if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
 				key = config.addDataSource(dsp,ISeriesProducer.class);
 			else key = config.addDataSource(dsp,IValueProducer.class);
 			ds += String.valueOf(key);
 			properties.setProperty(ChartConstants.DATASOURCE,ds);
 			properties.setProperty(ChartConstants.USER_DEFINED_WIDTH,String.valueOf(r_user_defined_width));
 			if (r_user_defined_width)
 				properties.setProperty(ChartConstants.WIDTH,pWidthField.getText());
 			else {
 				dsp = (IDataSourceProducer) pWidthParam.getSelectedItem();
 				if (dsp == null) {
 		 			properties.setProperty(ChartConstants.USER_DEFINED_WIDTH,"true");
 		 			properties.setProperty(ChartConstants.WIDTH,"");
 				} else {
	 				if (dsp.getSupportedIntfs().contains(IValueProducer.class)) { 
	 					key = config.addDataSource(dsp,IValueProducer.class);
	 				} else { // need emulation
	 					key = config.addDataSource(dsp,ISeriesProducer.class);
	 				}
	 				properties.setProperty(ChartConstants.WIDTH,String.valueOf(key));
 				}
 			}
 			properties.setProperty(ChartConstants.USER_DEFINED_HEIGHT,String.valueOf(r_user_defined_height));
 			if (r_user_defined_height)
 				properties.setProperty(ChartConstants.HEIGHT,pHeightField.getText());
 			else {
				dsp = (IDataSourceProducer) pHeightParam.getSelectedItem();
 				if (dsp == null) {
 		 			properties.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"true");
 		 			properties.setProperty(ChartConstants.HEIGHT,"");
 				} else {
	 				if (dsp.getSupportedIntfs().contains(IValueProducer.class)) { 
	 					key = config.addDataSource(dsp,IValueProducer.class);
	 				} else { // need emulation
	 					key = config.addDataSource(dsp,ISeriesProducer.class);
	 				}
	 				properties.setProperty(ChartConstants.HEIGHT,String.valueOf(key));
 				}
 			}
 		}*/
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 3) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
	 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
	 		if (code[0].equals("B"))
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.BASIC_APP);
	 		else
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.NORMAL_APP);
	 		if (code[1].equals("BW"))
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.BLACK_AND_WHITE);
	 		else
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.COLORED);
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
		properties.setProperty(ChartConstants.TOOLTIP,String.valueOf(tooltipBox.isSelected()));
 		properties.setProperty(ChartConstants.COLORMAP,cmp.settingsToString());
 		config.setChartProperties(ChartConstants.ONEDSERIES,properties);
 	}
	
	//------------------------------------------------------------------------------
 	@Override
 	public boolean isUpdateable() {
 		if (is_full) {
 			if (valuesParam.getItemCount() == 0) return false;
 			return true;
 		} else if (colorParam.getItemCount() > 0) return true;
 		return false;
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
	protected void displayPreview() throws Exception {
		DataSources ds = new DataSources(new SimpleDSPCollection());
		ChartConfig temp_config = new ChartConfig(ds);
		temp_config.setFireInitialEvent(true);
		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
		Properties temp_prop = (Properties)properties.clone();
		temp_prop.setProperty(ChartConstants.TITLE,temp_prop.getProperty(ChartConstants.TITLE) + " (Preview illustration)");
		if (is_full) {
			temp_config.addDataSource(dsl.get(2),ISeriesProducer.class);
			temp_prop.setProperty(ChartConstants.DATASOURCE,"1");
			if (!user_defined_width) {
				temp_prop.setProperty(ChartConstants.USER_DEFINED_WIDTH,"true");
				temp_prop.setProperty(ChartConstants.WIDTH,"3");
			}
			if (!user_defined_height) {
				temp_prop.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"true");
				temp_prop.setProperty(ChartConstants.HEIGHT,"4");
			}
		} else {
			temp_config.addDataSource(dsl.get(0),ISeriesProducer.class);
			temp_config.addDataSource(dsl.get(1),ISeriesProducer.class);
			temp_config.addDataSource(dsl.get(2),ISeriesProducer.class);
			temp_prop.setProperty(ChartConstants.DATASOURCE,"1,2,3");
			if (!r_user_defined_width) {
				temp_prop.setProperty(ChartConstants.USER_DEFINED_WIDTH,"true");
				temp_prop.setProperty(ChartConstants.WIDTH,"");
			}	
			if (!r_user_defined_height) {
				temp_prop.setProperty(ChartConstants.USER_DEFINED_HEIGHT,"true");
				temp_prop.setProperty(ChartConstants.HEIGHT,"");
			}
		}
		temp_config.setChartProperties(ChartConstants.ONEDSERIES,temp_prop);
		Utilities.displayPreview(temp_config);
	}
 	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem)appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		// reset widgets
		valuesParam.setEnabled(true);
		colorParam.setEnabled(true);
		advancedButton.setEnabled(true);
		colorAdvancedButton.setEnabled(true);
		
		
		pDsWidthButton.setEnabled(true);
		pDsHeightButton.setEnabled(true);
		fFixWidthButton.setEnabled(true);
		
		pFixHeightButton.setEnabled(true);
		
		pWidthParam.setEnabled(true);
		pHeightParam.setEnabled(true);
		
		Object valuesObject = valuesParam.getSelectedIndex() == -1 ? null : valuesParam.getSelectedItem();
		Object colorObject = colorParam.getSelectedIndex() == -1 ? null : colorParam.getSelectedItem();
		
		DefaultComboBoxModel valueModel = new DefaultComboBoxModel(getParamsToValues());
		valuesParam.setModel(valueModel);
		DefaultComboBoxModel colorModel = new DefaultComboBoxModel(getParamsToAll());
		colorParam.setModel(colorModel);

		if (valuesObject != null && findInComboBox(valueModel,(IDataSourceProducer)valuesObject) != -1) {
			int idx = findInComboBox(valueModel,(IDataSourceProducer)valuesObject);
			valuesParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (colorObject != null && findInComboBox(colorModel,(IDataSourceProducer)colorObject) != -1) {
			int idx = findInComboBox(colorModel,(IDataSourceProducer)colorObject);
			colorParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		
		validate();
		setWidgetDisabled();
		
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}
	
	//-----------------------------------------------------------------------------
	/** Updates the labels of the row/column with the name of the x and y components 
	 * (only in random mode). If the user changes to sequential mode, the labels
	 *  return to the default settings (empty strings).
	 */ 
	@SuppressWarnings("unused")
	private void updateRowAndColumnLabels() {
		if (is_full) {
			columnLabelField.setText("");
			rowLabelField.setText("");
		} 
		properties.setProperty(ChartConstants.COLUMN_LABEL,columnLabelField.getText());
		properties.setProperty(ChartConstants.ROW_LABEL,rowLabelField.getText());
	}
	
	//------------------------------------------------------------------------------
	/** Sets the minimum value and maximum value fields of the color map panel.
	 * @param minmax a list that contains the minimum and maximum values (or <code>null</code>)
	 */
	private void setMinMax(List<Double> minmax) {
		if (minmax != null) {
			cmp.setMinValue(String.valueOf(minmax.get(0).doubleValue()));
			cmp.setMaxValue(String.valueOf(minmax.get(1).doubleValue()));
		} else {
			cmp.setMinValue("");
			cmp.setMaxValue("");
		}
	}
}