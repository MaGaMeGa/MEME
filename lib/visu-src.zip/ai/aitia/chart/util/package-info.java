/** Utility package for the charting package. */
package ai.aitia.chart.util;