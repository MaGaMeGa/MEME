/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.view.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;

import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.Plot;
import org.jfree.ui.RectangleEdge;

/**
 * A color bar.
 *
 * @author David M. O'Donnell
 */
public class ColorBar implements Cloneable, Serializable {

    /** For serialization. */
    private static final long serialVersionUID = -2101776212647268103L;
    
    /** The default color bar thickness. */
    public static final int DEFAULT_COLORBAR_THICKNESS = 0;

    /** The default color bar thickness percentage. */
    public static final double DEFAULT_COLORBAR_THICKNESS_PERCENT = 0.10;

    /** The default outer gap. */
    public static final int DEFAULT_OUTERGAP = 2;

    /** The axis. */
    private ValueAxis axis;
    
    /** The color bar thickness. */
    private int colorBarThickness = DEFAULT_COLORBAR_THICKNESS;

    /** 
     * The color bar thickness as a percentage of the height of the data area. 
     */
    private double colorBarThicknessPercent 
        = DEFAULT_COLORBAR_THICKNESS_PERCENT;

    /** The color palette. */
    private ColorMap colorMap = null;

    /** The color bar length. */
    private int colorBarLength = 0; // default make height of plotArea

    /** The amount of blank space around the colorbar. */
    private int outerGap;

    private boolean isBasic = false;
    
    /**
     * Constructs a horizontal colorbar axis, using default values where 
     * necessary.
     *
     * @param label  the axis label.
     */
    public ColorBar(String label) {    	
        NumberAxis a = new NumberAxis(label);
        a.setAutoRangeIncludesZero(false);
        this.axis = a;
        this.axis.setLowerMargin(0.0);
        this.axis.setUpperMargin(0.0);
        
        this.colorMap = new SimpleColorMap(this.axis.getRange().getLowerBound(), 
        		this.axis.getRange().getUpperBound(), Color.black, Color.white);
        
        this.colorBarThickness = DEFAULT_COLORBAR_THICKNESS;
        this.colorBarThicknessPercent = DEFAULT_COLORBAR_THICKNESS_PERCENT;
        this.outerGap = DEFAULT_OUTERGAP;       
    }

    /**
     * Configures the color bar.
     * 
     * @param plot  the plot.
     */
    public void configure(ColorMap map) {
    	this.colorMap = map;
    	this.axis.setLowerBound(map.getMinLevel());
    	this.axis.setUpperBound(map.getMaxLevel());
    }
    
    /**
     * Returns the axis.
     * 
     * @return The axis.
     */
    public ValueAxis getAxis() {
        return this.axis;
    }
    
    /**
     * Sets the axis.
     * 
     * @param axis  the axis.
     */
    public void setAxis(ValueAxis axis) {
        this.axis = axis;
    }
  
    /*

    public void autoAdjustRange() {
        this.axis.autoAdjustRange();
        this.colorPalette.setMinZ(this.axis.getLowerBound());
        this.colorPalette.setMaxZ(this.axis.getUpperBound());
    }*/

    /**
     * Draws the plot on a Java 2D graphics device (such as the screen or a 
     * printer).
     *
     * @param g2  the graphics device.
     * @param cursor  the cursor.
     * @param plotArea  the area within which the chart should be drawn.
     * @param dataArea  the area within which the plot should be drawn (a
     *                  subset of the drawArea).
     * @param reservedArea  the reserved area.
     * @param edge  the color bar location.
     * 
     * @return The new cursor location.
     */
    public double draw(Graphics2D g2, double cursor,
                       Rectangle2D plotArea, Rectangle2D dataArea, 
                       Rectangle2D reservedArea, RectangleEdge edge) {


        Rectangle2D colorBarArea = null;
        
        double thickness = calculateBarThickness(dataArea, edge);
        if (this.colorBarThickness > 0) {
            thickness = this.colorBarThickness;  // allow fixed thickness
        }

        double length = 0.0;
        if (RectangleEdge.isLeftOrRight(edge)) {
            length = dataArea.getHeight();
        }
        else {
            length = dataArea.getWidth();
        }
        
        if (this.colorBarLength > 0) {
            length = this.colorBarLength;
        }

        if (edge == RectangleEdge.BOTTOM) {
            colorBarArea = new Rectangle2D.Double(
                dataArea.getX(), plotArea.getMaxY() + this.outerGap,
                length, thickness
            );
        }
        else if (edge == RectangleEdge.TOP) {
            colorBarArea = new Rectangle2D.Double(
                dataArea.getX(), reservedArea.getMinY() + this.outerGap,
                length, thickness
            );
        }
        else if (edge == RectangleEdge.LEFT) {
        	double x = isBasic ? dataArea.getX() - 50 : plotArea.getX();
            colorBarArea = new Rectangle2D.Double(
                x - thickness - this.outerGap ,
                dataArea.getMinY(), thickness, length
            );            
        }
        else if (edge == RectangleEdge.RIGHT) {
            colorBarArea = new Rectangle2D.Double(
                plotArea.getMaxX() + this.outerGap, dataArea.getMinY(),
                thickness, length
            );            
        }
        
        // update, but dont draw tick marks (needed for stepped colors)
        this.axis.refreshTicks(
            g2, new AxisState(), colorBarArea, edge
        );

        drawColorBar(g2, colorBarArea, edge);

        AxisState state = null;
        if (edge == RectangleEdge.TOP) {
            cursor = colorBarArea.getMinY();
            state = this.axis.draw(
                g2, cursor, reservedArea, colorBarArea, RectangleEdge.TOP, null
            );
        } 
        else if (edge == RectangleEdge.BOTTOM) {
            cursor = colorBarArea.getMaxY();
            state = this.axis.draw(
                g2, cursor, reservedArea, colorBarArea, RectangleEdge.BOTTOM, 
                null
            );
        } 
        else if (edge == RectangleEdge.LEFT) {
            cursor = colorBarArea.getMinX();
            state = this.axis.draw(
                g2, cursor, reservedArea, colorBarArea, RectangleEdge.LEFT, null
            );
        } 
        else if (edge == RectangleEdge.RIGHT) {
            cursor = colorBarArea.getMaxX();
            state = this.axis.draw(
                g2, cursor, reservedArea, colorBarArea, RectangleEdge.RIGHT, 
                null
            );
        }
        return state.getCursor();
        
    }

    /**
     * Draws the plot on a Java 2D graphics device (such as the screen or a 
     * printer).
     *
     * @param g2  the graphics device.
     * @param colorBarArea  the area within which the axis should be drawn.
     * @param edge  the location.
     */
    public void drawColorBar(Graphics2D g2, Rectangle2D colorBarArea, 
                             RectangleEdge edge) {

        Object antiAlias = g2.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_OFF);

        // setTickValues was missing from ColorPalette v. 0.96
        //colorPalette.setTickValues(this.axis.getTicks());

        Stroke strokeSaved = g2.getStroke();
        g2.setStroke(new BasicStroke(1.5f));

        if (RectangleEdge.isTopOrBottom(edge)) {
            double y1 = colorBarArea.getY();
            double y2 = colorBarArea.getMaxY();
            double xx = colorBarArea.getX();
            Line2D line = new Line2D.Double();
            while (xx <= colorBarArea.getMaxX()) {
                double value = this.axis.java2DToValue(xx, colorBarArea, edge);
                line.setLine(xx, y1, xx, y2);
                g2.setPaint(getPaint(value));
                g2.draw(line);
                xx += 1;
            }
        }
        else {
            double y1 = colorBarArea.getX();
            double y2 = colorBarArea.getMaxX();
            double xx = colorBarArea.getY();
            Line2D line = new Line2D.Double();
            while (xx <= colorBarArea.getMaxY()) {
                double value = this.axis.java2DToValue(xx, colorBarArea, edge);
                line.setLine(y1, xx, y2, xx);
                g2.setPaint(getPaint(value));
                g2.draw(line);
                xx += 1;
            }            
        }

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, antiAlias);
        g2.setStroke(strokeSaved);

    }

    /**
     * Returns the color palette.
     *
     * @return The color palette.
     */
    public ColorMap getColorMap() {
        return this.colorMap;
    }

    /**
     * Returns the Paint associated with a value.
     *
     * @param value  the value.
     *
     * @return The paint.
     */
    public Paint getPaint(double value) {
        return this.colorMap.getColor(value);
    }
    

    /**
     * Reserves the space required to draw the color bar.
     *
     * @param g2  the graphics device.
     * @param plot  the plot that the axis belongs to.
     * @param plotArea  the area within which the plot should be drawn.
     * @param dataArea  the data area.
     * @param edge  the axis location.
     * @param space  the space already reserved.
     *
     * @return The space required to draw the axis in the specified plot area.
     */
    public AxisSpace reserveSpace(Graphics2D g2, Plot plot, 
                                  Rectangle2D plotArea,
                                  Rectangle2D dataArea, RectangleEdge edge, 
                                  AxisSpace space) {

        AxisSpace result = this.axis.reserveSpace(
            g2, plot, plotArea, edge, space
        );
        double thickness = calculateBarThickness(dataArea, edge);
        result.add(thickness + 2 * this.outerGap, edge);
        return result;

    }
    
    /**
     * Calculates the bar thickness.
     * 
     * @param plotArea  the plot area.
     * @param edge  the location.
     * 
     * @return The thickness.
     */
    private double calculateBarThickness(Rectangle2D plotArea, 
                                         RectangleEdge edge) {
        double result = 0.0;
        if (RectangleEdge.isLeftOrRight(edge)) {
            result = plotArea.getWidth() * this.colorBarThicknessPercent;
        }
        else {
            result = plotArea.getHeight() * this.colorBarThicknessPercent;
        }
        return result;  
    }

    /**
     * Returns a clone of the object.
     * 
     * @return A clone.
     * 
     * @throws CloneNotSupportedException if some component of the color bar 
     *         does not support cloning.
     */
    public Object clone() throws CloneNotSupportedException {
    
        ColorBar clone = (ColorBar) super.clone();
        clone.axis = (ValueAxis) this.axis.clone();
        return clone;
            
    }
    
    /**
     * Tests this object for equality with another.
     * 
     * @param obj  the object to test against.
     * 
     * @return A boolean.
     */
    public boolean equals(Object obj) {

        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ColorBar)) {
            return false;   
        }
        ColorBar that = (ColorBar) obj;
        if (!this.axis.equals(that.axis)) {
            return false;
        }
        if (this.colorBarThickness != that.colorBarThickness) {
            return false;
        }
        if (this.colorBarThicknessPercent != that.colorBarThicknessPercent) {
            return false;
        }
        if (!this.colorMap.equals(that.colorMap)) {
            return false;
        }
        if (this.colorBarLength != that.colorBarLength) {
            return false;
        }
        if (this.outerGap != that.outerGap) {
            return false;
        }
        return true;
        
    }
    
    /**
     * Returns a hash code for this object.
     * 
     * @return A hash code.
     */
    public int hashCode() {
        return this.axis.hashCode();
    }
    
    
    public void setBasic(boolean isBasic) {
    	this.isBasic = isBasic;
    }
}