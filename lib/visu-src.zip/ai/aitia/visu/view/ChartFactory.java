/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.view;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.GraphicsConfiguration;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.text.NumberFormat;
import java.util.List;

import javax.media.j3d.Canvas3D;
import javax.swing.JPanel;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.block.BlockContainer;
import org.jfree.chart.block.FlowArrangement;
import org.jfree.chart.labels.BoxAndWhiskerToolTipGenerator;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.CompositeTitle;
import org.jfree.chart.title.LegendTitle;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.Dataset;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;

import ai.aitia.visu.VisualisationException;
import ai.aitia.visu.axis.LogarithmicMatrixAxis;
import ai.aitia.visu.axis.MatrixAxis;
import ai.aitia.visu.data.DefaultPieDataset;
import ai.aitia.visu.data.Grid2DDataset;
import ai.aitia.visu.data.Grid3DDataset;
import ai.aitia.visu.data.MatrixOfScatterplotsDataset;
import ai.aitia.visu.data.MultiHistogramDataset;
import ai.aitia.visu.data.OneDSeriesDataset;
import ai.aitia.visu.data.RadVizDataset;
import ai.aitia.visu.data.RectangleAreaDataset;
import ai.aitia.visu.data.sequence.SequenceDataset;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.ExtendedHistogramDatasetProducer;
import ai.aitia.visu.ds.IDatasetProducer;
import ai.aitia.visu.ds.RealTimeSeriesCollectionProducer;
import ai.aitia.visu.ds.TimeSeriesCollectionProducer;
import ai.aitia.visu.ds.XYSeriesCollectionProducer;
import ai.aitia.visu.ds.xy.ModifiableXYSeries;
import ai.aitia.visu.renderer.BoxPlotRenderer;
import ai.aitia.visu.renderer.MatrixOSPsRenderer;
import ai.aitia.visu.renderer.MultiHistogramRenderer;
import ai.aitia.visu.view.meta.Appearance;
import ai.aitia.visu.view.meta.BarChartMetadata;
import ai.aitia.visu.view.meta.BoxPlotMetadata;
import ai.aitia.visu.view.meta.CustomAppearance;
import ai.aitia.visu.view.meta.D1SeriesMetadata;
import ai.aitia.visu.view.meta.Grid2DMetadata;
import ai.aitia.visu.view.meta.Grid3DMetadata;
import ai.aitia.visu.view.meta.LineChartMetadata;
import ai.aitia.visu.view.meta.MultiGrid2DMetadata;
import ai.aitia.visu.view.meta.MultiHistogramMetadata;
import ai.aitia.visu.view.meta.PieChartMetadata;
import ai.aitia.visu.view.meta.RadVizMetadata;
import ai.aitia.visu.view.meta.RectangleAreaChartMetadata;
import ai.aitia.visu.view.meta.ScatterPlotMetadata;
import ai.aitia.visu.view.meta.SequenceMetadata;
import ai.aitia.visu.view.meta.SimpleHistogramMetadata;
import ai.aitia.visu.view.meta.TimeSeriesMetadata;
import ai.aitia.visu.view.plot.BWChartDrawingSupplier;
import ai.aitia.visu.view.plot.ChartDrawingSupplier;
import ai.aitia.visu.view.plot.FigureGrid2DPlot;
import ai.aitia.visu.view.plot.Grid2DPlot;
import ai.aitia.visu.view.plot.Grid3DPlot;
import ai.aitia.visu.view.plot.IBasicSupplier;
import ai.aitia.visu.view.plot.MatrixOSPsPlot;
import ai.aitia.visu.view.plot.MultiGrid2DPlot;
import ai.aitia.visu.view.plot.OneDSeriesPlot;
import ai.aitia.visu.view.plot.RadVizPlot;
import ai.aitia.visu.view.plot.RectangleAreaPlot;
import ai.aitia.visu.view.plot.SequencePlot;
import ai.aitia.visu.view.plot.TextureChartDrawingSupplier;
import ai.aitia.visu.view.selection.SelectionHandler;
import ai.aitia.visu.view.ui.IFigureRenderer;

import com.sun.j3d.utils.universe.SimpleUniverse;

public class ChartFactory {
	
	@SuppressWarnings("cast")
	public static JPanel createGrid3DChart(IDatasetProducer[] ds, Grid3DMetadata[] metaDatas) throws VisualisationException  {
			try {		
				
				Grid3DDataset[] datasets = new Grid3DDataset[ds.length];
				for (int i = 0;i < ds.length;++i) {
					Dataset data = ds[i].produceDataset(null);
					if (!(data instanceof Grid3DDataset))
						throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());
					
					datasets[i] = (Grid3DDataset) data;
				}
				
				//CustomAppearance app = metaData.getCustomAppearance();
		        final Grid3DPlot plot = new Grid3DPlot(datasets, metaDatas);
		        
		        //if (!metaData.isColorBarVisible())
		        //	plot.setColorBar(null);
		        
		        //String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
		        //final JFreeChart chart = new JFreeChart(title, null, plot, false);
		        
		        GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
				Canvas3D c3D = new Canvas3D(config);
				
		        final JPanel chart = new JPanel();
		        
		        Rectangle2D rect = (Rectangle2D) new Rectangle(c3D.getWidth(), c3D.getHeight());
				plot.draw(c3D, rect, null, null, null);

				/*if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
					TextTitle titleObject = chart.getTitle();
					if (app.getTitleFont() != null)
						titleObject.setFont(app.getTitleFont());
					if (app.getTitleColor() != null)
						titleObject.setPaint(app.getTitleColor());
				}

				if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
					chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
				else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
					 app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
				}*/
				
				/*if (metaData.hasCustomAppearance()) {
					ValueAxis domainAxis = plot.getDomainAxis();
					ValueAxis rangeAxis = plot.getRangeAxis();
					if (app.getDomainAxisFont() != null) {
						domainAxis.setLabelFont(app.getDomainAxisFont());
						rangeAxis.setLabelFont(app.getDomainAxisFont());
					}
					if (app.getDomainAxisColor() != null) {
						domainAxis.setLabelPaint(app.getDomainAxisColor());
						rangeAxis.setLabelPaint(app.getDomainAxisColor());
					}
					if (app.getDomainAxisTickFont() != null) {
						domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
						rangeAxis.setTickLabelFont(app.getDomainAxisTickFont());
					}
					domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
					domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
					rangeAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
					rangeAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
				
					if (metaData.isColorBarVisible()) {
						ValueAxis colorbarAxis = plot.getColorBar().getAxis();
						if (app.getRangeAxisFont() != null) 
							colorbarAxis.setLabelFont(app.getRangeAxisFont());
						if (app.getRangeAxisColor() != null)
							colorbarAxis.setLabelPaint(app.getRangeAxisColor());
						if (app.getRangeAxisTickFont() != null)
							colorbarAxis.setTickLabelFont(app.getRangeAxisTickFont());
						colorbarAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
						colorbarAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
					}
				}
		        
				if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
		        	chart.setBackgroundPaint(Color.WHITE);
		        	chart.setBorderVisible(false);
		        	plot.setInsets(new RectangleInsets(0,0,1.0,1.0));
		        	if (metaData.isColorBarVisible()) plot.getColorBar().setBasic(true);
				} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
					chart.setBackgroundPaint(app.getBackgroundPaint());
		        else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
		        */
				
				chart.setPreferredSize(new Dimension(640, 480));
				chart.setLayout(new BorderLayout());
				chart.add("Center", c3D);
				
		        return chart;
		        
			} catch (Throwable t) {
				throw new VisualisationException(t);
			}			
		}
	
	public static JFreeChart createMultiGrid2DChart(IDatasetProducer[] dss, MultiGrid2DMetadata metaData) throws VisualisationException {
		try {
			Grid2DDataset[] datasets = new Grid2DDataset[dss.length];
			for (int i = 0;i < dss.length;++i) {
				Dataset data = dss[i].produceDataset(null);
				if (!(data instanceof Grid2DDataset))
					throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());
				datasets[i] = (Grid2DDataset) data;
			}
			
			CustomAppearance app = metaData.getCustomAppearance();
			final MultiGrid2DPlot plot = new MultiGrid2DPlot(datasets,metaData.getColumnLabel(),metaData.getRowLabel(),metaData.getFigureRenderers().toArray(new IFigureRenderer[0]),false);
			
			String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
			final JFreeChart chart = new JFreeChart(title,null,plot,false);
			
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
			
			if (metaData.getSubtitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubtitle()));
			else if (metaData.getSubtitle() != null && metaData.hasCustomAppearance() && app.isShowSubtitle()) {
				TextTitle subTitle = new TextTitle(metaData.getSubtitle());
				if (app.getSubtitleFont() != null)
					subTitle.setFont(app.getSubtitleFont());
				if (app.getSubtitleColor() != null)
					subTitle.setPaint(app.getSubtitleColor());
				chart.addSubtitle(subTitle);
			}
			
			//TODO: ha lesz colorbar, akkor a range axises dolgok arra vonatkoznak, a domain axisesek pedig a m�sik kett�re
			if (metaData.hasCustomAppearance()) {
				ValueAxis domainAxis = plot.getDomainAxis();
				ValueAxis rangeAxis = plot.getRangeAxis();

				if (app.getDomainAxisFont() != null)
					domainAxis.setLabelFont(app.getDomainAxisFont());
				if (app.getDomainAxisColor() != null)
					domainAxis.setLabelPaint(app.getDomainAxisColor());
				if (app.getDomainAxisTickFont() != null)
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
				
				if (app.getRangeAxisFont() != null)
					rangeAxis.setLabelFont(app.getRangeAxisFont());
				if (app.getRangeAxisColor() != null)
					rangeAxis.setLabelPaint(app.getRangeAxisColor());
				if (app.getRangeAxisTickFont() != null)
					rangeAxis.setTickLabelFont(app.getRangeAxisTickFont());
				rangeAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
			}
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
	        	chart.setBackgroundPaint(Color.WHITE);
	        	chart.setBorderVisible(false);
	        	plot.setInsets(new RectangleInsets(0,0,1.0,1.0));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
	        else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
	        return chart;
		} catch (DataSourceException e) {
			throw new VisualisationException(e);
		}
	}

	public static JFreeChart createGrid2DChart(IDatasetProducer ds, Grid2DMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof Grid2DDataset) {
			Grid2DDataset grid2dData = (Grid2DDataset)data;	
			
			CustomAppearance app = metaData.getCustomAppearance();
	        final Grid2DPlot plot = new Grid2DPlot(grid2dData,metaData.getColumnLabel(),metaData.getRowLabel(), metaData.getColorMap(),metaData.noSelection(),metaData.generateTooltip());
	        
	        if (!metaData.isColorBarVisible())
	        	plot.setColorBar(null);
	        
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
	        final JFreeChart chart = new JFreeChart(title, null, plot, false);

			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}

			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
				 app.isShowSubtitle()) {
				TextTitle subTitle = new TextTitle(metaData.getSubTitle());
				if (app.getSubtitleFont() != null)
					subTitle.setFont(app.getSubtitleFont());
				if (app.getSubtitleColor() != null)
					subTitle.setPaint(app.getSubtitleColor());
				chart.addSubtitle(subTitle);
			}
			
			if (metaData.hasCustomAppearance()) {
				ValueAxis domainAxis = plot.getDomainAxis();
				ValueAxis rangeAxis = plot.getRangeAxis();
				if (app.getDomainAxisFont() != null) {
					domainAxis.setLabelFont(app.getDomainAxisFont());
					rangeAxis.setLabelFont(app.getDomainAxisFont());
				}
				if (app.getDomainAxisColor() != null) {
					domainAxis.setLabelPaint(app.getDomainAxisColor());
					rangeAxis.setLabelPaint(app.getDomainAxisColor());
				}
				if (app.getDomainAxisTickFont() != null) {
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
					rangeAxis.setTickLabelFont(app.getDomainAxisTickFont());
				}
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
				rangeAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
			
				if (metaData.isColorBarVisible()) {
					ValueAxis colorbarAxis = plot.getColorBar().getAxis();
					if (app.getRangeAxisFont() != null) 
						colorbarAxis.setLabelFont(app.getRangeAxisFont());
					if (app.getRangeAxisColor() != null)
						colorbarAxis.setLabelPaint(app.getRangeAxisColor());
					if (app.getRangeAxisTickFont() != null)
						colorbarAxis.setTickLabelFont(app.getRangeAxisTickFont());
					colorbarAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
					colorbarAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
				}
			}
	        
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
	        	chart.setBackgroundPaint(Color.WHITE);
	        	chart.setBorderVisible(false);
	        	plot.setInsets(new RectangleInsets(0,0,1.0,1.0));
	        	if (metaData.isColorBarVisible()) plot.getColorBar().setBasic(true);
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
	        else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
	        return chart;
		}
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			throw new VisualisationException(t);
		}			
	}	
	
	
	public static JFreeChart createOneDSeriesChart(IDatasetProducer ds, D1SeriesMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		if (data instanceof OneDSeriesDataset) {
			OneDSeriesDataset oneDSeriesData = (OneDSeriesDataset)data;	
			CustomAppearance app = metaData.getCustomAppearance();
	        final OneDSeriesPlot plot = new OneDSeriesPlot(oneDSeriesData,metaData.getColumnLabel(),metaData.getRowLabel(), metaData.getColorMap(),metaData.noSelection(),metaData.generateTooltip());
	        
	        if (!metaData.isColorBarVisible())
	        	plot.setColorBar(null);
	        
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
	        final JFreeChart chart = new JFreeChart(title, null, plot, false);

			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}

			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
				 app.isShowSubtitle()) {
				TextTitle subTitle = new TextTitle(metaData.getSubTitle());
				if (app.getSubtitleFont() != null)
					subTitle.setFont(app.getSubtitleFont());
				if (app.getSubtitleColor() != null)
					subTitle.setPaint(app.getSubtitleColor());
				chart.addSubtitle(subTitle);
			}
			
			if (metaData.hasCustomAppearance()) {
				ValueAxis domainAxis = plot.getDomainAxis();
				ValueAxis rangeAxis = plot.getRangeAxis();
				if (app.getDomainAxisFont() != null) {
					domainAxis.setLabelFont(app.getDomainAxisFont());
					rangeAxis.setLabelFont(app.getDomainAxisFont());
				}
				if (app.getDomainAxisColor() != null) {
					domainAxis.setLabelPaint(app.getDomainAxisColor());
					rangeAxis.setLabelPaint(app.getDomainAxisColor());
				}
				if (app.getDomainAxisTickFont() != null) {
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
					rangeAxis.setTickLabelFont(app.getDomainAxisTickFont());
				}
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
				rangeAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
			
				if (metaData.isColorBarVisible()) {
					ValueAxis colorbarAxis = plot.getColorBar().getAxis();
					if (app.getRangeAxisFont() != null) 
						colorbarAxis.setLabelFont(app.getRangeAxisFont());
					if (app.getRangeAxisColor() != null)
						colorbarAxis.setLabelPaint(app.getRangeAxisColor());
					if (app.getRangeAxisTickFont() != null)
						colorbarAxis.setTickLabelFont(app.getRangeAxisTickFont());
					colorbarAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
					colorbarAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
				}
			}
	        
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
	        	chart.setBackgroundPaint(Color.WHITE);
	        	chart.setBorderVisible(false);
	        	plot.setInsets(new RectangleInsets(0,0,1.0,1.0));
	        	if (metaData.isColorBarVisible()) plot.getColorBar().setBasic(true);
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
	        else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
	        return chart;
		}
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			throw new VisualisationException(t);
		}			
	}
	
	public static JFreeChart createShapeGrid2DChart(IDatasetProducer ds, Grid2DMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof Grid2DDataset) {
			
			Grid2DDataset grid2dData = (Grid2DDataset)data;	
			
			CustomAppearance app = metaData.getCustomAppearance();
	        final FigureGrid2DPlot plot = new FigureGrid2DPlot(grid2dData,metaData.getColumnLabel(),metaData.getRowLabel(),metaData.getShapeRenderer(), metaData.noSelection(),metaData.generateTooltip());
	   	       
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
	        final JFreeChart chart = new JFreeChart(title, null, plot, false);
	        
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
	        
			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
				 app.isShowSubtitle()) {
				TextTitle subTitle = new TextTitle(metaData.getSubTitle());
				if (app.getSubtitleFont() != null)
					subTitle.setFont(app.getSubtitleFont());
				if (app.getSubtitleColor() != null)
					subTitle.setPaint(app.getSubtitleColor());
				chart.addSubtitle(subTitle);
			}
	        
			if (metaData.hasCustomAppearance()) {
				ValueAxis domainAxis = plot.getDomainAxis();
				ValueAxis rangeAxis = plot.getRangeAxis();
				if (app.getDomainAxisFont() != null) {
					domainAxis.setLabelFont(app.getDomainAxisFont());
					rangeAxis.setLabelFont(app.getDomainAxisFont());
				}
				if (app.getDomainAxisColor() != null) {
					domainAxis.setLabelPaint(app.getDomainAxisColor());
					rangeAxis.setLabelPaint(app.getDomainAxisColor());
				}
				if (app.getDomainAxisTickFont() != null) {
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
					rangeAxis.setTickLabelFont(app.getDomainAxisTickFont());
				}
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
				rangeAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
			}
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
	        	chart.setBackgroundPaint(Color.WHITE);
	        	chart.setBorderVisible(false);
	        	plot.setInsets(new RectangleInsets(2.0,0,1.0,1.0));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
	        else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
	        return chart;
		}
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());		
		} catch (Throwable t) {
			throw new VisualisationException(t);
		}			
	}		
	
	@Deprecated
	public static CustomSaveableChartPanel createCompositeGrid2DChart(IDatasetProducer colorDataProducer, IDatasetProducer shapeDataProducer, Grid2DMetadata metaData) throws VisualisationException  {
		
		try {	
			
		ai.aitia.visu.ds.WrapperGrid2DDatasetProducer cp = new ai.aitia.visu.ds.WrapperGrid2DDatasetProducer(colorDataProducer,metaData,true);
		ai.aitia.visu.ds.WrapperGrid2DDatasetProducer sp = new ai.aitia.visu.ds.WrapperGrid2DDatasetProducer(shapeDataProducer,cp);
		cp.setPartner(sp);
		
		Grid2DDataset grid2dData = cp.produceDataset(null);
		final Grid2DPlot gplot = new Grid2DPlot(grid2dData, metaData.getColumnLabel(), metaData.getRowLabel(), metaData.getColorMap(), metaData.noSelection(), metaData.generateTooltip());
	    Grid2DDataset sgrid2dData = sp.produceDataset(null);
	    final FigureGrid2DPlot splot = new FigureGrid2DPlot(sgrid2dData, metaData.getColumnLabel(), metaData.getRowLabel(), metaData.getShapeRenderer(), metaData.noSelection(), metaData.generateTooltip());
	    
		CustomAppearance app = metaData.getCustomAppearance();
	    final ai.aitia.visu.view.plot.CompositeGrid2DPlot plot = new ai.aitia.visu.view.plot.CompositeGrid2DPlot(gplot,splot); 
		
	    if (!metaData.isColorBarVisible())
	    	plot.setColorBar(null);
	    
	    String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
        final JFreeChart chart = new JFreeChart(title,null,plot,false);
        final CustomSaveableChartPanel chartPanel = new CustomSaveableChartPanel(chart); 
        cp.setChartPanel(chartPanel);
        sp.setChartPanel(chartPanel);
        
		if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
			TextTitle titleObject = chart.getTitle();
			if (app.getTitleFont() != null)
				titleObject.setFont(app.getTitleFont());
			if (app.getTitleColor() != null)
				titleObject.setPaint(app.getTitleColor());
		}
		
		if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
			chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
		else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
			app.isShowSubtitle()) {
			TextTitle subTitle = new TextTitle(metaData.getSubTitle());
			if (app.getSubtitleFont() != null)
				subTitle.setFont(app.getSubtitleFont());
			if (app.getSubtitleColor() != null)
				subTitle.setPaint(app.getSubtitleColor());
			chart.addSubtitle(subTitle);
		}
		
		if (metaData.hasCustomAppearance()) {
			ValueAxis domainAxis = plot.getDomainAxis();
			ValueAxis rangeAxis = plot.getRangeAxis();
			if (app.getDomainAxisFont() != null) {
				domainAxis.setLabelFont(app.getDomainAxisFont());
				rangeAxis.setLabelFont(app.getDomainAxisFont());
			}
			if (app.getDomainAxisColor() != null) {
				domainAxis.setLabelPaint(app.getDomainAxisColor());
				rangeAxis.setLabelPaint(app.getDomainAxisColor());
			}
			if (app.getDomainAxisTickFont() != null) {
				domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
				rangeAxis.setTickLabelFont(app.getDomainAxisTickFont());
			}
			domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
			domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
			rangeAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
			rangeAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
		
			if (metaData.isColorBarVisible()) {
				ValueAxis colorbarAxis = plot.getColorBar().getAxis();
				if (app.getRangeAxisFont() != null) 
					colorbarAxis.setLabelFont(app.getRangeAxisFont());
				if (app.getRangeAxisColor() != null)
					colorbarAxis.setLabelPaint(app.getRangeAxisColor());
				if (app.getRangeAxisTickFont() != null)
					colorbarAxis.setTickLabelFont(app.getRangeAxisTickFont());
				colorbarAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
				colorbarAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
			}
		}
        
		if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
        	chart.setBackgroundPaint(Color.WHITE);
        	chart.setBorderVisible(false);
        	plot.setInsets(new RectangleInsets(0,0,1.0,1.0));
        	if (metaData.isColorBarVisible()) plot.getColorBar().setBasic(true);
		} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
			chart.setBackgroundPaint(app.getBackgroundPaint());
        else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
        return chartPanel;
		} catch (Throwable t) {
			throw new VisualisationException(t);
		}		        
	}	
	
	public static JFreeChart createRealTimeSeriesChart(IDatasetProducer ds, TimeSeriesMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof XYDataset) {
			CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
			JFreeChart chart = org.jfree.chart.ChartFactory.createTimeSeriesChart(title,metaData.getTimeAxisLabel(),metaData.getValueAxisLabel(),
																				  (XYDataset) data,metaData.isShowLegend(),true,false);
			
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
			
			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
					 app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
			}
			
			XYPlot plot = chart.getXYPlot();
			XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(true, true);
			plot.setRenderer(renderer);
			plot.setForegroundAlpha(0.75f);
			
			if (metaData.hasCustomAppearance()) {
				ValueAxis domainAxis = plot.getDomainAxis();
				if (app.getDomainAxisFont() != null) 
					domainAxis.setLabelFont(app.getDomainAxisFont());
				if (app.getDomainAxisColor() != null)
					domainAxis.setLabelPaint(app.getDomainAxisColor());
				if (app.getDomainAxisTickFont() != null)
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
			
				// auto range always
				
				ValueAxis rangeAxis = plot.getRangeAxis();
				if (app.getRangeAxisFont() != null) 
					rangeAxis.setLabelFont(app.getRangeAxisFont());
				if (app.getRangeAxisColor() != null)
					rangeAxis.setLabelPaint(app.getRangeAxisColor());
				if (app.getRangeAxisTickFont() != null)
					rangeAxis.setTickLabelFont(app.getRangeAxisTickFont());
				rangeAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
			
				rangeAxis.configure();
				rangeAxis.setAutoRange(app.isRangeAutoRange());
				if (!app.isRangeAutoRange()) {
					rangeAxis.setLowerBound(app.getRangeRangeMin());
					rangeAxis.setUpperBound(app.getRangeRangeMax());
				}
			}

			if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null) {
				List<Boolean> filledInfo = app.getFilledShapeInfo(((XYDataset)data).getSeriesCount());
				for (int i = 0;i < filledInfo.size();++i)
					renderer.setSeriesShapesFilled(i,filledInfo.get(i));
				plot.setDrawingSupplier(app.getDrawingSupplier(((XYDataset)data).getSeriesCount(),plot.getSeriesRenderingOrder()));
			} else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				plot.setDrawingSupplier(new BWChartDrawingSupplier());
			else
				plot.setDrawingSupplier(new ChartDrawingSupplier());
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
				IBasicSupplier supplier = (IBasicSupplier)plot.getDrawingSupplier();
				supplier.setThinLines();
				chart.setBackgroundPaint(Color.WHITE);
				chart.setBorderVisible(false);
				plot.setDomainGridlinesVisible(false);
				plot.setRangeGridlinesVisible(false);
				plot.setOutlineStroke(null);
				plot.setInsets(new RectangleInsets(0,0,1,1));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
			else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}			
	}
	
	public static JFreeChart createTimeSeriesChart(IDatasetProducer ds, TimeSeriesMetadata metaData) throws VisualisationException {
		try {
			Dataset data = ds.produceDataset(null);
			
		if (data instanceof XYDataset) {
			CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
			JFreeChart chart = org.jfree.chart.ChartFactory.createXYLineChart(title,metaData.getTimeAxisLabel(),
																			  metaData.getValueAxisLabel(),(XYDataset) data,
																			  PlotOrientation.VERTICAL, metaData.isShowLegend(),true,false);
			
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
			
			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
				app.isShowSubtitle()) {
				TextTitle subTitle = new TextTitle(metaData.getSubTitle());
				if (app.getSubtitleFont() != null)
					subTitle.setFont(app.getSubtitleFont());
				if (app.getSubtitleColor() != null)
					subTitle.setPaint(app.getSubtitleColor());
				chart.addSubtitle(subTitle);
			}


			XYPlot plot = chart.getXYPlot();
			XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(true,true);
			plot.setRenderer(renderer);
			plot.setForegroundAlpha(0.75f);
			
			ValueAxis domainAxis = plot.getDomainAxis();
			domainAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
			
			if (metaData.hasCustomAppearance()) {
				if (app.getDomainAxisFont() != null) 
					domainAxis.setLabelFont(app.getDomainAxisFont());
				if (app.getDomainAxisColor() != null)
					domainAxis.setLabelPaint(app.getDomainAxisColor());
				if (app.getDomainAxisTickFont() != null)
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
			
				domainAxis.configure();
				domainAxis.setAutoRange(app.isDomainAutoRange());
				if (!app.isDomainAutoRange()) {
					domainAxis.setLowerBound(app.getDomainRangeMin());
					domainAxis.setUpperBound(app.getDomainRangeMax());
				}
			
				ValueAxis rangeAxis = plot.getRangeAxis();
				if (app.getRangeAxisFont() != null) 
					rangeAxis.setLabelFont(app.getRangeAxisFont());
				if (app.getRangeAxisColor() != null)
					rangeAxis.setLabelPaint(app.getRangeAxisColor());
				if (app.getRangeAxisTickFont() != null)
					rangeAxis.setTickLabelFont(app.getRangeAxisTickFont());
				rangeAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
			
				rangeAxis.configure();
				rangeAxis.setAutoRange(app.isRangeAutoRange());
				if (!app.isRangeAutoRange()) {
					rangeAxis.setLowerBound(app.getRangeRangeMin());
					rangeAxis.setUpperBound(app.getRangeRangeMax());
				}
			}

			if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null) {
				List<Boolean> filledInfo = app.getFilledShapeInfo(((XYDataset)data).getSeriesCount());
				for (int i = 0;i < filledInfo.size();++i)
					renderer.setSeriesShapesFilled(i,filledInfo.get(i));
				plot.setDrawingSupplier(app.getDrawingSupplier(((XYDataset)data).getSeriesCount(),plot.getSeriesRenderingOrder()));
			} else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				plot.setDrawingSupplier(new BWChartDrawingSupplier());
			else 
				plot.setDrawingSupplier(new ChartDrawingSupplier());
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
				IBasicSupplier supplier = (IBasicSupplier)plot.getDrawingSupplier();
				supplier.setThinLines();
				chart.setBackgroundPaint(Color.WHITE);
				chart.setBorderVisible(false);
				plot.setDomainGridlinesVisible(false);
				plot.setRangeGridlinesVisible(false);
				plot.setOutlineStroke(null);
				plot.setInsets(new RectangleInsets(0,0,1,1));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
			else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());
		} catch (Throwable t) {
			throw new VisualisationException(t);
		}
	}
	
	public static JFreeChart createScatterPlot(IDatasetProducer ds, ScatterPlotMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof XYSeriesCollection) {
			XYSeriesCollection dataset = (XYSeriesCollection)data;
			removeNonPositiveElements(dataset,metaData.isXLog(),metaData.isYLog());
			
			CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
			JFreeChart chart = org.jfree.chart.ChartFactory.createScatterPlot(title,metaData.getTimeAxisLabel(),metaData.getValueAxisLabel(),
																			  dataset,PlotOrientation.VERTICAL,metaData.isShowLegend(),true,false);

			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
			
			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() && app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
			}
			
			XYPlot plot = chart.getXYPlot();
			plot.setForegroundAlpha(0.75f);

			if (metaData.isXLog()) {
				ValueAxis xAxis = new LogarithmicAxis(plot.getDomainAxis().getLabel());
				plot.setDomainAxis(xAxis);
			}
			if (metaData.isYLog()) {
				ValueAxis yAxis = new LogarithmicAxis(plot.getRangeAxis().getLabel());
				plot.setRangeAxis(yAxis);
			}
			
			if (metaData.hasCustomAppearance()) {
				ValueAxis domainAxis = plot.getDomainAxis();
				if (app.getDomainAxisFont() != null) 
					domainAxis.setLabelFont(app.getDomainAxisFont());
				if (app.getDomainAxisColor() != null)
					domainAxis.setLabelPaint(app.getDomainAxisColor());
				if (app.getDomainAxisTickFont() != null)
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
			
				domainAxis.configure();
				domainAxis.setAutoRange(app.isDomainAutoRange());
				if (!app.isDomainAutoRange()) {
					domainAxis.setLowerBound(app.getDomainRangeMin());
					domainAxis.setUpperBound(app.getDomainRangeMax());
				}
			
				ValueAxis rangeAxis = plot.getRangeAxis();
				if (app.getRangeAxisFont() != null) 
					rangeAxis.setLabelFont(app.getRangeAxisFont());
				if (app.getRangeAxisColor() != null)
					rangeAxis.setLabelPaint(app.getRangeAxisColor());
				if (app.getRangeAxisTickFont() != null)
					rangeAxis.setTickLabelFont(app.getRangeAxisTickFont());
				rangeAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
			
				rangeAxis.configure();
				rangeAxis.setAutoRange(app.isRangeAutoRange());
				if (!app.isRangeAutoRange()) {
					rangeAxis.setLowerBound(app.getRangeRangeMin());
					rangeAxis.setUpperBound(app.getRangeRangeMax());
				}
			}

			
			if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null) {
				List<Boolean> filledInfo = app.getFilledShapeInfo(dataset.getSeriesCount());
				XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();
				for (int i = 0;i < filledInfo.size();++i)
					renderer.setSeriesShapesFilled(i,filledInfo.get(i));
				plot.setDrawingSupplier(app.getDrawingSupplier(dataset.getSeriesCount(),plot.getSeriesRenderingOrder()));
			} else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				plot.setDrawingSupplier(new BWChartDrawingSupplier());
			else
				plot.setDrawingSupplier(new ChartDrawingSupplier());
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
				IBasicSupplier supplier = (IBasicSupplier)plot.getDrawingSupplier();
				supplier.setThinLines();
				chart.setBackgroundPaint(Color.WHITE);
				chart.setBorderVisible(false);
				plot.setDomainGridlinesVisible(false);
				plot.setRangeGridlinesVisible(false);
				plot.setOutlineStroke(null);
				plot.setInsets(new RectangleInsets(0,0,1,1));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
			else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
			
			if (metaData.isXLog() || metaData.isYLog()) {
				dataset.addChangeListener(new NonPositiveElementRemover(metaData.isXLog(),metaData.isYLog()));
			}
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}			
	}
	
	
	public static JFreeChart createMatrixOfScatterPlots(IDatasetProducer ds, ScatterPlotMetadata metaData) throws VisualisationException  {
		try {	
			Dataset data = ds.produceDataset(null);
			
		if (data instanceof MatrixOfScatterplotsDataset) {
			MatrixOfScatterplotsDataset dataset = (MatrixOfScatterplotsDataset)data;
			removeNonPositiveElements(dataset,metaData.isXLog(),metaData.isYLog());
			CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";	         	     											
	        MatrixAxis xAxis = new MatrixAxis(metaData.getTimeAxisLabel());
	        xAxis.setAutoRangeIncludesZero(false);
	        MatrixAxis yAxis = new MatrixAxis(metaData.getValueAxisLabel());
	        yAxis.setAutoRangeIncludesZero(false);
	        if (metaData.isXLog()) {
				xAxis = new LogarithmicMatrixAxis(metaData.getTimeAxisLabel());
				
			}
			if (metaData.isYLog()) {
				yAxis = new LogarithmicMatrixAxis(metaData.getValueAxisLabel());
			}
	        
	        
			MatrixOSPsRenderer renderer = new MatrixOSPsRenderer();

	        MatrixOSPsPlot plot = new MatrixOSPsPlot((MatrixOfScatterplotsDataset)data, xAxis, yAxis, renderer ); 
	        renderer.setSeriesLinesVisible(0, false);
	        JFreeChart chart = new JFreeChart(
	        		title, JFreeChart.DEFAULT_TITLE_FONT, plot, metaData.isShowLegend());
	        
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
			
			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() && app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
			}
			
			//XYPlot plot = chart.getXYPlot();
			plot.setForegroundAlpha(0.75f);

			
			
			if (metaData.hasCustomAppearance()) {
				ValueAxis domainAxis = plot.getDomainAxis();
				if (app.getDomainAxisFont() != null) 
					domainAxis.setLabelFont(app.getDomainAxisFont());
				if (app.getDomainAxisColor() != null)
					domainAxis.setLabelPaint(app.getDomainAxisColor());
				if (app.getDomainAxisTickFont() != null)
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
			
				domainAxis.configure();
				domainAxis.setAutoRange(app.isDomainAutoRange());
				if (!app.isDomainAutoRange()) {
					domainAxis.setLowerBound(app.getDomainRangeMin());
					domainAxis.setUpperBound(app.getDomainRangeMax());
				}
			
				ValueAxis rangeAxis = plot.getRangeAxis();
				if (app.getRangeAxisFont() != null) 
					rangeAxis.setLabelFont(app.getRangeAxisFont());
				if (app.getRangeAxisColor() != null)
					rangeAxis.setLabelPaint(app.getRangeAxisColor());
				if (app.getRangeAxisTickFont() != null)
					rangeAxis.setTickLabelFont(app.getRangeAxisTickFont());
				rangeAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
			
				rangeAxis.configure();
				rangeAxis.setAutoRange(app.isRangeAutoRange());
				if (!app.isRangeAutoRange()) {
					rangeAxis.setLowerBound(app.getRangeRangeMin());
					rangeAxis.setUpperBound(app.getRangeRangeMax());
				}
			}

			
			if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null) {
				List<Boolean> filledInfo = app.getFilledShapeInfo(dataset.getSeriesCount());
				//XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();
				for (int i = 0;i < filledInfo.size();++i)
					renderer.setSeriesShapesFilled(i,filledInfo.get(i));
				plot.setDrawingSupplier(app.getDrawingSupplier(dataset.getSeriesCount(),plot.getSeriesRenderingOrder()));
			} else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				plot.setDrawingSupplier(new BWChartDrawingSupplier());
			else
				plot.setDrawingSupplier(new ChartDrawingSupplier());
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
				IBasicSupplier supplier = (IBasicSupplier)plot.getDrawingSupplier();
				supplier.setThinLines();
				chart.setBackgroundPaint(Color.WHITE);
				chart.setBorderVisible(false);
				plot.setDomainGridlinesVisible(false);
				plot.setRangeGridlinesVisible(false);
				plot.setOutlineStroke(null);
				plot.setInsets(new RectangleInsets(0,0,1,1));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
			else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
			
			if (metaData.isXLog() || metaData.isYLog()) {
				dataset.addChangeListener(new NonPositiveElementRemover(metaData.isXLog(),metaData.isYLog()));
			}
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}			
	}
	
	public static JFreeChart createXYLineChart(IDatasetProducer ds, LineChartMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof XYSeriesCollection) {
			XYSeriesCollection dataset = (XYSeriesCollection)data;
			removeNonPositiveElements(dataset,metaData.isXLog(),metaData.isYLog());
			
			CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
			JFreeChart chart = org.jfree.chart.ChartFactory.createXYLineChart(title,metaData.getXAxisLabel(),
																	   		  metaData.getYAxisLabel(),dataset,
																	   		  PlotOrientation.VERTICAL,metaData.isShowLegend(),true,false);
			
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
					TextTitle titleObject = chart.getTitle();
					if (app.getTitleFont() != null)
						titleObject.setFont(app.getTitleFont());
					if (app.getTitleColor() != null)
						titleObject.setPaint(app.getTitleColor());
				}
				
				if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
					chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
				else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
						 app.isShowSubtitle()) {
						TextTitle subTitle = new TextTitle(metaData.getSubTitle());
						if (app.getSubtitleFont() != null)
							subTitle.setFont(app.getSubtitleFont());
						if (app.getSubtitleColor() != null)
							subTitle.setPaint(app.getSubtitleColor());
						chart.addSubtitle(subTitle);
				}
				
				XYPlot plot = chart.getXYPlot();
				if (metaData.isXLog()) {
					ValueAxis xAxis = new LogarithmicAxis(plot.getDomainAxis().getLabel());
					plot.setDomainAxis(xAxis);
				}
				if (metaData.isYLog()) {
					ValueAxis yAxis = new LogarithmicAxis(plot.getRangeAxis().getLabel());
					plot.setRangeAxis(yAxis);
				}
				plot.setForegroundAlpha(0.75f);
				
				if (metaData.hasCustomAppearance()) {
					ValueAxis domainAxis = plot.getDomainAxis();
					if (app.getDomainAxisFont() != null) 
						domainAxis.setLabelFont(app.getDomainAxisFont());
					if (app.getDomainAxisColor() != null)
						domainAxis.setLabelPaint(app.getDomainAxisColor());
					if (app.getDomainAxisTickFont() != null)
						domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
					domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
					domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
				
					domainAxis.configure();
					domainAxis.setAutoRange(app.isDomainAutoRange());
					if (!app.isDomainAutoRange()) {
						domainAxis.setLowerBound(app.getDomainRangeMin());
						domainAxis.setUpperBound(app.getDomainRangeMax());
					}
				
					ValueAxis rangeAxis = plot.getRangeAxis();
					if (app.getRangeAxisFont() != null) 
						rangeAxis.setLabelFont(app.getRangeAxisFont());
					if (app.getRangeAxisColor() != null)
						rangeAxis.setLabelPaint(app.getRangeAxisColor());
					if (app.getRangeAxisTickFont() != null)
						rangeAxis.setTickLabelFont(app.getRangeAxisTickFont());
					rangeAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
					rangeAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
				
					rangeAxis.configure();
					rangeAxis.setAutoRange(app.isRangeAutoRange());
					if (!app.isRangeAutoRange()) {
						rangeAxis.setLowerBound(app.getRangeRangeMin());
						rangeAxis.setUpperBound(app.getRangeRangeMax());
					}
				}
				
				int rendererType = metaData.getRendererType();
				boolean showLines = rendererType <= LineChartMetadata.RENDERER_LINES_AND_SHAPES;
				boolean showShapes = rendererType >= LineChartMetadata.RENDERER_LINES_AND_SHAPES;
				XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(showLines,showShapes);
				plot.setRenderer(renderer);
				
				if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null)  {
					List<Boolean> filledInfo = app.getFilledShapeInfo(dataset.getSeriesCount());
					for (int i = 0;i < filledInfo.size();++i)
						renderer.setSeriesShapesFilled(i,filledInfo.get(i));
					plot.setDrawingSupplier(app.getDrawingSupplier(dataset.getSeriesCount(),plot.getSeriesRenderingOrder()));
					
				} else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
					plot.setDrawingSupplier(new BWChartDrawingSupplier());
				else 
					plot.setDrawingSupplier(new ChartDrawingSupplier());
				
				if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
					IBasicSupplier supplier = (IBasicSupplier)plot.getDrawingSupplier();
					supplier.setThinLines();
					chart.setBackgroundPaint(Color.WHITE);
					chart.setBorderVisible(false);
					plot.setDomainGridlinesVisible(false);
					plot.setRangeGridlinesVisible(false);
					plot.setOutlineStroke(null);
					plot.setInsets(new RectangleInsets(0,0,1,1));
				} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
					chart.setBackgroundPaint(app.getBackgroundPaint());
				else
					chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
			
			if (metaData.isXLog() || metaData.isYLog()) {
				dataset.addChangeListener(new NonPositiveElementRemover(metaData.isXLog(),metaData.isYLog()));
			}
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());		
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}			
	}	
	
	public static JFreeChart createInteractiveXYLineChart(IDatasetProducer ds, LineChartMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof XYDataset) {
			
			PlotOrientation orientation = PlotOrientation.VERTICAL;

	        NumberAxis xAxis = new NumberAxis(metaData.getXAxisLabel());
	        xAxis.setAutoRangeIncludesZero(false);
	        NumberAxis yAxis = new NumberAxis(metaData.getYAxisLabel());
	        ai.aitia.visu.renderer.xy.XYLineAndShapeRenderer renderer = new ai.aitia.visu.renderer.xy.XYLineAndShapeRenderer(true, false);
	        ai.aitia.visu.view.plot.XYPlot plot = new ai.aitia.visu.view.plot.XYPlot((XYDataset)data, xAxis, yAxis, renderer);
	        
	        renderer.setAreaInfo(plot.getAreaInfo());
	        
	        plot.setOrientation(orientation);
	        
	        renderer.setBaseToolTipGenerator(new StandardXYToolTipGenerator());
	        
			renderer.setShapesVisible(true);
			renderer.setSeriesStroke(0, new BasicStroke(2.0f,
					BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f,
					new float[] { 10.0f, 6.0f }, 0.0f));
			renderer.setSeriesStroke(1, new BasicStroke(2.0f,
					BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f,
					new float[] { 6.0f, 6.0f }, 0.0f));
			renderer.setSeriesStroke(2, new BasicStroke(2.0f,
					BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f,
					new float[] { 2.0f, 6.0f }, 0.0f));
			renderer.setItemLabelsVisible(true);
			renderer.setPositiveItemLabelPosition(new ItemLabelPosition());
			renderer.setNegativeItemLabelPosition(new ItemLabelPosition());	        

	        JFreeChart chart = new JFreeChart(
	        		metaData.getTitle(), JFreeChart.DEFAULT_TITLE_FONT, plot, true
	        );
			
			// TODO Set additional metaData information
			chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
						
			chart.getXYPlot().setForegroundAlpha(0.75f);
			
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}		
	}	
		
	
	public static JFreeChart createHistogram(IDatasetProducer ds, SimpleHistogramMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof IntervalXYDataset) {
			CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
			JFreeChart chart = org.jfree.chart.ChartFactory.createHistogram(title,null,null,(IntervalXYDataset) data,PlotOrientation.VERTICAL,
																			metaData.isShowLegend(),true,false);
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}

			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
					 app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
			}
			
			XYPlot plot = chart.getXYPlot();
			plot.setForegroundAlpha(0.75f);
			
			ValueAxis rangeAxis = plot.getRangeAxis();
			if (metaData.hasCustomAppearance()) {
				ValueAxis domainAxis = plot.getDomainAxis();
				if (app.getDomainAxisFont() != null) 
					domainAxis.setLabelFont(app.getDomainAxisFont());
				if (app.getDomainAxisColor() != null)
					domainAxis.setLabelPaint(app.getDomainAxisColor());
				if (app.getDomainAxisTickFont() != null)
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
			
				domainAxis.configure();
				domainAxis.setAutoRange(app.isDomainAutoRange());
				if (!app.isDomainAutoRange()) {
					domainAxis.setLowerBound(app.getDomainRangeMin());
					domainAxis.setUpperBound(app.getDomainRangeMax());
				}
			
				if (app.getRangeAxisFont() != null) 
					rangeAxis.setLabelFont(app.getRangeAxisFont());
				if (app.getRangeAxisColor() != null)
					rangeAxis.setLabelPaint(app.getRangeAxisColor());
				if (app.getRangeAxisTickFont() != null)
					rangeAxis.setTickLabelFont(app.getRangeAxisTickFont());
				rangeAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
			
				rangeAxis.configure();
				rangeAxis.setAutoRange(app.isRangeAutoRange());
				if (!app.isRangeAutoRange()) {
					rangeAxis.setLowerBound(app.getRangeRangeMin());
					rangeAxis.setUpperBound(app.getRangeRangeMax());
				}
			}
			
			// histogram range settings overrides the range settings of the templates
			if (metaData.getRangeMin() != - Double.MAX_VALUE || metaData.getRangeMax() != Double.MAX_VALUE) {
				rangeAxis.configure();
				rangeAxis.setAutoRange(false);
				if (metaData.getRangeMin() != - Double.MAX_VALUE)
					rangeAxis.setLowerBound(metaData.getRangeMin());
				if (metaData.getRangeMax() != Double.MAX_VALUE)
					rangeAxis.setUpperBound(metaData.getRangeMax());
			}
			
			if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null) 
				plot.setDrawingSupplier(app.getDrawingSupplier(((IntervalXYDataset)data).getSeriesCount(),plot.getSeriesRenderingOrder()));
			else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				plot.setDrawingSupplier(new TextureChartDrawingSupplier());
			else
				plot.setDrawingSupplier(new ChartDrawingSupplier());
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
				IBasicSupplier supplier = (IBasicSupplier)plot.getDrawingSupplier();
				supplier.setThinLines();
				chart.setBackgroundPaint(Color.WHITE);
				chart.setBorderVisible(false);
				plot.setDomainGridlinesVisible(false);
				plot.setRangeGridlinesVisible(false);
				plot.setOutlineStroke(null);
				plot.setInsets(new RectangleInsets(0,0,1,1));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
			else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());		
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}			
	}
	
	public static JFreeChart createMultiHistogram(IDatasetProducer ds, MultiHistogramMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof IntervalXYDataset) {
			MultiHistogramDataset dataset = (MultiHistogramDataset)data;
			
			CustomAppearance app = metaData.getCustomAppearance();
			
			 NumberAxis xAxis = new NumberAxis(null);
		     xAxis.setAutoRangeIncludesZero(false);
		     ValueAxis yAxis = new NumberAxis(null);
		     
		     //XYItemRenderer renderer = new XYBarRenderer();
		     MultiHistogramRenderer renderer = new MultiHistogramRenderer();
		     renderer.setBaseToolTipGenerator(new StandardXYToolTipGenerator());
		     
			
		     //System.out.println("ChartFactory.createMultiHistogram()");
			XYPlot plot = new XYPlot(dataset, xAxis, yAxis, renderer);
		    //MultiHistogramPlot plot = new MultiHistogramPlot(dataset, xAxis, yAxis, renderer);
			//System.out.println("ChartFactory.createMultiHistogram()");
			plot.setForegroundAlpha(0.75f);
			
			String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
			
	        JFreeChart chart = new JFreeChart(
	        		title, JFreeChart.DEFAULT_TITLE_FONT, plot, metaData.isShowLegend());
			
			
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}

			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
					 app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
			}
			
			
			
			ValueAxis rangeAxis = plot.getRangeAxis();
			if (metaData.hasCustomAppearance()) {
				ValueAxis domainAxis = plot.getDomainAxis();
				if (app.getDomainAxisFont() != null) 
					domainAxis.setLabelFont(app.getDomainAxisFont());
				if (app.getDomainAxisColor() != null)
					domainAxis.setLabelPaint(app.getDomainAxisColor());
				if (app.getDomainAxisTickFont() != null)
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());
			
				domainAxis.configure();
				domainAxis.setAutoRange(app.isDomainAutoRange());
				if (!app.isDomainAutoRange()) {
					domainAxis.setLowerBound(app.getDomainRangeMin());
					domainAxis.setUpperBound(app.getDomainRangeMax());
				}
			
				if (app.getRangeAxisFont() != null) 
					rangeAxis.setLabelFont(app.getRangeAxisFont());
				if (app.getRangeAxisColor() != null)
					rangeAxis.setLabelPaint(app.getRangeAxisColor());
				if (app.getRangeAxisTickFont() != null)
					rangeAxis.setTickLabelFont(app.getRangeAxisTickFont());
				rangeAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
			
				rangeAxis.configure();
				rangeAxis.setAutoRange(app.isRangeAutoRange());
				if (!app.isRangeAutoRange()) {
					rangeAxis.setLowerBound(app.getRangeRangeMin());
					rangeAxis.setUpperBound(app.getRangeRangeMax());
				}
			}
			
			// histogram range settings overrides the range settings of the templates
			if (metaData.getRangeMin() != - Double.MAX_VALUE || metaData.getRangeMax() != Double.MAX_VALUE) {
				rangeAxis.configure();
				rangeAxis.setAutoRange(false);
				if (metaData.getRangeMin() != - Double.MAX_VALUE)
					rangeAxis.setLowerBound(metaData.getRangeMin());
				if (metaData.getRangeMax() != Double.MAX_VALUE)
					rangeAxis.setUpperBound(metaData.getRangeMax());
			}
			
			if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null) 
				plot.setDrawingSupplier(app.getDrawingSupplier(((IntervalXYDataset)data).getSeriesCount(),plot.getSeriesRenderingOrder()));
			else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				plot.setDrawingSupplier(new TextureChartDrawingSupplier());
			else
				plot.setDrawingSupplier(new ChartDrawingSupplier());
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
				IBasicSupplier supplier = (IBasicSupplier)plot.getDrawingSupplier();
				supplier.setThinLines();
				chart.setBackgroundPaint(Color.WHITE);
				chart.setBorderVisible(false);
				plot.setDomainGridlinesVisible(false);
				plot.setRangeGridlinesVisible(false);
				plot.setOutlineStroke(null);
				plot.setInsets(new RectangleInsets(0,0,1,1));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
			else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());		
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}			
	}
	
	public static JFreeChart createInteractiveHistogram(IDatasetProducer ds, SimpleHistogramMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof IntervalXYDataset) {
			
			PlotOrientation orientation = PlotOrientation.VERTICAL;
	        NumberAxis xAxis = new NumberAxis(null);
	        xAxis.setAutoRangeIncludesZero(false);
	        ValueAxis yAxis = new NumberAxis(null);

	        ai.aitia.visu.renderer.xy.XYBarRenderer renderer = new ai.aitia.visu.renderer.xy.XYBarRenderer();
	        
	        renderer.setBaseToolTipGenerator(new StandardXYToolTipGenerator());
	        
	        ai.aitia.visu.view.plot.XYPlot plot = new ai.aitia.visu.view.plot.XYPlot((XYDataset)data, xAxis, yAxis, renderer);
	        
	        renderer.setAreaInfo(plot.getAreaInfo());
	        
	        plot.setOrientation(orientation);
	        JFreeChart chart = new JFreeChart(
	        		metaData.getTitle(), JFreeChart.DEFAULT_TITLE_FONT, plot, true
	        );			
			// TODO Set additional metaData information
			
			chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
			
			chart.getXYPlot().setForegroundAlpha(0.75f);
			
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}			
	}	
	
	public static JFreeChart createBarChart(IDatasetProducer ds, BarChartMetadata metaData) throws VisualisationException  {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof CategoryDataset) {
			CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
			JFreeChart chart = org.jfree.chart.ChartFactory.createBarChart(title,null,null,(CategoryDataset) data,PlotOrientation.VERTICAL,
																		   metaData.isShowLegend(),true,false);
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
			
			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
					 app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
			}
			
			CategoryPlot plot = chart.getCategoryPlot();
			plot.setForegroundAlpha(0.75f);
			plot.getDomainAxis().setCategoryLabelPositions(metaData.getCategoryLabelAngle());
			if (metaData.getBarRenderer() > BarChartMetadata.ONE_BAR_PER_DATAROW) {
				boolean type = metaData.getBarRenderer() == BarChartMetadata.ONE_BAR_PER_CATEGORY_PERCENTAGE;
				StackedBarRenderer renderer = new StackedBarRenderer(type);
				if (type) {
					NumberAxis axis = (NumberAxis)plot.getRangeAxis();
					axis.setNumberFormatOverride(NumberFormat.getPercentInstance());
				} 
				renderer.setToolTipGenerator(new StandardCategoryToolTipGenerator());
				plot.setRenderer(renderer);
			}
			
			if (metaData.hasCustomAppearance()) {
				CategoryAxis domainAxis = plot.getDomainAxis();
				if (app.getDomainAxisFont() != null) 
					domainAxis.setLabelFont(app.getDomainAxisFont());
				if (app.getDomainAxisColor() != null)
					domainAxis.setLabelPaint(app.getDomainAxisColor());
				if (app.getDomainAxisTickFont() != null)
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());

				// There is no sorting on a category axis
			
				ValueAxis rangeAxis = plot.getRangeAxis();
				if (app.getRangeAxisFont() != null) 
					rangeAxis.setLabelFont(app.getRangeAxisFont());
				if (app.getRangeAxisColor() != null)
					rangeAxis.setLabelPaint(app.getRangeAxisColor());
				if (app.getRangeAxisTickFont() != null)
					rangeAxis.setTickLabelFont(app.getRangeAxisTickFont());
				rangeAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
				
				rangeAxis.configure();
				rangeAxis.setAutoRange(app.isRangeAutoRange());
				if (!app.isRangeAutoRange()) {
					rangeAxis.setLowerBound(app.getRangeRangeMin());
					rangeAxis.setUpperBound(app.getRangeRangeMax());
				}
			}

			if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null) 
				plot.setDrawingSupplier(app.getDrawingSupplier());
			else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				plot.setDrawingSupplier(new TextureChartDrawingSupplier());
			else
				plot.setDrawingSupplier(new ChartDrawingSupplier());
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
				chart.setBackgroundPaint(Color.WHITE);
				chart.setBorderVisible(false);
				plot.setDomainGridlinesVisible(false);
				plot.setRangeGridlinesVisible(false);
				plot.setOutlineStroke(null);
				plot.setInsets(new RectangleInsets(0,0,1,1));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
			else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}		
	}	
	
	public static JFreeChart createPieChart(IDatasetProducer ds, PieChartMetadata metaData) throws VisualisationException  {
		
		try {		
			Dataset data = ds.produceDataset(null);
		if (data instanceof DefaultPieDataset) {
			CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";														   
	        
	        JFreeChart chart = org.jfree.chart.ChartFactory.createPieChart(title,(DefaultPieDataset)data,
					   metaData.isShowLegend(),false, false);
	        PiePlot plot=(PiePlot)chart.getPlot();
	        if(!metaData.isShowLabels()){
	        	
		        plot.setLabelLinksVisible(false);
		        plot.setLabelGenerator(null);	
	        }
	        
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
			
			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
					 app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
			}
			
			if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null) 
				plot.setDrawingSupplier(app.getDrawingSupplier());
			else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				plot.setDrawingSupplier(new TextureChartDrawingSupplier());
			else
				plot.setDrawingSupplier(new ChartDrawingSupplier());
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
				chart.setBackgroundPaint(Color.WHITE);
				chart.setBorderVisible(false);
				plot.setOutlineStroke(null);
				plot.setInsets(new RectangleInsets(0,0,1,1));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
			else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));

			//plot.
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}		
	}

	public static JFreeChart createBoxPlot(IDatasetProducer ds, BoxPlotMetadata metaData) throws VisualisationException  {
		
		try {		
			Dataset data = ds.produceDataset(null);
			
		if (data instanceof BoxAndWhiskerCategoryDataset) {
			CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";														   
	        
	        CategoryAxis xAxis = new CategoryAxis();//("Type");
	        NumberAxis yAxis = new NumberAxis();//("Value");
	        yAxis.setAutoRangeIncludesZero(false);
	        BoxPlotRenderer renderer = new BoxPlotRenderer();
	        renderer.setFillBox(false);
	        renderer.setToolTipGenerator(new BoxAndWhiskerToolTipGenerator());
	        
	        CategoryPlot plot = new CategoryPlot((BoxAndWhiskerCategoryDataset)data, xAxis, yAxis, renderer);
	        plot.setForegroundAlpha(0.75f);
			plot.getDomainAxis().setCategoryLabelPositions(metaData.getCategoryLabelAngle());
	       
			JFreeChart chart = new JFreeChart(
	        		title, JFreeChart.DEFAULT_TITLE_FONT, plot, metaData.isShowLegend());
	        
	        if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
			
			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
					 app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
			}
	        
			if (metaData.hasCustomAppearance()) {
				CategoryAxis domainAxis = plot.getDomainAxis();
				if (app.getDomainAxisFont() != null) 
					domainAxis.setLabelFont(app.getDomainAxisFont());
				if (app.getDomainAxisColor() != null)
					domainAxis.setLabelPaint(app.getDomainAxisColor());
				if (app.getDomainAxisTickFont() != null)
					domainAxis.setTickLabelFont(app.getDomainAxisTickFont());
				domainAxis.setTickMarksVisible(app.isDomainAxisTickMarks());
				domainAxis.setTickLabelsVisible(app.isDomainAxisTickLabels());

				// There is no sorting on a category axis
			
				ValueAxis rangeAxis = plot.getRangeAxis();
				if (app.getRangeAxisFont() != null) 
					rangeAxis.setLabelFont(app.getRangeAxisFont());
				if (app.getRangeAxisColor() != null)
					rangeAxis.setLabelPaint(app.getRangeAxisColor());
				if (app.getRangeAxisTickFont() != null)
					rangeAxis.setTickLabelFont(app.getRangeAxisTickFont());
				rangeAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
				rangeAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
			
				rangeAxis.setAutoRange(app.isRangeAutoRange());
				if (!app.isRangeAutoRange()) {
					rangeAxis.setLowerBound(app.getRangeRangeMin());
					rangeAxis.setUpperBound(app.getRangeRangeMax());
				}
			}
	        
			if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null) 
				plot.setDrawingSupplier(app.getDrawingSupplier());
			else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				plot.setDrawingSupplier(new TextureChartDrawingSupplier());
			else
				plot.setDrawingSupplier(new ChartDrawingSupplier());
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
				chart.setBackgroundPaint(Color.WHITE);
				chart.setBorderVisible(false);
				plot.setDomainGridlinesVisible(false);
				plot.setRangeGridlinesVisible(false);
				plot.setOutlineStroke(null);
				plot.setInsets(new RectangleInsets(0,0,1,1));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
			else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
	        
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}		
	}

	public static JFreeChart createRadViz(IDatasetProducer ds, RadVizMetadata metaData) throws VisualisationException  {
		
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof RadVizDataset) {
			CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";														   
	        
	        
	        
	        RadVizPlot plot=new RadVizPlot((RadVizDataset)data);
	        
	        JFreeChart chart = new JFreeChart(
	        		title, JFreeChart.DEFAULT_TITLE_FONT, plot, metaData.isShowLegend());
	        
	       
	        if(!metaData.isShowLabels()){
	        	
		        plot.setLabelLinksVisible(false);
		        plot.setLabelGenerator(null);	
	        }
	        
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
			
			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
					 app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
			}
			
			
			if (metaData.hasCustomAppearance() && app.getDrawingSupplier() != null) 
				plot.setDrawingSupplier(app.getDrawingSupplier());
			else if (metaData.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				plot.setDrawingSupplier(new TextureChartDrawingSupplier());
			else
				plot.setDrawingSupplier(new ChartDrawingSupplier());
			
			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
				chart.setBackgroundPaint(Color.WHITE);
				chart.setBorderVisible(false);
				//plot.setDomainGridlinesVisible(false);
				//plot.setRangeGridlinesVisible(false);
				plot.setOutlineStroke(null);
				plot.setInsets(new RectangleInsets(0,0,1,1));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
			else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));

			//plot.
			return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());	
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}		
	}
	
	
	
	public static JFreeChart createRectangleAreaChart(IDatasetProducer ds,  RectangleAreaChartMetadata metaData) throws VisualisationException {
		try {		
			Dataset data = ds.produceDataset(null);
		
			if (data instanceof RectangleAreaDataset) {
				CustomAppearance app = metaData.getCustomAppearance();
		        final RectangleAreaPlot plot = new RectangleAreaPlot((RectangleAreaDataset)data, metaData.getColorMap(),true,metaData.getTooMany());
		        
				if (!metaData.isColorBarVisible()) {
					plot.setColorBar(null);
				}
	        
				String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
				final JFreeChart chart = new JFreeChart(title,null,plot,false);
	        
				if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
					TextTitle titleObject = chart.getTitle();
					if (app.getTitleFont() != null)
						titleObject.setFont(app.getTitleFont());
					if (app.getTitleColor() != null)
						titleObject.setPaint(app.getTitleColor());
				}

				if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
					chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
				else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
					app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
				}
				
				if (metaData.hasCustomAppearance() && metaData.isColorBarVisible()) {
					ValueAxis colorbarAxis = plot.getColorBar().getAxis();
					if (app.getRangeAxisFont() != null) 
						colorbarAxis.setLabelFont(app.getRangeAxisFont());
					if (app.getRangeAxisColor() != null)
						colorbarAxis.setLabelPaint(app.getRangeAxisColor());
					if (app.getRangeAxisTickFont() != null)
						colorbarAxis.setTickLabelFont(app.getRangeAxisTickFont());
					colorbarAxis.setTickMarksVisible(app.isRangeAxisTickMarks());
					colorbarAxis.setTickLabelsVisible(app.isRangeAxisTickLabels());
				}

				if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
		        	chart.setBackgroundPaint(Color.WHITE);
		        	chart.setBorderVisible(false);
		        	plot.setInsets(new RectangleInsets(0,0,5.0,1.0));
		        	if (metaData.isColorBarVisible()) plot.getColorBar().setBasic(true);
				} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
					chart.setBackgroundPaint(app.getBackgroundPaint());
		        else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
				return chart;
			}
			throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());
		} catch (Throwable t) {
			throw new VisualisationException(t);
		}
	}
	
	public static ChartPanel createInteractiveRectangleAreaChart(IDatasetProducer ds,  RectangleAreaChartMetadata metadata) throws VisualisationException {
		try {		
			Dataset data = ds.produceDataset(null);
		
			if (data instanceof RectangleAreaDataset) {
				final RectangleAreaPlot plot = new RectangleAreaPlot((RectangleAreaDataset)data, metadata.getColorMap(),false,metadata.getTooMany());
				if (!metadata.isColorBarVisible()) {
					plot.setColorBar(null);
				}
	        
				final JFreeChart chart = new JFreeChart(metadata.getTitle(), null, plot, false);
	        
				if (metadata.getSubTitle() != null) {
					chart.addSubtitle(new TextTitle(metadata.getSubTitle()));
				}
	        
				chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
	        
				ChartPanel panel = new ChartPanel(chart);
				SelectionHandler handler = new SelectionHandler(panel);
				
				panel.addMouseListener(handler);
				panel.addMouseMotionListener(handler);					
				
				return panel;
			}
		
			throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());
			
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}
	}	
	
	public static JFreeChart createSequenceChart(IDatasetProducer ds, SequenceMetadata metaData) throws VisualisationException {
		try {		
			Dataset data = ds.produceDataset(null);
		
		if (data instanceof SequenceDataset) {
	        final SequencePlot plot = new SequencePlot((SequenceDataset)data, null);

	        plot.setRows(2);
	        plot.setHgap(5);
	        plot.setVgap(5);
	        
	        CustomAppearance app = metaData.getCustomAppearance();
	        String title = metaData.hasCustomAppearance() && app.isShowTitle() || !metaData.hasCustomAppearance() ? metaData.getTitle() : "";
	        final JFreeChart chart = new JFreeChart(title,null,plot,false);
	        
			if (metaData.hasCustomAppearance() && (app.getTitleFont() != null || app.getTitleColor() != null)) {
				TextTitle titleObject = chart.getTitle();
				if (app.getTitleFont() != null)
					titleObject.setFont(app.getTitleFont());
				if (app.getTitleColor() != null)
					titleObject.setPaint(app.getTitleColor());
			}
			
			if (metaData.getSubTitle() != null && !metaData.hasCustomAppearance())
				chart.addSubtitle(new TextTitle(metaData.getSubTitle()));
			else if (metaData.getSubTitle() != null && metaData.hasCustomAppearance() &&
					 app.isShowSubtitle()) {
					TextTitle subTitle = new TextTitle(metaData.getSubTitle());
					if (app.getSubtitleFont() != null)
						subTitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subTitle.setPaint(app.getSubtitleColor());
					chart.addSubtitle(subTitle);
			}

			if (!metaData.hasCustomAppearance() && metaData.getEnvironmentAppearance() == Appearance.BASIC_APP) {
	        	plot.setFilledSet(false);
	        	chart.setBackgroundPaint(Color.WHITE);
	        	chart.setBorderVisible(false);
	        	plot.setOutlineStroke(null);
	        	plot.setInsets(new RectangleInsets(0,0,1.0,1.0));
			} else if (metaData.hasCustomAppearance() && app.getBackgroundPaint() != null)
				chart.setBackgroundPaint(app.getBackgroundPaint());
	        else chart.setBackgroundPaint(new GradientPaint(0, 0, Color.white, 0, 1000, Color.black));
	        return chart;
		}
		
		throw new VisualisationException("Invalid Dataset type: " + data.getClass().toString());		
		} catch (Throwable t) {
			
			throw new VisualisationException(t);
		}		
	}
	

	
	
	public static void addXYLineChart(JFreeChart chart, XYSeriesCollectionProducer producer,
									  boolean second_y_axis, boolean second_y_axis_log, String second_y_axis_title,
									  boolean two_layers,
									  boolean second_x_axis_log, String second_x_axis_title,
									  boolean hasLegend, int rendererType)
									  throws DataSourceException {
		
		XYPlot plot = chart.getXYPlot();
		XYSeriesCollection dataset = (XYSeriesCollection)producer.produceDataset(null);
		
		LegendItemCollection lcollection = null;
		if (hasLegend) {
			lcollection = new LegendItemCollection();
			lcollection.addAll(plot.getLegendItems());
		}

		int i = plot.getDatasetCount();
		plot.setDataset(i,dataset);
		if (plot.getDomainAxis() instanceof LogarithmicAxis) {
			removeNonPositiveElements(dataset,true,false);
			dataset.addChangeListener(new NonPositiveElementRemover(true,false));
		}
		
		if ((plot.getRangeAxis() instanceof LogarithmicAxis && !second_y_axis) ||
			(second_y_axis && second_y_axis_log)) {
			removeNonPositiveElements(dataset,false,true);
			dataset.addChangeListener(new NonPositiveElementRemover(false,true));
		}
		
		boolean showLines = rendererType <= LineChartMetadata.RENDERER_LINES_AND_SHAPES;
		boolean showShapes = rendererType >= LineChartMetadata.RENDERER_LINES_AND_SHAPES;
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(showLines,showShapes);
		plot.setRenderer(i, renderer);
		
		if (second_y_axis && plot.getRangeAxisCount()<2) {
			int j = plot.getRangeAxisCount();
			ValueAxis yAxis2 = second_y_axis_log ? new LogarithmicAxis(second_y_axis_title) : new NumberAxis(second_y_axis_title);
			yAxis2.setLabelPaint(renderer.getSeriesPaint(0));
			plot.setRangeAxis(j,yAxis2);
			plot.mapDatasetToRangeAxis(i,j);
		}

		if (plot.getDomainAxis(0) instanceof DateAxis) {
			int j = plot.getDomainAxisCount();
			if (j < 2) {
				if (second_x_axis_log) {
					removeNonPositiveElements(dataset,true,false);
					dataset.addChangeListener(new NonPositiveElementRemover(true,false));
				}
				ValueAxis xAxis2 = second_x_axis_log ? new LogarithmicAxis(second_x_axis_title) : new NumberAxis(second_x_axis_title);
				xAxis2.setLabelPaint(renderer.getSeriesPaint(0));
				plot.setDomainAxis(j,xAxis2);
				plot.mapDatasetToDomainAxis(i,j);
			} else {
				ValueAxis valAxis = plot.getDomainAxis(j-1);
				if (valAxis instanceof LogarithmicAxis) {
					removeNonPositiveElements(dataset,true,false);
					dataset.addChangeListener(new NonPositiveElementRemover(true,false));
				}
				if (valAxis.getLabel() == null || valAxis.getLabel().equals("")) {
					valAxis.setLabel(second_x_axis_title);
					valAxis.setLabelPaint(renderer.getSeriesPaint(0));
				}
				plot.mapDatasetToDomainAxis(i,j-1);
			}
		} else plot.getDomainAxis(0).setStandardTickUnits(NumberAxis.createStandardTickUnits());
		
		if (hasLegend && second_y_axis && two_layers) {
			chart.removeLegend();
			LegendTitle legend1 = new LegendTitle(plot.getRenderer());
			legend1.setMargin(new RectangleInsets(1.0,1.0,1.0,1.0));
			legend1.setBorder(new BlockBorder());
			legend1.setBackgroundPaint(Color.white);
			LegendTitle legend2 = new LegendTitle(renderer);
			legend2.setMargin(new RectangleInsets(1.0,1.0,1.0,1.0));
			legend2.setBorder(new BlockBorder());
			legend2.setBackgroundPaint(Color.white);
			BlockContainer container = new BlockContainer(new FlowArrangement(null,null,50,0));
			container.add(legend1);
			container.add(legend2);
			CompositeTitle two_legends = new CompositeTitle(container);
			two_legends.setPosition(RectangleEdge.BOTTOM);
			chart.addSubtitle(two_legends);
		} else if (hasLegend) {
			for (int k=0;k<dataset.getSeriesCount();++k) {
				String label = dataset.getSeriesKey(k).toString();
				if (second_y_axis) label += "[right y-axis]";
				String description = label;
				String toolTipText = null;
				if (renderer.getLegendItemToolTipGenerator() != null) {
					toolTipText = renderer.getLegendItemToolTipGenerator().generateLabel(dataset,k);
				}
				String urlText = null;
				if (renderer.getLegendItemURLGenerator() != null) {
					urlText = renderer.getLegendItemURLGenerator().generateLabel(dataset,k);
				}
				boolean shapeIsVisible = renderer.getItemShapeVisible(k,0);
				Shape shape = renderer.getSeriesShape(k);
				boolean shapeIsFilled = renderer.getItemShapeFilled(k,0);
				Paint fillPaint = (renderer.getUseFillPaint() 
						? renderer.getSeriesFillPaint(k) : renderer.getSeriesPaint(k));
				boolean shapeOutlineVisible = renderer.getDrawOutlines();  
				Paint outlinePaint = (renderer.getUseOutlinePaint() 
						? renderer.getSeriesOutlinePaint(k) 
						: renderer.getSeriesPaint(k));
				Stroke outlineStroke = renderer.getSeriesOutlineStroke(k);
				boolean lineVisible = renderer.getItemLineVisible(k,0);
				Stroke lineStroke = renderer.getSeriesStroke(k);
				Paint linePaint = renderer.getSeriesPaint(k);
				LegendItem item = new LegendItem(label, description, toolTipText, 
						urlText, shapeIsVisible, shape, shapeIsFilled, 
						fillPaint, shapeOutlineVisible, outlinePaint, 
						outlineStroke, lineVisible, renderer.getLegendLine(), 
						lineStroke, linePaint);
				lcollection.add(item);
			}
			plot.setFixedLegendItems(lcollection);
		}
		plot.setDatasetRenderingOrder(DatasetRenderingOrder.REVERSE);
	}
	
	public static void addScatterPlotChart(JFreeChart chart, XYSeriesCollectionProducer producer,
										   boolean second_y_axis, boolean second_y_axis_log, String second_y_axis_title,
										   boolean two_layers,
										   boolean second_x_axis_log, String second_x_axis_title,
										   boolean hasLegend)
										   throws DataSourceException {
		
		XYPlot plot = chart.getXYPlot();
		XYSeriesCollection dataset = (XYSeriesCollection)producer.produceDataset(null);
		
		LegendItemCollection lcollection = null;
		if (hasLegend) {
			lcollection = new LegendItemCollection();
			lcollection.addAll(plot.getLegendItems());
		}

		int i = plot.getDatasetCount();
		plot.setDataset(i,dataset);
		if (plot.getDomainAxis() instanceof LogarithmicAxis) {
			removeNonPositiveElements(dataset,true,false);
			dataset.addChangeListener(new NonPositiveElementRemover(true,false));
		}
		
		if ((plot.getRangeAxis() instanceof LogarithmicAxis && !second_y_axis) ||
			(second_y_axis && second_y_axis_log)) {
			removeNonPositiveElements(dataset,false,true);
			dataset.addChangeListener(new NonPositiveElementRemover(false,true));
		}
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(false,true);
		plot.setRenderer(i, renderer);
		
		if (second_y_axis && plot.getRangeAxisCount()<2) {
			int j = plot.getRangeAxisCount();
			ValueAxis yAxis2 = second_y_axis_log ? new LogarithmicAxis(second_y_axis_title) : new NumberAxis(second_y_axis_title);
			yAxis2.setLabelPaint(renderer.getSeriesPaint(0));
			plot.setRangeAxis(j,yAxis2);
			plot.mapDatasetToRangeAxis(i,j);
		}

		if (plot.getDomainAxis(0) instanceof DateAxis) {
			int j = plot.getDomainAxisCount();
			if (j < 2) {
				if (second_x_axis_log) {
					removeNonPositiveElements(dataset,true,false);
					dataset.addChangeListener(new NonPositiveElementRemover(true,false));
				}
				ValueAxis xAxis2 = second_x_axis_log ? new LogarithmicAxis(second_x_axis_title) : new NumberAxis(second_x_axis_title);
				xAxis2.setLabelPaint(renderer.getSeriesPaint(0));
				plot.setDomainAxis(j,xAxis2);
				plot.mapDatasetToDomainAxis(i,j);
			} else {
				ValueAxis valAxis = plot.getDomainAxis(j-1);
				if (valAxis instanceof LogarithmicAxis) {
					removeNonPositiveElements(dataset,true,false);
					dataset.addChangeListener(new NonPositiveElementRemover(true,false));
				}
				if (valAxis.getLabel() == null || valAxis.getLabel().equals("")) {
					valAxis.setLabel(second_x_axis_title);
					valAxis.setLabelPaint(renderer.getSeriesPaint(0));
				}
				plot.mapDatasetToDomainAxis(i,j-1);
			}
		} else plot.getDomainAxis(0).setStandardTickUnits(NumberAxis.createStandardTickUnits());
		
		if (hasLegend && second_y_axis && two_layers) {
			chart.removeLegend();
			LegendTitle legend1 = new LegendTitle(plot.getRenderer());
			legend1.setMargin(new RectangleInsets(1.0,1.0,1.0,1.0));
			legend1.setBorder(new BlockBorder());
			legend1.setBackgroundPaint(Color.white);
			LegendTitle legend2 = new LegendTitle(renderer);
			legend2.setMargin(new RectangleInsets(1.0,1.0,1.0,1.0));
            legend2.setBorder(new BlockBorder());
            legend2.setBackgroundPaint(Color.white);
            BlockContainer container = new BlockContainer(new FlowArrangement(null,null,50,0));
            container.add(legend1);
            container.add(legend2);
            CompositeTitle two_legends = new CompositeTitle(container);
            two_legends.setPosition(RectangleEdge.BOTTOM);
            chart.addSubtitle(two_legends);
		} else if (hasLegend) {
			for (int k=0;k<dataset.getSeriesCount();++k) {
				String label = dataset.getSeriesKey(k).toString();
				if (second_y_axis) label += "[right y-axis]";
				String description = label;
				String toolTipText = null;
				if (renderer.getLegendItemToolTipGenerator() != null) {
					toolTipText = renderer.getLegendItemToolTipGenerator().generateLabel(dataset,k);
				}
				String urlText = null;
				if (renderer.getLegendItemURLGenerator() != null) {
					urlText = renderer.getLegendItemURLGenerator().generateLabel(dataset,k);
				}
				boolean shapeIsVisible = renderer.getItemShapeVisible(k,0);
				Shape shape = renderer.getSeriesShape(k);
				boolean shapeIsFilled = renderer.getItemShapeFilled(k,0);
				Paint fillPaint = (renderer.getUseFillPaint() 
						? renderer.getSeriesFillPaint(k) : renderer.getSeriesPaint(k));
				boolean shapeOutlineVisible = renderer.getDrawOutlines();  
				Paint outlinePaint = (renderer.getUseOutlinePaint() 
						? renderer.getSeriesOutlinePaint(k) 
						: renderer.getSeriesPaint(k));
				Stroke outlineStroke = renderer.getSeriesOutlineStroke(k);
				boolean lineVisible = renderer.getItemLineVisible(k,0);
				Stroke lineStroke = renderer.getSeriesStroke(k);
				Paint linePaint = renderer.getSeriesPaint(k);
				LegendItem item = new LegendItem(label, description, toolTipText, 
						urlText, shapeIsVisible, shape, shapeIsFilled, 
						fillPaint, shapeOutlineVisible, outlinePaint, 
						outlineStroke, lineVisible, renderer.getLegendLine(), 
						lineStroke, linePaint);
				lcollection.add(item);
			}
			plot.setFixedLegendItems(lcollection);
		}
		plot.setDatasetRenderingOrder(DatasetRenderingOrder.REVERSE);
	}
	
	public static void addRealTimeSeriesChart(JFreeChart chart, RealTimeSeriesCollectionProducer producer, boolean second_y_axis, String x_axis_title, String second_y_axis_title, boolean two_layers, boolean hasLegends)
							throws DataSourceException {
		
		XYPlot plot = chart.getXYPlot();
		XYDataset dataset = (XYDataset)producer.produceDataset(null);
		
		LegendItemCollection lcollection = null;
		if (hasLegends) {
			lcollection = new LegendItemCollection();
			lcollection.addAll(plot.getLegendItems());
		}
		
		int i = plot.getDatasetCount();
		plot.setDataset(i,dataset);
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(true,true);
		plot.setRenderer(i, renderer);
		if ((second_y_axis || plot.getRangeAxis() instanceof LogarithmicAxis)/*&& plot.getRangeAxisCount()<2*/) {
			int j = plot.getRangeAxisCount();
			ValueAxis yAxis2 = new NumberAxis(second_y_axis_title);
			yAxis2.setLabelPaint(renderer.getSeriesPaint(0));
			plot.setRangeAxis(j,yAxis2);
			plot.mapDatasetToRangeAxis(i,j);
		}
		int j = plot.getDomainAxisCount();
		int index = -1;
		for (int k=0;k<j;++k) {
			if (plot.getDomainAxis(k) instanceof DateAxis) {
				index = k; break;
			}
		}
		if (index == -1) {
			ValueAxis xAxis2 = new DateAxis(x_axis_title);
			xAxis2.setLabelPaint(renderer.getSeriesPaint(0));
			plot.setDomainAxis(j,xAxis2);
			plot.mapDatasetToDomainAxis(i,j);
		} else {
			plot.mapDatasetToDomainAxis(i,index);
		}
		if (hasLegends && (second_y_axis || plot.getRangeAxis() instanceof LogarithmicAxis) && two_layers) {
			chart.removeLegend();
			LegendTitle legend1 = new LegendTitle(plot.getRenderer(0));
			legend1.setMargin(new RectangleInsets(1.0,1.0,1.0,1.0));
			legend1.setBorder(new BlockBorder());
			legend1.setBackgroundPaint(Color.white);
			LegendTitle legend2 = new LegendTitle(renderer);
			legend2.setMargin(new RectangleInsets(1.0,1.0,1.0,1.0));
            legend2.setBorder(new BlockBorder());
            legend2.setBackgroundPaint(Color.white);
            
            BlockContainer container = new BlockContainer(new FlowArrangement(null,null,50,0));
            container.add(legend1);
            container.add(legend2);
            CompositeTitle two_legends = new CompositeTitle(container);
            two_legends.setPosition(RectangleEdge.BOTTOM);
            chart.addSubtitle(two_legends);
		} else if (hasLegends) {
			for (int k=0;k<dataset.getSeriesCount();++k) {
				String label = dataset.getSeriesKey(k).toString();
				if (second_y_axis) label  += "[right value-axis]";
				String description = label;
				String toolTipText = null;
				if (renderer.getLegendItemToolTipGenerator() != null) {
					toolTipText = renderer.getLegendItemToolTipGenerator().generateLabel(dataset,k);
				}
				String urlText = null;
				if (renderer.getLegendItemURLGenerator() != null) {
					urlText = renderer.getLegendItemURLGenerator().generateLabel(dataset,k);
				}
				boolean shapeIsVisible = renderer.getItemShapeVisible(k,0);
				Shape shape = renderer.getSeriesShape(k);
				boolean shapeIsFilled = renderer.getItemShapeFilled(k,0);
				Paint fillPaint = (renderer.getUseFillPaint() 
						? renderer.getSeriesFillPaint(k) : renderer.getSeriesPaint(k));
				boolean shapeOutlineVisible = renderer.getDrawOutlines();  
				Paint outlinePaint = (renderer.getUseOutlinePaint() 
						? renderer.getSeriesOutlinePaint(k) 
						: renderer.getSeriesPaint(k));
				Stroke outlineStroke = renderer.getSeriesOutlineStroke(k);
				boolean lineVisible = renderer.getItemLineVisible(k,0);
				Stroke lineStroke = renderer.getSeriesStroke(k);
				Paint linePaint = renderer.getSeriesPaint(k);
				LegendItem item = new LegendItem(label, description, toolTipText, 
						urlText, shapeIsVisible, shape, shapeIsFilled, 
						fillPaint, shapeOutlineVisible, outlinePaint, 
						outlineStroke, lineVisible, renderer.getLegendLine(), 
						lineStroke, linePaint);
				lcollection.add(item);
			}
			plot.setFixedLegendItems(lcollection);
		}
		plot.setDatasetRenderingOrder(DatasetRenderingOrder.REVERSE);
	}
	
	public static int addHistogramChart(JFreeChart chart, ExtendedHistogramDatasetProducer producer, boolean second_y_axis, boolean two_layers,
										boolean hasLegend, double[] rangeBounds) throws DataSourceException {
		
		XYPlot plot = chart.getXYPlot();
		XYDataset dataset = (XYDataset) producer.produceDataset(null);
		
		LegendItemCollection lcollection = null;
		if (hasLegend) {
			lcollection = new LegendItemCollection();
			lcollection.addAll(plot.getLegendItems());
		}
		
		int i = plot.getDatasetCount();
		XYBarRenderer renderer = new XYBarRenderer();
		plot.setRenderer(i, renderer);
		if ((second_y_axis || plot.getRangeAxis() instanceof LogarithmicAxis) /*&& plot.getRangeAxisCount()<2*/) {
			int j = plot.getRangeAxisCount();
			ValueAxis yAxis2 = new NumberAxis();
			plot.setRangeAxis(j,yAxis2);
			plot.mapDatasetToRangeAxis(i,j);
			
			if (rangeBounds[0] != - Double.MAX_VALUE || rangeBounds[1] != Double.MAX_VALUE) {
				yAxis2.configure();
				yAxis2.setAutoRange(false);
				if (rangeBounds[0] != - Double.MAX_VALUE)
					yAxis2.setLowerBound(rangeBounds[0]);
				if (rangeBounds[1] != Double.MAX_VALUE)
					yAxis2.setUpperBound(rangeBounds[1]);
			}
		}
		int j = plot.getDomainAxisCount();
		int index = -1;
		for (int k = 0;k < j;++k) {
			if (plot.getDomainAxis(k) instanceof NumberAxis && !(plot.getDomainAxis(k) instanceof LogarithmicAxis)) {
				index = k;
				break;
			}
		}
		if (index == -1) {
			ValueAxis xAxis2 = new NumberAxis();
			plot.setDomainAxis(j,xAxis2);
			plot.mapDatasetToDomainAxis(i,j);
		} else plot.mapDatasetToDomainAxis(i, index);
		plot.setDataset(i,dataset);
		
		if (hasLegend && (second_y_axis || plot.getRangeAxis() instanceof LogarithmicAxis) && two_layers) {
			chart.removeLegend();
			LegendTitle legend1 = new LegendTitle(plot.getRenderer(0));
			legend1.setMargin(new RectangleInsets(1.0,1.0,1.0,1.0));
			legend1.setBorder(new BlockBorder());
			legend1.setBackgroundPaint(Color.white);
			LegendTitle legend2 = new LegendTitle(renderer);
			legend2.setMargin(new RectangleInsets(1.0,1.0,1.0,1.0));
            legend2.setBorder(new BlockBorder());
            legend2.setBackgroundPaint(Color.white);
            
            BlockContainer container = new BlockContainer(new FlowArrangement(null,null,50,0));
            container.add(legend1);
            container.add(legend2);
            CompositeTitle two_legends = new CompositeTitle(container);
            two_legends.setPosition(RectangleEdge.BOTTOM);
            chart.addSubtitle(two_legends);
		} else if (hasLegend) {
			for (int k = 0;k < dataset.getSeriesCount();++k) {
				String label = dataset.getSeriesKey(k).toString();
				if (second_y_axis) label += "[right v. axis]";
				String description = label;
				String toolTipText = null;
				if (renderer.getLegendItemToolTipGenerator() != null) {
					toolTipText = renderer.getLegendItemToolTipGenerator().generateLabel(dataset,k);
				}
				String urlText = null;
				if (renderer.getLegendItemURLGenerator() != null) {
					urlText = renderer.getLegendItemURLGenerator().generateLabel(dataset,k);
				}
				Shape shape = new Rectangle2D.Double(-3.0, -5.0, 6.0, 10.0);
				Paint paint = renderer.getSeriesPaint(k);
				Paint outlinePaint = renderer.getSeriesOutlinePaint(k);
				Stroke outlineStroke = renderer.getSeriesOutlineStroke(k);
				LegendItem item = new LegendItem(label,description,toolTipText,
						urlText,shape,paint,outlineStroke,outlinePaint);
				lcollection.add(item);
			}			
			plot.setFixedLegendItems(lcollection);
		}
		plot.setDatasetRenderingOrder(DatasetRenderingOrder.REVERSE);
		return i;
	}
	
	public static void addTimeSeriesChart(JFreeChart chart, TimeSeriesCollectionProducer producer, boolean second_y_axis, String second_y_axis_title, boolean two_layers, String second_x_axis_title, boolean hasLegends)
							throws DataSourceException {
		
		XYPlot plot = chart.getXYPlot();
		XYDataset dataset = (XYDataset)producer.produceDataset(null);
		
		LegendItemCollection lcollection = null;
		if (hasLegends) {
			lcollection = new LegendItemCollection();
			lcollection.addAll(plot.getLegendItems());
		}
		
		int i = plot.getDatasetCount();
		plot.setDataset(i,dataset);
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(true,true);
		plot.setRenderer(i, renderer);
		if ((second_y_axis || plot.getRangeAxis() instanceof LogarithmicAxis) /*&& plot.getRangeAxisCount()<2*/) {
			int j = plot.getRangeAxisCount();
			ValueAxis yAxis2 = new NumberAxis(second_y_axis_title);
			yAxis2.setLabelPaint(renderer.getSeriesPaint(0));
			plot.setRangeAxis(j,yAxis2);
			plot.mapDatasetToRangeAxis(i,j);
		}
		int index = -1;
		int j = plot.getDomainAxisCount();
		for (int k=0;k<j;++k) {
			if (plot.getDomainAxis(k) instanceof NumberAxis && !(plot.getDomainAxis(k) instanceof LogarithmicAxis)) {
				index = k;
				break;
			}
		}
		if (index == -1) {
			ValueAxis xAxis2 = new NumberAxis(second_x_axis_title);
			xAxis2.setLabelPaint(renderer.getSeriesPaint(0));
			plot.setDomainAxis(j,xAxis2);
			plot.mapDatasetToDomainAxis(i,j);
		} else {
			ValueAxis numAxis = plot.getDomainAxis(index);
			if (numAxis.getLabel() == null || numAxis.getLabel().equals("")) {
				numAxis.setLabel(second_x_axis_title);
				numAxis.setLabelPaint(renderer.getSeriesPaint(0));
			}
			plot.mapDatasetToDomainAxis(i,index);
		}
		if (hasLegends && (second_y_axis || plot.getRangeAxis() instanceof LogarithmicAxis) && two_layers) {
			chart.removeLegend();
			LegendTitle legend1 = new LegendTitle(plot.getRenderer());
			legend1.setMargin(new RectangleInsets(1.0,1.0,1.0,1.0));
			legend1.setBorder(new BlockBorder());
			legend1.setBackgroundPaint(Color.white);
			LegendTitle legend2 = new LegendTitle(renderer);
			legend2.setMargin(new RectangleInsets(1.0,1.0,1.0,1.0));
			legend2.setBorder(new BlockBorder());
			legend2.setBackgroundPaint(Color.white);
			BlockContainer container = new BlockContainer(new FlowArrangement(null,null,50,0));
			container.add(legend1);
			container.add(legend2);
			CompositeTitle two_legends = new CompositeTitle(container);
			two_legends.setPosition(RectangleEdge.BOTTOM);
			chart.addSubtitle(two_legends);
		} else if (hasLegends) {
			for (int k=0;k<dataset.getSeriesCount();++k) {
				String label = dataset.getSeriesKey(k).toString();
				if (second_y_axis) label += "[right y-axis]";
				String description = label;
				String toolTipText = null;
				if (renderer.getLegendItemToolTipGenerator() != null) {
					toolTipText = renderer.getLegendItemToolTipGenerator().generateLabel(dataset,k);
				}
				String urlText = null;
				if (renderer.getLegendItemURLGenerator() != null) {
					urlText = renderer.getLegendItemURLGenerator().generateLabel(dataset,k);
				}
				boolean shapeIsVisible = renderer.getItemShapeVisible(k,0);
				Shape shape = renderer.getSeriesShape(k);
				boolean shapeIsFilled = renderer.getItemShapeFilled(k,0);
				Paint fillPaint = (renderer.getUseFillPaint() 
						? renderer.getSeriesFillPaint(k) : renderer.getSeriesPaint(k));
				boolean shapeOutlineVisible = renderer.getDrawOutlines();  
				Paint outlinePaint = (renderer.getUseOutlinePaint() 
						? renderer.getSeriesOutlinePaint(k) 
						: renderer.getSeriesPaint(k));
				Stroke outlineStroke = renderer.getSeriesOutlineStroke(k);
				boolean lineVisible = renderer.getItemLineVisible(k,0);
				Stroke lineStroke = renderer.getSeriesStroke(k);
				Paint linePaint = renderer.getSeriesPaint(k);
				LegendItem item = new LegendItem(label, description, toolTipText, 
						urlText, shapeIsVisible, shape, shapeIsFilled, 
						fillPaint, shapeOutlineVisible, outlinePaint, 
						outlineStroke, lineVisible, renderer.getLegendLine(), 
						lineStroke, linePaint);
				lcollection.add(item);
			}
			plot.setFixedLegendItems(lcollection);
		}
		plot.setDatasetRenderingOrder(DatasetRenderingOrder.REVERSE);
	}
	
	public static void removeNonPositiveElements(XYSeriesCollection dataset, boolean xPos, boolean yPos) {
		if (xPos) {
			for (int i=0;i<dataset.getSeriesCount();++i) {
				ModifiableXYSeries series = (ModifiableXYSeries)dataset.getSeries(i);
				XYSeries new_series = new XYSeries(series.getKey());
				for (int j=0 ; j<series.getItemCount() ; ++ j) {
					if (series.getX(j).doubleValue()  > 0 ) new_series.add(series.getDataItem(j));
				}
				series.setItems(new_series);

			}
		}
		if (yPos) {
			for (int i=0;i<dataset.getSeriesCount();++i) {
				ModifiableXYSeries series = (ModifiableXYSeries)dataset.getSeries(i);
				XYSeries new_series = new XYSeries(series.getKey());
				for (int j=0 ; j<series.getItemCount() ; ++ j) {
					if (series.getY(j).doubleValue() > 0) new_series.add(series.getDataItem(j));
				}
				series.setItems(new_series);
			}
		}
	}
	
	public static void removeNonPositiveElements(MatrixOfScatterplotsDataset dataset, boolean xPos, boolean yPos) {
		if (xPos) {
			for (int i=0;i<dataset.getSeriesCount();++i) {
				ModifiableXYSeries series = (ModifiableXYSeries)dataset.getSeries(i);
				XYSeries new_series = new XYSeries(series.getKey());
				for (int j=0 ; j<series.getItemCount() ; ++ j) {
					if (series.getX(j).doubleValue()  > 0 ) new_series.add(series.getDataItem(j));
				}
				series.setItems(new_series);

			}
		}
		if (yPos) {
			for (int i=0;i<dataset.getSeriesCount();++i) {
				ModifiableXYSeries series = (ModifiableXYSeries)dataset.getSeries(i);
				XYSeries new_series = new XYSeries(series.getKey());
				for (int j=0 ; j<series.getItemCount() ; ++ j) {
					if (series.getY(j).doubleValue() > 0) new_series.add(series.getDataItem(j));
				}
				series.setItems(new_series);
			}
		}
	}

	
}
