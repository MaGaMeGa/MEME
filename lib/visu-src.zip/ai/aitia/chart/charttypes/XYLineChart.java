/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes;

import java.awt.Container;
import java.awt.Font;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JSeparator;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetChangeListener;
import org.jfree.ui.RectangleEdge;
import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.AbstractChartDialog;
import ai.aitia.chart.charttypes.dialogs.XYLineDialog;
import ai.aitia.chart.emulator.ProducerEmulator;
import ai.aitia.chart.emulator.SimpleXYSeriesProducer;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLLoadingException.TemplateLoadingException;
import ai.aitia.visu.VisualisationException;
import ai.aitia.visu.data.ExtendedHistogramDataset;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.ExtendedHistogramDatasetProducer;
import ai.aitia.visu.ds.IDataProducer;
import ai.aitia.visu.ds.IDatasetProducer;
import ai.aitia.visu.ds.IXYSeriesProducer;
import ai.aitia.visu.ds.RealTimeSeriesCollectionProducer;
import ai.aitia.visu.ds.TimeSeriesCollectionProducer;
import ai.aitia.visu.ds.XYSeriesCollectionProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.view.ChartFactory;
import ai.aitia.visu.view.CustomSaveableChartPanel;
import ai.aitia.visu.view.meta.Appearance;
import ai.aitia.visu.view.meta.CustomAppearance;
import ai.aitia.visu.view.meta.LineChartMetadata;

/** XY line chart type. It is a graphical display of a f(x) function in Cartesian
 *  coordinate system.
 */
public class XYLineChart extends AbstractChart implements DatasetChangeListener {

	/** Storage of the outliers' data of the child histograms in a multi-layered chart.*/ 
	private HashMap<ExtendedHistogramDataset,OutliersData> outliers = new HashMap<ExtendedHistogramDataset, OutliersData>();
	
	//===============================================================================
	// methods
	
	@Override
	public Container createChart(ChartConfig config) throws DataSourceException, VisualisationException {
		
		if (config.getChartProperties() instanceof Properties) {
			
			Properties properties = (Properties)config.getChartProperties();
			
			LineChartMetadata meta = new LineChartMetadata();
			meta.setTitle(properties.getProperty(ChartConstants.TITLE));
			meta.setSubTitle(properties.getProperty(ChartConstants.SUBTITLE));
			meta.setXAxisLabel(properties.getProperty(ChartConstants.X_AXIS));
			meta.setYAxisLabel(properties.getProperty(ChartConstants.Y_AXIS));
			String scale = properties.getProperty(ChartConstants.X_AXIS_SCALE);
			meta.setXLog(scale.equals(ChartConstants.LOG));
			scale = properties.getProperty(ChartConstants.Y_AXIS_SCALE);
			meta.setYLog(scale.equals(ChartConstants.LOG));
			meta.setShowLegend(Boolean.parseBoolean(properties.getProperty(ChartConstants.SHOW_LEGEND,"true")));
			meta.setRendererType(Integer.parseInt(properties.getProperty(ChartConstants.XYLINE_RENDERER,String.valueOf(LineChartMetadata.RENDERER_LINES_ONLY))));
			
			String templateName = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			boolean needDefault = true;
			if (templateName != null && !"".equals(templateName)) {
				Element template = templates.get(templateName);
				if (template != null) {
					try {
						CustomAppearance appearance = createCustomAppearance(template);
						meta.setCustomAppearance(appearance);
						needDefault = false;
					} catch (TemplateLoadingException e) {
						throw new VisualisationException(e);
					}
				}
			}
			if (needDefault) {
				int color = Appearance.COLORED;
				if (properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE))
					color = Appearance.BLACK_AND_WHITE;
				meta.setColorAppearance(color);
				int env = Appearance.BASIC_APP;
				if (properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP))
					env = Appearance.NORMAL_APP;
				meta.setEnvironmentAppearance(env);
			}
		
			outliers.clear();
			ArrayList<IDataProducer> dp = new ArrayList<IDataProducer>();
			XYSeriesCollectionProducer xyscp = (XYSeriesCollectionProducer)createDatasetProducer(config,dp);
			if (config.isFireInitialEvent()) {
				for (IDataProducer series : dp) xyscp.dataChanged(new DataChangeEvent(series));
			}
			JFreeChart chart = ChartFactory.createXYLineChart(xyscp, meta);
			
			// Add other charts (if any)
			if (config.isMultiLayerChart()) {
				boolean two_layers = config.getChilds().size() == 1;
				for (ChartConfig cc : config.getChilds()) {
					if (cc.getChartProperties() instanceof Properties) {
						Properties prop = (Properties) cc.getChartProperties();
						boolean second_y_axis = Boolean.parseBoolean(prop.getProperty(ChartConstants.SECOND_VERTICAL_AXIS)); 
						IDatasetProducer dsp = AbstractChart.find(cc.getChartType()).createDatasetProducer(cc,dp);
						if (cc.getChartType().equals(ChartConstants.HISTOGRAM)) {
							ExtendedHistogramDatasetProducer hdsp = (ExtendedHistogramDatasetProducer) dsp;
							if (config.isFireInitialEvent()) {
								for (IDataProducer p : dp) hdsp.dataChanged(new DataChangeEvent(p));
							}
							double[] rangeBounds = { - Double.MAX_VALUE, Double.MAX_VALUE };
							try {
								boolean user_defined = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_RANGE_LOWER_BOUND,"true"));
								if (user_defined)
									rangeBounds[0] = Double.parseDouble(prop.getProperty(ChartConstants.RANGE_LOWER_BOUND,""));
							} catch (NumberFormatException e) {}
							try {
								boolean user_defined = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_RANGE_UPPER_BOUND,"true"));
								if (user_defined)
									rangeBounds[1] = Double.parseDouble(prop.getProperty(ChartConstants.RANGE_UPPER_BOUND,""));
							} catch (NumberFormatException e) {}
							int index = ChartFactory.addHistogramChart(chart,hdsp,second_y_axis,two_layers,meta.isShowLegend(),rangeBounds);
							String strategy = prop.getProperty(ChartConstants.OUT_OF_BOUNDS_STRATEGY);
							if (strategy.equals(ChartConstants.OUTLIERS_STRATEGY)) {
								OutliersData od = new OutliersData(strategy,prop.getProperty(ChartConstants.OUTLIERS_TITLE));
								od.setChart(chart);
								od.setRendererIdx(index);
								outliers.put((ExtendedHistogramDataset)chart.getXYPlot().getDataset(index),od);
							} else {
								outliers.put((ExtendedHistogramDataset)chart.getXYPlot().getDataset(index),new OutliersData(strategy));
							}							chart.getXYPlot().getDataset(index).addChangeListener(this);
							datasetChanged(new DatasetChangeEvent(chart.getXYPlot().getDataset(index),chart.getXYPlot().getDataset(index)));
						} else if (cc.getChartType().equals(ChartConstants.TIMESERIES)) {
							TimeSeriesCollectionProducer tscp = (TimeSeriesCollectionProducer)dsp;
							String x_axis_title = prop.getProperty(ChartConstants.TIME_AXIS);
							String second_y_axis_title = prop.getProperty(ChartConstants.VALUE_AXIS);
							if (config.isFireInitialEvent()) {
								for (IDataProducer p : dp) tscp.dataChanged(new DataChangeEvent(p));
							}
							ChartFactory.addTimeSeriesChart(chart,tscp,second_y_axis,x_axis_title,two_layers,second_y_axis_title,meta.isShowLegend());
						} else if (cc.getChartType().equals(ChartConstants.REALTIMESERIES)) {
							RealTimeSeriesCollectionProducer tscp = (RealTimeSeriesCollectionProducer)dsp;
							String x_axis_title = prop.getProperty(ChartConstants.TIME_AXIS);
							String second_y_axis_title = prop.getProperty(ChartConstants.VALUE_AXIS);
							if (config.isFireInitialEvent()) {
								for (IDataProducer p : dp) tscp.dataChanged(new DataChangeEvent(p));
							}
							ChartFactory.addRealTimeSeriesChart(chart,tscp,second_y_axis,x_axis_title,second_y_axis_title,two_layers,meta.isShowLegend());
						} else if (cc.getChartType().equals(ChartConstants.SCATTERPLOT)) {
							XYSeriesCollectionProducer c_xyscp = (XYSeriesCollectionProducer)dsp;
							String second_y_axis_title = prop.getProperty(ChartConstants.Y_AXIS);
							boolean second_y_axis_log = prop.getProperty(ChartConstants.Y_AXIS_SCALE).equals(ChartConstants.LOG);
							if (config.isFireInitialEvent()) {
								for (IDataProducer p : dp) c_xyscp.dataChanged(new DataChangeEvent(p));
							}
							ChartFactory.addScatterPlotChart(chart,c_xyscp,second_y_axis,second_y_axis_log,second_y_axis_title,two_layers,false,null,meta.isShowLegend());
						} else throw new VisualisationException(cc.getChartType() + " can't be part of a multilayer chart.");
					}
				}
			}
			
			CustomSaveableChartPanel panel = new CustomSaveableChartPanel(chart);
			
			if (meta.getCustomAppearance() != null && meta.getCustomAppearance().getDimension() != null)
				panel.setPreferredSize(meta.getCustomAppearance().getDimension());

			return panel;
		}
		return null;
	}

	//-------------------------------------------------------------------------------
	@Override
	public Container createDialog(ChartConfig config, ChartConfigCollection collection) {
		if (!config.isMultiLayerChart()) return new XYLineDialog(config,collection);
		JPanel child_panel = new JPanel();
		child_panel.setLayout(new BoxLayout(child_panel,BoxLayout.Y_AXIS));
		for (ChartConfig cc : config.getChilds()) {
			Container c = AbstractChart.find(cc.getChartType()).createDialog(cc,collection);
			((AbstractChartDialog)c).setChildMode(false);
			child_panel.add(new JSeparator(JSeparator.HORIZONTAL));
			child_panel.add(c);
		}
		XYLineDialog result = new XYLineDialog(config,collection,child_panel);
		for (int i=1;i<child_panel.getComponentCount();i+=2)
			((AbstractChartDialog)child_panel.getComponent(i)).setParent(result);
		return result;
	}

	//-------------------------------------------------------------------------------
	@Override
	public String getID() {
		return ChartConstants.XYLINECHART;
	}
	
	//-------------------------------------------------------------------------------
	@Override
	public String toString() {
		return ChartConstants.XYLINECHART_NAME;
	}

	//-------------------------------------------------------------------------------
	@Override
	public String getDescription() {
		return "XY line chart is a graphical display of a f(x) function in Cartesian" +
				" coordinate system.";
	}

	//-------------------------------------------------------------------------------
	@Override
	public List<Integer> getDataSourceIDs(ChartConfig config) {
		List<Integer> result = new ArrayList<Integer>();
		if (config.getChartProperties() instanceof Properties) {
			Properties prop = (Properties)config.getChartProperties();
			String[] curves = prop.getProperty(ChartConstants.DATASOURCE).split(",");
			for (int i=0;i<curves.length;++i) {
				int[] ds = Utilities.splitDatasourceAroundSpace(curves[i]);
				for (int j=0;j<ds.length;++j) {
					Integer candidate = new Integer(ds[j]);
					result.add(candidate);
				}
			}
		}
		return result;
	}
	
	//-------------------------------------------------------------------------------
	@Override
	public IDatasetProducer createDatasetProducer(ChartConfig config, ArrayList<IDataProducer> dp) throws DataSourceException {

		if (config.getChartProperties() instanceof Properties) {
			
			Properties properties = (Properties)config.getChartProperties();
			dp.clear();
		
			String[] curves = properties.getProperty(ChartConstants.DATASOURCE).split(",");
			
			boolean use_short_legend = Boolean.parseBoolean(properties.getProperty(ChartConstants.SHORT_LEGEND_NAMES,"false"));
			
			IXYSeriesProducer[] series = new IXYSeriesProducer[curves.length];
			for (int i=0;i<curves.length;++i) {
				int[] ds = Utilities.splitDatasourceAroundSpace(curves[i]);
				if (ds.length == 1) { // x supports the IXYSeriesProducer
					IDataSourceProducer dsp = config.getDataSource(ds[0]);
					series[i] = (IXYSeriesProducer)dsp.createDataProducer(config.getDataSourceType(ds[0]),null);
					dp.add(series[i]);
				} else { // x supports only the ISeriesProducer or IValueProducer
					IDataSourceProducer xdsp = config.getDataSource(ds[0]);
					IDataSourceProducer ydsp = config.getDataSource(ds[1]);
					IDataProducer xp = xdsp.createDataProducer(config.getDataSourceType(ds[0]),null);
					IDataProducer yp = ydsp.createDataProducer(config.getDataSourceType(ds[1]),null);
					List<IDataProducer> p = new ArrayList<IDataProducer>();
					p.add(xp);
					p.add(yp);
					series[i] = (IXYSeriesProducer)ProducerEmulator.createProducer(p,IXYSeriesProducer.class);
					if (use_short_legend) ((SimpleXYSeriesProducer)series[i]).changeToShortNames();
					dp.add(series[i]);
				}
			}

			XYSeriesCollectionProducer xyscp = new XYSeriesCollectionProducer(series);
			return xyscp;
		}
		return null;
	}

	//-------------------------------------------------------------------------------
	/** Updates the appropriate OutliersData object whenever the data changes (if need).
	 * @param event event
	 */ 
	public void datasetChanged(DatasetChangeEvent event) {
		OutliersData od = outliers.get(event.getDataset());
		if (od == null) return;
		if (od.getStrategy().equals(ChartConstants.OUTLIERS_STRATEGY)) {
			TreeMap<Double,Integer> tmOutliers = ((ExtendedHistogramDataset)event.getDataset()).getOutliers();
			String ol_string = od.getOutliers_title() + " : ";
			for (Entry e : tmOutliers.entrySet()) {
				ol_string += e.getKey() + " (" + e.getValue() + "), ";
			}
			ol_string = ol_string.substring(0,ol_string.length()-2);
			if (!tmOutliers.isEmpty()) {
				for (Entry<ExtendedHistogramDataset,OutliersData> e : outliers.entrySet()) { 
					if (e.getValue().getOutliers() != null) 
						od.getChart().removeSubtitle(e.getValue().getOutliers());
				}
				XYPlot plot = od.getChart().getXYPlot();
				od.setOutliers(new TextTitle(ol_string,new Font("SansSerif",Font.PLAIN,12),plot.getRenderer(od.getRendererIdx()).getSeriesPaint(0),
								RectangleEdge.BOTTOM, Title.DEFAULT_HORIZONTAL_ALIGNMENT, Title.DEFAULT_VERTICAL_ALIGNMENT,
								Title.DEFAULT_PADDING));
				for (Entry<ExtendedHistogramDataset,OutliersData> e : outliers.entrySet()) { 
					if (e.getValue().getOutliers() != null && e.getValue().getChart().equals(od.getChart())) 
						od.getChart().addSubtitle(e.getValue().getOutliers());
				}
			} else {
				od.setOutliers(null);
			}
		}
	}
}
