/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.utils;

import java.awt.*;
import java.awt.geom.GeneralPath;
import java.awt.image.BufferedImage;
import java.util.*;

import javax.swing.*;

import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.substance.SubstanceImageCreator;
import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.button.BaseButtonShaper;
import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.painter.*;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.utils.ComponentState.ColorSchemeKind;
import org.jvnet.substance.utils.SubstanceConstants.Side;

/**
 * Delegate class for painting backgrounds of buttons in <b>Substance </b> look
 * and feel. This class is <b>for internal use only</b>.
 * 
 * @author Kirill Grouchnikov
 */
public class PairwiseButtonBackgroundDelegate {
	/**
	 * Cache for background images for pairwise backgrounds. Each time
	 * {@link #getPairwiseBackground(AbstractButton, int, int, Side)} is called,
	 * it checks <code>this</code> map to see if it already contains such
	 * background. If so, the background from the map is returned.
	 */
	private static Map<String, BufferedImage> pairwiseBackgrounds = new HashMap<String, BufferedImage>();

	/**
	 * Contains information on a button background.
	 * 
	 * @author Kirill Grouchnikov
	 */
	public static class ButtonBackground {
		/**
		 * Indicates whether the button is painted in active visual state.
		 */
		public boolean isPaintedActive;

		/**
		 * The button background image.
		 */
		public BufferedImage backgroundImage;

		/**
		 * Button background info object.
		 * 
		 * @param isPaintedActive
		 *            Indicates whether the button is painted in active visual
		 *            state.
		 * @param backgroundImage
		 *            The button background image.
		 */
		public ButtonBackground(boolean isPaintedActive,
				BufferedImage backgroundImage) {
			this.isPaintedActive = isPaintedActive;
			this.backgroundImage = backgroundImage;
		}

	}

	/**
	 * Resets image maps (used when setting new theme).
	 * 
	 * @see SubstanceLookAndFeel#setCurrentTheme(String)
	 * @see SubstanceLookAndFeel#setCurrentTheme(SubstanceTheme)
	 */
	public static synchronized void reset() {
		pairwiseBackgrounds.clear();
	}

	/**
	 * Retrieves background image for the specified button in button pair (such
	 * as scrollbar arrows, for example).
	 * 
	 * @param button
	 *            Button.
	 * @param kind
	 *            Color scheme kind.
	 * @param painter
	 *            Gradient painter.
	 * @param width
	 *            Button width.
	 * @param height
	 *            Button height.
	 * @param side
	 *            Button orientation.
	 * @param toIgnoreOpenSides
	 *            If <code>true</code>, the open side setting (controlled by
	 *            the {@link SubstanceLookAndFeel#BUTTON_OPEN_SIDE_PROPERTY} is
	 *            ignored.
	 * @return Button background image.
	 */
	public static BufferedImage getPairwiseBackground(AbstractButton button,
			ColorSchemeKind kind, SubstanceGradientPainter painter, int width,
			int height, SubstanceConstants.Side side, boolean toIgnoreOpenSides) {
		if (SubstanceCoreUtilities.isButtonNeverPainted(button))
			return null;

		BufferedImage resultNonFlat = null;
		ComponentState state = ComponentState.getState(button.getModel(),
				button);
		// ComponentState.ColorSchemeKind kind = state.getColorSchemeKind();
		// boolean isPaintedActive = (kind == ColorSchemeKind.CURRENT);
		float cyclePos = state.getCycleCount();
		ControlBackgroundComposite controlComposite = SubstanceCoreUtilities
				.getControlBackgroundComposite(button);

		ColorScheme colorScheme = SubstanceCoreUtilities.getComponentTheme(
				button, kind, true).getColorScheme();
		ColorScheme colorScheme2 = colorScheme;
		FadeTracker fadeTracker = FadeTracker.getInstance();
		if (fadeTracker.isTracked(button, FadeKind.ROLLOVER)) {
			Composite defaultComposite = controlComposite
					.getBackgroundComposite(button, button.getParent(), -1,
							false);
			Composite activeComposite = controlComposite
					.getBackgroundComposite(button, button.getParent(), -1,
							true);

			boolean isActive = SubstanceCoreUtilities
					.isControlAlwaysPaintedActive(button, true);
			ColorScheme defaultScheme = SubstanceCoreUtilities
					.getDefaultScheme(button);
			if (state == ComponentState.DEFAULT) {
				// Came from rollover state
				colorScheme2 = SubstanceCoreUtilities.getActiveScheme(button);
				colorScheme = isActive ? colorScheme : defaultScheme;
				cyclePos = /* 10 - */fadeTracker.getFade10(button,
						FadeKind.ROLLOVER);
				// isPaintedActive = true;
			}
			if (state == ComponentState.ROLLOVER_UNSELECTED) {
				// Came from default state
				colorScheme2 = colorScheme;
				colorScheme = isActive ? colorScheme : defaultScheme;
				cyclePos = fadeTracker.getFade10(button, FadeKind.ROLLOVER);
				// isPaintedActive = true;
			}

			BufferedImage imageDefault = getPairwiseBackground(button, painter,
					width, height, side, cyclePos, colorScheme, colorScheme2,
					defaultComposite, toIgnoreOpenSides);
			BufferedImage imageActive = getPairwiseBackground(button, painter,
					width, height, side, cyclePos, colorScheme, colorScheme2,
					activeComposite, toIgnoreOpenSides);
			if (imageDefault == null)
				return null;
			Graphics2D graphics = (Graphics2D) imageDefault.createGraphics();
			graphics.setComposite(AlphaComposite.getInstance(
					AlphaComposite.SRC_OVER, cyclePos / 10.0f));
			// System.out.println("Painting [" + colorScheme + "-->"
			// + colorScheme2 + "]" + cyclePos / 10.0f);
			graphics.drawImage(imageActive, 0, 0, null);
			resultNonFlat = imageDefault;
		} else {
			Composite graphicsComposite = controlComposite
					.getBackgroundComposite(
							button,
							button.getParent(),
							0,
							(ComponentState.getState(button.getModel(), null)
									.getColorSchemeKind() == ColorSchemeKind.CURRENT));
			resultNonFlat = getPairwiseBackground(button, painter, width,
					height, side, cyclePos, colorScheme, colorScheme2,
					graphicsComposite, toIgnoreOpenSides);
		}

		BufferedImage result = SubstanceCoreUtilities.getBlankImage(width,
				height);
		Graphics2D resultGr = (Graphics2D) result.createGraphics();
		if (SubstanceCoreUtilities.hasFlatProperty(button.getParent())) {
			// Special handling of flat buttons
			BufferedImage temp = SubstanceCoreUtilities.getBlankImage(
					resultNonFlat.getWidth(), resultNonFlat.getHeight());
			Graphics2D tempGr = (Graphics2D) temp.createGraphics();
			try {
				if (FadeTracker.getInstance().isTracked(button,
						FadeKind.ROLLOVER)
						&& !state.isSelected() && state.isEnabled()) {
					float fadeCoef = FadeTracker.getInstance().getFade10(
							button, FadeKind.ROLLOVER);
					tempGr.setComposite(AlphaComposite.getInstance(
							AlphaComposite.SRC_OVER, fadeCoef / 10.0f));
					tempGr.drawImage(resultNonFlat, 0, 0, null);
				} else {
					// // if (state == ComponentState.DEFAULT)
					// // return;
					// }
					if ((state != ComponentState.DISABLED_UNSELECTED)
							&& (state != ComponentState.DEFAULT)) {
						tempGr.drawImage(resultNonFlat, 0, 0, null);
						// graphics.drawImage(temp, 0, y, null);
					}
				}
				resultGr.drawImage(temp, 0, 0, null);
			} finally {
				tempGr.dispose();
			}
		} else {
			resultGr.drawImage(resultNonFlat, 0, 0, null);
		}
		return result;
	}

	/**
	 * Retrieves background image for the specified button in button pair (such
	 * as scrollbar arrows, for example).
	 * 
	 * @param button
	 *            Button.
	 * @param kind
	 *            Color scheme kind.
	 * @param painter
	 *            Gradient painter.
	 * @param width
	 *            Button width.
	 * @param height
	 *            Button height.
	 * @param side
	 *            Button orientation.
	 * @param cyclePos
	 *            Cycle position.
	 * @param colorScheme
	 *            The first color scheme.
	 * @param colorScheme2
	 *            The second color scheme.
	 * @param graphicsComposite
	 *            Composite to apply before painting the button.
	 * @param toIgnoreOpenSides
	 *            If <code>true</code>, the open side setting (controlled by
	 *            the {@link SubstanceLookAndFeel#BUTTON_OPEN_SIDE_PROPERTY} is
	 *            ignored.
	 * @return Button background image.
	 */
	private synchronized static BufferedImage getPairwiseBackground(
			AbstractButton button, SubstanceGradientPainter painter, int width,
			int height, SubstanceConstants.Side side, float cyclePos,
			ColorScheme colorScheme, ColorScheme colorScheme2,
			Composite graphicsComposite, boolean toIgnoreOpenSides) {
		if (SubstanceCoreUtilities.isButtonNeverPainted(button))
			return null;
		Set<Side> openSides = toIgnoreOpenSides ? new HashSet<Side>()
				: SubstanceCoreUtilities.getSides(button,
						SubstanceLookAndFeel.BUTTON_OPEN_SIDE_PROPERTY);
		String openKey = "";
		for (Side oSide : openSides) {
			openKey += oSide.name() + "-";
		}
		String sideKey = (side == null) ? "null" : side.toString();
		String key = width + ":" + height + ":" + sideKey + ":" + cyclePos
				+ ":" + openKey + ":"
				+ SubstanceCoreUtilities.getSchemeId(colorScheme) + ":"
				+ SubstanceCoreUtilities.getSchemeId(colorScheme2) + ":"
				+ button.getClass().getName() + ":" + painter.getDisplayName();
		if (!pairwiseBackgrounds.containsKey(key)) {
			BufferedImage newBackground = null;

			// buttons will be rectangular to make two scrolls (horizontal
			// and vertical) touch the corners.
			int radius = 0;

			int deltaLeft = openSides.contains(Side.LEFT) ? 3 : 0;
			int deltaRight = openSides.contains(Side.RIGHT) ? 3 : 0;
			int deltaTop = openSides.contains(Side.TOP) ? 3 : 0;
			int deltaBottom = openSides.contains(Side.BOTTOM) ? 3 : 0;

			GeneralPath contour = null;

			// SubstanceGradientPainter painter = new StandardGradientPainter();

			if (side != null) {
				switch (side) {
				case TOP:
				case BOTTOM:
					// arrow in vertical bar
					contour = BaseButtonShaper.getBaseOutline(height + deltaTop
							+ deltaBottom, width + deltaLeft + deltaRight,
							radius, null);

					newBackground = painter.getContourBackground(height
							+ deltaTop + deltaBottom, width + deltaLeft
							+ deltaRight, contour, false, colorScheme,
							colorScheme2, cyclePos, true,
							colorScheme != colorScheme2);
					newBackground = SubstanceImageCreator.getRotated(
							newBackground, 3);
					break;
				case RIGHT:
				case LEFT:
					// arrow in horizontal bar
					contour = BaseButtonShaper.getBaseOutline(width + deltaLeft
							+ deltaRight, height + deltaTop + deltaBottom,
							radius, null);

					newBackground = painter.getContourBackground(width
							+ deltaLeft + deltaRight, height + deltaTop
							+ deltaBottom, contour, false, colorScheme,
							colorScheme2, cyclePos, true,
							colorScheme != colorScheme2);
					break;
				}
			} else {
				contour = BaseButtonShaper.getBaseOutline(width + deltaLeft
						+ deltaRight, height + deltaTop + deltaBottom, radius,
						null);

				newBackground = painter.getContourBackground(width + deltaLeft
						+ deltaRight, height + deltaTop + deltaBottom, contour,
						false, colorScheme, colorScheme2, cyclePos, true,
						colorScheme != colorScheme2);
			}

			BufferedImage finalBackground = SubstanceCoreUtilities
					.getBlankImage(width, height);
			Graphics2D finalGraphics = (Graphics2D) finalBackground
					.getGraphics();
			finalGraphics.drawImage(newBackground, -deltaLeft, -deltaTop, null);
			pairwiseBackgrounds.put(key, finalBackground);
		}
		BufferedImage opaque = pairwiseBackgrounds.get(key);
		BufferedImage result = SubstanceCoreUtilities.getBlankImage(opaque
				.getWidth(), opaque.getHeight());
		Graphics2D resultGr = (Graphics2D) result.createGraphics();
		resultGr.setComposite(graphicsComposite);
		resultGr.drawImage(opaque, 0, 0, null);
		resultGr.dispose();
		return result;
	}

	/**
	 * Simple constructor.
	 */
	public PairwiseButtonBackgroundDelegate() {
		super();
	}

	/**
	 * Updates background of the specified button.
	 * 
	 * @param g
	 *            Graphic context.
	 * @param button
	 *            Button to update.
	 * @param side
	 *            Button side.
	 */
	public static void updateBackground(Graphics g, AbstractButton button,
			SubstanceConstants.Side side) {
		Graphics2D graphics = (Graphics2D) g.create();
		SubstanceGradientPainter painter = SubstanceCoreUtilities
				.getGradientPainter(button);
		int width = button.getWidth();
		int height = button.getHeight();
		// BufferedImage result = SubstanceCoreUtilities.getBlankImage(width,
		// height);
		// Graphics2D resultGr = (Graphics2D) result.createGraphics();

		try {
			int y = 0;

			// ControlBackgroundComposite composite = SubstanceCoreUtilities
			// .getControlBackgroundComposite(button);
			// Container parent = button.getParent();
			// // boolean hasOverlay = false;
			// if (parent instanceof JScrollBar) {
			// Container gp = parent.getParent();
			// if (gp instanceof JScrollPane) {
			// JScrollPane jsp = (JScrollPane) gp;
			// if (SubstanceCoreUtilities.hasOverlayProperty(jsp)) {
			// // hasOverlay = true;
			// JViewport viewport = jsp.getViewport();
			// int dx = -viewport.getX() + viewport.getViewRect().x
			// + button.getX() + parent.getX();
			// //
			// // button.getLocationOnScreen().x
			// // + viewport.getViewRect().x
			// // - viewport.getLocationOnScreen().x;
			// int dy = button.getY() + viewport.getViewRect().y
			// + parent.getY() - viewport.getY();
			// //
			// // button.getLocationOnScreen().y
			// // + viewport.getViewRect().y
			// // - viewport.getLocationOnScreen().y;
			// resultGr.translate(-dx, -dy);
			// JComponent view = (JComponent) viewport.getView();
			// boolean wasDb = view.isDoubleBuffered();
			// view.setDoubleBuffered(false);
			// view.paint(resultGr);
			// view.setDoubleBuffered(wasDb);
			// resultGr.translate(dx, dy);
			// }
			// }
			// }

			ComponentState state = ComponentState.getState(button.getModel(),
					button);
			painter = new SimplisticSoftBorderReverseGradientPainter();
			ComponentState.ColorSchemeKind kind = state.getColorSchemeKind();
			BufferedImage bgImage = getPairwiseBackground(button, kind,
					painter, width, height, side, false);
			// resultGr.drawImage(bgImage, 0, 0, null);
			graphics.drawImage(bgImage, 0, y, null);
			return;
		} finally {
			// resultGr.dispose();
			graphics.dispose();
		}
	}
}
