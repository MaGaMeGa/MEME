/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.view.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Ellipse2D;
import java.util.Hashtable;

public class DefaultFigureRenderer implements IFigureRenderer {
	
	//====================================================================================================
	// members
	
	public static final int DEFAULT = -1;
	public static final int CIRCLE = 1;
	public static final int RECTANGLE = 2;
	public static final int TRIANGLE = 3;
	
	private Hashtable<Double,Integer> map = new Hashtable<Double,Integer>();
	
	protected Color color = Color.black;
	protected Color backgroundColor = Color.white;
	
	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public DefaultFigureRenderer() {}
	
	//----------------------------------------------------------------------------------------------------
	public DefaultFigureRenderer(double[] values, int[] figures) {
		if (values.length != figures.length)
			throw new IllegalArgumentException();
		
		for (int i=0; i<values.length; i++) {
			//System.out.println("DefaultFigureRenderer: " + values[i] + " " + figures[i]);
			map.put(values[i],figures[i]);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public Color getBackgroundColor() { return backgroundColor; }
	public Color getColor() { return color; }
	public Hashtable<Double,Integer> getMap() {	return map; }
	
	//----------------------------------------------------------------------------------------------------
	public void setColor(Color color) { this.color = color; }
	public void setBackgroundColor(Color color) { this.backgroundColor = color; }
	
	//----------------------------------------------------------------------------------------------------
	public void addFigure(double value, int figure) {
		map.put(value,figure);		
	}
	
	//====================================================================================================
	// implemented interfaces
	
	//----------------------------------------------------------------------------------------------------
	public void render(Graphics2D g2d, Rectangle2D figureArea, double value) {
		int figure = getFigure(value);
		//System.out.println("render: " + value +" "+ figure);
				
		switch (figure) {
			case CIRCLE:
				renderCircle(g2d,figureArea);
				break;
				
			case RECTANGLE:
				renderRectangle(g2d,figureArea);
				break;
				
			case TRIANGLE:
				renderTriangle(g2d,figureArea);
				break;
				
			case DEFAULT:
				break;
		}
	}

	//----------------------------------------------------------------------------------------------------
	public String getName() { return "Default renderer"; }	
	
	//====================================================================================================
	// private methods
	
	//----------------------------------------------------------------------------------------------------
	protected int getFigure(double value) {
		Integer figure = map.get(value);
		if (figure != null)
			return figure;
		else 
			return DEFAULT;
	}
	
	//----------------------------------------------------------------------------------------------------
	protected void renderCircle(Graphics2D g2d, Rectangle2D area) {
		final double width = area.getWidth();
		final double height = area.getHeight();
		
		final double x = area.getX();
		final double y = area.getY();
		
		Ellipse2D.Double arc = new Ellipse2D.Double(x + width*0.2, y+height*0.2, width*0.6, height*0.6);
		 
//		Ellipse2D.Double arc2 = new Ellipse2D.Double(x + width*0.35, y+height*0.35, width*0.3, height*0.3);

		g2d.setPaint(color);
		g2d.setStroke(new BasicStroke((float)(width*0.15)));
		g2d.draw(arc);
		
//		g2d.setPaint(backgroundColor);
//		g2d.fill(arc2);
	}
	
	//----------------------------------------------------------------------------------------------------
	protected void renderRectangle(Graphics2D g2d, Rectangle2D area) {
		final double width = area.getWidth();
		final double height = area.getHeight();
		
		final double x = area.getX();
		final double y = area.getY();
		
		Rectangle2D.Double rect = new Rectangle2D.Double(x + width*0.2, y+height*0.2, width*0.6, height*0.6);
		
//		Rectangle2D.Double rect2 = new Rectangle2D.Double(x + width*0.35, y+height*0.35, width*0.3, height*0.3);
		
		g2d.setPaint(color);
		g2d.setStroke(new BasicStroke((float)(width*0.15)));
		g2d.draw(rect);
		
//		g2d.setPaint(backgroundColor);
//		g2d.fill(rect2);
	}	
	
	//----------------------------------------------------------------------------------------------------
	protected void renderTriangle(Graphics2D g2d, Rectangle2D area) {
		final double width = area.getWidth();
		final double height = area.getHeight();
		
		final double x = area.getX();
		final double y = area.getY();
		
		Polygon tri = new Polygon();
		tri.addPoint((int)(x+width*0.5), (int)(y+height*0.2));
		tri.addPoint((int)(x+width*0.2), (int)(y+height*0.8));
		tri.addPoint((int)(x+width*0.8), (int)(y+height*0.8));
		
//		Polygon tri2 = new Polygon();
//		tri2.addPoint((int)(x+width*0.5), (int)(y+height*0.40));
//		tri2.addPoint((int)(x+width*0.35), (int)(y+height*0.70));
//		tri2.addPoint((int)(x+width*0.65), (int)(y+height*0.70));		
				
		g2d.setPaint(color);
		g2d.setStroke(new BasicStroke((float)(width*0.15)));
		g2d.draw(tri);
		
//		g2d.setPaint(backgroundColor);
//		g2d.fill(tri2);
	}		
}