/** Display for networks, graphs and subgraphs. */
package ai.aitia.chart.networkpanel;