/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicListUI;

import org.jvnet.lafwidget.LafWidgetUtilities;
import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.lafwidget.utils.FadeTracker.FadeTrackerCallback;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * UI for lists in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceListUI extends BasicListUI {
	/**
	 * Name for the internal client property that holds the list of currently
	 * selected indices.
	 */
	public static String SELECTED_INDICES = "substancelaf.internal.listSelectedIndices";

	/**
	 * Name for the internal client property that holds the currently
	 * rolled-over index.
	 */
	public static String ROLLED_OVER_INDEX = "substancelaf.internal.listRolledOverIndex";

	/**
	 * Property listener that listens to the
	 * {@link SubstanceLookAndFeel#WATERMARK_TO_BLEED} property.
	 */
	protected PropertyChangeListener substancePropertyChangeListener;

	/**
	 * Local cache of JList's client property "List.isFileList"
	 */
	protected boolean isFileList;

	/**
	 * Local cache of JList's component orientation property
	 */
	protected boolean isLeftToRight;

	/**
	 * Delegate for painting the background.
	 */
	private static SubstanceGradientBackgroundDelegate backgroundDelegate = new SubstanceGradientBackgroundDelegate();

	/**
	 * Listener for fade animations on list selections.
	 */
	protected ListSelectionListener substanceFadeSelectionListener;

	/**
	 * Listener for fade animations on list rollovers.
	 */
	protected RolloverFadeListener substanceFadeRolloverListener;

	/**
	 * Listener for fade animations on list rollovers.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private class RolloverFadeListener implements MouseListener,
			MouseMotionListener {
		public void mouseClicked(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mousePressed(MouseEvent e) {
		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
			// if (SubstanceCoreUtilities.toBleedWatermark(list))
			// return;

			this.fadeOut();
			// System.out.println("Nulling RO index");
			list.putClientProperty(ROLLED_OVER_INDEX, null);
		}

		public void mouseMoved(MouseEvent e) {
			// if (SubstanceCoreUtilities.toBleedWatermark(list))
			// return;
			if (!list.isEnabled())
				return;
			handleMove(e);
		}

		public void mouseDragged(MouseEvent e) {
			// if (SubstanceCoreUtilities.toBleedWatermark(list))
			// return;

			if (!list.isEnabled())
				return;
			handleMove(e);
		}

		/**
		 * Handles various mouse move events and initiates the fade animation if
		 * necessary.
		 * 
		 * @param e
		 *            Mouse event.
		 */
		private void handleMove(MouseEvent e) {
			int roIndex = list.locationToIndex(e.getPoint());
			if ((roIndex < 0) || (roIndex >= list.getModel().getSize())) {
				this.fadeOut();
				// System.out.println("Nulling RO index");
				list.putClientProperty(ROLLED_OVER_INDEX, null);
			} else {
				// check if this is the same index
				Integer currRoIndex = (Integer) list
						.getClientProperty(ROLLED_OVER_INDEX);
				if ((currRoIndex != null) && (currRoIndex == roIndex))
					return;

				this.fadeOut();
				FadeTracker.getInstance().trackFadeIn(
						FadeKind.ROLLOVER,
						SubstanceListUI.this.list,
						roIndex,
						false,
						new CellRepaintCallback(SubstanceListUI.this.list,
								roIndex));
				// System.out.println("Setting RO index to " + roIndex);
				list.putClientProperty(ROLLED_OVER_INDEX, roIndex);
			}
		}

		/**
		 * Initiates the fade out effect.
		 */
		private void fadeOut() {
			Integer prevRoIndex = (Integer) list
					.getClientProperty(ROLLED_OVER_INDEX);
			if (prevRoIndex == null)
				return;

			FadeTracker.getInstance().trackFadeOut(
					FadeKind.ROLLOVER,
					SubstanceListUI.this.list,
					prevRoIndex,
					false,
					new CellRepaintCallback(SubstanceListUI.this.list,
							prevRoIndex));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent list) {
		return new SubstanceListUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicListUI#installDefaults()
	 */
	@Override
	protected void installDefaults() {
		super.installDefaults();
		this.isFileList = Boolean.TRUE.equals(this.list
				.getClientProperty("List.isFileList"));
		this.isLeftToRight = this.list.getComponentOrientation()
				.isLeftToRight();

		if (SubstanceCoreUtilities.toBleedWatermark(list)) {
			this.list.setOpaque(false);
		}

		Map<Integer, Object> selected = new HashMap<Integer, Object>();
		for (int i = 0; i < this.list.getModel().getSize(); i++)
			if (this.list.isSelectedIndex(i))
				selected.put(i, this.list.getModel().getElementAt(i));
		this.list.putClientProperty(SubstanceListUI.SELECTED_INDICES, selected);
	}

	@Override
	protected void uninstallDefaults() {
		this.list.putClientProperty(SubstanceListUI.SELECTED_INDICES, null);

		super.uninstallDefaults();
	}

	/**
	 * Repaints a single cell during the fade animation cycle.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class CellRepaintCallback implements FadeTrackerCallback {
		/**
		 * Associated list.
		 */
		protected JList list;

		/**
		 * Associated (animated) cell index.
		 */
		protected int cellIndex;

		/**
		 * Creates a new animation repaint callback.
		 * 
		 * @param list
		 *            Associated list.
		 * @param tabIndex
		 *            Associated (animated) cell index.
		 */
		public CellRepaintCallback(JList list, int tabIndex) {
			this.list = list;
			this.cellIndex = tabIndex;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadeEnded(org.jvnet.lafwidget.utils.FadeTracker.FadeKind)
		 */
		public void fadeEnded(FadeKind fadeKind) {
			this.repaintCell();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadePerformed(org.jvnet.lafwidget.utils.FadeTracker.FadeKind,
		 *      float)
		 */
		public void fadePerformed(FadeKind fadeKind, float fade10) {
			this.repaintCell();
		}

		/**
		 * Repaints the associated cell.
		 */
		private void repaintCell() {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					if (SubstanceListUI.this.list == null) {
						// may happen if the LAF was switched in the meantime
						return;
					}
					SubstanceListUI.this.maybeUpdateLayoutState();
					int cellCount = CellRepaintCallback.this.list.getModel()
							.getSize();
					if ((cellCount > 0)
							&& (CellRepaintCallback.this.cellIndex < cellCount)) {
						// need to retrieve the cell rectangle since the cells
						// can be moved while animating
						Rectangle rect = SubstanceListUI.this.getCellBounds(
								CellRepaintCallback.this.list,
								CellRepaintCallback.this.cellIndex,
								CellRepaintCallback.this.cellIndex);
						CellRepaintCallback.this.list.repaint(rect);
					}
				}
			});
		}
	}

	@Override
	protected void installListeners() {
		super.installListeners();

		// Add listener for the selection animation
		this.substanceFadeSelectionListener = new ListSelectionListener() {
			@SuppressWarnings("unchecked")
			public void valueChanged(ListSelectionEvent e) {
				// optimization on large lists and large selections
				if (LafWidgetUtilities.hasNoFades(SubstanceListUI.this.list,
						FadeKind.SELECTION))
					return;

				// if (SubstanceCoreUtilities.toBleedWatermark(list))
				// return;

				Map<Integer, Object> currSelected = (Map<Integer, Object>) SubstanceListUI.this.list
						.getClientProperty(SubstanceListUI.SELECTED_INDICES);
				for (int i = e.getFirstIndex(); i <= e.getLastIndex(); i++) {
					if (i >= SubstanceListUI.this.list.getModel().getSize())
						continue;
					if (SubstanceListUI.this.list.isSelectedIndex(i)) {
						// check if was selected before
						if (!currSelected.containsKey(i)) {
							// start fading in
							// System.out.println("Fade in on index " + i);
							FadeTracker.getInstance().trackFadeIn(
									FadeKind.SELECTION,
									SubstanceListUI.this.list,
									i,
									false,
									new CellRepaintCallback(
											SubstanceListUI.this.list, i));
							currSelected.put(i, SubstanceListUI.this.list
									.getModel().getElementAt(i));
						}
					} else {
						// check if was selected before and still points to the
						// same element
						if (currSelected.containsKey(i)) {
							if (currSelected.get(i) == SubstanceListUI.this.list
									.getModel().getElementAt(i)) {
								// start fading out
								// System.out.println("Fade out on index " + i);
								FadeTracker.getInstance().trackFadeOut(
										FadeKind.SELECTION,
										SubstanceListUI.this.list,
										i,
										false,
										new CellRepaintCallback(
												SubstanceListUI.this.list, i));
							}
							currSelected.remove(i);
						}
					}
				}
			}
		};
		this.list.getSelectionModel().addListSelectionListener(
				this.substanceFadeSelectionListener);

		this.substanceFadeRolloverListener = new RolloverFadeListener();
		this.list.addMouseMotionListener(this.substanceFadeRolloverListener);
		this.list.addMouseListener(this.substanceFadeRolloverListener);

		this.substancePropertyChangeListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if (SubstanceLookAndFeel.WATERMARK_TO_BLEED.equals(evt
						.getPropertyName())) {
					list.setOpaque(!SubstanceCoreUtilities
							.toBleedWatermark(list));
				}
			}
		};
		this.list
				.addPropertyChangeListener(this.substancePropertyChangeListener);
	}

	@Override
	protected void uninstallListeners() {
		this.list.getSelectionModel().removeListSelectionListener(
				this.substanceFadeSelectionListener);
		this.substanceFadeSelectionListener = null;

		this.list.removeMouseMotionListener(this.substanceFadeRolloverListener);
		this.list.removeMouseListener(this.substanceFadeRolloverListener);
		this.substanceFadeRolloverListener = null;

		this.list
				.removePropertyChangeListener(this.substancePropertyChangeListener);
		this.substancePropertyChangeListener = null;

		super.uninstallListeners();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicListUI#paintCell(java.awt.Graphics, int,
	 *      java.awt.Rectangle, javax.swing.ListCellRenderer,
	 *      javax.swing.ListModel, javax.swing.ListSelectionModel, int)
	 */
	@Override
	protected void paintCell(Graphics g, int row, Rectangle rowBounds,
			ListCellRenderer cellRenderer, ListModel dataModel,
			ListSelectionModel selModel, int leadIndex) {
		Object value = dataModel.getElementAt(row);
		boolean cellHasFocus = this.list.hasFocus() && (row == leadIndex);
		boolean isSelected = selModel.isSelectedIndex(row);

		boolean isWatermarkBleed = SubstanceCoreUtilities
				.toBleedWatermark(list);

		Component rendererComponent = cellRenderer
				.getListCellRendererComponent(this.list, value, row,
						isSelected, cellHasFocus);

		int cx = rowBounds.x;
		int cy = rowBounds.y;
		int cw = rowBounds.width;
		int ch = rowBounds.height;

		if (this.isFileList) {
			// Shrink renderer to preferred size. This is mostly used on Windows
			// where selection is only shown around the file name, instead of
			// across the whole list cell.
			int w = Math
					.min(cw, rendererComponent.getPreferredSize().width + 4);
			if (!this.isLeftToRight) {
				cx += (cw - w);
			}
			cw = w;
		}

		// Check if we have selection animation (from 3.0)
		boolean isSelectedAnim = FadeTracker.getInstance().isTracked(this.list,
				row, FadeKind.SELECTION);
		boolean isRolloverAnim = FadeTracker.getInstance().isTracked(this.list,
				row, FadeKind.ROLLOVER);
		Integer currRoIndex = (Integer) list
				.getClientProperty(ROLLED_OVER_INDEX);
		boolean isRollover = ((currRoIndex != null) && (currRoIndex == row));

		Graphics2D g2d = (Graphics2D) g.create();
		g2d.setComposite(TransitionLayout.getAlphaComposite(this.list));
		if (!isWatermarkBleed) {
			g2d.setColor(rendererComponent.getBackground());
			g2d.fillRect(cx, cy, cw, ch);
		}
		float alphaForBackground = 0.0f;
		// Support for selection animations (from 3.0)
		if (isSelected || isSelectedAnim) {
			if (isSelectedAnim) {
				// set the alpha for selection animation
				float fadeCoef = FadeTracker.getInstance().getFade10(this.list,
						row, FadeKind.SELECTION);
				alphaForBackground = 0.7f * fadeCoef / 10.0f;
			} else {
				alphaForBackground = 0.7f;
			}
		}
		// Support for rollover animations (from 3.0)
		if (isRolloverAnim) {
			// set the alpha for rollover animation
			float fadeCoef = FadeTracker.getInstance().getFade10(this.list,
					row, FadeKind.ROLLOVER);
			alphaForBackground = Math.max(alphaForBackground,
					0.4f * fadeCoef / 10.0f);
		} else {
			if (isRollover) {
				// set the alpha for rollover animation
				alphaForBackground = Math.max(alphaForBackground, 0.4f);
			}
		}
		if (alphaForBackground > 0.0f) {
			g2d.setComposite(TransitionLayout.getAlphaComposite(this.list,
					alphaForBackground));
			SubstanceListUI.backgroundDelegate.update(g2d, rendererComponent,
					new Rectangle(cx, cy, cw, ch), SubstanceCoreUtilities
							.getTheme(this.list, true)
							.getHighlightBackgroundTheme(), true);
			g2d.setComposite(TransitionLayout.getAlphaComposite(this.list));
		}

		if (rendererComponent instanceof JComponent) {
			// Play with opaqueness to make our own gradient background
			// on selected elements to show.
			JComponent jRenderer = (JComponent) rendererComponent;
			synchronized (jRenderer) {
				boolean newOpaque = !(isSelected || isSelectedAnim
						|| isRollover || isRolloverAnim);
				if (SubstanceCoreUtilities.toBleedWatermark(list))
					newOpaque = false;

				Map<Component, Boolean> opacity = new HashMap<Component, Boolean>();
				// System.out.println("Pre-painting at index " + row + " [" +
				// value
				// + "] " + (rendererComponent.isOpaque() ? "opaque" :
				// "transparent")
				// + " with bg " + rendererComponent.getBackground());
				if (!newOpaque)
					SubstanceCoreUtilities.makeNonOpaque(jRenderer, opacity);
				// System.out.println("Painting at index " + row + " [" + value
				// + "] " + (newOpaque ? "opaque" : "transparent")
				// + " with bg " + rendererComponent.getBackground());
				this.rendererPane.paintComponent(g2d, rendererComponent,
						this.list, cx, cy, cw, ch, true);
				// System.out.println("Painting at index " + row + " [" + value
				// + "] " + (newOpaque ? "opaque" : "transparent")
				// + " with bg " + rendererComponent.getBackground());
				if (!newOpaque)
					SubstanceCoreUtilities.restoreOpaque(jRenderer, opacity);
				// System.out.println("Post-painting at index " + row + " [" +
				// value
				// + "] " + (rendererComponent.isOpaque() ? "opaque" :
				// "transparent")
				// + " with bg " + rendererComponent.getBackground());
			}
		} else {
			this.rendererPane.paintComponent(g2d, rendererComponent, this.list,
					cx, cy, cw, ch, true);
		}
		g2d.dispose();
	}
	//
	// /*
	// * (non-Javadoc)
	// *
	// * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics,
	// * javax.swing.JComponent)
	// */
	// @Override
	// public void update(Graphics g, JComponent c) {
	// if (!SubstanceCoreUtilities.toBleedWatermark(c))
	// super.update(g, c);
	// else
	// super.paint(g, c);
	// }
}
