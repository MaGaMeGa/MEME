package ai.aitia.visu.data;

public class DefaultGrid3DDataset_DiagramLayer extends DefaultGrid3DDataset{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3707998687919392595L;

	public DefaultGrid3DDataset_DiagramLayer(int column, int row) {
		super(column, row, 3);
	}

}
