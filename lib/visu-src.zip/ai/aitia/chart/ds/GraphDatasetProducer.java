/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.ds;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.jfree.data.general.Dataset;
import org.jfree.data.xy.XYSeries;

import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.data.DefaultGraphDataset;
import ai.aitia.visu.data.Grid2DDataset;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDatasetProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.ds.IXYSeriesProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.event.IDataChangeListener;
import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.impl.SparseDoubleMatrix2D;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;
import edu.uci.ics.jung.graph.impl.DirectedSparseGraph;
import edu.uci.ics.jung.graph.impl.SimpleSparseVertex;
import edu.uci.ics.jung.graph.impl.UndirectedSparseEdge;
import edu.uci.ics.jung.graph.impl.UndirectedSparseGraph;
import edu.uci.ics.jung.io.PajekNetReader;
import edu.uci.ics.jung.utils.UserData;

/** Dataset producer for networks. */
public class GraphDatasetProducer implements IDatasetProducer, 	IDataChangeListener {

	/** Time of the last update. */
	private long time;
	
	/** The dataset that this object produces. */
	private DefaultGraphDataset dataset = null;
	
	/** Object that contains the current edges of the graph. */
	private XYSeries edges = null;
	
	/** The current produced value for number of nodes or a constant value. */
	private int nrOfNodes = 0;
	
	/** Flag that determines whether the graph is directed or undirected. */
	private boolean directed = false;
	
	/** The array of labels of the nodes. */
	private Object[] labels = new Object[0];
	
	/** The color values of the nodes. */
	private List<Double> colors = null;
	
	private List<Vertex> vertices = new ArrayList<Vertex>();

	//	private boolean fromAdjacencyMatrix = false;
	private ISeriesProducer colorProducer = null;
	
	//==============================================================================
	// methods
	
	/** Constructor. The content of the list parameter must be the follow: <br>
	 *   - a producer for edges. One (x,y) pair describes an edge between node x
	 *     and node y.<br>
	 *   - an Integer value or a value producer for the number of nodes. If this
	 *     element is a constant value, it must be positive.<br>
	 *   - Optionally a producer for node labels
	 *   
	 * @param data list with contents described above
	 * @param directed directed or undirected graph?
	 * @param colors a producer for node colors. Can be null.
	 * @throws DataSourceException it throws this exception if the constant value
	 *         of number of nodes is invalid (non-positive) or if it cannot construct
	 *         the dataset from the input parameters.
	 */ 
	public GraphDatasetProducer(List<Object> data, boolean directed, ISeriesProducer colorProducer) throws DataSourceException {
		time = System.currentTimeMillis();
		if (data.size() < 2) throw new DataSourceException("Missing input parameters!");
		
		this.directed = directed;
		dataset = new DefaultGraphDataset();
		if (data.get(0) instanceof IXYSeriesProducer) {
			IXYSeriesProducer edge_producer = (IXYSeriesProducer)data.get(0);
			edge_producer.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid egde parameters!");
		if (data.get(1) instanceof Integer) {
			int num = ((Integer)data.get(1)).intValue();
			if (num <= 0)
				throw new DataSourceException("The number of nodes must be positive integer.");
			this.nrOfNodes = num;
		} else if (data.get(1) instanceof IValueProducer) {
			IValueProducer nrOfNodesProducer = (IValueProducer)data.get(1);
			nrOfNodesProducer.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid number of nodes parameter!");
		if (data.size() > 2 && data.get(2) instanceof IStringListProducer) {
			IStringListProducer label_producer = (IStringListProducer)data.get(2);
			label_producer.addDataChangeListener(this);
		}
		if (colorProducer != null)
			colorProducer.addDataChangeListener(this);
	}
	
	/** Constructor. The content of the list parameter must be the follow: <br>
	 *   - a producer for edges. One (x,y) pair describes an edge between node x
	 *     and node y.<br>
	 *   - an Integer value or a value producer for the number of nodes. If this
	 *     element is a constant value, it must be positive.<br>
	 *   - Optionally a producer for node labels
	 *   
	 * @param data list with contents described above
	 * @param directed directed or undirected graph?
	 * @throws DataSourceException it throws this exception if the constant value
	 *         of number of nodes is invalid (non-positive) or if it cannot construct
	 *         the dataset from the input parameters.
	 */ 
	public GraphDatasetProducer(List<Object> data, boolean directed) throws DataSourceException {
		this(data,directed,null);
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor. It loads graph from a Pajek file specified by <code>file</code>.
	 * 
	 * @param file a Pajek file (<code>null</code> is not permitted)
	 * @throws DataSourceException it throws this exception if <code>file</code> is 
	 *         <code>null</code> or unparseable as Pajek file.
	 */
	public GraphDatasetProducer(java.io.File file) throws DataSourceException {
		if (file == null)
			throw new DataSourceException("missing valid Pajek file");
		try {
			time = System.currentTimeMillis();
			FileReader reader = new FileReader(file);
			PajekNetReader pnReader = new PajekNetReader();
			Graph g = pnReader.load(reader);
			dataset = new DefaultGraphDataset(g);
		} catch (Exception e) {
			throw new DataSourceException("missing or invalid Pajek file");
		}
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor. It produces graphs from an adjacency matrix data source.
	 * @param matrix_producer producer for adjacency matrix
	 * @param colorProducer a producer for node colors. Can be null.
	 */
	public GraphDatasetProducer(IAdjacencyMatrixProducer matrix_producer, ISeriesProducer colorProducer) {
		time = System.currentTimeMillis();
//		this.fromAdjacencyMatrix = true;
		matrix_producer.addDataChangeListener(this);
		if (colorProducer != null)
//			colorProducer.addDataChangeListener(this);
			this.colorProducer = colorProducer;
		dataset = new DefaultGraphDataset();
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor. It produces graphs from an adjacency matrix data source.
	 * @param matrix_producer producer for adjacency matrix
	 */
	public GraphDatasetProducer(IAdjacencyMatrixProducer matrix_producer) {
		this(matrix_producer,null);
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the time of the last update.
	 * @return the time of the last update
	 */
	public long getTime() {
		return time;
	}

	//-------------------------------------------------------------------------------
	/** Produces the dataset. This implementation of the method does not use the <code>
	 *  queryProperties</code> parameter and does not throw exception.
	 */  
	public Dataset produceDataset(Properties queryProperties) throws DataSourceException {
		return dataset;
	}

	//-------------------------------------------------------------------------------
	/** Updates the dataset.<p>
	 *  If x or y is greater than or equal <code>nrOfNodes</code> 
	 *  in a pair produced by <code>edge_producer</code>, it will be ignored. All
	 *  parallel edges, except the first one, will be ingnored, too.  If the size of
	 *  the list produced by label producer is lesser than <code>nrOfNodes</code> the
	 *  remaining nodes will have empty label.<p>
	 *  If the dataset created from a matrix producer and the created matrix is not a
	 *  square matrix the method uses its largest square submatrix as adjacency matrix
	 *  of the graph.
	 * @param event event 
	 */
	public void dataChanged(DataChangeEvent event) {
		Object source = event.getSource();
		if (source instanceof IXYSeriesProducer) {
			IXYSeriesProducer edge_producer = (IXYSeriesProducer)source;
			edges = edge_producer.produceSeries();
			time = edge_producer.getTime();
		} else if (source instanceof IStringListProducer) {
			IStringListProducer label_producer = (IStringListProducer)source;
			List<String> obj = label_producer.produceStringList();
			labels = ((List)obj).toArray();
			time = label_producer.getTime();
		} else if (source instanceof IValueProducer) {
			IValueProducer nrOfNodes_producer = (IValueProducer)source;
			nrOfNodes = Math.abs((int)nrOfNodes_producer.produceValue()); // get absolute value to avoid negative values
			time = nrOfNodes_producer.getTime();
		} else if (source instanceof ISeriesProducer) {
			ISeriesProducer colorProducer = (ISeriesProducer) source;
			colors = colorProducer.produceSeries();
			time = colorProducer.getTime();
//			if (fromAdjacencyMatrix) return;
		} else if (source instanceof IAdjacencyMatrixProducer) {
			IAdjacencyMatrixProducer matrix_producer = (IAdjacencyMatrixProducer)source;
			try {
				Grid2DDataset gds = (Grid2DDataset)matrix_producer.produceDataset(null);
				DoubleMatrix2D matrix = new SparseDoubleMatrix2D(gds.getValues());
				if (gds.getWidth() != gds.getHeight()) {
					int less = Math.min(gds.getWidth(),gds.getHeight());
					matrix = matrix.viewPart(0,0,less,less);
				}
				Graph g = Utilities.matrixToGraph(matrix,vertices);
				if (colorProducer != null)
					colors = colorProducer.produceSeries();
				if (colors != null) {
					for (int i = 0;i < vertices.size();++i) {
						if (colors.size() > i)
							vertices.get(i).addUserDatum("COLOR_ID",colors.get(i),UserData.SHARED);
					}
				}
				dataset.setGraph(g);
				time = matrix_producer.getTime();
			} catch (DataSourceException e) {
				// wrong dataset => no update
			}
			return;
		}
		if (edges == null) return;
		Graph graph = null;
		if (directed) graph = new DirectedSparseGraph();
		else graph = new UndirectedSparseGraph();
		Vertex[] nodes = new SimpleSparseVertex[nrOfNodes];
		for (int i=0;i<nrOfNodes;++i) {
			nodes[i] = new SimpleSparseVertex();
			nodes[i].addUserDatum("id",new Integer(i),UserData.SHARED);
			if (labels.length > i) nodes[i].addUserDatum("label",labels[i].toString(),UserData.SHARED);
			else nodes[i].addUserDatum("label"," ",UserData.SHARED);
			if (colors != null && colors.size() > i)
				nodes[i].addUserDatum("COLOR_ID",colors.get(i),UserData.SHARED);
			graph.addVertex(nodes[i]);
		}
		for (int i=0;i<edges.getItemCount();++i) {
			Edge edge = null;
			if (edges.getX(i).intValue() < 0 || edges.getY(i).intValue() < 0)
				throw new IllegalStateException("Invalid node index value: it must be a non-negative integer.");
			if (edges.getX(i).intValue() >= nrOfNodes || edges.getY(i).intValue() >= nrOfNodes) continue;
			if (directed) edge = new DirectedSparseEdge(nodes[edges.getX(i).intValue()],nodes[edges.getY(i).intValue()]);
			else edge = new UndirectedSparseEdge(nodes[edges.getX(i).intValue()],nodes[edges.getY(i).intValue()]);
			Vertex from = (Vertex)edge.getEndpoints().getFirst();
			Vertex to = (Vertex)edge.getEndpoints().getSecond();
			if ((!directed && !from.isPredecessorOf(to) && !to.isPredecessorOf(from)) ||
				(directed && !from.isPredecessorOf(to))) graph.addEdge(edge);
		}
		dataset.setGraph(graph);
	}
	
	//------------------------------------------------------------------------------------
	// For the descendant classes
	protected GraphDatasetProducer() {}
}
