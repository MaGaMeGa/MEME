package ai.aitia.visu.view.plot;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.TexturePaint;
import java.awt.image.BufferedImage;

import org.jfree.chart.plot.DefaultDrawingSupplier;

public class TextureChartDrawingSupplier extends DefaultDrawingSupplier implements IBasicSupplier {

	private static final long serialVersionUID = 1L;

	private final static int TEXTURE_LINES = 0; 
	private final static int TEXTURE_VIRGULES = 1;
 	private final static int TEXTURE_DOTS = 2;
 	private final static int TEXTURE_GRID = 3;

	private Stroke modifiedStroke = null;
 	
	/** Constructor. */
	public TextureChartDrawingSupplier() {
		this(createDefaultPaintArray(),
			 DEFAULT_OUTLINE_PAINT_SEQUENCE,
			 DEFAULT_STROKE_SEQUENCE,
			 DEFAULT_OUTLINE_STROKE_SEQUENCE,
			 DEFAULT_SHAPE_SEQUENCE);
	}

	//-------------------------------------------------------------------------------
	/** Constructor.
     * @param paintSequence  the fill paint sequence.
     * @param outlinePaintSequence  the outline paint sequence.
     * @param strokeSequence  the stroke sequence.
     * @param outlineStrokeSequence  the outline stroke sequence.
     * @param shapeSequence  the shape sequence.
	 */
	public TextureChartDrawingSupplier(Paint[] paintSequence,
			Paint[] outlinePaintSequence, Stroke[] strokeSequence,
			Stroke[] outlineStrokeSequence, Shape[] shapeSequence) {
		super(paintSequence, outlinePaintSequence, strokeSequence,
				outlineStrokeSequence, shapeSequence);
	}

	//-------------------------------------------------------------------------------
    /**
     * Convenience method to return an array of <code>Paint</code> objects that
     * represent the black an grey colors. 
     * @return An array of objects with the <code>Paint</code> interface.
     */
 	public static Paint[] createDefaultPaintArray() {
        return new Paint[] { Color.BLACK,
        					 Color.LIGHT_GRAY,
        					 createTexture(Color.BLACK,TEXTURE_LINES),
				 			 createTexture(Color.LIGHT_GRAY,TEXTURE_LINES),
        					 createTexture(Color.BLACK,TEXTURE_VIRGULES),
        					 createTexture(Color.LIGHT_GRAY,TEXTURE_VIRGULES),
        					 createTexture(Color.BLACK,TEXTURE_DOTS),
        					 createTexture(Color.LIGHT_GRAY,TEXTURE_DOTS),
        					 createTexture(Color.BLACK,TEXTURE_GRID),
        					 createTexture(Color.LIGHT_GRAY,TEXTURE_GRID)
        				   };
	}
 	
 	//--------------------------------------------------------------------------------
 	public static TexturePaint createTexture(Color color, int type) {
 		BufferedImage bi  = new BufferedImage(10,10,BufferedImage.TYPE_INT_RGB);
 		Graphics2D big = bi.createGraphics();
 		big.setPaint(Color.WHITE);
 		big.fillRect(0,0,10,10);
 		big.setPaint(color);
 		switch (type) {
 		case TEXTURE_LINES 	  :
 			big.fillRect(0,5,10,5);
 			break;
 		case TEXTURE_VIRGULES :
 			big.fillPolygon(new int[] {0,0,5}, 
 							new int[] {0,5,0},
 							3);
 			big.fillPolygon(new int[] {1,5,10,10},
 							new int[] {10,10,5,1},
 							4);
 			big.setPaint(Color.WHITE);
 			big.fillRect(0,0,1,1);
 			break;
 		case TEXTURE_DOTS	  :
 			big.fillOval(1,1,4,4);
 			big.fillOval(6,1,4,4);
 			big.fillOval(1,6,4,4);
 			big.fillOval(6,6,4,4);
			break;
 		case TEXTURE_GRID	  :
 		    big.drawLine(0,0,9,0);
 		    big.drawLine(0,5,9,5);
 		    big.drawLine(0,0,0,9);
 		    big.drawLine(5,0,5,9);
		}
 		Rectangle r = new Rectangle(0,0,10,10);
 		return new TexturePaint(bi,r);
 	}

 	//------------------------------------------------------------------------------
	public void setThinLines() {
		this.modifiedStroke = new BasicStroke(0.5f,BasicStroke.CAP_SQUARE,BasicStroke.JOIN_BEVEL);
	}
	
	//------------------------------------------------------------------------------
	@Override
	public Stroke getNextStroke() {
		if (this.modifiedStroke != null) return this.modifiedStroke;
		return super.getNextStroke();
	}
}
