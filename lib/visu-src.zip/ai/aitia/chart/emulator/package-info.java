/** This assistant package provides tool to emulate a data source with one or more
 *  another.
 */
package ai.aitia.chart.emulator;