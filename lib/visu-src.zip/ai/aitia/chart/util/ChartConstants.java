/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.util;

/** Constants for the charting package. */
public class ChartConstants {
	
	/** For Grid3D meta */
	
	public static final String BACKGROUND_FILE				= "Background File";
	
	public static final String SHOW_COLORBAR			= "Show Colorbar";
	
	public static final String SHOW_AXIS				= "Show Axis";
	
	public static final String PADDING					= "Padding";
	
	public static final String TRANSLATE				= "Translate";
	
	public static final String RADIUS					= "Radius";
	
	public static final String SHOW_BASE				= "Show Base";
	
	// chart ids
	
	/** Type id of the three-dimensional grids. */
	public static final String GRID3D					= "Grid3D";
	
	/** Type id of the bar charts. */
	public static final String BARCHART					= "BarChart";
	
	/** Type id of the two-dimensional composite grids. */
	@Deprecated
	public static final String COMPOSITEGRID2D			= "CompositeGrid2D";
	
	/** Type id of the two-dimensional grids. */
	public static final String GRID2D					= "Grid2D";
	
	/** Type id of the two-dimensional composite grids. */
	public static final String MULTIGRID2D				= "MultiGrid2D";
	
	/** Type id of the histograms. */
	public static final String HISTOGRAM				= "Histogram";
	
	/** Type id of the multihistograms. */
	public static final String MULTI_HISTOGRAM				= "MultiHistogram";
	
	/** Type id of the area-based diagrams. */
	public static final String RECTANGLEAREACHART		= "RectangleAreaChart";
	
	/** Type id of the scatter plots. */
	public static final String SCATTERPLOT				= "ScatterPlot";

	/** Type id of the matrix of scatterplots charts. */
	public static final String MATRIXOFSCATTERPLOTS				= "MatrixOfScatterPlots";
	
	/** Type id of the box plots. */
	public static final String BOXPLOT				= "BoxPlot";
	
	/** Type id of the two-dimensional grids with shapes. */
	public static final String SHAPEGRID2D				= "ShapeGrid2D";
	
	/** Type id of the time series. */
	public static final String TIMESERIES				= "TimeSeries";
	
	/** Type id of the time series with real time. */
	public static final String REALTIMESERIES			= "RealTimeSeries";
	
	/** Type id of the XY line charts. */
	public static final String XYLINECHART				= "XYLineChart";
	
	/** Type id of the networks/graphs. */
	public static final String NETWORK					= "Network";
	
	/** Type id of the interactive (sub)graphs. */
	public static final String SUBGRAPH					= "Subgraph";
	
	/** Type id of the sequences. */
	public static final String SEQUENCE					= "Sequence";
	
	/** Type id of the pie charts. */
	public static final String PIECHART					= "PieChart";
	
	/** Type id of the radviz charts. */
	public static final String RADVIZ					= "RadViz";
	
	public static final String ONEDSERIES					= "OneDSeries";
	
	
	// chart names
	
	/** Displayable name of the two-dimensional grid type. */
	public static final String GRID3D_NAME				= "3D Grid";
	
	/** Displayable name of the bar chart type. */
	public static final String BARCHART_NAME			= "Bar Chart";
	
	/** Displayable name of the two-dimensional composite grid type. */
	@Deprecated
	public static final String COMPOSITEGRID2D_NAME		= "Composite 2D Grid";
	
	/** Displayable name of the two-dimensional grid type. */
	public static final String GRID2D_NAME				= "2D Grid";
	
	/** Displayable name of the two-dimensional composite grid type. */
	public static final String MULTIGRID2D_NAME			= "Composite 2D Grid";
	
	/** Displayable name of the histogram type. */
	public static final String HISTOGRAM_NAME			= "Histogram";
	
	/** Displayable name of the multihistograms. */
	public static final String MULTI_HISTOGRAM_NAME				= "MultiHistogram";
	
	/** Displayable name of the area-based diagram type. */
	public static final String RECTANGLEAREACHART_NAME	= "Rectangle Area Chart";
	
	/** Displayable name of the scatter plot type. */
	public static final String SCATTERPLOT_NAME			= "Scatter Plot";
	
	/** Displayable name of the matrix of scatterplots type. */
	public static final String MATRIXOFSCATTERPLOTS_NAME			= "MatrixOfScatterPlots";
	
	/** Displayable name of the box plot type. */
	public static final String BOXPLOT_NAME			= "Box Plot";
	
	/** Displayable name of the pie chart type. */
	public static final String PIECHART_NAME			= "Pie Chart";
	
	/** Displayable name of the two-dimensional grid with shapes type. */
	public static final String SHAPEGRID2D_NAME			= "2D Grid with Shapes";
	
	/** Displayable name of the time series type. */
	public static final String TIMESERIES_NAME			= "Time Series";
	
	/** Displayable name of the time series with real time type. */
	public static final String REALTIMESERIES_NAME		= "Time Series with real time";
	
	/** Displayable name of the XY line chart type. */
	public static final String XYLINECHART_NAME			= "XY Line Chart";
	
	/** Displayable name of the network/graph type. */
	public static final String NETWORK_NAME				= "Network";
	
	/** Displayable name of the interactive (sub)graph type. */
	public static final String SUBGRAPH_NAME			= "Interactive subgraph";
	
	/** Displayable name of the sequence type. */
	public static final String SEQUENCE_NAME			= "Sequence";
	
	/** Displayable name of the radviz type. */
	public static final String RADVIZ_NAME			= "RadViz";
	
	/** Displayable name of the D1Series type. */
	public static final String ONEDSERIES_NAME				= "One D Series";
	// property keys
	
	/** property key for Grid3D layer type */
	public static final String TYPE							= "Type";
	
	/** property key for Grid3D diagram layer type */
	public static final String DIAGRAM_LAYER				= "Diagram Layer";
	
	/** property key for Grid3D surface layer type */
	public static final String SURFACE_LAYER				= "Surface Layer";
	
	/** property key for Grid3D object layer type */
	public static final String OBJECT_LAYER					= "Object Layer";
	
	/** Property key for data sources of the charts. */
	public static final String DATASOURCE				= "datasource";

	/** Property key for title of the charts. */
	public static final String TITLE 					= "title";
	
	/** Property key for subtitle of the charts. */
	public static final String SUBTITLE					= "subtitle";
	
	/** Property key for label of the rows (used only by grids). */
	public static final String ROW_LABEL				= "row label";
	
	/** Property key for label of the columns (used only by grids). */
	public static final String COLUMN_LABEL				= "column label";
	
	/** Property key for label of the x-axis. */
	public static final String X_AXIS					= "x-axis";
	
	/** Property key for label of the y-axis. */
	public static final String Y_AXIS					= "y-axis";
	
	/** Property key for label of the time-axis (used only by time series). */
	public static final String TIME_AXIS				= "time-axis";
	
	/** Property key for label of the value-axis (used onyl by time series). */
	public static final String VALUE_AXIS				= "value-axis";
	
	/** Property key for scale type of the x-axis. */
	public static final String X_AXIS_SCALE				= "x-axis scale";
	
	/** Property key for scale type of the y-axis. */
	public static final String Y_AXIS_SCALE				= "y-axis scale";
	
	/** Property key for colorbar (whether is visible or not). */
	public static final String COLORBAR					= "colorbar";
	
	/** Property key for colormap. */
	public static final String COLORMAP					= "colormap";
	
	/** Property key: dynamic_node_color determines whether the color of
	 *  the node comes from a colormap or not (used only by graphs).
	 */
	public static final String DYNAMIC_NODE_COLOR		= "dynamic_node_color";
	
	/** Property key for color of the nodes (used only by graphs). */
	public static final String NODE_COLOR				= "node color";
	
	/** Property key for shape renderer. */
	public static final String SHAPE_RENDERER			= "shape renderer";
	
	/** Property key: user defined width determines whether the user defines a fix
	 *  width value or a producer instead (used only by grids). */
	public static final String USER_DEFINED_WIDTH		= "user defined width";
	
	/** Property key for width. It can be a fix value or a data source id
	 *  (used only by grids). */
	public static final String WIDTH					= "width";
	
	/** Property key: user defined height determines whether the user defines a fix
	 *  height value or a producer instead (used only by grids). */
	public static final String USER_DEFINED_HEIGHT		= "user_defined height";
	
	/** Property key for height. It can be a fix value or a data source id
	 *  (used only by grids). */
	public static final String HEIGHT					= "height";
	
	/** Property key for filling order (used only by grids in sequential mode). */
	public static final String ROW_ORDER				= "row order";
	
	/** Property key for lower bound of an interval (used only by histogram). */
	public static final String LOWER_BOUND				= "lower bound";
	
	/** Property key for upper bound of an interval (used only by histogram). */
	public static final String UPPER_BOUND				= "upper bound";
	
	public static final String RANGE_LOWER_BOUND		= "range lower bound";
	public static final String RANGE_UPPER_BOUND		= "range upper bound";
	
	/** Property key for number of bins/intervals (used only by histogram). */
	public static final String NR_OF_INTERVALS			= "nrOfIntervals";
	
	public static final String USER_DEFINED_LOWER_BOUND = "user defined lower bound";
	public static final String USER_DEFINED_UPPER_BOUND = "user defined upper bound";
	public static final String USER_DEFINED_NR_OF_INTERVALS = "user defined nrOfIntervals";
	public static final String USER_DEFINED_RANGE_LOWER_BOUND = "user defined range lower bound";
	public static final String USER_DEFINED_RANGE_UPPER_BOUND = "user defined range upper bound";
	
	/** Property key for strategy that determines how handling value outside the
	 *  interval (used only by histogram). */
	public static final String OUT_OF_BOUNDS_STRATEGY	= "outOfBoundsStrategy";
	
	/** Property key for title of the outliers list (used only by histogram). */
	public static final String OUTLIERS_TITLE			= "outliers title";
	
	/** Property key for bin mode (used only by histogram). */
	public static final String BIN_MODE					= "bin mode";
	
	/** Property key for number of the displayed items (used only by time series). */
	public static final String NR_OF_DISPLAYED_ITEMS	= "nrOfDisplayedItems";
	
	/** Property key for second vertical axis (whether be or not). */
	public static final String SECOND_VERTICAL_AXIS		= "2nd vertical axis";
	
	/** Property key for number of the nodes (used only by graphs). */
	public static final String NR_OF_NODES				= "nrOfNodes";
	
	/** Property key: user defined number determines whether the user defined a fix
	 *  node number or a producer instead (used only by graphs).
	 */
	public static final String USER_DEFINED_NUMBER		= "user defined number";
	
	/** Property key for Pajek file name (used only by networks). */
	public static final String PAJEK_FILE				= "Pajek file";
	
	/** Property key for layout of the graph (used only by networks). */
	public static final String LAYOUT					= "layout";
	
	/** Property key for repulsion attribute of the Fruchterman Reingold layout 
	 *  (used only by networks). */
	public static final String REPULSION				= "repulsion";
	
	/** Property key for attraction attribute of the Fruchterman Reingold layout
	 *  (used only by networks). */
	public static final String ATTRACTION				= "attraction";
	
	/** Property key for number of iterations of the iterated layouts (used only
	 *  by networks. */
	public static final String NR_OF_ITERATIONS				= "nrOfIterations";
	
	/** Property key for direction of the networks (whether is undirected or directed). */
	public static final String UNDIRECTED				= "undirected";
	
	/** Property key for displayind depth of the interactive graphs. */
	public static final String DEPTH					= "depth";
	
	/** Property key for index of the initial root node (used only by interactive
	 *  graphs). */
	public static final String ROOT_INDEX				= "rootIndex";
	
	/** Property key for element renderer (used only by sequence). */
	public static final String ELEMENT_RENDERER			= "element renderer";
	
	/** Property key for legend. */
	public static final String SHOW_LEGEND				= "show legend";
	
	/** Property key for labels. */
	public static final String SHOW_LABELS				= "show labels";
	
	/** Property key for color appearance. */
	public static final String COLOR_APPEARANCE			= "color appearance";
	
	/** Property key for environment appearance. */
	public static final String ENV_APPEARANCE			= "environment appearance";
	
	/** Property key for bar renderer (used only by bar chart). */
	public static final String BAR_RENDERER				= "bar renderer";
	
	/** Property key for category label angle (used only by bar chart). */
	public static final String CATEGORY_LABEL_ANGLE		= "label angle";
	
	/** Property key for short legend names (use only by xy line chart and scatter 
	 *  plot.
	 */
	public static final String SHORT_LEGEND_NAMES		= "short legend names";
	
	/** Property key for renderer type of an xy line chart (used only by xy line chart). */
	public static final String XYLINE_RENDERER			= "xy line renderer";
	
	/** Property key for the used custom appearance template. */
	public static final String CUSTOM_APPEARANCE		= "custom appearance";
	
	public static final String GLOBAL_ALPHA				= "global alpha";
	
	public static final String TOOLTIP					= "tooltip";
	
	// grid mode ids
	
	/** Id of the sequential mode (used only by grids). */
	public static final String FULL						= "FULL";

	/** Id of the random mode (used only by grids). */
	public static final String PARTIAL					= "PARTIAL";
	
	// colormap ids
	
	/** Id of the black-and-white colormap */
	public static final String BLACK_AND_WHITE_COLORMAP	= "BLACK_AND_WHITE";
	
	/** Id of the rainbow colormap. */
	public static final String RAINBOW					= "RAINBOW";

	/** Id of the heat colormap. */
	public static final String HEAT						= "HEAT";
	
	/** Id of the real colormap. */
	public static final String REAL						= "REAL";
	
	/** Id of the pastel colormap. */
	public static final String PASTEL					= "PASTEL";
	
	/** Id of the random colormap. */
	public static final String RANDOM					= "RANDOM";
	
	/** Id of the simple colormap. */
	public static final String SIMPLE					= "SIMPLE";
	
	/** Id of the table colormap. */
	public static final String TABLE					= "TABLE";
	
	/** Id of the constant colormap. */
	public static final String CONSTANT					= "CONSTANT";
		
	// colormap & shape renderer files property keys
	
	/** Property keys for default color. */
	public static final String DEFAULT_COLOR			= "DEFAULT_COLOR";
	public static final String NAME						= "NAME";
	
	// shape renderer ids
	
	/** Id of the automatic shape renderer. */
	public static final String AUTO						= "AUTO";
	
	/** Id of the user defined shape renderer. */
	public static final String DEFINED					= "DEFINED";
	
	/** Id of the custom shape renderer. */
	public static final String CUSTOM					= "CUSTOM";
	
	// histogram out of bounds strategies
	
	/** Id of the outliers strategy: it writes the value outside the interval
	 *  to the first and last bins (used only by histogram). */
	public static final String OUTLIERS_STRATEGY		= "OUTLIERS_STRATEGY";
	
	/** Id of the use strategy: it puts the value outside the interval
	 *  into a separate list (used only by histogram). */
	public static final String USE_STRATEGY				= "USE_STRATEGY";
	
	/** Id of the ignore strategy: it ignores the value outside the interval
	 *  (used only by histogram). */
	public static final String IGNORE_STRATEGY			= "IGNORE_STRATEGY";
	
	// scaling types
	
	/** Linear scaling type. */
	public static final String NORMAL					= "NORMAL";

	/** Logarithmic scaling type. */
	public static final String LOG						= "LOG";
	
	// appearance types
	
	/** Colored appearance. */
	public static final String COLORED					= "colored";
	
	/** Black-and-white appearance. */
	public static final String BLACK_AND_WHITE			= "black-and-white";
	
	/** Normal appearance. */
	public static final String NORMAL_APP				= "normal";
	
	/** Basic appearance. */
	public static final String BASIC_APP				= "basic";
	
	// bar renderer types
	
	/** Default bar renderer type : one bar per datarow per category. */
	public static final String ONE_BAR_PER_DATAROW		= "one bar per datarow";
	
	/** One bar per category. */
	public static final String ONE_BAR_PER_CATEGORY		= "one bar per category";
	
	/** One bar per category with percent axis. */
	public static final String ONE_BAR_PER_CATEGORY_P	= "one bar per category percentage";
	
	// templates (xml-node and attribute names/possibilities)
	
	public static final String TEMPLATES				= "templates";
	public static final String TEMPLATE					= "template";
	public static final String REF_ID_ATTR				= "refId";
	public static final String DIMENSION				= "dimension";
	public static final String TEMPLATE_WIDTH			= "width";
	public static final String TEMPLATE_HEIGHT			= "height";
	public static final String TEMPLATE_TITLE			= "title";
	public static final String SHOW_ATTR				= "show";
	public static final String FONT						= "font";
	public static final String COLOR					= "color";
	public static final String TEMPLATE_SUBTITLE		= "subtitle";
	public static final String BACKGROUND				= "background";
	public static final String BACKGROUND_TYPE			= "type";
	public static final String SIMPLE_BG_TYPE			= "simple";
	public static final String GRADIENT_BG_TYPE			= "gradient";
	public static final String START_COLOR				= "startColor";
	public static final String END_COLOR				= "endColor";
	public static final String DOMAIN_AXIS				= "domainAxis";
	public static final String TICK_LABELS				= "tickLabels";
	public static final String TICK_MARKS				= "tickMarks";
	public static final String INTERVAL					= "interval";
	public static final String AUTO_ATTR				= "auto";
	public static final String MIN_RANGE_VALUE			= "minRangeValue";
	public static final String MAX_RANGE_VALUE			= "maxRangeValue";
	public static final String RANGE_AXIS				= "rangeAxis";
	public static final String SERIES_LIST				= "seriesList";
	public static final String SERIES					= "series";
	public static final String SHAPE					= "shape";
	public static final String CUSTOM_ATTR				= "custom";
	public static final String THICKNESS				= "thickness";
	public static final String STYLE					= "style";
	public static final String SHAPE_SIZE					= "shapeSize";
	public static final String VERTEX_SIZE_PERCENTAGE					= "vertexSizePercentage";
	// xml-nodes
	
	public static final String GRID_LAYERS				= "grid_layers";
	public static final String GRID_LAYER				= "layer";
	
	public static final int DEFAULT_DATASOURCE_IDX		= -10;
	
	public static final String CONSTANT_COLOR_PRODUCER  = "CONSTANT_COLOR_PRODUCER";
	public static final String CONSTANT_COLOR_PRODUCER_COLOR = "COLOR";
}