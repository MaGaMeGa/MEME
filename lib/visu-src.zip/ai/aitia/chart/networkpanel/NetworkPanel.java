/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.networkpanel;

import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Composite;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSlider;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

import org.freehep.graphics2d.VectorGraphics;
import org.freehep.graphicsio.emf.EMFGraphics2D;
import org.freehep.graphicsio.ps.PSGraphics2D;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetChangeListener;
import org.jfree.ui.ExtensionFileFilter;

import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.ds.GraphDatasetProducer;
import ai.aitia.chart.view.meta.GraphMetadata;
import ai.aitia.chart.view.meta.SubgraphMetadata;
import ai.aitia.visu.data.DefaultGraphDataset;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.globalhandlers.GlobalHandlers;
import ai.aitia.visu.network.DefaultGraphSource;
import ai.aitia.visu.network.IGraphSource;
import ai.aitia.visu.network.SubGraphUtils;
import ai.aitia.visu.network.jung.layout.KK3dLayout;
import ai.aitia.visu.view.meta.Appearance;
import ai.aitia.visu.view.meta.CustomAppearance;
import ai.aitia.visu.view.plot.ColorMapUpdateOption;
import ai.aitia.visu.view.ui.BlackAndWhiteColorMap;
import ai.aitia.visu.view.ui.ColorMap;
import ai.aitia.visu.view.ui.ColorMapCollection;
import ai.aitia.visu.view.ui.RainbowColorMap;
import ai.aitia.visu.view.ui.SimpleColorMap;
import edu.uci.ics.jung.graph.ArchetypeVertex;
import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.decorators.ConstantVertexPaintFunction;
import edu.uci.ics.jung.graph.decorators.EdgeShape;
import edu.uci.ics.jung.graph.decorators.ToStringLabeller;
import edu.uci.ics.jung.graph.decorators.ToolTipFunctionAdapter;
import edu.uci.ics.jung.graph.decorators.VertexPaintFunction;
import edu.uci.ics.jung.graph.decorators.VertexShapeFunction;
import edu.uci.ics.jung.graph.decorators.VertexStringer;
import edu.uci.ics.jung.io.PajekNetReader;
import edu.uci.ics.jung.io.PajekNetWriter;
import edu.uci.ics.jung.visualization.DefaultGraphLabelRenderer;
import edu.uci.ics.jung.visualization.FRLayout;
import edu.uci.ics.jung.visualization.GraphZoomScrollPane;
import edu.uci.ics.jung.visualization.ISOMLayout;
import edu.uci.ics.jung.visualization.Layout;
import edu.uci.ics.jung.visualization.PluggableRenderer;
import edu.uci.ics.jung.visualization.Renderer;
import edu.uci.ics.jung.visualization.SpringLayout;
import edu.uci.ics.jung.visualization.VisualizationModel;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.contrib.KKLayout;
import edu.uci.ics.jung.visualization.control.AbstractGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.AbstractPopupGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import edu.uci.ics.jung.visualization.control.TranslatingGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.ViewScalingControl;
import edu.uci.ics.jung.visualization.transform.MutableTransformer;

/** Display panel for networks, graphs and subgraphs. */
public class NetworkPanel extends JPanel implements MouseListener, ActionListener, ChangeListener, DatasetChangeListener, ComponentListener {
	
	//=============================================================================
	// members

	private static final long serialVersionUID = 1L;
	
	private JPanel titlesPanel = null;
	private JLabel title = null;
	private JLabel subtitle = null;
	private JPopupMenu pMenu = null;
	private JSlider slider = null;
	private JPanel wrapperPanel = null;
	private JPanel layoutPanel = null;
	private JPanel repulsionPanel = null;
	private JPanel attractionPanel = null;
	private JSlider repulsionSlider = null;
	private JSlider attractionSlider = null;
	private JMenuItem frParameters = null;
	
	private NetworkPanelVisualizationViewer viewer = null;
	private GraphZoomScrollPane scrollPane = null;
	private NetworkScalingGraphMousePlugin scaling_Plugin = null;
	
	//=============================================================================
	// additional members
	
	/** Meta information of the graph (used only in network mode). */
	private GraphMetadata metaG = null;
	
	/** Dataset producer of the graph. */
	private GraphDatasetProducer producer = null;
	
 	/** A hashmap that binds names to graph layouts.
 	 * @see ai.aitia.chart.view.meta.GraphMetadata GraphMetadata
 	 */ 
	private HashMap<String,Class> layouts = null;
	
	/** Dataset of the graph. */
	private DefaultGraphDataset dataset = null;
	
	/** Graph source (used only in subgraph mode). */
	private DefaultGraphSource source = null;
	
	/** Meta information of the subgraph (used only in subgraph mode). */
	private SubgraphMetadata metaS = null;
	
	/** Flag that determines whether the graph is a subgraph or a network. */ 
	private boolean subgraph = false;
	
	/** The actual value of the repulsion used by Fruchterman Reingold layout (network only). */
	private double actRepulsion;
	
	/** The actual value of the attraction used by Fruchterman Reingold layout (network only). */
	private double actAttraction;
	
	/** The actual layout (used by network only). */
	private Layout actLayout = null;
	
	private Paint backgroundPaint = null;
	
	private ColorMapUpdateOption updateOption = ColorMapUpdateOption.NONE;

	private BufferedImage imageBuffer;
	
	private static final double VERTEX_SIZE = 18; 
	private double vertexSize = 18;
	private double vertexSizePercentage;
	
	//==============================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	/** Constructor.
	 * @param producer dataset producer of the graph
	 * @param meta meta information of the graph 
	 * @throws DataSourceException if any problem occure during the production of the data
	 */
	public NetworkPanel(GraphDatasetProducer producer, GraphMetadata meta) throws DataSourceException {
		super();
		this.producer = producer;		
		this.metaG = meta;
		this.subgraph = false;
		initializeLayouts();
		initialize();
		addMouseListener(this);
	}
	
	//----------------------------------------------------------------------------------------------------
	/** Constructor.
	 * @param producer dataset producer of the graph
	 * @param meta meta information of the graph 
	 * @throws DataSourceException if any problem occure during the production of the data
	 */
	public NetworkPanel(GraphDatasetProducer producer, GraphMetadata meta, double vertexSizePercentage) throws DataSourceException {
		super();
		this.producer = producer;		
		this.metaG = meta;
		this.subgraph = false;
		this.vertexSizePercentage = vertexSizePercentage;
		this.setVertexSize(vertexSizePercentage);
		initializeLayouts();
		initialize();
		addMouseListener(this);
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor.
	 * @param producer dataset producer of the graph
	 * @param meta meta information of the subgraph 
	 * @throws DataSourceException if any problem occure during the production of the data
	 */
	public NetworkPanel(GraphDatasetProducer producer, SubgraphMetadata meta, double vertexSizePercentage) throws DataSourceException {
		super();
		this.producer = producer;
		this.metaS = meta;
		this.subgraph = true;
		this.vertexSizePercentage = vertexSizePercentage;
		this.setVertexSize(vertexSizePercentage);
		initialize();
		addMouseListener(this);
	}
	
	//----------------------------------------------------------------------------------------------------
	/** Constructor.
	 * @param producer dataset producer of the graph
	 * @param meta meta information of the subgraph 
	 * @throws DataSourceException if any problem occure during the production of the data
	 */
	public NetworkPanel(GraphDatasetProducer producer, SubgraphMetadata meta) throws DataSourceException {
		super();
		this.producer = producer;
		this.metaS = meta;
		this.subgraph = true;
		initialize();
		addMouseListener(this);
	}
	//-------------------------------------------------------------------------------
	public VisualizationViewer getViewer() { return viewer; }
	
	//----------------------------------------------------------------------------------------------------
	public void setVertexSize(double vertexSizePercentage) {
		this.vertexSize = (VERTEX_SIZE * vertexSizePercentage) / 100;
	}
 
	//-------------------------------------------------------------------------------
	/** This method initializes <code>layouts</code>. */
	private void initializeLayouts() {
		layouts = new HashMap<String,Class>();
		layouts.put(GraphMetadata.FRUCHTERMAN_REINGOLD,FRLayout.class);
		layouts.put(GraphMetadata.KAMADA_KAWAI,KKLayout.class);
		layouts.put(GraphMetadata.KAMADA_KAWAI_3D,KK3dLayout.class);
		layouts.put(GraphMetadata.MEYERS,ISOMLayout.class);
		layouts.put(GraphMetadata.CIRCLE,DefinedCircleLayout.class);
		layouts.put(GraphMetadata.SPRING,SpringLayout.class);
	}

	//-------------------------------------------------------------------------------
	/** This method initializes <code>this</code>. */
	private void initialize() throws DataSourceException {
		this.setBackground(Color.WHITE);
		if (subgraph) {
			if (metaS.hasCustomAppearance())
				this.backgroundPaint = metaS.getCustomAppearance().getBackgroundPaint();
		} else {
			if (metaG.hasCustomAppearance())
				this.backgroundPaint = metaG.getCustomAppearance().getBackgroundPaint();
		}
		this.setLayout(new BorderLayout());
		this.add(getTitlesPanel(),BorderLayout.NORTH);
		this.add(getScrollPane(),BorderLayout.CENTER);
		this.add(getSlider(),BorderLayout.SOUTH);
		pMenu = createPopupMenu();
		this.addComponentListener(this);
	}

	//-------------------------------------------------------------------------------
	private JPopupMenu createPopupMenu() {
		JPopupMenu result = new JPopupMenu();
		JMenuItem saveAs = new JMenuItem("Save As...");
		saveAs.setActionCommand("SAVE");
		saveAs.addActionListener(this);
		result.add(saveAs);
		JMenuItem exportToPajekFile = new JMenuItem("Export to Pajek File...");
		exportToPajekFile.setActionCommand("PAJEK");
		exportToPajekFile.addActionListener(this);
		result.add(exportToPajekFile);
		result.addSeparator();
		JMenuItem zoomIn = new JMenuItem("Zoom in");
		zoomIn.setActionCommand("ZOOMIN");
		zoomIn.addActionListener(this);
		result.add(zoomIn);
		JMenuItem zoomOut = new JMenuItem("Zoom out");
		zoomOut.setActionCommand("ZOOMOUT");
		zoomOut.addActionListener(this);
		result.add(zoomOut);
		result.addSeparator();
		if (!subgraph) { // layouts
			ButtonGroup layoutGroup = new ButtonGroup();
			JRadioButtonMenuItem frLayout = new JRadioButtonMenuItem(GraphMetadata.FRUCHTERMAN_REINGOLD);
			if (metaG.getLayout().equals(GraphMetadata.FRUCHTERMAN_REINGOLD)) {
				getLayoutPanel(); // initialize if need
				frLayout.setSelected(true);
				repulsionSlider.setValue((int)(metaG.getRepulsion()*100));
				repulsionSlider.setToolTipText("Value: " + metaG.getRepulsion());
				attractionSlider.setValue((int)(metaG.getAttraction()*100));
				attractionSlider.setToolTipText("Value: " + metaG.getAttraction());
			}
			layoutGroup.add(frLayout);
			frLayout.setActionCommand("FR_LAYOUT");
			frLayout.addActionListener(this);
			result.add(frLayout);
			JRadioButtonMenuItem kkLayout = new JRadioButtonMenuItem(GraphMetadata.KAMADA_KAWAI);
			if (metaG.getLayout().equals(GraphMetadata.KAMADA_KAWAI))
				kkLayout.setSelected(true);
			layoutGroup.add(kkLayout);
			kkLayout.setActionCommand(GraphMetadata.KAMADA_KAWAI);
			kkLayout.addActionListener(this);
			result.add(kkLayout);
			JRadioButtonMenuItem kk3dLayout = new JRadioButtonMenuItem(GraphMetadata.KAMADA_KAWAI_3D);
			if (metaG.getLayout().equals(GraphMetadata.KAMADA_KAWAI_3D))
				kk3dLayout.setSelected(true);
			layoutGroup.add(kk3dLayout);
			kk3dLayout.setActionCommand(GraphMetadata.KAMADA_KAWAI_3D);
			kk3dLayout.addActionListener(this);
			result.add(kk3dLayout);
			JRadioButtonMenuItem mLayout = new JRadioButtonMenuItem(GraphMetadata.MEYERS);
			if (metaG.getLayout().equals(GraphMetadata.MEYERS))
				mLayout.setSelected(true);
			layoutGroup.add(mLayout);
			mLayout.setActionCommand(GraphMetadata.MEYERS);
			mLayout.addActionListener(this);
			result.add(mLayout);
			JRadioButtonMenuItem cLayout = new JRadioButtonMenuItem(GraphMetadata.CIRCLE);
			if (metaG.getLayout().equals(GraphMetadata.CIRCLE))
				cLayout.setSelected(true);
			layoutGroup.add(cLayout);
			cLayout.setActionCommand(GraphMetadata.CIRCLE);
			cLayout.addActionListener(this);
			result.add(cLayout);
			JRadioButtonMenuItem sLayout = new JRadioButtonMenuItem(GraphMetadata.SPRING);
			if (metaG.getLayout().equals(GraphMetadata.SPRING))
				sLayout.setSelected(true);
			layoutGroup.add(sLayout);
			sLayout.setActionCommand(GraphMetadata.SPRING);
			sLayout.addActionListener(this);
			result.add(sLayout);
			result.addSeparator();
			frParameters = new JMenuItem(GraphMetadata.FRUCHTERMAN_REINGOLD + " parameters...");
			frParameters.setActionCommand("FR_PARAMETERS");
			frParameters.addActionListener(this);
			frParameters.setEnabled(metaG.getLayout().equals(GraphMetadata.FRUCHTERMAN_REINGOLD));
			result.add(frParameters);
		} else { // depth
			ButtonGroup depthGroup = new ButtonGroup();
			for (int i = 1;i < 6;++i) {
				JRadioButtonMenuItem depth = new JRadioButtonMenuItem("Depth " + i);
				if (metaS.getDepth() == i)
					depth.setSelected(true);
				depthGroup.add(depth);
				depth.setActionCommand("DEPTH_" + i);
				depth.addActionListener(this);
				result.add(depth);
			}
		}
		return result;
	}

	//-------------------------------------------------------------------------------
	private GraphZoomScrollPane getScrollPane() throws DataSourceException {
		if (scrollPane == null) {
			viewer = initializeViewer();
		    if (updateOption != ColorMapUpdateOption.NONE)
		    	datasetChanged(new DatasetChangeEvent(dataset,dataset));
			scrollPane = new GraphZoomScrollPane(viewer);
			scrollPane.setBorder(BorderFactory.createCompoundBorder(
					             BorderFactory.createEmptyBorder(0,5,5,5),
					             BorderFactory.createLineBorder(Color.BLACK)));
		}
		return scrollPane;
	}

	//-------------------------------------------------------------------------------
	private NetworkPanelVisualizationViewer initializeViewer() throws DataSourceException {
		NetworkPanelVisualizationViewer vv = null;
		final SavePopupGraphMousePlugin savePlugin = new SavePopupGraphMousePlugin();

		dataset = (DefaultGraphDataset) producer.produceDataset(null);
		dataset.addChangeListener(this);
		if (subgraph) {
			Graph g = dataset.getGraph(); 
			source = new DefaultGraphSource(g);
			source.setDepth(metaS.getDepth());
			Vertex root = getRootVertex(g,metaS.getRootIndex());
			scaling_Plugin = new NetworkScalingGraphMousePlugin();
			SubGraphUtils.setCustomScalingPlugin(scaling_Plugin);
			vv = new NetworkPanelVisualizationViewer(SubGraphUtils.createVisualizationViewer(source,root,vertexSizePercentage));
			if (metaS.getCustomAppearance() != null && metaS.getCustomAppearance().getDimension() != null) 
				vv.setPreferredSize(metaS.getCustomAppearance().getDimension());
			vv.setBackground(null);
			PluggableRenderer renderer = (PluggableRenderer) vv.getRenderer();
			if (metaS.getColorAppearance() == Appearance.BLACK_AND_WHITE)
				renderer.setVertexPaintFunction(new BWVertexPaintFunction());
			if (metaS.hasVertexLabels()) {
				renderer.setVertexStringer(new UserDataLabeller(g));
				renderer.setVertexLabelCentering(true);
				if (metaS.getColorAppearance() == Appearance.BLACK_AND_WHITE)
					renderer.setGraphLabelRenderer(new VertexLabelRenderer(Color.WHITE));
			}
			((DefaultModalGraphMouse)vv.getGraphMouse()).add(savePlugin);
		} else {
			Class layoutC = layouts.get(metaG.getLayout());
			Object o = null;
			try {
				@SuppressWarnings("unchecked")
				Constructor constructor = layoutC.getConstructor(new Class[] {Graph.class});
				o = constructor.newInstance(new Object[] {dataset.getGraph()});
			} catch (Exception e) {
				// never thrown
			}
			Layout layout = (Layout) o;
			actLayout = layout;
			if (layoutC == FRLayout.class) {
				actRepulsion = metaG.getRepulsion();
				actAttraction = metaG.getAttraction();
				((FRLayout)layout).setRepulsionMultiplier(actRepulsion);
				((FRLayout)layout).setAttractionMultiplier(actAttraction);
			}
			if (metaG.getNrOfIterations() != -1) {
				if (layout instanceof FRLayout)
					((FRLayout)layout).setMaxIterations(metaG.getNrOfIterations());
				else if (layout instanceof KKLayout)
					((KKLayout)layout).setMaxIterations(metaG.getNrOfIterations());
				else if (layout instanceof KK3dLayout)
					((KK3dLayout)layout).setMaxIterations(metaG.getNrOfIterations());
			}
				
			PluggableRenderer renderer = new PluggableRenderer();
			if (metaG.hasColorMap()) {
				renderer.setVertexPaintFunction(new ColorMapVertexPaintFunction(metaG.getColorMap()));
				renderer.setGraphLabelRenderer(new ColorVertexLabelRenderer(metaG.getColorMap()));
				updateOption = ColorMapUpdateOption.getOption(metaG.getColorMap().getMinLevel(),metaG.getColorMap().getMaxLevel());
			} else {
				renderer.setVertexPaintFunction(new ConstantVertexPaintFunction(Color.BLACK,metaG.getColor()));
				renderer.setGraphLabelRenderer(new VertexLabelRenderer(invertColor(metaG.getColor())));
			}
			renderer.setEdgeShapeFunction(new EdgeShape.Line());
			renderer.setVertexShapeFunction(new NetVertexShapeFunction());
			if (metaG.hasVertexLabels()) {
				renderer.setVertexStringer(new UserDataLabeller(dataset.getGraph()));
				renderer.setVertexLabelCentering(true);
			}
			
			vv = new NetworkPanelVisualizationViewer(layout,renderer);
			if (metaG.getCustomAppearance() != null && metaG.getCustomAppearance().getDimension() != null) 
				vv.setPreferredSize(metaG.getCustomAppearance().getDimension());
			else
				vv.setPreferredSize(new Dimension(800,440));
			
			if (actLayout instanceof FRLayout) {
				Dimension layoutDimension = new Dimension((int)(vv.getPreferredSize().width * 0.95),
														  (int)(vv.getPreferredSize().height * 0.95));
				
				actLayout.initialize(layoutDimension);
			}
			
			scaling_Plugin = new NetworkScalingGraphMousePlugin();
			DefaultModalGraphMouse gm = new DefaultModalGraphMouse() {
				@Override
				protected void loadPlugins() {
					translatingPlugin = new TranslatingGraphMousePlugin(InputEvent.BUTTON1_MASK);
					scalingPlugin = scaling_Plugin;
	                add(scalingPlugin);
	                add(translatingPlugin);
	                add(savePlugin);
	                setMode(Mode.TRANSFORMING);
				}    
			};
			vv.setGraphMouse(gm);
			//vv.setToolTipFunction(new DefaultToolTipFunction());
		}
		return vv;
	}
	
	//-------------------------------------------------------------------------------
	private JPanel getLayoutPanel() {
		if (wrapperPanel == null) {
			wrapperPanel = new JPanel();
			wrapperPanel.setLayout(new BorderLayout());
			wrapperPanel.setBorder(BorderFactory.createEmptyBorder(0,30,0,30));
			layoutPanel = new JPanel();
			layoutPanel.setBorder(BorderFactory.createTitledBorder(null, "Fruchterman Reingold Layout parameters", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			layoutPanel.setLayout(new BoxLayout(layoutPanel,BoxLayout.Y_AXIS));
			layoutPanel.add(getRepulsionPanel(), null);
			layoutPanel.add(Box.createRigidArea(new Dimension(0,10)));
			layoutPanel.add(getAttractionPanel(), null);
			wrapperPanel.add(layoutPanel, BorderLayout.NORTH);
		}
		return wrapperPanel;
	}
	
	//-------------------------------------------------------------------------------
	private JPanel getRepulsionPanel() {
		if (repulsionPanel == null) {
			JLabel label = new JLabel("   Repulsion:  ");
			repulsionPanel = new JPanel();
			repulsionPanel.setLayout(new BoxLayout(repulsionPanel,BoxLayout.X_AXIS));
			repulsionPanel.add(label, null);
			repulsionPanel.add(getRepulsionSlider(), null);
		}
		return repulsionPanel;
	}

	//-------------------------------------------------------------------------------
	private JSlider getRepulsionSlider() {
		if (repulsionSlider == null) {
			repulsionSlider = new JSlider(1,100,75);
			repulsionSlider.setToolTipText("Value: 0.75");
		}
		return repulsionSlider;
	}

	//-------------------------------------------------------------------------------
	private JPanel getAttractionPanel() {
		if (attractionPanel == null) {
			JLabel label1 = new JLabel("  Attraction:  ");
			attractionPanel = new JPanel();
			attractionPanel.setLayout(new BoxLayout(attractionPanel,BoxLayout.X_AXIS));
			attractionPanel.add(label1, null);
			attractionPanel.add(getAttractionSlider(), null);
		}
		return attractionPanel;
	}

	//-------------------------------------------------------------------------------
	private JSlider getAttractionSlider() {
		if (attractionSlider == null) {
			attractionSlider = new JSlider(1,100,75);
			attractionSlider.setToolTipText("Value: 0.75");
		}
		return attractionSlider;
	}
	
	//-------------------------------------------------------------------------------
	private JPanel getTitlesPanel() {
		if (titlesPanel == null) {
			titlesPanel = new JPanel();
			titlesPanel.setLayout(new BoxLayout(titlesPanel,BoxLayout.Y_AXIS));
			titlesPanel.add(getTitle(),null);
			String subtitleString = subgraph ? metaS.getSubtitle() : metaG.getSubtitle();
			if (subtitleString != null && subtitleString.trim().length() != 0)
				titlesPanel.add(getSubtitle(),null);
		}
		return titlesPanel;
	}
	

	public String getTitleText() {
		return title==null ? "" : title.getText();
	}
	
	public void setTitleText(String text) {
		if (title==null) {
			title = new JLabel(text);
		} else {
			title.setText(text);
		}
	}
	
	//-------------------------------------------------------------------------------
	private JPanel getTitle() {
		JPanel pTitle = null;
		if (title == null) {
			String titleString = subgraph ? metaS.getTitle() : metaG.getTitle();
			title = new JLabel(titleString, JLabel.CENTER);
			title.setFont(new Font("SansSerif",Font.BOLD,18));
			String subtitleString = subgraph ? metaS.getSubtitle() : metaG.getSubtitle();
			int b = subtitleString != null && subtitleString.trim().length() != 0 ? 0 : 3; 
			title.setBorder(BorderFactory.createEmptyBorder(5,0,b,0));
			CustomAppearance app = null;
			if (subgraph && metaS.hasCustomAppearance()) 
				app = metaS.getCustomAppearance();
			else if (!subgraph && metaG.hasCustomAppearance())
				app = metaG.getCustomAppearance();
			if (app != null) {
				if (app.isShowTitle()) {
					if (app.getTitleFont() != null) 
						title.setFont(app.getTitleFont());
					if (app.getTitleColor() != null)
						title.setForeground(app.getTitleColor());
				} else title.setVisible(false);
			}
			pTitle = new JPanel();
			pTitle.add(title);
		}
		return pTitle;
	}
	
	//-------------------------------------------------------------------------------
	private JPanel getSubtitle() {
		JPanel pSubtitle = null;
		if (subtitle == null) {
			String subtitleString = subgraph ? metaS.getSubtitle() : metaG.getSubtitle();
			subtitle = new JLabel(subtitleString, JLabel.CENTER);
			subtitle.setFont(new Font("SansSerif",Font.BOLD,12));
			CustomAppearance app = null;
			if (subgraph && metaS.hasCustomAppearance()) 
				app = metaS.getCustomAppearance();
			else if (!subgraph && metaG.hasCustomAppearance())
				app = metaG.getCustomAppearance();
			if (app != null) {
				if (app.isShowSubtitle()) {
					if (app.getSubtitleFont() != null) 
						subtitle.setFont(app.getSubtitleFont());
					if (app.getSubtitleColor() != null)
						subtitle.setForeground(app.getSubtitleColor());
				} else subtitle.setVisible(false);
			}
			pSubtitle = new JPanel();
			pSubtitle.setBorder(BorderFactory.createEmptyBorder(0,0,3,0));
			pSubtitle.add(subtitle);
		}
		return pSubtitle;
	}
	
	//-------------------------------------------------------------------------------
	private JSlider getSlider() {
		if (slider == null) {
			slider = new JSlider(10,130,100);
			slider.setMajorTickSpacing(10);
			slider.setMinorTickSpacing(5);
			slider.setPaintTicks(true);
			slider.setPaintLabels(true);
			slider.setSnapToTicks(false);
			slider.addChangeListener(this);
			slider.setBorder(BorderFactory.createEmptyBorder(0,10,5,10));
		}
		return slider;
	}

	//-------------------------------------------------------------------------------
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}

	//-------------------------------------------------------------------------------
	/** Shows the popup menu. This method is public as an implementation side effect.
	 *  Do not call or override.
	 * @param e event
	 */
	public void mousePressed(MouseEvent e) {
		if (e.isPopupTrigger())
			pMenu.show(this,e.getX(),e.getY());
	}

	//-------------------------------------------------------------------------------
	/** Shows the popup menu. This method is public as an implementation side effect.
	 *  Do not call or override.
	 * @param e event
	 */
	public void mouseReleased(MouseEvent e) {
		if (e.isPopupTrigger())
			pMenu.show(this,e.getX(),e.getY());
	}

	//-------------------------------------------------------------------------------
	/** Saves the graph into a file (PNG or EPS formats are supported only).
	 * @param file the file
	 */
	public void saveGraphImage(File file) throws FileNotFoundException, IOException, Throwable {
		boolean hasTitle = (title.getText() != null && !title.getText().equals(""))
		   					|| (subtitle != null && subtitle.getText() != null && !subtitle.getText().equals(""));
		viewer.setBackground(Color.WHITE);
		double factor = 1, back = 1;
		if (title.getText() == null || title.getText().equals("") ||
			subtitle == null || subtitle.getText() == null || subtitle.getText().equals("")) {
			factor = 0.875;
			back = 1.145;
		} else {
			factor = 0.75;
			back = 1.335;
		}
		if (hasTitle) {
			viewer.getViewTransformer().scale(factor,factor,viewer.getCenter());
		}
		TitleLabeller tl = new TitleLabeller();
		viewer.addPostRenderPaintable(tl);
		if (file.getName().toLowerCase().endsWith(".eps")) {
			VectorGraphics g = new PSGraphics2D(file,new Dimension(viewer.getWidth(),viewer.getHeight()));
			g.startExport();
			viewer.print(g);
			g.endExport();
		} else if (file.getName().toLowerCase().endsWith(".emf")) {
			VectorGraphics g = new EMFGraphics2D(file,new Dimension(viewer.getWidth(),viewer.getHeight()));
			g.startExport();
			viewer.print(g);
			g.endExport();
		} else {
			BufferedImage bufferedImage = new BufferedImage(viewer.getWidth(),viewer.getHeight(),BufferedImage.TYPE_INT_RGB);
			Graphics2D g2d = bufferedImage.createGraphics();
			viewer.print(g2d);
			g2d.dispose();
			ImageIO.write(bufferedImage,"png",file);
		}
		viewer.removePostRenderPaintable(tl);
		if (hasTitle) {
			viewer.getViewTransformer().scale(back,back,viewer.getCenter());
		}
		viewer.setBackground(null);
	}

	public BufferedImage getImage() {
		boolean hasTitle = (title.getText() != null && !title.getText().equals(""))
		   					|| (subtitle != null && subtitle.getText() != null && !subtitle.getText().equals(""));
		viewer.setBackground(Color.WHITE);
		double titleOffset = hasTitle ? 35 : 0;
		
		Dimension graphSize = viewer.getModel().getGraphLayout().getCurrentSize();
		Dimension viewerSize = viewer.getViewerSize();

		double scale = 0d;
		if (viewerSize.getWidth() / graphSize.getWidth() < (viewerSize.getHeight() - titleOffset - 20) / (graphSize.getHeight())) {
			scale = viewerSize.getWidth() / graphSize.getWidth();
		} else {
			scale = (viewerSize.getHeight() - titleOffset * 2) / graphSize.getHeight();
		}
		
		MutableTransformer viewTransformer = viewer.getViewTransformer();
		
			
		viewTransformer.scale(scale, scale, new Point2D.Float(0,0));
		
		double dx = (viewerSize.width - (graphSize.width * scale)) / 2d;
		double dy = (viewerSize.height - (graphSize.height * scale)) / 2d + titleOffset;
		viewTransformer.setTranslate(dx, dy);
		

		TitleLabeller tl = new TitleLabeller();
		viewer.addPostRenderPaintable(tl);

		if (imageBuffer == null) {
			imageBuffer = new BufferedImage(viewerSize.width, viewerSize.height, BufferedImage.TYPE_INT_RGB);
		}
		Graphics2D g2d = (Graphics2D) imageBuffer.getGraphics();
		viewer.renderGraph(g2d);

		viewer.removePostRenderPaintable(tl);
		scale = 1 / scale;
		viewTransformer.setTranslate(-dx, -dy);
		viewTransformer.scale(scale, scale, new Point2D.Float(0,0));
		
		viewer.setBackground(null);
		return imageBuffer;
	}

	public void setViewerSize(Dimension dim) {
		viewer.setPreferredSize(dim);
		Window root = (Window) SwingUtilities.getRoot(this);
		if (root != null) {
			root.pack();
		}
	}
	
	public Dimension getViewerSize() {
		return viewer.getViewerSize();
	}
	
	//----------------------------------------------------------------------------------------------------
	public void exportGraph(String filename) throws IOException {
		Graph g = dataset.getGraph();
		VertexStringer vs = null;
		if ((subgraph && metaS.hasVertexLabels()) ||
			(!subgraph && metaG.hasVertexLabels()))
			vs = new UserDataLabeller(g);
		PajekNetWriter writer = new PajekNetWriter();
		writer.save(g,filename,vs,null);
	}
	
	//-------------------------------------------------------------------------------
	/** Handles the events of the items of the popup menu. This method is public as an implementation side effect.
	 *  Do not call or override.
	 * @param e event
 	 */
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if (command.equals("SAVE")) {
			JFileChooser fileChooser = new JFileChooser(GlobalHandlers.getLastDirectory());
	        ExtensionFileFilter EPSfilter = new ExtensionFileFilter("Encapsulated Postscript Files (*.eps)",".eps");
	        fileChooser.addChoosableFileFilter(EPSfilter);
			ExtensionFileFilter EMFFilter = new ExtensionFileFilter("Enhanced Metafiles (*.emf)",".emf");
			fileChooser.addChoosableFileFilter(EMFFilter);
	        ExtensionFileFilter PNGfilter = new ExtensionFileFilter("PNG Image Files (*.png)",".png");
	        fileChooser.addChoosableFileFilter(PNGfilter);
	        int option = fileChooser.showSaveDialog(this);
	        if (option == JFileChooser.APPROVE_OPTION) {
		        String filename = fileChooser.getSelectedFile().getPath();
		        GlobalHandlers.setLastDirectory(fileChooser.getSelectedFile());
				if (filename.lastIndexOf('.') == -1) {
					FileFilter filter = fileChooser.getFileFilter();
					if (filter.equals(EPSfilter)) 
						filename += ".eps";
					else if (filter.equals(EMFFilter)) 
						filename +=".emf";
					else
						filename += ".png";
				} else if (!filename.endsWith(".eps") && !filename.endsWith(".png") && !filename.endsWith(".emf") &&
						   !filename.endsWith(".EPS") && !filename.endsWith(".PNG") && !filename.endsWith(".EMF")) 
					filename += ".png";
				try {
					saveGraphImage(new File(filename));
				} catch (FileNotFoundException e1) {
					JOptionPane.showMessageDialog(this,"Unable to create this file:" + filename,"Saving failure",JOptionPane.ERROR_MESSAGE,null);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(this,"Unable to save the image.","Saving failure",JOptionPane.ERROR_MESSAGE,null);
				} catch (Throwable t) {
					ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
				}
	        }
		} else if ("PAJEK".equals(command)) {
			JFileChooser fileChooser = new JFileChooser(GlobalHandlers.getLastDirectory());
	        ExtensionFileFilter pajekfilter = new ExtensionFileFilter("Pajek Files",".net");
	        fileChooser.addChoosableFileFilter(pajekfilter);
	        int option = fileChooser.showSaveDialog(this);
	        if (option == JFileChooser.APPROVE_OPTION) {
		        String filename = fileChooser.getSelectedFile().getPath();
		        GlobalHandlers.setLastDirectory(fileChooser.getSelectedFile());
				if (filename.lastIndexOf('.') == -1 || !filename.endsWith(".net")) 
					filename += ".net";
				try {
					exportGraph(filename);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(this,"Unable to export the graph.","Exporting failure",JOptionPane.ERROR_MESSAGE,null);
				} catch (Throwable t) {
					ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
				}
	        }
		} else if (command.equals("ZOOMIN")) {
			viewer.getViewTransformer().scale(1.1,1.1,viewer.getCenter());
			viewer.repaint();
		} else if (command.equals("ZOOMOUT")) {
			viewer.getViewTransformer().scale(0.9,0.9,viewer.getCenter());
			viewer.repaint();
		} else if (command.equals("FR_LAYOUT")) {
			getLayoutPanel(); // initialize if need
			getSlider().setValue(100);
			repulsionSlider.setValue(75);
			repulsionSlider.setToolTipText("Value: 0.75");
			attractionSlider.setValue(75);
			attractionSlider.setToolTipText("Value: 0.75");
			FRLayout layout = new FRLayout(dataset.getGraph());
			actLayout = layout;
			if (metaG.getNrOfIterations() != -1) 
				layout.setMaxIterations(metaG.getNrOfIterations());
			actRepulsion = actAttraction = 0.75;
			layout.setRepulsionMultiplier(0.75);
			layout.setAttractionMultiplier(0.75);
			viewer.stop();
			viewer.setGraphLayout(layout);
			viewer.restart();
			frParameters.setEnabled(true);
		} else if (layouts != null && layouts.get(command) != null) {
			getSlider().setValue(100);
			frParameters.setEnabled(false);
			try {
				Class layoutClass = layouts.get(command);
				@SuppressWarnings("unchecked")
				Constructor constructor = layoutClass.getConstructor(new Class[] {Graph.class});
				Object obj = constructor.newInstance(new Object[] { dataset.getGraph() });
				viewer.stop();
				actLayout = (Layout) obj;
				if (metaG.getNrOfIterations() != -1) {
					if (actLayout instanceof KKLayout)
						((KKLayout)actLayout).setMaxIterations(metaG.getNrOfIterations());
					else if (actLayout instanceof KK3dLayout)
						((KK3dLayout)actLayout).setMaxIterations(metaG.getNrOfIterations());
				}
				viewer.setGraphLayout(actLayout);
				viewer.restart();
			} catch (Exception e1) {
				// never thrown 
			}
		} else if (command.startsWith("DEPTH")) {
			String depth_str = command.substring(command.length() - 1);
			int depth = Integer.parseInt(depth_str);
			viewer.stop();
			source.setDepth(depth);
			Vertex root = getRootVertex(dataset.getGraph(),metaS.getRootIndex());
			Graph g = source.getSubGraph(root);
			Layout layout = new KKLayout(g);
			viewer.setGraphLayout(layout);
			viewer.restart();
		} else if (command.startsWith("FR_PARAMETERS")) {
			Container parent = getRootPane().getParent();
			boolean frameParent = true;
			if (parent != null) {
				frameParent = (parent instanceof Frame);
				while (!(parent instanceof Frame) && !(parent instanceof Dialog)) {
					parent = parent.getParent();
					if (parent == null) break;
					frameParent = (parent instanceof Frame);
				}
			}
			JDialog dlg = frameParent ? new JDialog((Frame)parent,"Set parameters",true) : new JDialog((Dialog)parent,"Set parameters",true);;
			dlg.setContentPane(getLayoutPanel());
			dlg.pack();
			dlg.setLocationRelativeTo(parent);
			dlg.setVisible(true);
			double repulsion = ((double)repulsionSlider.getValue())/100;
			repulsionSlider.setToolTipText("Value: " + repulsion);
			double attraction = ((double)attractionSlider.getValue())/100;
			attractionSlider.setToolTipText("Value: " + attraction);
			if (viewer.getGraphLayout() instanceof FRLayout) {
				viewer.stop();
				FRLayout layout = (FRLayout) viewer.getGraphLayout();
				actRepulsion = repulsion;
				layout.setRepulsionMultiplier(actRepulsion);
				actAttraction = attraction;
				layout.setAttractionMultiplier(actAttraction);
				viewer.restart();
			}
		}
	}

	//-------------------------------------------------------------------------------
	/** Handles the events of the sliders. This method is public as an implementation side effect.
	 *  Do not call or override.
	 * @param e event
	 */
	public void stateChanged(ChangeEvent e) {
		JSlider source = (JSlider) e.getSource();
		if (source.equals(slider)) {
			int value = source.getValue();
			if (value == 0) return;
			double ratio = (double) value/100;
			viewer.getViewTransformer().setToIdentity();
			viewer.getViewTransformer().scale(ratio,ratio,viewer.getCenter());
			viewer.repaint();
		} 
    }
	
	//----------------------------------------------------------------------------------------------------
	public void componentHidden(ComponentEvent e) {}
	public void componentMoved(ComponentEvent e) {}
	public void componentShown(ComponentEvent e) {}

	//----------------------------------------------------------------------------------------------------
	public void componentResized(ComponentEvent e) {
		viewer.stop();
		viewer.scaleToLayout(viewer.getModel().getGraphLayout().getCurrentSize());
		viewer.restart();
	}
	
	//-------------------------------------------------------------------------------
	/** Updates the dataset.
	 * @param event event
	 */
	public void datasetChanged(DatasetChangeEvent event) {
		viewer.stop();
		dataset.removeChangeListener(this);
		try {
			dataset = (DefaultGraphDataset) producer.produceDataset(null);
		} catch (DataSourceException e) {
			// wrong dataset => no update
			return;
		} finally {
			dataset.addChangeListener(this);
		}
		if (subgraph) {
			Graph g = dataset.getGraph();
			if (metaS.hasVertexLabels()) {
				PluggableRenderer renderer = (PluggableRenderer) viewer.getRenderer();
				renderer.setVertexStringer(new UserDataLabeller(g));
				renderer.setVertexLabelCentering(true);
			}
			source.setGraph(g);
			Vertex root = getRootVertex(g,metaS.getRootIndex());
			g = source.getSubGraph(root);
			Layout layout = new KKLayout(g);
			viewer.setGraphLayout(layout,true);
			getSlider().setValue(100);
		} else {
			Class layoutC = actLayout.getClass();;
			Object o = null;
			try {
				@SuppressWarnings("unchecked")
				Constructor constructor = layoutC.getConstructor(new Class[] { Graph.class });
				o = constructor.newInstance(new Object[] { dataset.getGraph() });
			} catch (Exception e) {
				// never thrown
			}
			Layout layout = (Layout) o;
			if (metaG.getNrOfIterations() != -1) {
				if (layout instanceof FRLayout)
					((FRLayout)layout).setMaxIterations(metaG.getNrOfIterations());
				else if (layout instanceof KKLayout)
					((KKLayout)layout).setMaxIterations(metaG.getNrOfIterations());
				else if (layout instanceof KK3dLayout)
					((KK3dLayout)layout).setMaxIterations(metaG.getNrOfIterations());
			}
			if (layout instanceof FRLayout) {
				((FRLayout)layout).setRepulsionMultiplier(actRepulsion);
				((FRLayout)layout).setAttractionMultiplier(actAttraction);
			}
			if (metaG.hasVertexLabels()) {
				PluggableRenderer renderer = (PluggableRenderer) viewer.getRenderer();
				renderer.setVertexStringer(new UserDataLabeller(dataset.getGraph()));
				renderer.setVertexLabelCentering(true);
			}
			viewer.setGraphLayout(layout,true);
			getSlider().setValue(100);

		   	if (updateOption != ColorMapUpdateOption.NONE) {
		   		final Graph g = dataset.getGraph();
	    		double min = Double.MAX_VALUE;
	    		double max = - Double.MAX_VALUE;
	    		for (final Object vo : g.getVertices()) {
	    			final Vertex v = (Vertex) vo;
	    			final Double colorValue = (Double) v.getUserDatum("COLOR_ID");
	    			if (colorValue != null && colorValue != - Double.MAX_VALUE && colorValue < min)
	    				min = colorValue.doubleValue();
	    			if (colorValue != null && colorValue > max)
	    				max = colorValue.doubleValue();
	    		}
	    		if (metaG.getColorMap() instanceof RainbowColorMap) {
	    			final RainbowColorMap cm = (RainbowColorMap) metaG.getColorMap();
	      			if (updateOption.contains(ColorMapUpdateOption.MIN))
	      				cm.setMinLevel(min);
	      			if (updateOption.contains(ColorMapUpdateOption.MAX))
	      				cm.setMaxLevel(max);
	    		} else if (metaG.getColorMap() instanceof BlackAndWhiteColorMap) {
	    			final BlackAndWhiteColorMap cm = (BlackAndWhiteColorMap) metaG.getColorMap();
	      			if (updateOption.contains(ColorMapUpdateOption.MIN))
	      				cm.setMinLevel(min);
	      			if (updateOption.contains(ColorMapUpdateOption.MAX))
	      				cm.setMaxLevel(max);
	    		} else if (metaG.getColorMap() instanceof SimpleColorMap) {
	    			final SimpleColorMap cm = (SimpleColorMap) metaG.getColorMap();
	      			if (!updateOption.contains(ColorMapUpdateOption.MIN))
	    				min = cm.getMinLevel();
	    			if (!updateOption.contains(ColorMapUpdateOption.MAX))
	    				max = cm.getMaxLevel();
	    			if (max >= min)
	    				cm.setLevels(min,max,cm.minColor,new Color(cm.maxRed,cm.maxGreen,cm.maxBlue));
	    		} else if (metaG.getColorMap() instanceof ColorMapCollection) {
	    			final ColorMapCollection cm = (ColorMapCollection) metaG.getColorMap();
	      			if (updateOption.contains(ColorMapUpdateOption.MIN))
	      				cm.setMinLevel(min);
	      			if (updateOption.contains(ColorMapUpdateOption.MAX))
	      				cm.setMaxLevel(max);
	    		}
		   	}
		}
		viewer.restart();
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the vertex of graph <code>g</code> identified by <code>index</code>.
	 * @param g graph
	 * @param index id of the vertex
	 * @return the new root vertex of the subgraph
	 */ 
	private Vertex getRootVertex(Graph g, int index) {
		Integer id = new Integer(index);
		Vertex root = null;
		for (Object obj : g.getVertices()) {
			Vertex v = (Vertex) obj;
			if (v.getUserDatum("id").equals(id)) {
				root = v;
				break;
			}
		}
		return root;
	}

	//-------------------------------------------------------------------------------
	/** Returns the title of the (sub)graph.
	 * @return title
	 */
	@Override
	public String getName() {
		return (subgraph ? metaS.getTitle() : metaG.getTitle());
	}
	
	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void paint(Graphics g) {
		try {
			super.paint(g);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void paintImmediately(int x, int y, int w, int h) {
		try {
			super.paintImmediately(x, y, w, h);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void paintImmediately(Rectangle r) {
		try {
			super.paintImmediately(r);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void print(Graphics g) {
		try {
			super.print(g);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void repaint(long tm, int x, int y, int width, int height) {
		try {
			super.repaint(tm, x, y, width, height);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void repaint(Rectangle r) {
		try {
			super.repaint(r);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void repaint() {
		try {
			super.repaint();
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void repaint(int x, int y, int width, int height) {
		try {
			super.repaint(x,y,width,height);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void repaint(long tm) {
		try {
			super.repaint(tm);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}
	
	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void paintComponents(Graphics g) {
		try {
			super.paintComponents(g);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void printComponents(Graphics g) {
		try {
			super.printComponents(g);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	//-------------------------------------------------------------------------------
	/** It catches and passes any Throwable to the global exception handler. */
	@Override
	public void paintAll(Graphics g) {
		try {
			super.paintAll(g);
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the inverse color of <code>c</code>.
	 * @return the inverse color of the parameter
	 */
	private Color invertColor(Color c) {
    	
    	final int newRed = 255 - c.getRed();
    	final int newGreen = 255 - c.getGreen();
    	final int newBlue = 255 - c.getBlue();
    	
    	return new Color(newRed, newGreen, newBlue);
    }
	
	//===============================================================================
	// nested classes
	
	//----------------------------------------------------------------------------------------------------
	/** This class writes the title and/or subtitle to the graph visualization viewer. */
	private class TitleLabeller implements VisualizationViewer.Paintable {

		//====================================================================================================
		// methods
		
		//----------------------------------------------------------------------------------------------------
		public void paint(Graphics g) {
				boolean mustDrawTitle = title.getText() != null && !title.getText().equals("");
				boolean mustDrawSubtitle = subtitle != null && subtitle.getText() != null && !subtitle.getText().equals("");
				
				if (!mustDrawTitle && !mustDrawSubtitle) return;
				
				Dimension d = viewer.getViewerSize();
				Color oldColor = g.getColor();
				g.setColor(Color.BLACK);
				int sheight = -5;
				if (mustDrawTitle) {
					Font font1 = new Font("SansSerif", Font.BOLD, 18);
					FontMetrics metrics = g.getFontMetrics(font1);
					int swidth = metrics.stringWidth(title.getText());
					sheight = metrics.getMaxAscent()+ metrics.getMaxDescent();
					int tx = (d.width - swidth) / 2;
					int ty = sheight;
					g.setFont(font1);
					g.drawString(title.getText(), tx, ty);
				}
				if (mustDrawSubtitle) {
					Font font2 = new Font("SansSerif", Font.BOLD, 12);
					FontMetrics metrics = g.getFontMetrics(font2);
					int swidth = metrics.stringWidth(subtitle.getText());
					sheight += 5 + metrics.getMaxAscent() + metrics.getMaxDescent();
					int sx = (d.width - swidth) / 2;
					int sy = sheight;
					g.setFont(font2);
					g.drawString(subtitle.getText(), sx, sy);
				}
		        g.setColor(oldColor);
		}

		//----------------------------------------------------------------------------------------------------
		public boolean useTransform() {	return false; }
		
	}
	
	//----------------------------------------------------------------------------------------------------
	/** This class provides the color of the labels. */
	@SuppressWarnings("serial")
	private static class VertexLabelRenderer extends DefaultGraphLabelRenderer {
		
		//====================================================================================================
		// methods
		
		//----------------------------------------------------------------------------------------------------
		public VertexLabelRenderer(Color vertexLabelColor) { super(vertexLabelColor,Color.BLACK); }

		//----------------------------------------------------------------------------------------------------
		@Override
		public Component getGraphLabelRendererComponent(JComponent vv, Object value, Font font, boolean isSelected, Vertex vertex) {
	        setForeground(pickedVertexLabelColor);
	        super.setBackground(vv.getBackground());
	        if (font != null) 
	            setFont(font);
	        else
	            setFont(vv.getFont());
	        setIcon(null);
	        setBorder(noFocusBorder);
	        setValue(value); 
	        return this;
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("serial")
	private class ColorVertexLabelRenderer extends DefaultGraphLabelRenderer {
		
		//====================================================================================================
		// members
		
		protected ColorMap colormap = null;
		
		//====================================================================================================
		// methods
		
		//----------------------------------------------------------------------------------------------------
		public ColorVertexLabelRenderer(ColorMap colormap) {
			super(Color.BLACK,Color.BLACK);
			if (colormap == null)
				throw new IllegalArgumentException("'colormap' cannot be null.");
			this.colormap = colormap;
		}

		//----------------------------------------------------------------------------------------------------
		@Override
		public Component getGraphLabelRendererComponent(JComponent vv, Object value, Font font, boolean isSelected, Vertex vertex) {
			Double colorValue = (Double) vertex.getUserDatum("COLOR_ID");
			Color nodeColor = colorValue == null ? colormap.getDefaultColor() : colormap.getColor(colorValue.doubleValue());
	        setForeground(NetworkPanel.this.invertColor(nodeColor));
	        super.setBackground(vv.getBackground());
	        if (font != null)
	        	setFont(font);
	        else
	        	setFont(vv.getFont());
	        setIcon(null);
	        setBorder(noFocusBorder);
	        setValue(value); 
	        return this;
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	/** This class provides the color of the vertices of a black-and-white subgraph. */
	private static class BWVertexPaintFunction implements VertexPaintFunction {

		//====================================================================================================
		// methhods
		
		//----------------------------------------------------------------------------------------------------
		public Paint getFillPaint(Vertex v) {
           Integer level = (Integer) v.getUserDatum(IGraphSource.LEVEL);
           switch (level.intValue()) {
           		case 0:	
           			return Color.BLACK;
            	case 1:
            		return Color.GRAY;
            	default:
            		return Color.LIGHT_GRAY; 			
           }
		}

		//----------------------------------------------------------------------------------------------------
		public Paint getDrawPaint(Vertex v) { return Color.BLACK; }
	}
	
	//----------------------------------------------------------------------------------------------------
	/** This class provides popup menu on the area of the graph visualization viewer. */
	private class SavePopupGraphMousePlugin extends AbstractPopupGraphMousePlugin {
		
		//====================================================================================================
		// methods
		
		//----------------------------------------------------------------------------------------------------
		@Override
		protected void handlePopup(MouseEvent e) {
			pMenu.show(viewer,e.getX(),e.getY()); 
		}
    }
	
	//----------------------------------------------------------------------------------------------------
	/** This class provides zoom capabilities to the mouse wheel. */
	private class NetworkScalingGraphMousePlugin extends AbstractGraphMousePlugin implements MouseWheelListener {

		//====================================================================================================
		// members
		
		/** Rate of the zoom in. */
		protected float in = 1.1f;
		
		/** Rate of the zoom out. */
		protected float out = 0.9f;
		
		/** Flag that determines whether the zoom methods use the mouse position
		 *  as center or the center of the graph.
		 */ 
		protected boolean zoomAtMouse = true;
		
		/** Scaler object. */
		protected ScalingControl scaler = new ViewScalingControl();

		//=========================================================================
		// methods
		
		//----------------------------------------------------------------------------------------------------
		/** Constructor. */
		public NetworkScalingGraphMousePlugin() {
			this(0,1.1f,0.9f);
		}
		
		//-------------------------------------------------------------------------
		/** Constructor.
		 * @param modifiers id of the modifier key (if any)
		 */
		public NetworkScalingGraphMousePlugin(int modifiers) {
			this(modifiers,1.1f,0.9f);
		}

		//-------------------------------------------------------------------------
		/** Constructor.
		 * @param in rate of zoom in
		 * @param out rate of zoom out
		 */
		public NetworkScalingGraphMousePlugin(float in, float out) {
			this(0,in,out);
		}

		//-------------------------------------------------------------------------
		/** Constructor.
		 * @param modifiers id of the modifier key (if any)
		 * @param in rate of zoom in
		 * @param out rate of zoom out
		 */
		public NetworkScalingGraphMousePlugin(int modifiers, float in, float out) {
			super(modifiers);
			this.in = in;
			this.out = out;
		}

		//-------------------------------------------------------------------------
		/** Sets the flag that determines whether the zoom methods use the mouse
		 *  position as center or the center of the graph. */
		public void setZoomAtMouse(boolean zoomAtMouse) { this.zoomAtMouse = zoomAtMouse; }

		//-------------------------------------------------------------------------
		@Override
		public boolean checkModifiers(MouseEvent e) {
			return e.getModifiers() == modifiers || (e.getModifiers() & modifiers) != 0;
		}
		
		//-------------------------------------------------------------------------
		/** Handles the events of the mouse wheel. This method is public as an
		 *  implementation side effect. Do not call or override.
		 * @param e event
		 */
		public void mouseWheelMoved(MouseWheelEvent e) {
			boolean accepted = checkModifiers(e);
			if (accepted) {
				VisualizationViewer vv = (VisualizationViewer) e.getSource();
				Point2D mouse = e.getPoint();
				Point2D center = vv.getCenter();
				int amount = e.getWheelRotation();
				if (zoomAtMouse) {
					if (amount > 0) 
						scaler.scale(vv,in,mouse);
					else if (amount < 0) 
						scaler.scale(vv,out,mouse);
				} else {
					if (amount > 0) 
						scaler.scale(vv,in,center);
					else if (amount < 0) 
						scaler.scale(vv,out,center);
				}
				e.consume();
				vv.repaint();
			}
		}

		//-------------------------------------------------------------------------
		/** Returns the rate of zoom in.
		 * @return rate of zoom in
		 */
		public float getIn() { return in; }

		//-------------------------------------------------------------------------
		/** Sets the rate of zoom in.
		 * @param in new rate of zoom in
		 */
		public void setIn(float in) { this.in = in;	}

		//-------------------------------------------------------------------------
		/** Returns the rate of zoom out.
		 * @return rate of zoom out
		 */
		public float getOut() { return out;	}

		//-------------------------------------------------------------------------
		/** Sets the rate of zoom out.
		 * @param out new rate of zoom out
		 */
		public void setOut(float out) { this.out = out;	}
	}
	
	//-------------------------------------------------------------------------------
	/** Assistant class that provides labels for the nodes of the graph. */
	private static class UserDataLabeller extends ToStringLabeller {
		
		//----------------------------------------------------------------------------------------------------
		/** Constructor.
		 * @param g the graph that needs labels.
		 */
		public UserDataLabeller(Graph g) {
			super(g);
		}
		
		//---------------------------------------------------------------------------
		@Override
		public String getLabel(ArchetypeVertex v) {
			Object o_result = v.getUserDatum("label");
			if (o_result != null) {
				return o_result.toString();
			} else {
				o_result = v.getUserDatum(PajekNetReader.LABEL);
				if (o_result != null) 
					return o_result.toString();
			}
			return "";
		}
	}
	
	//--------------------------------------------------------------------------------
	public class NetworkPanelVisualizationViewer extends VisualizationViewer {
		
		//============================================================================
		// members

		private static final long serialVersionUID = 1L;
		long[] paintTimes = new long[5];
		int paintIndex = 0;
		double paintfps;
		
		//============================================================================
		// methods
		
		//----------------------------------------------------------------------------
		/**
	     * Create an instance with passed parameters.
	     * 
	     * @param layout		The Layout to apply, with its associated Graph
	     * @param renderer		The Renderer to draw it with
	     */
		public NetworkPanelVisualizationViewer(Layout layout, Renderer renderer) {
			super(layout,renderer);
		}
		
		//----------------------------------------------------------------------------
	    /**
	     * Create an instance with passed parameters.
	     * 
	     * @param layout		The Layout to apply, with its associated Graph
	     * @param renderer		The Renderer to draw it with
	     * @param preferredSize the preferred size of this View
	     */
		public NetworkPanelVisualizationViewer(Layout layout, Renderer renderer, Dimension preferredSize) {
		    super(layout,renderer,preferredSize);
		}
		
		//----------------------------------------------------------------------------
		/**
		 * Create an instance with passed parameters.
		 * 
		 * @param model
		 * @param renderer
		 */
		public NetworkPanelVisualizationViewer(VisualizationModel model, Renderer renderer) {
			super(model,renderer);
		}
		
		//----------------------------------------------------------------------------
		/**
		 * Create an instance with passed parameters.
		 * 
		 * @param model
		 * @param renderer
		 * @param preferredSize initial preferred size of the view
		 */
		public NetworkPanelVisualizationViewer(VisualizationModel model, Renderer renderer, Dimension preferredSize) {
			super(model,renderer,preferredSize);
		}
		
		//-----------------------------------------------------------------------------
		public NetworkPanelVisualizationViewer(VisualizationViewer viewer) {
			super(viewer.getModel().getGraphLayout(),viewer.getRenderer());
	        setToolTipFunction(new ToolTipFunctionAdapter() {
	            @Override
				public String getToolTipText(Vertex v) {
	                return (String)v.getUserDatum(IGraphSource.TOOLTIP);
	            }
	        });
	        setPickSupport(viewer.getPickSupport());
	        setGraphMouse(viewer.getGraphMouse());
		}
		
		//----------------------------------------------------------------------------------------------------
		@Override
		public void scaleToLayout(Dimension layoutSize) {
			super.scaleToLayout(layoutSize);
		}
		
		//-----------------------------------------------------------------------------
		@SuppressWarnings("unchecked")
		@Override
		protected void renderGraph(Graphics2D g2d) {
		    Layout layout = model.getGraphLayout();
			g2d.setRenderingHints(renderingHints);
			long start = System.currentTimeMillis();
			
			// the size of the VisualizationViewer
			Dimension d = getViewerSize();
			
			// clear the offscreen image
	       if (backgroundPaint != null) {
	            Composite originalComposite = g2d.getComposite();
	            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f));
	            g2d.setPaint(backgroundPaint);
	            g2d.fillRect(0,0,d.width,d.height);
	            g2d.setComposite(originalComposite);
		    } else {
		    	g2d.setColor(getBackground());
	            g2d.fillRect(0,0,d.width,d.height);
		    }

			AffineTransform oldXform = g2d.getTransform();
	        AffineTransform newXform = new AffineTransform(oldXform);
	        newXform.concatenate(viewTransformer.getTransform());
			
	        g2d.setTransform(newXform);

			// if there are  preRenderers set, paint them
			for (Iterator iterator = preRenderers.iterator();iterator.hasNext();) {
			    Paintable paintable = (Paintable) iterator.next();
			    if (paintable.useTransform()) 
			        paintable.paint(g2d);
			    else {
			        g2d.setTransform(oldXform);
			        paintable.paint(g2d);
	                g2d.setTransform(newXform);
			    }
			}
			
	        locationMap.clear();
	        
			// paint all the edges
	        try {
	        	for (Iterator iter = layout.getGraph().getEdges().iterator();iter.hasNext();) {
				    Edge e = (Edge) iter.next();
				    Vertex v1 = (Vertex) e.getEndpoints().getFirst();
				    Vertex v2 = (Vertex) e.getEndpoints().getSecond();
	            
		            Point2D p = (Point2D) locationMap.get(v1);
		            if (p == null) {
		                p = layout.getLocation(v1);
		                p = layoutTransformer.transform(p);
		                locationMap.put(v1, p);
		            }
				    Point2D q = (Point2D) locationMap.get(v2);
		            if (q == null) {
		                q = layout.getLocation(v2);
		                q = layoutTransformer.transform(q);
		                locationMap.put(v2, q);
		            }
	
				    if (p != null && q != null) 
				        renderer.paintEdge(g2d,e,(int) p.getX(),(int) p.getY(),(int) q.getX(),(int) q.getY());
	        	}
	        } catch(ConcurrentModificationException cme) {
	            repaint();
	        }
			
			// paint all the vertices
	        try {
	        	for (Iterator iter = layout.getGraph().getVertices().iterator();iter.hasNext();) {
				    Vertex v = (Vertex) iter.next();
				    Point2D p = (Point2D) locationMap.get(v);
		            if (p == null) {
		                p = layout.getLocation(v);
		                p = layoutTransformer.transform(p);
		                locationMap.put(v, p);
		            }
				    if (p != null) 
				        renderer.paintVertex(g2d,v,(int) p.getX(),(int) p.getY());
				}
	        } catch(ConcurrentModificationException cme) {
	            repaint();
	        }
			
			long delta = System.currentTimeMillis() - start;
			paintTimes[paintIndex++] = delta;
			paintIndex = paintIndex % paintTimes.length;
			paintfps = average(paintTimes);
			
			// if there are postRenderers set, do it
			for(Iterator iterator = postRenderers.iterator();iterator.hasNext();) {
			    Paintable paintable = (Paintable) iterator.next();
			    if(paintable.useTransform()) 
			        paintable.paint(g2d);
			    else {
			        g2d.setTransform(oldXform);
			        paintable.paint(g2d);
	                g2d.setTransform(newXform);
			    }
			}
			g2d.setTransform(oldXform);
		}
		
		//----------------------------------------------------------------------------------------------------
		public Dimension getViewerSize() {
			int width = getWidth();
			int height = getHeight();
			
			if (width != 0 && height != 0) 
				return new Dimension(width, height);

			Dimension preferredSize = getPreferredSize();
			if (preferredSize == null) {
				preferredSize = new Dimension(800, 440);
				setPreferredSize(preferredSize);
			}
			return preferredSize;
		}
		
	    //----------------------------------------------------------------------------------------------------
		public Point2D getViewerCenter() {
	        Dimension d = getViewerSize();
	        return new Point2D.Float(d.width / 2, d.height / 2);
	    }

	    //----------------------------------------------------------------------------------------------------
		@Override
		public void setDoubleBuffered(boolean doubleBuffered) {	this.doubleBuffered = doubleBuffered; }
		public BufferedImage getOffscreen() { return offscreen;	}
	}
	
	//----------------------------------------------------------------------------------------------------
	private static class ColorMapVertexPaintFunction implements VertexPaintFunction {

		//====================================================================================================
		// members
		
		protected ColorMap colormap = null;
		
		//====================================================================================================
		// methods
		
		//----------------------------------------------------------------------------------------------------
		public ColorMapVertexPaintFunction(ColorMap colormap) {
			if (colormap == null)
				throw new IllegalArgumentException("'colormap' cannot be null.");
			this.colormap = colormap;
		}
		
		//====================================================================================================
		// implemented interfaces
		
		//----------------------------------------------------------------------------------------------------
		public Paint getDrawPaint(Vertex v) {
			try {
				Double colorValue = (Double) v.getUserDatum("COLOR_ID");
				return colorValue == null ? colormap.getDefaultColor() : colormap.getColor(colorValue.doubleValue());
			} catch (ClassCastException e) {
				return colormap.getDefaultColor();
			}
		}

		//----------------------------------------------------------------------------------------------------
		public Paint getFillPaint(Vertex v) { return getDrawPaint(v); }
	}
	
	//----------------------------------------------------------------------------------------------------
	private class NetVertexShapeFunction implements VertexShapeFunction {
		
		//====================================================================================================
		// methods
		
		//----------------------------------------------------------------------------------------------------
		public Shape getShape(Vertex vertex) { 
			Ellipse2D.Double e = new Ellipse2D.Double(- vertexSize / 2, - vertexSize / 2, vertexSize, vertexSize);
			return e;
		}
	}
}