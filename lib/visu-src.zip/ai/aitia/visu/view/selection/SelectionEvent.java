package ai.aitia.visu.view.selection;

import java.util.EventObject;

public class SelectionEvent extends EventObject {

	private static final long serialVersionUID = -4529370959402959095L;
	
	private ISelectionModel model;
	
	public SelectionEvent(ISelectionModel model) {
		super(model);
		this.model = model;
	}
	
	public ISelectionModel getSelectionModel() {
		return model;
	}
	
}
