/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes;

import java.awt.Container;
import java.util.ArrayList;
import java.util.Properties;

import org.jfree.chart.JFreeChart;
import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.SequenceDialog;
import ai.aitia.chart.ds.ElementListCollectionProducer;
import ai.aitia.chart.ds.IElementListProducer;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLLoadingException.TemplateLoadingException;
import ai.aitia.visu.VisualisationException;
import ai.aitia.visu.ds.IDataProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.view.ChartFactory;
import ai.aitia.visu.view.CustomSaveableChartPanel;
import ai.aitia.visu.view.meta.Appearance;
import ai.aitia.visu.view.meta.CustomAppearance;
import ai.aitia.visu.view.meta.SequenceMetadata;
import ai.aitia.visu.view.plot.SequencePlot;
import ai.aitia.visu.view.ui.DefaultElementRenderer;
import ai.aitia.visu.view.ui.IElementRenderer;

/** Sequence chart type. It is a chart for visualizing ordered series of sets.
 *  Visualization of the set elements can be customized.";
 */
public class Sequence extends AbstractChart {

	@Override
	public Container createChart(ChartConfig config) throws VisualisationException {
		
		if (config.getChartProperties() instanceof Properties) {
			
			Properties properties = (Properties)config.getChartProperties();
			
			SequenceMetadata meta = new SequenceMetadata();
			meta.setTitle(properties.getProperty(ChartConstants.TITLE));
			meta.setSubTitle(properties.getProperty(ChartConstants.SUBTITLE));
			
			String templateName = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			boolean needDefault = true;
			if (templateName != null && !"".equals(templateName)) {
				Element template = templates.get(templateName);
				if (template != null) {
					try {
						CustomAppearance appearance = createCustomAppearance(template);
						meta.setCustomAppearance(appearance);
						needDefault = false;
					} catch (TemplateLoadingException e) {
						throw new VisualisationException(e);
					}
				}
			}
			if (needDefault) {
				int env = Appearance.BASIC_APP;
				if (properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP))
					env = Appearance.NORMAL_APP;
				meta.setEnvironmentAppearance(env);
			}
			
			IElementRenderer renderer = null;
			try {
				renderer = Utilities.createElementRendererFromString(properties.getProperty(ChartConstants.ELEMENT_RENDERER));
			} catch (Exception e) {
				renderer = new DefaultElementRenderer();
			}
		
			ArrayList<IDataProducer> dp = new ArrayList<IDataProducer>();
			ElementListCollectionProducer elcp = new ElementListCollectionProducer();
			int[] sources = Utilities.splitDatasourceAroundCommas(properties.getProperty(ChartConstants.DATASOURCE));
			for (int i=0;i<sources.length;++i) {
				IDataSourceProducer dsp = config.getDataSource(sources[i]);
				IElementListProducer elp = (IElementListProducer)dsp.createDataProducer(IElementListProducer.class,null);
				dp.add(elp);
				elcp.addElementListProducer(elp);
			}
		
			if (config.isFireInitialEvent()) {
				for (IDataProducer p : dp) elcp.dataChanged(new DataChangeEvent(p));
			}
			JFreeChart chart = ChartFactory.createSequenceChart(elcp,meta);
			SequencePlot plot = (SequencePlot)chart.getPlot();
			plot.setElementRenderer(renderer);
			CustomSaveableChartPanel panel = new CustomSaveableChartPanel(chart);
			
			if (meta.getCustomAppearance() != null && meta.getCustomAppearance().getDimension() != null)
				panel.setPreferredSize(meta.getCustomAppearance().getDimension());
			
			return panel;
		}
		return null;
	}

	//-------------------------------------------------------------------------------
	@Override
	public Container createDialog(ChartConfig config, ChartConfigCollection collection) {
		return new SequenceDialog(config,collection);
	}

	//-------------------------------------------------------------------------------
	@Override
	public String getID() {
		return ChartConstants.SEQUENCE;
	}

	//-------------------------------------------------------------------------------
	@Override
	public String getDescription() {
		return "Sequence is a chart for visualizing ordered series of sets. Visualization of" +
			   " the set elements can be customized.";
	}

	//-------------------------------------------------------------------------------
	@Override
	public String toString() {
		return ChartConstants.SEQUENCE_NAME;
	}
}
