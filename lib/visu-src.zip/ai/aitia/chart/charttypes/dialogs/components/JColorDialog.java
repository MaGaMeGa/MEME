package ai.aitia.chart.charttypes.dialogs.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;

import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.utils.Utils;

@SuppressWarnings("serial")
public class JColorDialog extends JDialog implements ActionListener {

	//====================================================================================================
	// members
	
	private JPanel content = new JPanel(new BorderLayout());
	private JPanel bottom = new JPanel();
	private JColorChooser chooser;
	private JButton okButton = new JButton("Ok");
	private JButton cancelButton = new JButton("Cancel");
	
	private Window owner;
	private Color returnValue;

	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public JColorDialog(final Window owner, final Color initColor) {
		super(owner,"Choose a color...",ModalityType.APPLICATION_MODAL);
		this.owner = owner;
		returnValue = initColor;
		layoutGUI();
		initialize();
	}
	
	//----------------------------------------------------------------------------------------------------
	public JColorDialog(final Window owner) { this(owner,Color.BLUE); }
	
	//----------------------------------------------------------------------------------------------------
	public Color showDialog() {
		setVisible(true);
		final Color result = returnValue;
		dispose();
		return result;
	}
	
	//====================================================================================================
	// implemented interfaces
	
	//----------------------------------------------------------------------------------------------------
	public void actionPerformed(ActionEvent e) {
		final String cmd = e.getActionCommand();
		if ("OK".equals(cmd)) {
			returnValue = chooser.getColor();
			setVisible(false);
		} else if ("CANCEL".equals(cmd)) {
			returnValue = null;
			setVisible(false);
		}
	}

	//====================================================================================================
	// GUI methods
	
	//----------------------------------------------------------------------------------------------------
	private void layoutGUI() {
		chooser = new JColorChooser(returnValue);
		bottom.add(okButton);
		bottom.add(cancelButton);
		
		content.add(chooser,BorderLayout.CENTER);
		Box tmp = new Box(BoxLayout.Y_AXIS);
		tmp.add(new JSeparator());
		tmp.add(bottom);
		
		content.add(tmp,BorderLayout.SOUTH);
		setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			@Override public void windowClosing(WindowEvent e) {
				returnValue = null;
			}	
		});
	}
	
	//----------------------------------------------------------------------------------------------------
	private void initialize() {
		okButton.setActionCommand("OK");
		cancelButton.setActionCommand("CANCEL");
		Utilities.addActionListener(this,okButton,cancelButton);
		
		final JScrollPane sp = new JScrollPane(content,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		sp.setBorder(null);
		this.setContentPane(sp);
		this.pack();
		Dimension oldD = this.getPreferredSize();
		this.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
								     		oldD.height + sp.getHorizontalScrollBar().getHeight()));
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		oldD = this.getPreferredSize();
		final Dimension newD = Utils.getPreferredSize(this);
		if (!oldD.equals(newD)) 
			this.setPreferredSize(newD);
		this.pack();
		this.setLocationRelativeTo(owner);
	}

	//====================================================================================================
	// assistant methods

	//====================================================================================================
	// nested classes
}