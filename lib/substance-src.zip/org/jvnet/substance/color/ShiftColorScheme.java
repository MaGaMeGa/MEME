/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.color;

import java.awt.Color;

import org.jvnet.substance.utils.SubstanceColorUtilities;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * Base class for shifted color schemes. A shifted color scheme is based on some
 * original color scheme, a shift color and a shift factor. All colors of the
 * original color scheme are shifted towards the shift color based on the shift
 * factor. The closer the shift factor value is to 1.0, the closer the colors of
 * the shifted color scheme will be to the shift color.
 * 
 * @author Kirill Grouchnikov
 */
public class ShiftColorScheme extends BaseColorScheme {
	/**
	 * Shift factor.
	 */
	private double shiftFactor;

	/**
	 * Shift color.
	 */
	private Color shiftColor;

	/**
	 * The main ultra-light color.
	 */
	private Color mainUltraLightColor;

	/**
	 * The main extra-light color.
	 */
	private Color mainExtraLightColor;

	/**
	 * The main light color.
	 */
	private Color mainLightColor;

	/**
	 * The main medium color.
	 */
	private Color mainMidColor;

	/**
	 * The main dark color.
	 */
	private Color mainDarkColor;

	/**
	 * The main ultra-dark color.
	 */
	private Color mainUltraDarkColor;

	/**
	 * The foreground color.
	 */
	private Color foregroundColor;

	/**
	 * The original color scheme.
	 */
	private ColorScheme origScheme;

	/**
	 * Creates a new shifted color scheme.
	 * 
	 * @param origScheme
	 *            The original color scheme.
	 * @param shiftColor
	 *            Shift color.
	 * @param shiftFactor
	 *            Shift factor. Should be in 0.0-1.0 range.
	 */
	public ShiftColorScheme(ColorScheme origScheme, Color shiftColor,
			double shiftFactor) {
		this.shiftColor = shiftColor;
		this.shiftFactor = shiftFactor;
		this.origScheme = origScheme;
		this.foregroundColor = SubstanceColorUtilities.getInterpolatedColor(
				this.shiftColor, origScheme.getForegroundColor(),
				this.shiftFactor / 2.0);
		this.mainUltraDarkColor = SubstanceColorUtilities.getInterpolatedColor(
				this.shiftColor, origScheme.getUltraDarkColor(),
				this.shiftFactor);
		this.mainDarkColor = SubstanceColorUtilities.getInterpolatedColor(
				this.shiftColor, origScheme.getDarkColor(), this.shiftFactor);
		this.mainMidColor = SubstanceColorUtilities.getInterpolatedColor(
				this.shiftColor, origScheme.getMidColor(), this.shiftFactor);
		this.mainLightColor = SubstanceColorUtilities.getInterpolatedColor(
				this.shiftColor, origScheme.getLightColor(), this.shiftFactor);
		this.mainExtraLightColor = SubstanceColorUtilities
				.getInterpolatedColor(this.shiftColor, origScheme
						.getExtraLightColor(), this.shiftFactor);
		this.mainUltraLightColor = SubstanceColorUtilities
				.getInterpolatedColor(this.shiftColor, origScheme
						.getUltraLightColor(), this.shiftFactor);

		this.id = this.getClass().getName()
				+ SubstanceCoreUtilities.getSchemeId(origScheme) + "->"
				+ shiftColor + ":" + shiftFactor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.color.ColorScheme#getForegroundColor()
	 */
	public Color getForegroundColor() {
		return this.foregroundColor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.color.ColorScheme#getUltraLightColor()
	 */
	public Color getUltraLightColor() {
		return this.mainUltraLightColor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.color.ColorScheme#getExtraLightColor()
	 */
	public Color getExtraLightColor() {
		return this.mainExtraLightColor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.color.ColorScheme#getLightColor()
	 */
	public Color getLightColor() {
		return this.mainLightColor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.color.ColorScheme#getMidColor()
	 */
	public Color getMidColor() {
		return this.mainMidColor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.color.ColorScheme#getDarkColor()
	 */
	public Color getDarkColor() {
		return this.mainDarkColor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.color.ColorScheme#getUltraDarkColor()
	 */
	public Color getUltraDarkColor() {
		return this.mainUltraDarkColor;
	}

	/**
	 * Returns the original color scheme.
	 * 
	 * @return The original color scheme.
	 */
	public ColorScheme getOrigScheme() {
		return this.origScheme;
	}

	/**
	 * Returns the shift factor.
	 * 
	 * @return Shift factor.
	 */
	public double getShiftFactor() {
		return this.shiftFactor;
	}
}
