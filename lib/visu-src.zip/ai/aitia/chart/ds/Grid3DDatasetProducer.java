package ai.aitia.chart.ds;

import java.util.List;
import java.util.Properties;

import org.jfree.data.general.Dataset;

import ai.aitia.visu.data.Grid3DDataset;
import ai.aitia.chart.util.Utilities.IGridConstants;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDatasetProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.event.IDataChangeListener;

public class Grid3DDatasetProducer implements IDatasetProducer,
											  IDataChangeListener,
											  IGridConstants{
	/** Time of the last update. */
	protected long time;
	
	/** The dataset that this object produces. */
	protected Grid3DDataset dataset = null;
	
	/** Series producer for length values. */
	protected ISeriesProducer zvalue_values = null;
	
	/** Series producer for color values. */
	protected ISeriesProducer color_values = null;
	
	/** The current produced values for lengths. */ 
	protected List<Double> zvalue_values_series = null;
	
	/** The current produced values for colors. */ 
	protected List<Double> color_values_series = null;
	
	/** Series producer for column indices (used only in random mode). */
	protected ISeriesProducer xs = null;
	
	/** The current produced values for column indices (used only in random mode). */
	protected List<Double> xs_series = null;
	
	/** Series producer for row indices (used only in random mode). */
	protected ISeriesProducer ys = null;
	
	/** The current producer values for row indices (used only in random mode). */
	protected List<Double> ys_series = null;
	
	/** Complete dataset producer (used only in dataset mode). */
	protected IGrid3DDatasetProducer ds_producer = null;
	
	/** The current complete grid produced by <code>ds_producer</code>
	 * (used only in dataset mode). */
	protected double[][][] ds_producer_dataset = new double[0][0][0];
	
	/** Value producer for width of the grid. */
	protected IValueProducer width_producer = null;
	
	/** The current produced value for width of the grid or a fix width value. */
	protected int width = -1;
	
	/** Value producer for height of the grid. */
	protected IValueProducer height_producer = null;
	
	/** The current produced value for height of the grid or a fix height value. */ 
	protected int height = -1;
	
	/** Flag that determines whether uses row order (left-to-right or column order
	 *  (top-to-bottom) when it places the values (used only in sequential mode). */
	protected boolean row_order = true;
	
	/** Mode of the dataset producer object. (FULL_MODE, PARTIAL_MODE or DS_MODE. */
	protected int mode = -1;
	
	public void dataChanged(DataChangeEvent event) {
	}
	
	public long getTime() {
		return time;
	}

	public Dataset produceDataset(Properties queryProperties)
			throws DataSourceException {
		return dataset;
	}
	
}
