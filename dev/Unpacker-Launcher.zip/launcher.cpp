#include <windows.h>
#include <stdio.h>
#include <process.h>

int WINAPI WinMain(HINSTANCE _hinstance, HINSTANCE hPrevInstance,
    LPSTR lpCmdLine, int _nCmdShow)
{
	spawnlp(_P_WAIT, "javaw", "-version:1.5+ -cp . Unpacker");

	const TCHAR* cmd = "-version:1.5+ ";
	int len = strlen(cmd) + strlen(lpCmdLine);
	TCHAR* buff = (TCHAR*)malloc(sizeof(TCHAR) * (len + 1));
	strcpy(buff, cmd);
	strcpy(buff + strlen(cmd), lpCmdLine);
	buff[len] = 0;

	spawnlp(_P_WAIT, "javaw", buff);
	return 0;
}
