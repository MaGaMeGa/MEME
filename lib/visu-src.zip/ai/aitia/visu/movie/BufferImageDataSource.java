package ai.aitia.visu.movie;

import javax.media.Buffer;
import javax.media.MediaLocator;
import javax.media.Time;
import javax.media.format.RGBFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.PullBufferDataSource;
import javax.media.protocol.PullBufferStream;


/**
 * A DataSource for turning JMF Buffers into movies. See the Java Media
 * Framework documentation for details.
 *
 * @author Nick Collier
 * @version $Revision: 1.1 $ $Date: 2008/06/09 12:40:43 $
 */

public class BufferImageDataSource extends PullBufferDataSource {
  //boolean b=false;
  private BufferImageSourceStream streams[];

  public BufferImageDataSource(int width, int height, int frameRate, RGBFormat format) {
    streams = new BufferImageSourceStream[1];
    streams[0] = new BufferImageSourceStream(width, height, frameRate, format);
  }

  public void addBuffer(Buffer buf) {
	streams[0].addBuffer(buf);
    if(true){
    	
    }else{
    	streams[1].addBuffer(buf);
    }
    
   
  }

  public void cleanUp() {
    streams[0].waitForDone();
  }

  public void setLocator(MediaLocator source) {

  }

  public MediaLocator getLocator() {
    return null;
  }

  public String getContentType() {
    return ContentDescriptor.RAW;
  }

  public void connect() {}

  public void disconnect() {}

  public void start() {}

  public void stop() {}

  public PullBufferStream[] getStreams() {
    return streams;
  }

  public Time getDuration() {
    return DURATION_UNKNOWN; //new Time(10.0);
  }

  public Object[] getControls() {
    return new Object[0];
  }

  public Object getControl(String type) {
    return null;
  }
  
  public boolean sourceStreamNotDone(){
	  try{
		  return streams[0].isNotDone();
	  }catch(Exception e){
		  return false;
	  }
	  
  }
}







