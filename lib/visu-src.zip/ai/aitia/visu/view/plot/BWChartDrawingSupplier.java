package ai.aitia.visu.view.plot;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;

import org.jfree.chart.plot.DefaultDrawingSupplier;

public class BWChartDrawingSupplier extends DefaultDrawingSupplier implements IBasicSupplier {

	private static final long serialVersionUID = 1L;
	
	private Stroke[] modifiedStrokeSequence = null;
	private int modifiedStrokeIndex = 0;

	/** Constructor. */
	public BWChartDrawingSupplier() {
		this(createDefaultPaintArray(),
			 DEFAULT_OUTLINE_PAINT_SEQUENCE,
			 createDefaultStrokeArray(),
			 DEFAULT_OUTLINE_STROKE_SEQUENCE,
			 DEFAULT_SHAPE_SEQUENCE);
	}

	//-------------------------------------------------------------------------------
	/** Constructor.
     * @param paintSequence  the fill paint sequence.
     * @param outlinePaintSequence  the outline paint sequence.
     * @param strokeSequence  the stroke sequence.
     * @param outlineStrokeSequence  the outline stroke sequence.
     * @param shapeSequence  the shape sequence.
	 */
	public BWChartDrawingSupplier(Paint[] paintSequence,
			Paint[] outlinePaintSequence, Stroke[] strokeSequence,
			Stroke[] outlineStrokeSequence, Shape[] shapeSequence) {
		super(paintSequence, outlinePaintSequence, strokeSequence,
				outlineStrokeSequence, shapeSequence);
	}

	//-------------------------------------------------------------------------------
    /**
     * Convenience method to return an array of <code>Paint</code> objects that
     * represent the black an grey colors. 
     * @return An array of objects with the <code>Paint</code> interface.
     */
 	public static Paint[] createDefaultPaintArray() {
        return new Paint[] { Color.BLACK, Color.LIGHT_GRAY };
	}
 	
 	//--------------------------------------------------------------------------------
 	/**
 	 * Convenience method to return an array of <code>Stroke</code> objects.
 	 * @return An array of objects with the <code>Stroke</code> interface.
 	 */
 	public static Stroke[] createDefaultStrokeArray() {
 		return new Stroke[] {
 				new BasicStroke(2.0f), // 0
 				new BasicStroke(2.0f), // 1
 				new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {20.0f, 10.0f}, 0.0f), // 2
 				new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {16.0f, 8.0f}, 0.0f), // 3
 				new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {12.0f, 6.0f}, 0.0f), // 4
 				new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {8.0f, 6.0f}, 0.0f), // 5
 				new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {4.0f, 6.0f}, 0.0f), // 6
 				new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {1.0f, 1.0f}, 0.0f), // 7
 				new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {1.0f, 2.0f}, 0.0f), // 8
 				new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {1.0f, 3.0f}, 0.0f), // 9
 		};
 	}
 	
 	//--------------------------------------------------------------------------------
 	/** 
 	 * This method decrements the width of the lines.
 	 */
 	public void setThinLines() {
 		this.modifiedStrokeSequence = new Stroke[] {
 				new BasicStroke(0.5f), // 0
 				new BasicStroke(0.5f), // 1
 				new BasicStroke(0.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {20.0f, 10.0f}, 0.0f), // 2
 				new BasicStroke(0.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {16.0f, 8.0f}, 0.0f), // 3
 				new BasicStroke(0.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {12.0f, 6.0f}, 0.0f), // 4
 				new BasicStroke(0.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {8.0f, 6.0f}, 0.0f), // 5
 				new BasicStroke(0.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {4.0f, 6.0f}, 0.0f), // 6
 				new BasicStroke(0.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {1.0f, 1.0f}, 0.0f), // 7
 				new BasicStroke(0.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {1.0f, 2.0f}, 0.0f), // 8
 				new BasicStroke(0.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f, new float[] {1.0f, 3.0f}, 0.0f), // 9
 		};
 	}
 	
 	//------------------------------------------------------------------------------
 	
 	@Override
    public Stroke getNextStroke() {
    	if (modifiedStrokeSequence != null) {
    		Stroke result = this.modifiedStrokeSequence[
    		   this.modifiedStrokeIndex % this.modifiedStrokeSequence.length
    		];
    		this.modifiedStrokeIndex++;
    		return result;
    	} else return super.getNextStroke(); 
    }

 }
