/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.ds;

import java.util.Properties;

import org.jfree.chart.ChartPanel;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetChangeListener;

import ai.aitia.visu.VisualisationException;
import ai.aitia.visu.data.Grid2DDataset;
import ai.aitia.visu.data.ScalarMapGrid2DDataset;
import ai.aitia.visu.data.DefaultGrid2DDataset;
import ai.aitia.visu.view.ChartFactory;
import ai.aitia.visu.view.meta.Grid2DMetadata;

@Deprecated
public class WrapperGrid2DDatasetProducer implements IDatasetProducer, DatasetChangeListener {

	private IDatasetProducer kernel = null;
	private WrapperGrid2DDatasetProducer partner = null;
	private Grid2DDataset dataset = null;
	private Grid2DMetadata metadata = null;
	private boolean for_colors = true;
	private long time = 0;
	private ChartPanel chartPanel = null;
	
	public WrapperGrid2DDatasetProducer(IDatasetProducer kernel, Grid2DMetadata metadata, boolean for_colors) {
		time = System.currentTimeMillis();
		this.kernel = kernel;
		this.metadata = metadata;
		this.for_colors = for_colors;
	}
	
	public WrapperGrid2DDatasetProducer(IDatasetProducer kernel, WrapperGrid2DDatasetProducer partner) {
		this(kernel, partner.getMetadata(),!partner.getFor_colors());
		setPartner(partner);
	}
	
	public boolean getFor_colors() {
		return for_colors;
	}

	public Grid2DMetadata getMetadata() {
		return metadata;
	}
	
	public void setChartPanel(ChartPanel chartPanel) {
		this.chartPanel = chartPanel;
	}
	
	public void setPartner(WrapperGrid2DDatasetProducer partner) {
		this.partner = partner;
	}
	
	public long getTime() {
		return time;
	}
	
	public void updateDataset(Grid2DDataset dataset) {
		if (this.dataset != null) this.dataset.removeChangeListener(this);
		this.dataset = dataset;
		this.dataset.addChangeListener(this);
	}

	public Grid2DDataset produceDataset(Properties queryProperties)
			throws DataSourceException {
		if (partner == null) throw new DataSourceException("Missing partner");
		if (dataset == null) {
				dataset = (Grid2DDataset)kernel.produceDataset(null);
				dataset.addChangeListener(this);
		}
		return dataset;
	}

	public void datasetChanged(DatasetChangeEvent event) {
		Grid2DDataset myDataset = null, partnerDataset = null;
		try {
			myDataset = (Grid2DDataset)kernel.produceDataset(null);
			partnerDataset = (Grid2DDataset)partner.produceDataset(null);
		} catch (DataSourceException e) {
			// wrong own or partner dataset => no update
			return;
		}

		int mw = myDataset.getWidth();
		int mh = myDataset.getHeight();
		
		int pw = partnerDataset.getWidth();
		int ph = partnerDataset.getHeight();
		
		boolean need_modify = (mw != pw || mh != ph); 
		
		if (!need_modify) {
			dataset.removeChangeListener(this);
			dataset = myDataset;
			dataset.addChangeListener(this);
		} else {
		
			int maxw = (mw>pw ? mw : pw);
			int maxh = (mh>ph ? mh : ph);
			
			if (myDataset instanceof ScalarMapGrid2DDataset) {
				((ScalarMapGrid2DDataset)myDataset).setWidth(maxw);
				((ScalarMapGrid2DDataset)myDataset).setHeight(maxh);
				((ScalarMapGrid2DDataset)partnerDataset).setWidth(maxw);
				((ScalarMapGrid2DDataset)partnerDataset).setHeight(maxh);
				
			} else {
				if (maxw != mw || maxh != mh) {
					double[][] my_new_values = defaultValues(maxw,maxh);
					double[][] my_old_values = myDataset.getValues();
					for (int i=0;i<mw;++i)
						for (int j=0;j<mh;++j)
							my_new_values[i][j] = my_old_values[i][j];
					((DefaultGrid2DDataset)myDataset).setValues(my_new_values);
				}
				if (maxw != pw || maxh != ph) {
					double[][] partner_new_values = defaultValues(maxw,maxh);
					double[][] partner_old_values = partnerDataset.getValues();
					for (int i=0;i<pw;++i)
						for (int j=0;j<ph;++j)
							partner_new_values[i][j] = partner_old_values[i][j];
					((DefaultGrid2DDataset)partnerDataset).setValues(partner_new_values);
				}
			}
			dataset.removeChangeListener(this);
			dataset = myDataset;
			dataset.addChangeListener(this);
			partner.updateDataset(partnerDataset);
		}
		time = kernel.getTime();
		if (need_modify) {
			ChartPanel new_panel = null;
			try {
				if (for_colors) new_panel = ChartFactory.createCompositeGrid2DChart(kernel,partner,metadata);
				else new_panel = ChartFactory.createCompositeGrid2DChart(partner,kernel,metadata);
			} catch (VisualisationException e) {
				// if the new chart is wrong => no update
				return;
			}
			chartPanel.setChart(new_panel.getChart());
		} else if (chartPanel != null) 
			chartPanel.getChart().getPlot().datasetChanged(event);
	}
	
	private double[][] defaultValues(int width, int height) {
		double[][] values = new double[width][height];
		for (int i=0;i<width;++i) 
			for (int j=0;j<height;++j)
				values[i][j] = - Double.MAX_VALUE;
		return values;
	}
}
