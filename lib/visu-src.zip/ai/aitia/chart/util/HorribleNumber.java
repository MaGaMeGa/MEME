package ai.aitia.chart.util;

import java.util.ArrayList;
import java.util.List;

public class HorribleNumber extends Number {
	
	//====================================================================================================
	// members
	
	private static final long serialVersionUID = 1L;
	List<Number> numbers = new ArrayList<Number>(); 
	
	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public HorribleNumber() {}
	
	//----------------------------------------------------------------------------------------------------
	public HorribleNumber(List<Number> numbers) {
		this.numbers = numbers;
	}
	
	//----------------------------------------------------------------------------------------------------
	public List<Number> getNumbers() { return numbers; }
	@Override public double doubleValue() { throw new UnsupportedOperationException(); }
	@Override public float floatValue() { throw new UnsupportedOperationException(); }
	@Override public int intValue() { throw new UnsupportedOperationException(); }
	@Override public long longValue() {	throw new UnsupportedOperationException(); }
}