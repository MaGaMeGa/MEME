/*
 * @(#)QuaquaIconFactory.java  2.1 2006-02-14
 *
 * Copyright (c) 2005 Werner Randelshofer
 * Staldenmattweg 2, Immensee, CH-6405, Switzerland.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Werner Randelshofer. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Werner Randelshofer.
 */

package contrib.ch.randelshofer.quaqua;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.plaf.IconUIResource;

import contrib.ch.randelshofer.quaqua.util.Images;

/**
 * QuaquaIconFactory.
 *
 * @author  Werner Randelshofer
 * @version 2.1 2006-02-14 Added method createFrameButtonStateIcon. 
 * <br>2.0 2006-02-12 Added methods createApplicationIcon, compose,
 * createOptionPaneIcon. These methods were contributed by Christopher Atlan.
 * <br>1.0 December 4, 2005 Created.
 */
public class QuaquaIconFactory {
    private static BufferedImage applicationImage;
    
    /**
     * Prevent instance creation.
     */
    private QuaquaIconFactory() {
    }
    
    public static URL getResource(String location) {
        URL url = QuaquaIconFactory.class.getResource(location);
        if (url == null) {
            throw new InternalError("image resource missing: "+location);
        }
        return url;
    }
    
    public static Image createImage(String location) {
        return createImage(QuaquaIconFactory.class, location);
    }
    public static Image createImage(Class baseClass, String location) {
        return Toolkit.getDefaultToolkit().createImage(baseClass.getResource(location));
    }
    public static Image createBufferedImage(String location) {
        return Images.toBufferedImage(createImage(location));
    }
    
    public static Icon[] createIcons(String location, int count, boolean horizontal) {
        Icon[] icons = new Icon[count];
        
        BufferedImage[] images = Images.split(
        (Image) createImage(location),
        count, horizontal
        );
        
        for (int i=0; i < count; i++) {
            icons[i] = new IconUIResource(new ImageIcon(images[i]));
        }
        return icons;
    }
    
    public static Icon createIcon(String location, int count, boolean horizontal, int index) {
        return createIcons(location, count, horizontal)[index];
    }
    
    
    public static Icon createButtonStateIcon(String location, int states) {
        return new ButtonStateIcon(
        (Image) createImage(location),
        states, true
        );
    }


    public static Icon createIcon(Class baseClass, String location) {
        return new ImageIcon(createImage(baseClass, location));
    }
}
