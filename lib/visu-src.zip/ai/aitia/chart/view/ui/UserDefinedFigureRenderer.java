/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.view.ui;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.ImageIcon;

import ai.aitia.visu.data.sequence.Element;
import ai.aitia.visu.utils.Interval;
import ai.aitia.visu.view.ui.IElementRenderer;
import ai.aitia.visu.view.ui.IFigureRenderer;

/** Renderer class for user defined shape- and element renderers. */
public class UserDefinedFigureRenderer implements IFigureRenderer, IElementRenderer {
	
	//====================================================================================================
	// inner classes
	
	//----------------------------------------------------------------------------------------------------
	/** Generic representation of a triplet. */
	public static class Triplet<K,V,W>  {
		
		protected K	first;
		protected V second;
		protected W third;

		public Triplet() { first = null; second = null; third = null; }
		public Triplet(K first, V second, W third) { this.first = first; this.second = second; this.third = third; }

		public K getKey()					{ return first; } 
		public K getFirst()					{ return first; }
		public V getSecond()				{ return second; }
		public W getThird()					{ return third; }

		public K setFirst(K key)			{ K ans = first; first = key; return ans; }
		public V setSecond(V value)			{ V ans = second; second = value; return ans; }
		public W setThird(W value)			{ W ans = third; third = value; return ans; }
		public void set(K key, V value1, W value2)	{ first = key; second = value1; third = value2; }
		@Override public int hashCode()	{ return java.util.Arrays.hashCode(new Object[] { first,second,third }); }
		@Override
		public boolean equals(Object o) {
			if (o == this) return true;
			if (o instanceof Triplet) {
				Triplet that = (Triplet)o;
				return (this.first == null ? that.first == null : this.first.equals(that.first)) &&
					   (this.second == null ? that.second == null : this.second.equals(that.second)) &&
					   (this.third == null ? that.third == null : this.third.equals(that.third));
			}
			return false;
		}
		@Override
		public String toString() {
			Object tmp[] = { first, second, third };
			return java.util.Arrays.toString(tmp);
		}
	}

	//====================================================================================================
	// members
	
	/** String id of the 'empty' figure. */
	public static final String DEFAULT   = "";
	
	/** String id of the circle figure. */
	public static final String CIRCLE	 = "CIRCLE";
	
	/** String id of the rectangle figure. */
	public static final String RECTANGLE = "RECTANGLE";
	
	/** String id of the triangle figure. */
	public static final String TRIANGLE	 = "TRIANGLE";
	
	/** Storage of interval-figure-color triplets where figures represented by strings.
	 *  This representation can be a constant name of a predefined figure or a path of an
	 *  image. */
	private List<Triplet<Interval,String,Color>> map = null;
	
	/** Default icon. */
	private ImageIcon defaultIcon = null;
	
	/** Cache for icons. */
	private HashMap<String,ImageIcon> cache = null;
	
	/** Default color of figures. */
	private Color defaultColor = Color.BLACK;
	
	private String name = "";
	
	//===============================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	/** Constructor. */
	public UserDefinedFigureRenderer() {
		map = new ArrayList<Triplet<Interval,String,Color>>();
		cache = new HashMap<String, ImageIcon>();
		URL imageURL = UserDefinedFigureRenderer.class.getResource("/icons/defaulticon.png");
		if (imageURL != null) defaultIcon = new ImageIcon(imageURL);
	}
	
	//--------------------------------------------------------------------------------
	/** Constructor.
	 * @param intervals array of intervals
	 * @param shapes array of string ids of figures
	 */
	public UserDefinedFigureRenderer(Interval[] intervals, String[] shapes) {
		this();
		if (intervals.length != shapes.length) 
			throw new IllegalArgumentException();
		for (int i=0;i<intervals.length;++i) 
			map.add(new Triplet<Interval,String,Color>(intervals[i],shapes[i],null));
	}
	
	//--------------------------------------------------------------------------------
	/** Constructor.
	 * @param intervals array of intervals
	 * @param shapes array of string ids of figures
	 * @param colors array of colors
	 */
	public UserDefinedFigureRenderer(Interval[] intervals, String[] shapes, Color[] colors) {
		this();
		if (intervals.length != shapes.length && intervals.length != colors.length)
			throw new IllegalArgumentException();
		for (int i=0;i<intervals.length;++i) 
			map.add(new Triplet<Interval,String,Color>(intervals[i],shapes[i],colors[i]));
	}
	
	//--------------------------------------------------------------------------------
	/** Adds to the storage the <code>intv</code>, <code>figure</code> pair.
	 * @param intv interval
	 * @param figure string id (or path) of a figure
	 */ 
	public void addFigure(Interval intv, String figure) {
		addEntry(intv,figure,null);
	}
	
	//--------------------------------------------------------------------------------
	/** Adds to the storage the <code>intv</code>, <code>figure</code>, <code>color</code>
	 *  triplet.
	 * @param intv interval
	 * @param figure figure
	 * @param color color
	 */
	public void addEntry(Interval intv, String figure, Color color) {
		Triplet<Interval,String,Color> t = new Triplet<Interval,String,Color>(intv,figure,color);
		if (map.contains(t)) {
			int index = map.indexOf(t);
			map.set(index,t);
		} else map.add(t);
	}
	
	//--------------------------------------------------------------------------------
	/** Returns the string id (or path) of the figure binded to the <code>value</code>
	 *  (if any) or returns {@link #DEFAULT DEFAULT}.
	 * @param value value
	 */
	public String getFigure(double value) {
		for (int i = map.size() - 1;i >= 0;--i) {
			Interval intv = map.get(i).getKey();
			if (intv.contains(value))
				return map.get(i).getSecond() == null ? DEFAULT : map.get(i).getSecond();
		}
		return DEFAULT;
	}
	
	//--------------------------------------------------------------------------------
	/** Returns the color binded to the <code>value</code>
	 *  (if any) or returns {@link #defaultColor defaultColor}.
	 * @param value value
	 */
	public Color getColor(double value) {
		for (int i = map.size() - 1;i >= 0;--i) {
			Interval intv = map.get(i).getKey();
			if (intv.contains(value))
				return map.get(i).getThird() == null ? defaultColor : map.get(i).getThird();
		}
		return defaultColor;
	}
	
	//--------------------------------------------------------------------------------
	/** Returns the string id (or path) and the color binded to the interval <code>intv
	 *  </code>
	 * @param intv interval
	 */
	public Object[] getFigureAndColor(Interval intv) {
		for (int i = map.size() - 1;i >= 0;--i) {
			if (map.get(i).getKey().equals(intv)) 
				return new Object[] { map.get(i).getSecond(), map.get(i).getThird() };
		}
		return null;
	}
	
	//--------------------------------------------------------------------------------
	/** Returns whether the renderer contains valid figure or not. */
	public boolean containsFigure() {
		for (Triplet<Interval,String,Color> p : map) {
			if (p.getSecond() != null)
				return true;
		}
		return false;
	}
	
	//----------------------------------------------------------------------------------
	public boolean hasEntry(double level) {
		for (int i = map.size() - 1;i >= 0;--i) {
			Interval intv = map.get(i).getKey();
			if (intv.contains(level))
				return true;
		}
		return false;
	}

	
	//-------------------------------------------------------------------------------
	public String getName() { return name; }
	/** Returns the default icon.
	 * @return the default icon
	 */
	public ImageIcon getDefaultIcon() {	return defaultIcon; }
	/** Returns the default color of the figures
	 * @return the default colr of the figures
	 */
	public Color getDefaultColor() { return defaultColor; }
	/** Returns the storage.
	 * @return the storage
	 */
	public List<Triplet<Interval,String,Color>> getMap() { return map;	}
	
	//----------------------------------------------------------------------------------------------------
	public void setName(String name) { this.name = name; }
	/** Sets the default color of the figures.
	 * @param color the new default color of the figures
	 */
	public void setDefaultColor(Color color) { this.defaultColor = color; }

	//====================================================================================================
	// implemented interfaces
	
	//--------------------------------------------------------------------------------
	/** Draws the figure or icon that is binded to the id value of the <code>element
	 *  </code>.
	 * @param g2d graphic context
	 * @param rect drawing area
	 * @param element element
	 */
	public void drawElement(Graphics2D g2d, Rectangle2D rect, Element element) {
		double width = rect.getWidth();
		double height = rect.getHeight();
		
		double x = rect.getX();
		double y = rect.getY();
		
		double d;
		
		if (height < width) {
			d = height;    		
			x = x + (width - d) / 2;
		} else {
			d = width;
			y = y + (height - d) / 2;    	
			
		}
		render(g2d,new Rectangle2D.Double(x,y,d,d),element.getValue());
	}
	
	//--------------------------------------------------------------------------------
	/** Draws the figure or icon that is binded to the <code>value</code>.
	 * @param g2d graphic context
	 * @param figureArea drawing area
	 * @param value value
	 */
	public void render(Graphics2D g2d, Rectangle2D figureArea, double value) {
		String figure = getFigure(value);
		if (figure.equals(DEFAULT)) return;
		else if (figure.equals(CIRCLE)) renderCircle(g2d,figureArea,getColor(value));
		else if (figure.equals(RECTANGLE)) renderRectangle(g2d,figureArea,getColor(value));
		else if (figure.equals(TRIANGLE)) renderTriangle(g2d,figureArea,getColor(value));
		else renderIcon(g2d,figureArea,figure);
	}
	
	//====================================================================================================
	// private methods
	
	//--------------------------------------------------------------------------------
	/** Draws a circle.
	 * @param g2d graphic context
	 * @param area drawing area
	 * @param color color of the circle
	 */
	protected void renderCircle(Graphics2D g2d, Rectangle2D area, Color color) {
		final double width = area.getWidth();
		final double height = area.getHeight();
		
		final double x = area.getX();
		final double y = area.getY();
		
		Ellipse2D.Double arc = new Ellipse2D.Double(x + width*0.2, y+height*0.2, width*0.6, height*0.6);
		
		g2d.setPaint(color);
		g2d.fill(arc);
//		g2d.setPaint(Color.BLACK);
//		g2d.draw(arc);
	}
	
	//--------------------------------------------------------------------------------
	/** Draws a rectangle.
	 * @param g2d graphic context
	 * @param area drawing area
	 * @param color color of the rectangle
	 */
	protected void renderRectangle(Graphics2D g2d, Rectangle2D area, Color color) {
		final double width = area.getWidth();
		final double height = area.getHeight();
		
		final double x = area.getX();
		final double y = area.getY();
		
		Rectangle2D.Double rect = new Rectangle2D.Double(x + width*0.2, y+height*0.2, width*0.6, height*0.6);
		
		g2d.setPaint(color);
		g2d.fill(rect);
//		g2d.setPaint(Color.BLACK);
//		g2d.draw(rect);
	}	
	
	//--------------------------------------------------------------------------------
	/** Draws a triangle.
	 * @param g2d graphic context
	 * @param area drawing area
	 * @param color color of the triangle
	 */
	protected void renderTriangle(Graphics2D g2d, Rectangle2D area, Color color) {

		final double width = area.getWidth();
		final double height = area.getHeight();
		
		final double x = area.getX();
		final double y = area.getY();
		
		Polygon tri = new Polygon();
		tri.addPoint((int)(x+width*0.5), (int)(y+height*0.2));
		tri.addPoint((int)(x+width*0.2), (int)(y+height*0.8));
		tri.addPoint((int)(x+width*0.8), (int)(y+height*0.8));
				
		g2d.setPaint(color);
		g2d.fill(tri);
//		g2d.setPaint(Color.BLACK);
//		g2d.draw(tri);
	}
	
	//--------------------------------------------------------------------------------
	/** Draws an icon.
	 * @param g2d graphic context
	 * @param area drawing area
	 * @param figure path of the icon image
	 */
	protected void renderIcon(Graphics2D g2d, Rectangle2D area, String figure) {
		ImageIcon ii = cache.get(figure);
		if (ii == null) {
			ii = new ImageIcon(figure);
			if (ii == null || ii.getIconWidth() == -1) ii = defaultIcon;
			cache.put(figure,ii);
		}
		if (ii == null) return;
		
		Image image = ii.getImage();

		final double width = area.getWidth();
		final double height = area.getHeight();
		final double x = area.getX();
		final double y = area.getY();
		
		g2d.drawImage(image,(int)(x + width*0.05),(int)(y + height*0.05),(int)(width*0.9),(int)(height*0.9),null);
	}
}