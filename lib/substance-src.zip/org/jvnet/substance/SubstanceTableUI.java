/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicTableUI;
import javax.swing.table.*;

import org.jvnet.lafwidget.LafWidgetUtilities;
import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.lafwidget.utils.FadeTracker.FadeTrackerCallback;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * UI for tables in <b>Substance</b> look and feel. Unfortunately, the entire
 * painting stack has been copied from {@link BasicTableUI} since the methods
 * are private. The animation effects are implemented in the
 * {@link #paintCell(Graphics, Rectangle, int, int)}.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceTableUI extends BasicTableUI {
	/**
	 * Name for the internal client property that holds the list of currently
	 * selected row-column indexes.
	 */
	public static String SELECTED_INDICES = "substancelaf.internal.tableSelectedIndices";

	/**
	 * Name for the internal client property that holds the currently
	 * rolled-over row-column index.
	 */
	public static String ROLLED_OVER_INDEX = "substancelaf.internal.tableRolledOverIndex";

	/**
	 * Map of default renderers.
	 */
	protected Map<Class<?>, TableCellRenderer> defaultRenderers;

	/**
	 * Listener that listens to changes on
	 * {@link SubstanceLookAndFeel#WATERMARK_TO_BLEED} property.
	 */
	protected PropertyChangeListener substancePropertyChangeListener;

	/**
	 * Listener for fade animations on list selections.
	 */
	protected ListSelectionListener substanceFadeSelectionListener;

	/**
	 * Listener for fade animations on table rollovers.
	 */
	protected RolloverFadeListener substanceFadeRolloverListener;

	/**
	 * Delegate for painting the background.
	 */
	private static SubstanceGradientBackgroundDelegate backgroundDelegate = new SubstanceGradientBackgroundDelegate();

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new SubstanceTableUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTableUI#installDefaults()
	 */
	@Override
	protected void installDefaults() {
		super.installDefaults();
		if (SubstanceCoreUtilities.toBleedWatermark(this.table))
			this.table.setOpaque(false);

		// fix for defect 117 - need to restore default table cell
		// renderers when Substance is unset
		this.defaultRenderers = new HashMap<Class<?>, TableCellRenderer>();

		Class[] defClasses = new Class[] { Object.class, Icon.class,
				ImageIcon.class, Number.class, Float.class, Double.class,
				Date.class, Boolean.class };
		for (Class clazz : defClasses) {
			this.defaultRenderers.put(clazz, this.table
					.getDefaultRenderer(clazz));
		}

		// Override default renderers
		this.table.setDefaultRenderer(Object.class,
				new SubstanceDefaultTableCellRenderer());
		this.table.setDefaultRenderer(Icon.class,
				new SubstanceDefaultTableCellRenderer.IconRenderer());
		this.table.setDefaultRenderer(ImageIcon.class,
				new SubstanceDefaultTableCellRenderer.IconRenderer());
		this.table.setDefaultRenderer(Number.class,
				new SubstanceDefaultTableCellRenderer.NumberRenderer());
		this.table.setDefaultRenderer(Float.class,
				new SubstanceDefaultTableCellRenderer.DoubleRenderer());
		this.table.setDefaultRenderer(Double.class,
				new SubstanceDefaultTableCellRenderer.DoubleRenderer());
		this.table.setDefaultRenderer(Date.class,
				new SubstanceDefaultTableCellRenderer.DateRenderer());
		// fix for bug 56 - making default renderer for Boolean a check box.
		this.table.setDefaultRenderer(Boolean.class,
				new SubstanceDefaultTableCellRenderer.BooleanRenderer());

		Map<TableCellId, Object> selected = new HashMap<TableCellId, Object>();
		int rows = this.table.getRowCount();
		int cols = this.table.getColumnCount();
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (this.table.isCellSelected(i, j)) {
					selected.put(new TableCellId(i, j), this.table.getValueAt(
							i, j));
				}
			}
		}
		this.table.putClientProperty(SubstanceTableUI.SELECTED_INDICES,
				selected);
	}

	@Override
	protected void uninstallDefaults() {
		// fix for defect 117 - need to restore default table cell
		// renderers when Substance is unset
		for (Map.Entry<Class<?>, TableCellRenderer> entry : this.defaultRenderers
				.entrySet()) {
			this.table.setDefaultRenderer(entry.getKey(), entry.getValue());
		}

		this.table.putClientProperty(SubstanceTableUI.SELECTED_INDICES, null);

		super.uninstallDefaults();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTableUI#installListeners()
	 */
	@Override
	protected void installListeners() {
		super.installListeners();
		this.substancePropertyChangeListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if (SubstanceLookAndFeel.WATERMARK_TO_BLEED.equals(evt
						.getPropertyName())) {
					table.setOpaque(!SubstanceCoreUtilities
							.toBleedWatermark(table));
				}

				if ("columnSelectionAllowed".equals(evt.getPropertyName())
						|| "rowSelectionAllowed".equals(evt.getPropertyName())) {
					syncSelection();
				}
			}
		};
		this.table
				.addPropertyChangeListener(this.substancePropertyChangeListener);

		// Add listener for the selection animation
		this.substanceFadeSelectionListener = new TableSelectionListener();
		this.table.getSelectionModel().addListSelectionListener(
				this.substanceFadeSelectionListener);
		this.table.getColumnModel().getSelectionModel()
				.addListSelectionListener(this.substanceFadeSelectionListener);

		// Add listener for the fade animation
		this.substanceFadeRolloverListener = new RolloverFadeListener();
		this.table.addMouseMotionListener(this.substanceFadeRolloverListener);
		this.table.addMouseListener(this.substanceFadeRolloverListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTableUI#uninstallListeners()
	 */
	@Override
	protected void uninstallListeners() {
		this.table
				.removePropertyChangeListener(this.substancePropertyChangeListener);
		this.substancePropertyChangeListener = null;

		this.table.getSelectionModel().removeListSelectionListener(
				this.substanceFadeSelectionListener);
		this.table.getColumnModel().getSelectionModel()
				.removeListSelectionListener(
						this.substanceFadeSelectionListener);
		this.substanceFadeSelectionListener = null;

		// Remove listener for the fade animation
		this.table
				.removeMouseMotionListener(this.substanceFadeRolloverListener);
		this.table.removeMouseListener(this.substanceFadeRolloverListener);
		this.substanceFadeRolloverListener = null;

		super.uninstallListeners();
	}

	/**
	 * Paint a representation of the <code>table</code> instance that was set
	 * in installUI().
	 */
	public void paint(Graphics g, JComponent c) {
		Rectangle clip = g.getClipBounds();

		Rectangle bounds = table.getBounds();
		// account for the fact that the graphics has already been translated
		// into the table's bounds
		bounds.x = bounds.y = 0;

		if (table.getRowCount() <= 0 || table.getColumnCount() <= 0 ||
		// this check prevents us from painting the entire table
				// when the clip doesn't intersect our bounds at all
				!bounds.intersects(clip)) {

			return;
		}

		Point upperLeft = clip.getLocation();
		Point lowerRight = new Point(clip.x + clip.width - 1, clip.y
				+ clip.height - 1);
		int rMin = table.rowAtPoint(upperLeft);
		int rMax = table.rowAtPoint(lowerRight);
		// This should never happen (as long as our bounds intersect the clip,
		// which is why we bail above if that is the case).
		if (rMin == -1) {
			rMin = 0;
		}
		// If the table does not have enough rows to fill the view we'll get -1.
		// (We could also get -1 if our bounds don't intersect the clip,
		// which is why we bail above if that is the case).
		// Replace this with the index of the last row.
		if (rMax == -1) {
			rMax = table.getRowCount() - 1;
		}

		boolean ltr = table.getComponentOrientation().isLeftToRight();
		int cMin = table.columnAtPoint(ltr ? upperLeft : lowerRight);
		int cMax = table.columnAtPoint(ltr ? lowerRight : upperLeft);
		// This should never happen.
		if (cMin == -1) {
			cMin = 0;
		}
		// If the table does not have enough columns to fill the view we'll get
		// -1.
		// Replace this with the index of the last column.
		if (cMax == -1) {
			cMax = table.getColumnCount() - 1;
		}

		// Paint the grid.
		paintGrid(g, rMin, rMax, cMin, cMax);

		// Paint the cells.
		paintCells(g, rMin, rMax, cMin, cMax);
	}

	/**
	 * Paints the grid lines within <I>aRect</I>, using the grid color set with
	 * <I>setGridColor</I>. Paints vertical lines if
	 * <code>getShowVerticalLines()</code> returns true and paints horizontal
	 * lines if <code>getShowHorizontalLines()</code> returns true.
	 */
	private void paintGrid(Graphics g, int rMin, int rMax, int cMin, int cMax) {
		g.setColor(table.getGridColor());

		Rectangle minCell = table.getCellRect(rMin, cMin, true);
		Rectangle maxCell = table.getCellRect(rMax, cMax, true);
		Rectangle damagedArea = minCell.union(maxCell);

		if (table.getShowHorizontalLines()) {
			int tableWidth = damagedArea.x + damagedArea.width;
			int y = damagedArea.y;
			for (int row = rMin; row <= rMax; row++) {
				y += table.getRowHeight(row);
				g.drawLine(damagedArea.x, y - 1, tableWidth - 1, y - 1);
			}
		}
		if (table.getShowVerticalLines()) {
			TableColumnModel cm = table.getColumnModel();
			int tableHeight = damagedArea.y + damagedArea.height;
			int x;
			if (table.getComponentOrientation().isLeftToRight()) {
				x = damagedArea.x;
				for (int column = cMin; column <= cMax; column++) {
					int w = cm.getColumn(column).getWidth();
					x += w;
					g.drawLine(x - 1, 0, x - 1, tableHeight - 1);
				}
			} else {
				x = damagedArea.x + damagedArea.width;
				for (int column = cMin; column < cMax; column++) {
					int w = cm.getColumn(column).getWidth();
					x -= w;
					g.drawLine(x - 1, 0, x - 1, tableHeight - 1);
				}
				x -= cm.getColumn(cMax).getWidth();
				g.drawLine(x, 0, x, tableHeight - 1);
			}
		}
	}

	private int viewIndexForColumn(TableColumn aColumn) {
		TableColumnModel cm = table.getColumnModel();
		for (int column = 0; column < cm.getColumnCount(); column++) {
			if (cm.getColumn(column) == aColumn) {
				return column;
			}
		}
		return -1;
	}

	private void paintCells(Graphics g, int rMin, int rMax, int cMin, int cMax) {
		JTableHeader header = table.getTableHeader();
		TableColumn draggedColumn = (header == null) ? null : header
				.getDraggedColumn();

		TableColumnModel cm = table.getColumnModel();
		int columnMargin = cm.getColumnMargin();

		Rectangle cellRect;
		TableColumn aColumn;
		int columnWidth;
		if (table.getComponentOrientation().isLeftToRight()) {
			for (int row = rMin; row <= rMax; row++) {
				cellRect = table.getCellRect(row, cMin, false);
				for (int column = cMin; column <= cMax; column++) {
					aColumn = cm.getColumn(column);
					columnWidth = aColumn.getWidth();
					cellRect.width = columnWidth - columnMargin;
					if (aColumn != draggedColumn) {
						paintCell(g, cellRect, row, column);
					}
					cellRect.x += columnWidth;
				}
			}
		} else {
			for (int row = rMin; row <= rMax; row++) {
				cellRect = table.getCellRect(row, cMin, false);
				aColumn = cm.getColumn(cMin);
				if (aColumn != draggedColumn) {
					columnWidth = aColumn.getWidth();
					cellRect.width = columnWidth - columnMargin;
					paintCell(g, cellRect, row, cMin);
				}
				for (int column = cMin + 1; column <= cMax; column++) {
					aColumn = cm.getColumn(column);
					columnWidth = aColumn.getWidth();
					cellRect.width = columnWidth - columnMargin;
					cellRect.x -= columnWidth;
					if (aColumn != draggedColumn) {
						paintCell(g, cellRect, row, column);
					}
				}
			}
		}

		// Paint the dragged column if we are dragging.
		if (draggedColumn != null) {
			paintDraggedArea(g, rMin, rMax, draggedColumn, header
					.getDraggedDistance());
		}

		// Remove any renderers that may be left in the rendererPane.
		rendererPane.removeAll();
	}

	private void paintDraggedArea(Graphics g, int rMin, int rMax,
			TableColumn draggedColumn, int distance) {
		int draggedColumnIndex = viewIndexForColumn(draggedColumn);

		Rectangle minCell = table.getCellRect(rMin, draggedColumnIndex, true);
		Rectangle maxCell = table.getCellRect(rMax, draggedColumnIndex, true);

		Rectangle vacatedColumnRect = minCell.union(maxCell);

		// Paint a gray well in place of the moving column.
		g.setColor(table.getParent().getBackground());
		g.fillRect(vacatedColumnRect.x, vacatedColumnRect.y,
				vacatedColumnRect.width, vacatedColumnRect.height);

		// Move to the where the cell has been dragged.
		vacatedColumnRect.x += distance;

		// Fill the background.
		g.setColor(table.getBackground());
		g.fillRect(vacatedColumnRect.x, vacatedColumnRect.y,
				vacatedColumnRect.width, vacatedColumnRect.height);

		// Paint the vertical grid lines if necessary.
		if (table.getShowVerticalLines()) {
			g.setColor(table.getGridColor());
			int x1 = vacatedColumnRect.x;
			int y1 = vacatedColumnRect.y;
			int x2 = x1 + vacatedColumnRect.width - 1;
			int y2 = y1 + vacatedColumnRect.height - 1;
			// Left
			g.drawLine(x1 - 1, y1, x1 - 1, y2);
			// Right
			g.drawLine(x2, y1, x2, y2);
		}

		for (int row = rMin; row <= rMax; row++) {
			// Render the cell value
			Rectangle r = table.getCellRect(row, draggedColumnIndex, false);
			r.x += distance;
			paintCell(g, r, row, draggedColumnIndex);

			// Paint the (lower) horizontal grid line if necessary.
			if (table.getShowHorizontalLines()) {
				g.setColor(table.getGridColor());
				Rectangle rcr = table
						.getCellRect(row, draggedColumnIndex, true);
				rcr.x += distance;
				int x1 = rcr.x;
				int y1 = rcr.y;
				int x2 = x1 + rcr.width - 1;
				int y2 = y1 + rcr.height - 1;
				g.drawLine(x1, y2, x2, y2);
			}
		}
	}

	protected void paintCell(Graphics g, Rectangle cellRect, int row, int column) {
		Graphics2D g2d = (Graphics2D) g.create();
		g2d.setComposite(TransitionLayout.getAlphaComposite(this.table));

		Comparable cellId = new TableCellId(row, column);
		boolean isSelectedAnim = FadeTracker.getInstance().isTracked(
				this.table, cellId, FadeKind.SELECTION);
		boolean isRolloverAnim = FadeTracker.getInstance().isTracked(
				this.table, cellId, FadeKind.ROLLOVER);
		// System.out.println(row + ":" + column + " -> " + isRolloverAnim);
		Comparable currRoIndex = (Comparable) table
				.getClientProperty(ROLLED_OVER_INDEX);
		boolean isRollover = ((currRoIndex != null) && currRoIndex
				.equals(cellId));

		float alphaForBackground = 0.0f;
		// Support for selection animations (from 3.1)
		if (this.table.isCellSelected(row, column) || isSelectedAnim) {
			if (isSelectedAnim) {
				// set the alpha for selection animation
				float fadeCoef = FadeTracker.getInstance().getFade10(
						this.table, cellId, FadeKind.SELECTION);
				alphaForBackground = 0.7f * fadeCoef / 10.0f;
			} else {
				alphaForBackground = 0.7f;
			}
		}
		// Support for rollover animations (from 3.1)
		if (isRolloverAnim) {
			// set the alpha for rollover animation
			float fadeCoef = FadeTracker.getInstance().getFade10(this.table,
					cellId, FadeKind.ROLLOVER);
			// System.out.println("Has rollover anim on " + row + "["
			// + fadeCoef + "] : " + cx + ":" + cy + "-" + cw + ":"
			// + ch);
			alphaForBackground = Math.max(alphaForBackground,
					0.4f * fadeCoef / 10.0f);
		} else {
			if (isRollover) {
				alphaForBackground = Math.max(alphaForBackground, 0.4f);
			}
		}

		if (table.isEditing() && table.getEditingRow() == row
				&& table.getEditingColumn() == column) {
			Component component = table.getEditorComponent();
			if (alphaForBackground > 0.0f) {
				if (component != null) {
					g2d.setComposite(TransitionLayout.getAlphaComposite(
							this.table, alphaForBackground));
					backgroundDelegate.update(g2d, component, new Rectangle(
							cellRect.x, cellRect.y, cellRect.width,
							cellRect.height), SubstanceCoreUtilities.getTheme(
							this.table, true).getHighlightBackgroundTheme(),
							false);
					g2d.setComposite(TransitionLayout
							.getAlphaComposite(this.table));
				}
			}
			if (component instanceof JComponent) {
				// Play with opaqueness to make our own gradient background
				// on selected elements to show.
				JComponent jRenderer = (JComponent) component;
				synchronized (jRenderer) {
					boolean newOpaque = !(table.isCellSelected(row, column)
							|| isSelectedAnim || isRollover || isRolloverAnim);
					if (SubstanceCoreUtilities.toBleedWatermark(table))
						newOpaque = false;
					
					Map<Component, Boolean> opacity = new HashMap<Component, Boolean>();
					// System.out.println("Pre-painting at index " + row + " ["
					// +
					// value
					// + "] " + (rendererComponent.isOpaque() ? "opaque" :
					// "transparent")
					// + " with bg " + rendererComponent.getBackground());
					if (!newOpaque)
						SubstanceCoreUtilities
								.makeNonOpaque(component, opacity);
					// System.out.println("Painting at index " + row + " [" +
					// value
					// + "] " + (newOpaque ? "opaque" : "transparent")
					// + " with bg " + rendererComponent.getBackground());
					component.setBounds(cellRect);
					component.validate();
					// System.out.println("Painting at index " + row + " [" +
					// value
					// + "] " + (newOpaque ? "opaque" : "transparent")
					// + " with bg " + rendererComponent.getBackground());
					if (!newOpaque)
						SubstanceCoreUtilities
								.restoreOpaque(component, opacity);
					// System.out.println("Post-painting at index " + row + " ["
					// +
					// value
					// + "] " + (rendererComponent.isOpaque() ? "opaque" :
					// "transparent")
					// + " with bg " + rendererComponent.getBackground());
				}
			} else {
				component.setBounds(cellRect);
				component.validate();
			}

		} else {
			TableCellRenderer renderer = table.getCellRenderer(row, column);
			Component component = table.prepareRenderer(renderer, row, column);

			boolean isWatermarkBleed = SubstanceCoreUtilities
					.toBleedWatermark(table);
			if (!isWatermarkBleed) {
				if (component != null) {
					g2d.setColor(component.getBackground());
					g2d.fillRect(cellRect.x, cellRect.y, cellRect.width,
							cellRect.height);
				}
			}
			if (alphaForBackground > 0.0f) {
				if (component != null) {
					g2d.setComposite(TransitionLayout.getAlphaComposite(
							this.table, alphaForBackground));
					backgroundDelegate.update(g2d, component, new Rectangle(
							cellRect.x, cellRect.y, cellRect.width,
							cellRect.height), SubstanceCoreUtilities.getTheme(
							this.table, true).getHighlightBackgroundTheme(),
							false);
					g2d.setComposite(TransitionLayout
							.getAlphaComposite(this.table));
				}
			}

			if (component instanceof JComponent) {
				// Play with opaqueness to make our own gradient background
				// on selected elements to show.
				JComponent jRenderer = (JComponent) component;
				synchronized (jRenderer) {
					boolean newOpaque = !(table.isCellSelected(row, column)
							|| isSelectedAnim || isRollover || isRolloverAnim);
					if (SubstanceCoreUtilities.toBleedWatermark(table))
						newOpaque = false;

					Map<Component, Boolean> opacity = new HashMap<Component, Boolean>();
					// System.out.println("Pre-painting at index " + row + " ["
					// +
					// value
					// + "] " + (rendererComponent.isOpaque() ? "opaque" :
					// "transparent")
					// + " with bg " + rendererComponent.getBackground());
					if (!newOpaque)
						SubstanceCoreUtilities
								.makeNonOpaque(jRenderer, opacity);
					// System.out.println("Painting at index " + row + " [" +
					// value
					// + "] " + (newOpaque ? "opaque" : "transparent")
					// + " with bg " + rendererComponent.getBackground());
					this.rendererPane.paintComponent(g2d, component,
							this.table, cellRect.x, cellRect.y, cellRect.width,
							cellRect.height, true);
					// System.out.println("Painting at index " + row + " [" +
					// value
					// + "] " + (newOpaque ? "opaque" : "transparent")
					// + " with bg " + rendererComponent.getBackground());
					if (!newOpaque)
						SubstanceCoreUtilities
								.restoreOpaque(jRenderer, opacity);
					// System.out.println("Post-painting at index " + row + " ["
					// +
					// value
					// + "] " + (rendererComponent.isOpaque() ? "opaque" :
					// "transparent")
					// + " with bg " + rendererComponent.getBackground());
				}
			} else {
				this.rendererPane.paintComponent(g2d, component, this.table,
						cellRect.x, cellRect.y, cellRect.width,
						cellRect.height, true);
			}
		}
		g2d.dispose();
	}

	/**
	 * Repaints a single cell during the fade animation cycle.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class CellRepaintCallback implements FadeTrackerCallback {
		/**
		 * Associated table.
		 */
		protected JTable table;

		/**
		 * Associated (animated) row index.
		 */
		protected int rowIndex;

		/**
		 * Associated (animated) column index.
		 */
		protected int columnIndex;

		/**
		 * Creates a new animation repaint callback.
		 * 
		 * @param table
		 *            Associated table.
		 * @param rowIndex
		 *            Associated (animated) row index.
		 * @param columnIndex
		 *            Associated (animated) column index.
		 */
		public CellRepaintCallback(JTable table, int rowIndex, int columnIndex) {
			super();
			this.table = table;
			this.rowIndex = rowIndex;
			this.columnIndex = columnIndex;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadeEnded(org.jvnet.lafwidget.utils.FadeTracker.FadeKind)
		 */
		public void fadeEnded(FadeKind fadeKind) {
			this.repaintCell();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadePerformed(org.jvnet.lafwidget.utils.FadeTracker.FadeKind,
		 *      float)
		 */
		public void fadePerformed(FadeKind fadeKind, float fade10) {
			this.repaintCell();
		}

		/**
		 * Repaints the associated cell.
		 */
		private void repaintCell() {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					if (SubstanceTableUI.this.table == null) {
						// may happen if the LAF was switched in the meantime
						return;
					}
					int rowCount = table.getRowCount();
					int colCount = table.getColumnCount();
					if ((rowCount > 0)
							&& (CellRepaintCallback.this.rowIndex < rowCount)
							&& (colCount > 0)
							&& (CellRepaintCallback.this.columnIndex < colCount)) {
						// need to retrieve the cell rectangle since the cells
						// can be moved while animating
						Rectangle rect = table.getCellRect(
								CellRepaintCallback.this.rowIndex,
								CellRepaintCallback.this.columnIndex, true);
						CellRepaintCallback.this.table.repaint(rect);
					}
				}
			});
		}
	}

	/**
	 * Repaints a single row during the fade animation cycle.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class RowRepaintCallback implements FadeTrackerCallback {
		/**
		 * Associated table.
		 */
		protected JTable table;

		/**
		 * Associated (animated) row index.
		 */
		protected int rowIndex;

		/**
		 * Creates a new animation repaint callback.
		 * 
		 * @param table
		 *            Associated table.
		 * @param rowIndex
		 *            Associated (animated) row index.
		 */
		public RowRepaintCallback(JTable table, int rowIndex) {
			super();
			this.table = table;
			this.rowIndex = rowIndex;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadeEnded(org.jvnet.lafwidget.utils.FadeTracker.FadeKind)
		 */
		public void fadeEnded(FadeKind fadeKind) {
			this.repaintRow();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadePerformed(org.jvnet.lafwidget.utils.FadeTracker.FadeKind,
		 *      float)
		 */
		public void fadePerformed(FadeKind fadeKind, float fade10) {
			this.repaintRow();
		}

		/**
		 * Repaints the associated row.
		 */
		private void repaintRow() {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					if (SubstanceTableUI.this.table == null) {
						// may happen if the LAF was switched in the meantime
						return;
					}
					int rowCount = table.getRowCount();
					if ((rowCount > 0)
							&& (RowRepaintCallback.this.rowIndex < rowCount)) {
						// need to retrieve the cell rectangle since the cells
						// can be moved while animating
						Rectangle rect = table.getCellRect(
								RowRepaintCallback.this.rowIndex, 0, true);
						for (int i = 1; i < table.getColumnCount(); i++) {
							rect = rect.union(table.getCellRect(
									RowRepaintCallback.this.rowIndex, i, true));
						}
						RowRepaintCallback.this.table.repaint(rect);
					}
				}
			});
		}
	}

	/**
	 * Repaints a single column during the fade animation cycle.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class ColumnRepaintCallback implements FadeTrackerCallback {
		/**
		 * Associated table.
		 */
		protected JTable table;

		/**
		 * Associated (animated) column index.
		 */
		protected int columnIndex;

		/**
		 * Creates a new animation repaint callback.
		 * 
		 * @param table
		 *            Associated table.
		 * @param columnIndex
		 *            Associated (animated) column index.
		 */
		public ColumnRepaintCallback(JTable table, int columnIndex) {
			super();
			this.table = table;
			this.columnIndex = columnIndex;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadeEnded(org.jvnet.lafwidget.utils.FadeTracker.FadeKind)
		 */
		public void fadeEnded(FadeKind fadeKind) {
			this.repaintColumn();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadePerformed(org.jvnet.lafwidget.utils.FadeTracker.FadeKind,
		 *      float)
		 */
		public void fadePerformed(FadeKind fadeKind, float fade10) {
			this.repaintColumn();
		}

		/**
		 * Repaints the associated row.
		 */
		private void repaintColumn() {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					if (SubstanceTableUI.this.table == null) {
						// may happen if the LAF was switched in the meantime
						return;
					}
					int columnCount = table.getColumnCount();
					if ((columnCount > 0)
							&& (ColumnRepaintCallback.this.columnIndex < columnCount)) {
						// need to retrieve the cell rectangle since the cells
						// can be moved while animating
						Rectangle rect = table.getCellRect(0,
								ColumnRepaintCallback.this.columnIndex, true);
						for (int i = 1; i < table.getRowCount(); i++) {
							rect = rect.union(table.getCellRect(i,
									ColumnRepaintCallback.this.columnIndex,
									true));
						}
						ColumnRepaintCallback.this.table.repaint(rect);
					}
				}
			});
		}
	}

	/**
	 * ID of a single table cell.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected static class TableCellId implements Comparable {
		/**
		 * Cell row.
		 */
		protected int row;

		/**
		 * Cell column.
		 */
		protected int column;

		/**
		 * Creates a new cell ID.
		 * 
		 * @param row
		 *            Cell row.
		 * @param column
		 *            Cell column.
		 */
		public TableCellId(int row, int column) {
			this.row = row;
			this.column = column;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		public int compareTo(Object o) {
			if (o instanceof TableCellId) {
				TableCellId otherId = (TableCellId) o;
				if ((this.row == otherId.row)
						&& (this.column == otherId.column))
					return 0;
				return 1;
			}
			if (o instanceof TableRowId) {
				TableRowId otherId = (TableRowId) o;
				if (this.row == otherId.row)
					return 0;
				return 1;
			}
			if (o instanceof TableColumnId) {
				TableColumnId otherId = (TableColumnId) o;
				if (this.column == otherId.column)
					return 0;
				return 1;
			}
			return -1;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			return this.compareTo(obj) == 0;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			return (this.row ^ (this.row >>> 32))
					& (this.column ^ (this.column >>> 32));
		}
	}

	/**
	 * ID of a single table column.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected static class TableColumnId implements Comparable {
		/**
		 * Column.
		 */
		protected int column;

		/**
		 * Creates a new column ID.
		 * 
		 * @param column
		 *            Column.
		 */
		public TableColumnId(int column) {
			this.column = column;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		public int compareTo(Object o) {
			if (o instanceof TableCellId) {
				TableCellId otherId = (TableCellId) o;
				if (this.column == otherId.column)
					return 0;
				return 1;
			}
			if (o instanceof TableColumnId) {
				TableColumnId otherId = (TableColumnId) o;
				if (this.column == otherId.column)
					return 0;
				return 1;
			}
			return -1;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			return this.compareTo(obj) == 0;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			return (this.column ^ (this.column >>> 32));
		}
	}

	/**
	 * ID of a single table row.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected static class TableRowId implements Comparable {
		/**
		 * Row.
		 */
		protected int row;

		/**
		 * Creates a new row ID.
		 * 
		 * @param row
		 *            Row.
		 */
		public TableRowId(int row) {
			this.row = row;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		public int compareTo(Object o) {
			if (o instanceof TableCellId) {
				TableCellId otherId = (TableCellId) o;
				if (this.row == otherId.row)
					return 0;
				return 1;
			}
			if (o instanceof TableRowId) {
				TableRowId otherId = (TableRowId) o;
				if (this.row == otherId.row)
					return 0;
				return 1;
			}
			return -1;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			return this.compareTo(obj) == 0;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			return (this.row ^ (this.row >>> 32));
		}
	}

	/**
	 * Selection listener for selection animation effects.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class TableSelectionListener implements ListSelectionListener {
		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event.ListSelectionEvent)
		 */
		@SuppressWarnings("unchecked")
		public void valueChanged(ListSelectionEvent e) {
			syncSelection();
			// Map<TableCellId, Object> currSelected = (Map<TableCellId,
			// Object>) SubstanceTableUI.this.table
			// .getClientProperty(SubstanceTableUI.SELECTED_INDICES);
			// int rows = table.getRowCount();
			// int cols = table.getColumnCount();
			// for (int i = 0; i < rows; i++) {
			// for (int j = 0; j < cols; j++) {
			// TableCellId cellId = new TableCellId(i, j);
			// if (table.isCellSelected(i, j)) {
			// // check if was selected before
			// if (!currSelected.containsKey(cellId)) {
			// // start fading in
			// // System.out.println("Fade in on index " + i);
			// FadeTracker.getInstance().trackFadeIn(
			// FadeKind.SELECTION, table, cellId, false,
			// new CellRepaintCallback(table, i, j));
			// currSelected.put(cellId, table.getModel()
			// .getValueAt(i, j));
			// }
			// } else {
			// // check if was selected before and still points to
			// // the same element
			// if (currSelected.containsKey(cellId)) {
			// // corner case when the model returns null
			// Object oldValue = currSelected.get(cellId);
			// Object currValue = table.getValueAt(i, j);
			// boolean isSame = false;
			// if (oldValue == null) {
			// isSame = (currValue == null);
			// } else {
			// isSame = oldValue.equals(currValue);
			// }
			// if (isSame) {
			// // start fading out
			// System.out.println("Fade out on index " + i
			// + ":" + j);
			// FadeTracker.getInstance().trackFadeOut(
			// FadeKind.SELECTION, table, cellId,
			// false,
			// new CellRepaintCallback(table, i, j));
			// }
			// currSelected.remove(cellId);
			// }
			// }
			// }
			// }
		}
	}

	/**
	 * Listener for fade animations on table rollovers.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private class RolloverFadeListener implements MouseListener,
			MouseMotionListener {
		public void mouseClicked(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mousePressed(MouseEvent e) {
		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
			// if (SubstanceCoreUtilities.toBleedWatermark(list))
			// return;

			if (!table.isEnabled())
				return;
			this.fadeOut();
			// System.out.println("Nulling RO index");
			table.putClientProperty(ROLLED_OVER_INDEX, null);
		}

		public void mouseMoved(MouseEvent e) {
			// if (SubstanceCoreUtilities.toBleedWatermark(list))
			// return;

			if (!table.isEnabled())
				return;
			handleMove(e);
		}

		public void mouseDragged(MouseEvent e) {
			// if (SubstanceCoreUtilities.toBleedWatermark(list))
			// return;

			if (!table.isEnabled())
				return;
			handleMove(e);
		}

		/**
		 * Handles various mouse move events and initiates the fade animation if
		 * necessary.
		 * 
		 * @param e
		 *            Mouse event.
		 */
		private void handleMove(MouseEvent e) {
			int row = table.rowAtPoint(e.getPoint());
			int column = table.columnAtPoint(e.getPoint());
			if ((row < 0) || (row >= table.getRowCount()) || (column < 0)
					|| (column >= table.getColumnCount())) {
				this.fadeOut();
				// System.out.println("Nulling RO index");
				table.putClientProperty(ROLLED_OVER_INDEX, null);
			} else {
				// check if this is the same index
				Comparable newId = getId(row, column);
				Comparable currId = (Comparable) table
						.getClientProperty(ROLLED_OVER_INDEX);
				if ((currId != null) && newId.equals(currId))
					return;

				this.fadeOut();
				FadeTracker.getInstance().trackFadeIn(FadeKind.ROLLOVER, table,
						newId, false, getCallback(row, column));
				// System.out.println("Setting RO index to " + roIndex);
				table.putClientProperty(ROLLED_OVER_INDEX, newId);
			}
		}

		/**
		 * Initiates the fade out effect.
		 */
		private void fadeOut() {
			Comparable prevRoIndex = (Comparable) table
					.getClientProperty(ROLLED_OVER_INDEX);
			if (prevRoIndex == null)
				return;

			FadeTracker.getInstance().trackFadeOut(FadeKind.ROLLOVER, table,
					prevRoIndex, false, getCallback(prevRoIndex));
		}

	}

	private FadeTrackerCallback getCallback(int row, int column) {
		boolean hasRowSelection = table.getRowSelectionAllowed();
		boolean hasColumnSelection = table.getColumnSelectionAllowed();

		if (hasRowSelection && !hasColumnSelection)
			return new RowRepaintCallback(table, row);
		if (!hasRowSelection && hasColumnSelection)
			return new ColumnRepaintCallback(table, column);
		return new CellRepaintCallback(table, row, column);
	}

	private FadeTrackerCallback getCallback(Comparable comparable) {
		if (comparable instanceof TableRowId)
			return new RowRepaintCallback(table, ((TableRowId) comparable).row);
		if (comparable instanceof TableColumnId)
			return new ColumnRepaintCallback(table,
					((TableColumnId) comparable).column);
		return new CellRepaintCallback(table, ((TableCellId) comparable).row,
				((TableCellId) comparable).column);
	}

	private Comparable getId(int row, int column) {
		boolean hasRowSelection = table.getRowSelectionAllowed();
		boolean hasColumnSelection = table.getColumnSelectionAllowed();

		if (hasRowSelection && !hasColumnSelection)
			return new TableRowId(row);
		if (!hasRowSelection && hasColumnSelection)
			return new TableColumnId(column);
		return new TableCellId(row, column);
	}

	protected void syncSelection() {
		// optimization on large tables and large selections
		if (LafWidgetUtilities.hasNoFades(table, FadeKind.SELECTION))
			return;
		Map<TableCellId, Object> currSelected = (Map<TableCellId, Object>) SubstanceTableUI.this.table
				.getClientProperty(SubstanceTableUI.SELECTED_INDICES);
		int rows = table.getRowCount();
		int cols = table.getColumnCount();
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				TableCellId cellId = new TableCellId(i, j);
				if (table.isCellSelected(i, j)) {
					// check if was selected before
					if (!currSelected.containsKey(cellId)) {
						// start fading in
						// System.out.println("Fade in on " + i + ":" + j);
						FadeTracker.getInstance().trackFadeIn(
								FadeKind.SELECTION, table, cellId, false,
								new CellRepaintCallback(table, i, j));
						currSelected.put(cellId, table.getModel().getValueAt(i,
								j));
					}
				} else {
					// check if was selected before and still points
					// to the same element
					if (currSelected.containsKey(cellId)) {
						// corner case when the model returns null
						Object oldValue = currSelected.get(cellId);
						Object currValue = table.getValueAt(i, j);
						boolean isSame = false;
						if (oldValue == null) {
							isSame = (currValue == null);
						} else {
							isSame = oldValue.equals(currValue);
						}
						if (isSame) {
							// start fading out
							// System.out.println("Fade out on " + i + ":"
							// + j);
							FadeTracker.getInstance().trackFadeOut(
									FadeKind.SELECTION, table, cellId, false,
									new CellRepaintCallback(table, i, j));
						}
						currSelected.remove(cellId);
					}
				}
			}
		}

	}
}
