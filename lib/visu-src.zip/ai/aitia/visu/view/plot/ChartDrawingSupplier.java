/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.visu.view.plot;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;

import org.jfree.chart.ChartColor;
import org.jfree.chart.plot.DefaultDrawingSupplier;

/** It overrides the default color palette of the series to drop the yellow color,
 *  because the yellow lines on a white background are almost invisible. */ 
public class ChartDrawingSupplier extends DefaultDrawingSupplier implements IBasicSupplier {

	private static final long serialVersionUID = 1L;
	
	private Stroke modifiedStroke = null;

	/** Constructor. */
	public ChartDrawingSupplier() {
		this(createDefaultPaintArray(),
			 DEFAULT_OUTLINE_PAINT_SEQUENCE,
			 DEFAULT_STROKE_SEQUENCE,
			 DEFAULT_OUTLINE_STROKE_SEQUENCE,
			 DEFAULT_SHAPE_SEQUENCE);
	}

	//-------------------------------------------------------------------------------
	/** Constructor.
     * @param paintSequence  the fill paint sequence.
     * @param outlinePaintSequence  the outline paint sequence.
     * @param strokeSequence  the stroke sequence.
     * @param outlineStrokeSequence  the outline stroke sequence.
     * @param shapeSequence  the shape sequence.
	 */
	public ChartDrawingSupplier(Paint[] paintSequence,
			Paint[] outlinePaintSequence, Stroke[] strokeSequence,
			Stroke[] outlineStrokeSequence, Shape[] shapeSequence) {
		super(paintSequence, outlinePaintSequence, strokeSequence,
				outlineStrokeSequence, shapeSequence);
	}

	//-------------------------------------------------------------------------------
    /**
     * Convenience method to return an array of <code>Paint</code> objects that
     * represent the pre-defined colors in the <code>Color<code> and 
     * <code>ChartColor</code> objects.
     *
     * @return An array of objects with the <code>Paint</code> interface.
     */
 	public static Paint[] createDefaultPaintArray() {
        return new Paint[] {
                new Color(0xFF, 0x55, 0x55),
                new Color(0x55, 0x55, 0xFF),
                new Color(0x55, 0xFF, 0x55),
//                new Color(0xFF, 0xFF, 0x55),
                new Color(0xFF, 0x55, 0xFF),
                new Color(0x55, 0xFF, 0xFF),
                Color.pink,
                Color.gray,
                ChartColor.DARK_RED,
                ChartColor.DARK_BLUE,
                ChartColor.DARK_GREEN,
                ChartColor.DARK_YELLOW,
                ChartColor.DARK_MAGENTA,
                ChartColor.DARK_CYAN,
                Color.darkGray,
                ChartColor.LIGHT_RED,
                ChartColor.LIGHT_BLUE,
                ChartColor.LIGHT_GREEN,
                ChartColor.LIGHT_YELLOW,
                ChartColor.LIGHT_MAGENTA,
                ChartColor.LIGHT_CYAN,
                Color.lightGray,
                ChartColor.VERY_DARK_RED,
                ChartColor.VERY_DARK_BLUE,
                ChartColor.VERY_DARK_GREEN,
                ChartColor.VERY_DARK_YELLOW,
                ChartColor.VERY_DARK_MAGENTA,
                ChartColor.VERY_DARK_CYAN,
                ChartColor.VERY_LIGHT_RED,
                ChartColor.VERY_LIGHT_BLUE,
                ChartColor.VERY_LIGHT_GREEN,
                ChartColor.VERY_LIGHT_YELLOW,
                ChartColor.VERY_LIGHT_MAGENTA,
                ChartColor.VERY_LIGHT_CYAN
            };
	}

 	//------------------------------------------------------------------------------
	public void setThinLines() {
		this.modifiedStroke = new BasicStroke(0.5f,BasicStroke.CAP_SQUARE,BasicStroke.JOIN_BEVEL);
	}

	//------------------------------------------------------------------------------
	@Override
	public Stroke getNextStroke() {
		if (this.modifiedStroke != null) return this.modifiedStroke;
		return super.getNextStroke();
	}
}
