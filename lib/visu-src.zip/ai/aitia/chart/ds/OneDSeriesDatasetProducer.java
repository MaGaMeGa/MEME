/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.ds;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.jfree.data.general.Dataset;
import org.jfree.data.time.FixedMillisecond;
import org.jfree.data.time.TimeSeries;

import ai.aitia.chart.util.Utilities.IGridConstants;
import ai.aitia.visu.data.OneDSeriesDataset;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDatasetProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.event.IDataChangeListener;

/** Dataset producer for two-dimensional grids. */
public class OneDSeriesDatasetProducer implements IDatasetProducer,
											  IDataChangeListener,
											  IGridConstants {
	
	@SuppressWarnings("unused")
	private OneDSeriesDatasetProducer ds_producer = null;
	/** Time of the last update. */
	private long time;
	private ArrayList<TimeSeries> timeSeriesList;
	public static final int DEFAULT_MAXIMUM_ITEM_COUNT = 100;
	private int maxItemCount = DEFAULT_MAXIMUM_ITEM_COUNT;
	private int listLength=-1;
	
	/** The dataset that this object produces. */
	private OneDSeriesDataset dataset = null;
	
	/** Series producer for color/shape values. */
	private ISeriesProducer values = null;
	
	/** The current produced values for colors/shapes. */ 
	private List<Double> values_series = null;
	
	/** Series producer for column indices (used only in random mode). */
	private ISeriesProducer xs = null;
	
	/** The current produced values for column indices (used only in random mode). */
	@SuppressWarnings("unused")
	private List<Double> xs_series = null;
	
	/** Series producer for row indices (used only in random mode). */
	private ISeriesProducer ys = null;
	
	/** The current producer values for row indices (used only in random mode). */
	@SuppressWarnings("unused")
	private List<Double> ys_series = null;
	
	
	
	/** The current complete grid produced by <code>ds_producer</code>
	 * (used only in dataset mode). */
	@SuppressWarnings("unused")
	private double[][] ds_producer_dataset = new double[0][0];
	
	/** Flag that determines whether uses row order (left-to-right or column order
	 *  (top-to-bottom) when it places the values (used only in sequential mode). */
	private boolean row_order = true;
	
	/** Mode of the dataset producer object. (FULL_MODE, PARTIAL_MODE or DS_MODE. */
	private int mode = -1;
	
	int step=0;
	
	//===============================================================================
	// methods
	
	/** Constructor. It uses the ai.aitia.visu.data.DefaultGrid2DDataset implementation.
	 *  The content of the list parameter must be the follow:<br>
	 *    - a series producer that produces the color/shape values of the cells<br>
	 *    - an Integer value or a value producer for the width of the grid<br>
	 *    - an Integer value or a value producer for the height of the grid<p>
	 *    
	 *  If both width and height is a fix value then one of them must be non-negative. The 
	 *  other one can be computed from this one and the length of the series produced by
	 *  the series producer. If both of them are invalud then the constructor throws an
	 *  exception. 
	 *
	 * @param data list with contents described above
	 * @param row_order whether uses row order (left-to-right) or column order (top-to-bottom)
	 *        when it places the values
	 * @throws DataSourceException it throws this exception if it cannot construct the 
	 *         the dataset from the input parameters.
	 */
	public OneDSeriesDatasetProducer(List<Object> data, boolean row_order) throws DataSourceException {
		if (data.size() < 1) throw new DataSourceException("Missing input parameter!");
		
		time = System.currentTimeMillis();
		mode = FULL_MODE;
		dataset = new OneDSeriesDataset(0,0);
		this.row_order = row_order;
		if (data.get(0) instanceof ISeriesProducer) {
			this.values = (ISeriesProducer)data.get(0);
			this.values.addDataChangeListener(this);
		} else throw new DataSourceException("Invalid color/shape values parameter!");
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor. It uses the ai.aitia.visu.data.DefaultGrid2DDataset implementation.
	 * 
	 * @param ds_producer producer that produces a complete grid.
	 */
	public OneDSeriesDatasetProducer(OneDSeriesDatasetProducer ds_producer) {
	  time = System.currentTimeMillis();
	  mode = DS_MODE;
	  dataset = new OneDSeriesDataset(0,0);
	  this.ds_producer = ds_producer;
	}
	
	
	//-------------------------------------------------------------------------------
	/** Returns the time of the last update. */
	public long getTime() {
		return time;
	}

	//-------------------------------------------------------------------------------
	/** Produces the dataset. This implementation of the method does not use the <code>
	 *  queryProperties</code> parameter and does not throw exception.
	 */  
	public Dataset produceDataset(Properties queryProperties)
			throws DataSourceException {
		return dataset;
	}
	
	//-------------------------------------------------------------------------------
	/** Updates the dataset. In full mode, if both width and height are valid
	 *  (produced or fix) values and the length of values' series is less than 
	 *  width x height then the method uses the default <code>- Double.MAX_VALUE</code>
	 *  value to fill the empty places.
	 * @param event event
	 */
	public void dataChanged(DataChangeEvent event) {
		Object source = event.getSource();
		if (source.equals(values)) {
			ISeriesProducer p = (ISeriesProducer)source; 
			values_series = p.produceSeries();
			if (p.equals(xs)) xs_series = values_series;
			if (p.equals(ys)) ys_series = values_series;
			time = p.getTime();
		}
		if (mode == FULL_MODE) {
			if (values_series == null) return;
//			ISeriesProducer p = (ISeriesProducer)source;
			if(listLength!=values_series.size()){
				listLength=values_series.size();
				initTimeSeriesList();
			}
			for(int i=0; i<values_series.size(); i++){
				TimeSeries ts=timeSeriesList.get(i);
				ts.addOrUpdate(new FixedMillisecond(step), values_series.get(i));
			}
			
			((OneDSeriesDataset)dataset).setValues(timeSeriesList, listLength, maxItemCount, row_order);
			((OneDSeriesDataset)dataset).fireDatasetChanged();
			step++;
		}
	}
	
	public void setMaximumItemCount(final int maxItemCount) {
		this.maxItemCount = maxItemCount;
		if(null!=timeSeriesList){
			Iterator it = timeSeriesList.iterator();
			while (it.hasNext()) {
				((TimeSeries)it.next()).setMaximumItemCount(maxItemCount);
			}	
		}
		
	}
	
	public void initTimeSeriesList(){
		timeSeriesList = new ArrayList<TimeSeries>() ;
		for(int i=0; i<listLength; i++){
			TimeSeries ts=new TimeSeries(Integer.toString(i), FixedMillisecond.class);
			ts.setMaximumItemCount(maxItemCount);
			timeSeriesList.add(ts);
		}
		setMaximumItemCount(maxItemCount);
		
	}
	
}