/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Shape;
import java.awt.Stroke;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;
import java.util.concurrent.Callable;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.title.TextTitle;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import ai.aitia.chart.charttypes.BarChart;
import ai.aitia.chart.charttypes.BoxPlot;
import ai.aitia.chart.charttypes.Grid2D;
import ai.aitia.chart.charttypes.Grid3D;
import ai.aitia.chart.charttypes.Histogram;
import ai.aitia.chart.charttypes.MatrixOfScatterPlots;
import ai.aitia.chart.charttypes.MultiGrid2D;
import ai.aitia.chart.charttypes.Network;
import ai.aitia.chart.charttypes.OneDSeries;
import ai.aitia.chart.charttypes.PieChart;
import ai.aitia.chart.charttypes.RadViz;
import ai.aitia.chart.charttypes.RealTimeSeries;
import ai.aitia.chart.charttypes.RectangleAreaChart;
import ai.aitia.chart.charttypes.ScatterPlot;
import ai.aitia.chart.charttypes.Sequence;
import ai.aitia.chart.charttypes.ShapeGrid2D;
import ai.aitia.chart.charttypes.Subgraph;
import ai.aitia.chart.charttypes.TimeSeries;
import ai.aitia.chart.charttypes.XYLineChart;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLLoadingException;
import ai.aitia.chart.util.XMLLoadingException.TemplateLoadingException;
import ai.aitia.visu.VisualisationException;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDataProducer;
import ai.aitia.visu.ds.IDatasetProducer;
import ai.aitia.visu.view.meta.CustomAppearance;
import ai.aitia.visu.view.meta.CustomAppearance.DrawingSupplierItem;

/** This class is the common abstract supertype of all kind of chart class. */  
public abstract class AbstractChart {
	
	public static TreeMap<String,Element> templates = new TreeMap<String,Element>();
	static {
		loadTemplates();
	}
	
	/** Storage for the available chart types. */
	private static HashMap<String,AbstractChart> charts = new HashMap<String,AbstractChart>();

	//===============================================================================
	// methods
	
	/** It creates and returns a container which allows the user to assemble
	 *  the desired chart. The components are filled with data from the <code>config</code>,
	 *  and the changes of the chart settings are saved to that object, too. <br>
	 *
	 *  Note: the returned container contains a "Cancel" button. When it is clicked,
	 *  the container makes itself invisible and sends an event:<br>
	 *  - WindowEvent.WINDOW_CLOSING if the parent is a java.awt.Window,  
	 *    or a Window's JLayeredPane. The event is sent to the window with 
	 *    event.getSource() == the window.<br>
	 *  - ComponentEvent.COMPONENT_HIDDEN otherwise. The event is sent to the immediate
	 *    parent of this Container, with event.getSource() == this Container (not its parent).
	 *    In this case the parent should process the ComponentListener.componentHidden() 
	 *    message (which is only triggered when this dialog should be closed).<br>
	 *  <p>
	 *  For details, see {@link ai.aitia.chart.charttypes.dialogs.AbstractChartDialog#notifyForHide()
	 *   notifyForHide()}.
	 *
	 * @param config a chart configuration object, must not be <code>null</code>.
	 * @param collection a collection of chart configuration objects (<code>null</code> is permitted). 
	 * @return a container that contains the GUI-component of the appropriate chart type.
	 */
	public abstract Container createDialog(ChartConfig config, ChartConfigCollection collection);

	//-------------------------------------------------------------------------------
	/** It creates and returns a container that displays the chart
	 *  (ai.aitia.visu.view.CustomSaveableChartPanel). The chart is generated
	 *  from the configuration object.
	 * @param config a chart configuration object.
	 * @return a container that displays the chart
	 * @throws DataSourceException if any problems occure when it produces the data.
	 * @throws VisualisationException if any problem occure during the visualization.
	 */
	public abstract Container createChart(ChartConfig config) throws DataSourceException, VisualisationException;

	//-------------------------------------------------------------------------------
	/** It returns the ID of the chart type in string format.
	 * @see ai.aitia.chart.util.ChartConstants ChartConstants
	 * @return id of the chart type
	 */
	public abstract String getID();
	
	
	//-------------------------------------------------------------------------------
	/** It returns the displayable name of the chart type. By default, it returns the
	 *  ID of the chart type.
	 * @see ai.aitia.chart.util.ChartConstants ChartConstants
	 * @return displayable name of the chart type
	 */
	@Override
	public String toString() {
		return getID();
	}
	
	//-------------------------------------------------------------------------------
	/** It returns the short description of the chart type. By default, it returns the
	 * 	displayable name of the chart type.
	 * @return description of the chart type
	 */
	public String getDescription() {
		return toString();
	}
	
	//-------------------------------------------------------------------------------
	/** It returns a list that contains the IDs of the data sources used by the
	 *  chart.
	 * @param config a chart configuration object
	 * @return a list of Integer that contains data source IDs.
	 */
	public List<Integer> getDataSourceIDs(ChartConfig config) {
		List<Integer> result = new ArrayList<Integer>();
		if (config.getChartProperties() instanceof Properties) {
			Properties prop = (Properties)config.getChartProperties();
			int[] ds = Utilities.splitDatasourceAroundCommas(prop.getProperty(ChartConstants.DATASOURCE));
			for (int i=0;i<ds.length;++i) {
				Integer candidate = new Integer(ds[i]);
				result.add(candidate);
			}
		}
		return result;
	}
	
	//-------------------------------------------------------------------------------
	/** The classes that can be part of a multilayer chart must override this method.
	 *  In these classes it creates a dataset producer from the configuration object
	 *  <code>config</code>.
	 * 
	 * @param config configuration object
	 * @param dp an output list contained the data producer object that composes the
	 *           dataset producer
	 * @return a dataset producer object
	 * @throws DataSoruceException if any problems occure during the data creation.
	 */  
	public IDatasetProducer createDatasetProducer(ChartConfig config, ArrayList<IDataProducer> dp)  throws DataSourceException {
		return null;
	}
	
	//-------------------------------------------------------------------------------
	/** It creates and returns a container that contains a chart. The chart is
	 *  generated from the configuration object.
	 * @param config a chart configuration object.
	 * @return a container that displays the chart
	 * @throws Exception if any problems occure
	 */
	public static Container display(final ChartConfig config) throws Exception {
		final AbstractChart chart = find(config.getChartType());
		return (Container) ChartConfigCollection.getLOPExecutor().execute("Displaying chart",new Callable<Object>() {
				public Object call() throws DataSourceException, VisualisationException {
						try {
							ChartConfigCollection.getLOPExecutor().setAbortable(false);
							return chart.createChart(config);
						} finally {
							ChartConfigCollection.getLOPExecutor().setAbortable(true);
						}
				}
		});
	}

	//-------------------------------------------------------------------------------
	/** It returns a concrete chart object specified by <code>id</code>.
	 * @param id id of the chart type.
	 * @return the appropriate chart object
	 */
	public static AbstractChart find(String id) {
		return charts.get(id);
	}
	
	//-------------------------------------------------------------------------------
	/** This function registrates a concrete chart object to the chart storage.
	 * @param chart chart object
	 */
	public static void register(AbstractChart chart) {
		charts.put(chart.getID(),chart);
	}
	
	//-------------------------------------------------------------------------------
	/** This function registrates one instance to the chart storage from all
	 *  supported chart types.
	 */
	public static void registerAll() {
		register(new XYLineChart());
		register(new ScatterPlot());
		register(new TimeSeries());
		register(new RealTimeSeries());
		register(new Histogram());
		register(new BarChart());
		register(new RectangleAreaChart());
		register(new Grid2D());
		register(new ShapeGrid2D());
//		register(new CompositeGrid2D()); deprecated chart
		register(new Network());
		register(new Subgraph());
		register(new Sequence());
		register(new MultiGrid2D());
		register(new PieChart());
		register(new BoxPlot());
		register(new RadViz());
		register(new MatrixOfScatterPlots());
		//register(new D1Series());
		register(new OneDSeries());
//		register(new MultiHistogram());
		register(new Grid3D());
	}
	
	//-------------------------------------------------------------------------------
	/** This function returns the chart storage.
	 * @return chart storage
	 */
	public static HashMap<String,AbstractChart> getChartStorage() {
		return charts;
	}
	
	//-------------------------------------------------------------------------------
	/** This function loads information of the chart from an XML-node and adds as
	 *  chart properties to the configuration object.
	 * @param config configuration object
	 * @param node XML-node
	 * @throws XMLLoadingException if any problems occure during parsing of the XML-node.
	 */ 
	protected void loadChartProperties(ChartConfig config, Node node) throws XMLLoadingException {
		Properties prop = Utilities.readProperties(node);
		config.setChartProperties(getID(),prop);
	}
	
	//-------------------------------------------------------------------------------
	/** This function saves the chart properties of the configuration object into an
	 *  XML-node.
	 * @param config configuration object
	 * @param node destination XML-node
	 */ 
	protected void saveChartProperties(ChartConfig config, Node node) {
		if (config.getChartProperties() instanceof Properties) {
			Utilities.writeProperties(node,(Properties)config.getChartProperties());
		}
	}
	
	//-------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	protected CustomAppearance createCustomAppearance(Element root) throws TemplateLoadingException {
		CustomAppearance appearance = new CustomAppearance();
		
		// GENERAL
		NodeList nodes = root.getElementsByTagName(ChartConstants.DIMENSION);
		if (nodes != null && nodes.getLength() != 0) {
			Element dimensionElement = (Element) nodes.item(0);
			nodes = dimensionElement.getElementsByTagName(ChartConstants.TEMPLATE_WIDTH);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TEMPLATE_WIDTH + "' tag.");
			Element widthElement = (Element) nodes.item(0);
			Text text = (Text) widthElement.getChildNodes().item(0);
			int width = Integer.parseInt(text.getNodeValue().trim());
			nodes = dimensionElement.getElementsByTagName(ChartConstants.TEMPLATE_HEIGHT);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TEMPLATE_HEIGHT + "' tag.");
			Element heightElement = (Element) nodes.item(0);
			text = (Text) heightElement.getChildNodes().item(0);
			int height = Integer.parseInt(text.getNodeValue().trim());
			appearance.setDimension(new Dimension(width,height));
		}
		nodes = root.getElementsByTagName(ChartConstants.TEMPLATE_TITLE);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TEMPLATE_TITLE + "' tag.");
		Element titleElement = (Element) nodes.item(0);
		String tmp = titleElement.getAttribute(ChartConstants.SHOW_ATTR);
		if (null == tmp || "".equals(tmp))
			throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
		boolean	bool = Boolean.parseBoolean(tmp);
		appearance.setShowTitle(bool);
		if (bool) {
			nodes = titleElement.getElementsByTagName(ChartConstants.FONT);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
			Element fontElement = (Element) nodes.item(0);
			Text text = (Text) fontElement.getChildNodes().item(0);
			appearance.setTitleFont(Utilities.stringToFont(text.getNodeValue().trim()));
			
			nodes = titleElement.getElementsByTagName(ChartConstants.COLOR);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
			Element colorElement = (Element) nodes.item(0);
			text = (Text) colorElement.getChildNodes().item(0);
			appearance.setTitleColor(new Color(Integer.decode(text.getNodeValue().trim())));
		} 
		
		nodes = root.getElementsByTagName(ChartConstants.TEMPLATE_SUBTITLE);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TEMPLATE_SUBTITLE + "' tag.");
		Element subtitleElement = (Element) nodes.item(0);
		tmp = subtitleElement.getAttribute(ChartConstants.SHOW_ATTR);
		if (null == tmp || "".equals(tmp))
			throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
		bool = Boolean.parseBoolean(tmp);
		appearance.setShowSubtitle(bool);
		if (bool) {
			nodes = subtitleElement.getElementsByTagName(ChartConstants.FONT);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
			Element fontElement = (Element) nodes.item(0);
			Text text = (Text) fontElement.getChildNodes().item(0);
			appearance.setSubtitleFont(Utilities.stringToFont(text.getNodeValue().trim()));

			nodes = subtitleElement.getElementsByTagName(ChartConstants.COLOR);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
			Element colorElement = (Element) nodes.item(0);
			text = (Text) colorElement.getChildNodes().item(0);
			appearance.setSubtitleColor(new Color(Integer.decode(text.getNodeValue().trim())));
		}
		
		nodes = root.getElementsByTagName(ChartConstants.BACKGROUND);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.BACKGROUND + "' tag.");
		Element backgroundElement = (Element) nodes.item(0);
		tmp = backgroundElement.getAttribute(ChartConstants.BACKGROUND_TYPE);
		if (null == tmp || "".equals(tmp))
			throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.BACKGROUND_TYPE + "' is missing or empty.");
		boolean gradient = !ChartConstants.SIMPLE_BG_TYPE.equals(tmp);
		nodes = backgroundElement.getElementsByTagName(ChartConstants.START_COLOR);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.START_COLOR + "' tag.");
		Element startColorElement = (Element) nodes.item(0);
		Text text = (Text) startColorElement.getChildNodes().item(0);
		Color startColor = new Color(Integer.decode(text.getNodeValue().trim()));
		if (gradient) {
			nodes = backgroundElement.getElementsByTagName(ChartConstants.END_COLOR);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.END_COLOR + "' tag.");
			Element endColorElement = (Element) nodes.item(0);
			text = (Text) endColorElement.getChildNodes().item(0);
			Color endColor = new Color(Integer.decode(text.getNodeValue().trim()));
			appearance.setBackgroundPaint(new GradientPaint(0,0,startColor,0,1000,endColor));
		} else
			appearance.setBackgroundPaint(startColor);

		// DOMAIN AXIS
		nodes = root.getElementsByTagName(ChartConstants.DOMAIN_AXIS);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.DOMAIN_AXIS + "' tag.");
		Element domainAxisElement = (Element) nodes.item(0);
		
		nodes = domainAxisElement.getElementsByTagName(ChartConstants.FONT);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
		Element fontElement = (Element) nodes.item(0);
		text = (Text) fontElement.getChildNodes().item(0);
		appearance.setDomainAxisFont(Utilities.stringToFont(text.getNodeValue().trim()));
		
		nodes = domainAxisElement.getElementsByTagName(ChartConstants.COLOR);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
		Element colorElement = (Element) nodes.item(0);
		text = (Text) colorElement.getChildNodes().item(0);
		appearance.setDomainAxisColor(new Color(Integer.decode(text.getNodeValue().trim())));
		
		nodes = domainAxisElement.getElementsByTagName(ChartConstants.TICK_LABELS);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TICK_LABELS + "' tag.");
		Element tickLabelsElement = (Element) nodes.item(0);
		tmp = tickLabelsElement.getAttribute(ChartConstants.SHOW_ATTR);
		if (null == tmp || "".equals(tmp))
			throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
		bool = Boolean.parseBoolean(tmp);
		appearance.setDomainAxisTickLabels(bool);
		if (bool) {
			nodes = tickLabelsElement.getElementsByTagName(ChartConstants.FONT);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
			fontElement = (Element) nodes.item(0);
			text = (Text) fontElement.getChildNodes().item(0);
			appearance.setDomainAxisTickFont(Utilities.stringToFont(text.getNodeValue().trim()));
		} 
		
		nodes = domainAxisElement.getElementsByTagName(ChartConstants.TICK_MARKS);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TICK_MARKS + "' tag.");
		Element tickMarksElement = (Element) nodes.item(0);
		tmp = tickMarksElement.getAttribute(ChartConstants.SHOW_ATTR);
		if (null == tmp || "".equals(tmp))
			throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
		appearance.setDomainAxisTickMarks(Boolean.parseBoolean(tmp));
		
		nodes = domainAxisElement.getElementsByTagName(ChartConstants.INTERVAL);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.INTERVAL + "' tag.");
		Element intervalElement = (Element) nodes.item(0);
		tmp = intervalElement.getAttribute(ChartConstants.AUTO_ATTR);
		if (null == tmp || "".equals(tmp))
			throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.AUTO_ATTR + "' is missing or empty.");
		bool = Boolean.parseBoolean(tmp);
		appearance.setDomainAutoRange(bool);
		double domainMin, domainMax;
		if (!bool) {
			nodes = intervalElement.getElementsByTagName(ChartConstants.MIN_RANGE_VALUE);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.MIN_RANGE_VALUE + "' tag.");
			Element minValueElement = (Element) nodes.item(0);
			text = (Text) minValueElement.getChildNodes().item(0);
			try {
				domainMin = Double.parseDouble(text.getNodeValue().trim());
			} catch (NumberFormatException e) {
				throw new TemplateLoadingException("Invalid content at '" + ChartConstants.MIN_RANGE_VALUE + "' tag.");
			}
			nodes = intervalElement.getElementsByTagName(ChartConstants.MAX_RANGE_VALUE);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.MAX_RANGE_VALUE + "' tag.");
			Element maxValueElement = (Element) nodes.item(0);
			text = (Text) maxValueElement.getChildNodes().item(0);
			try {
				domainMax = Double.parseDouble(text.getNodeValue().trim());
			} catch (NumberFormatException e) {
				throw new TemplateLoadingException("Invalid content at '" + ChartConstants.MAX_RANGE_VALUE + "' tag.");
			}
			if (domainMin > domainMax)
				throw new TemplateLoadingException("Invalid domain interval.");
			appearance.setDomainRangeMin(domainMin);
			appearance.setDomainRangeMax(domainMax);
		}
		
		// RANGE AXIS
		nodes = root.getElementsByTagName(ChartConstants.RANGE_AXIS);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.RANGE_AXIS + "' tag.");
		Element rangeAxisElement = (Element) nodes.item(0);
		
		nodes = rangeAxisElement.getElementsByTagName(ChartConstants.FONT);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
		fontElement = (Element) nodes.item(0);
		text = (Text) fontElement.getChildNodes().item(0);
		appearance.setRangeAxisFont(Utilities.stringToFont(text.getNodeValue().trim()));

		nodes = rangeAxisElement.getElementsByTagName(ChartConstants.COLOR);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
		colorElement = (Element) nodes.item(0);
		text = (Text) colorElement.getChildNodes().item(0);
		appearance.setRangeAxisColor(new Color(Integer.decode(text.getNodeValue().trim())));
		
		nodes = rangeAxisElement.getElementsByTagName(ChartConstants.TICK_LABELS);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TICK_LABELS + "' tag.");
		tickLabelsElement = (Element) nodes.item(0);
		tmp = tickLabelsElement.getAttribute(ChartConstants.SHOW_ATTR);
		if (null == tmp || "".equals(tmp))
			throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
		bool = Boolean.parseBoolean(tmp);
		appearance.setRangeAxisTickLabels(bool);
		if (bool) {
			nodes = tickLabelsElement.getElementsByTagName(ChartConstants.FONT);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
			fontElement = (Element) nodes.item(0);
			text = (Text) fontElement.getChildNodes().item(0);
			appearance.setRangeAxisTickFont(Utilities.stringToFont(text.getNodeValue().trim()));
		}
		
		nodes = rangeAxisElement.getElementsByTagName(ChartConstants.TICK_MARKS);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TICK_MARKS + "' tag.");
		tickMarksElement = (Element) nodes.item(0);
		tmp = tickMarksElement.getAttribute(ChartConstants.SHOW_ATTR);
		if (null == tmp || "".equals(tmp))
			throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
		appearance.setRangeAxisTickMarks(Boolean.parseBoolean(tmp));
		
		nodes = rangeAxisElement.getElementsByTagName(ChartConstants.INTERVAL);
		if (nodes == null || nodes.getLength() == 0)
			throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.INTERVAL + "' tag.");
		intervalElement = (Element) nodes.item(0);
		tmp = intervalElement.getAttribute(ChartConstants.AUTO_ATTR);
		if (null == tmp || "".equals(tmp))
			throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.AUTO_ATTR + "' is missing or empty.");
		bool = Boolean.parseBoolean(tmp);
		appearance.setRangeAutoRange(bool);
		double rangeMin, rangeMax;
		if (!bool) {
			nodes = intervalElement.getElementsByTagName(ChartConstants.MIN_RANGE_VALUE);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.MIN_RANGE_VALUE + "' tag.");
			Element minValueElement = (Element) nodes.item(0);
			text = (Text) minValueElement.getChildNodes().item(0);
			try {
				rangeMin = Double.parseDouble(text.getNodeValue().trim());
			} catch (NumberFormatException e) {
				throw new TemplateLoadingException("Invalid content at '" + ChartConstants.MIN_RANGE_VALUE + "' tag.");
			}
			nodes = intervalElement.getElementsByTagName(ChartConstants.MAX_RANGE_VALUE);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.MAX_RANGE_VALUE + "' tag.");
			Element maxValueElement = (Element) nodes.item(0);
			text = (Text) maxValueElement.getChildNodes().item(0);
			try {
				rangeMax = Double.parseDouble(text.getNodeValue().trim());
			} catch (NumberFormatException e) {
				throw new TemplateLoadingException("Invalid content at '" + ChartConstants.MAX_RANGE_VALUE + "' tag.");
			}
			if (rangeMin > rangeMax)
				throw new TemplateLoadingException("Invalid domain interval.");
			appearance.setRangeRangeMin(rangeMin);
			appearance.setRangeRangeMax(rangeMax);
		} 
		
		//shape size
		nodes = root.getElementsByTagName(ChartConstants.SHAPE_SIZE);
		if (nodes != null && nodes.getLength() != 0) {
			Element shapeSizeElement = (Element) nodes.item(0);
			text = (Text) shapeSizeElement.getChildNodes().item(0);
			double sizePercentage = Double.parseDouble(text.getNodeValue().trim());
			ChartPropertiesDialog.createStandardSeriesShapes(sizePercentage);
		}
		
		// SERIES
		nodes = root.getElementsByTagName(ChartConstants.SERIES_LIST);
		if (nodes != null && nodes.getLength() != 0) {
			Element seriesListElement = (Element) nodes.item(0);
			NodeList seriesList = seriesListElement.getElementsByTagName(ChartConstants.SERIES);
			if (seriesList == null || seriesList.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.SERIES + "' tag.");
			List<DrawingSupplierItem> items = new ArrayList<DrawingSupplierItem>(seriesList.getLength());
			for (int i = 0;i < seriesList.getLength();++i) {
				Element seriesElement = (Element) seriesList.item(i);
				nodes = seriesElement.getElementsByTagName(ChartConstants.COLOR);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.COLOR + "' tag.");
				colorElement = (Element) nodes.item(0);
				text = (Text) colorElement.getChildNodes().item(0);
				Color color = new Color(Integer.decode(text.getNodeValue().trim()));
				
				nodes = seriesElement.getElementsByTagName(ChartConstants.SHAPE);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.SHAPE + "' tag.");
				Element shapeElement = (Element) nodes.item(0);
				String customAttribute = shapeElement.getAttribute(ChartConstants.CUSTOM_ATTR);
				if (null == customAttribute || "".equals(customAttribute))
					throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.CUSTOM_ATTR + "' is missing or empty.");
				boolean custom = Boolean.parseBoolean(customAttribute);
				text = (Text) shapeElement.getChildNodes().item(0);
				Class shapeClass = null;
				Shape shape = null;
				if (custom) {
					try {
						shapeClass = Class.forName(text.getNodeValue().trim());
					} catch (ClassNotFoundException e1) {
							throw new TemplateLoadingException("Invalid template. Shape class " + text.getNodeValue().trim() + " is not found.");
					}
					if (shapeClass.isAssignableFrom(Shape.class)) 
						throw new TemplateLoadingException("Invalid template. Class " + text.getNodeValue().trim() + " has not implemented the Shape interface.");
					try {
						shapeClass.getConstructor(new Class[] {});
					} catch (Exception e) {
						throw new TemplateLoadingException("Invalid template. Class " + text.getNodeValue().trim() + " has not nullary constructor.");
					}
				} else {
					try {
						int index = Integer.parseInt(text.getNodeValue().trim());
						if (index < 0 || index > 19)
							throw new NumberFormatException();
						shape = ChartPropertiesDialog.PREDEFINED_SHAPES[index];
					} catch (NumberFormatException e) {
						throw new TemplateLoadingException("Invalid template. Shape index must be an integer between 0 and 9.");
					}
				}
				
				nodes = seriesElement.getElementsByTagName(ChartConstants.THICKNESS);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.THICKNESS + "' tag.");
				Element thicknessElement = (Element) nodes.item(0);
				text = (Text) thicknessElement.getChildNodes().item(0);
				float thickness = 0;
				try {
					thickness = Float.parseFloat(text.getNodeValue().trim());
					if (thickness <= 0)
						throw new NumberFormatException();
				} catch (NumberFormatException e) {
					throw new TemplateLoadingException("Invalid template. Thickness must be a positive real.");
				}
				
				nodes = seriesElement.getElementsByTagName(ChartConstants.STYLE);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.STYLE + "' tag.");
				Element styleElement = (Element) nodes.item(0);
				text = (Text) styleElement.getChildNodes().item(0);
				long styleIndex = 0;
				Stroke stroke = null;
				try {
					styleIndex = Long.parseLong(text.getNodeValue().trim());
					if (styleIndex < 0 || styleIndex > 9)
						throw new NumberFormatException();
					float[] styleArray = ChartPropertiesDialog.PREDEFINED_STYLES.get((int)styleIndex);
					stroke = new BasicStroke(thickness,BasicStroke.CAP_SQUARE,BasicStroke.JOIN_MITER,10.f,styleArray,0.f);
				} catch (NumberFormatException e) {
					throw new TemplateLoadingException("Invalid template. Style index must be an integer between 0 and 9.");
				}
				if (custom) {
					try {
						items.add(new DrawingSupplierItem(color,shapeClass,stroke));
					} catch (Exception e) { 
						throw new TemplateLoadingException(e);
					}
				} else
					items.add(new DrawingSupplierItem(color,shape,stroke));
			}
			appearance.setItems(items);
		}
		return appearance;
	}
	
	//-------------------------------------------------------------------------------
	private static void loadTemplates() {
		File templatesDir = new File("Templates");
		if (!templatesDir.exists() || !templatesDir.isDirectory())
			return;
		File[] templateFiles = templatesDir.listFiles();
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		for (File f : templateFiles) {
			if (!f.getName().endsWith(".xml")) continue;
			try {
				DocumentBuilder parser = factory.newDocumentBuilder();
				Document document = parser.parse(f);
				Element root = document.getDocumentElement();
				String name = root.getAttribute(ChartConstants.REF_ID_ATTR);
				if ("".equals(name)) continue;
				templates.put(name,root);
			} catch (Exception e) {
				e.printStackTrace();
				continue;
			} 
		}
	}
	
	//===============================================================================
	// nested classes
	
	/** This class is used by multilayer charts with histogram. */
	protected class OutliersData {
		
		/** Displayable outliers subtitle. */
		private TextTitle outliers = null;
		
		/** Strategy that determines how to handle values outside the interval. Possible 
		 * values in {@link ai.aitia.chart.util.ChartConstants ChartConstants}. */
		private String strategy = null;
		
		/** Title of the outliers list. */
		private String outliers_title = null;
		
		private JFreeChart chart = null;
		private int rendererIdx = -1;
		
		//===========================================================================
		// methods
		
		/** Constructor.
		 * @param outliers displayable outliers subtitle object
		 * @param strategy Strategy that determines how to handle values outside the
		 * interval
		 * @param outliers_title title of the outliers list
		 */
		public OutliersData(TextTitle outliers, String strategy, String outliers_title) {
			this.outliers = outliers;
			this.strategy = strategy;
			this.outliers_title = outliers_title;
		}
		
		//---------------------------------------------------------------------------
		/** Constructor.
		 * @param strategy Strategy that determines how to handle values outside the
		 * interval
		 * @param outliers_title title of the outliers list
		 */
		public OutliersData(String strategy, String outliers_title) {
			this(null,strategy,outliers_title);
		}
		
		//---------------------------------------------------------------------------
		/** Constructor.
		 * @param strategy Strategy that determines how to handle values outside the
		 * interval
		 */
		public  OutliersData(String strategy) {
			this(null,strategy,null);
		}

		//---------------------------------------------------------------------------
		/** Returns the displayable outliers subtitle object.
		 * @return displayable outliers subtitle object
		 */
		public TextTitle getOutliers() {
			return outliers;
		}

		//---------------------------------------------------------------------------
		/** Sets the displayable outliers subtitle object. 
		 * @param outliers the new outliers subtitle object
		 */
		public void setOutliers(TextTitle outliers) {
			this.outliers = outliers;
		}

		//---------------------------------------------------------------------------
		/** Returns the title of the outliers list.
		 * @return title of the outliers list
		 */
		public String getOutliers_title() {
			return outliers_title;
		}

		//---------------------------------------------------------------------------
		/** Returns the strategy that determines how to handle values outside the
		 *  interval.
		 * @return strategy
		 */
		public String getStrategy() {
			return strategy;
		}
		
		public JFreeChart getChart() { return chart; }
		public void setChart(JFreeChart chart) { this.chart = chart; }
		public int getRendererIdx() { return rendererIdx; }
		public void setRendererIdx(int rendererIdx) { this.rendererIdx = rendererIdx; }
	}
}