package ai.aitia.visu.movie;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.media.Buffer;
import javax.media.ConfigureCompleteEvent;
import javax.media.Controller;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.DataSink;
import javax.media.EndOfMediaEvent;
import javax.media.Format;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.PrefetchCompleteEvent;
import javax.media.Processor;
import javax.media.RealizeCompleteEvent;
import javax.media.ResourceUnavailableEvent;
import javax.media.control.TrackControl;
import javax.media.datasink.DataSinkErrorEvent;
import javax.media.datasink.DataSinkEvent;
import javax.media.datasink.DataSinkListener;
import javax.media.datasink.EndOfStreamEvent;
import javax.media.format.RGBFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.FileTypeDescriptor;
import javax.media.util.ImageToBuffer;





/**
 * This program takes a list of JPEG image files and convert them into
 * a QuickTime movie.
 */
public class MovieMaker implements ControllerListener, DataSinkListener {

	private BufferImageDataSource source;
	private boolean init=false;
	//private static MovieMaker imageToMovie;
	private int width=0;
	private int height=0;
	private int frameRate=10;
    private static MediaLocator oml;
    private static String outputURL = null;
    private DataSink dsink;
    private Processor p;
    private boolean notDone=true;
   
    public MovieMaker(String outputURL, int frameRate){
    	outputURL="file:/" + outputURL+ ".mov";
    	this.frameRate=frameRate;
    }
    public boolean init(Buffer b,RGBFormat format) {
  	System.out.println("init  " +  frameRate);
    
	source = new BufferImageDataSource(width, height, frameRate, format);
	source.addBuffer(b);

    try {
      Thread.sleep(1000);
    } catch (InterruptedException ex) {}
    System.gc();
   
	try {
	    p = Manager.createProcessor(source);
	} catch (Exception e) {
	    System.err.println("Yikes!  Cannot create a processor from the data source.");
	    return false;
	}

	p.addControllerListener(this);

	// Put the Processor into configured state so we can set
	// some processing options on the processor.
	p.configure();
	if (!waitForState(p, Processor.Configured)) {
	    System.err.println("Failed to configure the processor.");
	    return false;
	}

	// Set the output content descriptor to QuickTime. 
	p.setContentDescriptor(new ContentDescriptor(FileTypeDescriptor.QUICKTIME));
	//p.setContentDescriptor(new ContentDescriptor(FileTypeDescriptor.MPEG));
	//p.setContentDescriptor(new ContentDescriptor(FileTypeDescriptor.MSVIDEO));
	// Query for the processor for supported formats.
	// Then set it on the processor.
	TrackControl tcs[] = p.getTrackControls();
	Format f[] = tcs[0].getSupportedFormats();
	if (f == null || f.length <= 0) {
	    System.err.println("The mux does not support the input format: " + tcs[0].getFormat());
	    return false;
	}
	tcs[0].setFormat(f[0]);
	// We are done with programming the processor.  Let's just
	// realize it.
	p.realize();
	if (!waitForState(p, Controller.Realized)) {
	    System.err.println("Failed to realize the processor.");
	    return false;
	}

	// Now, we'll need to create a DataSink.
	System.out.println(oml + "  oml");
	if ((dsink = createDataSink(p, oml)) == null) {
	    System.err.println("Failed to create a DataSink for the given output MediaLocator: " + oml);
	    return false;
	}

	dsink.addDataSinkListener(this);
	fileDone = false;

	//System.err.println("start processing...");

	// OK, we can now start the actual transcoding.
	try {
	    p.start();
	    dsink.start();
	} catch (IOException e) {
	    System.err.println("IO error during processing");
	    return false;
	}
	return true;
    }

    public void cleanUp() {
        source.cleanUp();
        waitForFileDone();
        try {
          dsink.close();
        } catch (Exception ex) {}


        p.removeControllerListener(this);

        //SimUtilities.showMessage("Movie capture has finished");
        //System.out.println("Movie done");
      }

    /**
     * Create the DataSink.
     */
    DataSink createDataSink(Processor p, MediaLocator outML) {

	DataSource ds;

	if ((ds = p.getDataOutput()) == null) {
	    System.err.println("Something is really wrong: the processor does not have an output DataSource");
	    return null;
	}

	DataSink dsink;

	try {
	    //System.err.println("- create DataSink for: " + outML);
	    dsink = Manager.createDataSink(ds, outML);
	    dsink.open();
	} catch (Exception e) {
	    System.err.println("Cannot create the DataSink: " + e);
	    return null;
	}

	return dsink;
    }


    Object waitSync = new Object();
    boolean stateTransitionOK = true;

    /**
     * Block until the processor has transitioned to the given state.
     * Return false if the transition failed.
     */
    boolean waitForState(Processor p, int state) {
	synchronized (waitSync) {
	    try {
		while (p.getState() < state && stateTransitionOK)
		    waitSync.wait();
	    } catch (Exception e) {}
	}
	return stateTransitionOK;
    }


    /**
     * Controller Listener.
     */
    public void controllerUpdate(ControllerEvent evt) {
    	//System.out.println(evt.toString());
	if (evt instanceof ConfigureCompleteEvent ||
	    evt instanceof RealizeCompleteEvent ||
	    evt instanceof PrefetchCompleteEvent) {
	    synchronized (waitSync) {
		stateTransitionOK = true;
		waitSync.notifyAll();
		
	    }
	} else if (evt instanceof ResourceUnavailableEvent) {
	    synchronized (waitSync) {
		stateTransitionOK = false;
		waitSync.notifyAll();
	    }
	} else if (evt instanceof EndOfMediaEvent) {
	    evt.getSourceController().stop();
	    //System.out.println("endofmedia            " + evt.getSourceController().toString());
	    evt.getSourceController().close();
	}
    }


    Object waitFileSync = new Object();
    boolean fileDone = false;
    boolean fileSuccess = true;

    /**
     * Block until file writing is done. 
     */
    boolean waitForFileDone() {
	synchronized (waitFileSync) {
	    try {
		while (!fileDone)
		    waitFileSync.wait();
	    } catch (Exception e) {}
	}
	return fileSuccess;
    }


    /**
     * Event handler for the file writer.
     */
    public void dataSinkUpdate(DataSinkEvent evt) {

	if (evt instanceof EndOfStreamEvent) {
	    synchronized (waitFileSync) {
		fileDone = true;
		waitFileSync.notifyAll();
	    }
	} else if (evt instanceof DataSinkErrorEvent) {
	    synchronized (waitFileSync) {
		fileDone = true;
		fileSuccess = false;
		waitFileSync.notifyAll();
	    }
	}
    }


    //public static void main(String args[]) {
    public void run(Image imageToAdd) {

	
	@SuppressWarnings("unused")
	int i = 0;
	int width = -1, height = -1, frameRate = 1;
	//outputURL = "file:/c:/Movie/pppp.mov";
	width=640;
	height=480;
	
	if (width < 0 || height < 0) {
	    System.err.println("Please specify the correct image size.");
	    prUsage();
	}

	// Check the frame rate.
	if (frameRate < 1){
		frameRate = 1;
	}
	    

	// Generate the output media locators.
	

	if ((oml = createMediaLocator(outputURL)) == null) {
	    System.err.println("Cannot build media locator from: " + outputURL);
	    System.exit(0);
	}
	this.addImageAsFrame(imageToAdd, 100);
    }
	
    static void prUsage() {
	System.err.println("Usage: java PngImagesToMovie -w <width> -h <height> -f <frame rate> -o <output URL> <input JPEG file 1> <input JPEG file 2> ...");
	System.exit(-1);
    }

    /**
     * Create a media locator from the given string.
     */
    static MediaLocator createMediaLocator(String url) {

	MediaLocator ml;

	if (url.indexOf(":") > 0 && (ml = new MediaLocator(url)) != null)
	    return ml;

	if (url.startsWith(File.separator)) {
	    if ((ml = new MediaLocator("file:" + url)) != null)
		return ml;
	} else {
	    String file = "file:" + System.getProperty("user.dir") + File.separator + url;
	    if ((ml = new MediaLocator(file)) != null)
		return ml;
	}

	return null;
    }
    
    /**
     * Adds an image to a movie as a frame. This method pause the main
     * simulation thread for the specified amount of time. This pause
     * is necessary to allow the images to be written to disk in a background
     * thread. Without the pauses the images are still written to disk, but
     * are added much faster than they can be written, resulting in increased
     * memory use and eventual OutOfMemoryErrors. This method is called by
     * DisplaySurface and shouldn't be called by a user in the course of
     * writing a model.
     *
     * @param image the image to add as a frame
     * @param sleepCount the amount to pause for writing images to disk
     */
    public void addImageAsFrame(Image image, int sleepCount) {
      Buffer b = ImageToBuffer.createBuffer(image, frameRate);
      //System.out.println("addimage  " + frameRate);
      if (!init) {  
        boolean result = init(b,(RGBFormat)b.getFormat());
        if (!result) {
          System.err.println("Failed to setup movie capture");
        }
        init = true;
      }else 
    	  source.addBuffer(b);
      try {
        Thread.sleep(sleepCount);
      } catch (InterruptedException ex) {}
      System.gc();
      
      if(!source.sourceStreamNotDone() || !notDone){
    	  cleanUp();
      }
      
    }
	public void setNotDone(boolean notDone) {
		this.notDone = notDone;
	}

	public void finalize() {
		cleanUp();
	}
	
}



