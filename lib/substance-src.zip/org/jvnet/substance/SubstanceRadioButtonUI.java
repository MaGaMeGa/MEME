/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.BasicButtonListener;
import javax.swing.plaf.basic.BasicRadioButtonUI;

import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.lafwidget.utils.FadeStateListener;
import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.substance.button.BaseButtonShaper;
import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.utils.*;
import org.jvnet.substance.utils.SubstanceConstants.FocusKind;

/**
 * UI for radio buttons in <b>Substance </b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceRadioButtonUI extends BasicRadioButtonUI {
	/**
	 * Default radio button dimension.
	 */
	private static final int DIMENSION = 11;

	/**
	 * Background delegate.
	 */
	private SubstanceFillBackgroundDelegate bgDelegate;

	/**
	 * Property change listener. Listens on changes to
	 * {@link AbstractButton#MODEL_CHANGED_PROPERTY} property.
	 */
	protected PropertyChangeListener substancePropertyListener;

	/**
	 * Associated toggle button.
	 */
	protected JToggleButton button;

	/**
	 * Icons for all component states
	 */
	private static Map<String, Icon> icons = new HashMap<String, Icon>();

	/**
	 * Listener for fade animations.
	 */
	protected FadeStateListener substanceFadeStateListener;

	/**
	 * Resets image maps (used when setting new theme).
	 * 
	 * @see SubstanceLookAndFeel#setCurrentTheme(String)
	 * @see SubstanceLookAndFeel#setCurrentTheme(org.jvnet.substance.theme.SubstanceTheme)
	 */
	public static synchronized void reset() {
		SubstanceRadioButtonUI.icons.clear();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonUI#installListeners(javax.swing.AbstractButton)
	 */
	@Override
	protected void installListeners(final AbstractButton b) {
		super.installListeners(b);

		this.substanceFadeStateListener = new FadeStateListener(b,
				b.getModel(), null);
		this.substanceFadeStateListener.registerListeners();

		this.substancePropertyListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if (AbstractButton.MODEL_CHANGED_PROPERTY.equals(evt
						.getPropertyName())) {
					if (substanceFadeStateListener != null)
						substanceFadeStateListener.unregisterListeners();
					substanceFadeStateListener = new FadeStateListener(b, b
							.getModel(), null);
					substanceFadeStateListener.registerListeners();
				}
			}
		};
		b.addPropertyChangeListener(this.substancePropertyListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicRadioButtonUI#installDefaults(javax.swing.AbstractButton)
	 */
	@Override
	protected void installDefaults(AbstractButton b) {
		super.installDefaults(b);

		Color bg = b.getBackground();
		if (bg instanceof UIResource) {
			b.setBackground(new ButtonColorDelegate(b, false));
		}

		b.putClientProperty(SubstanceButtonUI.OPACITY_ORIGINAL, b.isOpaque());
		b.setOpaque(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicRadioButtonUI#uninstallDefaults(javax.swing.AbstractButton)
	 */
	@Override
	protected void uninstallDefaults(AbstractButton b) {
		super.uninstallDefaults(b);

		b.setOpaque((Boolean) b
				.getClientProperty(SubstanceButtonUI.OPACITY_ORIGINAL));
		b.putClientProperty(SubstanceButtonUI.OPACITY_ORIGINAL, null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonUI#uninstallListeners(javax.swing.AbstractButton)
	 */
	@Override
	protected void uninstallListeners(AbstractButton b) {
		this.substanceFadeStateListener.unregisterListeners();
		this.substanceFadeStateListener = null;

		b.removePropertyChangeListener(this.substancePropertyListener);
		this.substancePropertyListener = null;

		super.uninstallListeners(b);
	}

	// private static synchronized Icon getIcon(ComponentState state) {
	// Icon result = icons.get(state);
	// if (result != null)
	// return result;
	// result = new ImageIcon(SubstanceImageCreator.getRadioButton(DIMENSION,
	// state, 0));
	// icons.put(state, result);
	// return result;
	// }
	/**
	 * Returns the icon that matches the specified state of the specified
	 * button.
	 * 
	 * @param button
	 *            Button (should be {@link JCheckBox}).
	 * @param state
	 *            Button state.
	 * @return Matching icon.
	 */
	private static synchronized Icon getIcon(JToggleButton button,
			ComponentState state) {
		// check if fading
		FadeTracker fadeTracker = FadeTracker.getInstance();
		float visibility = state.isSelected() ? 10 : 0;
		if (fadeTracker.isTracked(button, FadeKind.SELECTION)) {
			visibility = fadeTracker.getFade10(button, FadeKind.SELECTION);
		}

		if (fadeTracker.isTracked(button, FadeKind.ROLLOVER)) {
			SubstanceTheme defaultTheme = SubstanceCoreUtilities
					.getDefaultTheme(button, true);
			SubstanceTheme theme = SubstanceCoreUtilities.getActiveTheme(
					button, true);
			SubstanceTheme theme2 = theme;
			float cyclePos = 0;
			// Control remains colored when it's selected. In addition, no
			// fading on disabled controls.
			if (!state.isSelected() && state.isEnabled()) {
				if (state == ComponentState.DEFAULT) {
					// Came from rollover state
					theme2 = defaultTheme;
					cyclePos = 10 - fadeTracker.getFade10(button,
							FadeKind.ROLLOVER);
				} else {
					// Came from default state
					theme2 = theme;
					theme = defaultTheme;
					cyclePos = fadeTracker.getFade10(button, FadeKind.ROLLOVER);
				}

				String key = state.name() + ":" + theme.getDisplayName() + ":"
						+ theme2.getDisplayName() + ":" + cyclePos + ":"
						+ visibility;
				Icon result = SubstanceRadioButtonUI.icons.get(key);
				if (result != null)
					return result;
				result = new ImageIcon(SubstanceImageCreator.getRadioButton(
						button, SubstanceRadioButtonUI.DIMENSION, state, 0,
						theme, theme2, cyclePos, visibility / 10.f));
				SubstanceRadioButtonUI.icons.put(key, result);
				return result;
			}
		}

		ComponentState.ColorSchemeKind kind = state.getColorSchemeKind();
		SubstanceTheme theme = SubstanceCoreUtilities.getComponentTheme(button,
				kind);
		// if (kind == ColorSchemeKind.DISABLED) {
		// colorScheme = SubstanceCoreUtilities.getDisabledScheme(button);
		// } else {
		// if ((kind == ColorSchemeKind.CURRENT)
		// || SubstanceCoreUtilities
		// .isControlAlwaysPaintedActive(button)) {
		// colorScheme = SubstanceCoreUtilities.getActiveScheme(button);
		// } else {
		// colorScheme = SubstanceCoreUtilities.getDefaultScheme(button);
		// }
		// }
		int cyclePos = state.getCycleCount();
		String key = state.name() + ":" + theme.getDisplayName() + ":"
				+ theme.getDisplayName() + ":" + cyclePos + ":" + visibility;

		Icon result = SubstanceRadioButtonUI.icons.get(key);
		if (result != null)
			return result;
		result = new ImageIcon(SubstanceImageCreator.getRadioButton(button,
				SubstanceRadioButtonUI.DIMENSION, state, 0, theme, theme,
				cyclePos, visibility / 10.f));
		SubstanceRadioButtonUI.icons.put(key, result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent b) {
		return new SubstanceRadioButtonUI((JToggleButton) b);
	}

	/**
	 * Simple constructor.
	 * 
	 * @param button
	 *            Associated radio button.
	 */
	public SubstanceRadioButtonUI(JToggleButton button) {
		this.bgDelegate = new SubstanceFillBackgroundDelegate();
		this.button = button;
		button.setRolloverEnabled(true);
		// button.setOpaque(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonUI#createButtonListener(javax.swing.AbstractButton)
	 */
	@Override
	protected BasicButtonListener createButtonListener(AbstractButton b) {
		return new RolloverButtonListener(b);
		// return RolloverButtonListener.getListener(b);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicRadioButtonUI#getDefaultIcon()
	 */
	@Override
	public Icon getDefaultIcon() {
		ButtonModel model = this.button.getModel();
		return SubstanceRadioButtonUI.getIcon(this.button, ComponentState
				.getState(model, this.button));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#paint(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void update(Graphics g, JComponent c) {
		// failsafe for LAF change
		if (!(UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel))
			return;
		// important to synchronize on the button as we are
		// about to fiddle with its opaqueness
		synchronized (c) {
			this.bgDelegate.update(g, c);
			// remove opaqueness
			boolean isOpaque = c.isOpaque();
			c.setOpaque(false);
			this.bgDelegate.update(g, c);
			super.paint(g, c);
			// restore opaqueness
			c.setOpaque(isOpaque);
		}

		// Some ugly hack to allow fade-out of focus ring. The code
		// in BasicRadioButtonUI doesn't call paintFocus() at all
		// when the component is not focus owner.
		AbstractButton b = (AbstractButton) c;
		if (!b.isFocusPainted())
			return;

		FontMetrics fm = c.getFontMetrics(c.getFont());

		Insets i = c.getInsets();
		Dimension size = new Dimension();
		Rectangle viewRect = new Rectangle();
		Rectangle iconRect = new Rectangle();
		Rectangle textRect = new Rectangle();

		size = b.getSize(size);
		viewRect.x = i.left;
		viewRect.y = i.top;
		viewRect.width = size.width - (i.right + viewRect.x);
		viewRect.height = size.height - (i.bottom + viewRect.y);
		iconRect.x = iconRect.y = iconRect.width = iconRect.height = 0;
		textRect.x = textRect.y = textRect.width = textRect.height = 0;

		Icon altIcon = b.getIcon();

		String text = SwingUtilities.layoutCompoundLabel(c, fm, b.getText(),
				altIcon != null ? altIcon : this.getDefaultIcon(), b
						.getVerticalAlignment(), b.getHorizontalAlignment(), b
						.getVerticalTextPosition(), b
						.getHorizontalTextPosition(), viewRect, iconRect,
				textRect, b.getText() == null ? 0 : b.getIconTextGap());

		if ((text != null) && (textRect.width > 0) && (textRect.height > 0)) {
			if (!(b.hasFocus() && b.isFocusPainted())) {
				if (FadeTracker.getInstance().isTracked(c, FadeKind.FOCUS))
					this.paintFocus(g, textRect, size);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicRadioButtonUI#paintFocus(java.awt.Graphics,
	 *      java.awt.Rectangle, java.awt.Dimension)
	 */
	@Override
	protected void paintFocus(Graphics g, Rectangle t, Dimension d) {
		// System.out.println(button.getText() + " -> focus");
		FadeTracker fadeTracker = FadeTracker.getInstance();
		FocusKind focusKind = SubstanceCoreUtilities.getFocusKind(this.button);
		if ((focusKind == FocusKind.NONE)
				&& (!fadeTracker.isTracked(this.button, FadeKind.FOCUS)))
			return;
		Graphics2D graphics = (Graphics2D) g.create();
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		float alpha = 1.0f;
		if (fadeTracker.isTracked(this.button, FadeKind.FOCUS)) {
			alpha = fadeTracker.getFade10(this.button, FadeKind.FOCUS) / 10.f;
		}
		// System.out.println(button.getText() + " -> " + alpha);
		graphics.setComposite(TransitionLayout.getAlphaComposite(this.button,
				alpha));

		ColorScheme currScheme = SubstanceCoreUtilities
				.getActiveScheme(this.button);
		Color color = SubstanceCoreUtilities.isThemeDark(SubstanceCoreUtilities
				.getActiveTheme(this.button, true)) ? SubstanceColorUtilities
				.getInterpolatedColor(currScheme.getUltraLightColor(),
						currScheme.getForegroundColor(), 0.4)
				: SubstanceColorUtilities.getInterpolatedColor(currScheme
						.getMidColor(), currScheme.getDarkColor(), 0.5);
		graphics.setColor(color);

		if ((focusKind == FocusKind.TEXT) || (focusKind == FocusKind.ALL)
				|| (focusKind == FocusKind.ALL_INNER)) {
			if (focusKind != FocusKind.TEXT)
				graphics.translate(1, 1);
			else
				graphics.translate(t.x - 1, t.y - 1);
			Shape contour = (focusKind != FocusKind.TEXT) ? BaseButtonShaper
					.getBaseOutline(d.width - 2, d.height - 2, 3, null)
					: BaseButtonShaper.getBaseOutline(t.width + 2,
							t.height + 2, 2, null);
			graphics.setStroke(new BasicStroke(1.1f, BasicStroke.CAP_BUTT,
					BasicStroke.JOIN_ROUND, 0.0f, new float[] { 2.0f, 1.0f },
					0.0f));
			graphics.draw(contour);
		}
		if (focusKind == FocusKind.STRONG_UNDERLINE) {
			graphics.drawLine(t.x, t.y + t.height, t.x + t.width, t.y
					+ t.height);
		}
		if (focusKind == FocusKind.UNDERLINE) {
			graphics.setStroke(new BasicStroke(1.1f, BasicStroke.CAP_BUTT,
					BasicStroke.JOIN_ROUND, 0.0f, new float[] { 2.0f, 1.0f },
					0.0f));
			graphics.drawLine(t.x, t.y + t.height, t.x + t.width, t.y
					+ t.height);
		}

		graphics.dispose();
	}

	/**
	 * Returns memory usage string.
	 * 
	 * @return Memory usage string.
	 */
	public static String getMemoryUsage() {
		StringBuffer sb = new StringBuffer();
		sb.append("SubstanceRadioButtonUI: \n");
		sb.append("\t" + SubstanceRadioButtonUI.icons.size() + " icons");
		return sb.toString();
	}
}
