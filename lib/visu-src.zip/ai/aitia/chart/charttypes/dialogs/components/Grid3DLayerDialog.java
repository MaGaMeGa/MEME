package ai.aitia.chart.charttypes.dialogs.components;

import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.Grid3DDialog.GridDescriptor;
import ai.aitia.chart.charttypes.dialogs.Grid3DDialog.GridLayer;
import ai.aitia.chart.ds.IGrid3DDatasetProducer;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.meme.utils.FormsUtils;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.globalhandlers.UserBreakException;
import ai.aitia.visu.utils.Utils;
import ai.aitia.visu.view.ui.ColorMapFigureRenderer;
import ai.aitia.visu.view.ui.IFigureRenderer;

import com.jgoodies.forms.layout.CellConstraints;

public class Grid3DLayerDialog extends JDialog implements ActionListener,
														FocusListener,
														ChangeListener,
														CaretListener,
														IColorMapUser,
														IShapeRendererUser {
	
	//====================================================================================================
	// members
	
	private static final long serialVersionUID = 1L;
	
	/** Constant label text for series producers. */
	private static final String DEFAULT_TEXT = "Dimensions (one of them is mandatory)";
	
	/** Constant label text for dataset producers. */
	private static final String SPECIAL_TEXT = "Dimensions from the complete grid";  //  @jve:decl-index=0:

	/** Return value constant: indicates that the user closes the dialog by pressing Cancel button (or 'x' in the right top corner). */
	public static final int CANCEL_OPTION = -1;
	/** Return value constant: indicates that the user closes the dialog by pressing OK button. */
	public static final int OK_OPTION = 0;
	
	private ChartConfig config = null;

	private int returnValue = CANCEL_OPTION;
	private GridLayer gridLayer = null;
	
	/** Flag that determines the mode of the chart (sequential or random). */
	private boolean is_full = true;
	
	/** Flag that determines the kind of the width parameter in sequential mode. */
	private boolean user_defined_width = false;
	
	/** Flag that determines the kind of the height parameter in sequential mode. */
	private boolean user_defined_height = false;
	
	/** Flag that determines the kind of the width parameter in random mode. */
	private boolean r_user_defined_width = true;
	
	/** Flag that determines the kind of the height parameter in random mode. */
	private boolean r_user_defined_height = true;

	private Pattern positivePattern = null;
	
	
	//====================================================================================================
	// GUI members
	
	private JPanel content = new JPanel();
	
	private JPanel topPanel = new JPanel(new CardLayout());
	
	private JPanel fullPanel = null;
	private JPanel fFirstPanel = new JPanel(new GridLayout(1,0));
	private JPanel fValuePanel = new JPanel();
	private JButton fValueAdvancedButton = new JButton("Advanced...");
	private JPanel fSwitchPanel = null;
	private JButton fSwitchButton = new JButton("Switch to random filling");
	private JPanel fSecondPanel = null;
	private JPanel fWidthPanel = new JPanel(new CardLayout());
	private JLabel fWidthLabel = new JLabel(" Width:");
	private JComboBox fWidthParam = new JComboBox();
	private JTextField fWidthField = new JTextField("10"); 
	private JButton fWidthButton = new JButton("From user input");
	private JPanel fHeightPanel = new JPanel(new CardLayout());
	private JLabel fHeightLabel = new JLabel("Height:");
	private JComboBox fHeightParam = new JComboBox();
	private JTextField fHeightField = new JTextField("10");
	private JButton fHeightButton = new JButton("From user input");
	private JPanel fThirdPanel = null;
	private JLabel orderLabel = new JLabel(" Filling order:");
	private JRadioButton fLeftToRightButton = new JRadioButton("Left-to-Right");
	private JRadioButton fTopToBottomButton = new JRadioButton("Top-to-Bottom");
	
	private JPanel partialPanel = null;
	private JPanel pFirstPanel = new JPanel(new GridLayout(2,0));
	private JPanel pXPanel = null;
	private JComboBox pXParam = new JComboBox();
	private JButton pXAdvancedButton = new JButton("Advanced...");
	private JPanel pSwitchPanel = null;
	private JButton pSwitchButton = new JButton("Switch to sequential filling");
	private JPanel pYPanel = null;
	private JComboBox pYParam = new JComboBox();
	private JButton pYAdvancedButton = new JButton("Advanced...");
	private JPanel pValuePanel = null;
	private JButton pValueAdvancedButton = new JButton("Advanced...");
	private JPanel pSecondPanel = null;
	private JPanel pWidthPanel = new JPanel(new CardLayout());
	private JComboBox pWidthParam = new JComboBox();
	private JTextField pWidthField = new JTextField();
	private JButton pWidthButton = new JButton("From data source");
	private JPanel 	pHeightPanel = new JPanel(new CardLayout());
	private JComboBox pHeightParam = new JComboBox();
	private JTextField pHeightField = new JTextField();
	private JButton pHeightButton = new JButton("From data source");
	
	private JPanel bottomPanel = null;
	private JRadioButton colorMapButton = new JRadioButton("Colormaps");
	private JCheckBox globalTransparencyBox = new JCheckBox("Use global transparency value");
	private JLabel opaqueLabel = new JLabel("Opaque");
	private JSlider transparencySlider = new JSlider(0,100,50);
	private JLabel transparentLabel = new JLabel("Transparent");
	private ColorMapPanel colorMapPanel = new ColorMapPanel(this); 
	private JRadioButton shapeRendererButton = new JRadioButton("Shape renderers");
	private ShapeRendererPanel shapeRendererPanel = new ShapeRendererPanel(this); 
	
	private JPanel buttonsPanel = new JPanel();
	private JButton okButton = new JButton("Ok");
	private JButton cancelButton = new JButton("Cancel");
	
	//sajat bovites
	private JLabel radiusLabel = new JLabel("Radius");
	private JLabel paddingLabel = new JLabel("Padding");
	private JLabel translateLabel = new JLabel("Translate");
	private JLabel showbaseLabel = new JLabel("Show Base");
	private JLabel rowLabel = new JLabel("Row Title");
	private JLabel columnLabel = new JLabel("Column Title");
	private JLabel colorbarVisLabel = new JLabel("Show Colorbar");
	private JLabel axisVisLabel = new JLabel("Show Axis");
	
	private JCheckBox showbaseCheckBox = new JCheckBox();
	private JTextField radiusField = new JTextField();
	private JTextField paddingField = new JTextField();
	private JTextField translateField = new JTextField();
	private JTextField rowField = new JTextField();
	private JTextField columnField = new JTextField();
	private JCheckBox colorbarVisCheckBox = new JCheckBox();
	private JCheckBox axisVisCheckBox = new JCheckBox();
	
	private JRadioButton surfaceRButt = new JRadioButton("Surface");
	private JRadioButton diagrammRButt = new JRadioButton("Diagramm");
	private JRadioButton objectRButt = new JRadioButton("Object");

	private JPanel LayerTypePanel = null;
	
//	private JPanel fSurfaceValuePanel = null;
//	private JPanel fDiagrammValuePanel = null;
//	private JPanel fObjectValuePanel = null;
	private JComboBox fValueParam_value = new JComboBox();
	private JComboBox fValueParam_color = new JComboBox();
	private JComboBox fValueParam_shape = new JComboBox();
	private JComboBox fValueParam_radius = new JComboBox();
	private JLabel fvalueParamLabel = new JLabel("Value: ");
	private JLabel fcolorParamLabel = new JLabel("Color: ");
	private JLabel fshapeParamLabel = new JLabel("Shape: ");
	private JLabel fradiusParamLabel = new JLabel("Radius: ");
	
	private JLabel pvalueParamLabel = new JLabel("Value: ");
	private JLabel pcolorParamLabel = new JLabel("Color: ");
	private JLabel pshapeParamLabel = new JLabel("Shape: ");
	private JLabel pradiusParamLabel = new JLabel("Radius: ");
	private JComboBox pValueParam_value = new JComboBox();
	private JComboBox pValueParam_color = new JComboBox();
	private JComboBox pValueParam_shape = new JComboBox();
	private JComboBox pValueParam_radius = new JComboBox();
	
	private String currentLayerType = new String();
	
	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public Grid3DLayerDialog(Frame owner, ChartConfig config) {
		super(owner,"Grid layer editor",true);
		this.config = config;
		layoutGUI();
		initialize();
		setWidgetDisabled();
		setLocationRelativeTo(owner);
	}
	
	//----------------------------------------------------------------------------------------------------
	public Grid3DLayerDialog(Frame owner, ChartConfig config, GridLayer gridLayer) {
		this(owner,config);
		this.gridLayer = gridLayer;
		setSettingsFromEditedLayer();
	}
	
	//---------------------------------------------------------------------------------------
	/** Shows the dialog.
	 * @return an int that indicates the closing mode of the dialog
	 */
	public int showDialog() {
		setVisible(true);
		int result = returnValue;
		dispose();
		return result;
	}
	
	//----------------------------------------------------------------------------------------------------
	public GridLayer getGridLayer() { return gridLayer; }
	
	//====================================================================================================
	// implemented interfaces

	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("F_VALUE_PARAM".equals(command)) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam_value.getSelectedItem();
			fValueParam_value.setToolTipText(dsp.toString());
			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			if (dsp.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) {
				fThirdPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
				setEnabledDOWidgets(false);
				if (isWellDefined())
					okButton.setEnabled(true);
			} else {
				fThirdPanel.setBorder(BorderFactory.createTitledBorder(DEFAULT_TEXT));
				setEnabledDOWidgets(true);
				boolean w_valid = (user_defined_width && is_valid(fWidthField.getText())) || (!user_defined_width && fWidthParam.getItemCount() > 0);
				boolean h_valid = (user_defined_height && is_valid(fHeightField.getText())) || (!user_defined_height && fHeightParam.getItemCount() > 0);
				if (!w_valid && !h_valid) 
					okButton.setEnabled(false);
			}
			
			try {
				List<Double> list = (List<Double>) ChartConfigCollection.
				getLOPExecutor().execute("Calculating minimum/maximum values",
						   				 dsp,"getRange");
				setMinMax(list);
			} catch (UserBreakException e1) { setMinMax(null); }
			catch (Throwable t) {
				ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
			}
		} else if ("F_VALUE_ADVANCED".equals(command))
			advanced(fValueParam_value,this);
		else if ("F_SWITCH_BUTTON".equals(command)) {
			CardLayout cl = (CardLayout) topPanel.getLayout();
			cl.show(topPanel,"PARTIAL_PANEL");
			valueVisibles_partial();
			is_full = false;
			if (pXParam.getItemCount() > 0 && pYParam.getItemCount() > 0 && pValueParam_value.getItemCount() > 0 && isWellDefined()) 
				okButton.setEnabled(true);
		} else if ("F_WIDTH_PARAM".equals(command)) 
			tooltip(fWidthParam);
		else if ("F_WIDTH_BUTTON".equals(command)) {
			fWidthButton.setText(user_defined_width ? "From user input" : "From data source");
			user_defined_width ^= true; // negating
			CardLayout cl = (CardLayout) fWidthPanel.getLayout();
			cl.show(fWidthPanel,user_defined_width ? "F_WIDTH_FIELD" : "F_WIDTH_PARAM");
//			if (user_defined_width && !isWellDefined()) 
//				okButton.setEnabled(false);
//			else if (!user_defined_width && fWidthParam.getItemCount() > 0 && isWellDefined()) 
//				okButton.setEnabled(true);
			okButton.setEnabled(isWellDefined());
		} else if ("F_HEIGHT_PARAM".equals(command)) 
			tooltip(fHeightParam);
		else if ("F_HEIGHT_BUTTON".equals(command)) {
			fHeightButton.setText(user_defined_height ? "From user input" : "From data source");
			user_defined_height ^= true; // negating
			CardLayout cl = (CardLayout) fHeightPanel.getLayout();
			cl.show(fHeightPanel,user_defined_height ? "F_HEIGHT_FIELD" : "F_HEIGHT_PARAM");
//			if (user_defined_height && !isWellDefined()) 
//				okButton.setEnabled(false);
//			else if (!user_defined_height && fHeightParam.getItemCount() > 0 && isWellDefined()) 
//				okButton.setEnabled(true);
			okButton.setEnabled(isWellDefined());
		} else if ("P_X_PARAM".equals(command)) {
			IDataSourceProducer dsp = (IDataSourceProducer) pXParam.getSelectedItem();
			pXParam.setToolTipText(dsp.toString());
			pXAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		} else if ("P_X_ADVANCED".equals(command)) 
			advanced(pXParam,this);
		else if ("P_SWITCH_BUTTON".equals(command)) {
			CardLayout cl = (CardLayout) topPanel.getLayout();
			cl.show(topPanel,"FULL_PANEL");
			valueVisibles_full();
			is_full = true;
			if (fValueParam_value.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) fValueParam_value.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(ISeriesProducer.class)) {
					boolean w_valid = (user_defined_width && is_valid(fWidthField.getText())) || (!user_defined_width && fWidthParam.getItemCount() > 0);
					boolean h_valid = (user_defined_height && is_valid(fHeightField.getText())) || (!user_defined_height && fHeightParam.getItemCount() > 0);
					if (!w_valid && !h_valid) 
						okButton.setEnabled(false);
				}
			}
		} else if ("P_Y_PARAM".equals(command)) {
			IDataSourceProducer dsp = (IDataSourceProducer) pYParam.getSelectedItem();
			pYParam.setToolTipText(dsp.toString());
			pYAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		} else if ("P_Y_ADVANCED".equals(command))
			advanced(pYParam,this);
		else if ("P_VALUE_PARAM".equals(command)) {
			IDataSourceProducer dsp = (IDataSourceProducer) pValueParam_value.getSelectedItem();
			pValueParam_value.setToolTipText(dsp.toString());
			pValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());

			try {
				List<Double> list = (List<Double>) ChartConfigCollection.
				getLOPExecutor().execute("Calculating minimum/maximum values",
							             dsp,"getRange");
				setMinMax(list);
			} catch (UserBreakException e1) { setMinMax(null); }
			catch (Throwable t) {
				ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
			}
		} else if ("P_VALUE_ADVANCED".equals(command)) 
			advanced(pValueParam_value,this);
		else if ("P_WIDTH_PARAM".equals(command)) 
			tooltip(pWidthParam);
		else if ("P_WIDTH_BUTTON".equals(command)) {
			pWidthButton.setText(r_user_defined_width ? "From user input" : "From data source");
			r_user_defined_width ^= true; // negating
			CardLayout cl = (CardLayout) pWidthPanel.getLayout();
			cl.show(pWidthPanel,r_user_defined_width ? "P_WIDTH_FIELD" : "P_WIDTH_PARAM");
		} else if ("P_HEIGHT_PARAM".equals(command)) 
			tooltip(pHeightParam);
		else if ("P_HEIGHT_BUTTON".equals(command)) {
			pHeightButton.setText(r_user_defined_height ? "From user input" : "From data source");
			r_user_defined_height ^= true; // negating
			CardLayout cl = (CardLayout) pHeightPanel.getLayout();
			cl.show(pHeightPanel,r_user_defined_height ? "P_HEIGHT_FIELD" : "P_HEIGHT_PARAM");
		} else if ("COLORMAP_BUTTON".equals(command)) {
			globalTransparencyBox.setEnabled(true);
			if (globalTransparencyBox.isSelected()) {
				opaqueLabel.setVisible(true);
				transparencySlider.setVisible(true);
				transparentLabel.setVisible(true);
			}
			colorMapPanel.setEnabled(true);
			
			shapeRendererPanel.setEnabled(false);
			okButton.setEnabled(isWellDefined());
		} else if ("GLOBAL_TRANSPARENCY".equals(command)) {
			opaqueLabel.setVisible(globalTransparencyBox.isSelected());
			transparencySlider.setVisible(globalTransparencyBox.isSelected());
			transparentLabel.setVisible(globalTransparencyBox.isSelected());
		} else if ("SHAPE_RENDERER_BUTTON".equals(command)) {
			globalTransparencyBox.setEnabled(false);
			opaqueLabel.setVisible(false);
			transparencySlider.setVisible(false);
			transparentLabel.setVisible(false);
			colorMapPanel.setEnabled(false);
			shapeRendererPanel.setEnabled(true);
			okButton.setEnabled(isWellDefined());
		} else if ("SURFACE_BUTTON".equals(command)) {
			pSwitchButton.doClick();
			currentLayerType = ChartConstants.SURFACE_LAYER; 
			valueVisibles_full();
			okButton.setEnabled(isWellDefined());
			
		} else if ("DIAGRAMM_BUTTON".equals(command)) {
			pSwitchButton.doClick();
			currentLayerType = ChartConstants.DIAGRAM_LAYER;
			valueVisibles_full();
			okButton.setEnabled(isWellDefined());

		} else if ("OBJECT_BUTTON".equals(command)) {
			pSwitchButton.doClick();
			currentLayerType = ChartConstants.OBJECT_LAYER;
			valueVisibles_full();
			okButton.setEnabled(isWellDefined());
		
	/*	} else if ("TRANSLATE_FIELD".equals(command)) {
			okButton.setEnabled(isWellDefined());
		} else if ("PADDING_FIELD".equals(command)) {
			okButton.setEnabled(isWellDefined());
		} else if ("RADIUS_FIELD".equals(command)) {
			okButton.setEnabled(isWellDefined());*/
		} else if ("OK".equals(command)) {
			createGridLayer();
			returnValue = OK_OPTION;
			setVisible(false);
		} else if ("CANCEL".equals(command)) {
			returnValue = CANCEL_OPTION;
			setVisible(false);
		}
	}
	//----------------------------------------------------------------------------------------------------
	public void valueVisibles_full() 
	{
		pValueParam_color.setVisible(false);
		pvalueParamLabel.setVisible(false);
		pValueParam_value.setVisible(false);
		pcolorParamLabel.setVisible(false);
		pValueParam_radius.setVisible(false);
		pradiusParamLabel.setVisible(false);
		pValueParam_shape.setVisible(false);
		pshapeParamLabel.setVisible(false);
		
		if (currentLayerType.equals(ChartConstants.SURFACE_LAYER))
		{
			fValueParam_value.setVisible(true);
			fvalueParamLabel.setVisible(true);
			fValueParam_color.setVisible(true);
			fcolorParamLabel.setVisible(true);
			fValueParam_radius.setVisible(false);
			fradiusParamLabel.setVisible(false);
			fValueParam_shape.setVisible(false);
			fshapeParamLabel.setVisible(false);			
		}
		else if (currentLayerType.equals(ChartConstants.DIAGRAM_LAYER))
		{
			fValueParam_value.setVisible(true);
			fvalueParamLabel.setVisible(true);
			fValueParam_color.setVisible(true);
			fcolorParamLabel.setVisible(true);
			fValueParam_radius.setVisible(false);
			fradiusParamLabel.setVisible(false);
			fValueParam_shape.setVisible(true);
			fshapeParamLabel.setVisible(true);
		}
		else if (currentLayerType.equals(ChartConstants.OBJECT_LAYER))
		{
			fValueParam_value.setVisible(true);
			fvalueParamLabel.setVisible(true);
			fValueParam_color.setVisible(true);
			fcolorParamLabel.setVisible(true);
			fValueParam_radius.setVisible(true);
			fradiusParamLabel.setVisible(true);
			fValueParam_shape.setVisible(true);
			fshapeParamLabel.setVisible(true);
		}
	}
	
	public void valueVisibles_partial() 
	{
		fValueParam_color.setVisible(false);
		fvalueParamLabel.setVisible(false);
		fValueParam_value.setVisible(false);
		fcolorParamLabel.setVisible(false);
		fValueParam_radius.setVisible(false);
		fradiusParamLabel.setVisible(false);
		fValueParam_shape.setVisible(false);
		fshapeParamLabel.setVisible(false);
		
		if (currentLayerType.equals(ChartConstants.SURFACE_LAYER))
		{
			pValueParam_value.setVisible(true);
			pvalueParamLabel.setVisible(true);
			pValueParam_color.setVisible(true);
			pcolorParamLabel.setVisible(true);
			pValueParam_radius.setVisible(false);
			pradiusParamLabel.setVisible(false);
			pValueParam_shape.setVisible(false);
			pshapeParamLabel.setVisible(false);			
		}
		else if (currentLayerType.equals(ChartConstants.DIAGRAM_LAYER))
		{
			pValueParam_value.setVisible(true);
			pvalueParamLabel.setVisible(true);
			pValueParam_color.setVisible(true);
			pcolorParamLabel.setVisible(true);
			pValueParam_radius.setVisible(false);
			pradiusParamLabel.setVisible(false);
			pValueParam_shape.setVisible(true);
			pshapeParamLabel.setVisible(true);
		}
		else if (currentLayerType.equals(ChartConstants.OBJECT_LAYER))
		{
			pValueParam_value.setVisible(true);
			pvalueParamLabel.setVisible(true);
			pValueParam_color.setVisible(true);
			pcolorParamLabel.setVisible(true);
			pValueParam_radius.setVisible(true);
			pradiusParamLabel.setVisible(true);
			pValueParam_shape.setVisible(true);
			pshapeParamLabel.setVisible(true);
		}
	}

	

	//----------------------------------------------------------------------------------------------------
	public void focusGained(FocusEvent e) {}
	
	//----------------------------------------------------------------------------------------------------
	public void focusLost(FocusEvent e) {
		if (fWidthField.equals(e.getSource())) {
			if (!is_valid(fWidthField.getText())) {
				fWidthField.setText("");
//				if ((user_defined_height && !is_valid(fHeightField.getText())) ||
//					(!user_defined_height && fHeightParam.getItemCount() == 0)) 
//					okButton.setEnabled(false);
				okButton.setEnabled(isWellDefined());
			}
		} else if (fHeightField.equals(e.getSource())) {
			if (!is_valid(fHeightField.getText())) {
				fHeightField.setText("");
//				if ((user_defined_width && !is_valid(fWidthField.getText())) ||
//					(!user_defined_width && fWidthParam.getItemCount() == 0)) 
//					okButton.setEnabled(false);
				okButton.setEnabled(isWellDefined());
			}
		} else if (pWidthField.equals(e.getSource())) {
			if (!is_valid(pWidthField.getText())) pWidthField.setText("");
		} else if (pHeightField.equals(e.getSource())) {
			if (!is_valid(pHeightField.getText())) pHeightField.setText("");
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void stateChanged(ChangeEvent e) {
		transparencySlider.setToolTipText(transparencySlider.getValue() + " %");
	}
	
	//----------------------------------------------------------------------------------------------------
	public void caretUpdate(CaretEvent e) {
		okButton.setEnabled(isWellDefined());
//		if (fWidthField.equals(e.getSource())) {
//			if (isWellDefined()) 
//				okButton.setEnabled(true);
//			else if ((user_defined_height && !is_valid(fHeightField.getText())) ||
//			    	(!user_defined_height && fHeightParam.getItemCount() == 0)) 
//				okButton.setEnabled(false);
//		} else if (fHeightField.equals(e.getSource())) {
//			if (isWellDefined()) 
//				okButton.setEnabled(true);
//			else if ((user_defined_width && !is_valid(fWidthField.getText())) ||
//					(!user_defined_width && fWidthParam.getItemCount() == 0)) 
//				okButton.setEnabled(false);
//		}
	}

	//----------------------------------------------------------------------------------------------------
	public IDataSourceProducer getColorValueProducer() {
		return (IDataSourceProducer) (is_full ? fValueParam_value.getSelectedItem() : pValueParam_value.getSelectedItem());
	}
	
	//----------------------------------------------------------------------------------------------------
	public void setUpdateStatus(boolean status) {
		boolean paramAvailable = /* fValueParam.getItemCount() > 0;*/ isWellDefined();
		if (colorMapButton.isSelected())
			okButton.setEnabled(paramAvailable && colorMapPanel.hasDefinedColormap());
		else
			okButton.setEnabled(paramAvailable && shapeRendererPanel.hasDefinedRenderer());
	}

	//----------------------------------------------------------------------------------------------------
	public IDataSourceProducer getShapeValueProducer() {
		return (IDataSourceProducer) (is_full ? fValueParam_value.getSelectedItem() : pValueParam_value.getSelectedItem());
	}
	
	//====================================================================================================
	// GUI methods
	
	//----------------------------------------------------------------------------------------------------
	private void layoutGUI() {
		content.setLayout(new BoxLayout(content,BoxLayout.Y_AXIS));
		
		LayerTypePanel = FormsUtils.build("p ~ p ~ p",
										  "012",
										  surfaceRButt, diagrammRButt, objectRButt).getPanel();
		
		content.add(LayerTypePanel);
	
		fValuePanel = FormsUtils.build("f:p:g ~ p ~ p",
				 "501||" +
				 "62_||" +
				 "73_||" +
				 "84_||",
				 fValueParam_value,fValueAdvancedButton,
				 fValueParam_color,fValueParam_shape,fValueParam_radius,
				 fvalueParamLabel, fcolorParamLabel, fshapeParamLabel, fradiusParamLabel).getPanel();

		/*
		fSurfaceValuePanel = FormsUtils.build("f:p:g ~ p",
				 						 "01||" +
				 						 "2_",
				 						 fValueParam_value,fValueAdvancedButton,
				 						 fValueParam_color).getPanel();
		
		fDiagrammValuePanel = FormsUtils.build("f:p:g ~ p",
					 						   "01",
					 						   fValueParam_value,fValueAdvancedButton).getPanel();
		
		fObjectValuePanel = FormsUtils.build("f:p:g ~ p",
					 						 "01",
					 						 fValueParam_value,fValueAdvancedButton).getPanel();
		
		fValuePanel.add(fSurfaceValuePanel, "SURFACE_VALUE");
		
		fValuePanel.add(fDiagrammValuePanel, "DIAGRAMM_VALUE");

		fValuePanel.add(fObjectValuePanel, "OBJECT_VALUE");
*/
		fFirstPanel.add(fValuePanel);
		
		fSwitchPanel = FormsUtils.build("p:g p",
										"_0",
										fSwitchButton,CellConstraints.RIGHT).getPanel();
		fFirstPanel.add(fSwitchPanel);
		
		fWidthParam.setName("F_WIDTH_PARAM");
		fWidthPanel.add(fWidthParam,fWidthParam.getName());
		fWidthField.setName("F_WIDTH_FIELD");
		fWidthPanel.add(fWidthField,fWidthField.getName());
		
		fHeightParam.setName("F_HEIGHT_PARAM");
		fHeightPanel.add(fHeightParam,fHeightParam.getName());
		fHeightField.setName("F_HEIGHT_FIELD");
		fHeightPanel.add(fHeightField,fHeightField.getName());
		
		fSecondPanel = FormsUtils.build("p ~ p:g ~ p ~ ~ p ~ p:g ~ p",
										"012345",
										fWidthLabel,fWidthPanel,fWidthButton,fHeightLabel,fHeightPanel,fHeightButton).getPanel();
		
		fThirdPanel = FormsUtils.build("p ~ p ~ p",
									   "012|", 
									   orderLabel,fLeftToRightButton,
									   fTopToBottomButton).getPanel();
		
		fullPanel = FormsUtils.build("p:g",
									 "|0|" +
									  "1|" +
									  "2|" +
									  "_ f:p:g",
									  fFirstPanel,
									  fSecondPanel,
									  fThirdPanel).getPanel();
		fullPanel.setName("FULL_PANEL");
		topPanel.add(fullPanel,fullPanel.getName());
		
		pXPanel = FormsUtils.build("f:p:g ~ p",
								   "01",
								   pXParam,pXAdvancedButton).getPanel();

		pFirstPanel.add(pXPanel);
		
		pSwitchPanel = FormsUtils.build("p:g p",
										"_0",
										pSwitchButton,CellConstraints.RIGHT).getPanel();
		pFirstPanel.add(pSwitchPanel);
		
		pYPanel = FormsUtils.build("f:p:g ~ p",
								   "01",
								   pYParam,pYAdvancedButton).getPanel();
		pFirstPanel.add(pYPanel);
		
		pValuePanel = FormsUtils.build("f:p:g ~ p ~ p",
				 "501||" +
				 "62_||" +
				 "73_||" +
				 "84_||",
				 pValueParam_value,fValueAdvancedButton,
				 pValueParam_color,pValueParam_shape,pValueParam_radius,
				 pvalueParamLabel, pcolorParamLabel, pshapeParamLabel, pradiusParamLabel).getPanel();
		
		pFirstPanel.add(pValuePanel);
		
		pWidthField.setName("P_WIDTH_FIELD");
		pWidthPanel.add(pWidthField,pWidthField.getName());
		pWidthParam.setName("P_WIDTH_PARAM");
		pWidthPanel.add(pWidthParam,pWidthParam.getName());
		
		pHeightField.setName("P_HEIGHT_FIELD");
		pHeightPanel.add(pHeightField,pHeightField.getName());
		pHeightParam.setName("P_HEIGHT_PARAM");
		pHeightPanel.add(pHeightParam,pHeightParam.getName());
		
		pSecondPanel = 	FormsUtils.build("p ~ p:g ~ p ~ ~ p ~ p:g ~ p",
										 "012345",
										 " Width:",pWidthPanel,pWidthButton,"Height:",pHeightPanel,pHeightButton).getPanel();

		
		partialPanel = FormsUtils.build("p:g",
										"|0|" +
										 "1|" +
										 "_ f:p:g",
										 pFirstPanel,
										 pSecondPanel).getPanel();
		
		partialPanel.setName("PARTIAL_PANEL");
		topPanel.add(partialPanel,partialPanel.getName());
		
		content.add(topPanel);
		
		bottomPanel = FormsUtils.build("p ~ p ~ p ~ p:g ~ p",
									   "AGBJ_||" +
									   "8E9F_||" +
									   "CIDH_||" +
									   "MKNL_||" +
									   "00___||" +
									   "_1234||" +
									   "_5555||" +
									   "6633_||" +
									   "_7777|" +
									   "_____ f:p:g",
									   colorMapButton,
									   globalTransparencyBox,opaqueLabel,transparencySlider,transparentLabel,
									   colorMapPanel,
									   shapeRendererButton,
									   shapeRendererPanel,
									   radiusLabel, paddingLabel, translateLabel, showbaseLabel, rowLabel, columnLabel,
									   radiusField, paddingField, translateField, rowField, columnField,
									   showbaseCheckBox, colorbarVisCheckBox, axisVisCheckBox, colorbarVisLabel,axisVisLabel).getPanel();
		
		content.add(bottomPanel);
		
		content.add(new JSeparator(JSeparator.VERTICAL));
		buttonsPanel.add(okButton);
		buttonsPanel.add(cancelButton);
		content.add(buttonsPanel);
		
		this.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				returnValue = CANCEL_OPTION;
			}
		});
	}
	
	//----------------------------------------------------------------------------------------------------
	private void initialize() {
		content.setBorder(BorderFactory.createEmptyBorder(3,3,3,3));
		
		LayerTypePanel.setBorder(BorderFactory.createTitledBorder("Layer Type"));
		
		currentLayerType = ChartConstants.SURFACE_LAYER;
		ButtonGroup LTypeGroup = new ButtonGroup();
		LTypeGroup.add(surfaceRButt);
		LTypeGroup.add(diagrammRButt);
		LTypeGroup.add(objectRButt);
		surfaceRButt.setSelected(true);
		
		translateField.setText("0");
//		translateField.setActionCommand("TRANSLATE_FIELD");
		radiusField.setText("1");
//		radiusField.setActionCommand("RADIUS_FIELD");
		paddingField.setText("0");
//		paddingField.setActionCommand("PADDING_FIELD");
		rowField.setText("");
		columnField.setText("");
		showbaseCheckBox.setSelected(true);
		colorbarVisCheckBox.setSelected(true);
		axisVisCheckBox.setSelected(true);
		
		surfaceRButt.setActionCommand("SURFACE_BUTTON");
		diagrammRButt.setActionCommand("DIAGRAMM_BUTTON");
		objectRButt.setActionCommand("OBJECT_BUTTON");
		
		fradiusParamLabel.setVisible(false);
		fshapeParamLabel.setVisible(false);
		fValueParam_shape.setVisible(false);
		fValueParam_radius.setVisible(false);
		
		pradiusParamLabel.setVisible(false);
		pshapeParamLabel.setVisible(false);
		pValueParam_shape.setVisible(false);
		pValueParam_radius.setVisible(false);
		
		fSecondPanel.setBorder(BorderFactory.createTitledBorder(DEFAULT_TEXT));

		fValuePanel.setBorder(BorderFactory.createTitledBorder("Values / Complete grid"));
		fValueParam_value.setModel(new DefaultComboBoxModel(getParamsToValues()));
		fValueParam_value.setRenderer(new DataSourceComboBoxRenderer(fValueParam_value));
		fValueParam_value.setPreferredSize(new Dimension(200,26));
/*		if (fValueParam_value.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam_value.getSelectedItem();
			fValueParam_value.setToolTipText(dsp.toString());
			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			
			if (dsp.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) {  
				setEnabledDOWidgets(false);
				fSecondPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
			}
		}*/
		fValueParam_value.setActionCommand("F_VALUE_PARAM");
		fValueAdvancedButton.setActionCommand("F_VALUE_ADVANCED");
		
		fValueParam_color.setModel(new DefaultComboBoxModel(getParamsToValues()));
		fValueParam_color.setRenderer(new DataSourceComboBoxRenderer(fValueParam_value));
		fValueParam_color.setPreferredSize(new Dimension(200,26));
/*		if (fValueParam_color.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam_color.getSelectedItem();
			fValueParam_color.setToolTipText(dsp.toString());
//			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			
			if (dsp.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) {  
				setEnabledDOWidgets(false);
				fSecondPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
			}
		}*/
		fValueParam_color.setActionCommand("F_VALUE_PARAM_COLOR");
		
		fValueParam_shape.setModel(new DefaultComboBoxModel(getParamsToValues()));
		fValueParam_shape.setRenderer(new DataSourceComboBoxRenderer(fValueParam_shape));
		fValueParam_shape.setPreferredSize(new Dimension(200,26));
/*		if (fValueParam_shape.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam_shape.getSelectedItem();
			fValueParam_shape.setToolTipText(dsp.toString());
//			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			
			if (dsp.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) {  
				setEnabledDOWidgets(false);
				fSecondPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
			}
		}*/
		fValueParam_shape.setActionCommand("F_VALUE_PARAM_SHAPE");
		
		fValueParam_radius.setModel(new DefaultComboBoxModel(getParamsToValues()));
		fValueParam_radius.setRenderer(new DataSourceComboBoxRenderer(fValueParam_radius));
		fValueParam_radius.setPreferredSize(new Dimension(200,26));
/*		if (fValueParam_radius.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam_radius.getSelectedItem();
			fValueParam_radius.setToolTipText(dsp.toString());
//			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			
			if (dsp.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) {  
				setEnabledDOWidgets(false);
				fSecondPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
			}
		}*/
		fValueParam_radius.setActionCommand("F_VALUE_PARAM_RADIUS");
		
		fSwitchPanel.setBorder(BorderFactory.createTitledBorder("Grid filling mode: sequential"));
		fSwitchButton.setActionCommand("F_SWITCH_BUTTON");
		
		fWidthParam.setModel(new DefaultComboBoxModel(getParamsToDimensions()));
		fWidthParam.setRenderer(new DataSourceComboBoxRenderer(fWidthParam));
		fWidthParam.setPreferredSize(new Dimension(100,26));
		if (fWidthParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fWidthParam.getSelectedItem();
			fWidthParam.setToolTipText(dsp.toString());
		}
		fWidthParam.setActionCommand("F_WIDTH_PARAM");
		
		fWidthField.setHorizontalAlignment(JTextField.TRAILING);
		fWidthField.addCaretListener(this);
		fWidthField.addFocusListener(this);
		
		fWidthButton.setActionCommand("F_WIDTH_BUTTON");
		
		fHeightParam.setModel(new DefaultComboBoxModel(getParamsToDimensions()));
		fHeightParam.setRenderer(new DataSourceComboBoxRenderer(fHeightParam));
		fHeightParam.setPreferredSize(new Dimension(100,26));
		if (fHeightParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fHeightParam.getSelectedItem();
			fHeightParam.setToolTipText(dsp.toString());
		}
		fHeightParam.setActionCommand("F_HEIGHT_PARAM");
		
		fHeightField.setHorizontalAlignment(JTextField.TRAILING);
		fHeightField.addCaretListener(this);
		fHeightField.addFocusListener(this);
		
		fHeightButton.setActionCommand("F_HEIGHT_BUTTON");
		
		fThirdPanel.setBorder(BorderFactory.createTitledBorder("Order"));
		ButtonGroup g = new ButtonGroup();
		g.add(fLeftToRightButton);
		g.add(fTopToBottomButton);
		fLeftToRightButton.setSelected(true);
		
		pXPanel.setBorder(BorderFactory.createTitledBorder("X coordinates"));
		pXParam.setModel(new DefaultComboBoxModel(getParamsToAll()));
		pXParam.setRenderer(new DataSourceComboBoxRenderer(pXParam));
		pXParam.setPreferredSize(new Dimension(200,26));
		if (pXParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) pXParam.getSelectedItem();
			pXParam.setToolTipText(dsp.toString());
			pXAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		}
		pXParam.setActionCommand("P_X_PARAM");
		pXAdvancedButton.setActionCommand("P_X_ADVANCED");
		
		pSwitchPanel.setBorder(BorderFactory.createTitledBorder("Grid filling mode: random"));
		pSwitchButton.setActionCommand("P_SWITCH_BUTTON");
		
		pYPanel.setBorder(BorderFactory.createTitledBorder("Y coordinates"));
		pYParam.setModel(new DefaultComboBoxModel(getParamsToAll()));
		pYParam.setRenderer(new DataSourceComboBoxRenderer(pYParam));
		pYParam.setPreferredSize(new Dimension(200,26));
		if (pYParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) pYParam.getSelectedItem();
			pYParam.setToolTipText(dsp.toString());
			pYAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		}
		pYParam.setActionCommand("P_Y_PARAM");
		pYAdvancedButton.setActionCommand("P_Y_ADVANCED");
		
		pValuePanel.setBorder(BorderFactory.createTitledBorder("Values"));		
/*		pValueParam_value.setModel(new DefaultComboBoxModel(getParamsToAll()));
		pValueParam_value.setRenderer(new DataSourceComboBoxRenderer(pValueParam_value));
		pValueParam_value.setPreferredSize(new Dimension(200,26));
		if (pValueParam_value.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) pValueParam_value.getSelectedItem();
			pValueParam_value.setToolTipText(dsp.toString());
			pValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		}
		pValueParam_value.setActionCommand("P_VALUE_PARAM");
		pValueAdvancedButton.setActionCommand("P_VALUE_ADVANCED");*/
		
		pValueParam_value.setModel(new DefaultComboBoxModel(getParamsToValues()));
		pValueParam_value.setRenderer(new DataSourceComboBoxRenderer(fValueParam_value));
		pValueParam_value.setPreferredSize(new Dimension(200,26));
/*		if (fValueParam_value.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam_value.getSelectedItem();
			fValueParam_value.setToolTipText(dsp.toString());
			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			
			if (dsp.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) {  
				setEnabledDOWidgets(false);
				fSecondPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
			}
		}*/
		pValueParam_value.setActionCommand("F_VALUE_PARAM");
		pValueAdvancedButton.setActionCommand("F_VALUE_ADVANCED");
		
		pValueParam_color.setModel(new DefaultComboBoxModel(getParamsToValues()));
		pValueParam_color.setRenderer(new DataSourceComboBoxRenderer(fValueParam_value));
		pValueParam_color.setPreferredSize(new Dimension(200,26));
/*		if (fValueParam_color.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam_color.getSelectedItem();
			fValueParam_color.setToolTipText(dsp.toString());
//			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			
			if (dsp.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) {  
				setEnabledDOWidgets(false);
				fSecondPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
			}
		}*/
		pValueParam_color.setActionCommand("F_VALUE_PARAM_COLOR");
		
		pValueParam_shape.setModel(new DefaultComboBoxModel(getParamsToValues()));
		pValueParam_shape.setRenderer(new DataSourceComboBoxRenderer(fValueParam_shape));
		pValueParam_shape.setPreferredSize(new Dimension(200,26));
/*		if (fValueParam_shape.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam_shape.getSelectedItem();
			fValueParam_shape.setToolTipText(dsp.toString());
//			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			
			if (dsp.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) {  
				setEnabledDOWidgets(false);
				fSecondPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
			}
		}*/
		pValueParam_shape.setActionCommand("F_VALUE_PARAM_SHAPE");
		
		pValueParam_radius.setModel(new DefaultComboBoxModel(getParamsToValues()));
		pValueParam_radius.setRenderer(new DataSourceComboBoxRenderer(fValueParam_radius));
		pValueParam_radius.setPreferredSize(new Dimension(200,26));
/*		if (fValueParam_radius.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam_radius.getSelectedItem();
			fValueParam_radius.setToolTipText(dsp.toString());
//			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			
			if (dsp.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) {  
				setEnabledDOWidgets(false);
				fSecondPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
			}
		}*/
		pValueParam_radius.setActionCommand("F_VALUE_PARAM_RADIUS");
		
		pSecondPanel.setBorder(BorderFactory.createTitledBorder("Dimensions (optional)"));
		
		pWidthParam.setModel(new DefaultComboBoxModel(getParamsToDimensions()));
		pWidthParam.setRenderer(new DataSourceComboBoxRenderer(pWidthParam));
		pWidthParam.setPreferredSize(new Dimension(100,26));
		if (pWidthParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) pWidthParam.getSelectedItem();
			pWidthParam.setToolTipText(dsp.toString());
		}
		pWidthParam.setActionCommand("P_WIDTH_PARAM");
		
		pWidthField.setHorizontalAlignment(JTextField.TRAILING);
		pWidthField.addFocusListener(this);
		
		pWidthButton.setActionCommand("P_WIDTH_BUTTON");
		
		pHeightParam.setModel(new DefaultComboBoxModel(getParamsToDimensions()));
		pHeightParam.setRenderer(new DataSourceComboBoxRenderer(pHeightParam));
		pHeightParam.setPreferredSize(new Dimension(100,26));
		if (pHeightParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) pHeightParam.getSelectedItem();
			pHeightParam.setToolTipText(dsp.toString());
		}
		pHeightParam.setActionCommand("P_HEIGHT_PARAM");
		
		pHeightField.setHorizontalAlignment(JTextField.TRAILING);
		pHeightField.addFocusListener(this);
		
		pHeightButton.setActionCommand("P_HEIGHT_BUTTON");	
		
		bottomPanel.setBorder(BorderFactory.createTitledBorder("Value visualisation"));
		
		g = new ButtonGroup();
		g.add(colorMapButton);
		g.add(shapeRendererButton);
		
		colorMapButton.setSelected(true);
		colorMapButton.setActionCommand("COLORMAP_BUTTON");
		globalTransparencyBox.setActionCommand("GLOBAL_TRANSPARENCY");
		globalTransparencyBox.setPreferredSize(new Dimension(200,26));
		opaqueLabel.setVisible(false);
		transparencySlider.setVisible(false);
		transparencySlider.setToolTipText("50 %");
		transparencySlider.addChangeListener(this);
		transparentLabel.setVisible(false);
		colorMapPanel.setPreferredSize(new Dimension(400,26));
		
		shapeRendererButton.setActionCommand("SHAPE_RENDERER_BUTTON");
		shapeRendererPanel.setPreferredSize(new Dimension(400,52));
		shapeRendererPanel.setEnabled(false);
		
		okButton.setActionCommand("OK");
		cancelButton.setActionCommand("CANCEL");
		
		Utilities.addActionListener(this,fValueParam_value,fValueParam_radius,fValueParam_shape,
									fValueParam_color,fValueAdvancedButton,fSwitchButton,
									fWidthParam,fWidthButton,fHeightParam,fHeightButton,
									pXParam,pXAdvancedButton,pSwitchButton,pYParam,
									pYAdvancedButton,pValueParam_value,pValueAdvancedButton,
									pWidthParam,pWidthButton,pHeightPanel,pHeightButton,
									colorMapButton,globalTransparencyBox,shapeRendererButton,
									okButton,cancelButton,surfaceRButt,diagrammRButt,objectRButt,
									translateField,radiusField,paddingField);
		
		final JScrollPane sp = new JScrollPane(content,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		sp.setBorder(null);
		this.setContentPane(sp);
		this.pack();
		Dimension oldD = this.getPreferredSize();
		this.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
								     		oldD.height + sp.getHorizontalScrollBar().getHeight()));
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		oldD = this.getPreferredSize();
		final Dimension newD = Utils.getPreferredSize(this);
		if (!oldD.equals(newD)) 
			this.setPreferredSize(newD);
		this.pack();
	}
	
	//----------------------------------------------------------------------------------------------------
	private void setSettingsFromEditedLayer() {
		GridDescriptor descriptor = gridLayer.getDescriptor();
		
		if (gridLayer.getSpecProperties().getProperty(ChartConstants.TYPE).equals(ChartConstants.SURFACE_LAYER)) {
			surfaceRButt.setSelected(true);
			surfaceRButt.doClick();
		} else if (gridLayer.getSpecProperties().getProperty(ChartConstants.TYPE).equals(ChartConstants.DIAGRAM_LAYER))	{
			diagrammRButt.setSelected(true);
			diagrammRButt.doClick();
		} else if (gridLayer.getSpecProperties().getProperty(ChartConstants.TYPE).equals(ChartConstants.OBJECT_LAYER)) {
			objectRButt.setSelected(true);
			objectRButt.doClick();
		}
		
		if (descriptor.dataSources.size() == 2 || descriptor.dataSources.size() == 3 || (descriptor.dataSources.size() == 4 && !gridLayer.getSpecProperties().getProperty(ChartConstants.TYPE).equals(ChartConstants.SURFACE_LAYER))) { // full mode
 				is_full = true;
 				IDataSourceProducer dsp_v = descriptor.dataSources.get(0);
 				IDataSourceProducer dsp_c = descriptor.dataSources.get(1);
 				
 				fValueParam_value.setSelectedItem(dsp_v);
 				fValueParam_color.setSelectedItem(dsp_c);
 				
 				if (!currentLayerType.equals(ChartConstants.SURFACE_LAYER))
 				{
 					IDataSourceProducer dsp_s = descriptor.dataSources.get(2);
 	 				
 					fValueParam_shape.setSelectedItem(dsp_s);
 					if (currentLayerType.equals(ChartConstants.OBJECT_LAYER))
 					{
 						IDataSourceProducer dsp_r = descriptor.dataSources.get(3);
 						fValueParam_radius.setSelectedItem(dsp_r);
 		 			}
 				}
 				
 				if (dsp_v.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) 
 					setEnabledDOWidgets(false);
 				user_defined_width = descriptor.userDefinedWidth; 
 				if (user_defined_width) {
 					CardLayout cl = (CardLayout) fWidthPanel.getLayout();
					cl.show(fWidthPanel,"F_WIDTH_FIELD");
 					fWidthField.setText(descriptor.width == -1 ? "" : String.valueOf(descriptor.width));
 				} else 
 					fWidthParam.setSelectedItem(descriptor.widthProducer);
 				user_defined_height = descriptor.userDefinedHeight;
 				if (user_defined_height) {
 					CardLayout cl = (CardLayout) fHeightPanel.getLayout();
					cl.show(fHeightPanel,"F_HEIGHT_FIELD");
 					fHeightField.setText(descriptor.height == -1 ? "" : String.valueOf(descriptor.height));
 				} else 
 					fHeightParam.setSelectedItem(descriptor.heightProducer);
 				if (!descriptor.rowOrder)
 					fTopToBottomButton.setSelected(true);
 				
 				
 		} else { // three datasources, partial mode
			is_full = false;
			CardLayout cl = (CardLayout) topPanel.getLayout();
//			cl.show(topPanel,"PARTIAL_PANEL");
			fSwitchButton.doClick();
			pXParam.setSelectedItem(descriptor.dataSources.get(0));
			pYParam.setSelectedItem(descriptor.dataSources.get(1));
			pValueParam_value.setSelectedItem(descriptor.dataSources.get(2));
			pValueParam_color.setSelectedItem(descriptor.dataSources.get(3));
			
			if (currentLayerType != ChartConstants.SURFACE_LAYER)
			{
				IDataSourceProducer dsp_s = descriptor.dataSources.get(4);
	 			
				pValueParam_shape.setSelectedItem(dsp_s);
				if (currentLayerType == ChartConstants.OBJECT_LAYER)
				{
					IDataSourceProducer dsp_r = descriptor.dataSources.get(5);
					pValueParam_radius.setSelectedItem(dsp_r);
		 		}
			}
			
			r_user_defined_width = descriptor.userDefinedWidth;
			if (r_user_defined_width) 
				pWidthField.setText(descriptor.height == -1 ? "" : String.valueOf(descriptor.height));
			else { 
				cl = (CardLayout) pWidthPanel.getLayout();
				cl.show(pWidthPanel,"P_WIDTH_PARAM");
				pWidthButton.setText("From user input");
				pWidthParam.setSelectedItem(descriptor.widthProducer);
			}
			r_user_defined_height = descriptor.userDefinedHeight;
			if (r_user_defined_height) 
				pHeightField.setText(descriptor.height == -1 ? "" : String.valueOf(descriptor.height));
			else {
				cl = (CardLayout) pHeightPanel.getLayout();
				cl.show(pHeightPanel,"P_HEIGHT_PARAM");
				pHeightButton.setText("From user input");
				pHeightParam.setSelectedItem(descriptor.heightProducer);
			}
		}
		
		IFigureRenderer renderer = gridLayer.getRenderer();
		if (renderer instanceof ColorMapFigureRenderer) {
			ColorMapFigureRenderer _renderer = (ColorMapFigureRenderer) renderer;
			if (_renderer.getGlobalAlpha() >= 0) {
				globalTransparencyBox.doClick(0);
				transparencySlider.setValue((int)((1 - _renderer.getGlobalAlpha()) * 100));
			}
			colorMapPanel.setSettings(_renderer.getColorMap());
		} else {
			shapeRendererButton.setSelected(true);
			shapeRendererButton.doClick(0);
			shapeRendererPanel.setSettings(renderer,gridLayer.getRendererProperties());
		}
		
		showbaseCheckBox.setSelected(Boolean.parseBoolean(gridLayer.getSpecProperties().getProperty(ChartConstants.SHOW_BASE)));
		colorbarVisCheckBox.setSelected(Boolean.parseBoolean(gridLayer.getSpecProperties().getProperty(ChartConstants.SHOW_COLORBAR)));
		axisVisCheckBox.setSelected(Boolean.parseBoolean(gridLayer.getSpecProperties().getProperty(ChartConstants.SHOW_AXIS)));
		radiusField.setText(gridLayer.getSpecProperties().getProperty(ChartConstants.RADIUS));
		paddingField.setText(gridLayer.getSpecProperties().getProperty(ChartConstants.PADDING));
		translateField.setText(gridLayer.getSpecProperties().getProperty(ChartConstants.TRANSLATE));
		rowField.setText(gridLayer.getSpecProperties().getProperty(ChartConstants.ROW_LABEL));
		columnField.setText(gridLayer.getSpecProperties().getProperty(ChartConstants.COLUMN_LABEL));
		
		okButton.setEnabled(true);
 	}
	
	//====================================================================================================
	// private methods
	
 	//----------------------------------------------------------------------------------------------------
	private Object[] getParamsToValues() {
 		return getParams(new Class[]{ISeriesProducer.class, IValueProducer.class, IGrid3DDatasetProducer.class});
 	}
	
	//----------------------------------------------------------------------------------------------------
	private Object[] getParamsToAll() {
 		return getParams(ISeriesProducer.class, IValueProducer.class);
 	}
	
 	//------------------------------------------------------------------------------
 	private Object[] getParamsToDimensions() {
 		return getParams(IValueProducer.class);
 	}
	
	//----------------------------------------------------------------------------------------------------
	private Object[] getParams(Class... intfs) {
 		List<IDataSourceProducer> candidates = config.getDSPCollection().getList();
		List<IDataSourceProducer> accepted = new ArrayList<IDataSourceProducer>();
		Iterator<IDataSourceProducer> it = candidates.iterator();
		while (it.hasNext()) {
			IDataSourceProducer dsp = it.next();
			for (int i=0;i<intfs.length;++i) {
				if (Utilities.canBe(dsp,intfs[i])) {
					accepted.add(dsp);
					break;
				}
			}
		}
		return accepted.toArray();
 	}
	
	//----------------------------------------------------------------------------------------------------
	private void setEnabledDOWidgets(boolean enabled) {
		fWidthLabel.setEnabled(enabled);
		fWidthParam.setEnabled(enabled && fWidthParam.getItemCount() > 0);
		fWidthField.setEnabled(enabled);
		fWidthButton.setEnabled(enabled);
		fHeightLabel.setEnabled(enabled);
		fHeightParam.setEnabled(enabled && fHeightParam.getItemCount() > 0);
		fHeightField.setEnabled(enabled);
		fHeightButton.setEnabled(enabled);
		orderLabel.setEnabled(enabled);
		fLeftToRightButton.setEnabled(enabled);
		fTopToBottomButton.setEnabled(enabled);
	}
	
	//------------------------------------------------------------------------------
	/** Returns whether the input string contains a valid positive integer or
	 *  not.
	 * @param text input string
	 */
	private boolean is_valid(String text) {
		if (positivePattern == null)
		  positivePattern = Pattern.compile("^[1-9][0-9]*$"); // pattern for positive integers
		Matcher m = positivePattern.matcher(text.trim());
		if (m.matches()) {
			try {
				Integer.parseInt(text.trim());
				return true;
			} catch (NumberFormatException e) {}
		}
		return false;
	}
	
	//------------------------------------------------------------------------------
	/** Sets the minimum value and maximum value fields of the color map panel.
	 * @param minmax a list that contains the minimum and maximum values (or <code>null</code>)
	 */
	private void setMinMax(List<Double> minmax) {
		if (minmax != null) {
			colorMapPanel.setMinValue(String.valueOf(minmax.get(0)));
			colorMapPanel.setMaxValue(String.valueOf(minmax.get(1)));
		} else {
			colorMapPanel.setMinValue("");
			colorMapPanel.setMaxValue("");
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	private void advanced(JComboBox param, Component comp) {
		IDataSourceProducer dsp = (IDataSourceProducer) param.getSelectedItem();
		IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(comp);
		if (new_dsp != null) {
			int index = param.getSelectedIndex();
			param.removeItemAt(index);
			param.insertItemAt(new_dsp,index);
			param.setSelectedIndex(index);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	private void tooltip(JComboBox param) {
		IDataSourceProducer dsp = (IDataSourceProducer) param.getSelectedItem();
		param.setToolTipText(dsp.toString());
	}
	
	//----------------------------------------------------------------------------------------------------
	private boolean isWellDefined() {
		if (colorMapButton.isSelected() && !colorMapPanel.hasDefinedColormap()) return false;
		if (translateField.getText().equals("") || radiusField.getText().equals("") || paddingField.getText().equals("")) return false;
		if (shapeRendererButton.isSelected() && !shapeRendererPanel.hasDefinedRenderer()) return false;
 		if (is_full) 
 		{
 			if (fValueParam_color.getItemCount() != 0 && fValueParam_value.getItemCount() != 0)
 			{
 				if (!currentLayerType.equals(ChartConstants.SURFACE_LAYER))
 				{
 					if (fValueParam_shape.getItemCount() == 0)
 					{
 						return false;
 					}
 					else
 					{
 						if (currentLayerType.equals(ChartConstants.OBJECT_LAYER))
 						{
 							if (fValueParam_radius.getItemCount() == 0)
 							{
 								return false;
 							}
 						}
 					}
 				}
 			} 			
 			else
 			{
 				return false;
 			}
 			
 			IDataSourceProducer vdsp = (IDataSourceProducer) fValueParam_value.getSelectedItem();
 			if (vdsp.getSupportedIntfs().contains(IGrid3DDatasetProducer.class)) return true;
			boolean w_valid = (user_defined_width && is_valid(fWidthField.getText())) || (!user_defined_width && fWidthParam.getItemCount() > 0);
			boolean h_valid = (user_defined_height && is_valid(fHeightField.getText())) || (!user_defined_height && fHeightParam.getItemCount() > 0);
 			if (w_valid || h_valid) return true;
 		} 
 		else
 		{
 			if (pValueParam_color.getItemCount() != 0 && pValueParam_value.getItemCount() != 0)
 			{
 				if (currentLayerType != ChartConstants.SURFACE_LAYER)
 				{
 					if (pValueParam_shape.getItemCount() != 0)
 					{
 	 					if (currentLayerType == ChartConstants.OBJECT_LAYER)
 	 					{
 	 						 if (pValueParam_radius.getItemCount() == 0)
 	 						 {
 	 							 return false;
 	 						 }
 	 					}
 	 					else
 	 					{
 	 						return true;
 	 					}
 					}
 					else
 					{
 						return false;
 					}
 				}
 				else
 				{
 					return true;
 				}
 			} 			
 			else
 			{
 				return false;
 			}
 			
 			return true;
 		}
 		
 		return false;
 	}
	
	//----------------------------------------------------------------------------------------------------
	private java.util.Properties setGrid3DSpecProps()
	{
		java.util.Properties prop = new java.util.Properties();
		if (currentLayerType.equals(ChartConstants.SURFACE_LAYER))
		{
			prop.setProperty(ChartConstants.TYPE, ChartConstants.SURFACE_LAYER);
		}
		else if(currentLayerType.equals(ChartConstants.DIAGRAM_LAYER))
		{
			prop.setProperty(ChartConstants.TYPE, ChartConstants.DIAGRAM_LAYER);
		}
		else if(currentLayerType.equals(ChartConstants.OBJECT_LAYER))
		{
			prop.setProperty(ChartConstants.TYPE, ChartConstants.OBJECT_LAYER);
		}
		
		prop.setProperty(ChartConstants.RADIUS, radiusField.getText());
		prop.setProperty(ChartConstants.PADDING, paddingField.getText());
		prop.setProperty(ChartConstants.TRANSLATE, translateField.getText());
		prop.setProperty(ChartConstants.SHOW_BASE, String.valueOf(showbaseCheckBox.isSelected()));
		prop.setProperty(ChartConstants.ROW_LABEL, rowField.getText());
		prop.setProperty(ChartConstants.COLUMN_LABEL, columnField.getText());
		prop.setProperty(ChartConstants.SHOW_COLORBAR, String.valueOf(colorbarVisCheckBox.isSelected()));
		prop.setProperty(ChartConstants.SHOW_AXIS, String.valueOf(axisVisCheckBox.isSelected()));
		
		return prop;
	}
	
	//----------------------------------------------------------------------------------------------------
	private void createGridLayer() {
		GridDescriptor descriptor = null;
		//set the Grid3D special properties
		java.util.Properties specialpropsGrid3D = setGrid3DSpecProps();		
		
		if (is_full) {
			IDataSourceProducer dsp_v = (IDataSourceProducer) fValueParam_value.getSelectedItem();
			IDataSourceProducer dsp_c = (IDataSourceProducer) fValueParam_color.getSelectedItem();
			
			if (dsp_v.getSupportedIntfs().contains(IGrid3DDatasetProducer.class))
			{
				if (!currentLayerType.equals(ChartConstants.SURFACE_LAYER))
				{
					IDataSourceProducer dsp_s = (IDataSourceProducer) fValueParam_shape.getSelectedItem();
					
					if (currentLayerType.equals(ChartConstants.OBJECT_LAYER))
					{
						IDataSourceProducer dsp_r = (IDataSourceProducer) fValueParam_radius.getSelectedItem();
						
						descriptor = new GridDescriptor(GridDescriptor.DS_MODE,dsp_v,dsp_c,dsp_s,dsp_r);
					}
					else
					{
						descriptor = new GridDescriptor(GridDescriptor.DS_MODE,dsp_v,dsp_c,dsp_s);
					}
				}
				else
				{
					descriptor = new GridDescriptor(GridDescriptor.DS_MODE,dsp_v,dsp_c);
				}
			}
			else {
				if (!currentLayerType.equals(ChartConstants.SURFACE_LAYER))
				{
					IDataSourceProducer dsp_s = (IDataSourceProducer) fValueParam_shape.getSelectedItem();
					
					if (currentLayerType.equals(ChartConstants.OBJECT_LAYER))
					{
						IDataSourceProducer dsp_r = (IDataSourceProducer) fValueParam_radius.getSelectedItem();
						
						descriptor = new GridDescriptor(GridDescriptor.FULL_MODE,dsp_v,dsp_c,dsp_s,dsp_r);
					}
					else
					{
						descriptor = new GridDescriptor(GridDescriptor.FULL_MODE,dsp_v,dsp_c,dsp_s);
					}
				}
				else
				{
					descriptor = new GridDescriptor(GridDescriptor.FULL_MODE,dsp_v,dsp_c);
				}

				descriptor.userDefinedWidth = user_defined_width;
				descriptor.userDefinedHeight = user_defined_height;
				if (user_defined_width) {
					int width = -1;
					try {
						width = Integer.parseInt(fWidthField.getText());
					} catch (NumberFormatException e) {}
					descriptor.width = width;
				} else {
					descriptor.widthProducer = (IDataSourceProducer) fWidthParam.getSelectedItem();
					if (descriptor.widthProducer == null) { 
						descriptor.userDefinedWidth = true;
						descriptor.width = -1;
					}
				}
				if (user_defined_height) {
					int height = -1;
					try {
						height = Integer.parseInt(fHeightField.getText());
					} catch (NumberFormatException e) {}
					descriptor.height = height;
				} else {
					descriptor.heightProducer = (IDataSourceProducer) fHeightParam.getSelectedItem();
					if (descriptor.heightProducer == null) {
						descriptor.userDefinedHeight = true;
						descriptor.height = -1;
					}
				}
				descriptor.rowOrder = fLeftToRightButton.isSelected();
			}
		} else {
			IDataSourceProducer xds = (IDataSourceProducer) pXParam.getSelectedItem();
			IDataSourceProducer yds = (IDataSourceProducer) pYParam.getSelectedItem();
			IDataSourceProducer vds = (IDataSourceProducer) pValueParam_value.getSelectedItem();
			IDataSourceProducer cds = (IDataSourceProducer) pValueParam_color.getSelectedItem();

			if (!currentLayerType.equals(ChartConstants.SURFACE_LAYER))
			{
				IDataSourceProducer sds = (IDataSourceProducer) pValueParam_shape.getSelectedItem();
				if (currentLayerType.equals(ChartConstants.OBJECT_LAYER))
				{
					IDataSourceProducer rds = (IDataSourceProducer) pValueParam_radius.getSelectedItem();
					descriptor = new GridDescriptor(xds,yds,vds,cds,sds,rds);
				}
				else
				{
					descriptor = new GridDescriptor(xds,yds,vds,cds,sds);
				}
			}
			else
			{
				descriptor = new GridDescriptor(xds,yds,vds,cds);
			}
			
			descriptor.userDefinedWidth = r_user_defined_width;
			descriptor.userDefinedHeight = r_user_defined_height;
			if (r_user_defined_width) {
				int width = -1;
				try {
					width = Integer.parseInt(pWidthField.getText());
				} catch (NumberFormatException e) {}
				descriptor.width = width;
			} else
				descriptor.widthProducer = (IDataSourceProducer) pWidthParam.getSelectedItem();
			if (r_user_defined_height) {
				int height = -1;
				try {
					height = Integer.parseInt(pHeightField.getText());
				} catch (NumberFormatException e) {}
				descriptor.height = height;
			} else
				descriptor.heightProducer = (IDataSourceProducer) pHeightParam.getSelectedItem();
		}
		
		IFigureRenderer renderer = null;
		
		if (colorMapButton.isSelected()) {
			float globalAlpha = -1;
			if (globalTransparencyBox.isSelected()) {
				float transparency = ((float)transparencySlider.getValue()) / 100;
				globalAlpha = 1 - transparency;
			}
			renderer = new ColorMapFigureRenderer(colorMapPanel.getColormap(),globalAlpha);
		} else 
			renderer = shapeRendererPanel.getRenderer();
		gridLayer = new GridLayer(descriptor,renderer, specialpropsGrid3D);
		if (!(renderer instanceof ColorMapFigureRenderer))
			gridLayer.setRendererProperties(shapeRendererPanel.getCustomProperties());
	}
	
	//----------------------------------------------------------------------------------------------------
	private void setWidgetDisabled() {
		if (fValueParam_value.getItemCount() == 0) {
			fValueParam_value.setEnabled(false);
			okButton.setEnabled(false);
			fValueAdvancedButton.setEnabled(false);
			fWidthButton.setEnabled(false);
			fHeightButton.setEnabled(false);
		}
		if (pValueParam_value.getItemCount() == 0) {
			pValueParam_value.setEnabled(false);
			pXParam.setEnabled(false);
			pYParam.setEnabled(false);
			pValueAdvancedButton.setEnabled(false);
			pXAdvancedButton.setEnabled(false);
			pYAdvancedButton.setEnabled(false);
			pWidthButton.setEnabled(false);
			pHeightButton.setEnabled(false);
		}
		if (fWidthParam.getItemCount() == 0) {
			fWidthButton.doClick(0);
			fHeightButton.doClick(0);
			fWidthButton.setEnabled(false);
			fHeightButton.setEnabled(false);
			fWidthParam.setEnabled(false);
			fHeightParam.setEnabled(false);
			pWidthParam.setEnabled(false);
			pHeightParam.setEnabled(false);
			pWidthButton.doClick(0);
			pHeightButton.doClick(0);
			pWidthButton.setEnabled(false);
			pHeightButton.setEnabled(false);
		}
	}
}