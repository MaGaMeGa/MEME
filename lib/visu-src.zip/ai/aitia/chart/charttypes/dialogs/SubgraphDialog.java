/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.TitledBorder;

import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.ds.IStringListProducer;
import ai.aitia.chart.ds.IStringSeriesProducer;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.ds.IXYSeriesProducer;

/** GUI-component of interactive graphs (or subgraphs). */
public class SubgraphDialog extends AbstractChartDialog {

	private static final long serialVersionUID = 1L;
	private JTabbedPane tabbed = null;
	private JPanel mainPanel = null;
	private JPanel firstPanel = null;
	private JPanel edgePanel = null;
	private JComboBox edgeParam = null;
	private JButton edgeAdvancedButton = null;
	private JPanel additionalPanel = null;
	private JComboBox additionalParam = null;
	private JButton additionalAdvancedButton = null;
	private JPanel nodesPanel = null;
	private JPanel nodesFirstPanel = null;
	private JLabel jLabel = null;
	private JTextField nodesField = null;
	private JLabel jLabel1 = null;
	private JSpinner rootSpinner = null;
	private JPanel nodesSecondPanel = null;
	private JCheckBox hasLabelsBox = null;
	private JPanel labelSourcePanel = null;
	private JComboBox labelParam = null;
	private JPanel buttonsPanel = null;
	private JButton cancelButton = null;
	private JPanel detailsPanel = null;
	private JPanel titleLine = null;
	private JLabel jLabel2 = null;
	private JPanel subtitleLine = null;
	private JLabel jLabel3 = null;
	private JTextField subtitleField = null;
	private JPanel depthPanel = null;
	private JLabel jLabel4 = null;
	private JSlider depthSlider = null;
	private JButton labelAdvancedButton = null;
	private JPanel appearancePanel = null;
	private JLabel jLabel5 = null;
	private JComboBox appearanceBox = null;
	private JPanel cardPanel = null;
	private JPanel fixNumberPanel = null;
	private JButton fixNumberButton = null;
	private JPanel dsNumberPanel = null;
	private JComboBox nrOfNodesParam = null;
	private JButton dsNumberButton = null;
	private JPanel vertexSizePanel = null;
	@SuppressWarnings("unused")
	private JComboBox vertexSizeParam = null;
	private JPanel vertexSizeLine = null;
	private JLabel vertexLabel = null;
	private JTextField vertexSizeField = null;
	
	//============================================================================
	// additional members
	
	/** Array of destination combobox: contains all acceptable data sources. */
	private Object[] forDestAll = null;
	
	/** Array of destination combobox: contains only ISeriesProducer supporters. */
	private Object[] forDestSeries = null;
	
	/** Array of destination combobox: contains only IValueProducer supporters. */
	private Object[] forDestValue = null;
	
	/** Flag that determines the kind of the number of nodes value: constant when
	 *  the flag is <code>true</code> or producer otherwise.
	 */
	private boolean user_defined_number = false;

	//=============================================================================
	// methods
	
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public SubgraphDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
	}
	
	//-----------------------------------------------------------------------------
	/** This method initializes <code>this</code>. */
	private void initialize() {
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.setMinimumSize(new Dimension(609, 219));
        this.setPreferredSize(new Dimension(609, 219));
        this.add(getTabbed(), null);
        this.add(getButtonsPanel(), null);
	}

	//-----------------------------------------------------------------------------
	private JTabbedPane getTabbed() {
		if (tabbed == null) {
			tabbed = new JTabbedPane();
			tabbed.addTab("Main Settings", null, getMainPanel(), null);
			tabbed.addTab("Details", null, getDetailsPanel(), null);
		}
		return tabbed;
	}

	//-----------------------------------------------------------------------------
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(new BoxLayout(getMainPanel(), BoxLayout.Y_AXIS));
			mainPanel.add(getFirstPanel(), null);
			mainPanel.add(getNodesPanel(), null);
		}
		return mainPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getFirstPanel() {
		if (firstPanel == null) {
			GridLayout gridLayout = new GridLayout();
			gridLayout.setRows(1);
			firstPanel = new JPanel();
			firstPanel.setLayout(gridLayout);
			firstPanel.add(getEdgePanel(), null);
			firstPanel.add(getAdditionalPanel(), null);
		}
		return firstPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getEdgePanel() {
		if (edgePanel == null) {
			edgePanel = new JPanel();
			edgePanel.setLayout(new BoxLayout(getEdgePanel(), BoxLayout.X_AXIS));
			edgePanel.setBorder(BorderFactory.createTitledBorder(null, "Edges or source nodes", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			edgePanel.add(getEdgeParam(), null);
			edgePanel.add(Box.createRigidArea(new Dimension(10,0)));
			edgePanel.add(getEdgeAdvancedButton(), null);
		}
		return edgePanel;
	}

	//-----------------------------------------------------------------------------
	private JComboBox getEdgeParam() {
		if (edgeParam == null) {
			edgeParam = new JComboBox(getParamsToEdges());
			edgeParam.setRenderer(new DataSourceComboBoxRenderer(edgeParam));
			edgeParam.setPreferredSize(new Dimension(100,26));
			if (edgeParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
				edgeParam.setToolTipText(dsp.toString());
			}
			edgeParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
					edgeParam.setToolTipText(dsp.toString());
					edgeAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
					List<Class> ds = dsp.getSupportedIntfs();
					if (ds.contains(IXYSeriesProducer.class)) {
						// edges from one data source
						additionalParam.setEnabled(false);
						additionalAdvancedButton.setEnabled(false);
					} else {
						// edges from two data sources
						IDataSourceProducer old = null;
						if (additionalParam.getItemCount() > 0)
							old = (IDataSourceProducer)additionalParam.getSelectedItem();
						if (!ds.contains(ISeriesProducer.class)) {
							// dsp supports only IValueProducer => get out the
							// just-series-producer-supporters from the other
							// combobox.
							additionalParam.setModel(new DefaultComboBoxModel(getValueParamsToDestNodes()));
						} else if (!ds.contains(IValueProducer.class)) {
							// dsp supports only ISeriesProducer => get out the
							// just-value-producer-supporters from the other
							// combobox.
							additionalParam.setModel(new DefaultComboBoxModel(getSeriesParamsToDestNodes()));
						} else {
							additionalParam.setModel(new DefaultComboBoxModel(getParamsToDestNodes()));
						}
						if (additionalParam.getItemCount() > 0) {
							if (old != null) {
								for (int i=0;i<additionalParam.getItemCount();++i) {
									if (additionalParam.getItemAt(i).equals(old)) {
										additionalParam.setSelectedIndex(i);
										break;
									}
								}
							}
							additionalParam.setEnabled(true);
							IDataSourceProducer adsp = (IDataSourceProducer)additionalParam.getSelectedItem();
							additionalAdvancedButton.setEnabled(adsp.hasAdvancedSettings());
						}
					}
				}
			});
		}
		return edgeParam;
	}

	//-----------------------------------------------------------------------------
	private JButton getEdgeAdvancedButton() {
		if (edgeAdvancedButton == null) {
			edgeAdvancedButton = new JButton();
			edgeAdvancedButton.setEnabled(false);
			edgeAdvancedButton.setText("Advanced...");
			final SubgraphDialog tthis = this;
			edgeAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(tthis.getRootPane().getParent());
					if (new_dsp != null) {
						int index = edgeParam.getSelectedIndex();
						edgeParam.removeItemAt(index);
						edgeParam.insertItemAt(new_dsp,index);
						edgeParam.setSelectedIndex(index);
					}
				}
			});
			if (edgeParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
				edgeAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return edgeAdvancedButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getAdditionalPanel() {
		if (additionalPanel == null) {
			additionalPanel = new JPanel();
			additionalPanel.setLayout(new BoxLayout(getAdditionalPanel(), BoxLayout.X_AXIS));
			additionalPanel.setBorder(BorderFactory.createTitledBorder(null, "Destination nodes", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			additionalPanel.add(getAdditionalParam(), null);
			additionalPanel.add(Box.createRigidArea(new Dimension(10,0)));
			additionalPanel.add(getAdditionalAdvancedButton(), null);
		}
		return additionalPanel;
	}

	//-----------------------------------------------------------------------------
	private JComboBox getAdditionalParam() {
		if (additionalParam == null) {
			additionalParam = new JComboBox(getParamsToDestNodes());
			additionalParam.setRenderer(new DataSourceComboBoxRenderer(additionalParam));
			additionalParam.setPreferredSize(new Dimension(100,26));
			if (additionalParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)additionalParam.getSelectedItem();
				additionalParam.setToolTipText(dsp.toString());
			}
			if (edgeParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
				List<Class> ds = dsp.getSupportedIntfs();
				if (ds.contains(IXYSeriesProducer.class)) additionalParam.setEnabled(false);
			}
			additionalParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)additionalParam.getSelectedItem();
					additionalParam.setToolTipText(dsp.toString());
					additionalAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
				}
			});
		}
		return additionalParam;
	}

	//-----------------------------------------------------------------------------
	private JButton getAdditionalAdvancedButton() {
		if (additionalAdvancedButton == null) {
			additionalAdvancedButton = new JButton();
			additionalAdvancedButton.setEnabled(false);
			additionalAdvancedButton.setText("Advanced...");
			final SubgraphDialog tthis = this;
			additionalAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)additionalParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(tthis.getRootPane().getParent());
					if (new_dsp != null) {
						int index = additionalParam.getSelectedIndex();
						additionalParam.removeItemAt(index);
						additionalParam.insertItemAt(new_dsp,index);
						additionalParam.setSelectedIndex(index);
					}
				}
			});
			if (additionalParam.getItemCount() > 0 && additionalParam.isEnabled()) {
				IDataSourceProducer dsp = (IDataSourceProducer)additionalParam.getSelectedItem();
				additionalAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return additionalAdvancedButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getNodesPanel() {
		if (nodesPanel == null) {
			nodesPanel = new JPanel();
			nodesPanel.setLayout(new BoxLayout(getNodesPanel(), BoxLayout.Y_AXIS));
			nodesPanel.setBorder(BorderFactory.createTitledBorder(null, "Node informations", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			nodesPanel.add(getNodesFirstPanel(), null);
			nodesPanel.add(Box.createRigidArea(new Dimension(0,5)));
			nodesPanel.add(getNodesSecondPanel(), null);
		}
		return nodesPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getNodesFirstPanel() {
		if (nodesFirstPanel == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("  Index of the root node :  ");
			jLabel = new JLabel();
			jLabel.setText("  Number of nodes :  ");
			nodesFirstPanel = new JPanel();
			nodesFirstPanel.setLayout(new BoxLayout(getNodesFirstPanel(), BoxLayout.X_AXIS));
			nodesFirstPanel.add(jLabel, null);
			nodesFirstPanel.add(getCardPanel(), null);
			nodesFirstPanel.add(jLabel1, null);
			nodesFirstPanel.add(getRootSpinner(), null);
		}
		return nodesFirstPanel;
	}

	//-----------------------------------------------------------------------------
	private JTextField getNodesField() {
		if (nodesField == null) {
			nodesField = new JTextField();
			nodesField.setMaximumSize(new Dimension(2147483647, 26));
			nodesField.setText("5");
			nodesField.setName("nodesField");
			nodesField.setHorizontalAlignment(JTextField.TRAILING);
			final SubgraphDialog tthis = this;
			nodesField.addCaretListener(new javax.swing.event.CaretListener() {
				public void caretUpdate(javax.swing.event.CaretEvent e) {
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(tthis);
						rootSpinner.setModel(new SpinnerNumberModel(0,0,Integer.parseInt(nodesField.getText())-1,1));
						rootSpinner.setEnabled(true);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(tthis);
						rootSpinner.setEnabled(false);
					}
				}
			});
			nodesField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid_non()) {
						nodesField.setText("");
					}
				}
			});
		}
		return nodesField;
	}
	
	//-----------------------------------------------------------------------------
	private JSpinner getRootSpinner() {
		if (rootSpinner == null) {
			rootSpinner = new JSpinner();
			rootSpinner.setModel(new SpinnerNumberModel(0,0,Integer.MAX_VALUE,1));
			rootSpinner.setMinimumSize(new Dimension(100, 20));
			rootSpinner.setPreferredSize(new Dimension(100, 20));
		}
		return rootSpinner;
 	}

	//-----------------------------------------------------------------------------
	private JPanel getNodesSecondPanel() {
		if (nodesSecondPanel == null) {
			nodesSecondPanel = new JPanel();
			nodesSecondPanel.setLayout(new BoxLayout(getNodesSecondPanel(), BoxLayout.X_AXIS));
			nodesSecondPanel.add(getHasLabelsBox(), null);
			nodesSecondPanel.add(getLabelSourcePanel(), null);
			nodesSecondPanel.add(Box.createHorizontalGlue());
		}
		return nodesSecondPanel;
	}

	//-----------------------------------------------------------------------------
	private JCheckBox getHasLabelsBox() {
		if (hasLabelsBox == null) {
			hasLabelsBox = new JCheckBox();
			hasLabelsBox.setText(" Labelled nodes ");
			hasLabelsBox.addItemListener(new java.awt.event.ItemListener() {
				public void itemStateChanged(java.awt.event.ItemEvent e) {
					if (e.getStateChange() == ItemEvent.SELECTED) {
						labelParam.setEnabled(true);
						IDataSourceProducer dsp = (IDataSourceProducer) labelParam.getSelectedItem();
						labelAdvancedButton.setEnabled(dsp != null && dsp.hasAdvancedSettings());
					} else {
						labelParam.setEnabled(false);
						labelAdvancedButton.setEnabled(false);
					}
				}
			});
		}
		return hasLabelsBox;
	}

	//-----------------------------------------------------------------------------
	private JPanel getLabelSourcePanel() {
		if (labelSourcePanel == null) {
			labelSourcePanel = new JPanel();
			labelSourcePanel.setLayout(new BoxLayout(getLabelSourcePanel(), BoxLayout.X_AXIS));
			labelSourcePanel.add(getLabelParam(), null);
			labelSourcePanel.add(Box.createRigidArea(new Dimension(10,0)));
			labelSourcePanel.add(getLabelAdvancedButton(), null);
		}
		return labelSourcePanel;
	}

	//-----------------------------------------------------------------------------
	private JComboBox getLabelParam() {
		if (labelParam == null) {
			labelParam = new JComboBox(getParamsToNodeLabels());
			labelParam.setRenderer(new DataSourceComboBoxRenderer(labelParam));
			labelParam.setEnabled(false);
			labelParam.setMinimumSize(new Dimension(200, 26));
			labelParam.setMaximumSize(new Dimension(240, 32767));
			labelParam.setPreferredSize(new Dimension(200, 26));
			if (labelParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)labelParam.getSelectedItem();
				labelParam.setToolTipText(dsp.toString());
			}
			labelParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)labelParam.getSelectedItem();
					labelParam.setToolTipText(dsp.toString());
					labelAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
				}
			});
		}
		return labelParam;
	}

	//-----------------------------------------------------------------------------
	private JButton getLabelAdvancedButton() {
		if (labelAdvancedButton == null) {
			labelAdvancedButton = new JButton();
			labelAdvancedButton.setEnabled(false);
			labelAdvancedButton.setText("Advanced...");
			final SubgraphDialog tthis = this;
			labelAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)labelParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(tthis.getRootPane().getParent());
					if (new_dsp != null) {
						int index = labelParam.getSelectedIndex();
						labelParam.removeItemAt(index);
						labelParam.insertItemAt(new_dsp,index);
						labelParam.setSelectedIndex(index);
					}
				}
			});
		}
		return labelAdvancedButton;
	}
	
	//-----------------------------------------------------------------------------
	private JPanel getButtonsPanel() {
		if (buttonsPanel == null) {
			buttonsPanel = new JPanel();
			buttonsPanel.setLayout(new FlowLayout());
			buttonsPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
			buttonsPanel.add(getEditorButton(), null);
			buttonsPanel.add(getDisplayButton(), null);
			buttonsPanel.add(getSaveButton(), null);
			buttonsPanel.add(getCancelButton(), null);
		}
		return buttonsPanel;
	}

	//-----------------------------------------------------------------------------
	private JButton getDisplayButton() {
		if (displayButton == null) {
			displayButton = new JButton();
			displayButton.setText("Display");
			displayButton.setMnemonic(KeyEvent.VK_D);
			displayButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					displayChart();
				}
			});
		}
		return displayButton;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setEnabled(false);
			saveButton.setText("Save");
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					saveCollection();
				}
			});
		}
		return saveButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMnemonic(KeyEvent.VK_C);
			cancelButton.setText("Cancel");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					notifyForHide();
				}
			});
		}
		return cancelButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getDetailsPanel() {
		if (detailsPanel == null) {
			detailsPanel = new JPanel();
			detailsPanel.setLayout(new BoxLayout(getDetailsPanel(), BoxLayout.Y_AXIS));
			detailsPanel.setBorder(BorderFactory.createTitledBorder(null, "Titles and depth of the supgraph", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			detailsPanel.add(getTitleLine(), null);
			detailsPanel.add(getSubtitleLine(), null);
			detailsPanel.add(getAppearancePanel(),null);
			detailsPanel.add(getDepthPanel(), null);
		}
		return detailsPanel;
	}

	private Component getVertexSizePanel() {
		if (vertexSizePanel == null) {
			vertexSizePanel = new JPanel();
			vertexSizePanel.setLayout(new BoxLayout(vertexSizePanel,BoxLayout.X_AXIS));
			vertexSizePanel.setAlignmentX(0f);
			vertexSizePanel.add(new JLabel("      Vertex size:  "));
			vertexSizePanel.add(getVertexSizeLine());
		}
		return vertexSizePanel;
	}

	
	private JPanel getVertexSizeLine() {
		if (vertexSizeLine == null) {
			vertexLabel = new JLabel();
			vertexLabel.setText(" %");
			vertexSizeLine = new JPanel();
			vertexSizeLine.setLayout(new BoxLayout(getVertexSizeLine(), BoxLayout.X_AXIS));
			
			vertexSizeLine.add(getVertexSizeField(), null);
			vertexSizeLine.add(vertexLabel, null);
		}
		return vertexSizeLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getVertexSizeField() {
		if (vertexSizeField == null) {
			vertexSizeField = new JTextField();
			vertexSizeField.setText("100");
			vertexSizeField.setMaximumSize(new Dimension(160, 26));
			vertexSizeField.setHorizontalAlignment(JTextField.TRAILING);
			vertexSizeField.setPreferredSize(new Dimension(75, 26));
			vertexSizeField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					Pattern p = Pattern.compile("^[1-9][0-9]*$");
					Matcher positive = p.matcher(vertexSizeField.getText().trim());
					try {
						if (!positive.matches())
							throw new NumberFormatException();
						Integer.parseInt(vertexSizeField.getText().trim());
					} catch (NumberFormatException ee) {
						JOptionPane.showMessageDialog(SubgraphDialog.this,"Invalid value in field 'Max. count of displayed items'.","Warning",JOptionPane.WARNING_MESSAGE,null);
						vertexSizeField.setText("100");
						vertexSizeField.grabFocus();
						vertexSizeField.selectAll();
					}
					properties.setProperty(ChartConstants.VERTEX_SIZE_PERCENTAGE,vertexSizeField.getText());
				}
			});
		}
		return vertexSizeField;
	}

	
	//-----------------------------------------------------------------------------
	private JPanel getTitleLine() {
		if (titleLine == null) {
			jLabel2 = new JLabel();
			jLabel2.setText("  Title:  ");
			jLabel2.setMaximumSize(new Dimension(100, 20));
			jLabel2.setPreferredSize(new Dimension(100, 20));
			titleLine = new JPanel();
			titleLine.setLayout(new BoxLayout(getTitleLine(), BoxLayout.X_AXIS));
			titleLine.setPreferredSize(new Dimension(400, 20));
			titleLine.add(jLabel2, null);
			titleLine.add(getTitleField(), null);
		}
		return titleLine;
	}

	//-----------------------------------------------------------------------------
	private JTextField getTitleField() {
		if (titleField == null) {
			titleField = new JTextField();
			titleField.setMaximumSize(new Dimension(2147483647, 25));
			titleField.setText(ChartConstants.SUBGRAPH_NAME);
			titleField.setPreferredSize(new Dimension(300, 20));
			final SubgraphDialog tthis = this;
			titleField.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					subtitleField.grabFocus();
				}
			});
			titleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.TITLE,titleField.getText());
					ChartDialogChangeCenter.fireTitleChanged(tthis);
				}
			});
		}
		return titleField;
	}

	//-----------------------------------------------------------------------------
	private JPanel getSubtitleLine() {
		if (subtitleLine == null) {
			jLabel3 = new JLabel();
			jLabel3.setText("  Subtitle:  ");
			jLabel3.setMaximumSize(new Dimension(100, 20));
			jLabel3.setPreferredSize(new Dimension(100, 20));
			subtitleLine = new JPanel();
			subtitleLine.setLayout(new BoxLayout(getSubtitleLine(), BoxLayout.X_AXIS));
			subtitleLine.setPreferredSize(new Dimension(400, 20));
			subtitleLine.add(jLabel3, null);
			subtitleLine.add(getSubtitleField(), null);
		}
		return subtitleLine;
	}

	//-----------------------------------------------------------------------------
	private JTextField getSubtitleField() {
		if (subtitleField == null) {
			subtitleField = new JTextField();
			subtitleField.setMaximumSize(new Dimension(2147483647, 25));
			subtitleField.setPreferredSize(new Dimension(300, 20));
			subtitleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
				}
			});
		}
		return subtitleField;
	}

	//-----------------------------------------------------------------------------
	private JPanel getDepthPanel() {
		if (depthPanel == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("  Depth:  ");
			jLabel4.setPreferredSize(new Dimension(100, 20));
			jLabel4.setMaximumSize(new Dimension(100, 30));
			depthPanel = new JPanel();
			depthPanel.setLayout(new BoxLayout(getDepthPanel(), BoxLayout.X_AXIS));
			depthPanel.setPreferredSize(new Dimension(400, 30));
			depthPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
			depthPanel.add(jLabel4, null);
			depthPanel.add(getDepthSlider(), null);
		}
		return depthPanel;
	}

	//-----------------------------------------------------------------------------
	private JSlider getDepthSlider() {
		if (depthSlider == null) {
			depthSlider = new JSlider(1,5,2);
			depthSlider.setMajorTickSpacing(1);
			depthSlider.setPaintTicks(true);
			depthSlider.setPaintLabels(true);
			depthSlider.setSnapToTicks(true);
			depthSlider.addChangeListener(new javax.swing.event.ChangeListener() {
				public void stateChanged(javax.swing.event.ChangeEvent e) {
					if (!depthSlider.getValueIsAdjusting()) {
						properties.setProperty(ChartConstants.DEPTH,String.valueOf(depthSlider.getValue()));
					}
				}
			});
		}
		return depthSlider;
	}

	//-----------------------------------------------------------------------------
	private JPanel getAppearancePanel() {
		if (appearancePanel == null) {
			jLabel5 = new JLabel();
			jLabel5.setText("  Appearance:  ");
			appearancePanel = new JPanel();
			appearancePanel.setLayout(new BoxLayout(getAppearancePanel(), BoxLayout.X_AXIS));
			appearancePanel.setMaximumSize(new Dimension(Integer.MAX_VALUE,25));
			appearancePanel.add(jLabel5, null);
			appearancePanel.add(Box.createRigidArea(new Dimension(26,0)));
			appearancePanel.add(getAppearanceBox(), null);
			appearancePanel.add(getVertexSizePanel());
		}
		return appearancePanel;
	}

	//-----------------------------------------------------------------------------
	private JComboBox getAppearanceBox() {
		if (appearanceBox == null) {
			Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
			appearances.add(new ComboboxItem( "C",  "Colored"));
			appearances.add(new ComboboxItem( "BW", "Black-and-white"));
			for (String templateNames : AbstractChart.templates.keySet())
				appearances.add(new ComboboxItem("_" + templateNames,templateNames));
			appearances.add(new ComboboxItem("_NEW","New template..."));
			appearances.add(new ComboboxItem("_EDIT","Edit template..."));
			appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
			appearanceBox = new JComboBox(appearances);
			appearanceBox.setPreferredSize(new Dimension(154,25));
			appearanceBox.setMaximumSize(new Dimension(154,25));
			appearanceBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int index = appearanceBox.getSelectedIndex();
					String id = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
					if (index >= 0 && index <= 1) {
						if ("BW".equals(id)) ChartConfigCollection.setColorAppearance(ChartConstants.BLACK_AND_WHITE);
						else ChartConfigCollection.setColorAppearance(ChartConstants.COLORED);
					} else if (id.equals("_NEW")) {
						ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.SUBGRAPH);
						int result = dlg.showDialog();
						if (result == ChartPropertiesDialog.OK_OPTION) {
							Element newTemplate = (Element) dlg.getTemplate();
							dlg.dispose();
							String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
							AbstractChart.templates.put(name,newTemplate);
							ChartDialogChangeCenter.fireTemplateChanged();
							appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
						} else 
							appearanceBox.setSelectedIndex(0);
					} else if (id.equals("_EDIT")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(SubgraphDialog.this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(SubgraphDialog.this,"Select a template: ","Edit template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template == null || "".equals(template)) 
							appearanceBox.setSelectedIndex(0);
						else {
							Element templateElement = AbstractChart.templates.get(template);
							ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(),ChartKind.SUBGRAPH);
							int result = dlg.showDialog();
							if (result == ChartPropertiesDialog.OK_OPTION) {
								Element newTemplate = (Element) dlg.getTemplate();
								dlg.dispose();
								String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
								AbstractChart.templates.put(name,newTemplate);
								ChartDialogChangeCenter.fireTemplateChanged();
								appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
							} else 
								appearanceBox.setSelectedIndex(0);
						}
					} else if (id.equals("_REMOVE")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(SubgraphDialog.this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(SubgraphDialog.this,"Select a template: ","Delete template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template != null && !"".equals(template)) { 
							AbstractChart.templates.remove(template);
							File file = new File("Templates/" + template + ".xml");
							file.delete();
							ChartDialogChangeCenter.fireTemplateChanged();
						}
						appearanceBox.setSelectedIndex(0);
					}
				}
			});
		}
		return appearanceBox;
	}

	//------------------------------------------------------------------------------
	private List<String> getLegends() {	return new ArrayList<String>(); }
	
	//-----------------------------------------------------------------------------
	private JPanel getCardPanel() {
		if (cardPanel == null) {
			cardPanel = new JPanel();
			cardPanel.setLayout(new CardLayout());
			cardPanel.add(getDsNumberPanel(), getDsNumberPanel().getName());
			cardPanel.add(getFixNumberPanel(), getFixNumberPanel().getName());
		}
		return cardPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getFixNumberPanel() {
		if (fixNumberPanel == null) {
			fixNumberPanel = new JPanel();
			fixNumberPanel.setLayout(new BoxLayout(getFixNumberPanel(), BoxLayout.X_AXIS));
			fixNumberPanel.setName("FIX_NUMBER_PANEL");
			fixNumberPanel.add(getNodesField(), null);
			fixNumberPanel.add(Box.createRigidArea(new Dimension(5,0)));
			fixNumberPanel.add(getFixNumberButton(), null);
		}
		return fixNumberPanel;
	}

	//-----------------------------------------------------------------------------
	private JButton getFixNumberButton() {
		if (fixNumberButton == null) {
			fixNumberButton = new JButton();
			fixNumberButton.setText("From data source");
			fixNumberButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					user_defined_number = false;
					rootSpinner.setModel(new SpinnerNumberModel(0,0,Integer.MAX_VALUE,1));
					rootSpinner.setEnabled(true);
					CardLayout cl = (CardLayout)cardPanel.getLayout();
					cl.show(cardPanel,"DS_NUMBER_PANEL");
//					if (nrOfNodesParam.getItemCount() > 0) {
//						displayButton.setEnabled(true);
//						ChartDialogChangeCenter.fireSaveEnabled(tthis);
//					}
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(SubgraphDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(SubgraphDialog.this);
					}
				}
			});
		}
		return fixNumberButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getDsNumberPanel() {
		if (dsNumberPanel == null) {
			dsNumberPanel = new JPanel();
			dsNumberPanel.setLayout(new BoxLayout(getDsNumberPanel(), BoxLayout.X_AXIS));
			dsNumberPanel.setName("DS_NUMBER_PANEL");
			dsNumberPanel.add(getNrOfNodesParam(), null);
			dsNumberPanel.add(Box.createRigidArea(new Dimension(5,0)));
			dsNumberPanel.add(getDsNumberButton(), null);
		}
		return dsNumberPanel;
	}

	//-----------------------------------------------------------------------------
	private JComboBox getNrOfNodesParam() {
		if (nrOfNodesParam == null) {
			nrOfNodesParam = new JComboBox(getParamsToNumberOfNodes());
			nrOfNodesParam.setRenderer(new DataSourceComboBoxRenderer(nrOfNodesParam));
			nrOfNodesParam.setPreferredSize(new Dimension(100,26));
			if (nrOfNodesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)nrOfNodesParam.getSelectedItem();
				nrOfNodesParam.setToolTipText(dsp.toString());
			}
			nrOfNodesParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)nrOfNodesParam.getSelectedItem();
					nrOfNodesParam.setToolTipText(dsp.toString());
				}
			});
		}
		return nrOfNodesParam;
	}

	//-----------------------------------------------------------------------------
	private JButton getDsNumberButton() {
		if (dsNumberButton == null) {
			dsNumberButton = new JButton();
			dsNumberButton.setText("From user input");
			dsNumberButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					user_defined_number = true;
					CardLayout cl = (CardLayout)cardPanel.getLayout();
					cl.show(cardPanel,"FIX_NUMBER_PANEL");
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(SubgraphDialog.this);
						rootSpinner.setModel(new SpinnerNumberModel(0,0,Integer.parseInt(nodesField.getText())-1,1));
						rootSpinner.setEnabled(true);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(SubgraphDialog.this);
						rootSpinner.setEnabled(false);
					}
				}
			});
		}
		return dsNumberButton;
	}

	//=============================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-generated functions                                                //
	////////////////////////////////////////////////////////////////////////////

	@Override
	protected void displayPreview() throws Exception {
		DataSources ds = new DataSources(new SimpleDSPCollection());
		ChartConfig temp_config = new ChartConfig(ds);
		temp_config.setFireInitialEvent(true);
		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
		Properties temp_prop = (Properties)properties.clone();
		temp_config.addDataSource(dsl.get(0),ISeriesProducer.class);
		temp_config.addDataSource(dsl.get(1),ISeriesProducer.class);
		temp_config.addDataSource(dsl.get(3),IStringSeriesProducer.class);
		temp_prop.setProperty(ChartConstants.DATASOURCE,"1 2,3");
		if (!user_defined_number) {
			temp_prop.setProperty(ChartConstants.USER_DEFINED_NUMBER,"true");
			temp_prop.setProperty(ChartConstants.NR_OF_NODES,"5");
		}
		if (temp_prop.getProperty(ChartConstants.ROOT_INDEX).equals("0")) {
			int number = Integer.parseInt(temp_prop.getProperty(ChartConstants.NR_OF_NODES)); 
			temp_prop.setProperty(ChartConstants.ROOT_INDEX,String.valueOf(number/2));
		}
		temp_prop.setProperty(ChartConstants.TITLE,temp_prop.getProperty(ChartConstants.TITLE) + " (Preview Illustration)");
		temp_config.setChartProperties(ChartConstants.SUBGRAPH,temp_prop);
		Utilities.displayPreview(temp_config);
	}

	//-----------------------------------------------------------------------------
	@Override
	public boolean isUpdateable() {
		if (edgeParam.getItemCount() == 0) return false;
		IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
		if (user_defined_number &&  !is_valid_non()) return false;
		if (!user_defined_number && nrOfNodesParam.getItemCount() == 0) return false;
		if (dsp.getSupportedIntfs().contains(IXYSeriesProducer.class)) return true;
		if (additionalParam.getItemCount() == 0) return false;
		return true;
	}

	//-----------------------------------------------------------------------------
	@Override
	protected void setSettingsFromConfig() {
		if (config.getChartProperties() instanceof Properties) {
			// set settings from config
			properties = (Properties)config.getChartProperties();
			String[] ds = properties.getProperty(ChartConstants.DATASOURCE).split(",");
			int[] gds = Utilities.splitDatasourceAroundSpace(ds[0]);
			IDataSourceProducer dsp = config.getDataSource(gds[0]);
			edgeParam.setSelectedItem(dsp);
			if (gds.length == 1) { // IXYSeriesProducer
				additionalParam.setEnabled(false);
			} else { // two ISeriesProducer
				IDataSourceProducer adsp = config.getDataSource(gds[1]);
				additionalParam.setSelectedItem(adsp);
			}
			if (ds.length == 1) { // no labels
				hasLabelsBox.setSelected(false);
				labelParam.setEnabled(false);
				labelAdvancedButton.setEnabled(false);
			} else { 
				hasLabelsBox.setSelected(true);
				IDataSourceProducer ldsp = config.getDataSource(Integer.parseInt(ds[1]));
				labelParam.setSelectedItem(ldsp);
			}
			user_defined_number = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_NUMBER,"true"));
			int rootIndex = Integer.parseInt(properties.getProperty(ChartConstants.ROOT_INDEX));
			if (user_defined_number) {
				CardLayout cl = (CardLayout)cardPanel.getLayout();
				cl.show(cardPanel,"FIX_NUMBER_PANEL");
				nodesField.setText(properties.getProperty(ChartConstants.NR_OF_NODES));
				int max = Integer.parseInt(properties.getProperty(ChartConstants.NR_OF_NODES))-1;
				rootSpinner.setModel(new SpinnerNumberModel(rootIndex,0,max,1));
			} else {
				IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.NR_OF_NODES)));
				nrOfNodesParam.setSelectedItem(vp);
				rootSpinner.setModel(new SpinnerNumberModel(rootIndex,0,Integer.MAX_VALUE,1));
			}
			rootSpinner.setEnabled(true);
			titleField.setText(properties.getProperty(ChartConstants.TITLE));
			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
 				int colorIndex = properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
 				appearanceBox.setSelectedIndex(colorIndex);
 			}
			int depth = Integer.parseInt(properties.getProperty(ChartConstants.DEPTH));
			depthSlider.setValue(depth);
			vertexSizeField.setText(properties.getProperty(ChartConstants.VERTEX_SIZE_PERCENTAGE));
		} else { 
			// set the initial properties
			properties.setProperty(ChartConstants.USER_DEFINED_NUMBER,"false");
			properties.setProperty(ChartConstants.TITLE,ChartConstants.SUBGRAPH_NAME);
			properties.setProperty(ChartConstants.SUBTITLE,"");
			properties.setProperty(ChartConstants.DEPTH,"2");
			int appIndex = ChartConfigCollection.getColorAppearance().equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
			appearanceBox.setSelectedIndex(appIndex);
			properties.setProperty(ChartConstants.VERTEX_SIZE_PERCENTAGE,"100");
			
 			// initial dest params
 			if (edgeParam.getItemCount() > 0)
 				edgeParam.setSelectedIndex(0);
		}
	}

	//-----------------------------------------------------------------------------
	@Override
	protected void setWidgetDisabled() {
		if (edgeParam.getItemCount() == 0) {
			edgeParam.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			edgeAdvancedButton.setEnabled(false);
			hasLabelsBox.setEnabled(false);
			fixNumberButton.setEnabled(false);
			dsNumberButton.setEnabled(false);
		}
		if (additionalParam.getItemCount() == 0) {
			additionalParam.setEnabled(false);
			additionalAdvancedButton.setEnabled(false);
		}
		if (labelParam.getItemCount() == 0) {
			labelParam.setEnabled(false);
			labelAdvancedButton.setEnabled(false);
			hasLabelsBox.setEnabled(false);
		}
		if (nrOfNodesParam.getItemCount() == 0) {
			nrOfNodesParam.setEnabled(false);
			fixNumberButton.setEnabled(false);
		}
	}

	//-----------------------------------------------------------------------------
	@Override
	public void updateChartConfig() {
		config.clearAllDataSource();
		String ds = "";
		IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
		int key = -1;
		if (dsp.getSupportedIntfs().contains(IXYSeriesProducer.class)) {
			key = config.addDataSource(dsp,IXYSeriesProducer.class);
			ds += String.valueOf(key) + ",";
		} else {
			IDataSourceProducer ddsp = (IDataSourceProducer)additionalParam.getSelectedItem();
			boolean edgeIsSeries = dsp.getSupportedIntfs().contains(ISeriesProducer.class);
			boolean destIsSeries = ddsp.getSupportedIntfs().contains(ISeriesProducer.class);
			int eKey = -1, dKey = -1;
			if (edgeIsSeries && destIsSeries) {
				eKey = config.addDataSource(dsp,ISeriesProducer.class);
				dKey = config.addDataSource(ddsp,ISeriesProducer.class);
			} else if (!edgeIsSeries && !destIsSeries) {
				eKey = config.addDataSource(dsp,IValueProducer.class);
				dKey = config.addDataSource(ddsp,IValueProducer.class);
			}
			ds += String.valueOf(eKey) + " ";
			ds += String.valueOf(dKey) + ",";
		}
		properties.setProperty(ChartConstants.USER_DEFINED_NUMBER,String.valueOf(user_defined_number));
		if (user_defined_number)
			properties.setProperty(ChartConstants.NR_OF_NODES,nodesField.getText());
		else {
			dsp = (IDataSourceProducer)nrOfNodesParam.getSelectedItem();
			if (dsp.getSupportedIntfs().contains(IValueProducer.class))
				key = config.addDataSource(dsp,IValueProducer.class);
			else { // need emulation
				key = config.addDataSource(dsp,ISeriesProducer.class);
			}
			properties.setProperty(ChartConstants.NR_OF_NODES,String.valueOf(key));
		}
		if (hasLabelsBox.isSelected()) {
			dsp = (IDataSourceProducer)labelParam.getSelectedItem();
			if (dsp.getSupportedIntfs().contains(IStringListProducer.class)) {
				key = config.addDataSource(dsp,IStringListProducer.class);
			} else {
				key = config.addDataSource(dsp,IStringSeriesProducer.class);
			}
			ds += String.valueOf(key) + ",";
		}
		properties.setProperty(ChartConstants.DATASOURCE,ds.substring(0,ds.length()-1));
		properties.setProperty(ChartConstants.ROOT_INDEX,rootSpinner.getValue().toString());
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 1) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
			String ca = appearanceIndex == 1 ? ChartConstants.BLACK_AND_WHITE : ChartConstants.COLORED;
			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ca);
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
		config.setChartProperties(ChartConstants.SUBGRAPH,properties);
	}
	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "C",  "Colored"));
		appearances.add(new ComboboxItem( "BW", "Black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem)appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		// reset widgets
		edgeParam.setEnabled(true);
		edgeAdvancedButton.setEnabled(true);
		hasLabelsBox.setEnabled(true);
		fixNumberButton.setEnabled(true);
		dsNumberButton.setEnabled(true);
		additionalParam.setEnabled(true);
		additionalAdvancedButton.setEnabled(true);
		labelParam.setEnabled(true);
		labelAdvancedButton.setEnabled(true);
		nrOfNodesParam.setEnabled(true);
		fixNumberButton.setEnabled(true);
		
		Object edgeObject = edgeParam.getSelectedIndex() == -1 ? null : edgeParam.getSelectedItem();
		Object additionalObject = additionalParam.getSelectedIndex() == -1 ? null : additionalParam.getSelectedItem();
		Object labelObject = labelParam.getSelectedIndex() == -1 ? null : labelParam.getSelectedItem();
		Object nrObject = nrOfNodesParam.getSelectedIndex() == -1 ? null : nrOfNodesParam.getSelectedItem();
		
		DefaultComboBoxModel edgeModel = new DefaultComboBoxModel(getParamsToEdges());
		edgeParam.setModel(edgeModel);
		forDestAll = forDestSeries = forDestValue = null;
		DefaultComboBoxModel additionalModel = new DefaultComboBoxModel(getParamsToDestNodes());
		additionalParam.setModel(additionalModel);
		DefaultComboBoxModel labelModel = new DefaultComboBoxModel(getParamsToNodeLabels());
		labelParam.setModel(labelModel);
		DefaultComboBoxModel nrModel = new DefaultComboBoxModel(getParamsToNumberOfNodes());
		nrOfNodesParam.setModel(nrModel);
		
		if (additionalObject != null && findInComboBox(additionalModel,(IDataSourceProducer)additionalObject) != -1)  {
			int idx = findInComboBox(additionalModel,(IDataSourceProducer)additionalObject);
			additionalParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (edgeObject != null && findInComboBox(edgeModel,(IDataSourceProducer)edgeObject) != -1) {
			int idx = findInComboBox(edgeModel,(IDataSourceProducer)edgeObject);
			edgeParam.setSelectedIndex(idx >= 0 ? idx : 0);
		} else if (edgeParam.getItemCount() > 0)
			edgeParam.setSelectedIndex(0);
		if (labelObject != null && findInComboBox(labelModel,(IDataSourceProducer)labelObject) != -1)  {
			int idx = findInComboBox(labelModel,(IDataSourceProducer)labelObject);
			labelParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (nrObject != null && findInComboBox(nrModel,(IDataSourceProducer)nrObject) != -1) {
			int idx = findInComboBox(nrModel,(IDataSourceProducer)nrObject);
			nrOfNodesParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		
		validate();
		setWidgetDisabled();
		
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}

	//-----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that supports <code>
	 *  ISeriesProducer</code>, <code>IValueProducer</code> or <code>IXYSeriesProducer
	 *  </code>.
	 * @return array of data sources
	 */
	private Object[] getParamsToEdges() {
		return getParams(IXYSeriesProducer.class);
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data soruces that supports the 
	 *  <code>ISeriesProducer</code> and/or <code>IValueProducer<code> interface.
	 * @return array of data sources
	 */
	private Object[] getParamsToDestNodes() {
		if (forDestAll == null) {
			forDestAll = getParams(new Class[] { ISeriesProducer.class, IValueProducer.class });
		}
		return forDestAll;
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that supports only the
	 *  <code>ISeriesProducer</code> interface.
	 * @return array of data sources
	 */
	private Object[] getSeriesParamsToDestNodes() {
		if (forDestSeries == null) {
			forDestSeries = getParams(ISeriesProducer.class,IValueProducer.class);
		}
		return forDestSeries;
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that supports only the
	 *  <code>IValueProducer</code> interface.
	 * @return array of data sources
	 */
	private Object[] getValueParamsToDestNodes() {
		if (forDestValue == null) {
			forDestValue = getParams(IValueProducer.class,ISeriesProducer.class);
		}
		return forDestValue;
	}
	
	//-----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that supports 
	 * {@link ai.aitia.chart.ds.IStringListProducer IStringListProducer}.
	 * 
	 * @return array of data sources
	 */
	private Object[] getParamsToNodeLabels() {
		return getParams(IStringListProducer.class);
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that support the <code>
	 *  IValueProducer</code> and <code>ISeriesProducer</code> interfaces.
	 */
	private Object[] getParamsToNumberOfNodes() {
		return getParams(IValueProducer.class);
	}
	
	//-----------------------------------------------------------------------------
	/** Returns whether the <code>nodesField</code> contains a valid integer that
	 *  greater than 0 or not.
	 */
	private boolean is_valid_non() {
		Pattern p = Pattern.compile("^[1-9][0-9]*$"); // pattern for number of nodes
		Matcher m = p.matcher(nodesField.getText().trim());
		if (m.matches()) {
			try {
				Integer.parseInt(nodesField.getText().trim());
				return true;
			} catch (NumberFormatException e) {}
		}
		return false;
	}
}