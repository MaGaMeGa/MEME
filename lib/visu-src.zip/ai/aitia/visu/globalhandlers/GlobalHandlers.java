package ai.aitia.visu.globalhandlers;

import java.lang.Thread.UncaughtExceptionHandler;

/** Global handler objects for handle uncaught exceptions and long operations. It
 *  also stores the global variable of last open/save path. */
public class GlobalHandlers {
	
	/** Global uncaught exception handler object. */
	private static UncaughtExceptionHandler exceptionHandler;
	
	/** Global long operation executor object. */
	private static ILOPExecutor LOPExecutor;
	
	/** Global last open/save path. */
	private static java.io.File lastDirectory = null;
	
	private static IWarningManager warningManager;
	
	static {
		exceptionHandler = new DefaultExceptionHandler();
		LOPExecutor = new DefaultLOPExecutor();
		warningManager = new IWarningManager() {
			public boolean shouldDumpWarnings() { return true; }
		};
	}
	
	//================================================================================
	// methods
	
	/** Returns the global uncaught exception handler. 
	 * @return the global uncaught exception handler
	 */
	public static UncaughtExceptionHandler getExceptionHandler() {
		return exceptionHandler;
	}
	
	//--------------------------------------------------------------------------------
	/** Sets the global uncaught exception handler. 
	 * @param handler the new uncaught exception handler
	 */
	public static void setExceptionHandler(UncaughtExceptionHandler handler) {
		exceptionHandler = handler;
	}
	
	//--------------------------------------------------------------------------------
	/** Returns the global long operation executor object.
	 * @return the global long operation executor object
	 */
	public static ILOPExecutor getLOPExecutor() {
		return LOPExecutor;
	}
	
	//--------------------------------------------------------------------------------
	/** Sets the global long operation executor object.
	 * @param e the new long operation executor object
	 * @return the old long operation executor object
	 */
	public static ILOPExecutor setLOPExecutor(ILOPExecutor e) {
		ILOPExecutor ans = LOPExecutor;
		LOPExecutor = e;
		return ans;
	}
	
	//--------------------------------------------------------------------------------
	/** Returns the last open/save path.
	 * @return the last open/save path
	 */
	public static java.io.File getLastDirectory() {
		return lastDirectory;
	}
	
	//--------------------------------------------------------------------------------
	/** Sets the last open/save path. If the parameter is not a directory, it sets
	 *  as <code>lastDirectory</code> its directory.
	 * @param dir the last open/save path
	 * @return the old last open/save path
	 */
	public static java.io.File setLastDirectory(java.io.File dir) {
		java.io.File ans = lastDirectory;
		if (dir.isDirectory()) lastDirectory = dir;
		else {
			java.io.File parent = dir.getParentFile();
			if (parent != null) lastDirectory = parent;
		}
		return ans;
	}

	//----------------------------------------------------------------------------------------------------
	public static IWarningManager getWarningManager() {	return warningManager; }
	
	//----------------------------------------------------------------------------------------------------
	public static void setWarningManager(IWarningManager warningManager) {
		GlobalHandlers.warningManager = warningManager;
	}
}