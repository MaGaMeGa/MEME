package ai.aitia.visu.view.meta;

public class Appearance {

	public static final int BLACK_AND_WHITE = 0;
	public static final int COLORED = 1;
	public static final int BASIC_APP = 2;
	public static final int NORMAL_APP = 3;
}
