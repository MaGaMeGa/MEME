/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;

import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import javax.swing.border.AbstractBorder;
import javax.swing.plaf.UIResource;

import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.theme.SubstanceComplexTheme;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * Root pane and internal frame border in <b>Substance</b> look and feel. This
 * class is <b>for internal use only</b>.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstancePaneBorder extends AbstractBorder implements UIResource {
	/**
	 * Default border thickness.
	 */
	private static final int BORDER_THICKNESS = 4;

	/**
	 * Default insets.
	 */
	private static final Insets INSETS = new Insets(
			SubstancePaneBorder.BORDER_THICKNESS,
			SubstancePaneBorder.BORDER_THICKNESS,
			SubstancePaneBorder.BORDER_THICKNESS,
			SubstancePaneBorder.BORDER_THICKNESS);

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.border.Border#paintBorder(java.awt.Component,
	 *      java.awt.Graphics, int, int, int, int)
	 */
	@Override
	public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
		Window window = SwingUtilities.getWindowAncestor(c);
		boolean isSelected = (window == null) ? true : window.isActive();

		// Active for selected window, default for inactive windows
		ColorScheme colorScheme = isSelected ? SubstanceCoreUtilities
				.getActiveScheme((JComponent) c) : SubstanceCoreUtilities
				.getDefaultScheme((JComponent) c);

		// special case for complex themes
		if (isSelected
				&& (SubstanceLookAndFeel.getTheme() instanceof SubstanceComplexTheme)) {
			colorScheme = ((SubstanceComplexTheme) SubstanceLookAndFeel
					.getTheme()).getActiveTitlePaneTheme().getColorScheme();
		}

		Graphics2D graphics = (Graphics2D) g;

		ColorScheme titleBarColorScheme = colorScheme;
		// if (titleBarColorScheme instanceof MixDarkBiColorScheme)
		// titleBarColorScheme = ((MixDarkBiColorScheme) titleBarColorScheme)
		// .getOrigDarkScheme();

		// bottom and right in ultra dark
		graphics.setColor(colorScheme.getUltraDarkColor());
		graphics.drawLine(x, y + h - 1, x + w - 1, y + h - 1);
		graphics.drawLine(x + w - 1, y, x + w - 1, y + h - 1);
		// top and left in dark
		graphics.setColor(colorScheme.getDarkColor());
		graphics.drawLine(x, y, x + w - 2, y);
		graphics.drawLine(x, y, x, y + h - 2);
		// bottom and right in dark
		graphics.setColor(colorScheme.getMidColor());
		graphics.drawLine(x + 1, y + h - 2, x + w - 2, y + h - 2);
		graphics.drawLine(x + w - 2, y + 1, x + w - 2, y + h - 2);
		// top and left in ultra light
		graphics.setColor(colorScheme.getMidColor());
		graphics.drawLine(x + 1, y + 1, x + w - 3, y + 1);
		graphics.drawLine(x + 1, y + 1, x + 1, y + h - 3);
		// inner in light
		if (colorScheme == titleBarColorScheme) {
			graphics.setColor(colorScheme.getLightColor());
		} else {
			graphics.setColor(titleBarColorScheme.getDarkColor());
		}
		graphics.drawRect(x + 2, y + 2, w - 5, h - 5);
		graphics.drawRect(x + 3, y + 3, w - 7, h - 7);

		// // top and left in ultra dark
		// graphics.setColor(colorScheme.getDarkColor());
		// graphics.drawLine(x + 4, y + 4, x + w - 5, y + 4);
		// graphics.drawLine(x + 4, y + 4, x + 4, y + h - 5);
		// // bottom and right in light
		// graphics.setColor(colorScheme.getLightColor());
		// graphics.drawLine(x + 4, y + h - 5, x + w - 5, y + h - 5);
		// graphics.drawLine(x + w - 5, y + 4, x + w - 5, y + h - 5);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.border.Border#getBorderInsets(java.awt.Component)
	 */
	@Override
	public Insets getBorderInsets(Component c) {
		return SubstancePaneBorder.INSETS;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.border.AbstractBorder#getBorderInsets(java.awt.Component,
	 *      java.awt.Insets)
	 */
	@Override
	public Insets getBorderInsets(Component c, Insets newInsets) {
		newInsets.top = SubstancePaneBorder.INSETS.top;
		newInsets.left = SubstancePaneBorder.INSETS.left;
		newInsets.bottom = SubstancePaneBorder.INSETS.bottom;
		newInsets.right = SubstancePaneBorder.INSETS.right;
		return newInsets;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.border.Border#isBorderOpaque()
	 */
	@Override
	public boolean isBorderOpaque() {
		return false;
	}
}
