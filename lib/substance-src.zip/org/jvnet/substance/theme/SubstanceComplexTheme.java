/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.theme;

import javax.swing.JTabbedPane;

import org.jvnet.substance.painter.SubstanceGradientPainter;

/**
 * Complex theme. A complex theme is defined by four separate themes:
 * <ul>
 * <li>Active theme - used for the active (selected, pressed, rolled over)
 * controls.
 * <li>Default theme - used for inactive enabled controls.
 * <li>Disabled theme - used for disabled controls.
 * <li>Active title pane theme - used for title panes of active windows.
 * </ul>
 * This class is part of officially supported API.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceComplexTheme extends SubstanceTheme {
	/**
	 * Theme for controls in active visual state.
	 */
	protected SubstanceTheme activeTheme;

	/**
	 * Theme for controls in default visual state.
	 */
	protected SubstanceTheme defaultTheme;

	/**
	 * Theme for controls in disabled visual state.
	 */
	protected SubstanceTheme disabledTheme;

	/**
	 * Theme for title panes of active windows.
	 */
	protected SubstanceTheme activeTitlePaneTheme;

	/**
	 * Theme for watermarks.
	 */
	protected SubstanceTheme watermarkTheme;

	/**
	 * Theme for painting the background of selected cells in trees, lists and
	 * tables.
	 */
	protected SubstanceTheme cellRendererBackgroundTheme;

	/**
	 * Painter for painting the non-active controls.
	 */
	protected SubstanceGradientPainter nonActivePainter;

	/**
	 * The start of fade effect on the selected tabs in {@link JTabbedPane}s.
	 * 
	 * @see #selectedTabFadeEnd
	 */
	protected double selectedTabFadeStart;

	/**
	 * The end of fade effect on the selected tabs in {@link JTabbedPane}s.
	 * 
	 * @see #selectedTabFadeStart
	 */
	protected double selectedTabFadeEnd;

	/**
	 * Creates a new complex theme.
	 * 
	 * @param displayName
	 *            Theme display name.
	 * @param themeKind
	 *            Theme kind.
	 * @param activeTheme
	 *            Active theme.
	 * @param defaultTheme
	 *            Default theme.
	 * @param disabledTheme
	 *            Disabled theme.
	 * @param activeTitlePaneTheme
	 *            Active title pane theme.
	 */
	public SubstanceComplexTheme(String displayName, ThemeKind themeKind,
			SubstanceTheme activeTheme, SubstanceTheme defaultTheme,
			SubstanceTheme disabledTheme, SubstanceTheme activeTitlePaneTheme) {
		this(displayName, themeKind, activeTheme, defaultTheme, disabledTheme,
				activeTitlePaneTheme, defaultTheme);
	}

	/**
	 * Creates a new complex theme.
	 * 
	 * @param displayName
	 *            Theme display name.
	 * @param themeKind
	 *            Theme kind.
	 * @param activeTheme
	 *            Active theme.
	 * @param defaultTheme
	 *            Default theme.
	 * @param disabledTheme
	 *            Disabled theme.
	 * @param activeTitlePaneTheme
	 *            Active title pane theme.
	 * @param watermarkTheme
	 *            Watermark theme.
	 */
	public SubstanceComplexTheme(String displayName, ThemeKind themeKind,
			SubstanceTheme activeTheme, SubstanceTheme defaultTheme,
			SubstanceTheme disabledTheme, SubstanceTheme activeTitlePaneTheme,
			SubstanceTheme watermarkTheme) {
		super(defaultTheme.getColorScheme(), displayName, themeKind);
		this.activeTheme = activeTheme;
		this.defaultTheme = defaultTheme;
		this.disabledTheme = disabledTheme;
		this.activeTitlePaneTheme = activeTitlePaneTheme;
		this.watermarkTheme = watermarkTheme;
		this.cellRendererBackgroundTheme = activeTheme;
		this.selectedTabFadeStart = 1.0;
		this.selectedTabFadeEnd = 1.0;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getActiveTheme()
	 */
	@Override
	public SubstanceTheme getActiveTheme() {
		return this.activeTheme;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getDefaultTheme()
	 */
	@Override
	public SubstanceTheme getDefaultTheme() {
		return this.defaultTheme;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getDisabledTheme()
	 */
	@Override
	public SubstanceTheme getDisabledTheme() {
		return this.disabledTheme;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getActiveTitlePaneTheme()
	 */
	@Override
	public SubstanceTheme getActiveTitlePaneTheme() {
		return this.activeTitlePaneTheme;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getFirstTheme()
	 */
	@Override
	public SubstanceTheme getFirstTheme() {
		SubstanceComplexTheme result = new SubstanceComplexTheme("First "
				+ this.getDisplayName(), this.getKind(), this.getActiveTheme()
				.getFirstTheme(), this.getDefaultTheme().getFirstTheme(), this
				.getDisabledTheme().getFirstTheme(), this
				.getActiveTitlePaneTheme().getFirstTheme());
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().getFirstTheme());
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getSecondTheme()
	 */
	@Override
	public SubstanceTheme getSecondTheme() {
		SubstanceComplexTheme result = new SubstanceComplexTheme("Second "
				+ this.getDisplayName(), this.getKind(), this.getActiveTheme()
				.getSecondTheme(), this.getDefaultTheme().getSecondTheme(),
				this.getDisabledTheme().getSecondTheme(), this
						.getActiveTitlePaneTheme().getSecondTheme());
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().getSecondTheme());
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#saturate(double, boolean)
	 */
	@Override
	public SubstanceTheme saturate(double saturateFactor,
			boolean toSaturateEverything) {
		SubstanceComplexTheme result = new SubstanceComplexTheme("Saturated ["
				+ toSaturateEverything + "] " + this.getDisplayName() + " "
				+ (int) (100 * saturateFactor) + "%", this.getKind(), this
				.getActiveTheme()
				.saturate(saturateFactor, toSaturateEverything),
				toSaturateEverything ? this.getDefaultTheme().saturate(
						saturateFactor, true) : this.getDefaultTheme(),
				toSaturateEverything ? this.getDisabledTheme().saturate(
						saturateFactor, true) : this.getDisabledTheme(),
				toSaturateEverything ? this.getActiveTitlePaneTheme().saturate(
						saturateFactor, true) : this.getActiveTitlePaneTheme(),
				toSaturateEverything ? this.getWatermarkTheme().saturate(
						saturateFactor, true) : this.getWatermarkTheme());
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme()
				.saturate(saturateFactor, true));
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#shade(double)
	 */
	@Override
	public SubstanceTheme shade(double shadeFactor) {
		SubstanceComplexTheme result = new SubstanceComplexTheme(
				"Shade " + this.getDisplayName() + " "
						+ (int) (100 * shadeFactor) + "%", this.getKind(), this
						.getActiveTheme().shade(shadeFactor), this
						.getDefaultTheme().shade(shadeFactor), this
						.getDisabledTheme().shade(shadeFactor), this
						.getActiveTitlePaneTheme().shade(shadeFactor), this
						.getWatermarkTheme().shade(shadeFactor));
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().shade(shadeFactor));
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#tint(double)
	 */
	@Override
	public SubstanceTheme tint(double tintFactor) {
		SubstanceComplexTheme result = new SubstanceComplexTheme("Tint "
				+ this.getDisplayName() + " " + (int) (100 * tintFactor) + "%",
				this.getKind(), this.getActiveTheme().tint(tintFactor), this
						.getDefaultTheme().tint(tintFactor), this
						.getDisabledTheme().tint(tintFactor), this
						.getActiveTitlePaneTheme().tint(tintFactor), this
						.getWatermarkTheme().tint(tintFactor));
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().tint(tintFactor));
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#tone(double)
	 */
	@Override
	public SubstanceTheme tone(double toneFactor) {
		SubstanceComplexTheme result = new SubstanceComplexTheme("Tone "
				+ this.getDisplayName() + " " + (int) (100 * toneFactor) + "%",
				this.getKind(), this.getActiveTheme().tone(toneFactor), this
						.getDefaultTheme().tone(toneFactor), this
						.getDisabledTheme().tone(toneFactor), this
						.getActiveTitlePaneTheme().tone(toneFactor), this
						.getWatermarkTheme().tone(toneFactor));
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().tone(toneFactor));
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#invert()
	 */
	@Override
	public SubstanceTheme invert() {
		SubstanceComplexTheme result = new SubstanceComplexTheme("Inverted "
				+ this.getDisplayName(), this.getKind(), this.getActiveTheme()
				.invert(), this.getDefaultTheme().invert(), this
				.getDisabledTheme().invert(), this.getActiveTitlePaneTheme()
				.invert(), this.getWatermarkTheme().invert());
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().invert());
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#negate()
	 */
	@Override
	public SubstanceTheme negate() {
		SubstanceComplexTheme result = new SubstanceComplexTheme("Negated "
				+ this.getDisplayName(), this.getKind(), this.getActiveTheme()
				.negate(), this.getDefaultTheme().negate(), this
				.getDisabledTheme().negate(), this.getActiveTitlePaneTheme()
				.negate(), this.getWatermarkTheme().negate());
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().negate());
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#hueShift(double)
	 */
	@Override
	public SubstanceTheme hueShift(double hueShiftFactor) {
		SubstanceComplexTheme result = new SubstanceComplexTheme("Hue-shift "
				+ this.getDisplayName() + " " + (int) (100 * hueShiftFactor)
				+ "%", this.getKind(), this.getActiveTheme().hueShift(
				hueShiftFactor), this.getDefaultTheme()
				.hueShift(hueShiftFactor), this.getDisabledTheme().hueShift(
				hueShiftFactor), this.getActiveTitlePaneTheme().hueShift(
				hueShiftFactor), this.getWatermarkTheme().hueShift(
				hueShiftFactor));
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().hueShift(hueShiftFactor));
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#protanopia()
	 */
	@Override
	public SubstanceTheme protanopia() {
		SubstanceComplexTheme result = new SubstanceComplexTheme("Protanopia "
				+ this.getDisplayName(), this.getKind(), this.getActiveTheme()
				.protanopia(), this.getDefaultTheme().protanopia(), this
				.getDisabledTheme().protanopia(), this
				.getActiveTitlePaneTheme().protanopia(), this
				.getWatermarkTheme().protanopia());
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().protanopia());
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#tritanopia()
	 */
	@Override
	public SubstanceTheme tritanopia() {
		SubstanceComplexTheme result = new SubstanceComplexTheme("Tritanopia "
				+ this.getDisplayName(), this.getKind(), this.getActiveTheme()
				.tritanopia(), this.getDefaultTheme().tritanopia(), this
				.getDisabledTheme().tritanopia(), this
				.getActiveTitlePaneTheme().tritanopia(), this
				.getWatermarkTheme().tritanopia());
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().tritanopia());
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#deuteranopia()
	 */
	@Override
	public SubstanceTheme deuteranopia() {
		SubstanceComplexTheme result = new SubstanceComplexTheme(
				"Deuteranopia " + this.getDisplayName(), this.getKind(), this
						.getActiveTheme().deuteranopia(), this
						.getDefaultTheme().deuteranopia(), this
						.getDisabledTheme().deuteranopia(), this
						.getActiveTitlePaneTheme().deuteranopia(), this
						.getWatermarkTheme().deuteranopia());
		result.setCellRendererBackgroundTheme(this
				.getHighlightBackgroundTheme().deuteranopia());
		this.copyTo(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getWatermarkTheme()
	 */
	@Override
	public SubstanceTheme getWatermarkTheme() {
		return this.watermarkTheme;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getCellRendererBackgroundTheme()
	 */
	public SubstanceTheme getHighlightBackgroundTheme() {
		return cellRendererBackgroundTheme;
	}

	/**
	 * Sets the theme for painting the background of selected cells in trees,
	 * lists and tables.
	 * 
	 * @param cellRendererBackgroundTheme
	 *            Theme for painting the background of selected cells in trees,
	 *            lists and tables.
	 */
	public void setCellRendererBackgroundTheme(
			SubstanceTheme cellRendererBackgroundTheme) {
		this.cellRendererBackgroundTheme = cellRendererBackgroundTheme;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getScrollbarTrackPainter()
	 */
	public SubstanceGradientPainter getNonActivePainter() {
		if (this.nonActivePainter != null)
			return this.nonActivePainter;
		return super.getNonActivePainter();
	}

	/**
	 * Sets the painter for painting the non-active controls.
	 * 
	 * @param nonActivePainter
	 *            Painter for painting the non-active controls.
	 */
	public void setNonActivePainter(SubstanceGradientPainter nonActivePainter) {
		this.nonActivePainter = nonActivePainter;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getSelectedTabFadeStart()
	 */
	public double getSelectedTabFadeStart() {
		return this.selectedTabFadeStart;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.theme.SubstanceTheme#getSelectedTabFadeEnd()
	 */
	public double getSelectedTabFadeEnd() {
		return this.selectedTabFadeEnd;
	}

	/**
	 * Sets the end of fade effect on the selected tabs in {@link JTabbedPane}s.
	 * The value should be in 0.0-1.0 range.
	 * 
	 * @param selectedTabFadeEnd
	 *            The end of fade effect on the selected tabs in
	 *            {@link JTabbedPane}s. Should be in 0.0-1.0 range.
	 */
	public void setSelectedTabFadeEnd(double selectedTabFadeEnd) {
		this.selectedTabFadeEnd = selectedTabFadeEnd;
	}

	/**
	 * Sets the start of fade effect on the selected tabs in {@link JTabbedPane}s.
	 * The value should be in 0.0-1.0 range.
	 * 
	 * @param selectedTabFadeStart
	 *            The start of fade effect on the selected tabs in
	 *            {@link JTabbedPane}s. Should be in 0.0-1.0 range.
	 */
	public void setSelectedTabFadeStart(double selectedTabFadeStart) {
		this.selectedTabFadeStart = selectedTabFadeStart;
	}

	/**
	 * Copies theme-agnostic settings of <code>this</code> theme to the
	 * specified theme.
	 * 
	 * @param dst
	 *            Theme to copy to.
	 */
	protected void copyTo(SubstanceComplexTheme dst) {
		dst.setNonActivePainter(this.nonActivePainter);
		dst.setSelectedTabFadeStart(this.selectedTabFadeStart);
		dst.setSelectedTabFadeEnd(this.selectedTabFadeEnd);
	}
}
