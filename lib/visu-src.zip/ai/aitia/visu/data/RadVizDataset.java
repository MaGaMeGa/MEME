package ai.aitia.visu.data;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import org.jfree.data.Range;
import org.jfree.data.RangeInfo;
import org.jfree.data.general.AbstractDataset;


@SuppressWarnings("serial")
public class RadVizDataset extends AbstractDataset
    implements RangeInfo {

    /** Storage for the data. */
   // protected KeyedObjects2D data;

    Hashtable<Comparable,ArrayList<ArrayList<Double>>> data;
    Hashtable<Comparable,ArrayList<Double[]>> data2D;
    /** The minimum range value. */
    @SuppressWarnings("unused")
	private Number minimumRangeValue;

    /** The maximum range value. */
    @SuppressWarnings("unused")
	private Number maximumRangeValue;

    /** The range of values. */
    @SuppressWarnings("unused")
	private Range rangeBounds;
    
    /**
     * 
     */
    private ArrayList<String> anchors;
    //The min and max values belonging to every individual anchor
    //private ArrayList<Double> anchorsMin;
    private ArrayList<Double> anchorsMax;
    
    private ArrayList<Double> springXs;
    private ArrayList<Double> springYs;
    private ArrayList<Comparable> keys;
    

    /**
     * Creates a new dataset.
     */
    @SuppressWarnings("unchecked")
	public RadVizDataset() {
    	data=new Hashtable();
    	data2D=new Hashtable();
    	keys=new ArrayList<Comparable>();
        this.minimumRangeValue = null;
        this.maximumRangeValue = null;
        this.rangeBounds = new Range(0.0, 0.0);
        this.anchors= new ArrayList();
        
    }

    public void addAnchors(List<String> anchorNames) {
    	anchors.clear();
    	anchors.addAll(anchorNames);
    	anchorsMax=new ArrayList<Double>();
    	for(int i=0; i<anchors.size(); i++){
    		anchorsMax.add((double)Integer.MIN_VALUE);
    	}
    	//fireDatasetChanged();
    }
    
    public ArrayList getAnchors() {
		return anchors;
	}
    
    /**
     * Adds a list of values relating to one box-and-whisker entity to the 
     * table.  The various median values are calculated.
     *
     * @param list  a collection of values from which the various medians will 
     *              be calculated.
     * @param rowKey  the row key.
     * @param columnKey  the column key.
     */
    public void add(ArrayList<Double> list, Comparable key ) {
    	
    	//System.out.println(key);
    	if(list.size()!=anchors.size()){
            return;
    	}
    	
    	if(!data.containsKey(key)){
    		ArrayList<ArrayList<Double>> d=new ArrayList<ArrayList<Double>>();
    		d.add(list);
    		data.put(key, d );
    		keys.add(key);
    	}else{
    		ArrayList<ArrayList<Double>> d=(ArrayList<ArrayList<Double>>)(data.get(key));
    		d.add(list);
    		data.put(key,d);
    	}
    	for(int i=0; i<list.size(); i++){
    		if((Double)(list.get(i))>anchorsMax.get(i)){
    			anchorsMax.set(i, (Double)(list.get(i)));
    		}
    	}
    	data.elements();
    	
    	
    	
    }
    
    
    public void normalize(){
    	/*for(ArrayList<ArrayList<Double>> lists: data.values()){
    		for(ArrayList list:lists){
    			for(int i=0; i<lists.size(); i++){
    				list.set(i,(Double)list.get(i)/anchorsMax.get(i));
    				if(i==0){
    					System.out.println(anchorsMax.get(i));
    				}
    			}
    		}
    	}*/
    	
    	for(Object o: getKeys()){
			String name=o.toString();
			ArrayList <ArrayList <Double>> a=getValues(name);
			ArrayList <ArrayList <Double>> na=new ArrayList <ArrayList <Double>>();
			for(int i=0; i< a.size(); i++){
				ArrayList <Double> d=a.get(i);
				ArrayList <Double> nd=new ArrayList<Double>();
				for(int j=0; j<d.size(); j++){
					Double dd=0.0;
					if(anchorsMax.get(j)!=0){
						dd=d.get(j)/anchorsMax.get(j);	
					}
					nd.add(dd);
				}
				na.add(nd);
			}
			data.put(name, na);
		}
    }

    public Double[] projectionTo2D(ArrayList<Double> list ){
    	Double ret[]=new Double[2];
    	double x=0;
    	double y=0;
    	int springNum=anchors.size();
    	for(int i=0; i<springNum; i++){
    		@SuppressWarnings("unused")
			double w;
    		double xijSum=0;
    		for(int k=0; k<springNum; k++){
    			xijSum+=list.get(k);
    		}
    		xijSum=(1/xijSum)*list.get(i);
    		x+=xijSum*springXs.get(i);
    		y+=xijSum*springYs.get(i);
    	}
    	
    	ret[0]=x;
    	ret[1]=y;
    	return ret;
    	
    }
    
	public void calculateSpringVectors(){
		springXs=new ArrayList<Double>() ;
		springYs=new ArrayList<Double>() ;
		int springNum=anchors.size();
		for(int i=0; i<springNum; i++){
			springXs.add(Math.sin((Math.PI*2*i)/springNum));
			springYs.add(Math.cos((Math.PI*2*i)/springNum));
		}
	}
	
	public void projectionsTo2D(){
		
		/*for (Enumeration e = data.keys() ; e.hasMoreElements() ;) {
			Comparable key=(Comparable)e.nextElement();
			System.out.println("key : " +key);
			ArrayList<ArrayList<Double>> lists=data.get(key);
			for(ArrayList<Double> list: lists){
				Double [] d=projectionTo2D(list);
				if(data2D.containsKey(key)){
					data2D.get(key).add(d);	
				}else{
					ArrayList<Double[]> arr=new ArrayList<Double[]>();
					arr.add(d);
					data2D.put(key, arr);
					
				}
				
			}
		}*/
		
		Iterator it=data.keySet().iterator();
		while(it.hasNext()){
			Comparable key=(Comparable)it.next();
			//System.out.println("key : " + key);
			ArrayList<ArrayList<Double>> lists=data.get(key);
			for(ArrayList<Double> list: lists){
				Double [] d=projectionTo2D(list);
				if(data2D.containsKey(key)){
					data2D.get(key).add(d);	
				}else{
					ArrayList<Double[]> arr=new ArrayList<Double[]>();
					arr.add(d);
					data2D.put(key, arr);
					
				}
			}
		}
	}
	
	
    public double getRangeLowerBound(boolean includeInterval) {
        
        return -1;        
    }

    public double getRangeUpperBound(boolean includeInterval) {
        
        return +1;        
    }

    public Range getRangeBounds(boolean includeInterval) {
        return new Range(-1,1);
    }

    public void convertData(){
    	
    	normalize();
		calculateSpringVectors();
		projectionsTo2D();
		fireDatasetChanged();
    }
    
	public Hashtable<Comparable, ArrayList<Double[]>> getData2D() {
		return data2D;
	}
	
	public void clear(){
		data.clear();
		data2D.clear();
		keys.clear();
	}
	
	/**
     * Returns the categories in the dataset.  The returned list is 
     * unmodifiable.
     *
     * @return The categories in the dataset.
     */
    public List getKeys() {
    	
    	/*Iterator it=data2D.keySet().iterator();
    	ArrayList l=new ArrayList();
		while(it.hasNext()){
			Comparable key=(Comparable)it.next();
			l.add(key);
		}
    	
        return Collections.unmodifiableList(l);*/
    	return keys;
    }
	
    public Double[] getValue(Comparable key, int ind){
    	
    	return data2D.get(key).get(ind);
    }

    public ArrayList <ArrayList <Double>> getValues(Comparable key){
    	
    	return data.get(key);
    }
    
    public ArrayList <Double[]> get2DValues(Comparable key){
    	
    	return data2D.get(key);
    }
    
	public ArrayList<Double> getSpringXs() {
		return springXs;
	}

	public ArrayList<Double> getSpringYs() {
		return springYs;
	}
    
	
}
