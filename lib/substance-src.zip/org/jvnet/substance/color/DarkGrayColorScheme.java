/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.color;

import java.awt.Color;

/**
 * <b>Dark gray</b> color scheme.
 * 
 * @author Kirill Grouchnikov
 */
public class DarkGrayColorScheme extends BaseColorScheme {
//	/**
//	 * The main ultra-light color.
//	 */
//	private static final Color mainUltraLightColor = new Color(125, 125, 125);
//
//	/**
//	 * The main extra light color.
//	 */
//	private static final Color mainExtraLightColor = new Color(120, 120, 120);
//
//	/**
//	 * The main light color.
//	 */
//	private static final Color mainLightColor = new Color(112, 112, 112);
//
//	/**
//	 * The main medium color.
//	 */
//	private static final Color mainMidColor = new Color(105, 105, 105);
//
//	/**
//	 * The main dark color.
//	 */
//	private static final Color mainDarkColor = new Color(90, 90, 90);
//
//	/**
//	 * The main ultra-dark color.
//	 */
//	private static final Color mainUltraDarkColor = new Color(50, 50, 50);

	/**
	 * The main ultra-light color.
	 */
	private static final Color mainUltraDarkColor  = new Color(5, 5, 5);

	/**
	 * The main extra light color.
	 */
	private static final Color mainDarkColor  = new Color(15, 15, 15);

	/**
	 * The main light color.
	 */
	private static final Color mainMidColor  = new Color(30, 30, 30);

	/**
	 * The main medium color.
	 */
	private static final Color mainLightColor = new Color(45, 45, 45);

	/**
	 * The main dark color.
	 */
	private static final Color mainExtraLightColor = new Color(75, 75, 75);

	/**
	 * The main ultra-dark color.
	 */
	private static final Color mainUltraLightColor = new Color(155, 155, 155);

	/**
     * The foreground color.
     */
    private static final Color foregroundColor = Color.white;

    /* (non-Javadoc)
    * @see org.jvnet.substance.color.ColorScheme#getForegroundColor()
    */
    public Color getForegroundColor() {
        return DarkGrayColorScheme.foregroundColor;
    }

	/* (non-Javadoc)
	 * @see org.jvnet.substance.color.ColorScheme#getUltraLightColor()
	 */
	public Color getUltraLightColor() {
		return DarkGrayColorScheme.mainUltraLightColor;
	}

	/* (non-Javadoc)
	 * @see org.jvnet.substance.color.ColorScheme#getExtraLightColor()
	 */
	public Color getExtraLightColor() {
		return DarkGrayColorScheme.mainExtraLightColor;
	}

	/* (non-Javadoc)
	 * @see org.jvnet.substance.color.ColorScheme#getLightColor()
	 */
	public Color getLightColor() {
		return DarkGrayColorScheme.mainLightColor;
	}

	/* (non-Javadoc)
	 * @see org.jvnet.substance.color.ColorScheme#getMidColor()
	 */
	public Color getMidColor() {
		return DarkGrayColorScheme.mainMidColor;
	}

	/* (non-Javadoc)
	 * @see org.jvnet.substance.color.ColorScheme#getDarkColor()
	 */
	public Color getDarkColor() {
		return DarkGrayColorScheme.mainDarkColor;
	}

	/* (non-Javadoc)
	 * @see org.jvnet.substance.color.ColorScheme#getUltraDarkColor()
	 */
	public Color getUltraDarkColor() {
		return DarkGrayColorScheme.mainUltraDarkColor;
	}
}
