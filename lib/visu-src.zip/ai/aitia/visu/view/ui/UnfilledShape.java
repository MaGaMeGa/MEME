package ai.aitia.visu.view.ui;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

public class UnfilledShape implements Shape {
	
	private Shape shape;
	
	//===================================================================================
	// methods
	
	//-----------------------------------------------------------------------------------
	public UnfilledShape(Shape shape) {
		if (shape == null)
			throw new IllegalArgumentException("'shape' cannot be null");
		this.shape = shape;
	}
	
	//===================================================================================
	// implemented interfaces
	
	//-----------------------------------------------------------------------------------
	public boolean contains(Point2D p) { return shape.contains(p); }
	public boolean contains(Rectangle2D r) { return shape.contains(r); }
	public boolean contains(double x, double y) { return shape.contains(x,y); }
	public boolean contains(double x, double y, double w, double h) { return shape.contains(x,y,w,h); }
	public Rectangle getBounds() { return shape.getBounds(); }
	public Rectangle2D getBounds2D() { return shape.getBounds2D(); }
	public PathIterator getPathIterator(AffineTransform at) { return shape.getPathIterator(at); }
	public PathIterator getPathIterator(AffineTransform at, double flatness) { return shape.getPathIterator(at,flatness); }
	public boolean intersects(Rectangle2D r) { return shape.intersects(r); }
	public boolean intersects(double x, double y, double w, double h) { return shape.intersects(x,y,w,h); }
}