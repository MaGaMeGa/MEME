/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.test;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.Node;

import ai.aitia.chart.IDSPCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.ds.ConstantColorDataSourceProducer;
import ai.aitia.chart.util.Utilities;

/** A test implementation of the IDSPCollection interface that reads its data sources
 *  from a file named 'test.txt' */
public class SimpleDSPCollection implements IDSPCollection {

	/** Number of the data sources */
	public final static int SIZE = 9;
	
	/** Length of the data sources. */
	public final static int S_SIZE = 12;
	
	/** Array of ids of the data sources. */
	private String[] id = new String[0];
	
	/** Array of names of the data sources. */
	private String[] name = new String[0];
	
	/** Values of all data sources. */
	private HashMap<String,ArrayList<Comparable>> values;
	
	//===============================================================================
	// methods
	
	/** Constructor.
	 * @throws Exception if any problems occure during the reading and processing of
	 *  the data sources
	 */
	public SimpleDSPCollection() throws Exception {
		values = new HashMap<String,ArrayList<Comparable>>();
		BufferedReader reader = new BufferedReader(new InputStreamReader(getClass().getClassLoader().getResourceAsStream("test.txt")));
		id = new String[SIZE];
		for (int i=0;i<SIZE;i++) {
			id[i] = reader.readLine();
			values.put(id[i], new ArrayList<Comparable>());
		}
		reader.readLine();
		name = new String[SIZE];
		for (int i=0;i<SIZE;i++) {
			name[i] = reader.readLine();
		}
		reader.readLine();
		String line;
		for (int i=0;i<S_SIZE;++i) {
			line = reader.readLine();
			String[] temp = line.split(" ");
			for (int j=0;j<SIZE;++j) {
				ArrayList<Comparable> l = values.get(id[j]);
				if (j==3) {
					l.add(temp[j]);
				} else if ((j==7 || j==8) && i != 0) continue;
				else {
					l.add(Double.parseDouble(temp[j]));
				}
				values.put(id[j], l);
			}
		}
		reader.close();
	}
	
	//------------------------------------------------------------------------------
	/** Gets the list of available data sources.
	 * @return List of data sources.
	 */
	public List<IDataSourceProducer> getList() {
		ArrayList<IDataSourceProducer> list = new ArrayList<IDataSourceProducer>();
		for (int i=0;i<id.length;++i) {
			IDataSourceProducer dsp = new SimpleDataSourceProducer(id[i],name[i],values.get(id[i]));
			list.add(dsp);
		}
		return list;
	}
	
	//-------------------------------------------------------------------------------
	/** It loads a data source. This operation returns a data source which
	 *  is described by the XML node <code>node</code>.
	 * @param node source XML node
	 * @param type one of the types returned by {@link IDataSourceProducer#getSupportedIntfs()
	 *             getSupportedIntfs()} which is needed for at least one chart contained in
	 *             the XML document
	 * @return data source
	 * @throws Exception if any problems occure
	 */
	public IDataSourceProducer load(Node node, Class type) throws Exception {
		Properties prop = Utilities.readProperties(node);
		if (prop.containsKey("CONSTANT_COLOR_PRODUCER")) {
			final String colorStr = prop.getProperty("COLOR");
			final Color color = new Color(Integer.decode(colorStr));
			return new ConstantColorDataSourceProducer(color);
		} else {
			String id = prop.getProperty("ID");
			String name = prop.getProperty("NAME");
			String[] val_string = prop.getProperty("VALUES").split(",");
			ArrayList<Comparable> values = new ArrayList<Comparable>();
			for (int i=1;i<val_string.length;++i) {
				if (val_string[0].equals("STRING")) values.add(val_string[i]);
				else values.add(Double.parseDouble(val_string[i]));
			}
			return new SimpleDataSourceProducer(id,name,values);
		}
	}
}
