/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.view.meta;

import java.awt.Color;

import ai.aitia.visu.view.ui.ColorMap;
import ai.aitia.visu.view.ui.DefaultFigureRenderer;
import ai.aitia.visu.view.ui.IFigureRenderer;
import ai.aitia.visu.view.ui.SimpleColorMap;

public class D1SeriesMetadata {
	
	private static final String DEFAULT_TITLE = "Untitled";
	private static final String DEFAULT_COLUMN_LABEL = "Column";
	private static final String DEFAULT_ROW_LABEL = "Row";
	
	private String title;
	private String subTitle;
	private ColorMap colorMap;
	private IFigureRenderer shapeRenderer;
	private String columnLabel;
	private String rowLabel;
	private String tooMany = "Too many grids!";
	private boolean noSelection = false;
	private boolean colorBarVisible = true;
	private int environmentAppearance = Appearance.BASIC_APP;
	private CustomAppearance customAppearance = null;
	private boolean generateTooltip = false;
	
	public D1SeriesMetadata() {
		title = DEFAULT_TITLE;
		columnLabel = DEFAULT_COLUMN_LABEL;
		rowLabel = DEFAULT_ROW_LABEL;
		subTitle = null;
		colorMap = new SimpleColorMap(0, 65536, Color.white, Color.black);
		shapeRenderer =  new DefaultFigureRenderer();
	}
	
	public String getTitle() { return title; }
	public String getSubTitle() { return subTitle; }
	public ColorMap getColorMap() { return colorMap; }
	public boolean isColorBarVisible() { return colorBarVisible; }
	public String getColumnLabel() { return columnLabel; }
	public String getRowLabel() { return rowLabel; }
	public IFigureRenderer getShapeRenderer() {	return shapeRenderer; }
	public String getTooMany() { return tooMany; }
	public boolean noSelection() { return noSelection; }
	public int getEnvironmentAppearance() {	return environmentAppearance; }
	public boolean hasCustomAppearance() { return customAppearance != null; }
	public CustomAppearance getCustomAppearance() { return customAppearance; }
	public boolean generateTooltip() { return generateTooltip; }

	public void setTitle(String title) { this.title = title; }
	public void setSubTitle(String subTitle) { this.subTitle = subTitle; }
	public void setColorMap(ColorMap colorMap) { this.colorMap = colorMap; }
	public void setColorBarVisible(boolean colorBarVisible) { this.colorBarVisible = colorBarVisible; }
	public void setColumnLabel(String columnLabel) { this.columnLabel = columnLabel; }
	public void setRowLabel(String rowLabel) { this.rowLabel = rowLabel; }
	public void setShapeRenderer(IFigureRenderer shapeRenderer) { this.shapeRenderer = shapeRenderer; }	
	public void setTooMany(String tooMany) { this.tooMany = tooMany; }
	public void setNoSelection(boolean noSelection) { this.noSelection = noSelection; }
	public void setEnvironmentAppearance(int environmentAppearance) { this.environmentAppearance = environmentAppearance; }
	public void setCustomAppearance(CustomAppearance customAppearance) { this.customAppearance = customAppearance; }
	public void setGenerateTooltip(boolean generateTooltip) { this.generateTooltip = generateTooltip; }
}