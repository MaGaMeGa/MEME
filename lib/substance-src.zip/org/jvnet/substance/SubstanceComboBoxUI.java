/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.ComboPopup;

import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.substance.combo.*;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.utils.SubstanceConstants;
import org.jvnet.substance.utils.SubstanceCoreUtilities;
import org.jvnet.substance.utils.SubstanceConstants.Side;

/**
 * UI for combo boxes in <b>Substance </b> look and feel.
 * 
 * @author Kirill Grouchnikov
 * @author Thomas Bierhance http://www.orbital-computer.de/JComboBox/
 * @author inostock
 */
public class SubstanceComboBoxUI extends BasicComboBoxUI {
	/**
	 * Combobox button arrow.
	 */
	public static final Map<String, Icon> COMBO_ARROWS = new HashMap<String, Icon>();

	/**
	 * Property change handler on <code>enabled</code> property,
	 * <code>componentOrientation</code> property and on
	 * {@link SubstanceLookAndFeel#COMBO_BOX_POPUP_FLYOUT_ORIENTATION} property.
	 */
	protected ComboBoxPropertyChangeHandler substanceChangeHandler;

	/**
	 * Painting delegate (for background).
	 */
	private static SubstanceGradientBackgroundDelegate backgroundDelegate = new SubstanceGradientBackgroundDelegate();

	// /**
	// * Focus listener.
	// */
	// protected FocusListener substanceFocusListener;

	/**
	 * Resets the cache of arrow images.
	 */
	public static synchronized void reset() {
		SubstanceComboBoxUI.COMBO_ARROWS.clear();
	}

	/**
	 * Returns the arrow icon.
	 * 
	 * @param theme
	 *            Theme to paint the icon.
	 * @param orientation
	 *            Arrow orientation.
	 * @return Arrow icon.
	 */
	public static synchronized Icon getArrowIcon(SubstanceTheme theme,
			int orientation) {
		String key = theme.getDisplayName() + ":" + orientation;
		Icon result = SubstanceComboBoxUI.COMBO_ARROWS.get(key);
		if (result != null)
			return result;
		result = SubstanceImageCreator
				.getArrowIcon(
						SubstanceConstants.ARROW_WIDTH,
						(orientation == SwingConstants.CENTER) ? 2 * SubstanceConstants.ARROW_HEIGHT
								: SubstanceConstants.ARROW_HEIGHT, orientation,
						theme);
		SubstanceComboBoxUI.COMBO_ARROWS.put(key, result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent b) {
		SubstanceComboBoxUI ui = new SubstanceComboBoxUI();
		return ui;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicComboBoxUI#createArrowButton()
	 */
	@Override
	protected JButton createArrowButton() {
		SubstanceTheme theme = this.comboBox.isEnabled() ? SubstanceCoreUtilities
				.getActiveTheme(this.comboBox, true)
				: SubstanceCoreUtilities.getDefaultTheme(this.comboBox, true);
		return new SubstanceComboBoxButton(this.comboBox, SubstanceComboBoxUI
				.getArrowIcon(theme, SubstanceCoreUtilities
						.getPopupFlyoutOrientation(this.comboBox)));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicComboBoxUI#createRenderer()
	 */
	@Override
	protected ListCellRenderer createRenderer() {
		return new SubstanceComboBoxRenderer.SubstanceUIResource(this.comboBox);
	}

	// /*
	// * (non-Javadoc)
	// *
	// * @see javax.swing.plaf.basic.BasicComboBoxUI#createEditor()
	// */
	// @Override
	// protected ComboBoxEditor createEditor() {
	// return new SubstanceComboBoxEditor.SubstanceUIResource();
	// }
	//
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicComboBoxUI#installListeners()
	 */
	@Override
	protected void installListeners() {
		super.installListeners();
		this.substanceChangeHandler = new ComboBoxPropertyChangeHandler();
		this.comboBox.addPropertyChangeListener(this.substanceChangeHandler);
		// this.substanceFocusListener = new FocusBorderListener(this.comboBox);
		// this.comboBox.addFocusListener(this.substanceFocusListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicComboBoxUI#uninstallListeners()
	 */
	@Override
	protected void uninstallListeners() {
		// this.comboBox.removeFocusListener(this.substanceFocusListener);
		// this.substanceFocusListener = null;
		this.comboBox.removePropertyChangeListener(this.substanceChangeHandler);
		this.substanceChangeHandler = null;
		super.uninstallListeners();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicComboBoxUI#createLayoutManager()
	 */
	@Override
	protected LayoutManager createLayoutManager() {
		return new SubstanceComboBoxLayoutManager();
	}

	/**
	 * Layout manager for combo box.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private class SubstanceComboBoxLayoutManager extends
			BasicComboBoxUI.ComboBoxLayoutManager {

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
		 */
		@Override
		public void layoutContainer(Container parent) {
			JComboBox cb = (JComboBox) parent;

			// ListCellRenderer lcr = cb.getRenderer();
			// if (lcr.getClass().getName().startsWith("java"))
			// cb.setRenderer(new ComboBoxRenderer());

			int width = cb.getWidth();
			int height = cb.getHeight();

			Insets insets = SubstanceComboBoxUI.this.getInsets();
			int buttonWidth = UIManager.getInt("ScrollBar.width");
			int buttonHeight = height - (insets.top + insets.bottom);

			if (SubstanceComboBoxUI.this.arrowButton != null) {
				if (cb.getComponentOrientation().isLeftToRight()) {
					SubstanceComboBoxUI.this.arrowButton.setBounds(width
							- (insets.right + buttonWidth), insets.top,
							buttonWidth, buttonHeight);
				} else {
					SubstanceComboBoxUI.this.arrowButton.setBounds(insets.left,
							insets.top, buttonWidth, buttonHeight);
				}
			}
			if (SubstanceComboBoxUI.this.editor != null) {
				SubstanceComboBoxUI.this.editor
						.setBounds(SubstanceComboBoxUI.this
								.rectangleForCurrentValue());
				// System.out.println("Editor " + editor.hashCode() + " - "
				// + editor.getBounds() + " : " + editor.isVisible());
				// System.out.println("Real editor : "
				// + comboBox.getEditor().getEditorComponent().hashCode());
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#getPreferredSize(javax.swing.JComponent)
	 */
	@Override
	public Dimension getPreferredSize(JComponent c) {
		Dimension superRes = super.getPreferredSize(c);
		Dimension res = new Dimension((int) superRes.getWidth() + 4,
				(int) superRes.getHeight() + 4);
		return res;
	}

	/**
	 * This property change handler changes combo box arrow icon based on the
	 * enabled status of the combo box.
	 * 
	 * @author Kirill Grouchnikov
	 */
	public class ComboBoxPropertyChangeHandler extends PropertyChangeHandler {
		@Override
		public void propertyChange(final PropertyChangeEvent e) {
			String propertyName = e.getPropertyName();

			if (propertyName.equals("enabled")) {
				if (SubstanceComboBoxUI.this.arrowButton != null) {
					// fix for bug 55
					SubstanceTheme theme = comboBox.isEnabled() ? SubstanceCoreUtilities
							.getActiveTheme(comboBox, true)
							: SubstanceCoreUtilities.getDefaultTheme(comboBox,
									true);
					SubstanceComboBoxUI.this.arrowButton
							.setIcon(SubstanceComboBoxUI
									.getArrowIcon(
											theme,
											SubstanceCoreUtilities
													.getPopupFlyoutOrientation(SubstanceComboBoxUI.this.comboBox)));
				}
			}

			if (propertyName.equals("componentOrientation")) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						if (SubstanceComboBoxUI.this.comboBox == null)
							return;
						final ComponentOrientation newOrientation = (ComponentOrientation) e
								.getNewValue();
						SubstanceComboBoxUI.this.arrowButton.putClientProperty(
								SubstanceLookAndFeel.BUTTON_SIDE_PROPERTY,
								newOrientation.isLeftToRight() ? Side.LEFT
										.name() : Side.RIGHT.name());
						final ListCellRenderer cellRenderer = SubstanceComboBoxUI.this.comboBox
								.getRenderer();
						final ComboBoxEditor editor = SubstanceComboBoxUI.this.comboBox
								.getEditor();
						if (SubstanceComboBoxUI.this.popup instanceof Component) {
							final Component cPopup = (Component) SubstanceComboBoxUI.this.popup;
							cPopup.applyComponentOrientation(newOrientation);
							cPopup.doLayout();
						}
						if (cellRenderer instanceof Component) {
							((Component) cellRenderer)
									.applyComponentOrientation(newOrientation);
						}
						if ((editor != null)
								&& (editor.getEditorComponent() instanceof Component)) {
							(editor.getEditorComponent())
									.applyComponentOrientation(newOrientation);
						}
						if (SubstanceComboBoxUI.this.comboBox != null)
							SubstanceComboBoxUI.this.comboBox.repaint();
					}
				});
			}

			if (SubstanceLookAndFeel.COMBO_BOX_POPUP_FLYOUT_ORIENTATION
					.equals(propertyName)) {
				SubstanceTheme theme = comboBox.isEnabled() ? SubstanceCoreUtilities
						.getActiveTheme(comboBox, true)
						: SubstanceCoreUtilities
								.getDefaultTheme(comboBox, true);
				SubstanceComboBoxUI.this.arrowButton
						.setIcon(SubstanceComboBoxUI
								.getArrowIcon(
										theme,
										SubstanceCoreUtilities
												.getPopupFlyoutOrientation(SubstanceComboBoxUI.this.comboBox)));

			}
			// Do not call super - fix for bug 63
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicComboBoxUI#createPopup()
	 */
	@Override
	protected ComboPopup createPopup() {
		final ComboPopup sPopup = new SubstanceComboPopup(this.comboBox);

		final ComponentOrientation currOrientation = this.comboBox
				.getComponentOrientation();

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				if (SubstanceComboBoxUI.this.comboBox == null)
					return;

				if (sPopup instanceof Component) {
					final Component cPopup = (Component) sPopup;
					cPopup.applyComponentOrientation(currOrientation);
					cPopup.doLayout();
				}
				ListCellRenderer cellRenderer = SubstanceComboBoxUI.this.comboBox
						.getRenderer();
				if (cellRenderer instanceof Component) {
					((Component) cellRenderer)
							.applyComponentOrientation(currOrientation);
				}
				ComboBoxEditor editor = SubstanceComboBoxUI.this.comboBox
						.getEditor();
				if ((editor != null)
						&& (editor.getEditorComponent() instanceof Component)) {
					(editor.getEditorComponent())
							.applyComponentOrientation(currOrientation);
				}
				SubstanceComboBoxUI.this.comboBox.repaint();
			}
		});
		return sPopup;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicComboBoxUI#paintCurrentValueBackground(java.awt.Graphics,
	 *      java.awt.Rectangle, boolean)
	 */
	@Override
	public void paintCurrentValueBackground(Graphics g, Rectangle bounds,
			boolean hasFocus) {
		// override to prevent the behaviour from the base class, which
		// ignores the painting of the default cell renderer.
		SubstanceTheme theme = hasFocus ? SubstanceCoreUtilities
				.getActiveTheme(this.comboBox, true) : (this.comboBox
				.isEnabled() ? SubstanceCoreUtilities.getDefaultTheme(
				this.comboBox, true) : SubstanceCoreUtilities.getDisabledTheme(
				this.comboBox, true));
		Graphics2D graphics = (Graphics2D) g.create();
		if (!SubstanceCoreUtilities.isControlAlwaysPaintedActive(this.comboBox)) {
			graphics.setComposite(TransitionLayout.getAlphaComposite(
					this.comboBox, 0.5f));
		}
		Rectangle newBounds = bounds;
		if (this.comboBox.getBorder() != null) {
			newBounds = new Rectangle(bounds.x, bounds.y + 1, bounds.width,
					bounds.height - 2);
		}
		SubstanceComboBoxUI.backgroundDelegate.update(graphics, this.comboBox,
				newBounds, theme.getHighlightBackgroundTheme(), false);
		graphics.dispose();
	}

	/**
	 * Returns the popup of the associated combobox.
	 * 
	 * @return The popup of the associated combobox.
	 */
	public ComboPopup getPopup() {
		return this.popup;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void update(Graphics g, JComponent c) {
		if (SubstanceCoreUtilities.hasSubstanceBorder(c)) {
			if (c.isOpaque()) {
				g.setColor(c.getBackground());
				g.fillRect(1, 1, c.getWidth() - 2, c.getHeight() - 2);
			}
			paint(g, c);
		} else {
			super.update(g, c);
		}
	}

	/**
	 * Returns memory usage string.
	 * 
	 * @return Memory usage string.
	 */
	public static String getMemoryUsage() {
		StringBuffer sb = new StringBuffer();
		sb.append("SubstanceComboBoxUI: \n");
		sb.append("\t" + SubstanceComboBoxUI.COMBO_ARROWS.size() + " arrows");
		return sb.toString();
	}
	
	@Override
	public void configureArrowButton() {
		super.configureArrowButton();
		// Mustang decided to make the arrow button focusable on
		// focusable comboboxes 
		this.arrowButton.setFocusable(false);
	}
}
