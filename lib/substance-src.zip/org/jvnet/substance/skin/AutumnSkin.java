/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.skin;

import java.awt.Color;

import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.painter.*;
import org.jvnet.substance.theme.*;
import org.jvnet.substance.theme.SubstanceTheme.ThemeKind;
import org.jvnet.substance.title.ClassicTitlePainter;
import org.jvnet.substance.utils.SubstanceColorUtilities;
import org.jvnet.substance.watermark.SubstanceNullWatermark;

/**
 * <code>Autumn</code> skin. This class is experimental and not part of
 * officially supported API.
 * 
 * @author Kirill Grouchnikov
 * @since version 3.1
 */
public class AutumnSkin extends SubstanceAbstractSkin {
	/**
	 * Display name for <code>this</code> skin.
	 */
	public static String NAME = "Autumn";

	/**
	 * Color scheme for active visual state.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected static class ActiveScheme implements ColorScheme {
		/**
		 * The main ultra-light color.
		 */
		private static final Color mainUltraLightColor = SubstanceColorUtilities
				.getFromHex("FDDDAC");

		/**
		 * The main extra-light color.
		 */
		private static final Color mainExtraLightColor = SubstanceColorUtilities
				.getFromHex("FCEF9F");

		/**
		 * The main light color.
		 */
		private static final Color mainLightColor = SubstanceColorUtilities
				.getFromHex("FCD592");

		/**
		 * The main medium color.
		 */
		private static final Color mainMidColor = SubstanceColorUtilities
				.getFromHex("F9BE84");

		/**
		 * The main dark color.
		 */
		private static final Color mainDarkColor = SubstanceColorUtilities
				.getFromHex("F8B87A");

		/**
		 * The main ultra-dark color.
		 */
		private static final Color mainUltraDarkColor = SubstanceColorUtilities
				.getFromHex("5B0E00");

		/**
		 * The foreground color.
		 */
		private static final Color foregroundColor = SubstanceColorUtilities
				.getFromHex("0A0000");

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getForegroundColor()
		 */
		public Color getForegroundColor() {
			return ActiveScheme.foregroundColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getUltraLightColor()
		 */
		public Color getUltraLightColor() {
			return ActiveScheme.mainUltraLightColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getExtraLightColor()
		 */
		public Color getExtraLightColor() {
			return ActiveScheme.mainExtraLightColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getLightColor()
		 */
		public Color getLightColor() {
			return ActiveScheme.mainLightColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getMidColor()
		 */
		public Color getMidColor() {
			return ActiveScheme.mainMidColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getDarkColor()
		 */
		public Color getDarkColor() {
			return ActiveScheme.mainDarkColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getUltraDarkColor()
		 */
		public Color getUltraDarkColor() {
			return ActiveScheme.mainUltraDarkColor;
		}
	}

	/**
	 * Color scheme for default visual state.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected static class DefaultScheme implements ColorScheme {
		/**
		 * The main ultra-light color.
		 */
		private static final Color mainUltraLightColor = SubstanceColorUtilities
				.getFromHex("FFF2DF");

		/**
		 * The main extra-light color.
		 */
		private static final Color mainExtraLightColor = SubstanceColorUtilities
				.getFromHex("FFE3C5");

		/**
		 * The main light color.
		 */
		private static final Color mainLightColor = SubstanceColorUtilities
				.getFromHex("FDD1A4");

		/**
		 * The main medium color.
		 */
		private static final Color mainMidColor = SubstanceColorUtilities
				.getFromHex("FBCD9C");

		/**
		 * The main dark color.
		 */
		private static final Color mainDarkColor = SubstanceColorUtilities
				.getFromHex("FCC896");

		/**
		 * The main ultra-dark color.
		 */
		private static final Color mainUltraDarkColor = SubstanceColorUtilities
				.getFromHex("872A00");

		/**
		 * The foreground color.
		 */
		private static final Color foregroundColor = SubstanceColorUtilities
				.getFromHex("2B0E00");

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getForegroundColor()
		 */
		public Color getForegroundColor() {
			return DefaultScheme.foregroundColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getUltraLightColor()
		 */
		public Color getUltraLightColor() {
			return DefaultScheme.mainUltraLightColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getExtraLightColor()
		 */
		public Color getExtraLightColor() {
			return DefaultScheme.mainExtraLightColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getLightColor()
		 */
		public Color getLightColor() {
			return DefaultScheme.mainLightColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getMidColor()
		 */
		public Color getMidColor() {
			return DefaultScheme.mainMidColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getDarkColor()
		 */
		public Color getDarkColor() {
			return DefaultScheme.mainDarkColor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.color.ColorScheme#getUltraDarkColor()
		 */
		public Color getUltraDarkColor() {
			return DefaultScheme.mainUltraDarkColor;
		}
	}

	/**
	 * Creates a new <code>Autumn</code> skin.
	 */
	public AutumnSkin() {
		SubstanceTheme activeTheme = new SubstanceTheme(new ActiveScheme(),
				"Autumn Active", ThemeKind.COLD);
		SubstanceTheme defaultTheme = new SubstanceTheme(new DefaultScheme(),
				"Autumn Default", ThemeKind.COLD);
		SubstanceTheme disabledTheme = new SubstanceBlendBiTheme(defaultTheme,
				defaultTheme.getDisabledTheme(), 0.6);
		SubstanceTheme activeTitleTheme = defaultTheme;

		SubstanceComplexTheme theme = new SubstanceComplexTheme(NAME,
				ThemeKind.COLD, activeTheme, defaultTheme, disabledTheme,
				activeTitleTheme);
		theme
				.setNonActivePainter(new SimplisticSoftBorderReverseGradientPainter());
		theme.setSelectedTabFadeStart(0.1);
		theme.setSelectedTabFadeEnd(0.3);
		this.theme = theme;
		// ((SubstanceComplexTheme) this.theme)
		// .setCellRendererBackgroundTheme(new SubstanceBlendBiTheme(
		// new SubstanceTerracottaTheme(),
		// new SubstanceSunGlareTheme(), 0.5).tint(0.2));
		// theme.addPaintAsActive(JScrollBar.class);
		this.shaper = new ClassicButtonShaper();
		this.watermark = new SubstanceNullWatermark();
		this.gradientPainter = new GlassGradientPainter();
		this.titlePainter = new ClassicTitlePainter();
		this.tabBackgroundComposite = new AlphaControlBackgroundComposite(0.75f);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.skin.SubstanceSkin#getDisplayName()
	 */
	public String getDisplayName() {
		return NAME;
	}
}
