/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs.components;

import java.awt.Dimension;
import java.awt.Font;

import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JButton;

import ai.aitia.chart.charttypes.dialogs.AbstractChartDialog;
import ai.aitia.chart.util.ChartConstants;

import java.awt.BorderLayout;
import java.awt.event.ItemEvent;
import java.awt.event.KeyEvent;
import java.util.Properties;

/** GUI component that contains the extra widgets (title, '2nd vertical axis'
 *  checkbox and 'Remove' button) for the GUI component of a child chart in a
 *  multi-layered charts.
 */
public class ChildAdditionalPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JCheckBox axisCheckBox = null;
	private JButton removeButton = null;
	private JPanel buttonPanel = null;
	private JLabel jLabel = null;

	//=============================================================================
	// additional members
	
	/** Title of the child chart. */
	private String title = null;
	
	/** Settings of the child chart. */
	private Properties properties = null;
	
	/** Parent GUI component. */
	private AbstractChartDialog parent = null;

	//=============================================================================
	// methods
	
	/** Constructor.
	 * @param parent parent GUI component
	 * @param properties settings of the child chart
	 * @param title title of the child chart
	 */
	public ChildAdditionalPanel(AbstractChartDialog parent, Properties properties, String title) {
		super();
		this.parent = parent;
		this.properties = properties;
		this.title = title;
		initialize();
		setSettingsFromConfig();
	}

	//----------------------------------------------------------------------------
	/** This method initializes <code>this</code>. */
	private void initialize() {
		jLabel = new JLabel("Additional chart: " +title);
		jLabel.setFont(new Font("SansSerif",Font.BOLD,16));
		jLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
		this.setSize(609, 36);
		this.setLayout(new BorderLayout());
		this.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		this.setMaximumSize(new Dimension(609, 36));
		this.add(jLabel, BorderLayout.CENTER);
		this.add(getButtonPanel(), BorderLayout.EAST);
	}

	//----------------------------------------------------------------------------
	private JCheckBox getAxisCheckBox() {
		if (axisCheckBox == null) {
			axisCheckBox = new JCheckBox();
			axisCheckBox.setText("2nd vertical axis");
			axisCheckBox.addItemListener(new java.awt.event.ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					if (e.getStateChange() == ItemEvent.SELECTED) {
						properties.setProperty(ChartConstants.SECOND_VERTICAL_AXIS,"true");
						parent.setSelectedAxis();
					} else {
						properties.setProperty(ChartConstants.SECOND_VERTICAL_AXIS, "false");
					}
				}
			});
		}
		return axisCheckBox;
	}

	//----------------------------------------------------------------------------
	private JButton getRemoveButton() {
		if (removeButton == null) {
			removeButton = new JButton();
			removeButton.setText("Remove Chart");
			removeButton.setPreferredSize(new Dimension(114, 26));
			removeButton.setMnemonic(KeyEvent.VK_E);
			removeButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					parent.removeChild();
					parent.childStatusChanged();
				}
			});
		}
		return removeButton;
	}

	//----------------------------------------------------------------------------
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = new JPanel();
			buttonPanel.setLayout(new BoxLayout(getButtonPanel(), BoxLayout.X_AXIS));
			buttonPanel.add(getAxisCheckBox(), null);
			buttonPanel.add(Box.createRigidArea(new Dimension(10,0)));
			buttonPanel.add(getRemoveButton(), null);
		}
		return buttonPanel;
	}

	//=============================================================================
	// non-GUI methods
	
	/** Unselects the '2nd vertical axis' checkbox. */
	public void setAxisDisabled() {
		axisCheckBox.setSelected(false);
	}
	
	//----------------------------------------------------------------------------
	/** This function sets the widgets from the settings object. */
	private void setSettingsFromConfig() {
		String axis = properties.getProperty(ChartConstants.SECOND_VERTICAL_AXIS);
		if (axis != null) {
			axisCheckBox.setSelected(Boolean.parseBoolean(axis));
		} else {
			properties.setProperty(ChartConstants.SECOND_VERTICAL_AXIS,"false");
		}
	}
}
