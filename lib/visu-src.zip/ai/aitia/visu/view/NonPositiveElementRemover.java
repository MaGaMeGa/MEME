package ai.aitia.visu.view;

import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetChangeListener;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import ai.aitia.visu.ds.xy.ModifiableXYSeries;

public class NonPositiveElementRemover implements DatasetChangeListener {

	private boolean xLog = false;
	private boolean yLog = false;
	
	public NonPositiveElementRemover(boolean xLog, boolean yLog) {
		this.xLog = xLog;
		this.yLog = yLog;
	}
	
	public void datasetChanged(DatasetChangeEvent event) {
		Object source = event.getSource();
		XYSeriesCollection dataset = null;
		if (source instanceof XYSeriesCollection) {
			dataset = (XYSeriesCollection)source;
			if (xLog) {
				for (int i=0;i<dataset.getSeriesCount();++i) {
					ModifiableXYSeries series = (ModifiableXYSeries)dataset.getSeries(i);
					XYSeries new_series = new XYSeries(series.getKey());
					for (int j=0 ; j<series.getItemCount() ; ++ j) {
						if (!series.getX(j).equals(new Double(0))) new_series.add(series.getDataItem(j));
					}
					series.setItems(new_series,false);

				}
			}
			if (yLog) {
				for (int i=0;i<dataset.getSeriesCount();++i) {
					ModifiableXYSeries series = (ModifiableXYSeries)dataset.getSeries(i);
					XYSeries new_series = new XYSeries(series.getKey());
					for (int j=0 ; j<series.getItemCount() ; ++ j) {
						if (!series.getY(j).equals(new Double(0))) new_series.add(series.getDataItem(j));
					}
					series.setItems(new_series,false);
				}
			}
		}
	}
}
