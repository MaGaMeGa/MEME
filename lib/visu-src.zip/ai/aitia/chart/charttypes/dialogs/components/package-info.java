/** This package contains GUI components and interfaces that several chart GUI use. */
package ai.aitia.chart.charttypes.dialogs.components;