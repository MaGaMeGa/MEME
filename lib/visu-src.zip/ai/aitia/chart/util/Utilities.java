/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.util;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Map.Entry;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenuItem;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.IDataSourceProducer.NumberStrPair;
import ai.aitia.chart.emulator.ProducerEmulator;
import ai.aitia.chart.view.ui.AutomaticFigureRenderer;
import ai.aitia.chart.view.ui.ConstantColorMap;
import ai.aitia.chart.view.ui.UserDefinedFigureRenderer;
import ai.aitia.visu.globalhandlers.UserBreakException;
import ai.aitia.visu.utils.Interval;
import ai.aitia.visu.utils.Utils;
import ai.aitia.visu.view.ui.BlackAndWhiteColorMap;
import ai.aitia.visu.view.ui.ColorMap;
import ai.aitia.visu.view.ui.ColorMapCollection;
import ai.aitia.visu.view.ui.DefaultElementRenderer;
import ai.aitia.visu.view.ui.IElementRenderer;
import ai.aitia.visu.view.ui.IFigureRenderer;
import ai.aitia.visu.view.ui.IntervalTableColorMap;
import ai.aitia.visu.view.ui.RainbowColorMap;
import ai.aitia.visu.view.ui.SimpleColorMap;
import cern.colt.matrix.DoubleMatrix2D;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;
import edu.uci.ics.jung.graph.impl.DirectedSparseGraph;
import edu.uci.ics.jung.graph.impl.SparseVertex;
import edu.uci.ics.jung.graph.impl.UndirectedSparseEdge;
import edu.uci.ics.jung.graph.impl.UndirectedSparseGraph;
import edu.uci.ics.jung.utils.UserData;

/** Utility functions for the charting package. */
public class Utilities {
	
	//----------------------------------------------------------------------------------------------------
	public static interface IGridConstants {
		/** Constant for full mode (or sequential mode) of grid creation. */
		public static final int FULL_MODE = 0;
		
		/** Constant for partial mode (or random access mode) of grid creation. */
		public static final int PARTIAL_MODE = 1;
		
		/** Constant for dataset mode of grid creation. */
		public static final int DS_MODE = 2;
	}
	
	//----------------------------------------------------------------------------------------------------
	/** This functions returns whether the data source supports
	 *  (or can be part of the emulation) the given data producer type described by
	 *  <code>type</code> or not.
	 * @param dsp data source
	 * @param type IDataProducer-descendant interface
	 */
	public static boolean canBe(final IDataSourceProducer dsp, final Class type) {
		List<Class> supported = dsp.getSupportedIntfs(), disabled;
		if (supported == null) return false;
		if (supported.contains(type)) return true;
		disabled = dsp.getDisabledIntfs();
		if (disabled != null && disabled.contains(type)) return false;
		final Iterator<Class> it = supported.iterator();
		while (it.hasNext()) {
			boolean canBe = ProducerEmulator.canProduce(it.next(),type);
			if (canBe) return true;
		}
		return false;
	}
	
	//-----------------------------------------------------------------------------	
	/** This function writes the contains of the <code>prop</code> to an XML-node.
	 * 
	 * @param node XML-node
	 * @param prop properties object
	 */
	public static void writeProperties(final Node node, final Properties prop) {
		final Document document = node.getOwnerDocument();
		for (final Entry<Object,Object> e : prop.entrySet()) {
			final Element element = document.createElement("property");
			element.setAttribute("key",e.getKey().toString());
			element.appendChild(document.createTextNode(e.getValue().toString()));
			node.appendChild(element);
		}
	}
	
	//-----------------------------------------------------------------------------	
	/** This function reads data from <code>node</code> and creates a Properties
	 *  object.
	 * @param node XML-node
	 * @return a Properties object that contains the data of the <code>node</code>
	 * @throws XMLLoadingException it throws this exception if there is no child nodes
	 * 		   of <code>node</code>.
	 */
	public static Properties readProperties(final Node node) throws XMLLoadingException {
		final Properties prop = new Properties();
		final NodeList nodes = node.getChildNodes();
		if (nodes == null) {
			throw new XMLLoadingException("No childs of node: <" + node.getNodeName() + ">");
		}
		for (int i = 0;i < nodes.getLength();++i) {
			if (!(nodes.item(i) instanceof Element)) continue;
			final Element element = (Element) nodes.item(i);
			if (!element.getTagName().equals("property")) continue;
			final String key = element.getAttribute("key");
			final Text text = (Text) element.getChildNodes().item(0);
			if (text == null) 
				prop.setProperty(key.trim(),"");
			else {
				final String value = text.getNodeValue();
				prop.setProperty(key.trim(),value.trim());
			}
		}
		return prop;
	}
	
	//-----------------------------------------------------------------------------	
	/** This function examines the name of the <code>original</code> file, and if the 
	 *  name isn't ends with <code>extension</code>, it concatenates a point and the
	 *  <code>extension</code> to the end of the name, then returns a new file object.
	 *  If the name ends with <code>extension</code>, then returns the <code>original
	 *  </code> file object.
	 * @param original original file
	 * @param extension the desired extension
	 * @return the new file
	 */
	public static File generateValidFile(final File original, final String extension) {
		String name = original.toString();
		String ext = null;
		final int index = name.lastIndexOf('.');
		if (index > 0 &&  index < name.length() - 1) 
			ext = name.substring(index+1).toLowerCase();
		if (ext == null || !ext.equals(extension.toLowerCase())) {
			name += "." + extension.toLowerCase();
			final File newFile = new File(name);
			return newFile;
		}
		return original;
	}
	
	//-----------------------------------------------------------------------------	
	/** This function splits <code>dss</code> around commas, and returns the data
 	 *  source's XML-ids in an array of integers.
 	 * @param dss string that contains data source ids separated by commas
 	 * @return array of data source ids
 	 */
 	public static int[] splitDatasourceAroundCommas(final String dss) {
 		final String[] strings = dss.split(",");
 		final int[] result = new int[strings.length];
 		for (int i = 0;i < strings.length;++i) 
 			result[i] = Integer.parseInt(strings[i]);
 		return result;
 	}
 	
	//-----------------------------------------------------------------------------	
 	/** This functions splits <code>dss</code> around spaces, and returns the data
 	 *  sources's XML-ids in an array of integers.
 	 * @param dss strings that contains data source ids separated by spaces
 	 * @return array of data source ids
 	 */
 	public static int[] splitDatasourceAroundSpace(final String dss) {
 		final String[] strings = dss.split(" ");
 		final int[] result = new int[strings.length];
 		for (int i = 0;i < strings.length;++i) 
 			result[i] = Integer.parseInt(strings[i]);
 		return result;
 	}
 	
	//-----------------------------------------------------------------------------	
 	/** This function returns a ColorMap object created from the <code>settings
 	 *  </code> string. It returns <code>null</code> if the input string describes 
 	 *  an unknown or ill-formed colormap.
 	 * @param settings string description of a colormap
 	 * @return a ColorMap object
 	 */
 	public static ColorMap createColorMapFromString(final String settings) {
		final String[] strings = settings.split(",");
		if (strings[0].equals(ChartConstants.RAINBOW)) {
			return new RainbowColorMap(Double.parseDouble(strings[1]),Double.parseDouble(strings[2]));
		} else if (strings[0].equals(ChartConstants.BLACK_AND_WHITE_COLORMAP)) {
			return new BlackAndWhiteColorMap(Double.parseDouble(strings[1]),Double.parseDouble(strings[2]));
		} else if (strings[0].equals(ChartConstants.HEAT)) {
			return new ColorMapCollection(Double.parseDouble(strings[1]),Double.parseDouble(strings[2]),ColorMapCollection.HEAT);
		} else if (strings[0].equals(ChartConstants.REAL)) {
			return new ColorMapCollection(Double.parseDouble(strings[1]),Double.parseDouble(strings[2]),ColorMapCollection.REAL);
		} else if (strings[0].equals(ChartConstants.PASTEL)) {
			return new ColorMapCollection(Double.parseDouble(strings[1]),Double.parseDouble(strings[2]),ColorMapCollection.PASTEL);
		} else if (strings[0].equals(ChartConstants.RANDOM)) {
			return new ColorMapCollection(Double.parseDouble(strings[1]),Double.parseDouble(strings[2]),ColorMapCollection.RANDOM);
		} else if (strings[0].equals(ChartConstants.CONSTANT)) {
			final Color constantColor = new Color(Integer.decode(strings[1])); 
			return new ConstantColorMap(constantColor);
		} else if (strings[0].equals(ChartConstants.SIMPLE)) {
			final double min = Double.parseDouble(strings[1]);
			final double max = Double.parseDouble(strings[2]);
			final Color minColor = new Color(Integer.decode(strings[3]));
			final Color maxColor = new Color(Integer.decode(strings[4]));
			return new SimpleColorMap(min,max,minColor,maxColor);
		} else if (strings[0].equals(ChartConstants.TABLE)) {
			final IntervalTableColorMap tableColorMap = new IntervalTableColorMap();
			tableColorMap.setName(strings[1]);
			tableColorMap.setDefaultColor(new Color(Integer.decode(strings[2])));
			for (int i = 3;i < strings.length;++i) {
				final String[] pair = strings[i].split(":");
				final Interval intv = new Interval(pair[0]);
				final Color color = pair[1].equals("_") ? null : new Color(Integer.decode(pair[1]));
				tableColorMap.addEntry(intv,color);
			}
			return tableColorMap;
		}
		return null;
 	}
 	
	//-----------------------------------------------------------------------------	
 	/** This function returns an IFigureRenderer created from the <code>settings
 	 *  </code> string. It returns <code>null</code> if the input string describes 
 	 *  an unknown or ill-formed shape renderer.
 	 * @param settings string description of a shape renderer
 	 * @return an IFigureRenderer object
 	 * @throws Exception if any problems occure during the instantiation of a custom
 	 *  renderer
 	 */
 	@SuppressWarnings("unchecked")
	public static IFigureRenderer createShapeRendererFromString(final String settings) throws Exception {
		final String[] strings = settings.split(",");
		if (strings[0].equals(ChartConstants.AUTO)) 
			return new AutomaticFigureRenderer();
		else if (strings[0].equals(ChartConstants.DEFINED)) {
			final UserDefinedFigureRenderer defRenderer = new UserDefinedFigureRenderer();
			defRenderer.setName(strings[1]);
			defRenderer.setDefaultColor(new Color(Integer.decode(strings[2])));
			for (int i = 3;i < strings.length;++i) {
				final String[] pair = strings[i].split(";");
				final Interval intv = new Interval(pair[0]);
				final String[] parts = pair[1].split("\\?");
				final String figure = parts[0].equals("_") ? null : parts[0];
				final Color color = parts[1].equals("_") ? null : new Color(Integer.decode(parts[1]));
				defRenderer.addEntry(intv,figure,color);
			}
			return defRenderer;
		} else if (strings[0].equals("CUSTOM")) {
 			final Class rendererClass = Class.forName(strings[1]);
			final Properties prop = new Properties();
			for (int i = 2;i < strings.length;++i) {
				final String[] parts = strings[i].split(":");
				prop.setProperty(parts[0],parts[1]);
			}
			Constructor constructor = null;
			if (prop.isEmpty()) {
				constructor = rendererClass.getConstructor(new Class[] {});
				return (IFigureRenderer)constructor.newInstance(new Object[] {});
			} else {
				constructor = rendererClass.getConstructor(new Class[] { Properties.class });
				return (IFigureRenderer)constructor.newInstance(new Object[] { prop });
			}
		}
 		return null;
 	}
 	
 	//-----------------------------------------------------------------------------
 	/** This function returns an IElementRenderer created from the <code>settings</code>
 	 *  string. It returns <code>null</code> if the input string describes 
 	 *  an unknown or ill-formed element renderer.
 	 * @param settings string description of an element renderer
 	 * @return an IElementRenderer object
 	 * @throws Exception if any problems occure during the instantiation of a custom
 	 *  renderer
 	 */
 	@SuppressWarnings("unchecked")
	public static IElementRenderer createElementRendererFromString(final String settings) throws Exception {
 		final String[] strings = settings.split(",");
 		if (strings[0].equals("DEFAULT")) {
 			final DefaultElementRenderer renderer = new DefaultElementRenderer();
 			renderer.setForeground(new Color(Integer.decode(strings[1])));
 			renderer.setBackground(new Color(Integer.decode(strings[2])));
 			return renderer;
 		} else if (strings[0].equals("CUSTOM")) {
 			final Class rendererClass = Class.forName(strings[1]);
			final Properties prop = new Properties();
			for (int i = 2;i < strings.length;++i) {
				final String[] parts = strings[i].split(":");
				prop.setProperty(parts[0],parts[1]);
			}
			Constructor constructor = null;
			if (prop.isEmpty()) {
				constructor = rendererClass.getConstructor(new Class[] {});
				return (IElementRenderer)constructor.newInstance(new Object[] {});
			} else {
				constructor = rendererClass.getConstructor(new Class[] { Properties.class });
				return (IElementRenderer)constructor.newInstance(new Object[] { prop });
			}
 		} else if (strings[0].equals("DEFINED")) {
			final UserDefinedFigureRenderer defRenderer = new UserDefinedFigureRenderer();
			defRenderer.setDefaultColor(new Color(Integer.decode(strings[1])));
			for (int i = 2;i < strings.length;++i) {
				final String[] pair = strings[i].split(";");
				final Interval intv = new Interval(pair[0]);
				final String[] parts = pair[1].split("\\?");
				final String figure = parts[0].equals("_") ? null : parts[0];
				final Color color = parts[1].equals("_") ? null : new Color(Integer.decode(parts[1]));
				defRenderer.addEntry(intv,figure,color);
			}
			return defRenderer;
 		}
 		return null;
 	}
 	
	//-----------------------------------------------------------------------------	
 	/** This function returns from an XML-file a list of Properties objects that
 	 *  describe data sources. It returns <code>null</code> if any problems occure.
 	 * @param uri name of an XML file
 	 * @return list of Properties
 	 */ 
 	public static List<Properties> getDataSourceProperties(final URI uri) {
		final List<Properties> result_list = new ArrayList<Properties>();
 		try {
			final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			final DocumentBuilder parser = factory.newDocumentBuilder();
			final Document document = parser.parse(uri.toString());
			
			final Element chart = document.getDocumentElement();
			final NodeList nodes = chart.getElementsByTagName("datasources");
			if (nodes == null) return null;
			final Element datasources = (Element) nodes.item(0);
			final NodeList dsnodes = datasources.getElementsByTagName("datasource");
			for (int i = 0;i < dsnodes.getLength();++i) {
				final Element element = (Element) dsnodes.item(i);
				final Properties prop = Utilities.readProperties(element);
				String type_string = element.getAttribute("type");
				type_string = type_string.trim();
				if (type_string.equals("")) return null;
				String id_string = element.getAttribute("id");
				Class.forName(type_string);
				id_string = id_string.trim();
				if (id_string.equals("")) return null;
				prop.setProperty("producer",type_string);
				prop.setProperty("id",id_string);
				result_list.add(prop);
			}
		} catch (Exception e) {
			return null;
		} 
 		return result_list;
 	}
 	
 	//------------------------------------------------------------------------------------
 	/** This function returns whether a network specified by data source id
 	 *  directed or undirected. The function needs an URI of the chart descriptor XML-file.
 	 *  It throws IllegalArgumentException if the given data source id isn't use by a
 	 *  Network. It throws XMLLoadingException is any problem occure during the file operations.
 	 * @param uri name of an XML file
 	 * @param id data source id
 	 * @return the user network directed or undirected
 	 * @throws IllegalArgumentException
 	 * @throws XMLLoadingException
 	 */
 	public static boolean isDirected(final URI uri, final int id) throws IllegalArgumentException, XMLLoadingException {
 		try {
			final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			final DocumentBuilder parser = factory.newDocumentBuilder();
			final Document document = parser.parse(uri.toString());
			
			final Element chart = document.getDocumentElement();
			final NodeList nodes = chart.getElementsByTagName("chartconfig");
			if (nodes == null) 
				throw new XMLLoadingException("missing <chartconfig> node");
			for (int i = 0;i < nodes.getLength();++i) {
				final Element element = (Element) nodes.item(i);
				final Properties prop = Utilities.readProperties(element);
				if (prop == null) continue;
				final String type = element.getAttribute("type");
				if (type.equals(ChartConstants.NETWORK)) {
					final String ds_str =  prop.getProperty(ChartConstants.DATASOURCE);
					if (ds_str == null || ds_str.trim().equals("")) continue;
					final String[] split = ds_str.trim().split(",");
					final int ds_id = Integer.parseInt(split[0]);
					if (id == ds_id) {
						final String undir_str = prop.getProperty(ChartConstants.UNDIRECTED);
						final boolean undirected = Boolean.parseBoolean(undir_str);
						return !undirected;
					}
				}
			}
			throw new IllegalArgumentException("Id " + String.valueOf(id) + " is never used by networks.");
		} catch (ParserConfigurationException e) {
			throw new XMLLoadingException(e);
		} catch (SAXException e) {
			throw new XMLLoadingException(e);
		} catch (IOException e) {
			throw new XMLLoadingException(e);
		}
 	}
 	
 	//-----------------------------------------------------------------------------
 	/** This function returns from an XML-file a list of list of Integers. A list 
 	 *  of Integers contains the ids of the datasources for each &lt;chartconfig&gt;
 	 *  elements. 
 	 * @param uri name of an XML file
 	 * @return list of data source ids for each &lt;chartconfig&gt; elements in a list
 	 */
 	@SuppressWarnings("deprecation")
	public static List<List<Integer>> getDataSourceIDs(final URI uri) {
 		final List<List<Integer>> result_list = new ArrayList<List<Integer>>();
		try {
			final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			final DocumentBuilder parser = factory.newDocumentBuilder();
			final Document document = parser.parse(uri.toString());
			
			final Element chart = document.getDocumentElement();
			final NodeList nodes = chart.getElementsByTagName("chartconfig");
			if (nodes == null) return null;
			for (int i = 0;i < nodes.getLength();++i) {
				final List<Integer> datasource_list = new ArrayList<Integer>();
				final Element element = (Element) nodes.item(i);
				final Properties prop = readProperties(element);
				if (prop == null) continue;
				final String type = element.getAttribute("type");
				if (type.equals(ChartConstants.GRID2D) || type.equals(ChartConstants.SHAPEGRID2D) ||
					type.equals(ChartConstants.COMPOSITEGRID2D)) {
					final boolean user_defined_width = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_WIDTH));
					if (!user_defined_width) {
						final int ds = Integer.parseInt(prop.getProperty(ChartConstants.WIDTH));
						datasource_list.add(ds); 
					}
					final boolean user_defined_height = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
					if (!user_defined_height) {
						final int ds = Integer.parseInt(prop.getProperty(ChartConstants.HEIGHT));
						datasource_list.add(ds); 
					}
				} else if (type.equals(ChartConstants.NETWORK) || type.equals(ChartConstants.SUBGRAPH)) {
					final boolean user_defined_number = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_NUMBER,"true"));
					if (!user_defined_number) {
						final int ds = Integer.parseInt(prop.getProperty(ChartConstants.NR_OF_NODES));
						datasource_list.add(ds);
					}
				} else if (type.equals(ChartConstants.MULTIGRID2D)) {
					NodeList inner = element.getElementsByTagName(ChartConstants.GRID_LAYERS);
					final Element gridLayers = (Element) inner.item(0);
					inner = gridLayers.getElementsByTagName(ChartConstants.GRID_LAYER);
					for (int j = 0; j < inner.getLength();++j) {
						final Properties innerProp = readProperties(inner.item(j));
						final boolean user_defined_width = Boolean.parseBoolean(innerProp.getProperty(ChartConstants.USER_DEFINED_WIDTH));
						if (!user_defined_width) {
							final int ds = Integer.parseInt(innerProp.getProperty(ChartConstants.WIDTH));
							datasource_list.add(ds); 
						}
						final boolean user_defined_height = Boolean.parseBoolean(innerProp.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
						if (!user_defined_height) {
							final int ds = Integer.parseInt(innerProp.getProperty(ChartConstants.HEIGHT));
							datasource_list.add(ds); 
						}
						final String ds_str = innerProp.getProperty("datasource");
						if (ds_str == null || ds_str.trim().equals("")) continue;
						final int[] split = splitDatasourceAroundCommas(ds_str.trim());
						for (int k = 0;k < split.length;++k)
							datasource_list.add(split[k]);
					}
				}
				final String ds_str =  prop.getProperty("datasource");
				if (ds_str == null || ds_str.trim().equals("")) continue;
				final String[] split1 = ds_str.trim().split(",");
				for (int j = 0;j < split1.length;++j) {
					final int[] split2 = splitDatasourceAroundSpace(split1[j]);
					for (int k = 0;k < split2.length;++k)
						datasource_list.add(split2[k]);
				}
				result_list.add(datasource_list);
			}
		} catch (Exception e) {
			return null;
		}
		return result_list;
 
 	}
 	
	//-----------------------------------------------------------------------------	
 	/** This function returns from an XML-file a list of numbers that describe 
 	 *  dimensions (or variables) [width, height] and the filling order of any
 	 *  available "grid". It returns <code>null</code> if any problems occure.
 	 * @param uri name of a XML file
 	 * @return list of numbers
 	 */
 	@SuppressWarnings("deprecation")
	public static List<Number> getGridDimensions(final URI uri) {
 		final List<Number> result_list = new ArrayList<Number>();
		try {
			final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			final DocumentBuilder parser = factory.newDocumentBuilder();
			final Document document = parser.parse(uri.toString());
			
			final Element chart = document.getDocumentElement();
			final NodeList nodes = chart.getElementsByTagName("chartconfig");
			if (nodes == null) return null;
			for (int i = 0;i < nodes.getLength();++i) {
				final Element element = (Element) nodes.item(i);
				final String type_string = element.getAttribute("type");
				if (type_string.equals(ChartConstants.GRID2D) ||
					type_string.equals(ChartConstants.SHAPEGRID2D) ||
					type_string.equals(ChartConstants.COMPOSITEGRID2D)) {
					final Properties prop = readProperties(element);
					final String str_width = prop.getProperty(ChartConstants.WIDTH);
					final String str_height = prop.getProperty(ChartConstants.HEIGHT);
					final int width = str_width.equals("") ? -1 : Integer.parseInt(str_width);
					final int height = str_height.equals("") ? -1 : Integer.parseInt(str_height);
					final boolean user_defined_width = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_WIDTH));
					final boolean user_defined_height = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
					if (!user_defined_width) 
						result_list.add(new Long(width));
					else 
						result_list.add(new Integer(width));
					if (!user_defined_height) 
						result_list.add(new Long(height));
					else 
						result_list.add(new Integer(height));
					final String ds = prop.getProperty(ChartConstants.DATASOURCE);
					final String[] ds_split = ds.split(",");
					if (ds_split.length > 2)
						result_list.add(new Integer(-1));
					else {
						final int value = Boolean.parseBoolean(prop.getProperty(ChartConstants.ROW_ORDER)) ? 0 : 1;
						result_list.add(new Integer(value));
					}
				} else if (type_string.equals(ChartConstants.MULTIGRID2D)) {
					final HorribleNumber widths = new HorribleNumber();
					final HorribleNumber heights = new HorribleNumber();
					final HorribleNumber booleans = new HorribleNumber();
					NodeList inner = element.getElementsByTagName(ChartConstants.GRID_LAYERS);
					final Element gridLayers = (Element) inner.item(0);
					inner = gridLayers.getElementsByTagName(ChartConstants.GRID_LAYER);
					for (int j = 0;j < inner.getLength();++j) {
						final Properties prop = readProperties(inner.item(j));
						final String str_width = prop.getProperty(ChartConstants.WIDTH);
						final String str_height = prop.getProperty(ChartConstants.HEIGHT);
						final int width = str_width.equals("") ? -1 : Integer.parseInt(str_width);
						final int height = str_height.equals("") ? -1 : Integer.parseInt(str_height);
						final boolean user_defined_width = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_WIDTH));
						final boolean user_defined_height = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
						if (!user_defined_width) 
							widths.getNumbers().add(new Long(width));
						else widths.getNumbers().add(new Integer(width));
						if (!user_defined_height)
							heights.getNumbers().add(new Long(height));
						else 
							heights.getNumbers().add(new Integer(height));
						final String ds = prop.getProperty(ChartConstants.DATASOURCE);
						final String[] ds_split = ds.split(",");
						if (ds_split.length > 2)
							booleans.getNumbers().add(new Integer(-1));
						else {
							final int value = Boolean.parseBoolean(prop.getProperty(ChartConstants.ROW_ORDER)) ? 0 : 1;
							booleans.getNumbers().add(new Integer(value));
						}
					}
					result_list.add(widths);
					result_list.add(heights);
					result_list.add(booleans);
				}
			}
		} catch (Exception e) {
			return null;
		}
		return result_list;
 	}

 	//-----------------------------------------------------------------------------	
 	/** Icon storage. */
 	public static HashMap<String,ImageIcon> icons = new HashMap<String,ImageIcon>();

 	static {
 		// different icons here
 		icons.put(ChartConstants.BARCHART,createImageIcon("/icons/barchart.png"));
 		icons.put(ChartConstants.PIECHART,createImageIcon("/icons/pie.png"));
 		icons.put(ChartConstants.GRID2D,createImageIcon("/icons/grid2d.png"));
 		icons.put(ChartConstants.SHAPEGRID2D,createImageIcon("/icons/shapegrid2d.png"));
 		icons.put(ChartConstants.GRID3D, createImageIcon("/icons/grid3d.png"));
// 		icons.put(ChartConstants.COMPOSITEGRID2D,createImageIcon("/icons/compgrid2d.png"));
 		icons.put(ChartConstants.MULTIGRID2D,createImageIcon("/icons/compgrid2d.png"));
 		icons.put(ChartConstants.HISTOGRAM,createImageIcon("/icons/histogram.png"));
 		icons.put(ChartConstants.RECTANGLEAREACHART,createImageIcon("/icons/rectchart.png"));
 		icons.put(ChartConstants.TIMESERIES,createImageIcon("/icons/timeseries.png"));
 		icons.put(ChartConstants.REALTIMESERIES,createImageIcon("/icons/realtimeseries.png"));
 		icons.put(ChartConstants.XYLINECHART,createImageIcon("/icons/xylinechart.png"));
 		icons.put(ChartConstants.SCATTERPLOT,createImageIcon("/icons/scatterplot.png"));
 		icons.put(ChartConstants.NETWORK,createImageIcon("/icons/graph.gif"));
 		icons.put(ChartConstants.SUBGRAPH,createImageIcon("/icons/subgraph.gif"));
 		icons.put(ChartConstants.SEQUENCE,createImageIcon("/icons/sequence.png"));
 		icons.put("ComposeChart",createImageIcon("/icons/compose.png"));
 		icons.put(ChartConstants.BOXPLOT,createImageIcon("/icons/boxplot.png"));
 		icons.put(ChartConstants.RADVIZ,createImageIcon("/icons/radviz.png"));
 		icons.put(ChartConstants.MATRIXOFSCATTERPLOTS,createImageIcon("/icons/moscp.png"));
 		icons.put(ChartConstants.ONEDSERIES,createImageIcon("/icons/D1Series.png"));
 		icons.put(ChartConstants.MULTI_HISTOGRAM,createImageIcon("/icons/multiHistogram.png"));
 	}
 	
	//-----------------------------------------------------------------------------	
 	/** This function loads and returns an image. It looks for the image in the given
 	 *  location (<code>path</code>). If it has not found the file, it returns <code>
 	 *  null</code>.
 	 * @param path location of the image
 	 * @param description description of the image
 	 * @return ImageIcon object
 	 */ 
 	public static ImageIcon createImageIcon(final String path, final String description) {
 		final URL imgURL = Utilities.class.getResource(path);
        if (imgURL != null) 
            return new ImageIcon(imgURL,description);
        else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }
 	
 	//-----------------------------------------------------------------------------
 	/** This function loads and returns an image. It looks for the image in the given
 	 *  location (<code>path</code>). If it has not found the file, it returns <code>
 	 *  null</code>.
 	 * @param path location of the image
 	 * @return ImageIcon object
 	 */
 	public static ImageIcon createImageIcon(final String path) { return createImageIcon(path,""); }

 	
 	//-----------------------------------------------------------------------------
 	/** This function loads and returns an image specified by <code>name</code>. If
 	 *  the given name is unknown or the appropriate file is missing, it returns <code>
 	 *  null</code>. <code> name </code> can be 'RIGHT ARROW', 'CIRCLE, 'RECTANGLE' or
 	 *  'TRIANGLE'.
 	 * @param name name (not path) of the image
 	 * @return ImageIcon object
 	 */
 	public static ImageIcon getIcon(final String name) {
 		if (name.equals("RIGHT ARROW"))
 			return Utilities.createImageIcon("/icons/rightarrow.png");
 		if (name.equals("CIRCLE"))
 			return Utilities.createImageIcon("/icons/circle.png",name);
 		if (name.equals("RECTANGLE"))
 			return Utilities.createImageIcon("/icons/rectangle.png",name);
 		if (name.equals("TRIANGLE"))
 			return Utilities.createImageIcon("/icons/triangle.png",name);
 		return null;
 	}
 	
	//-----------------------------------------------------------------------------	
 	/** This function displays an illustration chart specified by the parameter.
 	 * @param config configuration object of the chart
 	 * @throws Exception if any problems occure during the displaying */
 	public static boolean displayPreview(final ChartConfig config) throws Exception {
 		final Container panel = AbstractChart.display(config);
 		final JFrame frame = new JFrame("Chart Preview");
 		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		final ImageIcon icon = createImageIcon("/icons/fables32.png");
		if (icon != null)
			frame.setIconImage(icon.getImage());
		final JScrollPane sp = new JScrollPane(panel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		sp.setBorder(null);
		frame.setContentPane(sp);
		frame.pack();
		Dimension oldD = frame.getPreferredSize();
		frame.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
			             		     		 oldD.height + sp.getHorizontalScrollBar().getHeight()));
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		oldD = frame.getPreferredSize();
		final Dimension newD = Utils.getPreferredSize(frame);
		if (!oldD.equals(newD)) 
			frame.setPreferredSize(newD);
		frame.pack();
		frame.setVisible(true);
		return true;
 	}

	//-----------------------------------------------------------------------------	
 	/** This function calls the appropriate <code>pack()</code> function on the parent
 	 *  of the parameter component <code>c</code>.
 	 * @param c a component 
 	 */
 	public static void repack(final Component c) {
 		final JRootPane root = SwingUtilities.getRootPane(c);
 		final Container p = (root == null) ? null : root.getParent();
 		if (p instanceof Window)
 			((Window)p).pack();
 		else if (p instanceof JInternalFrame)
 			((JInternalFrame)p).pack();
 	}

	//-----------------------------------------------------------------------------	
 	/** This function adapts the colormap described by <code>description</code> to the 
 	 *  <code>source</code> data source and returns the new colormap description.
 	 * @param description string description of a colormap
 	 * @param source a data source
 	 * @return description string of a new colormap
 	 */
 	@SuppressWarnings("unchecked")
 	@Deprecated
	public static String adaptColormap(final String description, final IDataSourceProducer source) {
 		try {
 			final String[] elements = description.split(",");
			if (elements[0].equals(ChartConstants.RAINBOW) ||
				elements[0].equals(ChartConstants.HEAT) ||
				elements[0].equals(ChartConstants.REAL) ||
				elements[0].equals(ChartConstants.PASTEL) ||
				elements[0].equals(ChartConstants.RANDOM) ||
				elements[0].equals(ChartConstants.BLACK_AND_WHITE_COLORMAP)) {
				//List<Double> minmax = source.getRange();
				// Begins a long operations
				try {
					final List<Double> minmax = (List<Double>) ChartConfigCollection.getLOPExecutor().execute("Adapting colormap",source,"getRange"); 
					if (minmax != null)
						return elements[0] + "," + minmax.get(0).toString() + "," + minmax.get(1).toString();
				} catch (UserBreakException e) {}
			} else if (elements[0].equals(ChartConstants.SIMPLE)) {
				//List<Double> minmax = source.getRange();
				// Begins a long operations
				try {
					final List<Double> minmax = (List<Double>) ChartConfigCollection.getLOPExecutor().execute("Adapting colormap",source,"getRange");
					if (minmax != null)
						return ChartConstants.SIMPLE + "," + minmax.get(0).toString() + "," + minmax.get(1).toString() + "," + elements[3] + "," 
							   + elements[4];
				} catch (UserBreakException e) {}
			} else { // Table Colormap
				String result = elements[0] + "," + elements[1] + ",";
				// Begins long operation
				try {
					final List<NumberStrPair> numbers = (List<NumberStrPair>) ChartConfigCollection.getLOPExecutor().execute("Adapting colormap",
											 																				 source,"getElements");
					if (numbers != null) {
						for (int i = 2;i < elements.length;++i) {
							final String[] colors = elements[i].split(":");
							boolean hit = false;
							for (final NumberStrPair item : numbers) {
								if (new Interval(colors[0]).contains(item.getNumber().doubleValue())) {
									hit = true;
									break;
								}
							}
							if (hit)
								result += elements[i] + ",";
						}
						return result.substring(0,result.length() - 1);
					}
				} catch (UserBreakException e) {}
			}
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
		return description;
 	}

	//-----------------------------------------------------------------------------	
 	/** This function adapts the shape renderer described by <code>description</code>
 	 *  to the <code>source</code> data source and returns the new shape renderer
 	 *  description.
 	 * @param description string description of a shape renderer
 	 * @param source a data source
 	 * @return description string of a new shape renderer
 	 */
 	@SuppressWarnings("unchecked")
 	@Deprecated
	public static String adaptRenderer(final String description, final IDataSourceProducer source) {
 		final String[] elements = description.split(",");
 		if (elements[0].equals("AUTO") || elements[0].equals("CUSTOM"))
 			return description;
 		// DEFINED renderer
 		String result = elements[0] + "," + elements[1] + ",";
		// Begins long operation
 		try {
 			final List<NumberStrPair> numbers = (List<NumberStrPair>)ChartConfigCollection.getLOPExecutor().execute("Adapting shape renderer",source,
 																													"getElements");
 			if (numbers != null) {
 				for (int i = 2;i < elements.length;++i) {
 					final String[] shapes = elements[i].split(";");
 					boolean hit = false;
 					for (final NumberStrPair item : numbers) {
 						if (new Interval(shapes[0]).contains(item.getNumber().doubleValue())) {
 							hit = true;
 							break;
 						}
 					}
 					if (hit) 
 						result += elements[i] + ",";
 				}
 				return result.substring(0,result.length()-1);
 			}
 		} catch (UserBreakException e) { ;
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
 		return description;
 	}
 	
 	//-------------------------------------------------------------------------------
 	/** This function returns a string that contains a rectangle in html-format. The 
 	 *  color and width of the rectangle is specfied by the parameters.
 	 * @param color color of the rectangle
 	 * @param width width of the rectangle
 	 * @return HTML code of the colorful rectangle 
 	 */
	public static String colorText(final Color color, final int width) {
		if (color == null)
			return "";
		final String color_string = String.format("#%06x",color.getRGB() & 0xffffff);
		String result ="<html><tt><font style=\"background-color:" + color_string + "\">";
		for (int i = 0;i < width;++i)
			result += "&nbsp;";
		result += "</font></tt></html>";
		return result;
	}
	
	//-------------------------------------------------------------------------------
	/** This function returns a color (a Color object) contained by a string in html
	 *  format. The string is produced by the colorText() method.
	 * @param text the text
	 * @param defaultColor default color. Returns this if text is invalid.
	 */
	public static Color toColor(final String text, final Color defaultColor) {
		if (text == null || "".equals(text)) return null;
		final int index = text.indexOf('#');
		if (index == -1)
			return defaultColor;
		final String color_text = text.substring(index,index + 7);
		return new Color(Integer.decode(color_text));
	}
	
	//-------------------------------------------------------------------------------
	/** This function adds <code>listener</code> as action listener to all JButton, 
	 *  JMenuItem, JTextField or JComboBox instances enumerated in the second, third,
	 *  etc. parameters.
	 * @param listener listener
	 * @param args the JButton, JMenuItem, JTextField, JComboBox instances
	 */
	public static void addActionListener(final ActionListener listener, final JComponent... args) {
		for (int i = 0;i < args.length;++i) {
			if (args[i] instanceof AbstractButton)
				((AbstractButton)args[i]).addActionListener(listener);
			else if (args[i] instanceof JMenuItem)
				((JMenuItem)args[i]).addActionListener(listener);
			else if (args[i] instanceof JTextField)
				((JTextField)args[i]).addActionListener(listener);
			else if (args[i] instanceof JComboBox)
				((JComboBox)args[i]).addActionListener(listener);
		}
	}
	
    //------------------------------------------------------------------------------
    // Imported from DefaultTableModel
    public static <T> void rotate(final List<T> list, final int a, final int b, final int shift) {
    	final int size = b - a; 
    	final int r = size - shift;
    	final int g = gcd(size,r); 
    	for (int i = 0;i < g;i++) {
    	    int to = i; 
    	    final T tmp = list.get(a + to);
    	    for (int from = (to + r) % size;from != i;from = (to + r) % size) {
    	    	list.set(a + to,list.get(a + from)); 
    	    	to = from; 
    	    }
    	    list.set(a + to,tmp); 
    	}
    }
    
    //----------------------------------------------------------------------------------------------------
    // Imported from DefaultTableModel
    private static int gcd(final int i, final int j) {	return (j == 0) ? i : gcd(j,i%j); }
    
    //-------------------------------------------------------------------------------
    public static Font stringToFont(final String fontDescription) {
    	if (fontDescription == null || "".equals(fontDescription)) return null;
    	final String[] parts = fontDescription.split("/");
    	final int size = Integer.parseInt(parts[1].trim());
    	int style = Font.PLAIN;
    	if (parts.length > 2) {
    		if ("bold".equals(parts[2].trim()))
    			style = Font.BOLD;
    		else if ("italic".equals(parts[2].trim()))
    			style = Font.ITALIC;
    		else if ("bold & italic".equals(parts[2].trim()))
    			style = Font.BOLD + Font.ITALIC;
    	}
    	return new Font(parts[0].trim(),style,size);
    }
    
    //--------------------------------------------------------------------------------
    public static Element cloneAndChangeOwner(final Element source, final Document newDocument) {
    	final Element result = newDocument.createElement(source.getNodeName());
    	cloneAttributes(source,result);
    	final NodeList nodes = source.getChildNodes();
    	if (nodes != null && nodes.getLength() != 0) {
    		for (int i = 0;i < nodes.getLength();++i) {
    			final Node n = nodes.item(i);
    			if (n instanceof Element) {
    				final Element element = cloneAndChangeOwner((Element) n,newDocument);
    				result.appendChild(element);
    			} else if (n instanceof Text) {
    				final Text text = newDocument.createTextNode(n.getNodeValue());
    				result.appendChild(text);
    			}
    		}
    	}
    	return result;
    }
    
    //-------------------------------------------------------------------------------
    private static void cloneAttributes(final Element source, final Element destination) {
    	if (source.hasAttributes()) {
    		final NamedNodeMap map = source.getAttributes();
    		for (int i = 0;i < map.getLength();++i) {
    			final Attr attr = (Attr) map.item(i);
    			destination.setAttribute(attr.getName(),attr.getNodeValue());
    		}
    	}
    }
    
    //----------------------------------------------------------------------------------------------------
	/**
	 * Adds <code>count</code> vertices into a graph. This is a convenience
	 * method; one might instead just call <code> g.addVertex( new SparseVertex())) </code>
	 * <code>count</code>
	 * times.
	 * <p>
	 * The input graph must be one that can accept a series of
	 * {@link edu.uci.ics.jung.graph.impl.SparseVertex directed vertices}.
	 * 
	 * @param g
	 *            A graph to add the vertices to
	 * @param count
	 *            how many vertices to add
	 * @return the list of the vertices
	 * @see edu.uci.ics.jung.graph.impl.AbstractSparseGraph#addVertex
	 */
	public static List<Vertex> addVertices(final Graph g, final int count)
	{
		final List<Vertex> result = new ArrayList<Vertex>(count);
		for (int i = 0; i < count; i++) {
			final SparseVertex sparseVertex = new SparseVertex();
			sparseVertex.addUserDatum("id",new Integer(i),UserData.SHARED);
			result.add(g.addVertex(sparseVertex));
		}
		return result;
	}
	
	//----------------------------------------------------------------------------------------------------
    /**
     * Creates a graph from a square (weighted) adjacency matrix.
     * Equivalent to <code>matrixToGraph(matrix, (NumberEdgeValue)null)</code>.
     *  
     * @return a representation of <code>matrix</code> as a JUNG <code>Graph</code>
     * 
     */
	public static Graph matrixToGraph(final DoubleMatrix2D matrix, final List<Vertex> vertices)
    {
        if (matrix.rows() != matrix.columns())
            throw new IllegalArgumentException("Matrix must be square.");
        
        final int size = matrix.rows();
        boolean isSymmetric = true;
        outer: for (int i = 0;i < size;i++) {
            for (int j = 0;j < size;j++) {
                if (matrix.getQuick(i,j) != matrix.getQuick(j,i)) {
                    isSymmetric = false;
                    break outer;
                }
            }
        }
        
        Graph graph;
        if (isSymmetric)
            graph = new UndirectedSparseGraph();
        else
            graph = new DirectedSparseGraph();
        
        final List<Vertex> vl = addVertices(graph,size);
        vertices.clear();
        vertices.addAll(vl);
        for (int i = 0;i < size;i++) {
            for (int j = 0;j < size;j++) {
            	final double value = matrix.getQuick(i,j);
                if (value != 0) {
                	final Vertex vI = vertices.get(i);
                	final Vertex vJ = vertices.get(j);
                    if (isSymmetric) {
                        if (i <= j)
                            graph.addEdge(new UndirectedSparseEdge(vI,vJ));
                    } else 
                        graph.addEdge(new DirectedSparseEdge(vI,vJ));
                }
            }
        }
        return graph;
    }
}