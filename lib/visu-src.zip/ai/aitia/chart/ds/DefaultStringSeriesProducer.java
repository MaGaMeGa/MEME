/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.ds; 

import java.util.ArrayList;
import java.util.List;

import ai.aitia.visu.ds.AbstractDataProducer;

/** Default implementation of the {@link IStringSeriesProducer IStringSeriesProducer}.
 */
public class DefaultStringSeriesProducer extends AbstractDataProducer implements
		IStringSeriesProducer {

	//===============================================================================
	// nested classes
	
	/** Nested class for numbers that owns a name. */
	public class NamedNumber {
		
		/** Number value. */
		private double value;
		
		/** Name of the number value. */
		private String name;
		
		//===========================================================================
		// methods
		
		/** Constructor.
		 * @param value number value
		 * @param name name of the number value
		 */
		public NamedNumber(double value, String name) {
			this.value = value;
			this.name = name;
		}
		
		//---------------------------------------------------------------------------
		/** Returns the name of the number.
		 * @return name of the number
		 */
		public String getName() {
			return name;
		}
		
		//---------------------------------------------------------------------------
		/** Returns the value of the number.
		 * @return value of the number
		 */
		public double getValue() {
			return value;
		}
		
		//---------------------------------------------------------------------------
		/** Returns the name of the number
		 * @return name of the number
		 */
		@Override
		public String toString() {
			return name;
		}
	}
	
	//===============================================================================
	// members
	
	/** Name of the series. */
	private String name;
	
	/** Time of the last update. */
	private long time;
	
	/** Storage for data with string type. */
	private NamedNumber[] stringData;
	
	/** Storage for data with number type. */
	private List<Double> data;
	
	/** Flag that determines whether the type of the data is string or not. */
	private boolean string_source; 
	
	//==============================================================================
	// methods
	
	/** Constructor.
	 * @param name name of the series
	 * @param series array of series elements
	 */
	public DefaultStringSeriesProducer(String name, Object[] series) {
		this(name,series,true,true/*, true, true*/);
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor.
	 * @param name name of the series
	 * @param series array of series elements
	 * @param ascendent sorting parameter, not used by current implementation
	 * @param caseSensitive sorting parameter, not used by current implementation
	 */
	public DefaultStringSeriesProducer(String name, Object[] series, boolean ascendent,
									   boolean caseSensitive/*, boolean ascii_order, boolean dictionary*/) {
		this.name = name;
		time = System.currentTimeMillis();
		if (series[0].getClass().getSuperclass().equals(Number.class)) { // number data source
			string_source = false;
			data = new ArrayList<Double>(series.length);
			for (int i=0;i<series.length;++i) {
				if (series[i] instanceof Double) data.add((Double)series[i]);
				else data.add(new Double(((Number)series[i]).doubleValue()));
			}
		} else { // string data source
			string_source = true;
			stringData = new NamedNumber[series.length];
			Object[] temp = new Object[series.length];
			for (int i=0;i<series.length;++i) temp[i] = series[i];
			//TODO: kell egy Comparator, azzal rendezni series m�solat�t (a param�terek figyelembev�tel�vel)
			for (int i=0;i<temp.length;++i) stringData[i] = new NamedNumber(i,temp[i].toString());
		}
		
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the name of the <code>number</code> (not certainly the string representation).
	 * @param number a number
	 * @return name of the number
	 */
	public String getNumberName(double number) {
		if (string_source) {
			for (int i=0;i<stringData.length;++i) {
				if (stringData[i].getValue() == number) return stringData[i].getName();
			}
			return null;
		}
		return String.valueOf(number);
	}

	//-------------------------------------------------------------------------------
	/** Produces an array that contains the values. */
	public List<Double> produceSeries() {
		if (string_source) {
			List<Double> temp = new ArrayList<Double>(stringData.length);
			for (int i=0;i<stringData.length;++i) {
				//temp.add(new Double(sringData[i].getValue()));
				temp.add(new Double(i));
			}
			return temp;
		}
		return data;
	}

	//-------------------------------------------------------------------------------
	/** Returns the name of the data source.
	 * @return name of the data source
	 */
	public String getName() {
		return name;
	}

	//-------------------------------------------------------------------------------
	/** Returns the time of the last update.
	 * @return time of the last update
	 */
	public long getTime() {
		return time;
	}
}
