/** Test package. */
package ai.aitia.chart.test;