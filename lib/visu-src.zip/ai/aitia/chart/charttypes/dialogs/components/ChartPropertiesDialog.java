package ai.aitia.chart.charttypes.dialogs.components;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.title.TextTitle;
import org.jfree.ui.ExtensionFileFilter;
import org.jfree.ui.FontChooserPanel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLLoadingException.TemplateLoadingException;
import ai.aitia.meme.utils.FormsUtils;
import ai.aitia.meme.utils.FormsUtils.Separator;
import ai.aitia.visu.globalhandlers.GlobalHandlers;
import ai.aitia.visu.utils.Utils;
import ai.aitia.visu.view.plot.ChartDrawingSupplier;
import ai.aitia.visu.view.ui.UnfilledShape;

public class ChartPropertiesDialog extends JDialog implements ActionListener,
															  ChangeListener {


	//=======================================================================================
	// members
	
	private static final String TEMPLATE_NAME = 				"TEMPLATE_NAME";
	private static final String TEMPLATE_WIDTH =				"TEMPLATE_WIDTH";
	private static final String TEMPLATE_HEIGHT =				"TEMPLATE_HEIGHT";
	private static final String RANGE_AXIS_AUTO_ADJUST_RANGE = 	"RANGE_AXIS_AUTO_ADJUST_RANGE";
	private static final String SELECT_RANGE_AXIS_TICK_FONT = 	"SELECT_RANGE_AXIS_TICK_FONT";
	private static final String SHOW_RANGE_AXIS_TICK_LABELS = 	"SHOW_RANGE_AXIS_TICK_LABELS";
	private static final String SELECT_RANGE_AXIS_COLOR = 		"SELECT_RANGE_AXIS_COLOR";
	private static final String SELECT_RANGE_AXIS_FONT = 		"SELECT_RANGE_AXIS_FONT";
	private static final String DOMAIN_AXIS_AUTO_ADJUST_RANGE = "DOMAIN_AXIS_AUTO_ADJUST_RANGE";
	private static final String SELECT_DOMAIN_AXIS_TICK_FONT = 	"SELECT_DOMAIN_AXIS_TICK_FONT";
	private static final String SHOW_DOMAIN_AXIS_TICK_LABELS = 	"SHOW_DOMAIN_AXIS_TICK_LABELS";
	private static final String SELECT_DOMAIN_AXIS_COLOR = 		"SELECT_DOMAIN_AXIS_COLOR";
	private static final String SELECT_DOMAIN_AXIS_FONT = 		"SELECT_DOMAIN_AXIS_FONT";
	private static final String SELECT_BACKGROUND_COLOR_2 = 	"SELECT_BACKGROUND_COLOR_2";
	private static final String SELECT_BACKGROUND_COLOR_1 = 	"SELECT_BACKGROUND_COLOR_1";
	private static final String GRADIENT_BACKGROUND = 			"GRADIENT_BACKGROUND";
	private static final String SIMPLE_BACKGROUND = 			"SIMPLE_BACKGROUND";
	private static final String SELECT_SUBTITLE_COLOR = 		"SELECT_SUBTITLE_COLOR";
	private static final String SELECT_SUBTITLE_FONT = 			"SELECT_SUBTITLE_FONT";
	private static final String SHOW_SUBTITLE = 				"SHOW_SUBTITLE";
	private static final String SELECT_TITLE_COLOR = 			"SELECT_TITLE_COLOR";
	private static final String SELECT_TITLE_FONT = 			"SELECT_TITLE_FONT";
	private static final String SHOW_TITLE = 					"SHOW_TITLE";
	private static final String CANCEL = 						"CANCEL";
	private static final String OK = 							"OK";
	private static final String MOVE_DOWN = 					"MOVE_DOWN";
	private static final String MOVE_UP = 						"MOVE_UP";
	private static final String REMOVE =						"REMOVE";
	private static final String DOMAIN_AXIS_MIN_FIELD =			"DOMAIN_AXIS_MIN_FIELD";
	private static final String DOMAIN_AXIS_MAX_FIELD =			"DOMAIN_AXIS_MAX_FIELD";
	private static final String RANGE_AXIS_MIN_FIELD =			"RANGE_AXIS_MIN_FIELD";
	private static final String RANGE_AXIS_MAX_FIELD =			"RANGE_AXIS_MAX_FIELD";
	
	private static final long serialVersionUID = 1L;
	/** Return value constant: indicates that the user closes the dialog by pressing Cancel button (or 'x' in the right top corner). */
	public static final int CANCEL_OPTION = -1;
	/** Return value constant: indicates that the user closes the dialog by pressing OK button. */
	public static final int OK_OPTION = 0;
	
	private static double sizePercentage = 100;
	
	private static List<String> RESERVED_TEMPLATE_NAMES = new ArrayList<String>(11);
	static {
		RESERVED_TEMPLATE_NAMES.add("Normal, colored");
		RESERVED_TEMPLATE_NAMES.add("Normal, black-and-white");
		RESERVED_TEMPLATE_NAMES.add("Basic, colored");
		RESERVED_TEMPLATE_NAMES.add("Basic, black-and-white");
		RESERVED_TEMPLATE_NAMES.add("Normal");
		RESERVED_TEMPLATE_NAMES.add("Basic");
		RESERVED_TEMPLATE_NAMES.add("Colored");
		RESERVED_TEMPLATE_NAMES.add("Black-and-white");

		RESERVED_TEMPLATE_NAMES.add("New template...");
		RESERVED_TEMPLATE_NAMES.add("Edit template...");
		RESERVED_TEMPLATE_NAMES.add("Remove template...");
	}
		
	
	public static Shape[] PREDEFINED_SHAPES = createStandardSeriesShapes();
	
	public static List<float[]> PREDEFINED_STYLES = new ArrayList<float[]>(10);
	static {
		PREDEFINED_STYLES.add(null);
		PREDEFINED_STYLES.add(new float[] { 2.f, 2.f });
		PREDEFINED_STYLES.add(new float[] { 8.f, 2.f });
		PREDEFINED_STYLES.add(new float[] { 5.f, 5.f });
		PREDEFINED_STYLES.add(new float[] { 8.f, 2.f, 2.f, 2.f });
		PREDEFINED_STYLES.add(new float[] { 8.f, 2.f, 2.f, 2.f, 2.f, 2.f });
		PREDEFINED_STYLES.add(new float[] { 8.f, 6.f });
		PREDEFINED_STYLES.add(new float[] { 12.f, 6.f });
		PREDEFINED_STYLES.add(new float[] { 16.f, 8.f });
		PREDEFINED_STYLES.add(new float[] { 20.f, 10.f });
	}
	
	/** The return value of the dialog. */
	private int returnValue = CANCEL_OPTION;
	
	private Set<String> knownTemplates = null;
	private Node template = null;
	private ChartKind kind = null;
	
	//=======================================================================================
	// GUI members
	
	private JTextField widthField = new JTextField();
	private JTextField heightField = new JTextField();
	private JPanel dimensionPanel = null;
	
	private JCheckBox showTitleBox = new JCheckBox("Show title");
	private JLabel _titleFontLabel = new JLabel(" Title font:  ");
	private JTextField titleFontField = new JTextField(30);
	private JButton titleFontSelectButton = new JButton("Select...");
	private JLabel _titleColorLabel = new JLabel(" Title color:  ");
	private JTextField titleColorField = new JTextField(30);
	private JButton titleColorSelectButton = new JButton("Select...");
	private JPanel titlePanel = null;
	
	private JCheckBox showSubtitleBox = new JCheckBox("Show subtitle");
	private JLabel _subtitleFontLabel = new JLabel(" Subtitle font:  ");
	private JTextField subtitleFontField = new JTextField(30);
	private JButton subtitleFontSelectButton = new JButton("Select...");
	private JLabel _subtitleColorLabel = new JLabel(" Subtitle color:  ");
	private JTextField subtitleColorField = new JTextField(30);
	private JButton subtitleColorSelectButton = new JButton("Select...");
	private JPanel subtitlePanel = null;
	
	private JRadioButton simpleBackgroundButton = new JRadioButton("Simple background");
	private JRadioButton gradientBackgroundButton = new JRadioButton("Gradient background");
	private JTextField backgroundColor1Field = new JTextField(30);
	private JButton backgroundColor1SelectButton = new JButton("Select...");
	private JLabel _backgroundColor2Label = new JLabel("  Second color:   ");
	private JTextField backgroundColor2Field = new JTextField(30);
	private JButton backgroundColor2SelectButton = new JButton("Select...");
	private JPanel backgroundPanel = null;
	
	private JPanel generalPanel = new JPanel();
	
	private JTextField domainAxisFontField = new JTextField(30);
	private JButton domainAxisFontSelectButton = new JButton("Select...");
	private JTextField domainAxisColorField = new JTextField(30);
	private JButton domainAxisColorSelectButton = new JButton("Select...");
	private JCheckBox domainAxisShowTickLabelBox = new JCheckBox("Show tick labels");
	private JCheckBox domainAxisShowTickMarkBox = new JCheckBox("Show tick marks");
	private JLabel _domainAxisTickFontLabel = new JLabel("  Tick label font:  ");
	private JTextField domainAxisTickFontField = new JTextField(30);
	private JButton domainAxisTickFontSelection = new JButton("Select...");
	private JPanel domainAxisRangePanel = null;
	private JCheckBox domainAxisAutoAdjustRangeBox = new JCheckBox("Auto-adjust range");
	private JLabel _domainAxisMinLabel = new JLabel("  Minimum range value: ");
	private JTextField domainAxisMinRange = new JTextField();
	private JLabel _domainAxisMaxLabel = new JLabel(" Maximum range value: ");
	private JTextField domainAxisMaxRange = new JTextField();
	private JPanel domainAxisPanel = null;
	
	private JTextField rangeAxisFontField = new JTextField(30);
	private JButton rangeAxisFontSelectButton = new JButton("Select...");
	private JTextField rangeAxisColorField = new JTextField(30);
	private JButton rangeAxisColorSelectButton = new JButton("Select...");
	private JCheckBox rangeAxisShowTickLabelBox = new JCheckBox("Show tick labels");
	private JCheckBox rangeAxisShowTickMarkBox = new JCheckBox("Show tick marks");
	private JLabel _rangeAxisTickFontLabel = new JLabel("  Tick label font:  ");
	private JTextField rangeAxisTickFontField = new JTextField(30);
	private JButton rangeAxisTickFontSelection = new JButton("Select...");
	private JPanel rangeAxisRangePanel = null;
	private JCheckBox rangeAxisAutoAdjustRangeBox = new JCheckBox("Auto-adjust range");
	private JLabel _rangeAxisMinLabel = new JLabel("  Minimum range value: ");
	private JTextField rangeAxisMinRange = new JTextField();
	private JLabel _rangeAxisMaxLabel = new JLabel(" Maximum range value: ");
	private JTextField rangeAxisMaxRange = new JTextField();
	private JPanel rangeAxisPanel = null;
	
	private JPanel axisPanel = new JPanel();
	
	private JTable seriesTable = new JTable() {
		private static final long serialVersionUID = 1L;
		{
			tableHeader.setReorderingAllowed(false);
		}
	};
	private JScrollPane seriesTableScr = new JScrollPane(seriesTable);
	private JButton moveDownButton = new JButton("Move down");
	private JButton moveUpButton = new JButton("Move up");
	private JButton removeButton = new JButton("Remove");
	private JColorChooser colorChooser = new JColorChooser();
	private JPanel seriesPanel = null;
	
	private JTextField templateName = new JTextField(); 
	private JTabbedPane tabbed = new JTabbedPane();
	private JButton okButton = new JButton("Ok");
	private JButton cancelButton = new JButton("Cancel");
	private JPanel content = null;
	private JLabel shapeSizeLabel = null;
	private JLabel percentageLabel = null;
	private JPanel shapeSizePanel = null;
	private JTextField shapeSizeField = null;
	
	//=======================================================================================
	// methods
	
	//---------------------------------------------------------------------------------------
	public ChartPropertiesDialog(Frame owner, Set<String> knownTemplates, Node template, List<String> legends, ChartKind kind) {
		super(owner,"Appearance Template Builder",true);
		this.knownTemplates = knownTemplates;
		this.kind = kind;
		layoutGUI();
		initialize();
		try {
			setSettingsFromConfig(template,legends);
		} catch (TemplateLoadingException e) {
			JOptionPane.showMessageDialog(owner,"Unable to load the selected template: " + e.getLocalizedMessage(),"Error",JOptionPane.ERROR_MESSAGE,null);
			try { setSettingsFromConfig(null,legends); } catch (TemplateLoadingException e1) {}
		} 
		this.setLocationRelativeTo(owner);
	}
	
	//---------------------------------------------------------------------------------------
	/** Shows the dialog.
	 * @return an int that indicates the closing mode of the dialog
	 */
	public int showDialog() {
		setVisible(true);
		int result = returnValue;
		dispose();
		return result;
	}
	
	//---------------------------------------------------------------------------------------
	public Node getTemplate() { return template; }
	
	//=======================================================================================
	// implemented interfaces

	//---------------------------------------------------------------------------------------
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if (TEMPLATE_NAME.equals(cmd)) {
			switch (tabbed.getSelectedIndex()) {
			case 0 : widthField.grabFocus(); break;
			case 1 : domainAxisFontSelectButton.grabFocus(); break;
			case 2 : moveDownButton.grabFocus(); break;
			}
		} else if (TEMPLATE_WIDTH.equals(cmd))
			heightField.grabFocus();
		else if (TEMPLATE_HEIGHT.equals(cmd))
			showTitleBox.grabFocus();
		else if (SHOW_TITLE.equals(cmd)) {
			_titleFontLabel.setEnabled(showTitleBox.isSelected());
			titleFontField.setEnabled(showTitleBox.isSelected());
			titleFontSelectButton.setEnabled(showTitleBox.isSelected());
			_titleColorLabel.setEnabled(showTitleBox.isSelected());
			titleColorField.setEnabled(showTitleBox.isSelected());
			titleColorSelectButton.setEnabled(showTitleBox.isSelected());
		} else if (SELECT_TITLE_FONT.equals(cmd))
			handleFontSelection(titleFontField);
		else if (SELECT_TITLE_COLOR.equals(cmd))
			handleColorSelection(titleColorField);
		else if (SHOW_SUBTITLE.equals(cmd)) {
			_subtitleFontLabel.setEnabled(showSubtitleBox.isSelected());
			subtitleFontField.setEnabled(showSubtitleBox.isSelected());
			subtitleFontSelectButton.setEnabled(showSubtitleBox.isSelected());
			_subtitleColorLabel.setEnabled(showSubtitleBox.isSelected());
			subtitleColorField.setEnabled(showSubtitleBox.isSelected());
			subtitleColorSelectButton.setEnabled(showSubtitleBox.isSelected());
		} else if (SELECT_SUBTITLE_FONT.equals(cmd))
			handleFontSelection(subtitleFontField);
		else if (SELECT_SUBTITLE_COLOR.equals(cmd))
			handleColorSelection(subtitleColorField);
		else if (SIMPLE_BACKGROUND.equals(cmd) || GRADIENT_BACKGROUND.equals(cmd)) {
			_backgroundColor2Label.setEnabled(gradientBackgroundButton.isSelected());
			backgroundColor2Field.setEnabled(gradientBackgroundButton.isSelected());
			backgroundColor2SelectButton.setEnabled(gradientBackgroundButton.isSelected());
		} else if (SELECT_BACKGROUND_COLOR_1.equals(cmd)) 
			handleColorSelection(backgroundColor1Field);
		else if (SELECT_BACKGROUND_COLOR_2.equals(cmd))
			handleColorSelection(backgroundColor2Field);
		else if (SELECT_DOMAIN_AXIS_FONT.equals(cmd))
			handleFontSelection(domainAxisFontField);
		else if (SELECT_DOMAIN_AXIS_COLOR.equals(cmd))
			handleColorSelection(domainAxisColorField);
		else if (SHOW_DOMAIN_AXIS_TICK_LABELS.equals(cmd)) {
			_domainAxisTickFontLabel.setEnabled(domainAxisShowTickLabelBox.isSelected());
			domainAxisTickFontField.setEnabled(domainAxisShowTickLabelBox.isSelected());
			domainAxisTickFontSelection.setEnabled(domainAxisShowTickLabelBox.isSelected());
		} else if (SELECT_DOMAIN_AXIS_TICK_FONT.equals(cmd))
			handleFontSelection(domainAxisTickFontField);
		else if (DOMAIN_AXIS_AUTO_ADJUST_RANGE.equals(cmd)) {
			_domainAxisMinLabel.setEnabled(!domainAxisAutoAdjustRangeBox.isSelected());
			domainAxisMinRange.setEnabled(!domainAxisAutoAdjustRangeBox.isSelected());
			_domainAxisMaxLabel.setEnabled(!domainAxisAutoAdjustRangeBox.isSelected());
			domainAxisMaxRange.setEnabled(!domainAxisAutoAdjustRangeBox.isSelected());
		} else if (DOMAIN_AXIS_MIN_FIELD.equals(cmd))
			domainAxisMaxRange.grabFocus();
		else if (DOMAIN_AXIS_MAX_FIELD.equals(cmd))
			rangeAxisFontSelectButton.grabFocus();
		else if (SELECT_RANGE_AXIS_FONT.equals(cmd))
			handleFontSelection(rangeAxisFontField);
		else if (SELECT_RANGE_AXIS_COLOR.equals(cmd))
			handleColorSelection(rangeAxisColorField);
		else if (SHOW_RANGE_AXIS_TICK_LABELS.equals(cmd)) {
			_rangeAxisTickFontLabel.setEnabled(rangeAxisShowTickLabelBox.isSelected());
			rangeAxisTickFontField.setEnabled(rangeAxisShowTickLabelBox.isSelected());
			rangeAxisTickFontSelection.setEnabled(rangeAxisShowTickLabelBox.isSelected());
		} else if (SELECT_RANGE_AXIS_TICK_FONT.equals(cmd))
			handleFontSelection(rangeAxisTickFontField);
		else if (RANGE_AXIS_AUTO_ADJUST_RANGE.equals(cmd)) {
			_rangeAxisMinLabel.setEnabled(!rangeAxisAutoAdjustRangeBox.isSelected());
			rangeAxisMinRange.setEnabled(!rangeAxisAutoAdjustRangeBox.isSelected());
			_rangeAxisMaxLabel.setEnabled(!rangeAxisAutoAdjustRangeBox.isSelected());
			rangeAxisMaxRange.setEnabled(!rangeAxisAutoAdjustRangeBox.isSelected());
		} else if (RANGE_AXIS_MIN_FIELD.equals(cmd))
			rangeAxisMaxRange.grabFocus();
		else if (RANGE_AXIS_MAX_FIELD.equals(cmd)) 
			(okButton.isEnabled() ? okButton : cancelButton).grabFocus();
		else if (MOVE_UP.equals(cmd)) 
			move(-1);
		else if (MOVE_DOWN.equals(cmd)) 
			move(1);
		else if (REMOVE.equals(cmd)) {
			SeriesTableModel tmodel = (SeriesTableModel) seriesTable.getModel();
			seriesTable.getSelectionModel().removeSelectionInterval(tmodel.getRowCount()-1,tmodel.getRowCount()-1);
			int[] selected = seriesTable.getSelectedRows();
			if (selected.length == 0) return;
			String msg[] = new String[2];
			if (selected.length == 1) 
				msg[0] = String.format("The following entry will be deleted: #%s", tmodel.getValueAt(selected[0],0).toString());
			else 
				msg[0] = String.format("The selected entries (%d) will be deleted.",selected.length);
			msg[1] = "Are you sure?";
			boolean ok = JOptionPane.showConfirmDialog(this, msg, "Warning", 
													   JOptionPane.YES_NO_OPTION,
													   JOptionPane.WARNING_MESSAGE
													   ) == JOptionPane.YES_OPTION;
			if (ok) {
				int originalSelectedLength = selected.length;
				while (selected.length != 0) {
					tmodel.removeRow(selected[0]);
					selected = seriesTable.getSelectedRows();
				}
				tmodel.removeBlankLines(originalSelectedLength);
			}
		} 
		else if (CANCEL.equals(cmd)) {
			returnValue = CANCEL_OPTION;
			setVisible(false);
		} else if (OK.equals(cmd)) {
			String error = checkInput();
			if (error != null) {
				if ("".equals(error)) return; // No answer to the confirmation question
				JOptionPane.showMessageDialog(this,error,"Warning",JOptionPane.WARNING_MESSAGE,null);
			} else {
				if (saveTemplate()) {
					returnValue = OK_OPTION;
					setVisible(false);
				}
			}
		}
	}
	
	//-------------------------------------------------------------------------------------
	public void stateChanged(ChangeEvent e) {
		Color newColor = colorChooser.getColor();
		int[] indices = seriesTable.getSelectedRows();
		if (indices.length != 0) {
			for (int i=0;i<indices.length;++i) 
				seriesTable.getModel().setValueAt(newColor,indices[i],2);
		}
	}
	
	//=======================================================================================
	// GUI methods
	
	//---------------------------------------------------------------------------------------
	private void layoutGUI() {
		dimensionPanel = FormsUtils.build("p ~ p:g ~ p ~ p:g",
										  "0123|",
										  "  Width:  ",widthField,"  Height:  ",heightField).getPanel();
		dimensionPanel.setBorder(BorderFactory.createTitledBorder("Dimension"));
		
		titlePanel = FormsUtils.build("p ~ p:g ~ p",
									  "000||" +
									  "123||" +
									  "456|",
									  showTitleBox,
									  _titleFontLabel,titleFontField,titleFontSelectButton,
									  _titleColorLabel,titleColorField,titleColorSelectButton).getPanel();
		
		titlePanel.setBorder(BorderFactory.createTitledBorder("Title"));
		
		subtitlePanel = FormsUtils.build("p ~ p:g ~ p",
										 "000||" +
										 "123||" +
										 "456|",
										 showSubtitleBox,
										 _subtitleFontLabel,subtitleFontField,subtitleFontSelectButton,
										 _subtitleColorLabel,subtitleColorField,subtitleColorSelectButton).getPanel();
		
		subtitlePanel.setBorder(BorderFactory.createTitledBorder("Subtitle"));
		
		backgroundPanel = FormsUtils.build("p ~ p ~ p ~ p:g ~ p",
										   "_01__||" +
										   "23334||" +
										   "56667|",
										   simpleBackgroundButton,gradientBackgroundButton,
										   "  (First) Color:  ",backgroundColor1Field,backgroundColor1SelectButton,
										   _backgroundColor2Label,backgroundColor2Field,backgroundColor2SelectButton).getPanel();
		backgroundPanel.setBorder(BorderFactory.createTitledBorder("Background"));
		
		generalPanel.setLayout(new BoxLayout(generalPanel,BoxLayout.Y_AXIS));
		generalPanel.add(dimensionPanel);
		generalPanel.add(titlePanel);
		generalPanel.add(subtitlePanel);
		generalPanel.add(backgroundPanel);
		
		domainAxisRangePanel = FormsUtils.build("p ~ p:g ~ p ~ p:g",
												"0000||" +
												"1___||" +
												"2345|",
												new Separator("Range"),
												domainAxisAutoAdjustRangeBox,
												_domainAxisMinLabel,domainAxisMinRange,_domainAxisMaxLabel,domainAxisMaxRange).getPanel();

		domainAxisPanel = FormsUtils.build("p ~ p:g ~ p",
										   "|012||" +
										    "345||" +
										    "666||" +
										    "789||" +
										    "AAA||" +
										    "BBB|",
										    "  Font:  ",domainAxisFontField,domainAxisFontSelectButton,
										    "  Color:  ",domainAxisColorField,domainAxisColorSelectButton,
										    domainAxisShowTickLabelBox,
										    _domainAxisTickFontLabel,domainAxisTickFontField,domainAxisTickFontSelection,
										    domainAxisShowTickMarkBox,
										    domainAxisRangePanel).getPanel();
		
		domainAxisPanel.setBorder(BorderFactory.createTitledBorder("Domain Axis"));
		
		rangeAxisRangePanel = FormsUtils.build("p ~ p:g ~ p ~ p:g",
											   "0000||" +
											   "1___||" +
											   "2345|",
											   new Separator("Range"),
											   rangeAxisAutoAdjustRangeBox,
											   _rangeAxisMinLabel,rangeAxisMinRange,_rangeAxisMaxLabel,rangeAxisMaxRange).getPanel();

		rangeAxisPanel = FormsUtils.build("p ~ p:g ~ p",
										  "|012||" +
										   "345||" +
										   "666||" +
										   "789||" +
										   "AAA||" +
										   "BBB|",
										   "  Font:  ",rangeAxisFontField,rangeAxisFontSelectButton,
										   "  Color:  ",rangeAxisColorField,rangeAxisColorSelectButton,
										   rangeAxisShowTickLabelBox,
										   _rangeAxisTickFontLabel,rangeAxisTickFontField,rangeAxisTickFontSelection,
										   rangeAxisShowTickMarkBox,
										   rangeAxisRangePanel).getPanel();

		rangeAxisPanel.setBorder(BorderFactory.createTitledBorder("Range Axis"));
		
		axisPanel.setLayout(new BoxLayout(axisPanel,BoxLayout.Y_AXIS));
		axisPanel.add(domainAxisPanel);
		axisPanel.add(rangeAxisPanel);
		
		shapeSizePanel = getShapeSizePanel();//new JPanel();

		seriesPanel = FormsUtils.build("p:g ~ p ~ p ~ p ~ p:g ~ p:g",
									   "000001 f:p:g||" +
									   "_234_1 p|"+
									   "_5 p|",
									   seriesTableScr,colorChooser,
									   moveDownButton,moveUpButton,removeButton,//).getPanel();
									   shapeSizePanel).getPanel();
		tabbed.addTab("General",generalPanel);
		tabbed.addTab("Axis",axisPanel);
		tabbed.addTab("Series",seriesPanel);
		
		JPanel buttons = FormsUtils.build("p:g p ~ p ~ p:g",
										  "_01_",
										  okButton,cancelButton).getPanel();
		
		content = FormsUtils.build("p ~ p:g",
								   "[DialogBorder]01||" +
								                 "22 f:p:g||" +
								                 "33 p||" +
								                 "44",
								                 "Template name:  ",templateName,
								                 tabbed,
								                 new JSeparator(),
								                 buttons).getPanel();
		
		this.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				returnValue = CANCEL_OPTION;
			}
		});
		
		final JScrollPane sp = new JScrollPane(content,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		sp.setBorder(null);
		this.setContentPane(sp);
		this.pack();
		Dimension oldD = this.getPreferredSize();
		this.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
										    oldD.height + sp.getHorizontalScrollBar().getHeight()));
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		oldD = this.getPreferredSize();
		final Dimension newD = Utils.getPreferredSize(this);
		if (!oldD.equals(newD)) 
			this.setPreferredSize(newD);
		this.pack();
//		this.setResizable(false); // ez mi�rt kellett?
	}
	
	//---------------------------------------------------------------------------------------
	private void initialize() {
		templateName.setActionCommand(TEMPLATE_NAME);
		okButton.setActionCommand(OK);
		cancelButton.setActionCommand(CANCEL);
		
		widthField.setActionCommand(TEMPLATE_WIDTH);
		heightField.setActionCommand(TEMPLATE_HEIGHT);
		
		showTitleBox.setActionCommand(SHOW_TITLE);
		titleFontField.setEditable(false);
		titleFontSelectButton.setActionCommand(SELECT_TITLE_FONT);
		titleColorField.setEditable(false);
		titleColorSelectButton.setActionCommand(SELECT_TITLE_COLOR);
		
		showSubtitleBox.setActionCommand(SHOW_SUBTITLE);
		subtitleFontField.setEditable(false);
		subtitleFontSelectButton.setActionCommand(SELECT_SUBTITLE_FONT);
		subtitleColorField.setEditable(false);
		subtitleColorSelectButton.setActionCommand(SELECT_SUBTITLE_COLOR);
		
		simpleBackgroundButton.setActionCommand(SIMPLE_BACKGROUND);
		gradientBackgroundButton.setActionCommand(GRADIENT_BACKGROUND);
		ButtonGroup grp = new ButtonGroup();
		grp.add(simpleBackgroundButton);
		grp.add(gradientBackgroundButton);
		backgroundColor1Field.setEditable(false);
		backgroundColor1SelectButton.setActionCommand(SELECT_BACKGROUND_COLOR_1);
		backgroundColor2Field.setEditable(false);
		backgroundColor2SelectButton.setActionCommand(SELECT_BACKGROUND_COLOR_2);
		
		domainAxisFontField.setEditable(false);
		domainAxisFontSelectButton.setActionCommand(SELECT_DOMAIN_AXIS_FONT);
		domainAxisColorField.setEditable(false);
		domainAxisColorSelectButton.setActionCommand(SELECT_DOMAIN_AXIS_COLOR);
		domainAxisShowTickLabelBox.setActionCommand(SHOW_DOMAIN_AXIS_TICK_LABELS);
		domainAxisTickFontField.setEditable(false);
		domainAxisTickFontSelection.setActionCommand(SELECT_DOMAIN_AXIS_TICK_FONT);
		domainAxisAutoAdjustRangeBox.setActionCommand(DOMAIN_AXIS_AUTO_ADJUST_RANGE);
		domainAxisMinRange.setHorizontalAlignment(JTextField.RIGHT);
		domainAxisMinRange.setActionCommand(DOMAIN_AXIS_MIN_FIELD);
		domainAxisMaxRange.setHorizontalAlignment(JTextField.RIGHT);
		domainAxisMaxRange.setActionCommand(DOMAIN_AXIS_MAX_FIELD);
		
		rangeAxisFontField.setEditable(false);
		rangeAxisFontSelectButton.setActionCommand(SELECT_RANGE_AXIS_FONT);
		rangeAxisColorField.setEditable(false);
		rangeAxisColorSelectButton.setActionCommand(SELECT_RANGE_AXIS_COLOR);
		rangeAxisShowTickLabelBox.setActionCommand(SHOW_RANGE_AXIS_TICK_LABELS);
		rangeAxisTickFontField.setEditable(false);
		rangeAxisTickFontSelection.setActionCommand(SELECT_RANGE_AXIS_TICK_FONT);
		rangeAxisAutoAdjustRangeBox.setActionCommand(RANGE_AXIS_AUTO_ADJUST_RANGE);
		rangeAxisMinRange.setHorizontalAlignment(JTextField.RIGHT);
		rangeAxisMinRange.setActionCommand(RANGE_AXIS_MIN_FIELD);
		rangeAxisMaxRange.setHorizontalAlignment(JTextField.RIGHT);
		rangeAxisMaxRange.setActionCommand(RANGE_AXIS_MAX_FIELD);

		seriesTable.getSelectionModel().setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		colorChooser.getSelectionModel().addChangeListener(this);
		moveDownButton.setActionCommand(MOVE_DOWN);
		moveUpButton.setActionCommand(MOVE_UP);
		removeButton.setActionCommand(REMOVE);

		Utilities.addActionListener(this,okButton,cancelButton,showTitleBox,titleFontSelectButton,titleColorSelectButton,
				showSubtitleBox,subtitleFontSelectButton,subtitleColorSelectButton,
				domainAxisFontSelectButton,domainAxisColorSelectButton,domainAxisShowTickLabelBox,domainAxisTickFontSelection,
				domainAxisAutoAdjustRangeBox,rangeAxisFontSelectButton,rangeAxisColorSelectButton,rangeAxisShowTickLabelBox,
				rangeAxisTickFontSelection,rangeAxisAutoAdjustRangeBox,simpleBackgroundButton,
				gradientBackgroundButton,backgroundColor1SelectButton,backgroundColor2SelectButton,
				templateName,moveDownButton,moveUpButton,removeButton,domainAxisMinRange,domainAxisMaxRange,
				rangeAxisMinRange,rangeAxisMaxRange,widthField,heightField,shapeSizeField);
	}
	
	//--------------------------------------------------------------------------------------
	private void setSettingsFromConfig(Node node, List<String> legends) throws TemplateLoadingException {
		if (node == null) {
			widthField.setText(String.valueOf(kind.default_width()));
			heightField.setText(String.valueOf(kind.default_height()));
			showTitleBox.setSelected(true);
			titleFontField.setText(fontToString(JFreeChart.DEFAULT_TITLE_FONT));
			titleColorField.setBackground(Color.BLACK);
			showSubtitleBox.setSelected(true);
			subtitleFontField.setText(fontToString(TextTitle.DEFAULT_FONT));
			subtitleColorField.setBackground(Color.BLACK);
			gradientBackgroundButton.setSelected(true);
			backgroundColor1Field.setBackground(Color.WHITE);
			backgroundColor2Field.setBackground(Color.BLACK);
			domainAxisFontField.setText(fontToString(Axis.DEFAULT_AXIS_LABEL_FONT));
			domainAxisColorField.setBackground(Color.BLACK);
			domainAxisShowTickLabelBox.setSelected(true);
			domainAxisTickFontField.setText(fontToString(Axis.DEFAULT_TICK_LABEL_FONT));
			domainAxisShowTickMarkBox.setSelected(true);
			domainAxisAutoAdjustRangeBox.doClick();
			rangeAxisFontField.setText(fontToString(Axis.DEFAULT_AXIS_LABEL_FONT));
			rangeAxisColorField.setBackground(Color.BLACK);
			rangeAxisShowTickLabelBox.setSelected(true);
			rangeAxisTickFontField.setText(fontToString(Axis.DEFAULT_TICK_LABEL_FONT));
			rangeAxisShowTickMarkBox.setSelected(true);
			rangeAxisAutoAdjustRangeBox.doClick();
			shapeSizeField.setText("100");
			initializeTable(null,legends);
		} else {
			Element templateElement = (Element) node;
			String name = templateElement.getAttribute(ChartConstants.REF_ID_ATTR);
			if (null == name || "".equals(name))
				throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.REF_ID_ATTR + "' is missing or empty.");
			templateName.setText(name);
			
			// GENERAL
			NodeList nodes = templateElement.getElementsByTagName(ChartConstants.DIMENSION);
			if (nodes == null || nodes.getLength() == 0) {
				widthField.setText(String.valueOf(kind.default_width()));
				heightField.setText(String.valueOf(kind.default_height()));
			} else {
				Element dimensionElement = (Element) nodes.item(0);
				nodes = dimensionElement.getElementsByTagName(ChartConstants.TEMPLATE_WIDTH);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TEMPLATE_WIDTH + "' tag.");
				Element widthElement = (Element) nodes.item(0);
				Text text = (Text) widthElement.getChildNodes().item(0);
				widthField.setText(text.getNodeValue().trim());
				nodes = dimensionElement.getElementsByTagName(ChartConstants.TEMPLATE_HEIGHT);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TEMPLATE_HEIGHT + "' tag.");
				Element heightElement = (Element) nodes.item(0);
				text = (Text) heightElement.getChildNodes().item(0);
				heightField.setText(text.getNodeValue().trim());
			}
			
			nodes = templateElement.getElementsByTagName(ChartConstants.TEMPLATE_TITLE);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TEMPLATE_TITLE + "' tag.");
			Element titleElement = (Element) nodes.item(0);
			String tmp = titleElement.getAttribute(ChartConstants.SHOW_ATTR);
			if (null == tmp || "".equals(tmp))
				throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
			boolean	bool = Boolean.parseBoolean(tmp);
			showTitleBox.setSelected(true);
			if (bool) {
				nodes = titleElement.getElementsByTagName(ChartConstants.FONT);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
				Element fontElement = (Element) nodes.item(0);
				Text text = (Text) fontElement.getChildNodes().item(0);
				titleFontField.setText(text.getNodeValue().trim());
				nodes = titleElement.getElementsByTagName(ChartConstants.COLOR);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
				Element colorElement = (Element) nodes.item(0);
				text = (Text) colorElement.getChildNodes().item(0);
				titleColorField.setBackground(new Color(Integer.decode(text.getNodeValue().trim())));
			} else {
				showTitleBox.doClick();
				titleFontField.setText(fontToString(JFreeChart.DEFAULT_TITLE_FONT));
				titleColorField.setBackground(Color.BLACK);
			}
			
			nodes = templateElement.getElementsByTagName(ChartConstants.TEMPLATE_SUBTITLE);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TEMPLATE_SUBTITLE + "' tag.");
			Element subtitleElement = (Element) nodes.item(0);
			tmp = subtitleElement.getAttribute(ChartConstants.SHOW_ATTR);
			if (null == tmp || "".equals(tmp))
				throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
			bool = Boolean.parseBoolean(tmp);
			showSubtitleBox.setSelected(true);
			if (bool) {
				nodes = subtitleElement.getElementsByTagName(ChartConstants.FONT);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
				Element fontElement = (Element) nodes.item(0);
				Text text = (Text) fontElement.getChildNodes().item(0);
				subtitleFontField.setText(text.getNodeValue().trim());
				nodes = subtitleElement.getElementsByTagName(ChartConstants.COLOR);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
				Element colorElement = (Element) nodes.item(0);
				text = (Text) colorElement.getChildNodes().item(0);
				subtitleColorField.setBackground(new Color(Integer.decode(text.getNodeValue().trim())));
			} else {
				showSubtitleBox.doClick();
				subtitleFontField.setText(fontToString(Axis.DEFAULT_AXIS_LABEL_FONT));
				subtitleColorField.setBackground(Color.BLACK);
			}
			
			nodes = templateElement.getElementsByTagName(ChartConstants.BACKGROUND);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.BACKGROUND + "' tag.");
			Element backgroundElement = (Element) nodes.item(0);
			tmp = backgroundElement.getAttribute(ChartConstants.BACKGROUND_TYPE);
			if (null == tmp || "".equals(tmp))
				throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.BACKGROUND_TYPE + "' is missing or empty.");
			boolean gradient = !ChartConstants.SIMPLE_BG_TYPE.equals(tmp);
			if (gradient) 
				gradientBackgroundButton.setSelected(true);
			else 
				simpleBackgroundButton.doClick();
			nodes = backgroundElement.getElementsByTagName(ChartConstants.START_COLOR);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.START_COLOR + "' tag.");
			Element startColorElement = (Element) nodes.item(0);
			Text text = (Text) startColorElement.getChildNodes().item(0);
			backgroundColor1Field.setBackground(new Color(Integer.decode(text.getNodeValue().trim())));
			if (gradient) {
				nodes = backgroundElement.getElementsByTagName(ChartConstants.END_COLOR);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.END_COLOR + "' tag.");
				Element endColorElement = (Element) nodes.item(0);
				text = (Text) endColorElement.getChildNodes().item(0);
				backgroundColor2Field.setBackground(new Color(Integer.decode(text.getNodeValue().trim())));
			}

			// DOMAIN AXIS
			nodes = templateElement.getElementsByTagName(ChartConstants.DOMAIN_AXIS);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.DOMAIN_AXIS + "' tag.");
			Element domainAxisElement = (Element) nodes.item(0);
			nodes = domainAxisElement.getElementsByTagName(ChartConstants.FONT);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
			Element fontElement = (Element) nodes.item(0);
			text = (Text) fontElement.getChildNodes().item(0);
			domainAxisFontField.setText(text.getNodeValue().trim());
			nodes = domainAxisElement.getElementsByTagName(ChartConstants.COLOR);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
			Element colorElement = (Element) nodes.item(0);
			text = (Text) colorElement.getChildNodes().item(0);
			domainAxisColorField.setBackground(new Color(Integer.decode(text.getNodeValue().trim())));
			
			nodes = domainAxisElement.getElementsByTagName(ChartConstants.TICK_LABELS);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TICK_LABELS + "' tag.");
			Element tickLabelsElement = (Element) nodes.item(0);
			tmp = tickLabelsElement.getAttribute(ChartConstants.SHOW_ATTR);
			if (null == tmp || "".equals(tmp))
				throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
			bool = Boolean.parseBoolean(tmp);
			domainAxisShowTickLabelBox.setSelected(true);
			if (bool) {
				nodes = tickLabelsElement.getElementsByTagName(ChartConstants.FONT);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
				fontElement = (Element) nodes.item(0);
				text = (Text) fontElement.getChildNodes().item(0);
				domainAxisTickFontField.setText(text.getNodeValue().trim());
			} else {
				domainAxisShowTickLabelBox.doClick();
				domainAxisTickFontField.setText(fontToString(Axis.DEFAULT_TICK_LABEL_FONT));
			}
			
			nodes = domainAxisElement.getElementsByTagName(ChartConstants.TICK_MARKS);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TICK_MARKS + "' tag.");
			Element tickMarksElement = (Element) nodes.item(0);
			tmp = tickMarksElement.getAttribute(ChartConstants.SHOW_ATTR);
			if (null == tmp || "".equals(tmp))
				throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
			domainAxisShowTickMarkBox.setSelected(Boolean.parseBoolean(tmp));
			
			nodes = domainAxisElement.getElementsByTagName(ChartConstants.INTERVAL);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.INTERVAL + "' tag.");
			Element intervalElement = (Element) nodes.item(0);
			tmp = intervalElement.getAttribute(ChartConstants.AUTO_ATTR);
			if (null == tmp || "".equals(tmp))
				throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.AUTO_ATTR + "' is missing or empty.");
			bool = Boolean.parseBoolean(tmp);
			domainAxisAutoAdjustRangeBox.setSelected(false);
			double domainMin, domainMax;
			if (!bool) {
				nodes = intervalElement.getElementsByTagName(ChartConstants.MIN_RANGE_VALUE);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.MIN_RANGE_VALUE + "' tag.");
				Element minValueElement = (Element) nodes.item(0);
				text = (Text) minValueElement.getChildNodes().item(0);
				try {
					domainMin = Double.parseDouble(text.getNodeValue().trim());
				} catch (NumberFormatException e) {
					throw new TemplateLoadingException("Invalid content at '" + ChartConstants.MIN_RANGE_VALUE + "' tag.");
				}
				nodes = intervalElement.getElementsByTagName(ChartConstants.MAX_RANGE_VALUE);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.MAX_RANGE_VALUE + "' tag.");
				Element maxValueElement = (Element) nodes.item(0);
				text = (Text) maxValueElement.getChildNodes().item(0);
				try {
					domainMax = Double.parseDouble(text.getNodeValue().trim());
				} catch (NumberFormatException e) {
					throw new TemplateLoadingException("Invalid content at '" + ChartConstants.MAX_RANGE_VALUE + "' tag.");
				}
				if (domainMin > domainMax)
					throw new TemplateLoadingException("Invalid domain interval.");
				domainAxisMinRange.setText(String.valueOf(domainMin));
				domainAxisMaxRange.setText(String.valueOf(domainMax));
			} else 
				domainAxisAutoAdjustRangeBox.doClick();
			
			// RANGE AXIS
			nodes = templateElement.getElementsByTagName(ChartConstants.RANGE_AXIS);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.RANGE_AXIS + "' tag.");
			Element rangeAxisElement = (Element) nodes.item(0);
			nodes = rangeAxisElement.getElementsByTagName(ChartConstants.FONT);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
			fontElement = (Element) nodes.item(0);
			text = (Text) fontElement.getChildNodes().item(0);
			rangeAxisFontField.setText(text.getNodeValue().trim());
			nodes = rangeAxisElement.getElementsByTagName(ChartConstants.COLOR);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
			colorElement = (Element) nodes.item(0);
			text = (Text) colorElement.getChildNodes().item(0);
			rangeAxisColorField.setBackground(new Color(Integer.decode(text.getNodeValue().trim())));
			
			nodes = rangeAxisElement.getElementsByTagName(ChartConstants.TICK_LABELS);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TICK_LABELS + "' tag.");
			tickLabelsElement = (Element) nodes.item(0);
			tmp = tickLabelsElement.getAttribute(ChartConstants.SHOW_ATTR);
			if (null == tmp || "".equals(tmp))
				throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
			bool = Boolean.parseBoolean(tmp);
			rangeAxisShowTickLabelBox.setSelected(true);
			if (bool) {
				nodes = tickLabelsElement.getElementsByTagName(ChartConstants.FONT);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.FONT + "' tag.");
				fontElement = (Element) nodes.item(0);
				text = (Text) fontElement.getChildNodes().item(0);
				rangeAxisTickFontField.setText(text.getNodeValue().trim());
			} else {
				rangeAxisShowTickLabelBox.doClick();
				rangeAxisTickFontField.setText(fontToString(Axis.DEFAULT_TICK_LABEL_FONT));
			}
			
			nodes = rangeAxisElement.getElementsByTagName(ChartConstants.TICK_MARKS);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.TICK_MARKS + "' tag.");
			tickMarksElement = (Element) nodes.item(0);
			tmp = tickMarksElement.getAttribute(ChartConstants.SHOW_ATTR);
			if (null == tmp || "".equals(tmp))
				throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.SHOW_ATTR + "' is missing or empty.");
			rangeAxisShowTickMarkBox.setSelected(Boolean.parseBoolean(tmp));
			
			nodes = rangeAxisElement.getElementsByTagName(ChartConstants.INTERVAL);
			if (nodes == null || nodes.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.INTERVAL + "' tag.");
			intervalElement = (Element) nodes.item(0);
			tmp = intervalElement.getAttribute(ChartConstants.AUTO_ATTR);
			if (null == tmp || "".equals(tmp))
				throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.AUTO_ATTR + "' is missing or empty.");
			bool = Boolean.parseBoolean(tmp);
			rangeAxisAutoAdjustRangeBox.setSelected(false);
			double rangeMin, rangeMax;
			if (!bool) {
				nodes = intervalElement.getElementsByTagName(ChartConstants.MIN_RANGE_VALUE);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.MIN_RANGE_VALUE + "' tag.");
				Element minValueElement = (Element) nodes.item(0);
				text = (Text) minValueElement.getChildNodes().item(0);
				try {
					rangeMin = Double.parseDouble(text.getNodeValue().trim());
				} catch (NumberFormatException e) {
					throw new TemplateLoadingException("Invalid content at '" + ChartConstants.MIN_RANGE_VALUE + "' tag.");
				}
				nodes = intervalElement.getElementsByTagName(ChartConstants.MAX_RANGE_VALUE);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.MAX_RANGE_VALUE + "' tag.");
				Element maxValueElement = (Element) nodes.item(0);
				text = (Text) maxValueElement.getChildNodes().item(0);
				try {
					rangeMax = Double.parseDouble(text.getNodeValue().trim());
				} catch (NumberFormatException e) {
					throw new TemplateLoadingException("Invalid content at '" + ChartConstants.MAX_RANGE_VALUE + "' tag.");
				}
				if (rangeMin > rangeMax)
					throw new TemplateLoadingException("Invalid domain interval.");
				rangeAxisMinRange.setText(String.valueOf(rangeMin));
				rangeAxisMaxRange.setText(String.valueOf(rangeMax));
			} else 
				rangeAxisAutoAdjustRangeBox.doClick();
			
			
			nodes = templateElement.getElementsByTagName(ChartConstants.SHAPE_SIZE);
			
			if (nodes == null || nodes.getLength() == 0) {
				shapeSizeField.setText("100");
			} else {
				Element shapeSizeElement = (Element) nodes.item(0);
				text = (Text) shapeSizeElement.getChildNodes().item(0);
				shapeSizeField.setText(text.getNodeValue().trim());
			}
			nodes = templateElement.getElementsByTagName(ChartConstants.SERIES_LIST);
			Node seriesList = nodes == null || nodes.getLength() == 0 ? null : nodes.item(0);
			initializeTable(seriesList,legends);
		}
	}
	
	//--------------------------------------------------------------------------------------
	private void initializeTable(Node node, List<String> legends) throws TemplateLoadingException {
		JComboBox shapeBox = new JComboBox();
		seriesTable.setModel(new SeriesTableModel(shapeBox,node,legends));
		
		seriesTable.getColumnModel().getColumn(0).setPreferredWidth(30);
		seriesTable.getColumnModel().getColumn(3).setPreferredWidth(100);
		seriesTable.getColumnModel().getColumn(4).setPreferredWidth(100);
		seriesTable.getColumnModel().getColumn(5).setPreferredWidth(100);
		
		seriesTable.setDefaultRenderer(Color.class,new ColorRenderer());
		seriesTable.setDefaultRenderer(UniversalShape.class,new ShapeRenderer());
		seriesTable.setDefaultRenderer(Float.class,new ThicknessRenderer());
		seriesTable.setDefaultRenderer(Long.class,new StyleRenderer());
		
		for (int i = 0;i < PREDEFINED_SHAPES.length;++i)
			shapeBox.addItem(new UniversalShape(i));
		shapeBox.addItem(new UniversalShape("Other..."));
		shapeBox.setRenderer(new ShapeRenderer());
		seriesTable.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(shapeBox));
		
		JComboBox thicknessBox = new JComboBox();
		for (Float f : ThicknessRenderer.iconMap.keySet()) 
			thicknessBox.addItem(f);
		thicknessBox.setRenderer(new ThicknessRenderer());
		seriesTable.getColumnModel().getColumn(4).setCellEditor(new DefaultCellEditor(thicknessBox));
		
		JComboBox styleBox = new JComboBox();
		for (int i = 0; i < 10 ; i++)
			styleBox.addItem(new Long(i));
		styleBox.setRenderer(new StyleRenderer());
		seriesTable.getColumnModel().getColumn(5).setCellEditor(new DefaultCellEditor(styleBox));
	}

	//=======================================================================================
	// private methods
	
	//--------------------------------------------------------------------------------------
	private String fontToString(Font font) {
		String style = "";
		switch (font.getStyle()) {
		case Font.BOLD   			 : style += "bold"; break;
		case Font.ITALIC 			 : style += "italic"; break;
		case Font.BOLD + Font.ITALIC : style += "bold & italic"; 
		}
		String desc = font.getName() + " / " + font.getSize(); 
		return  "".equals(style) ? desc : desc + " / " + style;
	}
	
	//--------------------------------------------------------------------------------------
	private void handleFontSelection(JTextField target) {
	    FontChooserPanel panel = new FontChooserPanel(Utilities.stringToFont(target.getText()));
	    int result = JOptionPane.showConfirmDialog(this,panel,"Font Selection",
	                							   JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
	    if (result == JOptionPane.OK_OPTION) {
	    	Font selectedFont = panel.getSelectedFont();
	    	target.setText(fontToString(selectedFont));
        }
	}
	
	//--------------------------------------------------------------------------------------
	private void handleColorSelection(JTextField target) {
		Color color = JColorChooser.showDialog(this,"Color Selection",target.getBackground());
		if (color != null)
			target.setBackground(color);
	}
	
	//------------------------------------------------------------------------------
	private JTextField getShapeSizeField() {
		if (shapeSizeField == null) {
			shapeSizeField = new JTextField();
			shapeSizeField.setMaximumSize(new Dimension(160, 30));
			shapeSizeField.setHorizontalAlignment(JTextField.TRAILING);
			shapeSizeField.setPreferredSize(new Dimension(75, 25));
			shapeSizeField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					Pattern p = Pattern.compile("^[1-9][0-9]*$");
					Matcher positive = p.matcher(shapeSizeField.getText().trim());
					try {
						if (!positive.matches())
							throw new NumberFormatException();
						Integer.parseInt(shapeSizeField.getText().trim());
					} catch (NumberFormatException ee) {
						JOptionPane.showMessageDialog(ChartPropertiesDialog.this,"Invalid value in field 'Shape Size'.","Warning",JOptionPane.WARNING_MESSAGE,null);
						shapeSizeField.setText("100");
						shapeSizeField.grabFocus();
						shapeSizeField.selectAll();
					}
				}
			});
		}
		return shapeSizeField;
	}
//------------------------------------------------------------------------------
	

	private JPanel getShapeSizePanel() {
		if (shapeSizePanel == null) {
			shapeSizeLabel = new JLabel();
			shapeSizeLabel.setText("  The size of the shapes :  ");
			percentageLabel = new JLabel();
			percentageLabel.setText("%");
			shapeSizePanel = new JPanel();
			shapeSizePanel.setLayout(new BoxLayout(getShapeSizePanel(), BoxLayout.X_AXIS));
			shapeSizePanel.add(shapeSizeLabel, null);
			shapeSizePanel.add(getShapeSizeField(), null);
			shapeSizePanel.add(percentageLabel, null);
			shapeSizePanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
		}
		return shapeSizePanel;
	}
	//--------------------------------------------------------------------------------------
	public static Shape[] createStandardSeriesShapes() {
        Shape[] result = new Shape[20];
        double size = 6 * sizePercentage / 100;
        double delta = size / 2.0;
        int[] xpoints = null;
        int[] ypoints = null;

        // filled square
        result[0] = new Rectangle2D.Double(-delta, -delta, size, size);
        
        // filled circle
        result[1] = new Ellipse2D.Double(-delta, -delta, size, size);

        // filled up-pointing triangle
        xpoints = intArray(0.0, delta, -delta);
        ypoints = intArray(-delta, delta, delta);
        result[2] = new Polygon(xpoints, ypoints, 3);

        // filled diamond
        xpoints = intArray(0.0, delta, 0.0, -delta);
        ypoints = intArray(-delta, 0.0, delta, 0.0);
        result[3] = new Polygon(xpoints, ypoints, 4);

        // filled horizontal rectangle
        result[4] = new Rectangle2D.Double(-delta, -delta / 2, size, size / 2);

        // filled down-pointing triangle
        xpoints = intArray(-delta, +delta, 0.0);
        ypoints = intArray(-delta, -delta, delta);
        result[5] = new Polygon(xpoints, ypoints, 3);

        // filled horizontal ellipse
        result[6] = new Ellipse2D.Double(-delta, -delta / 2, size, size / 2);

        // filled right-pointing triangle
        xpoints = intArray(-delta, delta, -delta);
        ypoints = intArray(-delta, 0.0, delta);
        result[7] = new Polygon(xpoints, ypoints, 3);

        // filled vertical rectangle
        result[8] = new Rectangle2D.Double(-delta / 2, -delta, size / 2, size);

        // filled left-pointing triangle
        xpoints = intArray(-delta, delta, delta);
        ypoints = intArray(0.0, -delta, +delta);
        result[9] = new Polygon(xpoints, ypoints, 3);
        
        // unfilled square
        result[10] = new UnfilledShape(new Rectangle2D.Double(-delta, -delta, size, size));
        
        // unfilled circle
        result[11] = new UnfilledShape(new Ellipse2D.Double(-delta, -delta, size, size));

        // unfilled up-pointing triangle
        xpoints = intArray(0.0, delta, -delta);
        ypoints = intArray(-delta, delta, delta);
        result[12] = new UnfilledShape(new Polygon(xpoints, ypoints, 3));

        // unfilled diamond
        xpoints = intArray(0.0, delta, 0.0, -delta);
        ypoints = intArray(-delta, 0.0, delta, 0.0);
        result[13] = new UnfilledShape(new Polygon(xpoints, ypoints, 4));

        // unfilled horizontal rectangle
        result[14] = new UnfilledShape(new Rectangle2D.Double(-delta, -delta / 2, size, size / 2));

        // unfilled down-pointing triangle
        xpoints = intArray(-delta, +delta, 0.0);
        ypoints = intArray(-delta, -delta, delta);
        result[15] = new UnfilledShape(new Polygon(xpoints, ypoints, 3));

        // unfilled horizontal ellipse
        result[16] = new UnfilledShape(new Ellipse2D.Double(-delta, -delta / 2, size, size / 2));

        // unfilled right-pointing triangle
        xpoints = intArray(-delta, delta, -delta);
        ypoints = intArray(-delta, 0.0, delta);
        result[17] = new UnfilledShape(new Polygon(xpoints, ypoints, 3));

        // unfilled vertical rectangle
        result[18] = new UnfilledShape(new Rectangle2D.Double(-delta / 2, -delta, size / 2, size));

        // unfilled left-pointing triangle
        xpoints = intArray(-delta, delta, delta);
        ypoints = intArray(0.0, -delta, +delta);
        result[19] = new UnfilledShape(new Polygon(xpoints, ypoints, 3));

        return result;
    }
	
	//--------------------------------------------------------------------------------------
	public static void createStandardSeriesShapes(double percentage){
		sizePercentage = percentage;
		PREDEFINED_SHAPES = createStandardSeriesShapes();
	}
	
	//--------------------------------------------------------------------------------------
    private static int[] intArray(double a, double b, double c) {
        return new int[] {(int) a, (int) b, (int) c};
    }
    private static int[] intArray(double a, double b, double c, double d) {
        return new int[] {(int) a, (int) b, (int) c, (int) d};
    }
    
    //-------------------------------------------------------------------------------------
	private void move(int offset) {
		SeriesTableModel tmodel = (SeriesTableModel) seriesTable.getModel();
		seriesTable.getSelectionModel().removeSelectionInterval(tmodel.getRowCount()-1,tmodel.getRowCount()-1);
		int[] selected = seriesTable.getSelectedRows();
		
		List<int[]> intervals = new ArrayList<int[]>();
		int start = selected[0], end = -1, previous = selected[0] - 1;

		for (int i=0;i<selected.length;++i) {
				if (selected[i] == previous + 1) previous = selected[i];
				else {
					end = previous;
					int[] intv = { start, end };
					intervals.add(intv);
					end = -1;
					start = previous = selected[i];
				}
		}
		intervals.add(new int[] { start, selected[selected.length-1] });
		
		seriesTable.getSelectionModel().clearSelection();
		for (int[] intv : intervals) {
			int to = intv[0] + offset;
			if (0 <= intv[0] && 0 <= to && intv[1] + offset < seriesTable.getRowCount() - 1) {
				tmodel.moveRow(intv[0],intv[1],to);
				seriesTable.getSelectionModel().addSelectionInterval(intv[0] + offset,intv[1] + offset);
			} else 
				seriesTable.getSelectionModel().addSelectionInterval(intv[0],intv[1]);
		}
	}
	
	//-------------------------------------------------------------------------------------
	private String checkInput() {
		if (templateName.getText().trim().equals("")) 
			return "Template name is empty";
		if (RESERVED_TEMPLATE_NAMES.contains(templateName.getText().trim())) 
			return "This is a reserved name.";
		if (knownTemplates.contains(templateName.getText().trim())) {
				String msg = "This template is already exist.\nDo you want to override?"; 
				boolean yes = JOptionPane.showConfirmDialog(this,msg,"Warning", 
							   							   JOptionPane.YES_NO_OPTION,
							   							   JOptionPane.WARNING_MESSAGE
							   							   ) == JOptionPane.YES_OPTION;
				if (!yes) return "";
		}
		if (("".equals(widthField.getText().trim()) || "".equals(heightField.getText().trim())) && 
			!widthField.getText().trim().equals(heightField.getText().trim()))
			return "Missing dimension information."; // XOR
		if (!"".equals(widthField.getText().trim())) {
			try {
				int no = Integer.parseInt(widthField.getText().trim());
				if (no < 1) 
					throw new NumberFormatException();
			} catch (NumberFormatException e) {
				return "Invalid content in the 'Width' field.";
			}
		}
		if (!"".equals(heightField.getText().trim())) {
			try {
				int no = Integer.parseInt(heightField.getText().trim());
				if (no < 1) 
					throw new NumberFormatException();
			} catch (NumberFormatException e) {
				return "Invalid content in the 'Height' field.";
			}
		}
		if (!domainAxisAutoAdjustRangeBox.isSelected()) {
			if (domainAxisMinRange.getText().trim().equals(""))
				return "The 'Minimum range value' field of the domain axis cannot be empty.";
			if (domainAxisMaxRange.getText().trim().equals(""))
				return "The 'Maximum range value' field of the domain axis cannot be empty.";
			double domainMin, domainMax;
			try {
				domainMin = Double.parseDouble(domainAxisMinRange.getText().trim());
			} catch (NumberFormatException e) {
				return "Invalid content in the 'Minimum range value' field of the domain axis.";
			}
			try {
				domainMax = Double.parseDouble(domainAxisMaxRange.getText().trim());
			} catch (NumberFormatException e) {
				return "Invalid content in the 'Maximum range value' field of the domain axis.";
			}
			if (domainMax < domainMin)
				return "The 'Maximum range value' of the domain axis cannot be less than the 'Minimum range value'.";
			
		}
		if (!rangeAxisAutoAdjustRangeBox.isSelected()) {
			if (rangeAxisMinRange.getText().trim().equals(""))
				return "The 'Minimum range value' field of the range axis cannot be empty.";
			if (rangeAxisMaxRange.getText().trim().equals(""))
				return "The 'Maximum range value' field of the range axis cannot be empty.";
			double rangeMin, rangeMax;
			try {
				rangeMin = Double.parseDouble(rangeAxisMinRange.getText().trim());
			} catch (NumberFormatException e) {
				return "Invalid content in the 'Minimum range value' field of the range axis.";
			}
			try {
				rangeMax = Double.parseDouble(rangeAxisMaxRange.getText().trim());
			} catch (NumberFormatException e) {
				return "Invalid content in the 'Maximum range value' field of the range axis.";
			}
			if (rangeMax < rangeMin)
				return "The 'Maximum range value' of the range axis cannot be less than the 'Minimum range value'.";
		}
		return null;
	}
	
	//-------------------------------------------------------------------------------------
	private boolean saveTemplate() {
		File templateDir = new File("Templates");
		if (!templateDir.exists()) templateDir.mkdir();
		try {
			File template = new File(templateDir,templateName.getText().trim() + ".xml");
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder parser = factory.newDocumentBuilder();
			Document document = parser.newDocument();
			
			Element templateElement = document.createElement(ChartConstants.TEMPLATE);
			templateElement.setAttribute(ChartConstants.REF_ID_ATTR,templateName.getText().trim());

			// GENERAL
			if (!"".equals(widthField.getText().trim()) && !"".equals(heightField.getText().trim())) {
				int width = Integer.parseInt(widthField.getText().trim());
				int height = Integer.parseInt(heightField.getText().trim());
				if (width != kind.default_width() || height != kind.default_height()) {
					Element dimensionElement = document.createElement(ChartConstants.DIMENSION);
					Element widthElement = document.createElement(ChartConstants.TEMPLATE_WIDTH);
					widthElement.appendChild(document.createTextNode(String.valueOf(width)));
					dimensionElement.appendChild(widthElement);
					Element heightElement = document.createElement(ChartConstants.TEMPLATE_HEIGHT);
					heightElement.appendChild(document.createTextNode(String.valueOf(height)));
					dimensionElement.appendChild(heightElement);
					templateElement.appendChild(dimensionElement);
				}
			}
			Element titleElement = document.createElement(ChartConstants.TEMPLATE_TITLE);
			titleElement.setAttribute(ChartConstants.SHOW_ATTR,String.valueOf(showTitleBox.isSelected()));
			if (showTitleBox.isSelected()) {
				Element fontElement = document.createElement(ChartConstants.FONT);
				fontElement.appendChild(document.createTextNode(titleFontField.getText().trim()));
				titleElement.appendChild(fontElement);
				
				Element colorElement = document.createElement(ChartConstants.COLOR);
				String color_string = String.format("#%06x",titleColorField.getBackground().getRGB() & 0xffffff);
				colorElement.appendChild(document.createTextNode(color_string));
				titleElement.appendChild(colorElement);
			}
			templateElement.appendChild(titleElement);
			
			Element subtitleElement = document.createElement(ChartConstants.TEMPLATE_SUBTITLE);
			subtitleElement.setAttribute(ChartConstants.SHOW_ATTR,String.valueOf(showSubtitleBox.isSelected()));
			if (showSubtitleBox.isSelected()) {
				Element fontElement = document.createElement(ChartConstants.FONT);
				fontElement.appendChild(document.createTextNode(subtitleFontField.getText().trim()));
				subtitleElement.appendChild(fontElement);
				
				Element colorElement = document.createElement(ChartConstants.COLOR);
				String color_string = String.format("#%06x",subtitleColorField.getBackground().getRGB() & 0xffffff);
				colorElement.appendChild(document.createTextNode(color_string));
				subtitleElement.appendChild(colorElement);
			}
			templateElement.appendChild(subtitleElement);
			
			Element backgroundElement = document.createElement(ChartConstants.BACKGROUND);
			backgroundElement.setAttribute(ChartConstants.BACKGROUND_TYPE,gradientBackgroundButton.isSelected() ? ChartConstants.GRADIENT_BG_TYPE : ChartConstants.SIMPLE_BG_TYPE);
			Element startColorElement = document.createElement(ChartConstants.START_COLOR);
			String color_string = String.format("#%06x",backgroundColor1Field.getBackground().getRGB() & 0xffffff);
			startColorElement.appendChild(document.createTextNode(color_string));
			backgroundElement.appendChild(startColorElement);
			if (gradientBackgroundButton.isSelected()) {
				Element endColorElement = document.createElement(ChartConstants.END_COLOR);
				color_string = String.format("#%06x",backgroundColor2Field.getBackground().getRGB() & 0xffffff);
				endColorElement.appendChild(document.createTextNode(color_string));
				backgroundElement.appendChild(endColorElement);
			}
			templateElement.appendChild(backgroundElement);
			
			// DOMAIN AXIS
			Element domainAxisElement = document.createElement(ChartConstants.DOMAIN_AXIS);
			
			Element fontElement = document.createElement(ChartConstants.FONT);
			fontElement.appendChild(document.createTextNode(domainAxisFontField.getText().trim()));
			domainAxisElement.appendChild(fontElement);

			Element colorElement = document.createElement(ChartConstants.COLOR);
			color_string = String.format("#%06x",domainAxisColorField.getBackground().getRGB() & 0xffffff);
			colorElement.appendChild(document.createTextNode(color_string));
			domainAxisElement.appendChild(colorElement);
			
			Element tickLabelsElement = document.createElement(ChartConstants.TICK_LABELS);
			tickLabelsElement.setAttribute(ChartConstants.SHOW_ATTR,String.valueOf(domainAxisShowTickLabelBox.isSelected()));
			if (domainAxisShowTickLabelBox.isSelected()) {
				fontElement = document.createElement(ChartConstants.FONT);
				fontElement.appendChild(document.createTextNode(domainAxisTickFontField.getText().trim()));
				tickLabelsElement.appendChild(fontElement);
			}
			domainAxisElement.appendChild(tickLabelsElement);
			
			Element tickMarksElement = document.createElement(ChartConstants.TICK_MARKS);
			tickMarksElement.setAttribute(ChartConstants.SHOW_ATTR,String.valueOf(domainAxisShowTickMarkBox.isSelected()));
			domainAxisElement.appendChild(tickMarksElement);
			
			Element intervalElement = document.createElement(ChartConstants.INTERVAL);
			intervalElement.setAttribute(ChartConstants.AUTO_ATTR,String.valueOf(domainAxisAutoAdjustRangeBox.isSelected()));
			if (!domainAxisAutoAdjustRangeBox.isSelected()) {
				Element minRangeElement = document.createElement(ChartConstants.MIN_RANGE_VALUE);
				minRangeElement.appendChild(document.createTextNode(domainAxisMinRange.getText().trim()));
				intervalElement.appendChild(minRangeElement);
				
				Element maxRangeElement = document.createElement(ChartConstants.MAX_RANGE_VALUE);
				maxRangeElement.appendChild(document.createTextNode(domainAxisMaxRange.getText().trim()));
				intervalElement.appendChild(maxRangeElement);
			}
			domainAxisElement.appendChild(intervalElement);
			
			templateElement.appendChild(domainAxisElement);
			
			// RANGE AXIS
			Element rangeAxisElement = document.createElement(ChartConstants.RANGE_AXIS);
			
			fontElement = document.createElement(ChartConstants.FONT);
			fontElement.appendChild(document.createTextNode(rangeAxisFontField.getText().trim()));
			rangeAxisElement.appendChild(fontElement);

			colorElement = document.createElement(ChartConstants.COLOR);
			color_string = String.format("#%06x",rangeAxisColorField.getBackground().getRGB() & 0xffffff);
			colorElement.appendChild(document.createTextNode(color_string));
			rangeAxisElement.appendChild(colorElement);
			
			tickLabelsElement = document.createElement(ChartConstants.TICK_LABELS);
			tickLabelsElement.setAttribute(ChartConstants.SHOW_ATTR,String.valueOf(rangeAxisShowTickLabelBox.isSelected()));
			if (rangeAxisShowTickLabelBox.isSelected()) {
				fontElement = document.createElement(ChartConstants.FONT);
				fontElement.appendChild(document.createTextNode(rangeAxisTickFontField.getText().trim()));
				tickLabelsElement.appendChild(fontElement);
			}
			rangeAxisElement.appendChild(tickLabelsElement);
			
			tickMarksElement = document.createElement(ChartConstants.TICK_MARKS);
			tickMarksElement.setAttribute(ChartConstants.SHOW_ATTR,String.valueOf(rangeAxisShowTickMarkBox.isSelected()));
			rangeAxisElement.appendChild(tickMarksElement);
			
			intervalElement = document.createElement(ChartConstants.INTERVAL);
			intervalElement.setAttribute(ChartConstants.AUTO_ATTR,String.valueOf(rangeAxisAutoAdjustRangeBox.isSelected()));
			if (!rangeAxisAutoAdjustRangeBox.isSelected()) {
				Element minRangeElement = document.createElement(ChartConstants.MIN_RANGE_VALUE);
				minRangeElement.appendChild(document.createTextNode(rangeAxisMinRange.getText().trim()));
				intervalElement.appendChild(minRangeElement);
				
				Element maxRangeElement = document.createElement(ChartConstants.MAX_RANGE_VALUE);
				maxRangeElement.appendChild(document.createTextNode(rangeAxisMaxRange.getText().trim()));
				intervalElement.appendChild(maxRangeElement);
			}
			rangeAxisElement.appendChild(intervalElement);
			
			templateElement.appendChild(rangeAxisElement);
			
			//SHAPE_SIZE
			
			if (!"".equals(shapeSizeField.getText().trim()) ) {
			
				sizePercentage = Double.parseDouble(shapeSizeField.getText().trim());
				Element shapeSizeElement = document.createElement(ChartConstants.SHAPE_SIZE);
				shapeSizeElement.appendChild(document.createTextNode(String.valueOf(sizePercentage)));
				templateElement.appendChild(shapeSizeElement);
				
			}
			// SERIES_LIST
			Element seriesListElement = document.createElement(ChartConstants.SERIES_LIST);
			SeriesTableModel tmodel = (SeriesTableModel) seriesTable.getModel();
			if (tmodel.saveSeries(seriesListElement))
				templateElement.appendChild(seriesListElement);
			document.appendChild(templateElement);
			
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			Source source = new DOMSource(document);
			FileOutputStream os = new FileOutputStream(template);
			Result result = new StreamResult(os);
			transformer.transform(source,result);
			this.template = templateElement;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,"Unable to save template.\n" + e.getLocalizedMessage(),"Error",JOptionPane.ERROR_MESSAGE,null);
			return false;
		}
		return true;
	}
	
	//=======================================================================================
	// nested classes
	
	//---------------------------------------------------------------------------------------
 	public enum ChartKind { 
 		NORMAL, GRAPH, SUBGRAPH; 
 							
 		public int default_width()	{
 			switch (this) {
 			case NORMAL 	: return 680;
 			case GRAPH		: return 800;
 			case SUBGRAPH	: return 600;
 			}
 			return 0;
 		};
 							
 		public int default_height() {
 			switch (this) {
 			case NORMAL		: return 420;
 			case GRAPH		: return 440;
 			case SUBGRAPH	: return 600;
 			}
 			return 0;
 		}
 	};
	
	//---------------------------------------------------------------------------------------
	private class SeriesTableModel extends AbstractTableModel {
		
		//=================================================================================
		// members
		
		private static final long serialVersionUID = 1L;
		private String[] columnNames = { "#", "Legend", "Color", "Shape", "Thickness", "Style" };
		private Class[] columnTypes = { Integer.class, String.class, Color.class, UniversalShape.class, Float.class, Long.class };
		private List<Object[]> rows = null;
		private List<Object[]> assist = null;
		private JComboBox shapeBox = null;
		private int index = 1;
		private List<String> legends = null;
		private int legendIndex = 0;
		
		//=================================================================================
		// methods
		
		//---------------------------------------------------------------------------------
		public SeriesTableModel(JComboBox shapeBox, Node node, List<String> legends) throws TemplateLoadingException {
			super();
			this.shapeBox = shapeBox;
			this.legends = legends;
			assist = new ArrayList<Object[]>();
			rows = new ArrayList<Object[]>();
			if (node == null) {
				if (legends != null && legends.size() > 0) {
					int shapeIndex = 0;
					ChartDrawingSupplier supplier = new ChartDrawingSupplier();
					for (String s : legends) {
						assist.add(new Object[] { index++, s });
						rows.add(new Object[] { (Color) supplier.getNextPaint(), new UniversalShape(shapeIndex % PREDEFINED_SHAPES.length), 1.f, 0L });
						shapeIndex++;
						legendIndex++;
					}
				}
			} else {
				int definedSeries = createFromNode(node);
				if (legends != null && legends.size() > definedSeries) {
					for (int i = 0;i < legends.size() - definedSeries;++i)
						addBlankLine();
				}
			}
			addBlankLine();
		}
		
		//---------------------------------------------------------------------------------
		public int getColumnCount() { return columnNames.length; }
		public int getRowCount() { return rows.size(); }
		@Override public String getColumnName(int column) { return columnNames[column]; }
		public Object getValueAt(int rowIndex, int columnIndex) {
			return columnIndex < 2 ? assist.get(rowIndex)[columnIndex] : rows.get(rowIndex)[columnIndex - 2];
		}
		@Override public Class<?> getColumnClass(int columnIndex) {	return columnTypes[columnIndex]; }
		@Override public boolean isCellEditable(int rowIndex, int columnIndex) { return columnIndex >= 2; }
		
		//---------------------------------------------------------------------------------
		@SuppressWarnings("unchecked") @Override
		public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
			if (columnIndex == 3 && aValue.equals(new UniversalShape("Other...")) ) {
				JFileChooser chooser = new JFileChooser(GlobalHandlers.getLastDirectory());
				chooser.setAcceptAllFileFilterUsed(false);
				chooser.setFileFilter(new ExtensionFileFilter("Java class files (.class)","class"));
				int result = chooser.showOpenDialog(ChartPropertiesDialog.this);
				if (result == JFileChooser.APPROVE_OPTION) {
					File file = chooser.getSelectedFile();
					GlobalHandlers.setLastDirectory(file);
					String name = file.getPath();
					String osName = System.getProperty("os.name").toLowerCase();
					name = name.substring(osName.indexOf("windows") >= 0 ? 3 : 1,name.lastIndexOf(".class"));
					String swap = null;
					if (File.separator.equals("\\")) swap = "\\";
					else swap = "";
					name = name.replaceAll(swap+File.separator,".");
					String candidate = name;
					Class c = null;
					int index = 0;
					while (c == null) {
						try {
							c = Class.forName(candidate);
						} catch (ClassNotFoundException e1) {
							int oldIndex = index;
							index = name.indexOf(".",oldIndex+1);
							if (index == -1) {
								JOptionPane.showMessageDialog(ChartPropertiesDialog.this,"Unable to load class!", "Error", JOptionPane.ERROR_MESSAGE, null);
								return;
							}
							candidate = name.substring(index+1);
							continue;
						}
						break;
					}
					if (c.isAssignableFrom(Shape.class)) {
						JOptionPane.showMessageDialog(ChartPropertiesDialog.this,"This class has not implemented the Shape interface!", "Warning", JOptionPane.WARNING_MESSAGE, null);
						return;
					}
					boolean validConstructor = true;
					try {
						c.getConstructor(new Class[] {});
					} catch (Exception e1) {
						validConstructor = false;
					}
					if (!validConstructor) {
						JOptionPane.showMessageDialog(ChartPropertiesDialog.this,"This class has not nullary constructor!", "Warning", JOptionPane.WARNING_MESSAGE, null);
						return;
					}
					UniversalShape us = new UniversalShape(c);
					((DefaultComboBoxModel)shapeBox.getModel()).insertElementAt(us,shapeBox.getItemCount()-1);
					rows.get(rowIndex)[columnIndex - 2] = us;
					fireTableCellUpdated(rowIndex,columnIndex);
					if (rowIndex == rows.size() - 1) {
						addBlankLine();
						fireTableRowsInserted(rows.size() - 1,rows.size() - 1);
					}  	
				}
			} else {
				Object[] actRow = rows.get(rowIndex);
				actRow[columnIndex - 2] = aValue;
				fireTableCellUpdated(rowIndex,columnIndex);
				if (rowIndex == rows.size() - 1) {
					addBlankLine();
					fireTableRowsInserted(rows.size() - 1,rows.size() - 1);
				}  	
			}
		}
		
		//---------------------------------------------------------------------------------
		// Imported from DefaultTableModel
	    /** Moves one or more rows from the inclusive range <code>start</code> to 
	     *  <code>end</code> to the <code>to</code> position in the model. 
	     *  After the move, the row that was at index <code>start</code> 
	     *  will be at index <code>to</code>. 
	     *  This method will send a <code>tableChanged</code> notification
	     *  message to all the listeners. <p>
	     *
	     *  <pre>
	     *  Examples of moves:
	     *  <p>
	     *  1. moveRow(1,3,5);
	     *          a|B|C|D|e|f|g|h|i|j|k   - before
	     *          a|e|f|g|h|B|C|D|i|j|k   - after
	     *  <p>
	     *  2. moveRow(6,7,1);
	     *          a|b|c|d|e|f|G|H|i|j|k   - before
	     *          a|G|H|b|c|d|e|f|i|j|k   - after
	     *  <p> 
	     *  </pre>
	     *
	     * @param   start       the starting row index to be moved
	     * @param   end         the ending row index to be moved
	     * @param   to          the destination of the rows to be moved
	     * @exception  ArrayIndexOutOfBoundsException  if any of the elements 
	     * would be moved out of the table's range 
	     * 
	     */
	    public void moveRow(int start, int end, int to) { 
	    	int shift = to - start; 
	    	int first, last; 
	    	if (shift < 0) { 
	    		first = to; 
		    	last = end; 
	    	} else { 
	    		first = start; 
	    		last = to + end - start;  
	    	}
	        Utilities.rotate(rows,first,last + 1,shift); 
	        fireTableRowsUpdated(first, last);
	    }
	    
		//---------------------------------------------------------------------------------
		// Imported from DefaultTableModel
	    /** Removes the row at <code>row</code> from the model.  Notification
	     *  of the row being removed will be sent to all the listeners.
	     * @param row the row index of the row to be removed
	     * @exception ArrayIndexOutOfBoundsException  if the row was invalid
	     */
		public void removeRow(int row) {
	        rows.remove(row);
	        fireTableRowsDeleted(row, row);
	    }

		//---------------------------------------------------------------------------------
		public void removeBlankLines(int no) {
			int size = assist.size();
			for (int i = size - 2; i >= size - no - 1;--i) {
				String s = getValueAt(i,1).toString();
				if ("".equals(s)) { 
					assist.remove(i);
					index--;
					fireTableRowsDeleted(i,i);
				} else
					rows.add(new Object[] { null, new UniversalShape(0), 0.5f, 0L });
			}
			Object[] lastRow = assist.get(assist.size() - 1);
			lastRow[0] = index - 1;
		}
		
		//---------------------------------------------------------------------------------
		public boolean saveSeries(Element node) {
			boolean result = false;
			Document document = node.getOwnerDocument();
			for (Object[] row : rows) {
				if (row[0] == null) continue;
				Element seriesElement = document.createElement(ChartConstants.SERIES);
				
				Element colorElement = document.createElement(ChartConstants.COLOR);
				String color_string = String.format("#%06x",((Color)row[0]).getRGB() & 0xffffff);
				colorElement.appendChild(document.createTextNode(color_string));
				seriesElement.appendChild(colorElement);
				
				UniversalShape shape = (UniversalShape) row[1];
				Element shapeElement = document.createElement(ChartConstants.SHAPE);
				boolean custom = shape.value() instanceof Class;
				shapeElement.setAttribute(ChartConstants.CUSTOM_ATTR,String.valueOf(custom));
				String shape_string = custom ? ((Class)shape.value()).getName() : shape.value().toString();
				shapeElement.appendChild(document.createTextNode(shape_string));
				seriesElement.appendChild(shapeElement);
				
				Element thicknessElement = document.createElement(ChartConstants.THICKNESS);
				thicknessElement.appendChild(document.createTextNode(row[2].toString()));
				seriesElement.appendChild(thicknessElement);
				
				Element styleElement = document.createElement(ChartConstants.STYLE);
				styleElement.appendChild(document.createTextNode(row[3].toString()));
				seriesElement.appendChild(styleElement);
				
				result = true;
				node.appendChild(seriesElement);
			}
			return result;
		}
		
		//=================================================================================
		// private methods
		
		//---------------------------------------------------------------------------------
		private void addBlankLine() {
			String legend = legends == null || legendIndex > legends.size() - 1 ? "" : legends.get(legendIndex++);
			assist.add(new Object[] { index++, legend });
			rows.add(new Object[] { null, new UniversalShape(0), 0.5f, 0L });
		}

		//---------------------------------------------------------------------------------
		@SuppressWarnings("unchecked")
		private int createFromNode(Node node) throws TemplateLoadingException {
			Element seriesListElement = (Element)node;
			NodeList seriesList = seriesListElement.getElementsByTagName(ChartConstants.SERIES);
			if (seriesList == null || seriesList.getLength() == 0)
				throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.SERIES + "' tag.");
			for (int i = 0;i < seriesList.getLength();++i) {
				Element seriesElement = (Element) seriesList.item(i);
				NodeList nodes = seriesElement.getElementsByTagName(ChartConstants.COLOR);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.COLOR + "' tag.");
				Element colorElement = (Element) nodes.item(0);
				Text text = (Text) colorElement.getChildNodes().item(0);
				Color color = new Color(Integer.decode(text.getNodeValue().trim()));
				nodes = seriesElement.getElementsByTagName(ChartConstants.SHAPE);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.SHAPE + "' tag.");
				Element shapeElement = (Element) nodes.item(0);
				String customAttribute = shapeElement.getAttribute(ChartConstants.CUSTOM_ATTR);
				if (null == customAttribute || "".equals(customAttribute))
					throw new TemplateLoadingException("Invalid template. Attribute '" + ChartConstants.CUSTOM_ATTR + "' is missing or empty.");
				boolean custom = Boolean.parseBoolean(customAttribute);
				text = (Text) shapeElement.getChildNodes().item(0);
				UniversalShape shape = null;
				if (custom) {
					Class c = null;
					try {
						c = Class.forName(text.getNodeValue().trim());
					} catch (ClassNotFoundException e1) {
							throw new TemplateLoadingException("Invalid template. Shape class " + text.getNodeValue().trim() + " is not found.");
					}
					if (c.isAssignableFrom(Shape.class)) 
						throw new TemplateLoadingException("Invalid template. Class " + text.getNodeValue().trim() + " has not implemented the Shape interface.");
					try {
						c.getConstructor(new Class[] {});
					} catch (Exception e) {
						throw new TemplateLoadingException("Invalid template. Class " + text.getNodeValue().trim() + " has not nullary constructor.");
					}
					shape = new UniversalShape(c);
				} else {
					try {
						int index = Integer.parseInt(text.getNodeValue().trim());
						if (index < 0 || index > 19)
							throw new NumberFormatException();
						shape = new UniversalShape(index);
					} catch (NumberFormatException e) {
						throw new TemplateLoadingException("Invalid template. Shape index must be an integer between 0 and 9.");
					}
				}
				nodes = seriesElement.getElementsByTagName(ChartConstants.THICKNESS);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.THICKNESS + "' tag.");
				Element thicknessElement = (Element) nodes.item(0);
				text = (Text) thicknessElement.getChildNodes().item(0);
				float thickness = 0;
				try {
					thickness = Float.parseFloat(text.getNodeValue().trim());
					if (thickness <= 0)
						throw new NumberFormatException();
				} catch (NumberFormatException e) {
					throw new TemplateLoadingException("Invalid template. Thickness must be a positive real.");
				}
				nodes = seriesElement.getElementsByTagName(ChartConstants.STYLE);
				if (nodes == null || nodes.getLength() == 0)
					throw new TemplateLoadingException("Invalid template, missing '" + ChartConstants.STYLE + "' tag.");
				Element styleElement = (Element) nodes.item(0);
				text = (Text) styleElement.getChildNodes().item(0);
				long styleIndex = 0;
				try {
					styleIndex = Long.parseLong(text.getNodeValue().trim());
					if (styleIndex < 0 || styleIndex > 9)
						throw new NumberFormatException();
				} catch (NumberFormatException e) {
					throw new TemplateLoadingException("Invalid template. Style index must be an integer between 0 and 9.");
				}
				String legend = legends == null || legendIndex > legends.size() - 1 ? "" : legends.get(legendIndex++);
				assist.add(new Object[] { index++, legend });
				rows.add(new Object[] { color, shape, thickness, styleIndex });
			}
			return seriesList.getLength();
		}
	}
	
	//--------------------------------------------------------------------------------------
	private static class ThicknessIcon implements Icon {
		
		//=================================================================================
		// members
		
		private float thickness = 0;
		
		//=================================================================================
		// methods
		
		//---------------------------------------------------------------------------------
		public ThicknessIcon(float thickness) { this.thickness = thickness; }
		
		//=================================================================================
		// implemented interfaces
		
		//---------------------------------------------------------------------------------
		public int getIconHeight() { return 16; }
		public int getIconWidth() { return 32; }
		
		//---------------------------------------------------------------------------------
		public void paintIcon(Component c, Graphics g, int x, int y) {
			Graphics2D g2d = (Graphics2D)g;
			g2d.setBackground(c.getBackground());
			g2d.setColor(Color.BLACK);
			g2d.setStroke(new BasicStroke(thickness));
			float yy = (16 - thickness)/2 + thickness/2;
			Line2D.Float line = new Line2D.Float(x+5f,y+yy,x+27,y+yy);
			g2d.draw(line);
		}
	}
	
	//--------------------------------------------------------------------------------------
	private static class StyleIcon implements Icon {
		
		//=================================================================================
		// members
		
		private float[] styleArray = null;
		
		//=================================================================================
		// methods
		
		//---------------------------------------------------------------------------------
		public StyleIcon(float[] styleArray) { this.styleArray = styleArray; }
		
		//=================================================================================
		// implemented interfaces
		
		//---------------------------------------------------------------------------------
		public int getIconHeight() { return 16; }
		public int getIconWidth() { return 96;	}
		
		//---------------------------------------------------------------------------------
		public void paintIcon(Component c, Graphics g, int x, int y) {
			Graphics2D g2d = (Graphics2D)g;
			g2d.setBackground(c.getBackground());
			g2d.setColor(Color.BLACK);
			g2d.setStroke(new BasicStroke(1.f,BasicStroke.CAP_SQUARE,BasicStroke.JOIN_MITER,10.f,styleArray,0.f));
			g2d.drawLine(x,y+8,x+96,y+8);
		}
	}
	
	//--------------------------------------------------------------------------------------
	private static class ShapeIcon implements Icon {
		
		//=================================================================================
		// members
		
		private Shape shape = null;
		
		//=================================================================================
		// methods
		
		//---------------------------------------------------------------------------------
		public ShapeIcon(Shape shape) { this.shape = shape; }
		
		//=================================================================================
		// implemented interfaces
		
		//---------------------------------------------------------------------------------
		public int getIconHeight() { return 16; }
		public int getIconWidth() { return 16; }
		
		//---------------------------------------------------------------------------------
		public void paintIcon(Component c, Graphics g, int x, int y) {
			Graphics2D g2d = (Graphics2D) g;
			g2d.setBackground(c.getBackground());
			g2d.setColor(Color.BLACK);
			g2d.translate(38,8); // This is a terrible fix of bug #1047. We use this, because the
								 // ordinary solution (setHorizontalAlignment()) doesn't work.
			g2d.scale(1.5,1.5);
			if (shape instanceof UnfilledShape) 
				g2d.draw(shape);
			else
				g2d.fill(shape);
		}
	}
	
	//-------------------------------------------------------------------------------------
	private static class ThicknessRenderer extends JLabel implements TableCellRenderer,
																	 ListCellRenderer {
		
		//=================================================================================
		// members
		
		private static final long serialVersionUID = 1L;
		private static TreeMap<Float,Icon> iconMap = new TreeMap<Float, Icon>();
		static {
			iconMap.put(0.5f,new ThicknessIcon(0.5f));
			iconMap.put(1.f,new ThicknessIcon(1.f));
			iconMap.put(1.5f,new ThicknessIcon(1.5f));
			iconMap.put(2.f,new ThicknessIcon(2.f));
			iconMap.put(2.5f,new ThicknessIcon(2.5f));
			iconMap.put(3.f,new ThicknessIcon(3.f));
			iconMap.put(3.5f,new ThicknessIcon(3.5f));
			iconMap.put(4.f,new ThicknessIcon(4.f));
			iconMap.put(4.5f,new ThicknessIcon(4.5f));
			iconMap.put(5.f,new ThicknessIcon(5.f));
		}
		
		//=================================================================================
		// implemented interfaces
		
		//---------------------------------------------------------------------------------
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			if (isSelected) {
				   setForeground(table.getSelectionForeground());
				   setBackground(table.getSelectionBackground());
			} else {
				   setForeground(table.getForeground());
				   setBackground(table.getBackground());
			}
				
			setFont(table.getFont());
			setBorder(null);
			
			if (hasFocus) {
		            Border border = null;
		            if (isSelected) 
		                border = UIManager.getBorder("Table.focusSelectedCellHighlightBorder");
		            if (border == null) 
		                border = UIManager.getBorder("Table.focusCellHighlightBorder");
		            setBorder(border);
		    }
			render(value);
			return this;
		}
		
		//---------------------------------------------------------------------------------
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
			if (isSelected) {
				   setForeground(list.getSelectionForeground());
				   setBackground(list.getSelectionBackground());
			} else {
				   setForeground(list.getForeground());
				   setBackground(list.getBackground());
			}
			setFont(list.getFont());
			render(value);
			return this;
		}
		
		//=================================================================================
		// private methods
		
		//---------------------------------------------------------------------------------
		@SuppressWarnings("cast")
		private void render(Object value) {
			setHorizontalAlignment(JLabel.CENTER);
			setIcon(iconMap.get((Float)value));
			setText(" " + value.toString());
		}
	}
	
	//-------------------------------------------------------------------------------------
	@SuppressWarnings("unused")
	private static class SizeRenderer extends JLabel implements TableCellRenderer,
																	 ListCellRenderer {
		
		//=================================================================================
		// members
		
		private static final long serialVersionUID = 1L;
		private static TreeMap<Double, String> sizeMap = new TreeMap<Double, String>();
		static {
			sizeMap.put(10d, "%");
			sizeMap.put(25d, "%");
			sizeMap.put(50d, "%");
			sizeMap.put(75d, "%");
			sizeMap.put(100d, "%");
		}
		
		//=================================================================================
		// implemented interfaces
		
		//---------------------------------------------------------------------------------
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			if (isSelected) {
				   setForeground(table.getSelectionForeground());
				   setBackground(table.getSelectionBackground());
			} else {
				   setForeground(table.getForeground());
				   setBackground(table.getBackground());
			}
				
			setFont(table.getFont());
			setBorder(null);
			
			if (hasFocus) {
		            Border border = null;
		            if (isSelected) 
		                border = UIManager.getBorder("Table.focusSelectedCellHighlightBorder");
		            if (border == null) 
		                border = UIManager.getBorder("Table.focusCellHighlightBorder");
		            setBorder(border);
		    }
			render(value);
			return this;
		}
		
		//---------------------------------------------------------------------------------
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
			if (isSelected) {
				   setForeground(list.getSelectionForeground());
				   setBackground(list.getSelectionBackground());
			} else {
				   setForeground(list.getForeground());
				   setBackground(list.getBackground());
			}
			setFont(list.getFont());
			//render(value);
			return this;
		}
		
		//=================================================================================
		// private methods
		
		//---------------------------------------------------------------------------------
		private void render(Object value) {
			
			setHorizontalAlignment(JLabel.CENTER);
			String t=value.toString();
			setText(t);
			if(sizePercentage!=Double.parseDouble(t)){
				sizePercentage=Double.parseDouble(t);
				PREDEFINED_SHAPES = createStandardSeriesShapes();
				
			}
		}
	}
	
	//--------------------------------------------------------------------------------------
	private static class StyleRenderer extends JLabel implements TableCellRenderer,
																 ListCellRenderer {
		
		//=================================================================================
		// members
		
		private static final long serialVersionUID = 1L;
		
		//=================================================================================
		// implemented interfaces
		
		//---------------------------------------------------------------------------------
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			if (isSelected) {
				  setForeground(table.getSelectionForeground());
				  setBackground(table.getSelectionBackground());
			} else {
				  setForeground(table.getForeground());
				  setBackground(table.getBackground());
			}
				
			setFont(table.getFont());
			setBorder(null);

			if (hasFocus) {
		            Border border = null;
		            if (isSelected) 
		                border = UIManager.getBorder("Table.focusSelectedCellHighlightBorder");
		            if (border == null) 
		                border = UIManager.getBorder("Table.focusCellHighlightBorder");
		            setBorder(border);
		    }
			setIcon(new StyleIcon(PREDEFINED_STYLES.get(((Long)value).intValue())));
			return this;
		}
		
		//---------------------------------------------------------------------------------
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
			if (isSelected) {
				  setForeground(list.getSelectionForeground());
				  setBackground(list.getSelectionBackground());
			} else {
				  setForeground(list.getForeground());
				  setBackground(list.getBackground());
			}
			setFont(list.getFont());
			setIcon(new StyleIcon(PREDEFINED_STYLES.get(((Long)value).intValue())));
			return this;
		}
	}
	
	//--------------------------------------------------------------------------------------
	private static class ShapeRenderer extends JLabel implements TableCellRenderer,
																 ListCellRenderer {
		
		//=================================================================================
		// members
		
		private static final long serialVersionUID = 1L;
		
		//=================================================================================
		// implemented interfaces
		
		//---------------------------------------------------------------------------------
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			if (isSelected) {
				  setForeground(table.getSelectionForeground());
				  setBackground(table.getSelectionBackground());
			} else {
				  setForeground(table.getForeground());
				  setBackground(table.getBackground());
			}
				
			setFont(table.getFont());
			setBorder(null);

			if (hasFocus) {
		            Border border = null;
		            if (isSelected) 
		                border = UIManager.getBorder("Table.focusSelectedCellHighlightBorder");
		            if (border == null) 
		                border = UIManager.getBorder("Table.focusCellHighlightBorder");
		            setBorder(border);
		    }
			renderValue(value,50);
			return this;
		}

		//---------------------------------------------------------------------------------
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
			if (isSelected) {
				  setForeground(list.getSelectionForeground());
				  setBackground(list.getSelectionBackground());
			} else {
				  setForeground(list.getForeground());
				  setBackground(list.getBackground());
			}
			setFont(list.getFont());
			renderValue(value,50);
			return this;
		}
		
		//=================================================================================
		// private methods
		
		//---------------------------------------------------------------------------------
		private void renderValue(Object value, int halfsize) {
			setToolTipText(null);
			if (value instanceof UniversalShape) {
				UniversalShape us = (UniversalShape) value;
				Object val = us.value();
				if (val == null) return;
				if (val instanceof Integer) {
					int shape = (Integer) val;
					setText(null);
					setIcon(new ShapeIcon(PREDEFINED_SHAPES[shape]));
				} else if (val instanceof Class) {
					Class clazz = (Class) val;
					setText(clazz.getName());
					setToolTipText(clazz.getName());
					setIcon(null);
				} else {
					setText(val.toString());
					setIcon(null);
				}
			}
		}
	}
	
	//--------------------------------------------------------------------------------------
	private static class UniversalShape {
		
		//=================================================================================
		// members
		
		private Object value = null;
		
		//=================================================================================
		// methods
		
		//---------------------------------------------------------------------------------
		public UniversalShape(Integer shape) { value = shape; }
		public UniversalShape(Class clazz) { value = clazz; }
		public UniversalShape(String string) { value = string; }
		
		//---------------------------------------------------------------------------------
		public Object value() { return value; }
		
		//---------------------------------------------------------------------------------
		@Override public boolean equals(Object o) {
			if (o == null) return false;
			if (o instanceof UniversalShape) {
				UniversalShape that = (UniversalShape) o;
				return that.value.equals(this.value);
			}
			return false;
		}
	}
	
	//--------------------------------------------------------------------------------------
	private static class ColorRenderer extends JLabel implements TableCellRenderer {
		
		//=================================================================================
		// members
		
		private static final long serialVersionUID = 1L;
		
		//=================================================================================
		// methods
		
		//---------------------------------------------------------------------------------
		public ColorRenderer() { super(); setOpaque(true); }
		
		//=================================================================================
		// implemented interfaces
		
		//---------------------------------------------------------------------------------
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			if (isSelected) {
				setForeground(table.getSelectionForeground());
				setBackground(table.getSelectionBackground());
			} else {
				setForeground(table.getForeground());
				setBackground(table.getBackground());
			}
			setBorder(null);
			if (hasFocus) {
		            Border border = null;
		            if (isSelected) 
		                border = UIManager.getBorder("Table.focusSelectedCellHighlightBorder");
		            if (border == null) 
		                border = UIManager.getBorder("Table.focusCellHighlightBorder");
		            setBorder(border);
		    }
			setHorizontalAlignment(JLabel.CENTER);
			if (value == null) {
				setFont(table.getFont());
				setText("N/A");
			} else {
				Color color = (Color)value;
				setText(Utilities.colorText(color,10));
			}
			return this;
		}
	}
}