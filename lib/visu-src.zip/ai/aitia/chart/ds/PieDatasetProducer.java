/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.ds;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.jfree.data.general.Dataset;

import ai.aitia.visu.data.DefaultPieDataset;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDatasetProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.event.IDataChangeListener;

/** Dataset producer for bar charts. */
public class PieDatasetProducer implements IDatasetProducer, IDataChangeListener {

	/** Time of the last update. */
	private long time;
	
	/** The dataset that this object produces. */
	private DefaultPieDataset dataset = null;
	
	/** Producer for categories. */
	private IStringListProducer categories = null;
	
	/** The current produced id values for categories. */
	private List<String> category_series = null;
	
	/** The names of the data rows. */
	private String[] datarow_names = null;
	
	/** Series producers for the data rows indexed with intergers. */ 
	private HashMap<ISeriesProducer,Integer> datarows = null;
	
	/** The current produced values for the data rows indexed with integers. */  
	private List<List<Double>> datarow_series = null;
	
	/** The next free index value. */
	private int currentIndex;
	
	//===============================================================================
	// methods

	/** Constructor. The size of <code>datarow_names</code> and <code>datarows</code>
	 *  must be equal. 
	 * @param categories producer for categories
	 * @param datarow_names list of data row names
	 * @param datarows list of producers
	 */
	public PieDatasetProducer(IStringListProducer categories, List<String> datarow_names, List<ISeriesProducer> datarows ) throws DataSourceException {

		if (datarow_names.size() != datarows.size()) {
			throw new DataSourceException("The number of data row names and producers must be equal");
		}
		currentIndex = 0;
		time = System.currentTimeMillis();
		dataset = new DefaultPieDataset();
		
		this.categories = categories;
		this.categories.addDataChangeListener(this);
		this.datarow_names = datarow_names.toArray(new String[0]);
		this.datarows = new HashMap<ISeriesProducer,Integer>();
		this.datarow_series = new ArrayList<List<Double>>();
		Iterator<ISeriesProducer> it = datarows.iterator();
		while (it.hasNext()) {
			ISeriesProducer item = it.next();
			item.addDataChangeListener(this);
			this.datarows.put(item,new Integer(currentIndex++));
			datarow_series.add(new ArrayList<Double>(0));
		}
	}
	
	
	//----------------------------------------------------------------------------------------------------
	public PieDatasetProducer(List<String> datarow_names, List<ISeriesProducer> datarows) throws DataSourceException {
		if (datarow_names.size() != datarows.size()) {
			throw new DataSourceException("The number of data row names and producers must be equal");
		}
		currentIndex = 0;
		time = System.currentTimeMillis();
		dataset = new DefaultPieDataset();
		this.datarow_names = datarow_names.toArray(new String[0]);
		this.datarows = new HashMap<ISeriesProducer,Integer>();
		this.datarow_series = new ArrayList<List<Double>>();
		for (ISeriesProducer p : datarows) {
			p.addDataChangeListener(this);
			this.datarows.put(p,currentIndex++);
			datarow_series.add(new ArrayList<Double>(0));
		}
		this.categories = null;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the time of the last update.
	 * @return the time of the last update
	 */
	public long getTime() {
		return time;
	}

	//-------------------------------------------------------------------------------
	/** Produces the dataset. This implementation of the method does not use the <code>
	 *  queryProperties</code> parameter and does not throw exception.
	 */  
	public Dataset produceDataset(Properties queryProperties)
			throws DataSourceException {
		return dataset;
	}
	
	//--------------------------------------------------------------------------------
	/** Updates the dataset.
	 * @param event event
	 */
	public void dataChanged(DataChangeEvent event) {
		
		Object source = event.getSource();
		if (source.equals(categories)) {
			IStringListProducer p = (IStringListProducer)source;
			category_series = p.produceStringList();
			time = p.getTime();
		} else if (source instanceof ISeriesProducer) {
			ISeriesProducer p = (ISeriesProducer)source;
			int index = datarows.get(p);
			datarow_series.remove(index);
			List<Double> series = p.produceSeries();
			datarow_series.add(index,series);
			time = p.getTime();
		} else return;
		
		dataset.clear();
		
		for (int i=0;i<datarow_names.length;++i) {
			List<Double> values = datarow_series.get(i);
			if (categories == null) {
				for (int j = 0; j < values.size();++j)
					dataset.setValue(String.valueOf(j),values.get(j));
			}else{
				int length = (category_series.size() > values.size() ? values.size() : category_series.size());
				for (int j=0;j<length;++j) {
					dataset.setValue(category_series.get(j), values.get(j));
				}	
			}
			
		}
		dataset.fireDatasetChanged();
	}

}