package ai.aitia.chart.charttypes.dialogs.components;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.MultiGrid2DDialog.GridDescriptor;
import ai.aitia.chart.charttypes.dialogs.MultiGrid2DDialog.GridLayer;
import ai.aitia.chart.ds.IGrid2DDatasetProducer;
import ai.aitia.chart.util.Utilities;
import ai.aitia.meme.utils.FormsUtils;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.globalhandlers.UserBreakException;
import ai.aitia.visu.utils.Utils;
import ai.aitia.visu.view.ui.ColorMapFigureRenderer;
import ai.aitia.visu.view.ui.IFigureRenderer;

import com.jgoodies.forms.layout.CellConstraints;

public class GridLayerDialog extends JDialog implements ActionListener,
														FocusListener,
														ChangeListener,
														CaretListener,
														IColorMapUser,
														IShapeRendererUser {
	
	//====================================================================================================
	// members
	
	private static final long serialVersionUID = 1L;
	
	private static final String COLOR_MENU_TEXT = "Define a color...";
	
	/** Constant label text for series producers. */
	private static final String DEFAULT_TEXT = "Dimensions (one of them is mandatory)";
	
	/** Constant label text for dataset producers. */
	private static final String SPECIAL_TEXT = "Dimensions from the complete grid";  //  @jve:decl-index=0:

	/** Return value constant: indicates that the user closes the dialog by pressing Cancel button (or 'x' in the right top corner). */
	public static final int CANCEL_OPTION = -1;
	/** Return value constant: indicates that the user closes the dialog by pressing OK button. */
	public static final int OK_OPTION = 0;
	
	private ChartConfig config = null;

	private int returnValue = CANCEL_OPTION;
	private GridLayer gridLayer = null;
	
	/** Flag that determines the mode of the chart (sequential or random). */
	private boolean is_full = true;
	
	/** Flag that determines the kind of the width parameter in sequential mode. */
	private boolean user_defined_width = false;
	
	/** Flag that determines the kind of the height parameter in sequential mode. */
	private boolean user_defined_height = false;
	
	/** Flag that determines the kind of the width parameter in random mode. */
	private boolean r_user_defined_width = true;
	
	/** Flag that determines the kind of the height parameter in random mode. */
	private boolean r_user_defined_height = true;

	private Pattern positivePattern = null;
	
	
	//====================================================================================================
	// GUI members
	
	private JPanel content = new JPanel();
	
	private JPanel topPanel = new JPanel(new CardLayout());
	
	private JPanel fullPanel = null;
	private JPanel fFirstPanel = new JPanel(new GridLayout(1,0));
	private JPanel fValuePanel = null;
	private JComboBox fValueParam = new JComboBox();
	private JButton fValueAdvancedButton = new JButton("Advanced...");
	private JPanel fSwitchPanel = null;
	private JButton fSwitchButton = new JButton("Switch to random filling");
	private JPanel fSecondPanel = null;
	private JPanel fWidthPanel = new JPanel(new CardLayout());
	private JLabel fWidthLabel = new JLabel(" Width:");
	private JComboBox fWidthParam = new JComboBox();
	private JTextField fWidthField = new JTextField("10"); 
	private JButton fWidthButton = new JButton("From user input");
	private JPanel fHeightPanel = new JPanel(new CardLayout());
	private JLabel fHeightLabel = new JLabel("Height:");
	private JComboBox fHeightParam = new JComboBox();
	private JTextField fHeightField = new JTextField("10");
	private JButton fHeightButton = new JButton("From user input");
	private JPanel fThirdPanel = null;
	private JLabel orderLabel = new JLabel(" Filling order:");
	private JRadioButton fLeftToRightButton = new JRadioButton("Left-to-Right");
	private JRadioButton fTopToBottomButton = new JRadioButton("Top-to-Bottom");
	
	private JPanel partialPanel = null;
	private JPanel pFirstPanel = new JPanel(new GridLayout(2,0));
	private JPanel pXPanel = null;
	private JComboBox pXParam = new JComboBox();
	private JButton pXAdvancedButton = new JButton("Advanced...");
	private JPanel pSwitchPanel = null;
	private JButton pSwitchButton = new JButton("Switch to sequential filling");
	private JPanel pYPanel = null;
	private JComboBox pYParam = new JComboBox();
	private JButton pYAdvancedButton = new JButton("Advanced...");
	private JPanel pValuePanel = null;
	private JComboBox pValueParam = new JComboBox();
	private JButton pValueAdvancedButton = new JButton("Advanced...");
	private JPanel pSecondPanel = null;
	private JPanel pWidthPanel = new JPanel(new CardLayout());
	private JComboBox pWidthParam = new JComboBox();
	private JTextField pWidthField = new JTextField();
	private JButton pWidthButton = new JButton("From data source");
	private JPanel 	pHeightPanel = new JPanel(new CardLayout());
	private JComboBox pHeightParam = new JComboBox();
	private JTextField pHeightField = new JTextField();
	private JButton pHeightButton = new JButton("From data source");
	
	private JPanel bottomPanel = null;
	private JRadioButton colorMapButton = new JRadioButton("Colormaps");
	private JCheckBox globalTransparencyBox = new JCheckBox("Use global transparency value");
	private JLabel opaqueLabel = new JLabel("Opaque");
	private JSlider transparencySlider = new JSlider(0,100,50);
	private JLabel transparentLabel = new JLabel("Transparent");
	private ColorMapPanel colorMapPanel = new ColorMapPanel(this); 
	private JRadioButton shapeRendererButton = new JRadioButton("Shape renderers");
	private ShapeRendererPanel shapeRendererPanel = new ShapeRendererPanel(this); 
	
	private JPanel buttonsPanel = new JPanel();
	private JButton okButton = new JButton("Ok");
	private JButton cancelButton = new JButton("Cancel");
	
	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public GridLayerDialog(Frame owner, ChartConfig config) {
		super(owner,"Grid layer editor",true);
		this.config = config;
		layoutGUI();
		initialize();
		setWidgetDisabled();
		setLocationRelativeTo(owner);
	}
	
	//----------------------------------------------------------------------------------------------------
	public GridLayerDialog(Frame owner, ChartConfig config, GridLayer gridLayer) {
		this(owner,config);
		this.gridLayer = gridLayer;
		setSettingsFromEditedLayer();
	}
	
	//---------------------------------------------------------------------------------------
	/** Shows the dialog.
	 * @return an int that indicates the closing mode of the dialog
	 */
	public int showDialog() {
		setVisible(true);
		int result = returnValue;
		dispose();
		return result;
	}
	
	//----------------------------------------------------------------------------------------------------
	public GridLayer getGridLayer() { return gridLayer; }
	
	//====================================================================================================
	// implemented interfaces

	//----------------------------------------------------------------------------------------------------
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("F_VALUE_PARAM".equals(command)) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam.getSelectedItem();
			fValueParam.setToolTipText(dsp.toString());
			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {
				fThirdPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
				setEnabledDOWidgets(false);
				if (isWellDefined())
					okButton.setEnabled(true);
			} else {
				fThirdPanel.setBorder(BorderFactory.createTitledBorder(DEFAULT_TEXT));
				setEnabledDOWidgets(true);
				boolean w_valid = (user_defined_width && is_valid(fWidthField.getText())) || (!user_defined_width && fWidthParam.getItemCount() > 0);
				boolean h_valid = (user_defined_height && is_valid(fHeightField.getText())) || (!user_defined_height && fHeightParam.getItemCount() > 0);
				if (!w_valid && !h_valid) 
					okButton.setEnabled(false);
			}
			
			try {
				@SuppressWarnings("unchecked")
				List<Double> list = (List<Double>) ChartConfigCollection.
																	getLOPExecutor().execute("Calculating minimum/maximum values",dsp,"getRange");
				setMinMax(list);
			} catch (UserBreakException e1) { 
				setMinMax(null);
			} catch (Throwable t) {
				ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
			}
		} else if ("F_VALUE_ADVANCED".equals(command))
			advanced(fValueParam,this);
		else if ("F_SWITCH_BUTTON".equals(command)) {
			CardLayout cl = (CardLayout) topPanel.getLayout();
			cl.show(topPanel,"PARTIAL_PANEL");
			is_full = false;
			if (pXParam.getItemCount() > 0 && pYParam.getItemCount() > 0 && pValueParam.getItemCount() > 1 && isWellDefined()) 
				okButton.setEnabled(true);
			if (pValueParam.getSelectedItem() instanceof Color) {
				setEnabledVisualisation(false);
				colorMapPanel.defineConstantColorMap((Color)pValueParam.getSelectedItem());
			}
		} else if ("F_WIDTH_PARAM".equals(command)) 
			tooltip(fWidthParam);
		else if ("F_WIDTH_BUTTON".equals(command)) {
			fWidthButton.setText(user_defined_width ? "From user input" : "From data source");
			user_defined_width ^= true; // negating
			CardLayout cl = (CardLayout) fWidthPanel.getLayout();
			cl.show(fWidthPanel,user_defined_width ? "F_WIDTH_FIELD" : "F_WIDTH_PARAM");
			okButton.setEnabled(isWellDefined());
		} else if ("F_HEIGHT_PARAM".equals(command)) 
			tooltip(fHeightParam);
		else if ("F_HEIGHT_BUTTON".equals(command)) {
			fHeightButton.setText(user_defined_height ? "From user input" : "From data source");
			user_defined_height ^= true; // negating
			CardLayout cl = (CardLayout) fHeightPanel.getLayout();
			cl.show(fHeightPanel,user_defined_height ? "F_HEIGHT_FIELD" : "F_HEIGHT_PARAM");
			okButton.setEnabled(isWellDefined());
		} else if ("P_X_PARAM".equals(command)) {
			IDataSourceProducer dsp = (IDataSourceProducer) pXParam.getSelectedItem();
			pXParam.setToolTipText(dsp.toString());
			pXAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		} else if ("P_X_ADVANCED".equals(command)) 
			advanced(pXParam,this);
		else if ("P_SWITCH_BUTTON".equals(command)) {
			CardLayout cl = (CardLayout) topPanel.getLayout();
			cl.show(topPanel,"FULL_PANEL");
			is_full = true;
			if (fValueParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) fValueParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(ISeriesProducer.class)) {
					boolean w_valid = (user_defined_width && is_valid(fWidthField.getText())) || (!user_defined_width && fWidthParam.getItemCount() > 0);
					boolean h_valid = (user_defined_height && is_valid(fHeightField.getText())) || (!user_defined_height && fHeightParam.getItemCount() > 0);
					if (!w_valid && !h_valid) 
						okButton.setEnabled(false);
				}
			}
			setEnabledVisualisation(true);
			colorMapPanel.reloadCombobox(false,"");
			colorMapPanel.setEnabled(true);
		} else if ("P_Y_PARAM".equals(command)) {
			IDataSourceProducer dsp = (IDataSourceProducer) pYParam.getSelectedItem();
			pYParam.setToolTipText(dsp.toString());
			pYAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		} else if ("P_Y_ADVANCED".equals(command))
			advanced(pYParam,this);
		else if ("P_VALUE_PARAM".equals(command)) {
			final Object selectedItem = pValueParam.getSelectedItem();
			pValueParam.setToolTipText(selectedItem.toString());
			if (selectedItem instanceof IDataSourceProducer) {
				IDataSourceProducer dsp = (IDataSourceProducer) pValueParam.getSelectedItem();
				pValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
				setEnabledVisualisation(true);
				colorMapPanel.resetColorMapPanel(false); 
				
				try {
					@SuppressWarnings("unchecked") List<Double> list = (List<Double>) ChartConfigCollection.getLOPExecutor().
																						execute("Calculating minimum/maximum values",dsp,"getRange");
					setMinMax(list);
				} catch (UserBreakException e1) { 
					setMinMax(null);
				} catch (Throwable t) {
					ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
				}
			} else if (selectedItem instanceof Color) {
				final Color color = (Color) selectedItem;
				pValueAdvancedButton.setEnabled(false);
				setEnabledVisualisation(false);
				colorMapPanel.defineConstantColorMap(color);
			} else if (selectedItem instanceof String) 
				handleColorMenu(selectedItem.toString());
		} else if ("P_VALUE_ADVANCED".equals(command)) 
			advanced(pValueParam,this);
		else if ("P_WIDTH_PARAM".equals(command)) 
			tooltip(pWidthParam);
		else if ("P_WIDTH_BUTTON".equals(command)) {
			pWidthButton.setText(r_user_defined_width ? "From user input" : "From data source");
			r_user_defined_width ^= true; // negating
			CardLayout cl = (CardLayout) pWidthPanel.getLayout();
			cl.show(pWidthPanel,r_user_defined_width ? "P_WIDTH_FIELD" : "P_WIDTH_PARAM");
		} else if ("P_HEIGHT_PARAM".equals(command)) 
			tooltip(pHeightParam);
		else if ("P_HEIGHT_BUTTON".equals(command)) {
			pHeightButton.setText(r_user_defined_height ? "From user input" : "From data source");
			r_user_defined_height ^= true; // negating
			CardLayout cl = (CardLayout) pHeightPanel.getLayout();
			cl.show(pHeightPanel,r_user_defined_height ? "P_HEIGHT_FIELD" : "P_HEIGHT_PARAM");
		} else if ("COLORMAP_BUTTON".equals(command)) {
			globalTransparencyBox.setEnabled(true);
			if (globalTransparencyBox.isSelected()) {
				opaqueLabel.setVisible(true);
				transparencySlider.setVisible(true);
				transparentLabel.setVisible(true);
			}
			colorMapPanel.setEnabled(true);
			
			shapeRendererPanel.setEnabled(false);
			okButton.setEnabled(isWellDefined());
		} else if ("GLOBAL_TRANSPARENCY".equals(command)) {
			opaqueLabel.setVisible(globalTransparencyBox.isSelected());
			transparencySlider.setVisible(globalTransparencyBox.isSelected());
			transparentLabel.setVisible(globalTransparencyBox.isSelected());
		} else if ("SHAPE_RENDERER_BUTTON".equals(command)) {
			globalTransparencyBox.setEnabled(false);
			opaqueLabel.setVisible(false);
			transparencySlider.setVisible(false);
			transparentLabel.setVisible(false);
			colorMapPanel.setEnabled(false);
			shapeRendererPanel.setEnabled(true);
			okButton.setEnabled(isWellDefined());
		} else if ("OK".equals(command)) {
			createGridLayer();
			returnValue = OK_OPTION;
			setVisible(false);
		} else if ("CANCEL".equals(command)) {
			returnValue = CANCEL_OPTION;
			setVisible(false);
		}
	}

	//----------------------------------------------------------------------------------------------------
	public void focusGained(FocusEvent e) {}
	
	//----------------------------------------------------------------------------------------------------
	public void focusLost(FocusEvent e) {
		if (fWidthField.equals(e.getSource())) {
			if (!is_valid(fWidthField.getText())) {
				fWidthField.setText("");
				okButton.setEnabled(isWellDefined());
			}
		} else if (fHeightField.equals(e.getSource())) {
			if (!is_valid(fHeightField.getText())) {
				fHeightField.setText("");
				okButton.setEnabled(isWellDefined());
			}
		} else if (pWidthField.equals(e.getSource())) {
			if (!is_valid(pWidthField.getText()))
				pWidthField.setText("");
		} else if (pHeightField.equals(e.getSource())) {
			if (!is_valid(pHeightField.getText()))
				pHeightField.setText("");
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void stateChanged(ChangeEvent e) {
		transparencySlider.setToolTipText(transparencySlider.getValue() + " %");
	}
	
	//----------------------------------------------------------------------------------------------------
	public void caretUpdate(CaretEvent e) {
		okButton.setEnabled(isWellDefined());
	}

	//----------------------------------------------------------------------------------------------------
	public IDataSourceProducer getColorValueProducer() {
		final Object selectedObject = is_full ? fValueParam.getSelectedItem() : pValueParam.getSelectedItem();
		if (selectedObject instanceof IDataSourceProducer) {
			final IDataSourceProducer selected = (IDataSourceProducer) selectedObject;
			return selected;
		}
		return null;
	}
	
	//----------------------------------------------------------------------------------------------------
	public void setUpdateStatus(boolean status) {
		boolean paramAvailable = isWellDefined();
		if (shapeRendererButton.isSelected())
			okButton.setEnabled(paramAvailable && shapeRendererPanel.hasDefinedRenderer());
		else
			okButton.setEnabled(paramAvailable && colorMapPanel.hasDefinedColormap());
	}

	//----------------------------------------------------------------------------------------------------
	public IDataSourceProducer getShapeValueProducer() {
		return (IDataSourceProducer) (is_full ? fValueParam.getSelectedItem() : pValueParam.getSelectedItem());
	}
	
	//====================================================================================================
	// GUI methods
	
	//----------------------------------------------------------------------------------------------------
	private void layoutGUI() {
		content.setLayout(new BoxLayout(content,BoxLayout.Y_AXIS));
		fValuePanel = FormsUtils.build("f:p:g ~ p",
									   "01",
									   fValueParam,fValueAdvancedButton).getPanel();
		fFirstPanel.add(fValuePanel);
		
		fSwitchPanel = FormsUtils.build("p:g p",
										"_0",
										fSwitchButton,CellConstraints.RIGHT).getPanel();
		fFirstPanel.add(fSwitchPanel);
		
		fWidthParam.setName("F_WIDTH_PARAM");
		fWidthPanel.add(fWidthParam,fWidthParam.getName());
		fWidthField.setName("F_WIDTH_FIELD");
		fWidthPanel.add(fWidthField,fWidthField.getName());
		
		fHeightParam.setName("F_HEIGHT_PARAM");
		fHeightPanel.add(fHeightParam,fHeightParam.getName());
		fHeightField.setName("F_HEIGHT_FIELD");
		fHeightPanel.add(fHeightField,fHeightField.getName());
		
		fSecondPanel = FormsUtils.build("p ~ p:g ~ p ~ ~ p ~ p:g ~ p",
										"012345",
										fWidthLabel,fWidthPanel,fWidthButton,fHeightLabel,fHeightPanel,fHeightButton).getPanel();
		
		fThirdPanel = FormsUtils.build("p ~ p ~ p",
									   "012|", 
									   orderLabel,fLeftToRightButton,
									   fTopToBottomButton).getPanel();
		
		fullPanel = FormsUtils.build("p:g",
									 "|0|" +
									  "1|" +
									  "2|" +
									  "_ f:p:g",
									  fFirstPanel,
									  fSecondPanel,
									  fThirdPanel).getPanel();
		fullPanel.setName("FULL_PANEL");
		topPanel.add(fullPanel,fullPanel.getName());
		
		pXPanel = FormsUtils.build("f:p:g ~ p",
								   "01",
								   pXParam,pXAdvancedButton).getPanel();
		pFirstPanel.add(pXPanel);
		
		pSwitchPanel = FormsUtils.build("p:g p",
										"_0",
										pSwitchButton,CellConstraints.RIGHT).getPanel();
		pFirstPanel.add(pSwitchPanel);
		
		pYPanel = FormsUtils.build("f:p:g ~ p",
								   "01",
								   pYParam,pYAdvancedButton).getPanel();
		pFirstPanel.add(pYPanel);
		
		pValuePanel = FormsUtils.build("f:p:g ~ p",
									   "01",
									   pValueParam,pValueAdvancedButton).getPanel();
		pFirstPanel.add(pValuePanel);
		
		pWidthField.setName("P_WIDTH_FIELD");
		pWidthPanel.add(pWidthField,pWidthField.getName());
		pWidthParam.setName("P_WIDTH_PARAM");
		pWidthPanel.add(pWidthParam,pWidthParam.getName());
		
		pHeightField.setName("P_HEIGHT_FIELD");
		pHeightPanel.add(pHeightField,pHeightField.getName());
		pHeightParam.setName("P_HEIGHT_PARAM");
		pHeightPanel.add(pHeightParam,pHeightParam.getName());
		
		pSecondPanel = 	FormsUtils.build("p ~ p:g ~ p ~ ~ p ~ p:g ~ p",
										 "012345",
										 " Width:",pWidthPanel,pWidthButton,"Height:",pHeightPanel,pHeightButton).getPanel();
		
		partialPanel = FormsUtils.build("p:g",
										"|0|" +
										 "1|" +
										 "_ f:p:g",
										 pFirstPanel,
										 pSecondPanel).getPanel();
		
		partialPanel.setName("PARTIAL_PANEL");
		topPanel.add(partialPanel,partialPanel.getName());
		content.add(topPanel);
		
		bottomPanel = FormsUtils.build("p ~ p ~ p ~ p:g ~ p",
									   "00___||" +
									   "_1234||" +
									   "_5555||" +
									   "66___||" +
									   "_7777|" +
									   "_____ f:p:g",
									   colorMapButton,
									   globalTransparencyBox,opaqueLabel,transparencySlider,transparentLabel,
									   colorMapPanel,
									   shapeRendererButton,
									   shapeRendererPanel).getPanel();
		
		content.add(bottomPanel);
		
		content.add(new JSeparator(JSeparator.VERTICAL));
		buttonsPanel.add(okButton);
		buttonsPanel.add(cancelButton);
		content.add(buttonsPanel);
		
		this.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				returnValue = CANCEL_OPTION;
			}
		});
	}
	
	//----------------------------------------------------------------------------------------------------
	private void initialize() {
		content.setBorder(BorderFactory.createEmptyBorder(3,3,3,3));
		
		fSecondPanel.setBorder(BorderFactory.createTitledBorder(DEFAULT_TEXT));

		fValuePanel.setBorder(BorderFactory.createTitledBorder("Values / Complete grid"));
		fValueParam.setModel(new DefaultComboBoxModel(getParamsToValues()));
		fValueParam.setRenderer(new DataSourceComboBoxRenderer(fValueParam));
		fValueParam.setPreferredSize(new Dimension(200,26));
		if (fValueParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam.getSelectedItem();
			fValueParam.setToolTipText(dsp.toString());
			fValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			
			if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) {  
				setEnabledDOWidgets(false);
				fSecondPanel.setBorder(BorderFactory.createTitledBorder(SPECIAL_TEXT));
			}
		}
		fValueParam.setActionCommand("F_VALUE_PARAM");
		fValueAdvancedButton.setActionCommand("F_VALUE_ADVANCED");
		
		fSwitchPanel.setBorder(BorderFactory.createTitledBorder("Grid filling mode: sequential"));
		fSwitchButton.setActionCommand("F_SWITCH_BUTTON");
		
		fWidthParam.setModel(new DefaultComboBoxModel(getParamsToDimensions()));
		fWidthParam.setRenderer(new DataSourceComboBoxRenderer(fWidthParam));
		fWidthParam.setPreferredSize(new Dimension(100,26));
		if (fWidthParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fWidthParam.getSelectedItem();
			fWidthParam.setToolTipText(dsp.toString());
		}
		fWidthParam.setActionCommand("F_WIDTH_PARAM");
		
		fWidthField.setHorizontalAlignment(JTextField.TRAILING);
		fWidthField.addCaretListener(this);
		fWidthField.addFocusListener(this);
		
		fWidthButton.setActionCommand("F_WIDTH_BUTTON");
		
		fHeightParam.setModel(new DefaultComboBoxModel(getParamsToDimensions()));
		fHeightParam.setRenderer(new DataSourceComboBoxRenderer(fHeightParam));
		fHeightParam.setPreferredSize(new Dimension(100,26));
		if (fHeightParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) fHeightParam.getSelectedItem();
			fHeightParam.setToolTipText(dsp.toString());
		}
		fHeightParam.setActionCommand("F_HEIGHT_PARAM");
		
		fHeightField.setHorizontalAlignment(JTextField.TRAILING);
		fHeightField.addCaretListener(this);
		fHeightField.addFocusListener(this);
		
		fHeightButton.setActionCommand("F_HEIGHT_BUTTON");
		
		fThirdPanel.setBorder(BorderFactory.createTitledBorder("Order"));
		ButtonGroup g = new ButtonGroup();
		g.add(fLeftToRightButton);
		g.add(fTopToBottomButton);
		fLeftToRightButton.setSelected(true);
		
		pXPanel.setBorder(BorderFactory.createTitledBorder("X coordinates"));
		pXParam.setModel(new DefaultComboBoxModel(getParamsToAll()));
		pXParam.setRenderer(new DataSourceComboBoxRenderer(pXParam));
		pXParam.setPreferredSize(new Dimension(200,26));
		if (pXParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) pXParam.getSelectedItem();
			pXParam.setToolTipText(dsp.toString());
			pXAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		}
		pXParam.setActionCommand("P_X_PARAM");
		pXAdvancedButton.setActionCommand("P_X_ADVANCED");
		
		pSwitchPanel.setBorder(BorderFactory.createTitledBorder("Grid filling mode: random"));
		pSwitchButton.setActionCommand("P_SWITCH_BUTTON");
		
		pYPanel.setBorder(BorderFactory.createTitledBorder("Y coordinates"));
		pYParam.setModel(new DefaultComboBoxModel(getParamsToAll()));
		pYParam.setRenderer(new DataSourceComboBoxRenderer(pYParam));
		pYParam.setPreferredSize(new Dimension(200,26));
		if (pYParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) pYParam.getSelectedItem();
			pYParam.setToolTipText(dsp.toString());
			pYAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		}
		pYParam.setActionCommand("P_Y_PARAM");
		pYAdvancedButton.setActionCommand("P_Y_ADVANCED");
		
		pValuePanel.setBorder(BorderFactory.createTitledBorder("Values"));		
		pValueParam.setModel(new DefaultComboBoxModel(getParamsToColor()));
		pValueParam.setRenderer(new DataSourceComboBoxRenderer(pValueParam));
		pValueParam.setPreferredSize(new Dimension(200,26));
		if (pValueParam.getItemCount() > 1) {
			pValueParam.setToolTipText(pValueParam.getSelectedItem().toString());
			if (pValueParam.getSelectedItem() instanceof IDataSourceProducer) {
				IDataSourceProducer dsp = (IDataSourceProducer) pValueParam.getSelectedItem();
				pValueAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		pValueParam.setActionCommand("P_VALUE_PARAM");
		pValueAdvancedButton.setActionCommand("P_VALUE_ADVANCED");
		
		pSecondPanel.setBorder(BorderFactory.createTitledBorder("Dimensions (optional)"));
		
		pWidthParam.setModel(new DefaultComboBoxModel(getParamsToDimensions()));
		pWidthParam.setRenderer(new DataSourceComboBoxRenderer(pWidthParam));
		pWidthParam.setPreferredSize(new Dimension(100,26));
		if (pWidthParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) pWidthParam.getSelectedItem();
			pWidthParam.setToolTipText(dsp.toString());
		}
		pWidthParam.setActionCommand("P_WIDTH_PARAM");
		
		pWidthField.setHorizontalAlignment(JTextField.TRAILING);
		pWidthField.addFocusListener(this);
		
		pWidthButton.setActionCommand("P_WIDTH_BUTTON");
		
		pHeightParam.setModel(new DefaultComboBoxModel(getParamsToDimensions()));
		pHeightParam.setRenderer(new DataSourceComboBoxRenderer(pHeightParam));
		pHeightParam.setPreferredSize(new Dimension(100,26));
		if (pHeightParam.getItemCount() > 0) {
			IDataSourceProducer dsp = (IDataSourceProducer) pHeightParam.getSelectedItem();
			pHeightParam.setToolTipText(dsp.toString());
		}
		pHeightParam.setActionCommand("P_HEIGHT_PARAM");
		
		pHeightField.setHorizontalAlignment(JTextField.TRAILING);
		pHeightField.addFocusListener(this);
		
		pHeightButton.setActionCommand("P_HEIGHT_BUTTON");	
		
		bottomPanel.setBorder(BorderFactory.createTitledBorder("Value visualisation"));
		
		g = new ButtonGroup();
		g.add(colorMapButton);
		g.add(shapeRendererButton);
		
		colorMapButton.setSelected(true);
		colorMapButton.setActionCommand("COLORMAP_BUTTON");
		globalTransparencyBox.setActionCommand("GLOBAL_TRANSPARENCY");
		globalTransparencyBox.setPreferredSize(new Dimension(200,26));
		opaqueLabel.setVisible(false);
		transparencySlider.setVisible(false);
		transparencySlider.setToolTipText("50 %");
		transparencySlider.addChangeListener(this);
		transparentLabel.setVisible(false);
		colorMapPanel.setPreferredSize(new Dimension(400,26));
		
		shapeRendererButton.setActionCommand("SHAPE_RENDERER_BUTTON");
		shapeRendererPanel.setPreferredSize(new Dimension(400,52));
		shapeRendererPanel.setEnabled(false);
		
		okButton.setActionCommand("OK");
		cancelButton.setActionCommand("CANCEL");
		
		Utilities.addActionListener(this,fValueParam,fValueAdvancedButton,fSwitchButton,
									fWidthParam,fWidthButton,fHeightParam,fHeightButton,
									pXParam,pXAdvancedButton,pSwitchButton,pYParam,
									pYAdvancedButton,pValueParam,pValueAdvancedButton,
									pWidthParam,pWidthButton,pHeightPanel,pHeightButton,
									colorMapButton,globalTransparencyBox,shapeRendererButton,
									okButton,cancelButton);
		
		final JScrollPane sp = new JScrollPane(content,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		sp.setBorder(null);
		this.setContentPane(sp);
		this.pack();
		Dimension oldD = this.getPreferredSize();
		this.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
								     		oldD.height + sp.getHorizontalScrollBar().getHeight()));
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		oldD = this.getPreferredSize();
		final Dimension newD = Utils.getPreferredSize(this);
		if (!oldD.equals(newD)) 
			this.setPreferredSize(newD);
		this.pack();
	}
	
	//----------------------------------------------------------------------------------------------------
	private void setSettingsFromEditedLayer() {
		GridDescriptor descriptor = gridLayer.getDescriptor();
		if (descriptor.dataSources.size() == 1) { // one datasource, full mode
 				is_full = true;
 				IDataSourceProducer dsp = descriptor.dataSources.get(0);
 				fValueParam.setSelectedItem(dsp);
 				if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) 
 					setEnabledDOWidgets(false);
 				user_defined_width = descriptor.userDefinedWidth; 
 				if (user_defined_width) {
 					CardLayout cl = (CardLayout) fWidthPanel.getLayout();
					cl.show(fWidthPanel,"F_WIDTH_FIELD");
 					fWidthField.setText(descriptor.width == -1 ? "" : String.valueOf(descriptor.width));
 				} else 
 					fWidthParam.setSelectedItem(descriptor.widthProducer);
 				user_defined_height = descriptor.userDefinedHeight;
 				if (user_defined_height) {
 					CardLayout cl = (CardLayout) fHeightPanel.getLayout();
					cl.show(fHeightPanel,"F_HEIGHT_FIELD");
 					fHeightField.setText(descriptor.height == -1 ? "" : String.valueOf(descriptor.height));
 				} else 
 					fHeightParam.setSelectedItem(descriptor.heightProducer);
 				if (!descriptor.rowOrder)
 					fTopToBottomButton.setSelected(true);
 		} else { // three datasources, partial mode
			is_full = false;
			CardLayout cl = (CardLayout) topPanel.getLayout();
			cl.show(topPanel,"PARTIAL_PANEL");
			pXParam.setSelectedItem(descriptor.dataSources.get(0));
			pYParam.setSelectedItem(descriptor.dataSources.get(1));
			if (descriptor.constantColorDataSource != null) {
				final DefaultComboBoxModel model = (DefaultComboBoxModel) pValueParam.getModel();
				model.insertElementAt(descriptor.constantColorDataSource,model.getSize() - 1);
				pValueParam.setSelectedItem(descriptor.constantColorDataSource);
			} else 
				pValueParam.setSelectedItem(descriptor.dataSources.get(2));
			r_user_defined_width = descriptor.userDefinedWidth;
			if (r_user_defined_width) 
				pWidthField.setText(descriptor.height == -1 ? "" : String.valueOf(descriptor.height));
			else {
				cl = (CardLayout) pWidthPanel.getLayout();
				cl.show(pWidthPanel,"P_WIDTH_PARAM");
				pWidthButton.setText("From user input");
				pWidthParam.setSelectedItem(descriptor.widthProducer);
			}
			r_user_defined_height = descriptor.userDefinedHeight;
			if (r_user_defined_height) 
				pHeightField.setText(descriptor.height == -1 ? "" : String.valueOf(descriptor.height));
			else { 
				cl = (CardLayout) pHeightPanel.getLayout();
				cl.show(pHeightPanel,"P_HEIGHT_PARAM");
				pHeightButton.setText("From user input");
				pHeightParam.setSelectedItem(descriptor.heightProducer);
			}
		}
		
		IFigureRenderer renderer = gridLayer.getRenderer();
		if (renderer instanceof ColorMapFigureRenderer) {
			ColorMapFigureRenderer _renderer = (ColorMapFigureRenderer) renderer;
			if (_renderer.getGlobalAlpha() >= 0) {
				globalTransparencyBox.doClick(0);
				transparencySlider.setValue((int)((1 - _renderer.getGlobalAlpha()) * 100));
			}
			colorMapPanel.setSettings(_renderer.getColorMap());
		} else {
			shapeRendererButton.setSelected(true);
			shapeRendererButton.doClick(0);
			shapeRendererPanel.setSettings(renderer,gridLayer.getRendererProperties());
		}
		okButton.setEnabled(true);
 	}
	
	//====================================================================================================
	// private methods
	
 	//----------------------------------------------------------------------------------------------------
	private Object[] getParamsToColor(final Color... colors) {
		List<Object> result = new ArrayList<Object>();
		result.addAll(Arrays.asList(getParams(new Class[] { ISeriesProducer.class, IValueProducer.class })));
		if (colors != null && colors.length > 0 && colors[0] != null) {
			for (final Color color : colors)
				result.add(color);
		}
		result.add(COLOR_MENU_TEXT);
		return result.toArray();
	}
	
	//----------------------------------------------------------------------------------------------------
	private Object[] getParamsToValues() {
 		return getParams(new Class[]{ISeriesProducer.class, IValueProducer.class, IGrid2DDatasetProducer.class});
 	}
	
	//----------------------------------------------------------------------------------------------------
	private Object[] getParamsToAll() {
 		return getParams(ISeriesProducer.class, IValueProducer.class);
 	}
	
 	//------------------------------------------------------------------------------
 	private Object[] getParamsToDimensions() {
 		return getParams(IValueProducer.class);
 	}
	
	//----------------------------------------------------------------------------------------------------
	private Object[] getParams(Class... intfs) {
 		List<IDataSourceProducer> candidates = config.getDSPCollection().getList();
		List<IDataSourceProducer> accepted = new ArrayList<IDataSourceProducer>();
		Iterator<IDataSourceProducer> it = candidates.iterator();
		while (it.hasNext()) {
			IDataSourceProducer dsp = it.next();
			for (int i=0;i<intfs.length;++i) {
				if (Utilities.canBe(dsp,intfs[i])) {
					accepted.add(dsp);
					break;
				}
			}
		}
		return accepted.toArray();
 	}
	
	//----------------------------------------------------------------------------------------------------
	private void setEnabledDOWidgets(boolean enabled) {
		fWidthLabel.setEnabled(enabled);
		fWidthParam.setEnabled(enabled && fWidthParam.getItemCount() > 0);
		fWidthField.setEnabled(enabled);
		fWidthButton.setEnabled(enabled);
		fHeightLabel.setEnabled(enabled);
		fHeightParam.setEnabled(enabled && fHeightParam.getItemCount() > 0);
		fHeightField.setEnabled(enabled);
		fHeightButton.setEnabled(enabled);
		orderLabel.setEnabled(enabled);
		fLeftToRightButton.setEnabled(enabled);
		fTopToBottomButton.setEnabled(enabled);
	}
	
	//------------------------------------------------------------------------------
	/** Returns whether the input string contains a valid positive integer or
	 *  not.
	 * @param text input string
	 */
	private boolean is_valid(String text) {
		if (positivePattern == null)
		  positivePattern = Pattern.compile("^[1-9][0-9]*$"); // pattern for positive integers
		Matcher m = positivePattern.matcher(text.trim());
		if (m.matches()) {
			try {
				Integer.parseInt(text.trim());
				return true;
			} catch (NumberFormatException e) {}
		}
		return false;
	}
	
	//------------------------------------------------------------------------------
	/** Sets the minimum value and maximum value fields of the color map panel.
	 * @param minmax a list that contains the minimum and maximum values (or <code>null</code>)
	 */
	private void setMinMax(List<Double> minmax) {
		if (minmax != null) {
			colorMapPanel.setMinValue(String.valueOf(minmax.get(0)));
			colorMapPanel.setMaxValue(String.valueOf(minmax.get(1)));
		} else {
			colorMapPanel.setMinValue("");
			colorMapPanel.setMaxValue("");
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	private void advanced(JComboBox param, Component comp) {
		IDataSourceProducer dsp = (IDataSourceProducer) param.getSelectedItem();
		IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(comp);
		if (new_dsp != null) {
			int index = param.getSelectedIndex();
			param.removeItemAt(index);
			param.insertItemAt(new_dsp,index);
			param.setSelectedIndex(index);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	private void tooltip(JComboBox param) {
		IDataSourceProducer dsp = (IDataSourceProducer) param.getSelectedItem();
		param.setToolTipText(dsp.toString());
	}
	
	//----------------------------------------------------------------------------------------------------
	private boolean isWellDefined() {
		if (shapeRendererButton.isSelected() && !shapeRendererPanel.hasDefinedRenderer()) return false;
		if (!colorMapPanel.hasDefinedColormap()) return false;
 		if (is_full) {
 			if (fValueParam.getItemCount() == 0) return false;
 			IDataSourceProducer cdsp = (IDataSourceProducer) fValueParam.getSelectedItem();
 			if (cdsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class)) return true;
			boolean w_valid = (user_defined_width && is_valid(fWidthField.getText())) || (!user_defined_width && fWidthParam.getItemCount() > 0);
			boolean h_valid = (user_defined_height && is_valid(fHeightField.getText())) || (!user_defined_height && fHeightParam.getItemCount() > 0);
 			if (w_valid || h_valid) return true;
 		} else if (pValueParam.getItemCount() > 1) return true;
 		return false;
 	}
	
	//----------------------------------------------------------------------------------------------------
	private void createGridLayer() {
		GridDescriptor descriptor = null;
		if (is_full) {
			IDataSourceProducer dsp = (IDataSourceProducer) fValueParam.getSelectedItem();
			if (dsp.getSupportedIntfs().contains(IGrid2DDatasetProducer.class))
				descriptor = new GridDescriptor(GridDescriptor.DS_MODE,dsp);
			else {
				descriptor = new GridDescriptor(GridDescriptor.FULL_MODE,dsp);
				descriptor.userDefinedWidth = user_defined_width;
				descriptor.userDefinedHeight = user_defined_height;
				if (user_defined_width) {
					int width = -1;
					try {
						width = Integer.parseInt(fWidthField.getText());
					} catch (NumberFormatException e) {}
					descriptor.width = width;
				} else {
					descriptor.widthProducer = (IDataSourceProducer) fWidthParam.getSelectedItem();
					if (descriptor.widthProducer == null) { 
						descriptor.userDefinedWidth = true;
						descriptor.width = -1;
					}
				}
				if (user_defined_height) {
					int height = -1;
					try {
						height = Integer.parseInt(fHeightField.getText());
					} catch (NumberFormatException e) {}
					descriptor.height = height;
				} else {
					descriptor.heightProducer = (IDataSourceProducer) fHeightParam.getSelectedItem();
					if (descriptor.heightProducer == null) {
						descriptor.userDefinedHeight = true;
						descriptor.height = -1;
					}
				}
				descriptor.rowOrder = fLeftToRightButton.isSelected();
			}
		} else {
			final IDataSourceProducer xds = (IDataSourceProducer) pXParam.getSelectedItem();
			final IDataSourceProducer yds = (IDataSourceProducer) pYParam.getSelectedItem();
			if (pValueParam.getSelectedItem() instanceof IDataSourceProducer)
				descriptor = new GridDescriptor(xds,yds,(IDataSourceProducer)pValueParam.getSelectedItem());
			else
				descriptor = new GridDescriptor(xds,yds,(Color)pValueParam.getSelectedItem());
			descriptor.userDefinedWidth = r_user_defined_width;
			descriptor.userDefinedHeight = r_user_defined_height;
			if (r_user_defined_width) {
				int width = -1;
				try {
					width = Integer.parseInt(pWidthField.getText());
				} catch (NumberFormatException e) {}
				descriptor.width = width;
			} else
				descriptor.widthProducer = (IDataSourceProducer) pWidthParam.getSelectedItem();
			if (r_user_defined_height) {
				int height = -1;
				try {
					height = Integer.parseInt(pHeightField.getText());
				} catch (NumberFormatException e) {}
				descriptor.height = height;
			} else
				descriptor.heightProducer = (IDataSourceProducer) pHeightParam.getSelectedItem();
		}
		
		IFigureRenderer renderer = null;
		
		if (shapeRendererButton.isSelected()) {
			renderer = shapeRendererPanel.getRenderer();
		} else {
			float globalAlpha = -1;
			if (globalTransparencyBox.isSelected()) {
				float transparency = ((float)transparencySlider.getValue()) / 100;
				globalAlpha = 1 - transparency;
			}
			renderer = new ColorMapFigureRenderer(colorMapPanel.getColormap(),globalAlpha);
		}
		gridLayer = new GridLayer(descriptor,renderer);
		if (!(renderer instanceof ColorMapFigureRenderer))
			gridLayer.setRendererProperties(shapeRendererPanel.getCustomProperties());
	}
	
	//----------------------------------------------------------------------------------------------------
	private void setWidgetDisabled() {
		if (fValueParam.getItemCount() == 0) {
			fValueParam.setEnabled(false);
			okButton.setEnabled(false);
			fValueAdvancedButton.setEnabled(false);
			fWidthButton.setEnabled(false);
			fHeightButton.setEnabled(false);
			pValueParam.setEnabled(false);
			pXParam.setEnabled(false);
			pYParam.setEnabled(false);
			pValueAdvancedButton.setEnabled(false);
			pXAdvancedButton.setEnabled(false);
			pYAdvancedButton.setEnabled(false);
			pWidthButton.setEnabled(false);
			pHeightButton.setEnabled(false);
		}
		if (fWidthParam.getItemCount() == 0) {
			fWidthButton.doClick(0);
			fHeightButton.doClick(0);
			fWidthButton.setEnabled(false);
			fHeightButton.setEnabled(false);
			fWidthParam.setEnabled(false);
			fHeightParam.setEnabled(false);
			pWidthParam.setEnabled(false);
			pHeightParam.setEnabled(false);
			pWidthButton.doClick(0);
			pHeightButton.doClick(0);
			pWidthButton.setEnabled(false);
			pHeightButton.setEnabled(false);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	private void handleColorMenu(final String command) {
		if (COLOR_MENU_TEXT.equals(command)) {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					final JColorDialog dialog = new JColorDialog(GridLayerDialog.this);
					Color color = null;
					if ((color = dialog.showDialog()) != null) {
						final DefaultComboBoxModel model = (DefaultComboBoxModel) pValueParam.getModel();
						final int idx = model.getIndexOf(color);
						if (idx > -1)
							pValueParam.setSelectedIndex(idx);
						else {
							model.insertElementAt(color,model.getSize() - 1);
							pValueParam.setSelectedItem(color);
						}
					} else
						pValueParam.setSelectedIndex(0);
				}
			});
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	private void setEnabledVisualisation(boolean enabled) {
		colorMapButton.setSelected(true);
		colorMapButton.setEnabled(enabled);
		shapeRendererButton.setEnabled(enabled);
	}
}