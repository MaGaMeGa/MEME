/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.view.plot;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.plot.Plot;

import ai.aitia.visu.view.selection.DefaultSelectionModel;
import ai.aitia.visu.view.selection.ISelectionListener;
import ai.aitia.visu.view.selection.SelectionEvent;

public abstract class DefaultInteractivePlot extends Plot implements InteractivePlot {

	protected DefaultSelectionModel selectionModel;
    protected HashMap areaInfo;
    
    private List listeners;
    
	public DefaultInteractivePlot() {
		super();
		this.selectionModel = new DefaultSelectionModel();
		this.areaInfo = new HashMap();
		this.listeners = new ArrayList();
	}
	
	public abstract void selectEntity(ChartEntity entity);
	
	public HashMap getAreaInfo() {
		return areaInfo;
	}
	
	public DefaultSelectionModel getSelectionModel() {
		return selectionModel;
	}

	public void setSelectionModel(DefaultSelectionModel selectionModel) {
		this.selectionModel = selectionModel;
	}
	
    public void renderSelection(Graphics2D g2d) {
    	Rectangle2D frame = selectionModel.getFrame();
    	
    	if (frame != null) {
    		g2d.setColor(Color.GRAY);
    		g2d.draw(frame);
    	}
    	
    	
    	g2d.setColor(Color.MAGENTA);
    	
    	//added code
    	Composite originalComposite = g2d.getComposite();
    	g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,0.5f));
    	//added code end
    	
    	List list = selectionModel.getSelectedObjects();
    	for (int i=0; i<list.size(); i++) {
    		
    		Rectangle2D area = (Rectangle2D.Double) areaInfo.get(list.get(i));    		    		    		    		
    		g2d.draw(area);
    		
//    		double x = area.getX();
//    		double y = area.getY();
//    		
//    		double width = area.getWidth();
//    		double height = area.getHeight();
//    		
    		g2d.fill(area);
//    		for (double c=x; c<x + width; c+=3) 
//    			g2d.drawLine((int)c, (int)y, (int)c, (int)(y+height));
    	}
    	
    	//added code
    	g2d.setComposite(originalComposite);
    	//added code end
    }
    
	@SuppressWarnings("unchecked")
	public void addSelectionListener(ISelectionListener listener) {
		listeners.add(listener);
	}
	
	public void removeSelectionListener(ISelectionListener listener) {
		listeners.remove(listener);
	}
	
    public void fireSelectionChanged() {
    	notifyListeners(new SelectionEvent(selectionModel));
    }
    
    protected void notifyListeners(SelectionEvent e) {
    	
    	final int length = listeners.size();
    	
    	for (int i=0; i<length; i++) {
    		ISelectionListener l = (ISelectionListener) listeners.get(i);
    		l.selectionChanged(e);
    	}
    }    
	
}
