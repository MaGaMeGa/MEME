/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.network;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Iterator;
import java.util.StringTokenizer;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.decorators.StringLabeller;
import edu.uci.ics.jung.io.PajekNetReader;
import edu.uci.ics.jung.utils.UserData;

public class HttpGraphSource implements IGraphSource {
	
	private String url;
	
	private int depth = 2;
	
	public HttpGraphSource(String url) {
		if (url == null)
			throw new IllegalArgumentException("Graph source cannot be null");
		this.url = url;
	}
		
	public int getDepth() {
		return depth;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}
	
	public Graph getSubGraph(Vertex v) {
		
		try {
		
			long start = System.currentTimeMillis();
			
			String params;
			
			if (v!=null) {
			
				String label = (String) v.getUserDatum("REMOTE_LABEL");
				params = "?root="+label+"&level=" + depth;
			} else 
				params = "?level=" + depth;
			
		
			String targetURL = url + params;
			
			System.out.println(targetURL);
			
			URL target = new URL(targetURL);
			URLConnection connection = target.openConnection();
			
			PajekNetReader pnr = new PajekNetReader();
			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			
			Graph g = pnr.load(br);
			
			@SuppressWarnings("unused")
			StringLabeller sl = StringLabeller.getLabeller(g);
			
			Iterator it = g.getVertices().iterator();
			while (it.hasNext()) {
				
				Vertex vertex = (Vertex) it.next();
				//System.out.println(vertex.getUserDatum(pnr.LABEL));
				
				StringTokenizer st = new StringTokenizer((String)vertex.getUserDatum(PajekNetReader.LABEL), " ");
				String label = st.nextToken();
				int l = Integer.parseInt(st.nextToken());

				vertex.setUserDatum(IGraphSource.LEVEL, new Integer(l), UserData.SHARED);
				vertex.setUserDatum("REMOTE_LABEL", label, UserData.SHARED);
				vertex.setUserDatum(IGraphSource.TOOLTIP, label, UserData.SHARED);
			}
			
			long end = System.currentTimeMillis();
			
			System.out.println("HttpGraphSource.getGraph: " + (end - start) + "ms");
			
			return g;
		} catch (Exception e) {
			e.printStackTrace();
			
			return null;
		}
		
	}
}
