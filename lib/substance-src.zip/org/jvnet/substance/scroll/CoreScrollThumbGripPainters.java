/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.scroll;

import java.awt.*;

import javax.swing.JScrollBar;

import org.jvnet.substance.SubstanceImageCreator;
import org.jvnet.substance.theme.SubstanceTheme;

/**
 * Factory of core implementations of {@link ScrollThumbGripPainter} interface.
 * 
 * @author Kirill Grouchnikov
 * @see ScrollThumbGripPainter
 */
public class CoreScrollThumbGripPainters {
	/**
	 * Implementation of scroll bar grip painter that uses drag bumps identical
	 * to those on toolbars and split pane dividers.
	 * 
	 * @author Kirill Grouchnikov
	 */
	public static class DragBumpsScrollThumbGripPainter implements
			ScrollThumbGripPainter {
		public void painScrollThumbGrip(JScrollBar scrollBar,
				Graphics2D graphics, SubstanceTheme theme,
				Rectangle scrollThumbArea, boolean isScrollBarVertical,
				ComponentOrientation scrollBarOrientation) {
			if (isScrollBarVertical) {
				int thumbHeight = scrollThumbArea.height;
				if (thumbHeight < 30)
					return;
				int gripHeight = thumbHeight / 4;
				if (gripHeight > 40)
					gripHeight = 40;

				int thumbWidth = scrollThumbArea.width;
				int gripWidth = thumbWidth * 2 / 3;

				int gripX = scrollThumbArea.x + (thumbWidth - gripWidth) / 2;
				int gripY = scrollThumbArea.y + (thumbHeight - gripHeight) / 2;
				graphics.drawImage(SubstanceImageCreator.getDragImage(theme,
						true, gripWidth, gripHeight, true), gripX, gripY, null);
			} else {
				int thumbWidth = scrollThumbArea.width;
				if (thumbWidth < 30)
					return;
				int gripWidth = thumbWidth / 4;
				if (gripWidth > 40)
					gripWidth = 40;

				int thumbHeight = scrollThumbArea.height;
				int gripHeight = thumbHeight * 2 / 3;

				int gripX = scrollThumbArea.x + (thumbWidth - gripWidth) / 2;
				int gripY = 1 + scrollThumbArea.y + (thumbHeight - gripHeight)
						/ 2;
				graphics.drawImage(SubstanceImageCreator.getRotated(
						SubstanceImageCreator.getDragImage(theme, true,
								gripHeight, gripWidth, true), 3), gripX, gripY,
						null);
			}
		}
	}
}
