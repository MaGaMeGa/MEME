/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.AllDummyDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.ds.IStringListProducer;
import ai.aitia.chart.ds.IStringSeriesProducer;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.meme.utils.FormsUtils;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;

/** GUI component of the pie charts. */
public class PieChartDialog extends AbstractChartDialog implements ActionListener,
																   FocusListener,
																   ItemListener,
																   MouseListener {

	/** Special producer for 'All' combobox item. */
	private AllDummyDataSourceProducer allProducer = new AllDummyDataSourceProducer();

	private static final long serialVersionUID = 1L;
	private JTabbedPane tabbed = new JTabbedPane();
	private JPanel mainPanel = null;
	private JPanel sourceAndCategoriesPanel = null;
	@SuppressWarnings("unused")
	private JPanel categoriesPanel = null;
	private JRadioButton defaultCategoriesButton = new JRadioButton("  Default categories");
	private JRadioButton selectedCategoriesButton = new JRadioButton("");
	private JComboBox categoriesParam = new JComboBox(getParamsToCategories());
	private JButton catAdvancedButton = new JButton("Advanced...");
	private JPanel sourcePanel = null;
	private JComboBox drParams = new JComboBox(getParamsToDataRows());
	private JButton drAdvancedButton = new JButton("Advanced...");
	private JPanel detailsPanel = null;
	private JTextField subtitleField = new JTextField();
	
	private JCheckBox showLegendBox = new JCheckBox("Show legend");
	private JCheckBox showLabelsBox = new JCheckBox("Show labels");
	private JComboBox appearanceBox = null;
	private JPanel buttonPanel = null;
	private JButton cancelButton = new JButton("Cancel");
	
	//===============================================================================
	// additional members
	
	/** Model of the selected datarows. */
	private DefaultListModel lmodel = null;  

	/** List of producers for the selected datarows. */
	private LinkedList<IDataSourceProducer> datarows = null;
	
	//===============================================================================
	// methods
	
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public PieChartDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		lmodel = new DefaultListModel();
		datarows = new LinkedList<IDataSourceProducer>();
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
		
	}

	//-------------------------------------------------------------------------------
	/** This method initializes the GUI. */
	private void initialize() {
		this.setLayout(new BorderLayout());
		
		ButtonGroup g = new ButtonGroup();
		g.add(defaultCategoriesButton);
		g.add(selectedCategoriesButton);
		
		defaultCategoriesButton.setActionCommand("DEFAULT_CB");
		defaultCategoriesButton.setSelected(true);
		selectedCategoriesButton.setActionCommand("SELECTED_CB");
		
		// Categories combobox
		categoriesParam.setRenderer(new DataSourceComboBoxRenderer(categoriesParam));
		categoriesParam.setEnabled(false);
		categoriesParam.setPreferredSize(new Dimension(100,26)); 
		categoriesParam.setActionCommand("CATERGORIES_PARAM");
		
		// Categories advanced button
		catAdvancedButton.setActionCommand("CATEGORIES_ADVANCED");
		catAdvancedButton.setEnabled(false);
		
		// Categories panel
		categoriesPanel = FormsUtils.build("p - p:g - p",
				                           "000 pref||" +
				                           "123",
				                           defaultCategoriesButton,
				                           selectedCategoriesButton,categoriesParam,catAdvancedButton).getPanel();

		// Data row combobox
		drParams.setRenderer(new DataSourceComboBoxRenderer(drParams));
		drParams.setPreferredSize(new Dimension(100,26));
		drParams.setActionCommand("DRPARAMS");

		// Data row advanced button
		drAdvancedButton.setEnabled(false);
		drAdvancedButton.setActionCommand("DR_ADVANCED");
		if (drParams.getItemCount()>0) {
			IDataSourceProducer dsp = (IDataSourceProducer)drParams.getSelectedItem();
			drParams.setToolTipText(dsp.toString()); // combobox settings
			drAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		}

	
		// Title textfield
		titleField = new JTextField(ChartConstants.PIECHART_NAME);
		titleField.setActionCommand("TITLE");
		titleField.addFocusListener(this);
		// Subtitle textfield
		subtitleField.addFocusListener(this);
	
		// Show legend checkbox
		showLegendBox.setSelected(true);
		showLegendBox.addItemListener(this);
		
		showLabelsBox.setSelected(true);
		showLabelsBox.addItemListener(this);
		
		// Appearance combobox
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox = new JComboBox(appearances);
		appearanceBox.setActionCommand("APPEARANCE");
		
		
		// Data row panel
		sourcePanel = FormsUtils.build("p:grow - p",
				   						 "01 pref",
				   						 drParams,
				   						 drAdvancedButton).getPanel();
		
		detailsPanel = FormsUtils.build("left:pref = pref:grow p p pref:grow",
					"01111 pref|'|" +
								  "23333|'|" +
								  "45_67|'|" +
								  //"_8_9|" +
								  "_____ pref:grow",
					"Title:", titleField,
					"Subtitle:", subtitleField,
					"Appearance:  ",appearanceBox,
					showLegendBox, showLabelsBox
					
					
					).getPanel();
		
		
		sourceAndCategoriesPanel = FormsUtils.build("p:grow - p",
					 	"01 pref",
					 	FormsUtils.titledBorder("Source",sourcePanel),
					 	FormsUtils.titledBorder("Categories", categoriesPanel))
					 	.getPanel();
		
		mainPanel = FormsUtils.build("fill:p:grow =",
					 "0 pref|'|" +
					 "1 pref|'|" +
					 "_____ pref:grow",
					 
					 sourceAndCategoriesPanel,
					 
					 FormsUtils.titledBorder("Details",detailsPanel)
					 ).getPanel();
		
		
		
		
		// Tabbed pane
		tabbed.addTab("Main Settings",Utilities.icons.get(ChartConstants.PIECHART),mainPanel);
		
		
		// Display button
		displayButton = new JButton("Display");
		if(drParams.getItemCount()==0)
			displayButton.setEnabled(false);
		displayButton.setMnemonic(KeyEvent.VK_D);
		displayButton.setActionCommand("DISPLAY");
		
		// Save button
		saveButton = new JButton("Save");
		saveButton.setEnabled(true);
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setActionCommand("SAVE");
		
		// Cancel button
		cancelButton.setMnemonic(KeyEvent.VK_C);
		cancelButton.setActionCommand("CANCEL");
		
		
		buttonPanel = FormsUtils.build("p:grow d ' d ' d ' d p:grow",
				   "-|_0123_",
				   getEditorButton(),
				   displayButton,
				   saveButton,
				   cancelButton).getPanel();
		
		this.setPreferredSize(new Dimension(609, 219)); //TODO: ideiglenes
//		this.setMinimumSize(new Dimension(609, 219));
		this.add(tabbed, BorderLayout.CENTER);
		this.add(buttonPanel, BorderLayout.SOUTH);
		
		Utilities.addActionListener(this,categoriesParam,catAdvancedButton,drParams,drAdvancedButton,
									titleField,displayButton,saveButton,
									cancelButton,appearanceBox,editorButton, defaultCategoriesButton,
									selectedCategoriesButton);
	}
	
	

	//===============================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-GUI functions                                                      //
	////////////////////////////////////////////////////////////////////////////
	
	@Override
	protected void setWidgetDisabled() {
		if (categoriesParam.getItemCount()==0) {
			categoriesParam.setEnabled(false);
			displayButton.setEnabled(!selectedCategoriesButton.isSelected());
			saveButton.setEnabled(isUpdateable());
			catAdvancedButton.setEnabled(false);
		}
		if (drParams.getItemCount()==0) {
			drParams.setEnabled(false);
			displayButton.setEnabled(false);
			drAdvancedButton.setEnabled(false);
		}
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that supports the 
	 *  {@link ai.aitia.chart.ds.IStringSeriesProducer IStringSeriesProducer} and/or
	 *  {@link ai.aitia.chart.ds.IStringListProducer IStringListProducer}.
	 *  interface.
	 * @return array of data sources
	 */
 	private Object[] getParamsToCategories() {
 		return getParams(new Class[] { IStringSeriesProducer.class, IStringListProducer.class });
 	}
 	
	//-------------------------------------------------------------------------------
 	/** Returns the displayable names of the data sources that supports the
 	 *  ISeriesProducer interface.
 	 * @return array of data sources
 	 */
 	private Object[] getParamsToDataRows() {
 		Object[] res = getParams(new Class[] { ISeriesProducer.class, IValueProducer.class});
 		return res;
 	}
 	
	//-------------------------------------------------------------------------------
 	@Override
 	protected void setSettingsFromConfig() {
 		if (config.getChartProperties() instanceof Properties) {
 			// set settings from config
 			properties = (Properties)config.getChartProperties();
 			int[] ds = Utilities.splitDatasourceAroundCommas(properties.getProperty("datasource"));
 			
 			IDataSourceProducer dsp = null;
 			if (ds[0] != ChartConstants.DEFAULT_DATASOURCE_IDX) {
 				selectedCategoriesButton.doClick(0);
 				dsp = config.getDataSource(ds[0]);
 				categoriesParam.setSelectedItem(dsp);
 			}
 			for (int i = 1;i < ds.length;++i) {
 				dsp = config.getDataSource(ds[i]);
 				datarows.add(dsp);
 				lmodel.addElement(dsp.toString());
 			}
 			drParams.setSelectedItem(dsp);
 			titleField.setText(properties.getProperty(ChartConstants.TITLE));
 			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
 			
// 			String renderer = properties.getProperty(ChartConstants.BAR_RENDERER,ChartConstants.ONE_BAR_PER_DATAROW);
 			showLegendBox.setSelected(Boolean.parseBoolean(properties.getProperty(ChartConstants.SHOW_LEGEND,"true")));
 			showLabelsBox.setSelected(Boolean.parseBoolean(properties.getProperty(ChartConstants.SHOW_LABELS ,"true")));
			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
 			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
 				String appearanceCode = "";
 				appearanceCode += properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP) ? "N" : "B";
 				appearanceCode += properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE) ? "BW" : "C";
 				for (int i = 0;i < appearanceBox.getItemCount();++i) {
 					String id = ((ComboboxItem)appearanceBox.getItemAt(i)).getID().toString();
 					if (id.equals(appearanceCode)) {
 						appearanceBox.setSelectedIndex(i);
 						break;
 					}
 				}
 			}
 			if (datarows.size() > 0) {
 				displayButton.setEnabled(true);
 				saveButton.setEnabled(true);
 			}
 			
 		} else {
 			// set the initial properties
 			properties.setProperty(ChartConstants.TITLE,ChartConstants.PIECHART_NAME);
 			properties.setProperty(ChartConstants.SUBTITLE,"");
 			properties.setProperty(ChartConstants.SHOW_LEGEND,"true");
 			int appIndex = 0;
 			appIndex += ChartConfigCollection.getColorAppearance().equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
 			appIndex += ChartConfigCollection.getEnvironmentAppearance().equals(ChartConstants.NORMAL_APP) ? 2 : 0;
 			appearanceBox.setSelectedIndex(appIndex);
 		}
 	}
 	
	//-------------------------------------------------------------------------------
 	@Override
 	public void updateChartConfig() {
 		IDataSourceProducer cdsp = (IDataSourceProducer)categoriesParam.getSelectedItem();
 		int key = -1;
 		if (defaultCategoriesButton.isSelected())
 			key = ChartConstants.DEFAULT_DATASOURCE_IDX;
 		else if (cdsp.getSupportedIntfs().contains(IStringListProducer.class))
 			key = config.addDataSource(cdsp,IStringListProducer.class);
 		else key = config.addDataSource(cdsp,IStringSeriesProducer.class);
 		
 		String ds = String.valueOf(key) + ",";

 		IDataSourceProducer dsp = (IDataSourceProducer)drParams.getSelectedItem();
		if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
			key = config.addDataSource(dsp,ISeriesProducer.class);
		else key = config.addDataSource(dsp,IValueProducer.class);
		ds += String.valueOf(key) + ",";
 		
 		properties.setProperty(ChartConstants.DATASOURCE,ds.substring(0,ds.length()-1));
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 3) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
	 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
	 		if (code[0].equals("B"))
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.BASIC_APP);
	 		else
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.NORMAL_APP);
	 		if (code[1].equals("BW"))
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.BLACK_AND_WHITE);
	 		else
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.COLORED);
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
 		config.setChartProperties(ChartConstants.PIECHART,properties);
 	}
 	
	//-------------------------------------------------------------------------------
 	@Override
 	public boolean isUpdateable() {
 		if ((defaultCategoriesButton.isSelected() || categoriesParam.getItemCount()>0) && drParams.getItemCount()>0) return true;
 		return false;
 	}
 	
	//-------------------------------------------------------------------------------
 	@Override
 	protected void displayPreview() throws Exception {
 		DataSources ds = new DataSources(new SimpleDSPCollection());
 		ChartConfig temp_config = new ChartConfig(ds);
 		temp_config.setFireInitialEvent(true);
 		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
 		temp_config.addDataSource(dsl.get(3), IStringSeriesProducer.class);
 		temp_config.addDataSource(dsl.get(0), ISeriesProducer.class);
 		temp_config.addDataSource(dsl.get(1), ISeriesProducer.class);
 		temp_config.addDataSource(dsl.get(2), ISeriesProducer.class);
 		Properties temp_prop = (Properties)properties.clone();
 		temp_prop.setProperty(ChartConstants.DATASOURCE,"1,2,3,4");
 		temp_prop.setProperty(ChartConstants.TITLE, temp_prop.getProperty(ChartConstants.TITLE)+ " (Preview illustration)");
 		temp_config.setChartProperties(ChartConstants.PIECHART,temp_prop);
 		Utilities.displayPreview(temp_config);
 	}
 	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		// reset widgets
		boolean scs = selectedCategoriesButton.isSelected();
		
		defaultCategoriesButton.setSelected(true);
		categoriesParam.setEnabled(true);
		catAdvancedButton.setEnabled(true);
		drParams.setEnabled(true);
		drAdvancedButton.setEnabled(true);
		
		Object catObject = categoriesParam.getSelectedIndex() == -1 ? null : categoriesParam.getSelectedItem();
		Object drObject = drParams.getSelectedIndex() == -1 ? null : drParams.getSelectedItem();
		
		DefaultComboBoxModel catModel = new DefaultComboBoxModel(getParamsToCategories());
		categoriesParam.setModel(catModel);
		DefaultComboBoxModel drModel = new DefaultComboBoxModel(getParamsToDataRows());
		drParams.setModel(drModel);
		
		if (catObject != null && findInComboBox(catModel,(IDataSourceProducer)catObject) != -1) {
			int idx = findInComboBox(catModel,(IDataSourceProducer)catObject);
			categoriesParam.setSelectedIndex(idx >= 0 ? idx : 0);
		} 
		if (drObject != null && findInComboBox(drModel,(IDataSourceProducer)drObject) != -1) {
			int idx = findInComboBox(drModel,(IDataSourceProducer)drObject);
			drParams.setSelectedIndex(idx >= 0 ? idx : 0);
		} 
		
		validate();
		setWidgetDisabled();
		selectedCategoriesButton.setEnabled(categoriesParam.getItemCount() > 0);
		if (scs)
			selectedCategoriesButton.doClick(0);
		
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);

	}
 	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem)appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}

 	//-------------------------------------------------------------------------------
 	/** This method handles all ActionEvent-s of the panel. It is public because of
 	 *  implementation side effect. Do not call or override.
 	 * @param event event
 	 */
	public void actionPerformed(ActionEvent event) {
		String command = event.getActionCommand();
		if (command.equals("CATEGORIES_PARAM")) { // Categories combobox
			IDataSourceProducer dsp = (IDataSourceProducer)categoriesParam.getSelectedItem();
			categoriesParam.setToolTipText(dsp.toString());
			catAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		} else if (command.equals("CATEGORIES_ADVANCED")) { // Categories advanced button
			advanced(categoriesParam);
		}
		else if (command.equals("DRPARAMS")) { // Data row combobox
			IDataSourceProducer dsp = (IDataSourceProducer)drParams.getSelectedItem();
			drParams.setToolTipText(dsp.toString());
			drAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		} else if (command.equals("DR_ADVANCED")) { // Data row advanced button
			advanced(drParams);
		} else if (command.equals("ADD")) { // Add data row button
			IDataSourceProducer dsp = (IDataSourceProducer)drParams.getSelectedItem();
			if (dsp.equals(allProducer)) {
				// special data source
				for (int i=0;i<drParams.getItemCount();++i) {
					IDataSourceProducer p = (IDataSourceProducer)drParams.getItemAt(i);
					if (p.equals(allProducer) || datarows.contains(p)) continue;
					datarows.add(p);
					lmodel.addElement(p.toString());
				}
			} else {
				if (datarows.contains(dsp)) return; // repeated datarow
				datarows.clear();
				datarows.add(dsp); // add datarow
				lmodel.clear();
				lmodel.addElement(dsp.toString()); // display it in the list 
				
				
			}
			
			// enable the buttons (if need)
			if (datarows.size()>0) {
				//removeButton.setEnabled(true);
				if (categoriesParam.getItemCount()>0) {
					displayButton.setEnabled(true);
					ChartDialogChangeCenter.fireSaveEnabled(this);
				}
			}
			
			
		} else if (command.equals("DEFAULT_CB")) {
			categoriesParam.setEnabled(false);
			catAdvancedButton.setEnabled(false);
			if (isUpdateable())
				ChartDialogChangeCenter.fireSaveEnabled(this);
			else 
				ChartDialogChangeCenter.fireSaveDisabled(this);
			displayButton.setEnabled(isUpdateable());
		} else if (command.equals("SELECTED_CB")) {
			categoriesParam.setEnabled(categoriesParam.getItemCount() > 0);
			if (categoriesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) categoriesParam.getSelectedItem();
				catAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
			if (isUpdateable())
				ChartDialogChangeCenter.fireSaveEnabled(this);
			else 
				ChartDialogChangeCenter.fireSaveDisabled(this);
			displayButton.setEnabled(isUpdateable());
		}
		else if (command.equals("TITLE")) { // Title textfield
			subtitleField.grabFocus();
		} else if (command.equals("DISPLAY")) { // Display button
			displayChart();
		} else if (command.equals("SAVE")) { // Save button
			saveCollection();
		} else if (command.equals("CANCEL")) { // Cancel button
			notifyForHide();
		} else if (command.equals("APPEARANCE")) { // Appearance box
			int index = appearanceBox.getSelectedIndex();
	 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
			if (index >= 0 && index <= 3) {
		 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
		 		if (code[0].equals("B"))
		 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.BASIC_APP);
		 		else
		 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.NORMAL_APP);
		 		if (code[1].equals("BW"))
		 			ChartConfigCollection.setColorAppearance(ChartConstants.BLACK_AND_WHITE);
		 		else
		 			ChartConfigCollection.setColorAppearance(ChartConstants.COLORED);
			}  else if (appearanceCode.equals("_NEW")) {
				ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(), ChartKind.NORMAL);
				int result = dlg.showDialog();
				if (result == ChartPropertiesDialog.OK_OPTION) {
					Element newTemplate = (Element) dlg.getTemplate();
					dlg.dispose();
					String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
					AbstractChart.templates.put(name,newTemplate);
					ChartDialogChangeCenter.fireTemplateChanged();
					appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
				} else 
					appearanceBox.setSelectedIndex(0);
			} else if (appearanceCode.equals("_EDIT")) {
				String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
				if (templates.length == 0) {
					JOptionPane.showMessageDialog(this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
					appearanceBox.setSelectedIndex(0);
					return;
				} 
				String template = (String)JOptionPane.showInputDialog(this,"Select a template: ","Edit template",
															  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
				if (template == null || "".equals(template)) 
					appearanceBox.setSelectedIndex(0);
				else {
					Element templateElement = AbstractChart.templates.get(template);
					ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(), ChartKind.NORMAL);
					int result = dlg.showDialog();
					if (result == ChartPropertiesDialog.OK_OPTION) {
						Element newTemplate = (Element) dlg.getTemplate();
						dlg.dispose();
						String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
						AbstractChart.templates.put(name,newTemplate);
						ChartDialogChangeCenter.fireTemplateChanged();
						appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
					} else 
						appearanceBox.setSelectedIndex(0);
				}
			} else if (appearanceCode.equals("_REMOVE")) {
				String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
				if (templates.length == 0) {
					JOptionPane.showMessageDialog(this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
					appearanceBox.setSelectedIndex(0);
					return;
				} 
				String template = (String)JOptionPane.showInputDialog(this,"Select a template: ","Delete template",
															  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
				if (template != null && !"".equals(template)) { 
					AbstractChart.templates.remove(template);
					File file = new File("Templates/" + template + ".xml");
					file.delete();
					ChartDialogChangeCenter.fireTemplateChanged();
				}
				appearanceBox.setSelectedIndex(0);
			}
		}
	}
	
	
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}
	
	//------------------------------------------------------------------------------
	private List<String> getLegends() {
		List<String> result = new ArrayList<String>(lmodel.size());
		for (int i = 0;i < lmodel.size();++i)
			result.add(lmodel.get(i).toString());
		return result;
	}
	
	
	
	//-----------------------------------------------------------------------------
	/** This method handles all focus lost focus events of the panel. It is public
	 *  because of implementation sideeffect. Do not call or override.
	 * @param e event
	 */
	public void focusLost(FocusEvent e) {
		if (e.getSource().equals(titleField)) {
			properties.setProperty(ChartConstants.TITLE,titleField.getText());
			ChartDialogChangeCenter.fireTitleChanged(this);
		} else if (e.getSource().equals(subtitleField)) {
			properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
		}
	}
	
	//-----------------------------------------------------------------------------
	public void focusGained(FocusEvent e) {}

	//-----------------------------------------------------------------------------
	/** This method handles all item state changed events of the panel. It is public
	 *  because of implementation sideeffect. Do not call or override.
	 * @param e event
	 */
	public void itemStateChanged(ItemEvent e) {
		properties.setProperty(ChartConstants.SHOW_LEGEND,String.valueOf(showLegendBox.isSelected()));
		properties.setProperty(ChartConstants.SHOW_LABELS,String.valueOf(showLabelsBox.isSelected()));
	}

	//-------------------------------------------------------------------------------
	/** This method haldles all released mouse events of the panel. It is public 
	 *  because of implementation side effect. Do not call or override.
	 * @param e event
	 */
	public void mouseReleased(MouseEvent e) {
		if (!SwingUtilities.isRightMouseButton(e))
			return;
	}
	
	//--------------------------------------------------------------------------------
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
}