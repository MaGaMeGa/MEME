package ai.aitia.visu.data;

public class DefaultGrid3DDataset_SurfaceLayer extends DefaultGrid3DDataset{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8297588210725289475L;

	public DefaultGrid3DDataset_SurfaceLayer(int column, int row) {
		super(column, row, 2);
	}

}
