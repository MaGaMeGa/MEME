
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.TreeSet;
import java.util.jar.Pack200;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.image.BufferedImage;

import javax.swing.*;

@SuppressWarnings("serial")
public class Unpacker extends JFrame implements Runnable, java.beans.PropertyChangeListener, 
													java.awt.event.ActionListener
{
	File			appDir		= new File(System.getProperty("user.dir"));
	URL				baseURL		= null;
	boolean			isJARmode	= false;

	volatile String currSrc	= null;
	volatile String currDest	= null;
	volatile int	 currPos	= -1;
	volatile boolean done		= false;

	JLabel			label		= null;
	JProgressBar	pr			= null;
	Timer			timer		= null;

	//-------------------------------------------------------------------------
	// [Main thread]
	public static void main(String[] args) {
		try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception e) {}
		Unpacker _this = new Unpacker();
		SwingUtilities.invokeLater(_this);
		_this.worker();
		_this.done = true;
		_this = null;
		System.exit(0);
	}

	//-------------------------------------------------------------------------
	// [Main thread]
	private Unpacker() {
		try	{
			baseURL = this.getClass().getResource('/' + this.getClass().getName().replace('.', '/') + ".class");
	    	String furl = baseURL.getFile();
		    if (baseURL.toString().startsWith("jar:")) {
		    	isJARmode = true;
		        furl = furl.substring(0, furl.indexOf('!'));
		        File f = new File(new URL(furl).getFile()).getParentFile();
		        if (f != null && f.exists())
		        	appDir = f;
		    } else {
		    	//appDir = new File(furl).getParentFile();
		    }
		}
		catch (Exception ex)
		{
			if (baseURL == null)
				try { baseURL = appDir.toURI().toURL(); }
				catch (Exception e) {};
		}
	}

	//-------------------------------------------------------------------------
	// [Main thread]
	private void worker() {
		Pack200.Unpacker unpacker = Pack200.newUnpacker();
		unpacker.addPropertyChangeListener(this);
		for (File f : listFilesRecursively(appDir, ".*\\.pack(\\.gz)?")) {
			try {
				synchronized (this) {
					currSrc = f.toString();
					currDest= withExt(f, ".jar");
					currPos = 0;
				}
				f = new File(appDir, currSrc);
				java.io.FileOutputStream os = new java.io.FileOutputStream(new File(appDir, currDest));
				java.util.jar.JarOutputStream jos = new java.util.jar.JarOutputStream(os);
				unpacker.unpack(f, jos);
				jos.close();
			} catch (Exception e) {
				e.printStackTrace();
				String messages[] = { String.format("Error while unpacking %s:", f), e.getLocalizedMessage() };
				JOptionPane.showMessageDialog(this, messages, "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	//-------------------------------------------------------------------------
	// [Main thread]
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
		if (Pack200.Unpacker.PROGRESS.equals(evt.getPropertyName())) {
			synchronized (this) {
				currPos = Integer.valueOf(evt.getNewValue().toString()); 
			}
		}
	}

	//-------------------------------------------------------------------------
	// [EDT]
	public void run() {
		label = new JLabel();
		pr    = new JProgressBar();
		pr.setStringPainted(false);

		timer = new Timer(10, this);	// 10 = a first-time delay only. The real delay is set in actionPerformed() 
		timer.setRepeats(true);
		timer.setCoalesce(true);
		timer.start();

		this.setTitle("Unpacking...");
		this.setIconImage(getIcon());
		this.setLocationRelativeTo(null);

		JPanel panel = new JPanel(new BorderLayout());
		panel.add(label, BorderLayout.NORTH);
		panel.add(pr, BorderLayout.CENTER);
		panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		label.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
		this.setContentPane(panel);

		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		actionPerformed(null);	// this calls pack()
		if (!done)
			this.setVisible(true);
	}

	//-------------------------------------------------------------------------
	// Timer events
	// [EDT]
	public void actionPerformed(java.awt.event.ActionEvent e) {
		if (done) {
			timer.stop();
			this.setVisible(false);
			dispose();
			return;
		} else {
			timer.setDelay(500);
		}
		int pos;
		String src, dest;
		synchronized (this) {
			pos = currPos;
			src = currSrc;
			dest= currDest;
		}
		pr.setIndeterminate(pos < 0);
		pr.setValue(pos);

		String text; 
		if (src != null && dest != null) {
			text = String.format("Unpacking %s to %s", src, dest);
		} else {
			text = "Collecting file list...";
		}
		if (!text.equals(label.getText())) {
			label.setText(text);
			this.pack();
		}
	}

	//-------------------------------------------------------------------------
	// [EDT]
	@Override
	public Dimension getPreferredSize() {
		java.awt.Dimension ans = super.getPreferredSize(), d = this.getToolkit().getScreenSize();
		d.width = d.width * 2/3;
		if (ans.width > d.width) ans.width = d.width;
		return ans;
	}
	
	//-------------------------------------------------------------------------
	// [EDT]
	@Override
	public void dispose() {
		if (timer != null) timer.stop();
		super.dispose();
	}

	//-------------------------------------------------------------------------
	// [Main thread]
	private static ArrayList<File> listFilesRecursively(File basedir, String pattern) {
		ArrayList<File> ans = new ArrayList<File>();
		TreeSet<File> tmp = new TreeSet<File>();
		boolean first = true;
		while (!tmp.isEmpty() || first) {
			File d = (first) ? new File("") : null; 
			if (!first) {
				java.util.Iterator<File> it = tmp.iterator(); 
				d = it.next();
				it.remove();
			}
			for (String s : new File(basedir, d.toString()).list()) {
				File f = (first) ? new File(s) : new File(d, s);
				s = f.toString();
				if (new File(basedir, s).isDirectory()) tmp.add(f);
				else if (pattern == null || s.toString().matches(pattern)) {
					ans.add(f);
				}
			}
			first = false;
		}
		return ans;
	}

	//-------------------------------------------------------------------------
	// [Main thread]
	private static String withExt(File f, String newext) {
		String rootname = getRootName(f);
		if (newext == null || newext.length() == 0) return rootname;
		return rootname + (newext.charAt(0) != '.' ? '.' + newext : newext);
	}

	//-------------------------------------------------------------------------
	/** Returns the whole 'pathname' without the extension ('.' is also removed) */
	// [Main thread]
	private static String getRootName(File f) {
		String name = f.getName();
		int i = name.lastIndexOf('.');
		String pathname = f.toString();
		return (i < 0) ? pathname : pathname.substring(0, pathname.length() + i - name.length()); 
	}

	//-------------------------------------------------------------------------
	// [EDT]
	private static java.awt.Image getIcon() {
		// Constructs an empty, completely transparent icon
	    BufferedImage bi = new BufferedImage(1, 16, BufferedImage.TYPE_INT_ARGB);
	    java.awt.Graphics g = bi.getGraphics();
	    g.setColor(new java.awt.Color(0,0,0,0));
	    g.fillRect(0, 0, 1, 16);
	    g.dispose();
	    return bi;
	}
}

