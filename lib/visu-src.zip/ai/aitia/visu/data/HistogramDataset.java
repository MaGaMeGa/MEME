/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.statistics.HistogramBin;
import org.jfree.data.statistics.HistogramType;
import org.jfree.data.xy.AbstractIntervalXYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.util.ObjectUtilities;
import org.jfree.util.PublicCloneable;

/**
 * A dataset that can be used for creating histograms.  
 * 
 * @see SimpleHistogramDataset
 */
public class HistogramDataset extends AbstractIntervalXYDataset 
                              implements IntervalXYDataset, 
                                         Cloneable, PublicCloneable, 
                                         Serializable {

    /** For serialization. */
	private static final long serialVersionUID = 246753149078771505L;

	/** A list of maps. */
    private List list;
    
    /** The histogram type. */
    private HistogramType type;
    
    /** An integer field that says what we do with the values out of bounds (min, max). */
    private int strategy;
    
    /** A hashmap for the outlier values. */
    private TreeMap<Double,Integer> outliers;

    /**
     * Creates a new (empty) dataset with a default type of 
     * {@link HistogramType}.FREQUENCY.
     */
    public HistogramDataset(int strategy) {
        this.list = new ArrayList();
        this.type = HistogramType.FREQUENCY;
        this.strategy = strategy;
        this.outliers = new TreeMap<Double,Integer>();
    }
    
    public HistogramDataset() {
    	this(1);
    }
    
    public TreeMap<Double,Integer> getOutliers() {
    	return outliers;
    }
    
    /**
     * Returns the histogram type. 
     * 
     * @return The type (never <code>null</code>).
     */
    public HistogramType getType() { 
        return this.type; 
    }

    /**
     * Sets the histogram type and sends a {@link DatasetChangeEvent} to all 
     * registered listeners.
     * 
     * @param type  the type (<code>null</code> not permitted).
     */
    public void setType(HistogramType type) {
        if (type == null) {
            throw new IllegalArgumentException("Null 'type' argument");
        }
        this.type = type;   
        notifyListeners(new DatasetChangeEvent(this, this));
    }

    /**
     * Adds a series to the dataset. Any data value falling on a bin boundary 
     * will be assigned to the lower value bin, with the exception of the lower 
     * bound of the bin range which is always assigned to the first bin.
     * 
     * @param key  the series key (<code>null</code> not permitted).
     * @param values  the raw observations.
     * @param bins  the number of bins.
     * @param minimum  the lower bound of the bin range.
     * @param maximum  the upper bound of the bin range.
     */
    @SuppressWarnings("unchecked")
	public void addSeries(Comparable key, 
                          List<Double> values, 
                          int bins, 
                          double minimum, 
                          double maximum) {
        
        if (key == null) {
            throw new IllegalArgumentException("Null 'key' argument.");   
        }
        if (values == null) {
            throw new IllegalArgumentException("Null 'values' argument.");
        }
        else if (bins < 1) {
            throw new IllegalArgumentException(
                "The 'bins' value must be at least 1."
            );
        }
        double binWidth = (maximum - minimum) / bins;

        double tmp = minimum;
        List binList = new ArrayList(bins);
        for (int i = 0; i < bins; i++) {
            HistogramBin bin;
            // make sure bins[bins.length]'s upper boundary ends at maximum
            // to avoid the rounding issue. the bins[0] lower boundary is
            // guaranteed start from min
            if (i == bins - 1) {
                bin = new HistogramBin(tmp, maximum);
            }
            else {
                bin = new HistogramBin(tmp, tmp + binWidth);
            }
            tmp = tmp + binWidth;
            binList.add(bin);
        }     
        
        // fill the bins
        for (int i = 0; i < values.size(); i++) {
        	if ((values.get(i).doubleValue() < minimum || values.get(i).doubleValue() > maximum)) {
        		if (strategy == 0) {
        			Integer count = outliers.get(values.get(i));
        			if (count == null) {
        				outliers.put(values.get(i),new Integer(1));
        			} else {
        				outliers.put(values.get(i), count+1);
        			}
        		}
        		if (strategy != 1) continue;
        	}
            int binIndex = bins - 1;
            if (values.get(i).doubleValue() < minimum) {
            	binIndex = 0;
            } else if (values.get(i).doubleValue() < maximum) {
                double fraction = (values.get(i).doubleValue() - minimum) / (maximum - minimum);
                binIndex = (int) (fraction * bins);
            }
            HistogramBin bin = (HistogramBin) binList.get(binIndex);
            bin.incrementCount();
        }
        
        // generic map for each series
        Map map = new HashMap();
        map.put("key", key);
        map.put("bins", binList);
        map.put("values.length", new Integer(values.size()));
        
        map.put("minvalue", new Double(minimum));
        map.put("maxvalue", new Double(maximum));
        
        map.put("bin width", new Double(binWidth));
        
        this.list.add(map);
    }
    
    @SuppressWarnings("unchecked")
	public void addValue(int series, double value) {
    	Map map = (Map) this.list.get(series);
    	
    	List binList = (List) map.get("bins");
    	
    	final int bins = binList.size();
    	
    	int binIndex = bins - 1;
    	
    	double minimum = ((Double) map.get("minvalue")).doubleValue();
    	double maximum = ((Double) map.get("maxvalue")).doubleValue();
    	if ((value < minimum || value > maximum)) {
    		if (strategy == 0) {
    			Integer count = outliers.get(new Double(value));
    			if (count == null) {
    				outliers.put(new Double(value),new Integer(1));
    			} else {
    				outliers.put(new Double(value), count+1);
    			}
    		}
    		if (strategy != 1) return;
    	}

    	if (value < minimum) {
        	binIndex = 0;
        } else if (value < maximum) {
    		double fraction = (value - minimum) / (maximum - minimum);
    		binIndex = (int) (fraction * bins);
    	}
    	
        HistogramBin bin = (HistogramBin) binList.get(binIndex);
        bin.incrementCount();
        
        map.put("values.length", new Integer(((Integer)map.get("values.length")).intValue() + 1));
        
        notifyListeners(new DatasetChangeEvent(this, this));
    }
    
    @SuppressWarnings("unchecked")
	public void replaceValues(int series, List<Double> values) {
    	
    	//System.out.println("replaceValues");
    	
    	Map map = (Map) this.list.get(series);
    	
    	List oldBinList = (List) map.get("bins");
    	
    	final int bins = oldBinList.size();
    	    	
    	double minimum = ((Double) map.get("minvalue")).doubleValue();
    	double maximum = ((Double) map.get("maxvalue")).doubleValue();
    	    	
        double binWidth = (maximum - minimum) / bins;

        double tmp = minimum;
        
        // Create new empty bins        
        List binList = new ArrayList(bins);
        for (int i = 0; i < bins; i++) {
            HistogramBin bin;
            // make sure bins[bins.length]'s upper boundary ends at maximum
            // to avoid the rounding issue. the bins[0] lower boundary is
            // guaranteed start from min
            if (i == bins - 1) {
                bin = new HistogramBin(tmp, maximum);
            }
            else {
                bin = new HistogramBin(tmp, tmp + binWidth);
            }
            tmp = tmp + binWidth;
            binList.add(bin);
        }         	
    	
        // Fill the bins
        outliers.clear();
		for (int i = 0; i < values.size(); i++) {
        	int binIndex = bins - 1;
        	if ((values.get(i).doubleValue() < minimum || values.get(i).doubleValue() > maximum)) {
        		if (strategy == 0) {
        			Integer count = outliers.get(values.get(i));
        			if (count == null) {
        				outliers.put(values.get(i),new Integer(1));
        			} else {
        				outliers.put(values.get(i), count+1);
        			}
        		}
        		if (strategy != 1) continue;
        	}
    		if (values.get(i).doubleValue() < minimum) {
            	binIndex = 0;
            } else if (values.get(i).doubleValue() < maximum) {
                double fraction = (values.get(i).doubleValue() - minimum) / (maximum - minimum);
                binIndex = (int) (fraction * bins);
            }
            HistogramBin bin = (HistogramBin) binList.get(binIndex);
            bin.incrementCount();
        }
        
        map.put("bins", binList);        
        map.put("values.length", new Integer(values.size()));
        
        notifyListeners(new DatasetChangeEvent(this, this));
    }    
    
    /**
     * Returns the bins for a series.
     * 
     * @param series  the series index.
     * 
     * @return An array of bins.
     */
    List getBins(int series) {
        Map map = (Map) this.list.get(series);
        return (List) map.get("bins"); 
    }

    /**
     * Returns the total number of observations for a series.
     * 
     * @param series  the series index.
     * 
     * @return The total.
     */
    private int getTotal(int series) {
        Map map = (Map) this.list.get(series);
        return ((Integer) map.get("values.length")).intValue(); 
    }

    /**
     * Returns the bin width for a series.
     * 
     * @param series  the series index (zero based).
     * 
     * @return The bin width.
     */
    private double getBinWidth(int series) {
        Map map = (Map) this.list.get(series);
        return ((Double) map.get("bin width")).doubleValue(); 
    }

    /**
     * Returns the number of series in the dataset.
     * 
     * @return The series count.
     */
    public int getSeriesCount() { 
        return this.list.size(); 
    }
    
    /**
     * Returns the key for a series.
     * 
     * @param series  the series index (zero based).
     * 
     * @return The series key.
     */
    public Comparable getSeriesKey(int series) {
        Map map = (Map) this.list.get(series);
        return (String) map.get("key"); 
    }

    /**
     * Returns the number of data items for a series.
     * 
     * @param series  the series index (zero based).
     * 
     * @return The item count.
     */
    public int getItemCount(int series) {
        return getBins(series).size(); 
    }

    /**
     * Returns the X value for a bin.  This value won't be used for plotting 
     * histograms, since the renderer will ignore it.  But other renderers can 
     * use it (for example, you could use the dataset to create a line
     * chart).
     * 
     * @param series  the series index (zero based).
     * @param item  the item index (zero based).
     * 
     * @return The start value.
     */
    public Number getX(int series, int item) {
        List bins = getBins(series);
        HistogramBin bin = (HistogramBin) bins.get(item);
        double x = (bin.getStartBoundary() + bin.getEndBoundary()) / 2.;
        return new Double(x);
    }

    /**
     * Returns the y-value for a bin (calculated to take into account the 
     * histogram type).
     * 
     * @param series  the series index (zero based).
     * @param item  the item index (zero based).
     * 
     * @return The y-value.
     */
    public Number getY(int series, int item) {
        List bins = getBins(series);
        HistogramBin bin = (HistogramBin) bins.get(item);
        double total = getTotal(series);
        double binWidth = getBinWidth(series);

        if (this.type == HistogramType.FREQUENCY) {
            return new Double(bin.getCount());
        }
        else if (this.type == HistogramType.RELATIVE_FREQUENCY) {
            return new Double(bin.getCount() / total);
        }
        else if (this.type == HistogramType.SCALE_AREA_TO_1) {
            return new Double(bin.getCount() / (binWidth * total));
        }
        else { // pretty sure this shouldn't ever happen
            throw new IllegalStateException();
        }
    }

    /**
     * Returns the start value for a bin.
     * 
     * @param series  the series index (zero based).
     * @param item  the item index (zero based).
     * 
     * @return The start value.
     */
    public Number getStartX(int series, int item) {
        List bins = getBins(series);
        HistogramBin bin = (HistogramBin) bins.get(item);
        return new Double(bin.getStartBoundary());
    }

    /**
     * Returns the end value for a bin.
     * 
     * @param series  the series index (zero based).
     * @param item  the item index (zero based).
     * 
     * @return The end value.
     */
    public Number getEndX(int series, int item) {
        List bins = getBins(series);
        HistogramBin bin = (HistogramBin) bins.get(item);
        return new Double(bin.getEndBoundary());
    }

    /**
     * Returns the start y-value for a bin (which is the same as the y-value, 
     * this method exists only to support the general form of the 
     * {@link IntervalXYDataset} interface).
     * 
     * @param series  the series index (zero based).
     * @param item  the item index (zero based).
     * 
     * @return The y-value.
     */
    public Number getStartY(int series, int item) {
        return getY(series, item);
    }

    /**
     * Returns the end y-value for a bin (which is the same as the y-value, 
     * this method exists only to support the general form of the 
     * {@link IntervalXYDataset} interface).
     * 
     * @param series  the series index (zero based).
     * @param item  the item index (zero based).
     * 
     * @return The Y value.
     */    
    public Number getEndY(int series, int item) {
        return getY(series, item);
    }

    /**
     * Tests this dataset for equality with an arbitrary object.
     * 
     * @param obj  the object to test against (<code>null</code> permitted).
     * 
     * @return A boolean.
     */
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;   
        }
        if (!(obj instanceof HistogramDataset)) {
            return false;
        }
        HistogramDataset that = (HistogramDataset) obj;
        if (!ObjectUtilities.equal(this.type, that.type)) {
            return false;
        }
        if (!ObjectUtilities.equal(this.list, that.list)) {
            return false;
        }
        return true;   
    }

    /**
     * Returns a clone of the dataset.
     * 
     * @return A clone of the dataset.
     * 
     * @throws CloneNotSupportedException if the object cannot be cloned.
     */
    public Object clone() throws CloneNotSupportedException {
        return super.clone();   
    }
}
