package ai.aitia.visu.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.xy.AbstractIntervalXYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.util.PublicCloneable;

public class MultiHistogramDataset extends AbstractIntervalXYDataset implements
		IntervalXYDataset, Serializable, PublicCloneable, Cloneable {

	private static final long serialVersionUID = -2845493267084776277L;

	public static final int FREQUENCY = 0;
	public static final int SUM = 1;
	public static final int MEAN = 2;

	/** List of bins */
	
	HashMap<Comparable, List<ExtendedBin>> binListMap = null;
	HashMap<Comparable, List<Double>> valuesMap = null;
	HashMap<Comparable, Double> maxMap = null;
	HashMap<Comparable, Double> minMap = null;
	ArrayList <Comparable> keyList;

	/** Type of the histogram. */
	private int type = 0;
	
	/**
	 * An integer field that says what we do with the values out of bounds (min,
	 * max).
	 */
	private int strategy;

	/** A hashmap for the outlier values. */
	@SuppressWarnings("unused")
	private TreeMap<Double, Integer> outliers;

	private HashMap<Comparable, TreeMap<Double, Integer>> outliersMap;
	
	private boolean automaticMinValue = false;
	private boolean automaticMaxValue = false;

	private int binCount = 0;

	private double actMinValue;
	private double actMaxValue;

	public MultiHistogramDataset(int type, int strategy) {
		this.binListMap = new HashMap<Comparable, List<ExtendedBin>>();
		this.outliersMap = new HashMap<Comparable, TreeMap<Double,Integer>>();
		this.valuesMap = new HashMap<Comparable, List<Double>>();
		this.maxMap = new HashMap<Comparable, Double>();
		this.minMap = new HashMap<Comparable, Double>();
		this.type = type;
		this.strategy = strategy;
		this.outliers = new TreeMap<Double, Integer>();
		this.actMinValue = -Double.MAX_VALUE;
		this.actMaxValue = Double.MAX_VALUE;
	}

	public MultiHistogramDataset(int type) {
		this(type, 1);
	}

	public MultiHistogramDataset() {
		this(FREQUENCY, 1);
	}

	
   public TreeMap<Double, Integer> getOutliers() {
		return outliersMap.get(keyList.get(0));
	}

	
	public HashMap<Comparable, TreeMap<Double, Integer>>  getOutliersMap(){
		return this.outliersMap;
		
	}
	
	public int getType() {
		return type;
	}

	public void setType(int type) {
		if (type < 0 || type > 2)
			throw new IllegalArgumentException("Illegal 'type' argument.");
		this.type = type;
		notifyListeners(new DatasetChangeEvent(this, this));
	}

	/**
	 * Adds a series to the dataset. Any data value falling on a bin boundary
	 * will be assigned to the lower value bin, with the exception of the lower
	 * bound of the bin range which is always assigned to the first bin.
	 * 
	 * @param key
	 *            the series key (<code>null</code> not permitted).
	 * @param values
	 *            the raw observations.
	 * @param bins
	 *            the number of bins.
	 * @param minimum
	 *            the lower bound of the bin range.
	 * @param maximum
	 *            the upper bound of the bin range.
	 */
	public void addSeries(Comparable key, List<Double> values, int bins,
			double minimum, double maximum) {
		
		if (key == null) {
			throw new IllegalArgumentException("Null 'key' argument.");
		}
		if (values == null) {
			throw new IllegalArgumentException("Null 'values' argument.");
		} else if (bins < 1) {
			throw new IllegalArgumentException(
					"The 'bins' value must be at least 1.");
		}
		// this.key = key;

		this.valuesMap.put(key, values);
		
		double actMin, actMax;
		
		if (minimum == -Double.MAX_VALUE) { // automatic min value
			// if (automaticMinValue) { // automatic min value
			automaticMinValue = true;
			actMin = Double.MAX_VALUE;
			/*for (int i = 0; i < values.size(); ++i)
				if (actMin > values.get(i).doubleValue())
					actMin = values.get(i).doubleValue();*/
			if(!values.isEmpty()){
				double m=Collections.min(values);
				if(actMin>m){
					actMin=m;
				}	
			}
			
			
		} else{
			actMin = minimum;
			actMinValue=actMin;
		}
			
		if (maximum == Double.MAX_VALUE) { // automatic max value
			// if (automaticMaxValue) { // automatic max value
			automaticMaxValue = true;
			actMax = -Double.MAX_VALUE;
			/*for (int i = 0; i < values.size(); ++i)
				if (actMax < values.get(i).doubleValue())
					actMax = values.get(i).doubleValue();*/
			if(!values.isEmpty()){
				double m=Collections.max(values);
				if(actMax<m){
					actMax=m;
				}	
			}
			
		} else{
			actMax = maximum;
			actMaxValue=actMax;
		}
			

		maxMap.put(key, actMax);
		minMap.put(key, actMin);
		double actmi = getActMinValue();
		double actma = getActMaxValue();
		boolean recalculateBins = false;
		if (actMinValue != actmi || actMaxValue != actma || binCount != bins) {
			actMinValue = actmi;
			actMaxValue = actma;
			binCount = bins;
			recalculateBins = true;
		}
		//System.out.println(binCount);
		//this.outliers.clear();
		double binWidth = (actMaxValue - actMinValue) / binCount;
		for (Comparable ke : valuesMap.keySet()) {
		//for (Comparable ke : keyList) {
			List <Double> actValues =valuesMap.get(ke);
			if ((recalculateBins || ke.equals(key))/* &&  null!=actValues*/ ) {
				TreeMap<Double, Integer> outlier = new TreeMap<Double, Integer>();
				double tmp = actMinValue;
				List<ExtendedBin> binList = new ArrayList<ExtendedBin>(bins);
				for (int i = 0; i < bins; i++) {
					ExtendedBin bin;
					// make sure bins[bins.length]'s upper boundary ends at
					// maximum
					// to avoid the rounding issue. the bins[0] lower boundary
					// is
					// guaranteed start from min
					if (i == bins - 1) {
						bin = new ExtendedBin(tmp, actMaxValue);
					} else {
						bin = new ExtendedBin(tmp, tmp + binWidth);
					}
					tmp = tmp + binWidth;
					binList.add(bin);
				}

				// fill the bins
				
				for (int i = 0; i < actValues.size(); i++) {
					if ((actValues.get(i).doubleValue() < actMinValue || actValues
							.get(i).doubleValue() > actMaxValue)) {
						
						if (strategy == 0) {
							Integer count = outlier.get(actValues.get(i));
							if (count == null) {
								outlier.put(actValues.get(i), new Integer(1));
							} else {
								outlier.put(actValues.get(i), count + 1);
							}
						}
						if (strategy != 1)
							continue;
					}
					int binIndex = bins - 1;
					if (actValues.get(i).doubleValue() < actMinValue) {
						binIndex = 0;
					} else if (actValues.get(i).doubleValue() < actMaxValue) {
						double fraction = (actValues.get(i).doubleValue() - actMinValue)
								/ (actMaxValue - actMinValue);
						binIndex = (int) (fraction * bins);
						
					}
					ExtendedBin bin = binList.get(binIndex);
					bin.incrementValue(actValues.get(i).doubleValue());
				}
				binListMap.put(ke, binList);
				outliersMap.put(ke, outlier);
			}

		}
		notifyListeners(new DatasetChangeEvent(this, this));
	}

	

	public void replaceValues(Comparable key, List<Double> values) {
		if (automaticMinValue)
			this.actMinValue = -Double.MAX_VALUE;
		if (automaticMaxValue)
			this.actMaxValue = Double.MAX_VALUE;
		
		addSeries(key, values, binCount, actMinValue,
				actMaxValue);
		/*this.valuesMap.put(key, values);
		if(key==keyList.get(keyList.size()-1)){
			addSeries(key, values, binListMap.get(key).size(), actMinValue,
					actMaxValue);
		notifyListeners(new DatasetChangeEvent(this, this));
		
		}*/
			
	}

	@Override
	public int getSeriesCount() {
		return valuesMap.size();
	}

	@Override
	public Comparable getSeriesKey(int series) {
		
		return keyList.get(series);
	}

	public int getItemCount(int series) {
		
		Comparable key = keyList.get(series);
		
		return binListMap.get(key).size();
		
	}

	public Number getEndX(int series, int item) {
		Comparable key = keyList.get(series);
		ExtendedBin bin = binListMap.get(key).get(item);
		return new Double(bin.getEndBoundary());
	}

	public Number getEndY(int series, int item) {
		return getY(series, item);
	}

	public Number getStartX(int series, int item) {
		
		Comparable key = keyList.get(series);
		ExtendedBin bin = binListMap.get(key).get(item);
		return new Double(bin.getStartBoundary());
	}

	public Number getStartY(int series, int item) {
		return getY(series, item);
	}
	
	public List<ExtendedBin> getBin(String seriesKey ){
		return binListMap.get(seriesKey);
	}

	public Number getX(int series, int item) {
		
		Comparable key = keyList.get(series);
		ExtendedBin bin = binListMap.get(key).get(item);
		double x = (bin.getStartBoundary() + bin.getEndBoundary()) / 2.;
		return new Double(x);
	}

	public Number getY(int series, int item) {
		
		Comparable key = keyList.get(series);
		ExtendedBin bin = binListMap.get(key).get(item);
		if (type == SUM)
			return new Double(bin.getValue());
		else if (type == FREQUENCY)
			return new Double(bin.getCounter());
		else if (type == MEAN)
			return new Double(bin.getMeanValue());
		else
			throw new IllegalStateException();
	}

	
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	private double getActMaxValue() {
		if(automaticMaxValue){
			return Collections.max(maxMap.values());
			
		}
		return this.actMaxValue;
		//return Collections.max(maxMap.values());
	}

	private double getActMinValue() {
		if(automaticMinValue){
			return Collections.min(minMap.values());	
		}
		return this.actMinValue;
		//return Collections.min(minMap.values());
	}

	public class ExtendedBin {

		private double startBoundary;
		private double endBoundary;

		private double value;
		private int counter;

		public ExtendedBin(double startBoundary, double endBoundary) {
			this.startBoundary = startBoundary;
			this.endBoundary = endBoundary;
			this.counter = 0;
			this.value = 0;
		}

		public int getCounter() {
			return counter;
		}

		public double getEndBoundary() {
			return endBoundary;
		}

		public double getStartBoundary() {
			return startBoundary;
		}

		public double getValue() {
			return value;
		}

		public double getMeanValue() {
			if (counter == 0)
				return 0;
			else
				return value / counter;
		}

		public void incrementValue(double value) {
			this.value += value;
			counter++;
		}
	}

	public int getHistogramCount() {
		return valuesMap.size();
	}

	public void setKeyList(ArrayList<Comparable> keyList) {
		this.keyList = keyList;
	}

	public ArrayList<Comparable> getKeyList() {
		return keyList;
	}

}
