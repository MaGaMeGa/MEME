/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Time;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.filechooser.FileFilter;

import org.freehep.graphics2d.VectorGraphics;
import org.freehep.graphicsio.emf.EMFGraphics2D;
import org.freehep.graphicsio.ps.PSGraphics2D;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ExtensionFileFilter;

import ai.aitia.visu.data.DefaultPieDataset;
import ai.aitia.visu.data.ExtendedHistogramDataset;
import ai.aitia.visu.data.Grid2DDataset;
import ai.aitia.visu.data.MatrixOfScatterplotsDataset;
import ai.aitia.visu.data.MultiHistogramDataset;
import ai.aitia.visu.data.OneDSeriesDataset;
import ai.aitia.visu.data.RadVizDataset;
import ai.aitia.visu.data.RectangleAreaEntry;
import ai.aitia.visu.data.ExtendedHistogramDataset.ExtendedBin;
import ai.aitia.visu.data.sequence.SequenceDataset;
import ai.aitia.visu.data.sequence.Set;
import ai.aitia.visu.globalhandlers.GlobalHandlers;
import ai.aitia.visu.movie.MovieMaker;
import ai.aitia.visu.utils.Utils;
import ai.aitia.visu.view.plot.Grid2DPlot;
import ai.aitia.visu.view.plot.MatrixOSPsPlot;
import ai.aitia.visu.view.plot.MultiGrid2DPlot;
import ai.aitia.visu.view.plot.OneDSeriesPlot;
import ai.aitia.visu.view.plot.RadVizPlot;
import ai.aitia.visu.view.plot.RectangleAreaPlot;
import ai.aitia.visu.view.plot.SequencePlot;



/** This class allows the user to save the chart in vectorgraphical format (eps). */
public class CustomSaveableChartPanel extends ChartPanel {

	public static boolean NEED_MOVIE = true; 
	private static final long serialVersionUID = 1L;
	private MovieMaker mM;
	private boolean recordMovie=false;
	private int frameRate=1;
	private int count=0;
	public static final String MOVIE_COMMAND = "MOVIE";
	public static final String FINISH_MOVIE_COMMAND = "FINISHMOVIE";
	public static final String MAX_ITEM_COUNT_COMMAND = "MAX_ITEM_COUNT";
	private JMenuItem finishMovie;
	
	/** Elv�laszt� karakter a CSV file-ban. */
    private char delimiter = ';';
    
    /** Tizedesjel a CSV file-ban. */
    private char decimalSign = ',';

	private BufferedImage image; // Used by PET

	public CustomSaveableChartPanel(JFreeChart chart) {
		super(chart);
	}
	
	public CustomSaveableChartPanel(JFreeChart chart, boolean useBuffer) {
		super(chart,useBuffer);
	}

	public CustomSaveableChartPanel(JFreeChart chart, boolean properties, boolean save,
							  boolean print, boolean zoom, boolean tooltips) {
		super(chart,properties,save,print,zoom,tooltips);
	}


	public CustomSaveableChartPanel(JFreeChart chart, int width, int height,
							  int minimumDrawWidth, int minimumDrawHeight,
							  int maximumDrawWidth, int maximumDrawHeight,
							  boolean useBuffer, boolean properties, boolean save,
							  boolean print, boolean zoom, boolean tooltips) {
		super(chart,width,height,minimumDrawWidth,minimumDrawHeight,maximumDrawWidth,
			  maximumDrawHeight,useBuffer,properties,save,print,zoom,tooltips);
	}
	
	private enum ImageType { PNG, EPS, EMF }
	
	@Override
	public void doSaveAs() throws IOException {
		JFileChooser fileChooser = new JFileChooser(GlobalHandlers.getLastDirectory());
		//TODO: use resourcebundles
		ExtensionFileFilter EPSFilter = new ExtensionFileFilter("Encapsulated Postscript Files (*.eps)",".eps");
		fileChooser.addChoosableFileFilter(EPSFilter);
		ExtensionFileFilter EMFFilter = new ExtensionFileFilter("Enhanced Metafiles (*.emf)",".emf");
		fileChooser.addChoosableFileFilter(EMFFilter);
		ExtensionFileFilter PNGFilter = new ExtensionFileFilter("PNG Image Files (*.png)",".png");
		fileChooser.addChoosableFileFilter(PNGFilter);
		
		int option = fileChooser.showSaveDialog(this);
		if (option == JFileChooser.APPROVE_OPTION) {
			String filename = fileChooser.getSelectedFile().getPath();
			GlobalHandlers.setLastDirectory(fileChooser.getSelectedFile());
			ImageType imageType = ImageType.PNG;
			if (filename.lastIndexOf('.') == -1) {
				FileFilter filter = fileChooser.getFileFilter();
				if (filter.equals(EPSFilter)) {
					filename += ".eps";
					imageType = ImageType.EPS;
				} else if (filter.equals(EMFFilter)) {
					filename +=".emf";
					imageType = ImageType.EMF;
				} else 
					filename += ".png";
			} else if (filename.endsWith(".eps") || filename.endsWith(".EPS"))
				imageType = ImageType.EPS;
			else if (filename.endsWith(".emf") || filename.endsWith(".EMF"))
				imageType = ImageType.EMF;
			else if (filename.endsWith(".png") || filename.endsWith(".PNG"))
				imageType = ImageType.PNG;
			else 
				filename += ".png";
			switch (imageType) {
			case EPS : saveChartAsEPS(filename); break;
			case EMF : saveChartAsEMF(filename); break;
			default  : ChartUtilities.saveChartAsPNG(new File(filename),this.getChart(),getWidth(),getHeight());
			}
		}
	}

	private void saveChartAsEPS(String filename) {
		try {
			VectorGraphics g = new PSGraphics2D(new File(filename), new Dimension(getWidth(),getHeight()));
			g.startExport();
			print(g);
			g.endExport();
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(this,"Unable to create this file:" + filename,"Saving failure",JOptionPane.ERROR_MESSAGE,null);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}
	
	private void saveChartAsEMF(String filename) {
		try {
			VectorGraphics g = new EMFGraphics2D(new File(filename), new Dimension(getWidth(),getHeight()));
			g.startExport();
			print(g);
			g.endExport();
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(this,"Unable to create this file:" + filename,"Saving failure",JOptionPane.ERROR_MESSAGE,null);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	public BufferedImage getImage() {
		Dimension size = getPreferredSize();
		if (image==null) {
			image = new BufferedImage(size.width, size.height, BufferedImage.TYPE_INT_RGB);
		}
		Graphics2D g2 = (Graphics2D)image.getGraphics();
		getChart().draw(g2, new Rectangle2D.Double(0,0,size.width,size.height));
		return image;
	}
	
	@Override
	public void paintComponent(Graphics g) {
		
		try {
			super.paintComponent(g);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	@Override
	public int print(Graphics g, PageFormat pf, int pageIndex) {
		try {
			return super.print(g,pf,pageIndex);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
		return NO_SUCH_PAGE; 
	}

	@Override
	public void paint(Graphics g) {
		
		try {
			super.paint(g);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}	}

	@Override
	public void paintImmediately(int x, int y, int w, int h) {
		try {
			super.paintImmediately(x,y,w,h);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
	}

	@Override
	public void paintImmediately(Rectangle r) {
		try {
			super.paintImmediately(r);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}	}

	@Override
	public void print(Graphics g) {
		try {
			super.print(g);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}	}

	@Override
	public void repaint(long tm, int x, int y, int width, int height) {
		try {
			super.repaint(tm,x,y,width,height);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}	}

	@Override
	public void repaint(Rectangle r) {
		try {
			super.repaint(r);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}	}

	@Override
	public void printComponents(Graphics g) {
		try {
			super.printComponents(g);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}	}

	@Override
	public void paintAll(Graphics g) {
		try {
			super.paintAll(g);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}	}

	@Override
	public void repaint() {
		try {
			super.repaint();
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}	}

	@Override
	public void repaint(int x, int y, int width, int height) {
		try {
			super.repaint(x,y,width,height);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}	}

	@Override
	public void repaint(long tm) {
		try {
			super.repaint(tm);
		} catch (Throwable t) {
			GlobalHandlers.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}	}
	
	
	/**
     * Creates a popup menu for the panel.
     *
     * @param properties  include a menu item for the chart property editor.
     * @param save  include a menu item for saving the chart.
     * @param print  include a menu item for printing the chart.
     * @param zoom  include menu items for zooming.
     *
     * @return The popup menu.
     */
    @Override
	protected JPopupMenu createPopupMenu(boolean properties, 
                                         boolean save, 
                                         boolean print,
                                         boolean zoom) {
        JPopupMenu result = super.createPopupMenu(properties, save, print, zoom);
        
        result.addSeparator();
        JMenuItem saveDataItem = new JMenuItem("Save Data");
        saveDataItem.setActionCommand("SAVE_DATA");
        saveDataItem.addActionListener(this);
        result.add(saveDataItem);
        
        result.addSeparator();
        
        if (NEED_MOVIE) {
	        JMenuItem makeMovie = new JMenuItem("Make Movie...");
			makeMovie.setActionCommand("MOVIE");
			makeMovie.addActionListener(this);
			result.add(makeMovie);
			
			result.addSeparator();
	        finishMovie = new JMenuItem("Finish Movie...");
			finishMovie.setActionCommand("FINISHMOVIE");
			finishMovie.addActionListener(this);
			finishMovie.setEnabled(false);
			result.add(finishMovie);
			
			
            
			if(this.getChart().getPlot().getClass().equals(org.jfree.chart.plot.XYPlot.class)){
				XYPlot pl=(XYPlot)this.getChart().getPlot();
				if((pl.getDataset().getClass().equals(TimeSeriesCollection.class)) ||
						(pl.getDataset().getClass().equals(XYSeriesCollection.class))	){
					result.addSeparator();
			        JMenuItem maxItemCount = new JMenuItem("Set max item count");
			        maxItemCount.setActionCommand("MAX_ITEM_COUNT");
					maxItemCount.addActionListener(this);
					result.add(maxItemCount);
				}
						
			}
		}
        return result;

    }
    
    @Override
	public void actionPerformed(ActionEvent event) {
    	
    	super.actionPerformed(event);
        String command = event.getActionCommand();
        if (command.equals(MOVIE_COMMAND)) {
            doMakeMovie();
        }
        if (command.equals(FINISH_MOVIE_COMMAND)) {
            doFinishMovie();
        }
        if (command.equals(MAX_ITEM_COUNT_COMMAND)) {
            doSetMaxItemCount();
        }
        if (command.equals("SAVE_DATA")) {
			doSaveData();
		}
    }

	private void doMakeMovie() {
		// TODO Auto-generated method stub
		SaveMovieDialog saveMovieDialog=new SaveMovieDialog(findActiveFrame());
		if(JFileChooser.APPROVE_OPTION== saveMovieDialog.showDialog()){
			try{
				String saveFileName=saveMovieDialog.getSelectedFile().getCanonicalPath();
				recordMovie=true ;
				Image image=this.getChart().createBufferedImage(getWidth(),getHeight(), null);
				this.frameRate=saveMovieDialog.getFrameRate();
				mM=new MovieMaker(saveFileName, frameRate);
				mM.run(image);	
			}catch(IOException e){
				e.printStackTrace();
			}
			finishMovie.setEnabled(true);	
		}
	}
	
	@SuppressWarnings({ "unchecked", "cast" })
	private void doSetMaxItemCount() {
		
		if(!this.getChart().getPlot().getClass().equals(org.jfree.chart.plot.XYPlot.class)){
			return;	
		}
		XYPlot pl=(XYPlot)this.getChart().getPlot();
		if(pl.getDataset().getClass().equals(TimeSeriesCollection.class)){
			TimeSeriesCollection tsc=(TimeSeriesCollection)pl.getDataset();
			if(tsc.getSeriesCount()>0){
				TimeSeries ts=(TimeSeries)tsc.getSeries(0);
				
			
				int i=ts.getMaximumItemCount();;
				int maxCount=0;
				String response = JOptionPane.showInputDialog("Set Max Item Count",
						 i );
				if(response!=null){
					try{
						i=Integer.parseInt(response);
						if(i<1){
							JOptionPane.showMessageDialog(this, "The value of the Max Item Count should be a positive integer!");
						}else{
							maxCount=i;
						}
						
					}catch (Exception e){
						JOptionPane.showMessageDialog(this, "The value of the Max Item Count should be a positive integer!");
					}
				}
				
				if(maxCount>0){
					Iterator<TimeSeries> it = tsc.getSeries().iterator();
					while (it.hasNext()) {
						it.next().setMaximumItemCount(maxCount);
						
					}
					
				}
					
			}
			
		}
		else 
		if(pl.getDataset().getClass().equals(XYSeriesCollection.class)){
			XYSeriesCollection tsc=(XYSeriesCollection)pl.getDataset();
			if(tsc.getSeriesCount()>0){
				XYSeries ts=(XYSeries)tsc.getSeries(0);
				
			
				int i=ts.getMaximumItemCount();;
				int maxCount=0;
				String response = JOptionPane.showInputDialog("Set Max Item Count",
						 i );
				if(response!=null){
					try{
						i=Integer.parseInt(response);
						if(i<1){
							JOptionPane.showMessageDialog(this, "The value of the Max Item Count should be a positive integer!");
						}else{
							maxCount=i;
						}
						
					}catch (Exception e){
						JOptionPane.showMessageDialog(this, "The value of the Max Item Count should be a positive integer!");
					}
				}
				
				if(maxCount>0){
					Iterator<XYSeries> it = tsc.getSeries().iterator();
					while (it.hasNext()) {
						it.next().setMaximumItemCount(maxCount);
						
					}
					
				}
					
			}
			
		}
	}
	
	public void doFinishMovie() {
		if(null!=mM){
			mM.setNotDone(false);
			recordMovie=false ;
			mM.cleanUp();
			finishMovie.setEnabled(false);
			mM=null;
		}
	}
	
	protected void addImageToMovie(){
		/*if(count>17){
			BufferImageSourceStream.notDone=false;
			recordMovie=false ;
		}*/
		
		if(null!=mM){
			Image image=this.getChart().createBufferedImage(getWidth(),getHeight(), null);
			mM.addImageAsFrame(image, frameRate);
			count ++;
		}
		
	}
	
	public void recordMovieFrame(){
		if(recordMovie){
			this.addImageToMovie();	
		}
	}
	
	private Frame findActiveFrame() {
		Frame[] frames = JFrame.getFrames();
	    for (int i = 0; i < frames.length; i++) {
	    	if (frames[i].isActive()) {
	               return frames[i];
	        }
	    }
	    return null;
	}
	
	
//-------------------------------------------------------------------------------
	
	/** Saving data in CSV format. */
	@SuppressWarnings({ "unchecked", "cast" })
	private void doSaveData() {
		JFileChooser fc = new JFileChooser();
		fc.setAcceptAllFileFilterUsed(false);
		fc.addChoosableFileFilter(new ExtensionFileFilter("CSV f�jlok",".csv"));
		int result = fc.showSaveDialog((JFrame)this.getTopLevelAncestor());
		if (result == JFileChooser.APPROVE_OPTION) {
			File file = fc.getSelectedFile();
			if (!file.getName().endsWith(".csv")) file = new File(file.getPath() + ".csv");
			exportData(file);
		}
	}
	
	public void exportData(File file) {
		if (this.getChart().getPlot() instanceof MatrixOSPsPlot) {
			saveMatrixOSPsPlotData(file);
		}
		else if (this.getChart().getPlot() instanceof XYPlot) {
			saveXYPlotData(file);
		}else if (this.getChart().getPlot() instanceof Grid2DPlot) {
			saveGrid2DPlotData(file);
		}else if (this.getChart().getPlot() instanceof RectangleAreaPlot) {
			saveRectangleAreaPlotData(file);
		}else if (this.getChart().getPlot() instanceof OneDSeriesPlot) {
			saveOneDSeriesPlotData(file);
		}
		else if (this.getChart().getPlot() instanceof CategoryPlot) {
			saveCategoryPlotData(file);
		} 
		else if (this.getChart().getPlot() instanceof PiePlot) {
			savePiePlotData(file);
		}
		else if (this.getChart().getPlot() instanceof SequencePlot) {
			saveSequencePlotData(file);
		}
		else if (this.getChart().getPlot() instanceof MultiGrid2DPlot) {
			saveMultiGrid2DPlotData(file);
		}
		else if (this.getChart().getPlot() instanceof RadVizPlot) {
			saveRadVizPlotData(file);
		}
	}
	
	/**
	 * Save data to csv from radViz
	 * @param file
	 */
	private void saveMatrixOSPsPlotData(File file){

		MatrixOSPsPlot plot = (MatrixOSPsPlot)this.getChart().getPlot();
		if(plot.getDataset() instanceof MatrixOfScatterplotsDataset){
			try {
				@SuppressWarnings("unused")
				double min=-1;
				@SuppressWarnings("unused")
				double max=1;
				MatrixOfScatterplotsDataset dataset = (MatrixOfScatterplotsDataset)plot.getDataset();
				BufferedWriter w = new BufferedWriter(new FileWriter(file));
				int histo=0; 
				int sqrt=(int)Math.floor(Math.sqrt(dataset.getSeriesCount()));
				for(int i=0; i<dataset.getSeriesCount(); i++){
					
					if(i==histo){
						histo+=sqrt+1;
						ArrayList<ArrayList<Double>> lists=dataset.getHistogramValues(i);
						ArrayList<Double> starts=lists.get(0);
						ArrayList<Double> ends=lists.get(1);
						ArrayList<Double> counts=lists.get(2);
						
						String title=dataset.getSeries(i).getKey().toString();
						w.write(title + "\n");
						String header="Bins_Start_Boundaries" + delimiter;
						String record1="Bins_End_Boundaries" + delimiter;
						String record2="Item_Counts" + delimiter;
						for(int l=0; l<starts.size(); l++){
							Double start=starts.get(l);
							Double end=ends.get(l);
							Integer count=(int)Math.floor(counts.get(l));
							if (decimalSign != '.') {
								header += start.toString().replace('.',decimalSign) + delimiter;
								record1 += end.toString().replace('.',decimalSign) + delimiter;
								record2 += count.toString().replace('.',decimalSign) + delimiter;
							} else {
								header += start.toString() + delimiter;
								record1 += end.toString() + delimiter;
								record2 += count.toString() + delimiter;
							}
						}
						if (Utils.findRealNumber(header,decimalSign) != -1) w.write(header.substring(0,header.length()-1) + "\n");
						if (Utils.findRealNumber(record1,decimalSign) != -1) w.write(record1.substring(0,record1.length()-1) + "\n");
						if (Utils.findRealNumber(record2,decimalSign) != -1) w.write(record2.substring(0,record2.length()-1) + "\n");
						
					}else{
						String title=dataset.getSeries(i).getKey().toString();
						w.write(title +"\n");
						String header="X" + delimiter;
						String record="Y" + delimiter;
						for(int j=0; j< dataset.getSeries(i).getItemCount(); j++){
							Double x=dataset.getXValue(i,j);
							Double y=dataset.getYValue(i,j);
							if (decimalSign != '.') {
								header += x.toString().replace('.',decimalSign) + delimiter;
								record += y.toString().replace('.',decimalSign) + delimiter;
							} else {
								header += x.toString() + delimiter;
								record += y.toString() + delimiter;
							}
						}
						if (Utils.findRealNumber(header,decimalSign) != -1) w.write(header.substring(0,header.length()-1) + "\n");
						if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
					}
					
					
				}
				
				w.flush();
				w.close();
				
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
			}	
		}
	}
	
	/**
	 * Save data to csv from radViz
	 * @param file
	 */
	@SuppressWarnings("cast")
	private void saveRadVizPlotData(File file){

		RadVizPlot plot = (RadVizPlot)this.getChart().getPlot();
		
		
		if(plot.getDataset() instanceof RadVizDataset){
			try {
				@SuppressWarnings("unused")
				double min=-1;
				@SuppressWarnings("unused")
				double max=1;
				RadVizDataset dataset = (RadVizDataset)plot.getDataset();
				BufferedWriter w = new BufferedWriter(new FileWriter(file));
				String header="Categories:" + delimiter;
				ArrayList l=dataset.getAnchors();
				for(Object o:l){
					header += o.toString() + delimiter;
				}
				w.write(header.substring(0,header.length()-1) + "\n");
				for(Object o: dataset.getKeys()){
					String name=o.toString();
					String record = "\"" +  name +  "\"" + "\n";// delimiter;
					ArrayList <ArrayList <Double>> a=dataset.getValues(name);
					ArrayList <Double []> d2 = dataset.get2DValues(name); 
					for(int i=0; i< a.size(); i++){
						record +=  Integer.toString(i+1) + ". point" + delimiter;
						ArrayList <Double> d=a.get(i);
						for(int j=0; j<d.size(); j++){
							Double dd=d.get(j);
							if (decimalSign != '.') {
								record += dd.toString().replace('.',decimalSign) + delimiter;
							} else {
								record += dd.toString() + delimiter;
							}	
						}
						record +="\n";
						record +=  "2D projection" + delimiter;
						Double dx=d2.get(i)[0];
						Double dy=d2.get(i)[1];
						if (decimalSign != '.') {
							record += dx.toString().replace('.',decimalSign) + delimiter;
							record += dy.toString().replace('.',decimalSign) + delimiter;
						} else {
							record += dx.toString() + delimiter;
							record += dy.toString() + delimiter;
						}
						record +="\n";
						
					}
					if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
				}
				
				w.flush();
				w.close();
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
			}	
		}
	}
	
	/**
	 * Save data to csv from Sequence
	 * @param file
	 */
	private void saveMultiGrid2DPlotData(File file){
		
		MultiGrid2DPlot plot = (MultiGrid2DPlot)this.getChart().getPlot();
		try {
			BufferedWriter w = new BufferedWriter(new FileWriter(file));
			
			
			
			
			double ymin = - Double.MAX_VALUE;
			Grid2DDataset[] datasets=plot.getDatasets();
			for(int e=0; e<datasets.length; e++){
				double [][] d =datasets[e].getValues();
				String header = "Layer " + Integer.toString(e);
				header +=	plot.getDomainAxis().getLabel() + delimiter;
				header += plot.getRangeAxis().getLabel() + delimiter;
				w.write(header + "\n");
				//datasets[e].
				//Vector<Double> c = dataset.getColumnData(metaData.getColumnIdByName(plot.getDomainAxis().getLabel())); 
				//Vector<Double> r = dataset.getColumnData(metaData.getColumnIdByName(plot.getRangeAxis().getLabel())); 
				//Vector<Double> color = dataset.getColumnData(metaData.getColumnIdByName(plot.getColorBar().getAxis().getLabel()));
				for (int i=0 ; i<d[0].length ; ++i) {
					
					
					String record = "";
					for(int j=0; j<d.length; j++){
						Double dd=d[j][i];
							
						if (dd<=ymin ) {
							record += delimiter;
							continue;
						}
						String s=dd.toString();
						if (decimalSign != '.') {
							record += s.replace('.',decimalSign) + delimiter;
							
						} else {
							
							record += s + delimiter;
							
							
						}	
					}
					
					w.write(record + "\n");
				}
				w.write("\n");
				w.write("\n");
				w.write("\n");
			}
			
			w.flush();
			w.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,"Unsuccesfull Save.","Error",JOptionPane.ERROR_MESSAGE,null);
		}
	}
	
	/**
	 * Save data to csv from Sequence
	 * @param file
	 */
	@SuppressWarnings("cast")
	private void saveSequencePlotData(File file){

		SequencePlot plot = (SequencePlot)this.getChart().getPlot();
		
		
		if(plot.getDataset() instanceof SequenceDataset){
			try {
				SequenceDataset dataset = (SequenceDataset)plot.getDataset();
				BufferedWriter w = new BufferedWriter(new FileWriter(file));
				Iterator it=dataset.getSets();
				//dataset.
				while(it.hasNext()){
					Set s=(Set)it.next();
					Iterator i=s.getElements();
					String record = "\"" +  "name" +  "\"" + delimiter;
					while(i.hasNext()){
						Object d= i.next();
						if (decimalSign != '.') {
							record += d.toString().replace('.',decimalSign) + delimiter;
						} else {
							record += d.toString() + delimiter;
						}
					}
					if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
					
				}	
				w.flush();
				w.close();
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
			}	
		}
	}
	/**
	 * Save data to csv from pkiechart
	 * @param file
	 */
	private void savePiePlotData(File file){

		PiePlot plot = (PiePlot)this.getChart().getPlot();
		
		
		if(plot.getDataset() instanceof DefaultPieDataset){
			try {
				DefaultPieDataset dataset = (DefaultPieDataset)plot.getDataset();
				BufferedWriter w = new BufferedWriter(new FileWriter(file));
				String header="Categories:" + delimiter;
				List l=dataset.getKeys();
				for(Object o:l){
					header += o.toString() + delimiter;
				}
				w.write(header.substring(0,header.length()-1) + "\n");
				String record = "\"" +  "Values:" +  "\"" + delimiter;
				for(int i=0; i<dataset.getItemCount(); i++){
					Double d=(Double)dataset.getValue(i);	
					if (decimalSign != '.') {
						record += d.toString().replace('.',decimalSign) + delimiter;
					} else {
						record += d.toString() + delimiter;
					}
				}
				if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
				
				
				w.flush();
				w.close();
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
			}	
		}
	}
	
	/**
	 * Save data to csv from barchart or boxplot
	 * @param file
	 */
	@SuppressWarnings("cast")
	private void saveCategoryPlotData(File file){

		CategoryPlot plot = (CategoryPlot)this.getChart().getPlot();
		if(plot.getDataset() instanceof BoxAndWhiskerCategoryDataset){
			try {
				
				BoxAndWhiskerCategoryDataset dataset = (BoxAndWhiskerCategoryDataset)plot.getDataset();
				
				BufferedWriter w = new BufferedWriter(new FileWriter(file));
				
				
				List cols=dataset.getColumnKeys();
				List rows=dataset.getRowKeys();
				@SuppressWarnings("unused")
				List l=dataset.getColumnKeys();

				
				
				
				for(Object o: cols){
					String columnKey= o.toString();
					String header="Category: " + columnKey + delimiter;
					header += "mean" +delimiter;
					header += "median" +delimiter;
					header += "min" +delimiter;
					header += "max" +delimiter;
					header += "Q1" +delimiter;
					header += "Q3" +delimiter;
					w.write(header.substring(0,header.length()-1) + "\n");
					for(Object oo: rows){
						String rowKey=oo.toString();
						String record = "\"" +  rowKey +  "\"" + delimiter;
						Double mean = (Double)dataset.getMeanValue(rowKey, columnKey);
						Double median = (Double)dataset.getMedianValue(rowKey, columnKey);
						Double min = (Double)dataset.getMinRegularValue(rowKey, columnKey) ;
						Double max = (Double)dataset.getMaxRegularValue(rowKey, columnKey) ;
						Double q1 = (Double)dataset.getQ1Value(rowKey, columnKey);
						Double q3 = (Double)dataset.getQ3Value(rowKey, columnKey);
						
						if (decimalSign != '.') {
							record += mean.toString().replace('.',decimalSign) + delimiter;
							record += median.toString().replace('.',decimalSign) + delimiter;
							record += min.toString().replace('.',decimalSign) + delimiter;
							record += 	max.toString().replace('.',decimalSign) + delimiter;
							record += q1.toString().replace('.',decimalSign) + delimiter;
							record += 	q3.toString().replace('.',decimalSign) + delimiter;
						} else {
							record += mean.toString() + delimiter;
							record += median.toString() + delimiter;
							record += min.toString() + delimiter;
							record += max.toString() + delimiter;
							record += q1.toString() + delimiter;
							record += q3.toString() + delimiter;
						}
						if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");		
					}
					w.write("\n");
							
				}
				
				w.flush();
				w.close();
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
			}	
		}
		else if(plot.getDataset() instanceof CategoryDataset){
			try {
				@SuppressWarnings("unused")
				double xmin,ymin,y2min,xmax,ymax,y2max;
				xmin = ymin = y2min = - Double.MAX_VALUE;
				xmax = ymax = y2max = Double.MAX_VALUE;
				CategoryDataset dataset = (CategoryDataset)plot.getDataset();
				ymin = plot.getRangeAxis().getRange().getLowerBound();
				ymax = plot.getRangeAxis().getRange().getUpperBound();
				BufferedWriter w = new BufferedWriter(new FileWriter(file));
				String header="Categories:" + delimiter;
				List l=dataset.getColumnKeys();
				for(Object o:l){
					header += o.toString() + delimiter;
				}
				w.write(header.substring(0,header.length()-1) + "\n");
				
				for(int i=0; i<dataset.getRowCount(); i++){
					String name=(dataset.getRowKey(i)).toString();
					String record = "\"" +  name +  "\"" + delimiter;
					for(int j=0; j<l.size(); j++){
						Double d=(Double)dataset.getValue(i, j);	
						if (d.doubleValue()<ymin || d.doubleValue()>ymax ) {
							record += delimiter;
							continue;
						}
						if (decimalSign != '.') {
							record += d.toString().replace('.',decimalSign) + delimiter;
						} else {
							record += d.toString() + delimiter;
						}
					}
					if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
					
				}
				
				
				
				w.flush();
				w.close();
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
			}	
		} 
	}
	
	@SuppressWarnings("cast")
	private void saveOneDSeriesPlotData(File file){

		OneDSeriesPlot plot = (OneDSeriesPlot)this.getChart().getPlot();
		try {
			@SuppressWarnings("unused")
			double xmin,ymin,y2min,xmax,ymax,y2max;
			xmin = ymin = y2min = - Double.MAX_VALUE;
			xmax = ymax = y2max = Double.MAX_VALUE;
			
			OneDSeriesDataset dataset = (OneDSeriesDataset)plot.getDataset();
			xmin = plot.getDomainAxis().getRange().getLowerBound();
			xmax = plot.getDomainAxis().getRange().getUpperBound();
			ymin = plot.getRangeAxis().getRange().getLowerBound();
			ymax = plot.getRangeAxis().getRange().getUpperBound();
			BufferedWriter w = new BufferedWriter(new FileWriter(file));
			int width=dataset.getWidth();
			int height=dataset.getHeight();
			int step=dataset.getStep();
			int elapsedSteps=dataset.getElapsedSteps();
			String header = "Steps:"  + delimiter;
			@SuppressWarnings("unused")
			int itemCount=height;
			for(int i=step+1; i<=elapsedSteps; i++){
				header += Integer.toString(i) + delimiter; 
			}
			w.write(header.substring(0,header.length()-1) + "\n");
			if(dataset.isRow_order()){
				
				for(int i=0; i<width; i++){
					String record = "\"" +   "Values_of_the_" + Integer.toString(i+1) + "._row: " + "\"" + delimiter;
					for(int j=0; j<elapsedSteps-step; j++){
						try{
							Double v=dataset.getValue(i, j);
							if (decimalSign != '.') {
								record += v.toString().replace('.',decimalSign) + delimiter;
							} else {
								record += v.toString() + delimiter;
							}
						}catch(Exception e){
							record += "no_value" + delimiter;
						}
					}
					if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
				}
			}
			else
			{
				
				for(int i=0; i<width; i++){
					String record = "\"" +   "Values_of_the_" + Integer.toString(i+1) + "._column:" + "\"" + delimiter;
					for(int j=0; j<elapsedSteps-step; j++){
						try{
							Double v=dataset.getValue(j, i);
							if (decimalSign != '.') {
								record += v.toString().replace('.',decimalSign) + delimiter;
							} else {
								record += v.toString() + delimiter;
							}
						}catch(Exception e){
							record += "no_value" + delimiter;
						}
					}
					if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
				}
			}
			
			w.flush();
			w.close();
		} catch (IOException e1) {
			JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
		}
	}
	
	private void saveXYPlotData(File file){

		XYPlot plot = (XYPlot)this.getChart().getPlot();
		/*
		 * TimeSeries, ScatterPlot,XYLineChart 
		 */
		if(plot.getDataset() instanceof XYSeriesCollection){
			try {
				@SuppressWarnings("unused")
				double xmin,ymin,y2min,xmax,ymax,y2max;
				xmin = ymin = y2min = - Double.MAX_VALUE;
				xmax = ymax = y2max = Double.MAX_VALUE;
				XYSeriesCollection dataset = (XYSeriesCollection)plot.getDataset();
				xmin = plot.getDomainAxis().getRange().getLowerBound();
				xmax = plot.getDomainAxis().getRange().getUpperBound();
				ymin = plot.getRangeAxis().getRange().getLowerBound();
				ymax = plot.getRangeAxis().getRange().getUpperBound();
				BufferedWriter w = new BufferedWriter(new FileWriter(file));
				for (int i=0;i<dataset.getSeriesCount();++i) {
					String name = dataset.getSeriesKey(i).toString();
					int index = name.lastIndexOf(',');
					String record = "\"" +  name.substring(index+1,name.length()) + "_Y" + "\"" + delimiter;
					XYSeries series = dataset.getSeries(i);
					if (/*i==0*/true) {
						String xname = dataset.getSeriesKey(i).toString();
						int xindex = xname.lastIndexOf(',');
						String header;
						if(xindex>-1){
							header = "\"" + xname.substring(1,xindex) + "_X" + "\"" + delimiter;
						}
						else{
							header = "\"" + xname + "_X" + "\"" + delimiter;
						}
							
						for (int j=0;j<series.getItemCount();++j) {
							Number n = dataset.getX(i,j);
							if (n.doubleValue()<xmin || n.doubleValue()>xmax) continue;
							if (decimalSign != '.') {
								header += n.toString().replace('.',decimalSign) + delimiter;
							} else {
								header += n.toString() + delimiter;
							}
						}
						w.write(header.substring(0,header.length()-1) + "\n");
					}
					for (int j=0;j<series.getItemCount();++j) {
						Number n = dataset.getY(i,j);
						Number x = dataset.getX(i,j);
						if (x.doubleValue()<xmin || x.doubleValue()>xmax) continue;
						if (n.doubleValue()<ymin || n.doubleValue()>ymax ) {
							record += delimiter;
							continue;
						}
						if (decimalSign != '.') {
							record += n.toString().replace('.',decimalSign) + delimiter;
						} else {
							record += n.toString() + delimiter;
						}
					}
					if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
				}
				w.flush();
				w.close();
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
			}	
		}
		
		else /*
			 * RealTimeSeries 
			 */
			if(plot.getDataset() instanceof TimeSeriesCollection){
			try {
				@SuppressWarnings("unused")
				double xmin,ymin,y2min,xmax,ymax,y2max;
				xmin = ymin = y2min = - Double.MAX_VALUE;
				xmax = ymax = y2max = Double.MAX_VALUE;
				
				TimeSeriesCollection dataset = (TimeSeriesCollection)plot.getDataset();
				xmin = plot.getDomainAxis().getRange().getLowerBound();
				xmax = plot.getDomainAxis().getRange().getUpperBound();
				ymin = plot.getRangeAxis().getRange().getLowerBound();
				ymax = plot.getRangeAxis().getRange().getUpperBound();
				BufferedWriter w = new BufferedWriter(new FileWriter(file));
				for (int i=0;i<dataset.getSeriesCount();++i) {
					String name = dataset.getSeriesKey(i).toString();
					int index = name.lastIndexOf(',');
					String record = "\"" +  name.substring(index+1,name.length()) + "_Y" + "\"" + delimiter;
					TimeSeries series = dataset.getSeries(i);
					if (/*i==0*/true) {
						String xname = dataset.getSeriesKey(i).toString();
						int xindex = xname.lastIndexOf(',');
						String header;
						if(xindex>-1){
							header = "\"" + xname.substring(1,xindex) + "_X" + "\"" + delimiter;
						}
						else{
							header = "\"" + xname + "_X" + "\"" + delimiter;
						}
							
						for (int j=0;j<series.getItemCount();++j) {
							Number n = dataset.getX(i,j);
							String time=(new Time((Long)n).toString());
							if (n.doubleValue()<xmin || n.doubleValue()>xmax) continue;
							header += time + delimiter;
						}
						w.write(header.substring(0,header.length()-1) + "\n");
					}
					for (int j=0;j<series.getItemCount();++j) {
						Number n = dataset.getY(i,j);
						Number x = dataset.getX(i,j);
						if (x.doubleValue()<xmin || x.doubleValue()>xmax) continue;
						if (n.doubleValue()<ymin || n.doubleValue()>ymax ) {
							record += delimiter;
							continue;
						}
						if (decimalSign != '.') {
							record += n.toString().replace('.',decimalSign) + delimiter;
						} else {
							record += n.toString() + delimiter;
						}
					}
					if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
				}
				w.flush();
				w.close();
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
			}
		}else/*
			 * Histogram 
			 */ 
			if(plot.getDataset() instanceof ExtendedHistogramDataset){
				try {
					@SuppressWarnings("unused")
					double xmin,ymin,y2min,xmax,ymax,y2max;
					xmin = ymin = y2min = - Double.MAX_VALUE;
					xmax = ymax = y2max = Double.MAX_VALUE;
					
					ExtendedHistogramDataset dataset = (ExtendedHistogramDataset)plot.getDataset();
					xmin = plot.getDomainAxis().getRange().getLowerBound();
					xmax = plot.getDomainAxis().getRange().getUpperBound();
					ymin = plot.getRangeAxis().getRange().getLowerBound();
					ymax = plot.getRangeAxis().getRange().getUpperBound();
					BufferedWriter w = new BufferedWriter(new FileWriter(file));
					for (int i=0;i<dataset.getSeriesCount();++i) {
						String name = dataset.getSeriesKey(i).toString();
						int index = name.lastIndexOf(',');
						String record = "\"" +  name.substring(index+1,name.length()) + "_Item_Count" + "\"" + delimiter;
						List<ExtendedBin> binList=dataset.getBins();
						String xname = dataset.getSeriesKey(i).toString();
						@SuppressWarnings("unused")
						int xindex = xname.lastIndexOf(',');
						String header1;
						header1=	 "\"" + "StartBoundaries" + "\"" + delimiter;
						String header2;
						header2=	 "\"" + "EndBoundaries" + "\"" + delimiter;
						for(ExtendedBin b: binList){
							header1 += Double.toString(b.getStartBoundary()) + delimiter;
							header2 += Double.toString(b.getEndBoundary()) + delimiter;
							@SuppressWarnings("unused")
							Integer n=b.getCounter();
							record += Integer.toString(b.getCounter()) + delimiter;
						}
						w.write(header1.substring(0,header1.length()-1) + "\n");
						w.write(header2.substring(0,header2.length()-1) + "\n");
						if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
						}
					w.flush();
					w.close();
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
				}
		}
			else/*
				 * Multihistogram 
				 */ 
				if(plot.getDataset() instanceof MultiHistogramDataset){
					try {
						@SuppressWarnings("unused")
						double xmin,ymin,y2min,xmax,ymax,y2max;
						xmin = ymin = y2min = - Double.MAX_VALUE;
						xmax = ymax = y2max = Double.MAX_VALUE;
						
						MultiHistogramDataset dataset = (MultiHistogramDataset)plot.getDataset();
						xmin = plot.getDomainAxis().getRange().getLowerBound();
						xmax = plot.getDomainAxis().getRange().getUpperBound();
						ymin = plot.getRangeAxis().getRange().getLowerBound();
						ymax = plot.getRangeAxis().getRange().getUpperBound();
						BufferedWriter w = new BufferedWriter(new FileWriter(file));
						for (int i=0;i<dataset.getSeriesCount();++i) {
							String name = dataset.getSeriesKey(i).toString();
							int index = name.lastIndexOf(',');
							String record = "\"" +  name.substring(index+1,name.length()) + "_Item_Count" + "\"" + delimiter;
							List<MultiHistogramDataset.ExtendedBin> binList=dataset.getBin(name);
							String xname = dataset.getSeriesKey(i).toString();
							@SuppressWarnings("unused")
							int xindex = xname.lastIndexOf(',');
							String header1;
							header1=	 "\"" + "StartBoundaries" + "\"" + delimiter;
							String header2;
							header2=	 "\"" + "EndBoundaries" + "\"" + delimiter;
							for(MultiHistogramDataset.ExtendedBin b: binList){
								header1 += Double.toString(b.getStartBoundary()) + delimiter;
								header2 += Double.toString(b.getEndBoundary()) + delimiter;
								@SuppressWarnings("unused")
								Integer n=b.getCounter();
								record += Integer.toString(b.getCounter()) + delimiter;
							}
							if(i==0){
								w.write(header1.substring(0,header1.length()-1) + "\n");
								w.write(header2.substring(0,header2.length()-1) + "\n");
							}
							if (Utils.findRealNumber(record,decimalSign) != -1) w.write(record.substring(0,record.length()-1) + "\n");
							}
						w.flush();
						w.close();
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(this,"Unsuccessful save.","Error",JOptionPane.ERROR_MESSAGE,null);
					}
			}
		
	}
	
	
	private void saveGrid2DPlotData(File file){
		
		Grid2DPlot plot = (Grid2DPlot)this.getChart().getPlot();
		try {
			BufferedWriter w = new BufferedWriter(new FileWriter(file));
			
			String header = plot.getDomainAxis().getLabel() + delimiter;
			
			header += plot.getRangeAxis().getLabel() + delimiter;
			
			
			w.write(header + "\n");
			
			Grid2DDataset dataset=plot.getDataset();
			
			double [][] d =dataset.getValues();
			//Vector<Double> c = dataset.getColumnData(metaData.getColumnIdByName(plot.getDomainAxis().getLabel())); 
			//Vector<Double> r = dataset.getColumnData(metaData.getColumnIdByName(plot.getRangeAxis().getLabel())); 
			//Vector<Double> color = dataset.getColumnData(metaData.getColumnIdByName(plot.getColorBar().getAxis().getLabel()));
			
			for (int i=0 ; i<d[0].length ; ++i) {
				String record = "";
				for(int j=0; j<d.length; j++){
					String s=Double.toString(d[j][i]);
					if (decimalSign != '.') {
						record += s.replace('.',decimalSign) + delimiter;
						
					} else {
						
						record += s + delimiter;
						
						
					}	
				}
				
				w.write(record + "\n");
			}
			w.flush();
			w.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,"Unsuccesfull Save.","Error",JOptionPane.ERROR_MESSAGE,null);
		}
	}
	
	@SuppressWarnings("unchecked")
	private void saveRectangleAreaPlotData(File file){
		RectangleAreaPlot plot = (RectangleAreaPlot)this.getChart().getPlot();
		try {
			BufferedWriter w = new BufferedWriter(new FileWriter(file));
			String areaName = "";
			String header = delimiter + "Area";
			if (!areaName.equals("")) header += " (" + areaName + ")";
			header += delimiter + "\"Area_in_%\"" + delimiter + "Value (";
			header += plot.getColorBar().getAxis().getLabel() + ")\n";
			w.write(header);
			NumberFormat percentFormat = NumberFormat.getPercentInstance();
			percentFormat.setMinimumFractionDigits(0);
			percentFormat.setMaximumFractionDigits(4);
			List<RectangleAreaEntry> entries = plot.getDataset().getEntries();
			for (RectangleAreaEntry e : entries) {
				String record = String.valueOf(delimiter);
				if (decimalSign != '.') {
					record += String.valueOf(e.getAreaValue()).replace('.',decimalSign) + delimiter;
					record += percentFormat.format(e.getAreaValue()/plot.getDataset().getTotalArea()).replace('.',decimalSign) + delimiter;
					record += String.valueOf(e.getColorValue()).replace('.',decimalSign) + "\n";
				} else {
					record += String.valueOf(e.getAreaValue()) + delimiter;
					record += percentFormat.format(e.getAreaValue()/plot.getDataset().getTotalArea())+ delimiter;
					record += String.valueOf(e.getColorValue()) + "\n";
				}
				w.write(record);
			}
			String coda = "Total:" + delimiter;
			coda += String.valueOf(plot.getDataset().getTotalArea()).replace('.',decimalSign) + delimiter;
			coda += percentFormat.format(1) + "\n";
			w.write(coda);
			w.flush();
			w.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,"Unsuccessful Save.","Error",JOptionPane.ERROR_MESSAGE,null);
		}
	
	}
	//===============================================================================
	// nested classes
	
	private static class SaveMovieDialog extends JDialog implements ActionListener {

		private static final long serialVersionUID = 1L;
		private JFileChooser chooser = null;
		private JComboBox combo = null;
		@SuppressWarnings("unused")
		private Frame owner = null;
		private File selectedFile = null;
		@SuppressWarnings("unused")
		private String className = null;
		private JLabel frameRateLabel = null;
		private JLabel frameRateLabel2 = null;
		private int frameRate=1;
		private int returnValue = JFileChooser.ERROR_OPTION;
		
		public SaveMovieDialog(Frame owner) {
			super(owner,"Make Movie",true);
			this.owner = owner;
			initialize();
			this.addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(WindowEvent e) {
					returnValue = JFileChooser.CANCEL_OPTION;
				}
			});
		}
		
		public int showDialog() {
			setVisible(true);
			int result = returnValue;
			dispose();
			return result;
		}
		
		public File getSelectedFile() { return selectedFile; }
		
		private void initialize() {
			

			chooser = new JFileChooser(GlobalHandlers.getLastDirectory());
			chooser.setMultiSelectionEnabled(false);
			chooser.setAcceptAllFileFilterUsed(true);
			chooser.addChoosableFileFilter(new MovFilter());
			chooser.setDialogType(JFileChooser.SAVE_DIALOG);
			chooser.addActionListener(this);
	
			JPanel panel = new JPanel(new BorderLayout());
			JPanel temp = new JPanel(new BorderLayout());
	        
	        combo=new JComboBox();
			for(int i=1; i<=60; i++ ){
				combo.addItem(i);
			}
			combo.setSelectedIndex(29);
			frameRateLabel=new JLabel("  Frame Rate :");
			
			frameRateLabel2=new JLabel("  Frame/sec  ");
			       
			temp.add(frameRateLabel,BorderLayout.WEST);
			temp.add(combo,BorderLayout.CENTER);
			temp.add(frameRateLabel2,BorderLayout.EAST);
			panel.add(temp,BorderLayout.NORTH);
			panel.add(chooser,BorderLayout.CENTER);
	        
			final JScrollPane sp = new JScrollPane(panel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			sp.setBorder(null);
			this.setContentPane(sp);
			this.pack();
			Dimension oldD = this.getPreferredSize();
			this.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
				             		     		oldD.height + sp.getHorizontalScrollBar().getHeight()));
			sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			oldD = this.getPreferredSize();
			final Dimension newD = Utils.getPreferredSize(this);
			if (!oldD.equals(newD)) 
				this.setPreferredSize(newD);
			this.pack();
			this.setLocationByPlatform(true);
		}

		public void actionPerformed(ActionEvent e) {
			selectedFile = chooser.getSelectedFile();
			frameRate=(Integer)(combo.getSelectedItem());
			boolean approve = e.getActionCommand().equals("ApproveSelection");
			returnValue =  approve ? JFileChooser.APPROVE_OPTION : JFileChooser.CANCEL_OPTION;
			if (approve) GlobalHandlers.setLastDirectory(selectedFile);
			setVisible(false);
		}

		public int getFrameRate() {
			return frameRate;
		}
	}
	
	private static class MovFilter extends FileFilter{
		//Accept all directories and all gif, jpg, tiff, or png files.
	    @Override
		public boolean accept(File f) {
	        if (f.isDirectory()) {
	            return true;
	        }

	        String extension = getExtension(f);
	        if (extension != null) {
	            if (extension.equals("mov") || extension.equals("MOV"))
	                 {
	                    return true;
	            } else {
	                return false;
	            }
	        }

	        return false;
	    }

	    //The description of this filter
	    @Override
		public String getDescription() {
	    	//this.
	        return "MOV";
	    }

	    public static String getExtension(File f) {
	        String ext = null;
	        String s = f.getName();
	        int i = s.lastIndexOf('.');

	        if (i > 0 &&  i < s.length() - 1) {
	            ext = s.substring(i+1).toLowerCase();
	        }
	        return ext;
	    }

	}
	
	

		
}
