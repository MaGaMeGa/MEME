/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.ds;

import java.util.ArrayList;
import java.util.Properties;
import java.util.List;

import org.jfree.data.general.Dataset;

import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDatasetProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.data.RectangleAreaDataset;
import ai.aitia.visu.data.RectangleAreaEntry;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.event.IDataChangeListener;

/** Dataset producer for areabased charts. */
public class RectangleAreaDatasetProducer implements IDatasetProducer, IDataChangeListener {

	/** Time of the last update. */
	private long time;
	
	/** The dataset that this object produces. */
	private RectangleAreaDataset dataset = null;

	/** Series producer for area values. */
	private ISeriesProducer areaValues = null;
	
	/** The current produced values for areas. */
	private List<Double> area_series = null;
	
	/** Series producer for color values. */
	private ISeriesProducer colorValues = null;
	
	/** The current producer values for colors. */
	private List<Double> color_series = null;
	
	/** List of the names of the areas. */
	private List<String> name_list = null; 
	
	//===============================================================================
	// methods
	
	/** Constructor.
	 * @param areaValues Series producer. It's series contains the size (as a rate) of the areas.
	 * @param colorValues Series producer. It's series contains a color value for each area.
	 * @param names String list producers. This list contains a name for each area.
	 */
	public RectangleAreaDatasetProducer(ISeriesProducer areaValues, ISeriesProducer colorValues, IStringListProducer names) {
		time = System.currentTimeMillis();
		dataset = new RectangleAreaDataset();
		
		this.areaValues = areaValues;
		this.areaValues.addDataChangeListener(this);
		this.colorValues = colorValues;
		this.colorValues.addDataChangeListener(this);
		names.addDataChangeListener(this);
	}
	
	//----------------------------------------------------------------------------------------------------
	public RectangleAreaDatasetProducer(ISeriesProducer areaValues, ISeriesProducer colorValues) {
		time = System.currentTimeMillis();
		dataset = new RectangleAreaDataset();
		
		this.areaValues = areaValues;
		this.areaValues.addDataChangeListener(this);
		this.colorValues = colorValues;
		this.colorValues.addDataChangeListener(this);
		name_list = new ArrayList<String>(0);
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the time of the last update. */
	public long getTime() {
		return time;
	}

	//-------------------------------------------------------------------------------
	/** Produces the dataset. This implementation of the method does not use the <code>
	 *  queryProperties</code> parameter and does not throw exception.
	 */  
	public Dataset produceDataset(Properties queryProperties) throws DataSourceException {
		return dataset;
	}
	
	//-------------------------------------------------------------------------------
	/** Updates the dataset. If the length of the area series greater than the length
	 *  of the color series or the list of names is <code>null</code> it clears the 
	 *  dataset.
	 * @param event event
	 */
	public void dataChanged(DataChangeEvent event) {
		Object source = event.getSource();
		
		if (source.equals(areaValues)) {
			ISeriesProducer p = (ISeriesProducer) source;
			area_series = p.produceSeries();
			if (p.equals(colorValues)) {
				// same source
				color_series = area_series;
			}
			time = p.getTime();
		} else if (source.equals(colorValues)) {
			ISeriesProducer p = (ISeriesProducer) source;
			color_series = p.produceSeries();
			time = p.getTime();
		} else if (source instanceof IStringListProducer) {
			IStringListProducer p = (IStringListProducer) source;
			name_list = p.produceStringList();
			time = p.getTime();
		} else return;
		dataset.clear();
		if (area_series == null || color_series == null || name_list == null) {
			dataset.clear();
			return;
		}
		int length = (area_series.size() > color_series.size() ? color_series.size() : area_series.size());
		for (int i = 0;i < length;++i) {
			if (area_series.get(i).doubleValue() <= 0) continue;
			String name = (i < name_list.size() ? name_list.get(i) : ""); 
			RectangleAreaEntry entry = new RectangleAreaEntry(name,area_series.get(i).doubleValue(),color_series.get(i).doubleValue());
			dataset.addEntry(entry);
		}
		for (int i = length;i < area_series.size();++i) {
			if (area_series.get(i).doubleValue() <= 0) continue;
			String name = (i < name_list.size() ? name_list.get(i) : ""); 
			RectangleAreaEntry entry = new RectangleAreaEntry(name,area_series.get(i).doubleValue(),-Double.MAX_VALUE);
			dataset.addEntry(entry);
		}
	}
}

