package ai.aitia.visu.view.plot;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.PieToolTipGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.DrawingSupplier;
import org.jfree.chart.plot.PieLabelDistributor;
import org.jfree.chart.plot.PieLabelRecord;
import org.jfree.chart.plot.PiePlotState;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.urls.PieURLGenerator;
import org.jfree.data.DefaultKeyedValues;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.PieDataset;
import org.jfree.text.G2TextMeasurer;
import org.jfree.text.TextBlock;
import org.jfree.text.TextBox;
import org.jfree.text.TextUtilities;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.RectangleInsets;
import org.jfree.util.ObjectList;
import org.jfree.util.PaintList;
import org.jfree.util.StrokeList;

import ai.aitia.visu.data.RadVizDataset;

/**
 * A plot that displays data in the form of a pie chart, using data from any 
 * class that implements the {@link PieDataset} interface.
 * <P>
 * Special notes:
 * <ol>
 * <li>the default starting point is 12 o'clock and the pie sections proceed
 * in a clockwise direction, but these settings can be changed;</li>
 * <li>negative values in the dataset are ignored;</li>
 * <li>there are utility methods for creating a {@link PieDataset} from a
 * {@link org.jfree.data.category.CategoryDataset};</li>
 * </ol>
 *
 * @see Plot
 * @see PieDataset
 */
public class RadVizPlot extends Plot implements Cloneable, Serializable {
    
    /** For serialization. */
    private static final long serialVersionUID = -795612466005590431L;
    
    /** The default interior gap. */
    public static final double DEFAULT_INTERIOR_GAP = 0.25;

    /** The default interior gap. */
    public static final int DOT_SIZE = 1;
    
    /** The maximum interior gap (currently 40%). */
    public static final double MAX_INTERIOR_GAP = 0.40;


    /** The default section label font. */
    public static final Font DEFAULT_LABEL_FONT 
        = new Font("SansSerif", Font.PLAIN, 10);

    /** The default section label paint. */
    public static final Paint DEFAULT_LABEL_PAINT = Color.black;
    
    /** The default section label background paint. */
    public static final Paint DEFAULT_LABEL_BACKGROUND_PAINT 
        = new Color(255, 255, 192);

    /** The default section label outline paint. */
    public static final Paint DEFAULT_LABEL_OUTLINE_PAINT = Color.black;
    
    /** The default section label outline stroke. */
    public static final Stroke DEFAULT_LABEL_OUTLINE_STROKE 
        = new BasicStroke(0.5f);
    
    /** The default section label shadow paint. */
    public static final Paint DEFAULT_LABEL_SHADOW_PAINT = Color.lightGray;
    
    /** The default minimum arc angle to draw. */
    public static final double DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW = 0.00001;

    /** The dataset for the pie chart. */
    private RadVizDataset dataset;


    /** 
     * The amount of space left around the outside of the pie plot, expressed 
     * as a percentage. 
     */
    private double interiorGap;

    /** The paint for ALL sections (overrides list). */
    private transient Paint dotPaint;

    /** The section paint list. */
    private PaintList dotPaintList;

    /** The base section paint (fallback). */
    private transient Paint baseSectionPaint;

    /** 
     * A flag that controls whether or not an outline is drawn for each
     * section in the plot.
     */
    private boolean sectionOutlinesVisible;

    /** The outline paint for ALL sections (overrides list). */
    private transient Paint sectionOutlinePaint;

    /** The section outline paint list. */
    private PaintList sectionOutlinePaintList;

    /** The base section outline paint (fallback). */
    private transient Paint baseSectionOutlinePaint;

    /** The outline stroke for ALL sections (overrides list). */
    private transient Stroke sectionOutlineStroke;

    /** The section outline stroke list. */
    private StrokeList sectionOutlineStrokeList;

    /** The base section outline stroke (fallback). */
    private transient Stroke baseSectionOutlineStroke;
 
    /** The percentage amount to explode each pie section. */
    private ObjectList explodePercentages;
    
    /** The section label generator. */
    private PieSectionLabelGenerator labelGenerator;

    /** The font used to display the section labels. */
    private Font labelFont;

    /** The color used to draw the section labels. */
    private transient Paint labelPaint;
    
    /** The color used to draw the background of the section labels. */
    private transient Paint labelBackgroundPaint;

    /** 
     * The paint used to draw the outline of the section labels 
     * (<code>null</code> permitted). 
     */
    private transient Paint labelOutlinePaint;
    
    /** 
     * The stroke used to draw the outline of the section labels 
     * (<code>null</code> permitted). 
     */
    private transient Stroke labelOutlineStroke;
    
    /** 
     * The paint used to draw the shadow for the section labels 
     * (<code>null</code> permitted). 
     */
    private transient Paint labelShadowPaint;
    
    /** The maximum label width as a percentage of the plot width. */
    private double maximumLabelWidth = 0.20;
    
    /** 
     * The gap between the labels and the plot as a percentage of the plot 
     * width. 
     */
    private double labelGap = 0.05;

    /** A flag that controls whether or not the label links are drawn. */
    private boolean labelLinksVisible;
    
    /** The link margin. */
    private double labelLinkMargin = 0.05;
    
    /** The paint used for the label linking lines. */
    private transient Paint labelLinkPaint = Color.black;
    
    /** The stroke used for the label linking lines. */
    private transient Stroke labelLinkStroke = new BasicStroke(0.5f);
    
    /** The tooltip generator. */
    private PieToolTipGenerator toolTipGenerator;

    /** The URL generator. */
    private PieURLGenerator urlGenerator;
    
    /** The legend label generator. */
    private PieSectionLabelGenerator legendLabelGenerator;
    
    /** A tool tip generator for the legend. */
    private PieSectionLabelGenerator legendLabelToolTipGenerator;
    
    /** 
     * A flag that controls whether <code>null</code> values are ignored.  
     */
    private boolean ignoreNullValues;
    
    /**
     * A flag that controls whether zero values are ignored.
     */
    private boolean ignoreZeroValues;

    /** The legend item shape. */
    private transient Shape legendItemShape;
    

    /** The resourceBundle for the localization. */
    protected static ResourceBundle localizationResources =
        ResourceBundle.getBundle("org.jfree.chart.plot.LocalizationBundle");

    /**
     * Creates a new plot.  The dataset is initially set to <code>null</code>.
     */
    public RadVizPlot() {
        this(null);
    }

    /**
     * Creates a plot that will draw a pie chart for the specified dataset.
     *
     * @param dataset  the dataset (<code>null</code> permitted).
     */
    public RadVizPlot(RadVizDataset dataset) {
        super();
        this.dataset = dataset;
        
        if (dataset != null) {
        	
            dataset.addChangeListener(this);
        }
        
        this.interiorGap = DEFAULT_INTERIOR_GAP;
        
        this.dotPaint = null;
        this.dotPaintList = new PaintList();
        this.baseSectionPaint = null;

        this.sectionOutlinesVisible = true;
        this.sectionOutlinePaint = null;
        this.sectionOutlinePaintList = new PaintList();
        this.baseSectionOutlinePaint = DEFAULT_OUTLINE_PAINT;

        this.sectionOutlineStroke = null;
        this.sectionOutlineStrokeList = new StrokeList();
        this.baseSectionOutlineStroke = DEFAULT_OUTLINE_STROKE;
        
        this.explodePercentages = new ObjectList();

        this.labelGenerator = new StandardPieSectionLabelGenerator();
        this.labelFont = DEFAULT_LABEL_FONT;
        this.labelPaint = DEFAULT_LABEL_PAINT;
        this.labelBackgroundPaint = DEFAULT_LABEL_BACKGROUND_PAINT;
        this.labelOutlinePaint = DEFAULT_LABEL_OUTLINE_PAINT;
        this.labelOutlineStroke = DEFAULT_LABEL_OUTLINE_STROKE;
        this.labelShadowPaint = DEFAULT_LABEL_SHADOW_PAINT;
        this.labelLinksVisible = true;
        
        this.toolTipGenerator = null;
        this.urlGenerator = null;
        this.legendLabelGenerator = new StandardPieSectionLabelGenerator();
        this.legendLabelToolTipGenerator = null;
        this.legendItemShape = Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        
        this.ignoreNullValues = false;
        this.ignoreZeroValues = false;
    }

    /**
     * Returns the dataset.
     *
     * @return The dataset (possibly <code>null</code>).
     */
    public RadVizDataset getDataset() {
        return this.dataset;
    }

    /**
     * Sets the dataset and sends a {@link DatasetChangeEvent} to 'this'.
     *
     * @param dataset  the dataset (<code>null</code> permitted).
     */
    public void setDataset(RadVizDataset dataset) {
        // if there is an existing dataset, remove the plot from the list of 
        // change listeners...
        RadVizDataset existing = this.dataset;
        if (existing != null) {
            existing.removeChangeListener(this);
        }

        // set the new dataset, and register the chart as a change listener...
        this.dataset = dataset;
        if (dataset != null) {
            setDatasetGroup(dataset.getGroup());
            dataset.addChangeListener(this);
        }

        // send a dataset change event to self...
        DatasetChangeEvent event = new DatasetChangeEvent(this, dataset);
        datasetChanged(event);
    }
    
    
    
    /**
     * Returns the interior gap, measured as a percentage of the available 
     * drawing space.
     *
     * @return The gap (as a percentage of the available drawing space).
     */
    public double getInteriorGap() {
        return this.interiorGap;
    }

    /**
     * Sets the interior gap and sends a {@link PlotChangeEvent} to all 
     * registered listeners.  This controls the space between the edges of the 
     * pie plot and the plot area itself (the region where the section labels 
     * appear).
     *
     * @param percent  the gap (as a percentage of the available drawing space).
     */
    public void setInteriorGap(double percent) {

        // check arguments...
        if ((percent < 0.0) || (percent > MAX_INTERIOR_GAP)) {
            throw new IllegalArgumentException(
                "Invalid 'percent' (" + percent + ") argument.");
        }

        // make the change...
        if (this.interiorGap != percent) {
            this.interiorGap = percent;
            notifyListeners(new PlotChangeEvent(this));
        }

    }

    /**
     * Returns the flag that controls whether <code>null</code> values in the 
     * dataset are ignored.  
     * 
     * @return A boolean.
     */
    public boolean getIgnoreNullValues() {
        return this.ignoreNullValues;   
    }
    
    /**
     * Sets a flag that controls whether <code>null</code> values are ignored, 
     * and sends a {@link PlotChangeEvent} to all registered listeners.  At 
     * present, this only affects whether or not the key is presented in the 
     * legend.
     * 
     * @param flag  the flag.
     */
    public void setIgnoreNullValues(boolean flag) {
        this.ignoreNullValues = flag;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the flag that controls whether zero values in the 
     * dataset are ignored.  
     * 
     * @return A boolean.
     */
    public boolean getIgnoreZeroValues() {
        return this.ignoreZeroValues;   
    }
    
    /**
     * Sets a flag that controls whether zero values are ignored, 
     * and sends a {@link PlotChangeEvent} to all registered listeners.  This 
     * only affects whether or not a label appears for the non-visible
     * pie section.
     * 
     * @param flag  the flag.
     */
    public void setIgnoreZeroValues(boolean flag) {
        this.ignoreZeroValues = flag;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    //// SECTION PAINT ////////////////////////////////////////////////////////

    /**
     * Returns the paint for ALL sections in the plot.
     *
     * @return The paint (possibly <code>null</code>).
     */
    public Paint getDotPaint() {
        return this.dotPaint;
    }

    /**
     * Sets the paint for ALL sections in the plot.  If this is set to
     * </code>null</code>, then a list of paints is used instead (to allow
     * different colors to be used for each section).
     *
     * @param paint  the paint (<code>null</code> permitted).
     */
    public void setDotPaint(Paint paint) {
        this.dotPaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the paint for the specified section.
     * 
     * @param section  the section index (zero-based).
     * 
     * @return The paint (never <code>null</code>).
     */
    public Paint getDotPaint(int dot) {
        
        // return the override, if there is one...
        if (this.dotPaint != null) {
            return this.dotPaint;
        }

        // otherwise look up the paint list
        Paint result = this.dotPaintList.getPaint(dot);
        if (result == null) {
            DrawingSupplier supplier = getDrawingSupplier();
            if (supplier != null) {
                Paint p = supplier.getNextPaint();
                this.dotPaintList.setPaint(dot, p);
                result = p;
            }
            else {
                result = this.baseSectionPaint;
            }
        }
        return result;
       
    }
    
    /**
     * Sets the paint used to fill a section of the pie and sends a 
     * {@link PlotChangeEvent} to all registered listeners.
     *
     * @param section  the section index (zero-based).
     * @param paint  the paint (<code>null</code> permitted).
     */
    public void setSectionPaint(int section, Paint paint) {
        this.dotPaintList.setPaint(section, paint);
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the base section paint.  This is used when no other paint is 
     * available.
     * 
     * @return The paint (never <code>null</code>).
     */
    public Paint getBaseSectionPaint() {
        return this.baseSectionPaint;   
    }
    
    /**
     * Sets the base section paint.
     * 
     * @param paint  the paint (<code>null</code> not permitted).
     */
    public void setBaseSectionPaint(Paint paint) {
        if (paint == null) {
            throw new IllegalArgumentException("Null 'paint' argument.");   
        }
        this.baseSectionPaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    //// SECTION OUTLINE PAINT ////////////////////////////////////////////////

    /**
     * Returns the flag that controls whether or not the outline is drawn for
     * each pie section.
     * 
     * @return The flag that controls whether or not the outline is drawn for
     *         each pie section.
     */
    public boolean getSectionOutlinesVisible() {
        return this.sectionOutlinesVisible;
    }
    
    /**
     * Sets the flag that controls whether or not the outline is drawn for 
     * each pie section, and sends a {@link PlotChangeEvent} to all registered
     * listeners.
     * 
     * @param visible  the flag.
     */
    public void setSectionOutlinesVisible(boolean visible) {
        this.sectionOutlinesVisible = visible;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the outline paint for ALL sections in the plot.
     *
     * @return The paint (possibly <code>null</code>).
     */
    public Paint getSectionOutlinePaint() {
        return this.sectionOutlinePaint;
    }

    /**
     * Sets the outline paint for ALL sections in the plot.  If this is set to
     * </code>null</code>, then a list of paints is used instead (to allow
     * different colors to be used for each section).
     *
     * @param paint  the paint (<code>null</code> permitted).
     */
    public void setSectionOutlinePaint(Paint paint) {
        this.sectionOutlinePaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the paint for the specified section.
     * 
     * @param section  the section index (zero-based).
     * 
     * @return The paint (never <code>null</code>).
     */
    public Paint getSectionOutlinePaint(int section) {
        
        // return the override, if there is one...
        if (this.sectionOutlinePaint != null) {
            return this.sectionOutlinePaint;
        }

        // otherwise look up the paint list
        Paint result = this.sectionOutlinePaintList.getPaint(section);
        if (result == null) {
            result = this.baseSectionOutlinePaint;
        }
        return result;
       
    }
    
    /**
     * Sets the paint used to fill a section of the pie and sends a 
     * {@link PlotChangeEvent} to all registered listeners.
     *
     * @param section  the section index (zero-based).
     * @param paint  the paint (<code>null</code> permitted).
     */
    public void setSectionOutlinePaint(int section, Paint paint) {
        this.sectionOutlinePaintList.setPaint(section, paint);
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the base section paint.  This is used when no other paint is 
     * available.
     * 
     * @return The paint (never <code>null</code>).
     */
    public Paint getBaseSectionOutlinePaint() {
        return this.baseSectionOutlinePaint;   
    }
    
    /**
     * Sets the base section paint.
     * 
     * @param paint  the paint (<code>null</code> not permitted).
     */
    public void setBaseSectionOutlinePaint(Paint paint) {
        if (paint == null) {
            throw new IllegalArgumentException("Null 'paint' argument.");   
        }
        this.baseSectionOutlinePaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    //// SECTION OUTLINE STROKE ///////////////////////////////////////////////

    /**
     * Returns the outline stroke for ALL sections in the plot.
     *
     * @return The stroke (possibly <code>null</code>).
     */
    public Stroke getSectionOutlineStroke() {
        return this.sectionOutlineStroke;
    }

    /**
     * Sets the outline stroke for ALL sections in the plot.  If this is set to
     * </code>null</code>, then a list of paints is used instead (to allow
     * different colors to be used for each section).
     *
     * @param stroke  the stroke (<code>null</code> permitted).
     */
    public void setSectionOutlineStroke(Stroke stroke) {
        this.sectionOutlineStroke = stroke;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the stroke for the specified section.
     * 
     * @param section  the section index (zero-based).
     * 
     * @return The stroke (never <code>null</code>).
     */
    public Stroke getSectionOutlineStroke(int section) {
        
        // return the override, if there is one...
        if (this.sectionOutlineStroke != null) {
            return this.sectionOutlineStroke;
        }

        // otherwise look up the paint list
        Stroke result = this.sectionOutlineStrokeList.getStroke(section);
        if (result == null) {
            result = this.baseSectionOutlineStroke;
        }
        return result;
       
    }
    
    /**
     * Sets the stroke used to fill a section of the pie and sends a 
     * {@link PlotChangeEvent} to all registered listeners.
     *
     * @param section  the section index (zero-based).
     * @param stroke  the stroke (<code>null</code> permitted).
     */
    public void setSectionOutlineStroke(int section, Stroke stroke) {
        this.sectionOutlineStrokeList.setStroke(section, stroke);
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the base section stroke.  This is used when no other stroke is 
     * available.
     * 
     * @return The stroke (never <code>null</code>).
     */
    public Stroke getBaseSectionOutlineStroke() {
        return this.baseSectionOutlineStroke;   
    }
    
    /**
     * Sets the base section stroke.
     * 
     * @param stroke  the stroke (<code>null</code> not permitted).
     */
    public void setBaseSectionOutlineStroke(Stroke stroke) {
        if (stroke == null) {
            throw new IllegalArgumentException("Null 'stroke' argument.");   
        }
        this.baseSectionOutlineStroke = stroke;
        notifyListeners(new PlotChangeEvent(this));
    }

    
    /**
     * Returns the amount that a section should be 'exploded'.
     *
     * @param section  the section number.
     *
     * @return The amount that a section should be 'exploded'.
     */
    public double getExplodePercent(int section) {
        double result = 0.0;
        if (this.explodePercentages != null) {
            Number percent = (Number) this.explodePercentages.get(section);
            if (percent != null) {
                result = percent.doubleValue();
            }
        }
        return result;
    }

    /**
     * Sets the amount that a pie section should be exploded and sends a 
     * {@link PlotChangeEvent} to all registered listeners.
     *
     * @param section  the section index.
     * @param percent  the explode percentage (0.30 = 30 percent).
     */
    public void setExplodePercent(int section, double percent) {
        if (this.explodePercentages == null) {
            this.explodePercentages = new ObjectList();
        }
        this.explodePercentages.set(section, new Double(percent));
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the maximum explode percent.
     * 
     * @return The percent.
     */
    public double getMaximumExplodePercent() {
        double result = 0.0;
        for (int i = 0; i < this.explodePercentages.size(); i++) {
            Number explode = (Number) this.explodePercentages.get(i);
            if (explode != null) {
                result = Math.max(result, explode.doubleValue());   
            }
        }
        return result;
    }
    
    /**
     * Returns the section label generator. 
     * 
     * @return The generator (possibly <code>null</code>).
     */
    public PieSectionLabelGenerator getLabelGenerator() {
        return this.labelGenerator;   
    }
    
    /**
     * Sets the section label generator and sends a {@link PlotChangeEvent} to
     * all registered listeners.
     * 
     * @param generator  the generator (<code>null</code> permitted).
     */
    public void setLabelGenerator(PieSectionLabelGenerator generator) {
        this.labelGenerator = generator;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the gap between the edge of the pie and the labels, expressed as 
     * a percentage of the plot width.
     * 
     * @return The gap (a percentage, where 0.05 = five percent).
     */
    public double getLabelGap() {
        return this.labelGap;   
    }
    
    /**
     * Sets the gap between the edge of the pie and the labels (expressed as a 
     * percentage of the plot width) and sends a {@link PlotChangeEvent} to all
     * registered listeners.
     * 
     * @param gap  the gap (a percentage, where 0.05 = five percent).
     */
    public void setLabelGap(double gap) {
        this.labelGap = gap;   
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the maximum label width as a percentage of the plot width.
     * 
     * @return The width (a percentage, where 0.20 = 20 percent).
     */
    public double getMaximumLabelWidth() {
        return this.maximumLabelWidth;   
    }
    
    /**
     * Sets the maximum label width as a percentage of the plot width and sends
     * a {@link PlotChangeEvent} to all registered listeners.
     * 
     * @param width  the width (a percentage, where 0.20 = 20 percent).
     */
    public void setMaximumLabelWidth(double width) {
        this.maximumLabelWidth = width;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the flag that controls whether or not label linking lines are
     * visible.
     * 
     * @return A boolean.
     */
    public boolean getLabelLinksVisible() {
        return this.labelLinksVisible;
    }
    
    /**
     * Sets the flag that controls whether or not label linking lines are 
     * visible and sends a {@link PlotChangeEvent} to all registered listeners.
     * Please take care when hiding the linking lines - depending on the data 
     * values, the labels can be displayed some distance away from the
     * corresponding pie section.
     * 
     * @param visible  the flag.
     */
    public void setLabelLinksVisible(boolean visible) {
        this.labelLinksVisible = visible;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the margin (expressed as a percentage of the width or height) 
     * between the edge of the pie and the link point.
     * 
     * @return The link margin (as a percentage, where 0.05 is five percent).
     */
    public double getLabelLinkMargin() {
        return this.labelLinkMargin;   
    }
    
    /**
     * Sets the link margin and sends a {@link PlotChangeEvent} to all 
     * registered listeners.
     * 
     * @param margin  the margin.
     */
    public void setLabelLinkMargin(double margin) {
        this.labelLinkMargin = margin;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the paint used for the lines that connect pie sections to their 
     * corresponding labels.
     * 
     * @return The paint (never <code>null</code>).
     */
    public Paint getLabelLinkPaint() {
        return this.labelLinkPaint;   
    }
    
    /**
     * Sets the paint used for the lines that connect pie sections to their 
     * corresponding labels, and sends a {@link PlotChangeEvent} to all 
     * registered listeners.
     * 
     * @param paint  the paint (<code>null</code> not permitted).
     */
    public void setLabelLinkPaint(Paint paint) {
        if (paint == null) {
            throw new IllegalArgumentException("Null 'paint' argument.");
        }
        this.labelLinkPaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the stroke used for the label linking lines.
     * 
     * @return The stroke.
     */
    public Stroke getLabelLinkStroke() {
        return this.labelLinkStroke;   
    }
    
    /**
     * Sets the link stroke and sends a {@link PlotChangeEvent} to all 
     * registered listeners.
     * 
     * @param stroke  the stroke.
     */
    public void setLabelLinkStroke(Stroke stroke) {
        if (stroke == null) {
            throw new IllegalArgumentException("Null 'stroke' argument.");
        }
        this.labelLinkStroke = stroke;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the section label font.
     *
     * @return The font (never <code>null</code>).
     */
    public Font getLabelFont() {
        return this.labelFont;
    }

    /**
     * Sets the section label font and sends a {@link PlotChangeEvent} to all 
     * registered listeners.
     *
     * @param font  the font (<code>null</code> not permitted).
     */
    public void setLabelFont(Font font) {
        if (font == null) {
            throw new IllegalArgumentException("Null 'font' argument.");
        }
        this.labelFont = font;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the section label paint.
     *
     * @return The paint (never <code>null</code>).
     */
    public Paint getLabelPaint() {
        return this.labelPaint;
    }

    /**
     * Sets the section label paint and sends a {@link PlotChangeEvent} to all 
     * registered listeners.
     *
     * @param paint  the paint (<code>null</code> not permitted).
     */
    public void setLabelPaint(Paint paint) {
        if (paint == null) {
            throw new IllegalArgumentException("Null 'paint' argument.");
        }
        this.labelPaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the section label background paint.
     *
     * @return The paint (possibly <code>null</code>).
     */
    public Paint getLabelBackgroundPaint() {
        return this.labelBackgroundPaint;
    }

    /**
     * Sets the section label background paint and sends a 
     * {@link PlotChangeEvent} to all registered listeners.
     *
     * @param paint  the paint (<code>null</code> permitted).
     */
    public void setLabelBackgroundPaint(Paint paint) {
        this.labelBackgroundPaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the section label outline paint.
     *
     * @return The paint (possibly <code>null</code>).
     */
    public Paint getLabelOutlinePaint() {
        return this.labelOutlinePaint;
    }

    /**
     * Sets the section label outline paint and sends a 
     * {@link PlotChangeEvent} to all registered listeners.
     *
     * @param paint  the paint (<code>null</code> permitted).
     */
    public void setLabelOutlinePaint(Paint paint) {
        this.labelOutlinePaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the section label outline stroke.
     *
     * @return The stroke (possibly <code>null</code>).
     */
    public Stroke getLabelOutlineStroke() {
        return this.labelOutlineStroke;
    }

    /**
     * Sets the section label outline stroke and sends a 
     * {@link PlotChangeEvent} to all registered listeners.
     *
     * @param stroke  the stroke (<code>null</code> permitted).
     */
    public void setLabelOutlineStroke(Stroke stroke) {
        this.labelOutlineStroke = stroke;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the section label shadow paint.
     *
     * @return The paint (possibly <code>null</code>).
     */
    public Paint getLabelShadowPaint() {
        return this.labelShadowPaint;
    }

    /**
     * Sets the section label shadow paint and sends a {@link PlotChangeEvent}
     * to all registered listeners.
     *
     * @param paint  the paint (<code>null</code> permitted).
     */
    public void setLabelShadowPaint(Paint paint) {
        this.labelShadowPaint = paint;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the tool tip generator, an object that is responsible for 
     * generating the text items used for tool tips by the plot.  If the 
     * generator is <code>null</code>, no tool tips will be created.
     *
     * @return The generator (possibly <code>null</code>).
     */
    public PieToolTipGenerator getToolTipGenerator() {
        return this.toolTipGenerator;
    }

    /**
     * Sets the tool tip generator and sends a {@link PlotChangeEvent} to all 
     * registered listeners.  Set the generator to <code>null</code> if you 
     * don't want any tool tips.
     *
     * @param generator  the generator (<code>null</code> permitted).
     */
    public void setToolTipGenerator(PieToolTipGenerator generator) {
        this.toolTipGenerator = generator;
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Returns the URL generator.
     *
     * @return The generator (possibly <code>null</code>).
     */
    public PieURLGenerator getURLGenerator() {
        return this.urlGenerator;
    }

    /**
     * Sets the URL generator and sends a {@link PlotChangeEvent} to all 
     * registered listeners.
     *
     * @param generator  the generator (<code>null</code> permitted).
     */
    public void setURLGenerator(PieURLGenerator generator) {
        this.urlGenerator = generator;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the shape used for legend items.
     * 
     * @return The shape.
     */
    public Shape getLegendItemShape() {
        return this.legendItemShape;
    }

    /**
     * Sets the shape used for legend items.
     * 
     * @param shape  the shape (<code>null</code> not permitted).
     */
    public void setLegendItemShape(Shape shape) {
        if (shape == null) {
            throw new IllegalArgumentException("Null 'shape' argument.");
        }
        this.legendItemShape = shape;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the legend label tool tip generator.
     * 
     * @return The legend label tool tip generator (possibly <code>null</code>).
     */
    public PieSectionLabelGenerator getLegendLabelToolTipGenerator() {
        return this.legendLabelToolTipGenerator;
    }
    
    /**
     * Sets the legend label tool tip generator and sends a 
     * {@link PlotChangeEvent} to all registered listeners.
     * 
     * @param generator  the generator (<code>null</code> permitted).
     */
    public void setLegendLabelToolTipGenerator(
            PieSectionLabelGenerator generator) {
        this.legendLabelToolTipGenerator = generator;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Returns the legend label generator.
     * 
     * @return The legend label generator (never <code>null</code>).
     */
    public PieSectionLabelGenerator getLegendLabelGenerator() {
        return this.legendLabelGenerator;
    }
    
    /**
     * Sets the legend label generator and sends a {@link PlotChangeEvent} to 
     * all registered listeners.
     * 
     * @param generator  the generator (<code>null</code> not permitted).
     */
    public void setLegendLabelGenerator(PieSectionLabelGenerator generator) {
        if (generator == null) {
            throw new IllegalArgumentException("Null 'generator' argument.");
        }
        this.legendLabelGenerator = generator;
        notifyListeners(new PlotChangeEvent(this));
    }
    
    /**
     * Initialises the drawing procedure.  This method will be called before 
     * the first item is rendered, giving the plot an opportunity to initialise
     * any state information it wants to maintain.
     *
     * @param g2  the graphics device.
     * @param plotArea  the plot area (<code>null</code> not permitted).
     * @param plot  the plot.
     * @param index  the secondary index (<code>null</code> for primary 
     *               renderer).
     * @param info  collects chart rendering information for return to caller.
     * 
     * @return A state object (maintains state information relevant to one 
     *         chart drawing).
     */
    public PiePlotState initialise(Graphics2D g2, Rectangle2D plotArea,
            RadVizPlot plot, Integer index, PlotRenderingInfo info) {
     
        PiePlotState state = new PiePlotState(info);
        return state;
        
    }
    
    /**
     * Draws the plot on a Java 2D graphics device (such as the screen or a 
     * printer).
     *
     * @param g2  the graphics device.
     * @param area  the area within which the plot should be drawn.
     * @param anchor  the anchor point (<code>null</code> permitted).
     * @param parentState  the state from the parent plot, if there is one.
     * @param info  collects info about the drawing 
     *              (<code>null</code> permitted).
     */
    public void draw(Graphics2D g2, Rectangle2D area, Point2D anchor,
                     PlotState parentState, PlotRenderingInfo info) {

        // adjust for insets...
        RectangleInsets insets = getInsets();
        insets.trim(area);

        if (info != null) {
            info.setPlotArea(area);
            info.setDataArea(area);
        }

        drawBackground(g2, area);
        drawOutline(g2, area);

        Shape savedClip = g2.getClip();
        g2.clip(area);

        Composite originalComposite = g2.getComposite();
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 
                getForegroundAlpha()));

       
        if (null!=this.dataset){
            drawRadViz(g2, area, info);  
        }
        else {
            drawNoDataMessage(g2, area);
        }

        g2.setClip(savedClip);
        g2.setComposite(originalComposite);

        drawOutline(g2, area);

    }

    /**
     * Draws the pie.
     *
     * @param g2  the graphics device.
     * @param plotArea  the plot area.
     * @param info  chart rendering info.
     */
    @SuppressWarnings("unchecked")
	protected void drawRadViz(Graphics2D g2, Rectangle2D plotArea, 
                           PlotRenderingInfo info) {
    	
    	
        PiePlotState state = initialise(g2, plotArea, this, null, info);

        // adjust the plot area for interior spacing and labels...
        double labelWidth = 0.0;
        if (this.labelGenerator != null) {
            labelWidth = this.labelGap + this.maximumLabelWidth 
                         + this.labelLinkMargin;    
        }
        double gapHorizontal 
            = plotArea.getWidth() * (this.interiorGap + labelWidth);
        double gapVertical = plotArea.getHeight() * this.interiorGap;

        double linkX = plotArea.getX() + gapHorizontal / 2;
        double linkY = plotArea.getY() + gapVertical / 2;
        double linkW = plotArea.getWidth() - gapHorizontal;
        double linkH = plotArea.getHeight() - gapVertical;
        
        double min = Math.min(linkW, linkH) / 2;
        linkX = (linkX + linkX + linkW) / 2 - min;
        linkY = (linkY + linkY + linkH) / 2 - min;
        linkW = 2 * min;
        linkH = 2 * min;
            
        
        
        // make the link area a square if the pie chart is to be circular...
        
        g2.setColor(Color.black);
        g2.drawOval((int)linkX, (int)linkY, (int)linkW, (int)linkH);
        
        @SuppressWarnings("unused")
		ArrayList<Double> springXs=dataset.getSpringXs();
        @SuppressWarnings("unused")
		ArrayList<Double> springYs=dataset.getSpringYs();
        ArrayList<Comparable> anchorNames=dataset.getAnchors();
        /*for(int i=0; i<springXs.size(); i++){
        	double x=springXs.get(i);
        	double y=springYs.get(i);
        	//g2.drawLine((int)(linkX + linkW/2 + (linkW*x)/2),(int)(linkY + linkH/2 + (linkH*y)/2),(int)(linkX+ linkW/2),(int)(linkY +  linkH/2));
        	//g2.drawString((String)anchorNames.get(i), (int)(linkX + linkW/2 + (linkW*x)/2), (int)(linkY + linkH/2 + (linkH*y)/2));
        }*/
        // the link area defines the dog leg points for the linking lines to 
        // the labels
        Rectangle2D linkArea = new Rectangle2D.Double(linkX, linkY, linkW, 
                linkH);
        state.setLinkArea(linkArea);
        
        // the explode area defines the max circle/ellipse for the exploded 
        // pie sections.  it is defined by shrinking the linkArea by the 
        // linkMargin factor.
        double hh = linkArea.getWidth() * this.labelLinkMargin;
        double vv = linkArea.getHeight() * this.labelLinkMargin;
        Rectangle2D explodeArea = new Rectangle2D.Double(linkX + hh / 2.0, 
                linkY + vv / 2.0, linkW - hh, linkH - vv);
       
        state.setExplodedPieArea(explodeArea);
        
        // the pie area defines the circle/ellipse for regular pie sections.
        // it is defined by shrinking the explodeArea by the explodeMargin 
        // factor. 
        double maximumExplodePercent = getMaximumExplodePercent();
        double percent = maximumExplodePercent / (1.0 + maximumExplodePercent);
        
        double h1 = explodeArea.getWidth() * percent;
        double v1 = explodeArea.getHeight() * percent;
        Rectangle2D pieArea = new Rectangle2D.Double(explodeArea.getX() 
                + h1 / 2.0, explodeArea.getY() + v1 / 2.0, 
                explodeArea.getWidth() - h1, explodeArea.getHeight() - v1);

        state.setPieArea(pieArea);
        state.setPieCenterX(pieArea.getCenterX());
        state.setPieCenterY(pieArea.getCenterY());
        state.setPieWRadius(pieArea.getWidth() / 2.0);
        state.setPieHRadius(pieArea.getHeight() / 2.0);
        // plot the data (unless the dataset is null)...
        if ((this.dataset != null) && (this.dataset.getKeys().size() > 0)) {
        	drawLabels(g2, anchorNames, plotArea, linkArea, state);
            List<Comparable> keys = this.dataset.getKeys();
            int paintNum=0;
            for(Comparable key: keys){
            	ArrayList <Double[]> points=this.dataset.getData2D().get(key);
            	if(null!=points){
            		for(Double [] point: points){
                		//System.out.println(key + "  " + point[0] + "  "  + point[1]);
                		int dotSize=(int)Math.ceil((((double)DOT_SIZE)*linkW)/200);
                		this.drawPoint(g2,(int)(linkX - dotSize+ linkW/2 + (linkW*point[0])/2),(int)(linkY - dotSize + linkH/2 + (linkH*point[1])/2), paintNum, dotSize*2);
                	}
                	paintNum++;	
            	}
            	
            }
            
            

        }
        else {
            drawNoDataMessage(g2, plotArea);
        }
    }
    
    protected void drawPoint(Graphics2D g2, int x, int y, int paintNum,int dotSize){
    	Paint paint = getDotPaint(paintNum);
    	g2.setPaint(paint);
    	g2.fillOval(x, y, dotSize, dotSize);
    }
    
    
    
    /**
     * Draws the labels for the pie sections.
     * 
     * @param g2  the graphics device.
     * @param keys  the keys.
     * @param totalValue  the total value.
     * @param plotArea  the plot area.
     * @param linkArea  the link area.
     * @param state  the state.
     */
    protected void drawLabels(Graphics2D g2, ArrayList<Comparable> anchorNames, 
                              Rectangle2D plotArea, Rectangle2D linkArea, 
                              PiePlotState state) {   
    	
        Composite originalComposite = g2.getComposite();
        g2.setComposite(
                AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f));

        // classify the keys according to which side the label will appear...
        @SuppressWarnings("unused")
		DefaultKeyedValues leftKeys = new DefaultKeyedValues();
        DefaultKeyedValues rightKeys = new DefaultKeyedValues();
        ArrayList<Comparable> lefts=new ArrayList<Comparable>();
        ArrayList<Comparable> rights=new ArrayList<Comparable>();
        @SuppressWarnings("unused")
		double runningTotal1 = 0.0;
        //Iterator iterator1 = keys.iterator();
        int anchorsSize=anchorNames.size();
        for(int i=0; i<anchorsSize; i++){
            Comparable key = anchorNames.get(i);
            //System.out.println(keys);
            //boolean include = true;
            if (i>=(Math.ceil(anchorsSize)/2)) {
                //leftKeys.addValue(key,1);
                lefts.add(key);
            }
            else {
                rightKeys.addValue(key,1);
                rights.add(key);
            }
        
        }
       
        
        
        
        g2.setFont(getLabelFont());
        float maxLabelWidth 
            = (float) (getMaximumLabelWidth() * plotArea.getWidth());
        
        // draw the labels...
        if (this.labelGenerator != null) {
            drawLeftLabels(lefts, g2, plotArea, linkArea, maxLabelWidth, 
                    state, rights.size(), lefts.size() );
            drawRightLabels(rights, g2, plotArea, linkArea, maxLabelWidth, 
                    state, rights.size(), lefts.size());
        }
        g2.setComposite(originalComposite);

    }

    /**
     * Draws the left labels.
     * 
     * @param leftKeys  the keys.
     * @param g2  the graphics device.
     * @param plotArea  the plot area.
     * @param linkArea  the link area.
     * @param maxLabelWidth  the maximum label width.
     * @param state  the state.
     */
    protected void drawLeftLabels(ArrayList<Comparable> anchorNames, Graphics2D g2, 
                                  Rectangle2D plotArea, Rectangle2D linkArea, 
                                  float maxLabelWidth, PiePlotState state,int rightNum,int leftNum) {
        
        PieLabelDistributor distributor1 = new PieLabelDistributor(
            anchorNames.size()
        );
        double lGap = plotArea.getWidth() * this.labelGap;
        double verticalLinkRadius = state.getLinkArea().getHeight() / 2.0;
        for (int i = 0; i < anchorNames.size(); i++) {   
        	String label = anchorNames.get(i).toString();
            if (label != null) {
                TextBlock block = TextUtilities.createTextBlock(label, 
                        this.labelFont, this.labelPaint, maxLabelWidth, 
                        new G2TextMeasurer(g2));
                TextBox labelBox = new TextBox(block);
                labelBox.setBackgroundPaint(this.labelBackgroundPaint);
                labelBox.setOutlinePaint(this.labelOutlinePaint);
                labelBox.setOutlineStroke(this.labelOutlineStroke);
                labelBox.setShadowPaint(this.labelShadowPaint);
                double theta = Math.toRadians(
                		((double)(i+rightNum)/(double)(leftNum+rightNum))*360-90
                        );
                double baseY = state.getPieCenterY() - Math.sin(theta) 
                               * verticalLinkRadius;
                double hh = labelBox.getHeight(g2);

                distributor1.addPieLabelRecord(new PieLabelRecord(
                        anchorNames.get(i), theta, baseY, labelBox, hh,
                        lGap / 2.0 + lGap / 2.0 * -Math.cos(theta), 0 
                        ));
            }
        }
        distributor1.distributeLabels(plotArea.getMinY(), plotArea.getHeight());
        for (int i = 0; i < distributor1.getItemCount(); i++) {
            drawLeftLabel(g2, state, distributor1.getPieLabelRecord(i));
        }
    }
    
    /**
     * Draws the right labels.
     * 
     * @param keys  the keys.
     * @param g2  the graphics device.
     * @param plotArea  the plot area.
     * @param linkArea  the link area.
     * @param maxLabelWidth  the maximum label width.
     * @param state  the state.
     */
    protected void drawRightLabels(ArrayList<Comparable> anchorNames, Graphics2D g2, 
                                   Rectangle2D plotArea, Rectangle2D linkArea, 
                                   float maxLabelWidth, PiePlotState state,int rightNum, int leftNum) {

        // draw the right labels...
        PieLabelDistributor distributor2 
            = new PieLabelDistributor(anchorNames.size());
        double lGap = plotArea.getWidth() * this.labelGap;
        double verticalLinkRadius = state.getLinkArea().getHeight() / 2.0;

        for (int i = 0; i < anchorNames.size(); i++) {
        	
        	String label = anchorNames.get(i).toString();
            if (label != null) {
                TextBlock block = TextUtilities.createTextBlock(label, 
                        this.labelFont, this.labelPaint, maxLabelWidth, 
                        new G2TextMeasurer(g2));
                TextBox labelBox = new TextBox(block);
                labelBox.setBackgroundPaint(this.labelBackgroundPaint);
                labelBox.setOutlinePaint(this.labelOutlinePaint);
                labelBox.setOutlineStroke(this.labelOutlineStroke);
                labelBox.setShadowPaint(this.labelShadowPaint);
                //double theta = Math.toRadians(keys.getValue(i).doubleValue());
                double theta = Math.toRadians(
                		((double)i/(double)(leftNum+rightNum))*360-90
                        );
                double baseY = state.getPieCenterY() 
                              - Math.sin(theta) * verticalLinkRadius;
                double hh = labelBox.getHeight(g2);
                distributor2.addPieLabelRecord(new PieLabelRecord(
                        anchorNames.get(i), theta, baseY, labelBox, hh,
                        lGap / 2.0 + lGap / 2.0 * Math.cos(theta), 
                        0 ));
            }
        }
        distributor2.distributeLabels(linkArea.getMinY(), linkArea.getHeight());
        for (int i = 0; i < distributor2.getItemCount(); i++) {
            drawRightLabel(g2, state, distributor2.getPieLabelRecord(i));
        }

    }
    
    /**
     * Returns a collection of legend items for the pie chart.
     *
     * @return The legend items (never <code>null</code>).
     */
    public LegendItemCollection getLegendItems() {
    	
        LegendItemCollection result = new LegendItemCollection();
        if (this.dataset == null) {
            return result;
        }
        List keys = this.dataset.getKeys();
        int dot = 0;
        Shape shape = getLegendItemShape();
        Iterator iterator = keys.iterator();
        while (iterator.hasNext()) {
            Comparable key = (Comparable) iterator.next();
            String label=key.toString();
            String description = label;
            String toolTipText = null;
            /*if (this.legendLabelToolTipGenerator != null) {
                toolTipText 
                    = this.legendLabelToolTipGenerator.generateSectionLabel(
                            this.dataset, key);
            }*/
            String urlText = null;
            Paint paint = getDotPaint(dot);
            Paint outlinePaint = getSectionOutlinePaint(dot);
            Stroke outlineStroke = getSectionOutlineStroke(dot);
            //paint.
            LegendItem item = new LegendItem(label, description, 
                    toolTipText, urlText, true, shape, true, paint, 
                    true, outlinePaint, outlineStroke, 
                    false,          // line not visible
                    new Line2D.Float(), new BasicStroke(), Color.black);
            result.add(item);
            dot++;       	    
            
        }
        return result;
    }

    /**
     * Returns a short string describing the type of plot.
     *
     * @return The plot type.
     */
    public String getPlotType() {
        return localizationResources.getString("Pie_Plot");
    }

    /**
     * A zoom method that does nothing.
     * <p>
     * Plots are required to support the zoom operation.  In the case of a pie
     * chart, it doesn't make sense to zoom in or out, so the method is empty.
     *
     * @param percent  the zoom percentage.
     */
    public void zoom(double percent) {
        // no zooming for pie plots
    }
    
    /**
     * Draws a section label on the left side of the pie chart.
     * 
     * @param g2  the graphics device.
     * @param state  the state.
     * @param record  the label record.
     */
    protected void drawLeftLabel(Graphics2D g2, PiePlotState state, 
                                 PieLabelRecord record) {

        double anchorX = state.getLinkArea().getMinX();
        double targetX = anchorX - record.getGap();
        double targetY = record.getAllocatedY();
        
        if (this.labelLinksVisible) {
            double theta = record.getAngle();
            double linkX = state.getPieCenterX() + Math.cos(theta) 
                * state.getPieWRadius() * record.getLinkPercent();
            double linkY = state.getPieCenterY() - Math.sin(theta) 
                * state.getPieHRadius() * record.getLinkPercent();
            double elbowX = state.getPieCenterX() + Math.cos(theta) 
                * state.getLinkArea().getWidth() / 2.0;
            double elbowY = state.getPieCenterY() - Math.sin(theta) 
                * state.getLinkArea().getHeight() / 2.0;
            double anchorY = elbowY;
            g2.setPaint(this.labelLinkPaint);
            g2.setStroke(this.labelLinkStroke);
            g2.draw(new Line2D.Double(linkX, linkY, elbowX, elbowY));
            g2.draw(new Line2D.Double(anchorX, anchorY, elbowX, elbowY));
            g2.draw(new Line2D.Double(anchorX, anchorY, targetX, targetY));
        }
        TextBox tb = record.getLabel();
        tb.draw(g2, (float) targetX, (float) targetY, RectangleAnchor.RIGHT);
        
    }

    /**
     * Draws a section label on the right side of the pie chart.
     * 
     * @param g2  the graphics device.
     * @param state  the state.
     * @param record  the label record.
     */
    protected void drawRightLabel(Graphics2D g2, PiePlotState state, 
                                  PieLabelRecord record) {
        
        double anchorX = state.getLinkArea().getMaxX();
        double targetX = anchorX + record.getGap();
        double targetY = record.getAllocatedY();
        
        if (this.labelLinksVisible) {
            double theta = record.getAngle();
            double linkX = state.getPieCenterX() + Math.cos(theta) 
                * state.getPieWRadius() * record.getLinkPercent();
            double linkY = state.getPieCenterY() - Math.sin(theta) 
                * state.getPieHRadius() * record.getLinkPercent();
            double elbowX = state.getPieCenterX() + Math.cos(theta) 
                * state.getLinkArea().getWidth() / 2.0;
            double elbowY = state.getPieCenterY() - Math.sin(theta) 
                * state.getLinkArea().getHeight() / 2.0;
            double anchorY = elbowY;
            g2.setPaint(this.labelLinkPaint);
            g2.setStroke(this.labelLinkStroke);
            g2.draw(new Line2D.Double(linkX, linkY, elbowX, elbowY));
            g2.draw(new Line2D.Double(anchorX, anchorY, elbowX, elbowY));
            g2.draw(new Line2D.Double(anchorX, anchorY, targetX, targetY));
        }
        
        TextBox tb = record.getLabel();
        tb.draw(g2, (float) targetX, (float) targetY, RectangleAnchor.LEFT);
    
    }

    /**
     * Returns a clone of the plot.
     *
     * @return A clone.
     *
     * @throws CloneNotSupportedException if some component of the plot does 
     *         not support cloning.
     */
    public Object clone() throws CloneNotSupportedException {

        RadVizPlot clone = (RadVizPlot) super.clone();
        if (clone.dataset != null) {
            clone.dataset.addChangeListener(clone);
        }
        return clone;

    }

    
}
