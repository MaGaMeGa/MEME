package ai.aitia.visu.ds.xy;

import org.jfree.data.xy.XYSeries;

public class ModifiableXYSeries extends XYSeries {
	
	private static final long serialVersionUID = 3766900745817242596L;
	
	public ModifiableXYSeries(Comparable key) {
		this(key,true,true);
	}
	
	public ModifiableXYSeries(Comparable key, boolean autoSort) {
		this(key,autoSort,true);
	}
	
	public ModifiableXYSeries(Comparable key, boolean autoSort, boolean allowDuplicateXValues) {
		super(key,autoSort,allowDuplicateXValues);
	}
	
	public void setItems(XYSeries other) {
		this.data = other.getItems();
		fireSeriesChanged();
	}
	
	public void setItems(XYSeries other, boolean notify) {
		this.data = other.getItems();
		if (notify) fireSeriesChanged();
	}
}
