package ai.aitia.chart.util;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.AbstractList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public class ConstantList<E> extends AbstractList<E> implements List<E>,
																RandomAccess,
																Cloneable,
																Serializable {

	//====================================================================================================
	// members
	
	private static final long serialVersionUID = -7732009607424973L;
	private E element;
	private int size;

	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public ConstantList(final E element, final int size) {
		super();
		this.element = element;
		this.size = size;
	}
	
	//----------------------------------------------------------------------------------------------------
	public ConstantList(final E element) { this(element,Integer.MAX_VALUE); }

	//----------------------------------------------------------------------------------------------------
	@Override public boolean equals(Object o) {
		if (o instanceof ConstantList) {
			final ConstantList that = (ConstantList) o;
			return element.equals(that.element);
		}
		return false;
	}
	
	//----------------------------------------------------------------------------------------------------
	@Override public int hashCode() { return element.hashCode(); }
	
	//----------------------------------------------------------------------------------------------------
	@Override public String toString() { return "[size: " + size + ", value: " + element + "]"; }
	
	//----------------------------------------------------------------------------------------------------
	@Override public ConstantList<E> clone() {
		try {
			@SuppressWarnings("unchecked") final ConstantList<E> clone = (ConstantList<E>) super.clone();
			clone.size = size;
			clone.element = element;
			return clone;
		} catch (CloneNotSupportedException e) {
		    // this shouldn't happen, since we are Cloneable
		    throw new InternalError();
		}
	}

	//====================================================================================================
	// implemented interfaces

	//----------------------------------------------------------------------------------------------------
	@Override public E get(final int index) {
		rangeCheck(index);
		return element;
	}
	
	//----------------------------------------------------------------------------------------------------
	@Override public int size() { return size; }
	@Override public boolean add(E e) { throw new UnsupportedOperationException(); }
	@Override public void add(final int index, final  E element) { throw new UnsupportedOperationException(); }
	public boolean addAll(final Collection<? extends E> c) { throw new UnsupportedOperationException(); }
	@Override public boolean addAll(final int index, final Collection<? extends E> c) { throw new UnsupportedOperationException(); }
	@Override public void clear() { throw new UnsupportedOperationException(); }
	@Override public E remove(final int index) { throw new UnsupportedOperationException(); }
	public boolean remove(final Object o) { throw new UnsupportedOperationException(); }
	public boolean removeAll(final Collection<?> c) { throw new UnsupportedOperationException(); }
	@Override public E set(final int index, final E element) { throw new UnsupportedOperationException(); }
	public boolean isEmpty() { return false; }
	public boolean retainAll(final Collection<?> c) { throw new UnsupportedOperationException(); }
	public ListIterator<E> listIterator() { return new ConstantListIterator(); }
	public ListIterator<E> listIterator(final int index) { return new ConstantListIterator(index); }
	public boolean contains(final Object o) { return indexOf(o) != -1; }
	
	//----------------------------------------------------------------------------------------------------
	@Override
	public int indexOf(final Object o) {
		if (o == null && element != null)
			return -1;
		return o.equals(element) ? 0 : -1;
	}

	//----------------------------------------------------------------------------------------------------
	@Override
	public int lastIndexOf(final Object o) {
		if (o == null && element != null)
			return -1;
		return o.equals(element) ? size - 1 : -1;
	}

    //----------------------------------------------------------------------------------------------------
	public Iterator<E> iterator() {
		return new Iterator<E>() {
			private int idx = 0;
			
			//----------------------------------------------------------------------------------------------------
			public boolean hasNext() { return idx < ConstantList.this.size(); }
			public void remove() { throw new UnsupportedOperationException(); }
			
			//----------------------------------------------------------------------------------------------------
			public E next() { 
				idx++;
				return element;
			}
		};
	}

    //----------------------------------------------------------------------------------------------------
	public Object[] toArray() {
		final Object[] result = new Object[size];
		Arrays.fill(result,element);
		return result;
	}
	
    //----------------------------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	public <T> T[] toArray(T[] a) {
        if (a.length < size) 
            a = (T[]) Array.newInstance(a.getClass().getComponentType(),size);
        for (int i = 0;i < size;++i)
        	a[i] = (T) element;
        if (a.length > size) {
        	for (int i = size;i < a.length;++i)
        		a[i] = null;
        }
        return a;
	}

    //----------------------------------------------------------------------------------------------------
	public boolean containsAll(final Collection<?> c) {
		if (c instanceof ConstantList) {
			final ConstantList cl = (ConstantList) c;
			return element.equals(cl.element);
		}
		for (final Object o : c) {
			if (!element.equals(o)) return false; 
		}
		return true;
	}

    //----------------------------------------------------------------------------------------------------
	public List<E> subList(final int fromIndex, final int toIndex) {
		if (fromIndex < 0 || toIndex > size)
			throw new IndexOutOfBoundsException("Invalid indices.");
		if (fromIndex > toIndex)
			throw new IllegalArgumentException("'fromIndex' is greater than 'toIndex'.");
		if (fromIndex == toIndex)
			return Collections.<E>emptyList();
		return new ConstantList<E>(element,toIndex - fromIndex);
	}
	
	//====================================================================================================
	// assistant methods
	
	//----------------------------------------------------------------------------------------------------
	private void rangeCheck(final int index) throws IndexOutOfBoundsException {
		if (index < 0 || index >= size)
		    throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
	}
	
	//====================================================================================================
	// nested classes
	
	//----------------------------------------------------------------------------------------------------
	private class ConstantListIterator implements ListIterator<E> {

		//====================================================================================================
		// members
		
		private int idx;
		
		//====================================================================================================
		// methods
		
		//----------------------------------------------------------------------------------------------------
		public ConstantListIterator() { this(0); }
		
		//----------------------------------------------------------------------------------------------------
		public ConstantListIterator(final int idx) {
			ConstantList.this.rangeCheck(idx);
			this.idx = idx;
		}
		
		//====================================================================================================
		// implemented interfaces
		
		//----------------------------------------------------------------------------------------------------
		public void add(final E e) { throw new UnsupportedOperationException(); }
		public boolean hasNext() { return idx < ConstantList.this.size(); }
		public boolean hasPrevious() { return idx != 0; }
		public int nextIndex() { return idx; }
		public int previousIndex() { return idx - 1; }
		public void set(final E e) { throw new UnsupportedOperationException();	}
		public void remove() { throw new UnsupportedOperationException(); }

	    //----------------------------------------------------------------------------------------------------
		public E previous() {
	    	idx--;
	        return element;
        }

		//----------------------------------------------------------------------------------------------------
		public E next() {
			idx++;
			return element;
		}
	}
}