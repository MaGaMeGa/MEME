/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLLoadingException;
import ai.aitia.visu.ds.TimeSeriesCollectionProducer;

/** Configuration object for charts. */
public class ChartConfig {
	
	/** Data source storage.*/
	private DataSources dataSources = null;
	
	/** Properties object of the chart. */
	private Object chartProperties = null;
	
	private Object other = null;
	
	/** Storage for chart configuration objects. If the chart is multi-layered, this
	 *  storage contains the addtional configuration object that describes the other
	 *  layers.
	 */
	private ArrayList<ChartConfig> childs = null;
	
	/** The type of the chart. */
	private String chartType = null;
	
	/** Whether generates a data changing event when the chart is displayed or not. (If
	 *  we have static data sources, we need set true this flag, otherwise the display
	 *  panel will be empty. The chart is drawn only when the data changes.)
	 */
	private boolean fireInitialEvent = false;
	
	//===============================================================================
	// methods
	
	/** Constructor.
	 * @param dataSources the data source storage used by this configuration object
	 */
	public ChartConfig(DataSources dataSources) {
		this.dataSources = dataSources;
		// chartProperties remains null.
		// chartType remains null.
	}
	
	//-------------------------------------------------------------------------------
	/** It returns the data sources storage.
	 * @return data sources storage
	 */
	public DataSources getDataSources() {
		return dataSources;
	}

	//-------------------------------------------------------------------------------
	/** It returns the number of the data sources in the storage.
	 * @return number of the data sources
	 */
	public int getDataSourceCount(){
		return dataSources.getDataSourceCount();
	}

	//-------------------------------------------------------------------------------
	/** It returns the data source specified by <code>index</code>.
	 * @param index index of the data source
	 * @return a data source object
	 */
	public IDataSourceProducer getDataSource(int index) {
		return dataSources.getDataSource(index);
	}

	//-------------------------------------------------------------------------------
	/** It returns the type of the data source specified by <code>index</code>.
	 * @param index index of the data source
	 * @return type of an data source
	 */
	public Class getDataSourceType(int index) {
		return dataSources.getDataSourceType(index);
	}
	
	//-------------------------------------------------------------------------------
	/** This method adds a new data source (with new type) to the config.
	 * 
	 * @param dsp the data source.
	 * @param type type of the data source
	 * @return the key of the datasource
	 */
	public int addDataSource(IDataSourceProducer dsp, Class type) {
		return dataSources.addDataSource(dsp,type);
	}
	
	//-------------------------------------------------------------------------------
	/** This method deletes the data sources of the chart configuration object. This
	 *  deletion in not certainly real removal, it may be a simple reference count
	 *  decrementing. */
	public void clearAllDataSource() {
		dataSources.deleteDataSources(this);
	}
	
	//-------------------------------------------------------------------------------
	/** This method returns a list that contains the IDs of the data sources
	 *  used by the chart.
	 * @return list of Integer that contains data source IDs.
	 */ 
	public List<Integer> getDataSourceIDs() {
		return AbstractChart.find(chartType).getDataSourceIDs(this);
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the key of the data source specified by <code>dsp</code> and 
	 *   <code>type</code>. If the specified data source isn't in the storage, it
	 *   returns -1.
	 *  @param dsp the data source
	 *  @param type type of the data source
	 *  @return key of the data source
	 */
	public int find(IDataSourceProducer dsp, Class type) { 
		return dataSources.find(dsp,type).intValue();
	}
	
	//-------------------------------------------------------------------------------
	/** It returns the properties object of the chart.
	 * @return properties of the chart
	 */
	public Object getChartProperties() {
		return chartProperties;
	}

	//-------------------------------------------------------------------------------
	/** It returns the type of the chart.
	 * @return a string that contains the type of the chart.
	 */
	public String getChartType() {
		return chartType;
	}

	//-------------------------------------------------------------------------------
	/** This method sets the type and the properties object of the chart.
	 * @param chartType a string that contains the type of the chart
	 * @param properties properties object of the chart
	 */
	public void setChartProperties(String chartType, Object properties) {
		this.chartType = chartType;
		chartProperties = properties;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns whether the configured chart is multi-layered or not. */
	public boolean isMultiLayerChart() {
		return (childs != null);
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the list of child configuration objects if the top configuration
	 *  object describes a multilayer-chart. Otherwise returns <code>null</code>.
	 * @return list of configuration objects
	 */
	public ArrayList<ChartConfig> getChilds() {
		return childs;
	}
	
	//-------------------------------------------------------------------------------
	/** Adds a new configuration object to the multilayer-chart.
	 * 
	 * @param config child configuration object
	 * @return the index of the child configuration object
	 */
	public int addNewChild(ChartConfig config) {
		if (childs == null) childs = new ArrayList<ChartConfig>(); 
		childs.add(config);
		return childs.indexOf(config);
	}
	
	//-------------------------------------------------------------------------------
	/** Remove the child configuration object <code>config</code>.
	 * 
	 * @param config the removeable configuration object
	 */
	public void removeChild(ChartConfig config) {
		config.clearAllDataSource();
		childs.remove(config);
		if (childs.isEmpty()) childs = null;
	}

	//-------------------------------------------------------------------------------
	/** This method saves the config into the XML node. It uses the 
	 * {@link AbstractChart#saveChartProperties(ChartConfig,Node)
	 *  saveChartProperties()} method of the appropriate chart class.
	 * @param node destination XML node
	 */
	public void save(Node node) {
		if (chartProperties == null) return;
		Document document = node.getOwnerDocument();

		Element chartconfig = document.createElement("chartconfig");
		chartconfig.setAttribute("type",chartType);
		chartconfig.setAttribute("fireInitialEvent",String.valueOf(fireInitialEvent));
		AbstractChart.find(chartType).saveChartProperties(this,chartconfig);
		if (childs != null) 
			for (ChartConfig cc : childs) cc.save(chartconfig);
		node.appendChild(chartconfig);
	} 
	
	//-------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	public void saveTemplate(Node node, List<String> exceptions) {
		if (chartProperties == null) return;
		String templateName = getTemplateName();  
		if (templateName != null && !exceptions.contains(templateName) && AbstractChart.templates.get(templateName) != null) {
			Element template = (Element) AbstractChart.templates.get(templateName);
			Element clone = Utilities.cloneAndChangeOwner(template,node.getOwnerDocument());
			node.appendChild(clone);
			exceptions.add(templateName);
		}
		if (childs != null)
			for (ChartConfig cc : childs) cc.saveTemplate(node,exceptions);
	}
	
	//-------------------------------------------------------------------------------
	private String getTemplateName() {
		if (chartProperties instanceof Properties) {
			Properties prop = (Properties) chartProperties;
			return prop.getProperty(ChartConstants.CUSTOM_APPEARANCE);
		}
		return null;
	}
	
	//-------------------------------------------------------------------------------
	/** This factory-method creates a chart configuration object from an XML node and
	 *  a data source storage object. It uses the {@link AbstractChart#loadChartProperties(ChartConfig,Node) 
	 *  loadChartProperties() } method of the appropriate chart class. 
     * @param node source XML node
     * @param dataSources a data source storage object
	 * @return a chart configuration object
	 * @throws XMLLoadingException if any problems occure during parsing of the XML node
	 */ 
	public static ChartConfig load(Node node, DataSources dataSources)
			throws XMLLoadingException {
		ChartConfig config = new ChartConfig(dataSources);
		
		if (!(node instanceof Element)) {
			throw new XMLLoadingException("Invalid XML-file!");
		}
		Element chartconfig = (Element)node;
		String cc_string = chartconfig.getAttribute("type");
		if (cc_string.equals("")) {
			throw new XMLLoadingException("Invalid XML-file. There is no 'type' attribute of the node: <" +
										  chartconfig.getNodeName() + ">");
		}
		config.chartType = cc_string;
		AbstractChart ac = AbstractChart.find(config.chartType);
		if (ac == null) {
			throw new XMLLoadingException("Invalid XML-file. The 'type' of <" + chartconfig.getNodeName() +
					  "> is not registered: " + cc_string);
		}
		String fireIE_string = chartconfig.getAttribute("fireInitialEvent");
		config.fireInitialEvent = fireIE_string.equals("") ? false : Boolean.parseBoolean(fireIE_string);
		ac.loadChartProperties(config,chartconfig);
		config.dataSources.updateRefCnt(config);
		
		NodeList nodes = chartconfig.getElementsByTagName("chartconfig");

		for (int i=0;i<nodes.getLength();++i) {
			Element ccc_element = null;
			try {
				ccc_element = (Element)nodes.item(i);
			} catch (ClassCastException e ) {
				throw new XMLLoadingException("Invalid XML-file: missing <chartconfig> tag");
			}
			ChartConfig ccc = ChartConfig.load(ccc_element,dataSources);
			config.addNewChild(ccc);
		}
		return config;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the collection of the available data sources.
	 * @return collection of the available data sources
	 */
	public IDSPCollection getDSPCollection() {
		return dataSources.getDSPCollection();
	}
	
	//-------------------------------------------------------------------------------
	/** It returns whether the object fires a data changed event or not. */
	public boolean isFireInitialEvent() {
		return fireInitialEvent;
	}
	
	//-------------------------------------------------------------------------------
	/** Sets the <code>fireIntialEvent</code> flag.
	 * @param fireInitialEvent the new value of the flag
	 */
	public void setFireInitialEvent(boolean fireInitialEvent) {
		this.fireInitialEvent = fireInitialEvent;
	}
	
	//-------------------------------------------------------------------------------
	public void setOther(Object other) { this.other = other; }
	
	//-------------------------------------------------------------------------------
	public Object getOther() { return other; }
	
	//-------------------------------------------------------------------------------
	public void skip() {
		if (other instanceof TimeSeriesCollectionProducer) {
			TimeSeriesCollectionProducer series = (TimeSeriesCollectionProducer)other;
			series.skipStep();
		}
	}
}