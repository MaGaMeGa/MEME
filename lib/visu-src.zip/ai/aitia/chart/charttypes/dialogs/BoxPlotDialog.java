/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.DefaultListModel;
import javax.swing.SwingUtilities;

import org.w3c.dom.Element;

import com.jgoodies.forms.layout.CellConstraints;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.AllDummyDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.ds.IStringListProducer;
import ai.aitia.chart.ds.IStringSeriesProducer;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.meme.utils.FormsUtils;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;

/** GUI component of the bar charts. */
public class BoxPlotDialog extends AbstractChartDialog implements ActionListener,
																   FocusListener,
																   ItemListener,
																   MouseListener {

	/** Special producer for 'All' combobox item. */
	private AllDummyDataSourceProducer allProducer = new AllDummyDataSourceProducer();

	private static final long serialVersionUID = 1L;
	private JTabbedPane tabbed = new JTabbedPane();
	private JPanel mainPanel = null;
	private JPanel categoriesPanel = null;
	private JComboBox categoriesParam = new JComboBox(getParamsToCategories());
	private JButton catAdvancedButton = new JButton("Advanced...");
	private JPanel selectedPanel = null;
	private JList drList = new JList();
	private JScrollPane scrList = new JScrollPane(drList);
	private JButton downButton = new JButton("Down");
	private JButton upButton = new JButton("Up");
	private JButton removeButton = new JButton("Remove");
	private JPanel datarowsPanel = null;
	private JComboBox drParams = new JComboBox(getParamsToDataRows());
	private JButton drAdvancedButton = new JButton("Advanced...");
	private JButton addButton = new JButton("Add data row",Utilities.getIcon("RIGHT ARROW"));
	private JPanel detailsPanel = null;
	private JTextField subtitleField = new JTextField();
	private JComboBox angleBox = new JComboBox( new Object[] { new ComboboxItem("90", "90 degrees (counter-clockwise)"),
															   new ComboboxItem("45", "45 degrees (counter-clockwise)"),
															   new ComboboxItem("0", "Standard (horizantal)"),
															   new ComboboxItem("-45", "45 degrees (clockwise)"),
															   new ComboboxItem("-90", "90 degrees (clockwise")
															 });
	private JComboBox rendererBox = new JComboBox( new Object[] { new ComboboxItem(ChartConstants.ONE_BAR_PER_DATAROW, "Default"),
																  new ComboboxItem(ChartConstants.ONE_BAR_PER_CATEGORY, "Cumulative"),
																  new ComboboxItem(ChartConstants.ONE_BAR_PER_CATEGORY_P, "Cumulative (percent format)")
																});
	private JCheckBox showLegendBox = new JCheckBox("Show legend");
	private JComboBox appearanceBox = null;
	private JPanel buttonPanel = null;
	private JButton cancelButton = new JButton("Cancel");
	
	private JPopupMenu dataRowsContextMenu = new JPopupMenu();
	private AbstractAction removeAction = null;
	private AbstractAction upAction = null;
	private AbstractAction downAction = null;
	
	//===============================================================================
	// additional members
	
	/** Model of the selected datarows. */
	private DefaultListModel lmodel = null;  

	/** List of producers for the selected datarows. */
	private LinkedList<IDataSourceProducer> datarows = null;
	
	//===============================================================================
	// methods
	
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public BoxPlotDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		lmodel = new DefaultListModel();
		datarows = new LinkedList<IDataSourceProducer>();
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
	}

	//-------------------------------------------------------------------------------
	/** This method initializes the GUI. */
	private void initialize() {
		this.setLayout(new BorderLayout());
		
		// Categories combobox
		categoriesParam.setRenderer(new DataSourceComboBoxRenderer(categoriesParam));
		categoriesParam.setPreferredSize(new Dimension(100,26)); 
		categoriesParam.setActionCommand("CATERGORIES_PARAM");
		
		// Categories advanced button
		catAdvancedButton.setActionCommand("CATEGORIES_ADVANCED");
		if (categoriesParam.getItemCount()>0) {
			IDataSourceProducer dsp = (IDataSourceProducer)categoriesParam.getSelectedItem();
			categoriesParam.setToolTipText(dsp.toString()); // categories combobox settings
			catAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		}
		
		// Categories panel
		categoriesPanel = FormsUtils.build("p:grow - p",
				                           "01 pref",
				                           categoriesParam,
				                           catAdvancedButton).getPanel();

		// Selected list
		drList.setModel(lmodel);
		drList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		drList.addMouseListener(this);
		
		// Down button
		downButton.setEnabled(false);
		downButton.setMnemonic(KeyEvent.VK_DOWN);
		downButton.setActionCommand("DOWN");
		
		// Up button
		upButton.setEnabled(false);
		upButton.setMnemonic(KeyEvent.VK_UP);
		upButton.setActionCommand("UP");
		
		// Remove button
		removeButton.setEnabled(false);
		removeButton.setMnemonic(KeyEvent.VK_R);
		removeButton.setActionCommand("REMOVE");
		
		// Context menu
		initializeContextMenu();
		
		// Selected data rows panel
		selectedPanel = FormsUtils.build("p:grow d ' d ' d p:grow",
				                         "00000 default|-|" +
				                         "_123_",
				                         scrList,
				                         downButton,
				                         upButton,
				                         removeButton).getPanel();
		
		// Data row combobox
		drParams.setRenderer(new DataSourceComboBoxRenderer(drParams));
		drParams.setPreferredSize(new Dimension(100,26));
		drParams.setActionCommand("DRPARAMS");

		// Data row advanced button
		drAdvancedButton.setEnabled(false);
		drAdvancedButton.setActionCommand("DR_ADVANCED");
		if (drParams.getItemCount()>0) {
			IDataSourceProducer dsp = (IDataSourceProducer)drParams.getSelectedItem();
			drParams.setToolTipText(dsp.toString()); // combobox settings
			drAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		}

		
		// Data row panel
		datarowsPanel = FormsUtils.build("p:grow - p",
				   						 "01 pref",
				   						 drParams,
				   						 drAdvancedButton).getPanel();
		
		// Add data row button
		addButton.setMnemonic(KeyEvent.VK_A);
		addButton.setIconTextGap(2);
		addButton.setHorizontalTextPosition(JLabel.LEADING);
		addButton.setActionCommand("ADD");
		
		// Main panel
		mainPanel = FormsUtils.build("fill:p:grow = p:grow",
				   					 "[DialogBorder]01 pref|'|" +
				   					 			   "21|-|" +
				   					 			   "31 default",
				   					 				//"21 default",
				   					 FormsUtils.titledBorder("Categories",categoriesPanel),
				   					 
				   					 FormsUtils.titledBorder("Selected data rows",selectedPanel),
				   					 FormsUtils.titledBorder("Data row",datarowsPanel),
				   					 addButton, CellConstraints.CENTER).getPanel();
		
		// Title textfield
		titleField = new JTextField(ChartConstants.BOXPLOT_NAME);
		titleField.setActionCommand("TITLE");
		titleField.addFocusListener(this);
		
		// Subtitle textfield
		subtitleField.addFocusListener(this);
		
		// Category Label Angle combobox
		angleBox.setSelectedIndex(2);
		
		// Show legend checkbox
		showLegendBox.setSelected(true);
		showLegendBox.addItemListener(this);
		
		// Appearance combobox
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox = new JComboBox(appearances);
		appearanceBox.setActionCommand("APPEARANCE");
		
		// Details panel
		detailsPanel = FormsUtils.build("left:pref = pref:grow p p pref:grow",
				   						"[DialogBorder]01111 pref|'|" +
				   									  "23333|" +
				   									  "45___|" +
				   									  "67___|'|" +
				   									  "_8___|" +
				   									  "_____ pref:grow",
				   						"Title:", titleField,
				   						"Subtitle:", subtitleField,
				   						"Category label angle:", angleBox,
				   						//"   Bar renderer:  ", rendererBox,
				   						"Appearance:",appearanceBox,
				   						showLegendBox
				   						).getPanel();
		
		// Tabbed pane
		tabbed.addTab("Main Settings",Utilities.icons.get(ChartConstants.BOXPLOT),mainPanel);
		tabbed.addTab("Details",detailsPanel);
		
		// Display button
		displayButton = new JButton("Display");
		displayButton.setEnabled(false);
		displayButton.setMnemonic(KeyEvent.VK_D);
		displayButton.setActionCommand("DISPLAY");
		
		// Save button
		saveButton = new JButton("Save");
		saveButton.setEnabled(false);
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setActionCommand("SAVE");
		
		// Cancel button
		cancelButton.setMnemonic(KeyEvent.VK_C);
		cancelButton.setActionCommand("CANCEL");
		
		// Button panel
		buttonPanel = FormsUtils.build("p:grow d ' d ' d ' d p:grow",
									   "-|_0123_",
									   getEditorButton(),
									   displayButton,
									   saveButton,
									   cancelButton).getPanel();
		
		this.setPreferredSize(new Dimension(609, 219)); //TODO: ideiglenes
//		this.setMinimumSize(new Dimension(609, 219));
		this.add(tabbed, BorderLayout.CENTER);
		this.add(buttonPanel, BorderLayout.SOUTH);
		
		Utilities.addActionListener(this, categoriesParam,catAdvancedButton,downButton,
									upButton,removeButton,drParams,drAdvancedButton,
									addButton,titleField,displayButton,saveButton,
									cancelButton,appearanceBox,editorButton);
	}
	
	//-------------------------------------------------------------------------------
	/** This method initializes the context menu of the selected datarows list.*/
	@SuppressWarnings("serial")
	private void initializeContextMenu() {
		downAction = new AbstractAction() {
			{
				putValue(NAME,"Down");
				putValue(ACTION_COMMAND_KEY,"DOWN");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		dataRowsContextMenu.add(downAction);
		upAction = new AbstractAction() {
			{
				putValue(NAME,"Up");
				putValue(ACTION_COMMAND_KEY,"UP");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		dataRowsContextMenu.add(upAction);
		removeAction = new AbstractAction() {
			{
				putValue(NAME,"Remove");
				putValue(ACTION_COMMAND_KEY,"REMOVE");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		dataRowsContextMenu.add(removeAction);
	}
	
	//-------------------------------------------------------------------------------
	/** Forwards the ActionEvent <code>e</code> to the general handler.
	 * @param action the action object 
	 * @param e the event
	 */
	private void contextEvent(AbstractAction action, ActionEvent e) {
		if (drList.getSelectedIndex() == -1) {
			int x = ((Integer)action.getValue("X")).intValue();
			int y = ((Integer)action.getValue("Y")).intValue();
			int index = drList.locationToIndex(new Point(x,y));
			drList.setSelectedIndex(index);
		}
		BoxPlotDialog.this.actionPerformed(e);
	}

	//===============================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-GUI functions                                                      //
	////////////////////////////////////////////////////////////////////////////
	
	@Override
	protected void setWidgetDisabled() {
		if (categoriesParam.getItemCount() == 0) {
			categoriesParam.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			catAdvancedButton.setEnabled(false);
		}
		if (drParams.getItemCount() == 0) {
			drParams.setEnabled(false);
			displayButton.setEnabled(false);
			drAdvancedButton.setEnabled(false);
			addButton.setEnabled(false);
		}
	}
	
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}
	//-------------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that supports the 
	 *  {@link ai.aitia.chart.ds.IStringSeriesProducer IStringSeriesProducer} and/or
	 *  {@link ai.aitia.chart.ds.IStringListProducer IStringListProducer}.
	 *  interface.
	 * @return array of data sources
	 */
 	private Object[] getParamsToCategories() {
 		return getParams(new Class[] { IStringSeriesProducer.class, IStringListProducer.class });
 	}
 	
	//-------------------------------------------------------------------------------
 	/** Returns the displayable names of the data sources that supports the
 	 *  ISeriesProducer interface.
 	 * @return array of data sources
 	 */
 	private Object[] getParamsToDataRows() {
 		Object[] res = getParams(new Class[] { ISeriesProducer.class, IValueProducer.class});
 		if (res.length != 0) {
 			List<Object> resPlus = new ArrayList<Object>(Arrays.asList(res));
 			resPlus.add(allProducer);
 			return resPlus.toArray();
 		}
 		return res;
 	}
 	
	//-------------------------------------------------------------------------------
 	@Override
 	protected void setSettingsFromConfig() {
 		if (config.getChartProperties() instanceof Properties) {
 			// set settings from config
 			properties = (Properties)config.getChartProperties();
 			int[] ds = Utilities.splitDatasourceAroundCommas(properties.getProperty("datasource"));
 			IDataSourceProducer dsp = config.getDataSource(ds[0]);
 			categoriesParam.setSelectedItem(dsp);
 			for (int i = 1;i < ds.length;++i) {
 				dsp = config.getDataSource(ds[i]);
 				datarows.add(dsp);
 				lmodel.addElement(dsp.toString());
 			}
 			drParams.setSelectedItem(dsp);
 			titleField.setText(properties.getProperty(ChartConstants.TITLE));
 			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
 			int degree = Integer.parseInt(properties.getProperty(ChartConstants.CATEGORY_LABEL_ANGLE,"0"));
 			for (int i=0;i<angleBox.getItemCount();++i) {
 				String id = ((ComboboxItem)angleBox.getItemAt(i)).getID().toString();
 				if (String.valueOf(degree).equals(id)) {
 					angleBox.setSelectedIndex(i);
 					break;
 				}
 			}
 			String renderer = properties.getProperty(ChartConstants.BAR_RENDERER,ChartConstants.ONE_BAR_PER_DATAROW);
 			if (ChartConstants.ONE_BAR_PER_CATEGORY.equals(renderer)) rendererBox.setSelectedIndex(1);
 			else if (ChartConstants.ONE_BAR_PER_CATEGORY_P.equals(renderer)) rendererBox.setSelectedIndex(2);
 			showLegendBox.setSelected(Boolean.parseBoolean(properties.getProperty(ChartConstants.SHOW_LEGEND,"true")));
			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
 			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
 				String appearanceCode = "";
 				appearanceCode += properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP) ? "N" : "B";
 				appearanceCode += properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE) ? "BW" : "C";
 				for (int i = 0;i < appearanceBox.getItemCount();++i) {
 					String id = ((ComboboxItem)appearanceBox.getItemAt(i)).getID().toString();
 					if (id.equals(appearanceCode)) {
 						appearanceBox.setSelectedIndex(i);
 						break;
 					}
 				}
 			}
 			if (datarows.size() > 0) {
 				displayButton.setEnabled(true);
 				saveButton.setEnabled(true);
 				removeButton.setEnabled(true);
 			}
 			if (datarows.size() > 1) {
 				downButton.setEnabled(true);
 				upButton.setEnabled(true);
 			}
 		} else {
 			// set the initial properties
 			properties.setProperty(ChartConstants.TITLE,ChartConstants.BOXPLOT_NAME);
 			properties.setProperty(ChartConstants.SUBTITLE,"");
 			properties.setProperty(ChartConstants.SHOW_LEGEND,"true");
 			int appIndex = 0;
 			appIndex += ChartConfigCollection.getColorAppearance().equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
 			appIndex += ChartConfigCollection.getEnvironmentAppearance().equals(ChartConstants.NORMAL_APP) ? 2 : 0;
 			appearanceBox.setSelectedIndex(appIndex);
 		}
 	}
 	
	//-------------------------------------------------------------------------------
 	@Override
 	public void updateChartConfig() {
 		config.clearAllDataSource();
 		IDataSourceProducer cdsp = (IDataSourceProducer)categoriesParam.getSelectedItem();
 		int key = -1;
 		if (cdsp.getSupportedIntfs().contains(IStringListProducer.class))
 			key = config.addDataSource(cdsp,IStringListProducer.class);
 		else key = config.addDataSource(cdsp,IStringSeriesProducer.class);
 		String ds = String.valueOf(key) + ",";
 		Iterator<IDataSourceProducer> it = datarows.iterator();
 		while (it.hasNext()) {
 			IDataSourceProducer dsp = it.next();
 			if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
 				key = config.addDataSource(dsp,ISeriesProducer.class);
 			else key = config.addDataSource(dsp,IValueProducer.class);
 			ds += String.valueOf(key) + ",";
 		}
 		properties.setProperty(ChartConstants.DATASOURCE,ds.substring(0,ds.length()-1));
 		properties.setProperty(ChartConstants.CATEGORY_LABEL_ANGLE,((ComboboxItem)angleBox.getSelectedItem()).getID().toString());
 		properties.setProperty(ChartConstants.BAR_RENDERER,((ComboboxItem)rendererBox.getSelectedItem()).getID().toString());
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 3) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
	 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
	 		if (code[0].equals("B"))
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.BASIC_APP);
	 		else
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.NORMAL_APP);
	 		if (code[1].equals("BW"))
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.BLACK_AND_WHITE);
	 		else
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.COLORED);
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
 		config.setChartProperties(ChartConstants.BOXPLOT,properties);
 	}
 	
	//-------------------------------------------------------------------------------
 	@Override
 	public boolean isUpdateable() {
 		if (categoriesParam.getItemCount()>0 && !datarows.isEmpty()) return true;
 		return false;
 	}
 	
	//-------------------------------------------------------------------------------
 	@Override
 	protected void displayPreview() throws Exception {
 		DataSources ds = new DataSources(new SimpleDSPCollection());
 		ChartConfig temp_config = new ChartConfig(ds);
 		temp_config.setFireInitialEvent(true);
 		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
 		temp_config.addDataSource(dsl.get(3), IStringSeriesProducer.class);
 		temp_config.addDataSource(dsl.get(0), ISeriesProducer.class);
 		temp_config.addDataSource(dsl.get(1), ISeriesProducer.class);
 		temp_config.addDataSource(dsl.get(2), ISeriesProducer.class);
 		Properties temp_prop = (Properties)properties.clone();
 		temp_prop.setProperty(ChartConstants.DATASOURCE,"1,2,3,4");
 		temp_prop.setProperty(ChartConstants.TITLE, temp_prop.getProperty(ChartConstants.TITLE)+ " (Preview illustration)");
 		temp_config.setChartProperties(ChartConstants.BOXPLOT,temp_prop);
 		Utilities.displayPreview(temp_config);
 	}
 	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem)appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		// reset widgets
		categoriesParam.setEnabled(true);
		catAdvancedButton.setEnabled(true);
		drParams.setEnabled(true);
		drAdvancedButton.setEnabled(true);
		addButton.setEnabled(true);
		
		Object catObject = categoriesParam.getSelectedIndex() == -1 ? null : categoriesParam.getSelectedItem();
		Object drObject = drParams.getSelectedIndex() == -1 ? null : drParams.getSelectedItem();
		
		DefaultComboBoxModel catModel = new DefaultComboBoxModel(getParamsToCategories());
		categoriesParam.setModel(catModel);
		DefaultComboBoxModel drModel = new DefaultComboBoxModel(getParamsToDataRows());
		drParams.setModel(drModel);
		
		if (catObject != null && findInComboBox(catModel,(IDataSourceProducer)catObject) != -1) {
			int idx = findInComboBox(catModel,(IDataSourceProducer)catObject);
			categoriesParam.setSelectedIndex(idx >= 0 ? idx : 0);
		} 
		if (drObject != null && findInComboBox(drModel,(IDataSourceProducer)drObject) != -1) {
			int idx = findInComboBox(drModel,(IDataSourceProducer)drObject);
			drParams.setSelectedIndex(idx >= 0 ? idx : 0);
		} 
		
		LinkedList<IDataSourceProducer> newDatarows = new LinkedList<IDataSourceProducer>();
		for (IDataSourceProducer prod : datarows) {
			int idx = findInComboBox(drModel,prod);
			if (idx != -1) 
				newDatarows.add((IDataSourceProducer)drModel.getElementAt(idx));
		}
		datarows = newDatarows;
		lmodel.clear();
		for (IDataSourceProducer prod : newDatarows) 
			lmodel.addElement(prod.toString());
		downButton.setEnabled(datarows.size() >= 2);
		upButton.setEnabled(datarows.size() >= 2);
		removeButton.setEnabled(datarows.size() != 0);
		
		validate();
		setWidgetDisabled();
		
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}

 	//-------------------------------------------------------------------------------
 	/** This method handles all ActionEvent-s of the panel. It is public because of
 	 *  implementation side effect. Do not call or override.
 	 * @param event event
 	 */
	public void actionPerformed(ActionEvent event) {
		String command = event.getActionCommand();
		if (command.equals("CATEGORIES_PARAM")) { // Categories combobox
			IDataSourceProducer dsp = (IDataSourceProducer)categoriesParam.getSelectedItem();
			categoriesParam.setToolTipText(dsp.toString());
			catAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		} else if (command.equals("CATEGORIES_ADVANCED")) { // Categories advanced button
			advanced(categoriesParam);
		} else if (command.equals("DOWN")) { // Down button
			move(1);
		} else if (command.equals("UP")) { // Up button
			move(-1);
		} else if (command.equals("REMOVE")) { // Remove button
			int[] selected = drList.getSelectedIndices();
			while (selected.length != 0) {
				datarows.remove(selected[0]);
				lmodel.remove(selected[0]);
				selected = drList.getSelectedIndices();
			}
			// disable the buttons (if need)
			if (datarows.size() < 2) {
				downButton.setEnabled(false);
				upButton.setEnabled(false);
			}
			if (datarows.size() == 0) {
				removeButton.setEnabled(false);
				displayButton.setEnabled(false);
				ChartDialogChangeCenter.fireSaveDisabled(this);
			}
		} else if (command.equals("DRPARAMS")) { // Data row combobox
			IDataSourceProducer dsp = (IDataSourceProducer)drParams.getSelectedItem();
			drParams.setToolTipText(dsp.toString());
			drAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
		} else if (command.equals("DR_ADVANCED")) { // Data row advanced button
			advanced(drParams);
		} else if (command.equals("ADD")) { // Add data row button
			IDataSourceProducer dsp = (IDataSourceProducer)drParams.getSelectedItem();
			if (dsp.equals(allProducer)) {
				// special data source
				for (int i=0;i<drParams.getItemCount();++i) {
					IDataSourceProducer p = (IDataSourceProducer)drParams.getItemAt(i);
					if (p.equals(allProducer) || datarows.contains(p)) continue;
					datarows.add(p);
					lmodel.addElement(p.toString());
				}
			} else {
				if (datarows.contains(dsp)) return; // repeated datarow
				datarows.add(dsp); // add datarow
				lmodel.addElement(dsp.toString()); // display it in the list 
			}
			
			// enable the buttons (if need)
			if (datarows.size()>0) {
				removeButton.setEnabled(true);
				if (categoriesParam.getItemCount() > 0) {
					displayButton.setEnabled(true);
					ChartDialogChangeCenter.fireSaveEnabled(this);
				}
			}
			if (datarows.size()>1) {
				downButton.setEnabled(true);
				upButton.setEnabled(true);
			}
		} else if (command.equals("TITLE")) { // Title textfield
			subtitleField.grabFocus();
		} else if (command.equals("DISPLAY")) { // Display button
			displayChart();
		} else if (command.equals("SAVE")) { // Save button
			saveCollection();
		} else if (command.equals("CANCEL")) { // Cancel button
			notifyForHide();
		} else if (command.equals("APPEARANCE")) { // Appearance box
			int index = appearanceBox.getSelectedIndex();
	 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
			if (index >= 0 && index <= 3) {
		 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
		 		if (code[0].equals("B"))
		 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.BASIC_APP);
		 		else
		 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.NORMAL_APP);
		 		if (code[1].equals("BW"))
		 			ChartConfigCollection.setColorAppearance(ChartConstants.BLACK_AND_WHITE);
		 		else
		 			ChartConfigCollection.setColorAppearance(ChartConstants.COLORED);
			}  else if (appearanceCode.equals("_NEW")) {
				ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.NORMAL);
				int result = dlg.showDialog();
				if (result == ChartPropertiesDialog.OK_OPTION) {
					Element newTemplate = (Element) dlg.getTemplate();
					dlg.dispose();
					String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
					AbstractChart.templates.put(name,newTemplate);
					ChartDialogChangeCenter.fireTemplateChanged();
					appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
				} else 
					appearanceBox.setSelectedIndex(0);
			} else if (appearanceCode.equals("_EDIT")) {
				String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
				if (templates.length == 0) {
					JOptionPane.showMessageDialog(this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
					appearanceBox.setSelectedIndex(0);
					return;
				} 
				String template = (String)JOptionPane.showInputDialog(this,"Select a template: ","Edit template",
															  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
				if (template == null || "".equals(template)) 
					appearanceBox.setSelectedIndex(0);
				else {
					Element templateElement = AbstractChart.templates.get(template);
					ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(),ChartKind.NORMAL);
					int result = dlg.showDialog();
					if (result == ChartPropertiesDialog.OK_OPTION) {
						Element newTemplate = (Element) dlg.getTemplate();
						dlg.dispose();
						String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
						AbstractChart.templates.put(name,newTemplate);
						ChartDialogChangeCenter.fireTemplateChanged();
						appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
					} else 
						appearanceBox.setSelectedIndex(0);
				}
			} else if (appearanceCode.equals("_REMOVE")) {
				String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
				if (templates.length == 0) {
					JOptionPane.showMessageDialog(this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
					appearanceBox.setSelectedIndex(0);
					return;
				} 
				String template = (String)JOptionPane.showInputDialog(this,"Select a template: ","Delete template",
															  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
				if (template != null && !"".equals(template)) { 
					AbstractChart.templates.remove(template);
					File file = new File("Templates/" + template + ".xml");
					file.delete();
					ChartDialogChangeCenter.fireTemplateChanged();
				}
				appearanceBox.setSelectedIndex(0);
			}
		}
	}
	
	//------------------------------------------------------------------------------
	private List<String> getLegends() {
		List<String> result = new ArrayList<String>(lmodel.size());
		for (int i = 0;i < lmodel.size();++i)
			result.add(lmodel.get(i).toString());
		return result;
	}
	
	//-----------------------------------------------------------------------------
	/** Moves the selected elements in the selected datarows list.
	 * @param offset the direction of the move (possible values: -1,1)
	 */
	private void move(int offset) {
		int[] selected = drList.getSelectedIndices();
		
		List<int[]> intervals = new ArrayList<int[]>();
		int start = selected[0], end = -1, previous = selected[0] - 1;

		for (int i=0;i<selected.length;++i) {
				if (selected[i] == previous + 1) previous = selected[i];
				else {
					end = previous;
					int[] intv = { start, end };
					intervals.add(intv);
					end = -1;
					start = previous = selected[i];
				}
		}
		intervals.add(new int[] { start, selected[selected.length-1] });
		
		drList.clearSelection();
		for (int[] intv : intervals) {
			int to = intv[0] + offset;
			if (0 <= intv[0] && 0 <= to && intv[1] + offset < lmodel.size()) {
				moveInterval(intv[0],intv[1],to);
				drList.getSelectionModel().addSelectionInterval(intv[0] + offset,intv[1] + offset);
			} else 
				drList.getSelectionModel().addSelectionInterval(intv[0],intv[1]);
		}
	}
	
	//-------------------------------------------------------------------------------
	/** Moves the elements in the selected datarows list. The indices of the moved
	 *  elements are in the interval [<code>start</code>,<code>end</code>]. 
	 * @param to the new index of the first element
	 */
	private void moveInterval(int start, int end, int to) {
		int temp = to;
		String[] path = new String[end - start + 1];
		IDataSourceProducer[] dsps = new IDataSourceProducer[end - start + 1];
		for (int i = start;i <= end; ++i) {
			path[i - start] = (String)lmodel.get(i);
			dsps[i - start] = datarows.get(i);
		}
		lmodel.removeRange(start,end);
		datarows.removeAll(Arrays.asList(dsps));
		for (int i = 0;i < path.length;++i) {
			lmodel.add(temp,path[i]);
			datarows.add(temp++,dsps[i]);
		}
	}
	
	//-----------------------------------------------------------------------------
	/** This method handles all focus lost focus events of the panel. It is public
	 *  because of implementation sideeffect. Do not call or override.
	 * @param e event
	 */
	public void focusLost(FocusEvent e) {
		if (e.getSource().equals(titleField)) {
			properties.setProperty(ChartConstants.TITLE,titleField.getText());
			ChartDialogChangeCenter.fireTitleChanged(this);
		} else if (e.getSource().equals(subtitleField)) {
			properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
		}
	}
	
	//-----------------------------------------------------------------------------
	public void focusGained(FocusEvent e) {}

	//-----------------------------------------------------------------------------
	/** This method handles all item state changed events of the panel. It is public
	 *  because of implementation sideeffect. Do not call or override.
	 * @param e event
	 */
	public void itemStateChanged(ItemEvent e) {
		properties.setProperty(ChartConstants.SHOW_LEGEND,String.valueOf(showLegendBox.isSelected()));
	}

	//-------------------------------------------------------------------------------
	/** This method haldles all released mouse events of the panel. It is public 
	 *  because of implementation side effect. Do not call or override.
	 * @param e event
	 */
	public void mouseReleased(MouseEvent e) {
		if (!SwingUtilities.isRightMouseButton(e))
			return;
		if (e.getComponent().isEnabled()) {
			downAction.setEnabled(drList.getModel().getSize() > 1);
			upAction.setEnabled(drList.getModel().getSize() > 1);
			removeAction.setEnabled(drList.getModel().getSize() != 0);
			if (drList.getModel().getSize() > 1) {
				downAction.putValue("X",e.getX());
				downAction.putValue("Y",e.getY());
				upAction.putValue("X",e.getX());
				upAction.putValue("Y",e.getY());
			}
			if (drList.getModel().getSize() != 0) {
				removeAction.putValue("X",e.getX());
				removeAction.putValue("Y",e.getY());
			}
			dataRowsContextMenu.show(e.getComponent(),e.getX(),e.getY());
		}
	}
	
	//--------------------------------------------------------------------------------
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
}