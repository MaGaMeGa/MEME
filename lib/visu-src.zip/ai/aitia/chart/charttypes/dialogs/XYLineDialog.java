/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;

import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.AllDummyDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.assisttypes.Pair;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.ChildAdditionalPanel;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.ds.IXYSeriesProducer;
import ai.aitia.visu.view.meta.LineChartMetadata;

/** GUI component of the XY line charts. */
public class XYLineDialog extends AbstractChartDialog implements MouseListener,
																 ActionListener {

	private static final long serialVersionUID = 1L;
	private JTabbedPane tabbed = null;
	private JPanel mainPanel = null;
	private JPanel detailsPanel = null;
	private JPanel titleLine = null;
	private JPanel subtitleLine = null;
	private JPanel xLabelLine = null;
	private JPanel yLabelLine = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	private JTextField subtitleField = null;
	private JLabel jLabel2 = null;
	private JTextField xLabelField = null;
	private JLabel jLabel3 = null;
	private JTextField yLabelField = null;
	private JPanel buttonPanel = null;
	private JButton cancelButton = null;
	private JPanel paramPanel = null;
	private JPanel xyPanel = null;
	private JComboBox xParams = null;
	private JComboBox yParams = null;
	private JButton addButton = null;
	private JButton removeButton = null;
	private JList xyList = null;
	private JPanel sortPanel = null;
	private JButton downButton = null;
	private JButton upButton = null;
	private JPanel xPanel = null;
	private JPanel yPanel = null;
	private JPanel addButtonPanel = null;
	private JButton xAdvancedButton = null;
	private JButton yAdvancedButton = null;
	private JScrollPane scrList = null;
	private JPopupMenu composeMenu = null;
	private JMenuItem mHistogram = null;
	private JMenuItem mRealTimeSeries = null;
	private JMenuItem mScatterPlot = null;
	private JMenuItem mTimeSeries = null;
	private JLabel jLabel4 = null;
	private JComboBox xScaleBox = null;
	private JLabel jLabel5 = null;
	private JComboBox yScaleBox = null;
	private JPanel appearancePanel = null;
	private JLabel jLabel6 = null;
	private JCheckBox showLegendBox = null;
	private JLabel jLabel7 = null;
	private JComboBox appearanceBox = null;
	private JComboBox rendererBox = null;
	
	private JPopupMenu functionsContextMenu = new JPopupMenu();
	private AbstractAction removeAction = null;  //  @jve:decl-index=0:
	private AbstractAction upAction = null;
	private AbstractAction downAction = null;
	
	//============================================================================
	// additional members
	
	/** Model of the list of selected functions. */
	private DefaultListModel lmodel = null; //  @jve:decl-index=0:
	
	/** List of the selected functions. A function is formed from a sequence of (x,y)
	 *  point or two series.
	 */
	private List<Pair> functions = null;

	/** Array of scaling types for comboboxes. */
	private static final Object[] scaleTypes = { new ComboboxItem(ChartConstants.NORMAL,"Linear"),
												 new ComboboxItem(ChartConstants.LOG, "Logarithmic")
											   };
	
	/** Array of rendering types for the combobox. */
	private static final Object[] rendererTypes = { new ComboboxItem(LineChartMetadata.RENDERER_LINES_ONLY,"Lines only"),
													new ComboboxItem(LineChartMetadata.RENDERER_LINES_AND_SHAPES, "Lines and shapes"),
													new ComboboxItem(LineChartMetadata.RENDERER_SHAPES_ONLY,"Shapes only")
												  };
	
	/** Array of y combobox : contains all acceptable datasources. */
	private Object[] forYAll = null;
	
	/** Array of y combobox : contains only ISeriesProducer supporters. */
	private Object[] forYSeries = null;
	
	/** Array of y combobox : contains only IValueProducer supporters. */
	private Object[] forYValue = null;
	
	/** Special producer for 'All' combobox item. */
	private AllDummyDataSourceProducer allProducer = new AllDummyDataSourceProducer();
	
	//============================================================================
	// methods
	
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public XYLineDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		functions = new LinkedList<Pair>();
		lmodel = new DefaultListModel();
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
	}

	//------------------------------------------------------------------------------
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted)
	 * @param child_panel panel that contains the GUI of the other charts in a multi-layered
	 *  chart. 
	 */
	public XYLineDialog(ChartConfig config, ChartConfigCollection cc_collection, JPanel child_panel) {
		super(config,cc_collection);
		this.child_panel = child_panel;
		functions = new LinkedList<Pair>();
		lmodel = new DefaultListModel();
		initialize();
		this.scr = new JScrollPane();
		scr.setViewportView(this.child_panel);
		this.setPreferredSize(new Dimension(619,484));
		this.add(this.scr,1);
		setWidgetDisabled();
		setSettingsFromConfig();
	}
	
	//------------------------------------------------------------------------------
	/** This method initializes <code>this</code>. */
	private void initialize() {
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.setMinimumSize(new Dimension(609, 219));
		this.add(getTabbed(), null);
		this.add(getButtonPanel(), null);
		initializeContextMenu();
	}

	//-------------------------------------------------------------------------------
	/** This method initializes the context menu of the selected functions list.*/
	@SuppressWarnings("serial")
	private void initializeContextMenu() {
		downAction = new AbstractAction() {
			{
				putValue(NAME,"Down");
				putValue(ACTION_COMMAND_KEY,"DOWN");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		functionsContextMenu.add(downAction);
		upAction = new AbstractAction() {
			{
				putValue(NAME,"Up");
				putValue(ACTION_COMMAND_KEY,"UP");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		functionsContextMenu.add(upAction);
		removeAction = new AbstractAction() {
			{
				putValue(NAME,"Remove");
				putValue(ACTION_COMMAND_KEY,"REMOVE");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		functionsContextMenu.add(removeAction);
	}

	//-------------------------------------------------------------------------------
	/** Forwards the ActionEvent <code>e</code> to the general handler.
	 * @param action the action object 
	 * @param e the event
	 */
	private void contextEvent(AbstractAction action, ActionEvent e) {
		if (xyList.getSelectedIndex() == -1) {
			int x = ((Integer)action.getValue("X")).intValue();
			int y = ((Integer)action.getValue("Y")).intValue();
			int index = xyList.locationToIndex(new Point(x,y));
			xyList.setSelectedIndex(index);
		}
		XYLineDialog.this.actionPerformed(e);
	}
	
	//------------------------------------------------------------------------------
	private JTabbedPane getTabbed() {
		if (tabbed == null) {
			tabbed = new JTabbedPane();
			tabbed.setPreferredSize(new Dimension(609, 168));
			tabbed.addTab("Main Settings",Utilities.icons.get(ChartConstants.XYLINECHART), getMainPanel(), null);
			tabbed.addTab("Details", null, getDetailsPanel(), null);
		}
		return tabbed;
	}

	//------------------------------------------------------------------------------
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(new BoxLayout(getMainPanel(), BoxLayout.X_AXIS));
			mainPanel.add(getParamPanel(), null);
			mainPanel.add(getXyPanel(), null);
		}
		return mainPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getDetailsPanel() {
		if (detailsPanel == null) {
			detailsPanel = new JPanel();
			detailsPanel.setLayout(new BoxLayout(getDetailsPanel(), BoxLayout.Y_AXIS));
			detailsPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
			detailsPanel.setBorder(BorderFactory.createTitledBorder(null, "Titles and axis labels of the chart", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			detailsPanel.add(getTitleLine(), null);
			detailsPanel.add(getSubtitleLine(), null);
			detailsPanel.add(getXLabelLine(), null);
			detailsPanel.add(getYLabelLine(), null);
			detailsPanel.add(getAppearancePanel(), null);
		}
		return detailsPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getTitleLine() {
		if (titleLine == null) {
			jLabel = new JLabel();
			jLabel.setText("  Title:  ");
			jLabel.setHorizontalTextPosition(SwingConstants.RIGHT);
			jLabel.setPreferredSize(new Dimension(125, 16));
			jLabel.setHorizontalAlignment(SwingConstants.LEADING);
			titleLine = new JPanel();
			titleLine.setLayout(new BoxLayout(getTitleLine(), BoxLayout.X_AXIS));
			titleLine.add(jLabel, null);
			titleLine.add(getTitleField(), null);
		}
		return titleLine;
	}

	//------------------------------------------------------------------------------
	private JPanel getSubtitleLine() {
		if (subtitleLine == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("  Subtitle:  ");
			jLabel1.setHorizontalTextPosition(SwingConstants.RIGHT);
			jLabel1.setPreferredSize(new Dimension(125, 16));
			jLabel1.setHorizontalAlignment(SwingConstants.LEADING);
			subtitleLine = new JPanel();
			subtitleLine.setLayout(new BoxLayout(getSubtitleLine(), BoxLayout.X_AXIS));
			subtitleLine.setPreferredSize(new Dimension(400, 20));
			subtitleLine.add(jLabel1, null);
			subtitleLine.add(getSubtitleField(), null);
		}
		return subtitleLine;
	}

	//------------------------------------------------------------------------------
	private JPanel getXLabelLine() {
		if (xLabelLine == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("  Scaling:  ");
			jLabel2 = new JLabel();
			jLabel2.setText("  X-Axis label:");
			jLabel2.setPreferredSize(new Dimension(125, 16));
			xLabelLine = new JPanel();
			xLabelLine.setLayout(new BoxLayout(getXLabelLine(), BoxLayout.X_AXIS));
			xLabelLine.setPreferredSize(new Dimension(400, 20));
			xLabelLine.add(jLabel2, null);
			xLabelLine.add(getXLabelField(), null);
			xLabelLine.add(jLabel4, null);
			xLabelLine.add(getXScaleBox(), null);
		}
		return xLabelLine;
	}

	//------------------------------------------------------------------------------
	private JPanel getYLabelLine() {
		if (yLabelLine == null) {
			jLabel5 = new JLabel();
			jLabel5.setText("  Scaling:  ");
			jLabel3 = new JLabel();
			jLabel3.setText("  Y-Axis label:");
			jLabel3.setPreferredSize(new Dimension(125, 16));
			yLabelLine = new JPanel();
			yLabelLine.setLayout(new BoxLayout(getYLabelLine(), BoxLayout.X_AXIS));
			yLabelLine.setPreferredSize(new Dimension(400, 20));
			yLabelLine.add(jLabel3, null);
			yLabelLine.add(getYLabelField(), null);
			yLabelLine.add(jLabel5, null);
			yLabelLine.add(getYScaleBox(), null);
		}
		return yLabelLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getTitleField() {
		if (titleField == null) {
			titleField = new JTextField();
			titleField.setText(ChartConstants.XYLINECHART_NAME);
			titleField.setName("titleField");
			final XYLineDialog tthis = this;
			titleField.setPreferredSize(new Dimension(300, 20));
			titleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.TITLE,titleField.getText());
					ChartDialogChangeCenter.fireTitleChanged(tthis);
				}
			});
			titleField.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					subtitleField.grabFocus();
				}
			});
		}
		return titleField;
	}

	//------------------------------------------------------------------------------
	private JTextField getSubtitleField() {
		if (subtitleField == null) {
			subtitleField = new JTextField();
			subtitleField.setPreferredSize(new Dimension(300, 20));
			subtitleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
				}
			});
		}
		return subtitleField;
	}

	//------------------------------------------------------------------------------
	private JTextField getXLabelField() {
		if (xLabelField == null) {
			xLabelField = new JTextField();
			xLabelField.setPreferredSize(new Dimension(200, 20));
			xLabelField.setText("X");
			xLabelField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.X_AXIS,xLabelField.getText());
				}
			});
		}
		return xLabelField;
	}

	//------------------------------------------------------------------------------
	private JTextField getYLabelField() {
		if (yLabelField == null) {
			yLabelField = new JTextField();
			yLabelField.setPreferredSize(new Dimension(200, 20));
			yLabelField.setText("Y");
			yLabelField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.Y_AXIS,yLabelField.getText());
				}
			});
		}
		return yLabelField;
	}

	//------------------------------------------------------------------------------
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = new JPanel();
			buttonPanel.setLayout(new FlowLayout());
			buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
			buttonPanel.add(getEditorButton(), null);
			buttonPanel.add(getComposeButton(), null);
			buttonPanel.add(getDisplayButton(), null);
			buttonPanel.add(getSaveButton(), null);
			buttonPanel.add(getCancelButton(), null);
		}
		return buttonPanel;
	}
	
	//------------------------------------------------------------------------------
	private JButton getDisplayButton() {
		if (displayButton == null) {
			displayButton = new JButton();
			displayButton.setText("Display");
			displayButton.setEnabled(false);
			displayButton.setMnemonic(KeyEvent.VK_D);
			displayButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					displayChart();
				}
			});
		}
		return displayButton;
	}

	//------------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.setEnabled(false);
			saveButton.setText("Save");
			saveButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					saveCollection();
				}
			});
		}
		return saveButton;
	}

	//------------------------------------------------------------------------------
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setText("Cancel");
			cancelButton.setMnemonic(KeyEvent.VK_C);
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					notifyForHide();
				}
			});
		}
		return cancelButton;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getParamPanel() {
		if (paramPanel == null) {
			paramPanel = new JPanel();
			paramPanel.setLayout(new BoxLayout(getParamPanel(), BoxLayout.Y_AXIS));
			paramPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
			paramPanel.add(getXPanel(), null);
			paramPanel.add(getYPanel(), null);
			paramPanel.add(getAddButtonPanel(), null);
		}
		return paramPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getXyPanel() {
		if (xyPanel == null) {
			xyPanel = new JPanel();
			xyPanel.setLayout(new BoxLayout(getXyPanel(), BoxLayout.Y_AXIS));
			xyPanel.setBorder(BorderFactory.createTitledBorder(null, "Selected functions", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			xyPanel.setPreferredSize(new Dimension(150, 100));
			xyPanel.add(getScrList(), null);
			xyPanel.add(Box.createRigidArea(new Dimension(0,5)));
			xyPanel.add(getSortPanel(), null);
		}
		return xyPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getXParams() {
		if (xParams == null) {
			xParams = new JComboBox(getParamsToX());
			xParams.setRenderer(new DataSourceComboBoxRenderer(xParams));
			xParams.setPreferredSize(new Dimension(100,26));
			if (xParams.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)xParams.getSelectedItem();
				xParams.setToolTipText(dsp.toString());
			}
			xParams.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)xParams.getSelectedItem();
					xParams.setToolTipText(dsp.toString());
					xAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
					List<Class> ds = dsp.getSupportedIntfs();
					if (ds.contains(IXYSeriesProducer.class)) {
						// XYLineChart from one data source
						yParams.setEnabled(false);
						yAdvancedButton.setEnabled(false);
					} else {
						// XYLineChart from two data source
						IDataSourceProducer old = null;
						if (yParams.getItemCount() > 0)
							old = (IDataSourceProducer)yParams.getSelectedItem();
						if (dsp.equals(allProducer)) {
							yParams.setModel(new DefaultComboBoxModel(getParamsToY()));
						} else 	if (!ds.contains(ISeriesProducer.class)) {
							// dsp supports only IValueProducer => get out the
							// just-series-producer-supporters from the other
							// combobox.
							yParams.setModel(new DefaultComboBoxModel(getValueParamsToY()));
						} else if (!ds.contains(IValueProducer.class)) {
							// dsp supports only ISeriesProducer => get out the
							// just-value-producer-supporters from the other
							// combobox.
							yParams.setModel(new DefaultComboBoxModel(getSeriesParamsToY()));
						} else {
							yParams.setModel(new DefaultComboBoxModel(getParamsToY()));
						}
						if (yParams.getItemCount() > 0) {
							if (old != null) {
								for (int i=0;i<yParams.getItemCount();++i) {
									if (yParams.getItemAt(i).equals(old)) {
										yParams.setSelectedIndex(i);
										break;
									}
								}
							}
							
							yParams.setEnabled(true);
							IDataSourceProducer ydsp = (IDataSourceProducer)yParams.getSelectedItem();
							yAdvancedButton.setEnabled(ydsp.hasAdvancedSettings());
						}
					}
				}
			});
		}
		return xParams;
	}

	//------------------------------------------------------------------------------
	private JComboBox getYParams() {
		if (yParams == null) {
			yParams = new JComboBox(getParamsToY());
			yParams.setRenderer(new DataSourceComboBoxRenderer(yParams));
			yParams.setPreferredSize(new Dimension(100,26));
			if (yParams.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)yParams.getSelectedItem();
				yParams.setToolTipText(dsp.toString());
			}
			if (xParams.getItemCount()>0) {
				IDataSourceProducer dsp = (IDataSourceProducer)xParams.getSelectedItem();
				List<Class> ds = dsp.getSupportedIntfs();
				if (ds.contains(IXYSeriesProducer.class)) {
					yParams.setEnabled(false);
				}
			}
			yParams.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)yParams.getSelectedItem();
					yParams.setToolTipText(dsp.toString());
					yAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
				}
			});
		}
		return yParams;
	}

	//------------------------------------------------------------------------------
	private JButton getAddButton() {
		if (addButton == null) {
			addButton = new JButton();
			addButton.setMnemonic(KeyEvent.VK_A);
			addButton.setPreferredSize(new Dimension(73, 26));
			addButton.setText("Add");
			addButton.setIcon(Utilities.getIcon("RIGHT ARROW"));
			addButton.setIconTextGap(2);
			addButton.setHorizontalTextPosition(JButton.LEADING);
			addButton.setMaximumSize(new Dimension(73, 26));
			final XYLineDialog tthis = this;
			addButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer xdsp = (IDataSourceProducer)xParams.getSelectedItem();
					if (xdsp.equals(allProducer)) {
						IDataSourceProducer ydsp = (IDataSourceProducer)yParams.getSelectedItem();
						if (ydsp.equals(allProducer)) {
							// All -> All
							for (int i=0;i<xParams.getItemCount();++i) {
								IDataSourceProducer xp = (IDataSourceProducer)xParams.getItemAt(i);
								if (xp.equals(allProducer)) continue;
								if (xp.getSupportedIntfs().contains(IXYSeriesProducer.class)) {
									Pair f = new Pair(xp,null);
									if (functions.contains(f)) return; // repeated function
									functions.add(f); // add new function
									lmodel.addElement(xp.toString()+" [(x,y) series from one source]"); // display it in the list									
								} else if (!xp.getSupportedIntfs().contains(ISeriesProducer.class)) {
									for (Object o : getValueParamsToY()) {
										IDataSourceProducer yp = (IDataSourceProducer)o;
										if (yp.equals(allProducer)) continue;
										Pair f = new Pair(xp,yp);
										if (functions.contains(f)) continue;
										functions.add(f);
										lmodel.addElement(xp.toString() + " -> " + yp.toString());
									}
								} else {
									for (Object o : getSeriesParamsToY()) {
										IDataSourceProducer yp = (IDataSourceProducer)o;
										if (yp.equals(allProducer)) continue;
										Pair f = new Pair(xp,yp);
										if (functions.contains(f)) continue;
										functions.add(f);
										lmodel.addElement(xp.toString() + " -> " + yp.toString());
									}
								}
							}
						} else {
							// All -> y
							boolean justValues = !ydsp.getSupportedIntfs().contains(ISeriesProducer.class);
							boolean justSeries = !ydsp.getSupportedIntfs().contains(IValueProducer.class);
							for (int i=0;i<xParams.getItemCount();++i) {
								IDataSourceProducer xp = (IDataSourceProducer)xParams.getItemAt(i);
								if (xp.equals(allProducer) ||
									xp.getSupportedIntfs().contains(IXYSeriesProducer.class) ||
								   (justValues && !xp.getSupportedIntfs().contains(IValueProducer.class)) ||
								   (justSeries && !xp.getSupportedIntfs().contains(ISeriesProducer.class))
								   ) continue;
								Pair f = new Pair(xp,ydsp);
								if (functions.contains(f)) continue;
								functions.add(f);
								lmodel.addElement(xp.toString() + " -> " + ydsp.toString());
							}
						}
					} else {
						List<Class> ds = xdsp.getSupportedIntfs();
						if (ds.contains(IXYSeriesProducer.class)) {
							Pair f = new Pair(xdsp,null);
							if (functions.contains(f)) return; // repeated function
							functions.add(f); // add new function
							lmodel.addElement(xdsp.toString()+" [(x,y) series from one source]"); // display it in the list
//							updateAxesLabels();
						} else {
							IDataSourceProducer ydsp = (IDataSourceProducer)yParams.getSelectedItem();
							if (ydsp == null) return;
							if (ydsp.equals(allProducer)) {
								for (int i=0;i<yParams.getItemCount();++i) {
									IDataSourceProducer yp = (IDataSourceProducer)yParams.getItemAt(i);
									Pair f = new Pair(xdsp,yp);
									if (yp.equals(allProducer) || functions.contains(f)) continue;
									functions.add(f);
									lmodel.addElement(xdsp.toString() + " -> " + yp.toString());
								}
							} else {
								//if (xdsp.equals(ydsp)) return; // identical function
								Pair f = new Pair(xdsp,ydsp);
								if (functions.contains(f)) return; // repeated function
								functions.add(f); // add new function
								lmodel.addElement(xdsp.toString()+" -> "+ydsp.toString()); // display the function in the list
							}
						}
					}
					updateAxesLabels();
					
					// enable the buttons (if need)
					if (functions.size()>0) {
						if (isUpdateable()) {
							displayButton.setEnabled(true);
							ChartDialogChangeCenter.fireSaveEnabled(tthis);
						}
						removeButton.setEnabled(true);
						if (chartDialogParent != null) childStatusChanged();
					}
					if (functions.size()>1) {
						downButton.setEnabled(true);
						upButton.setEnabled(true);
					}
				}
			});
		}
		return addButton;
	}

	//------------------------------------------------------------------------------
	private JButton getRemoveButton() {
		if (removeButton == null) {
			removeButton = new JButton();
			removeButton.setMnemonic(KeyEvent.VK_R);
			removeButton.setText("Remove");
			removeButton.setEnabled(false);
			removeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
			removeButton.setActionCommand("REMOVE");			
			removeButton.addActionListener(this);
		}
		return removeButton;
	}

	//------------------------------------------------------------------------------
	private JList getXyList() {
		if (xyList == null) {
			xyList = new JList(lmodel);
			xyList.setAutoscrolls(true);
			xyList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			xyList.addMouseListener(this);
		}
		return xyList;
	}

	//------------------------------------------------------------------------------
	private JPanel getSortPanel() {
		if (sortPanel == null) {
			sortPanel = new JPanel();
			sortPanel.setLayout(new FlowLayout());
			sortPanel.setMinimumSize(new Dimension(150, 36));
			sortPanel.setPreferredSize(new Dimension(150, 36));
			sortPanel.add(getDownButton(), null);
			sortPanel.add(getUpButton(), null);
			sortPanel.add(getRemoveButton(), null);
		}
		return sortPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getDownButton() {
		if (downButton == null) {
			downButton = new JButton();
			downButton.setMnemonic(KeyEvent.VK_DOWN);
			downButton.setEnabled(false);
			downButton.setText("Down");
			downButton.setActionCommand("DOWN");
			downButton.addActionListener(this);
		}
		return downButton;
	}

	//------------------------------------------------------------------------------
	private JButton getUpButton() {
		if (upButton == null) {
			upButton = new JButton();
			upButton.setMnemonic(KeyEvent.VK_UP);
			upButton.setMaximumSize(new Dimension(66, 26));
			upButton.setEnabled(false);
			upButton.setText("Up");
			upButton.setActionCommand("UP");
			upButton.addActionListener(this);
		}
		return upButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getXPanel() {
		if (xPanel == null) {
			xPanel = new JPanel();
			xPanel.setLayout(new BoxLayout(getXPanel(), BoxLayout.X_AXIS));
			xPanel.setBorder(BorderFactory.createTitledBorder(null, "X values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			xPanel.add(getXParams(), null);
			xPanel.add(Box.createRigidArea(new Dimension(5,0)));
			xPanel.add(getXAdvancedButton(), null);
		}
		return xPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getYPanel() {
		if (yPanel == null) {
			yPanel = new JPanel();
			yPanel.setLayout(new BoxLayout(getYPanel(), BoxLayout.X_AXIS));
			yPanel.setBorder(BorderFactory.createTitledBorder(null, "Y values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			yPanel.add(getYParams(), null);
			yPanel.add(Box.createRigidArea(new Dimension(5,0)));
			yPanel.add(getYAdvancedButton(), null);
		}
		return yPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getAddButtonPanel() {
		if (addButtonPanel == null) {
			addButtonPanel = new JPanel();
			addButtonPanel.setLayout(new FlowLayout());
			addButtonPanel.add(getAddButton(), null);
		}
		return addButtonPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getXAdvancedButton() {
		if (xAdvancedButton == null) {
			xAdvancedButton = new JButton();
			xAdvancedButton.setEnabled(false);
			xAdvancedButton.setText("Advanced...");
			final XYLineDialog tthis = this;
			xAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)xParams.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(tthis.getRootPane().getParent());
					if (new_dsp != null) {
						int index = xParams.getSelectedIndex();
						xParams.removeItemAt(index);
						xParams.insertItemAt(new_dsp,index);
						xParams.setSelectedIndex(index);
					}
				}
			});
			if (xParams.getItemCount()>0) {
				IDataSourceProducer dsp = (IDataSourceProducer)xParams.getSelectedItem();
				xAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return xAdvancedButton;
	}

	//------------------------------------------------------------------------------
	private JButton getYAdvancedButton() {
		if (yAdvancedButton == null) {
			yAdvancedButton = new JButton();
			yAdvancedButton.setEnabled(false);
			yAdvancedButton.setText("Advanced...");
			final XYLineDialog tthis = this;
			yAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)yParams.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(tthis.getRootPane().getParent());
					if (new_dsp != null) {
						int index = yParams.getSelectedIndex();
						yParams.removeItemAt(index);
						yParams.insertItemAt(new_dsp,index);
						yParams.setSelectedIndex(index);
					}
				}
			});
			if (yParams.getItemCount()>0 && yParams.isEnabled()) {
				IDataSourceProducer dsp = (IDataSourceProducer)yParams.getSelectedItem();
				yAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return yAdvancedButton;
	}
	
	//------------------------------------------------------------------------------
	private JScrollPane getScrList() {
		if (scrList == null) {
			scrList = new JScrollPane();
			scrList.setAutoscrolls(true);
			scrList.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			scrList.setWheelScrollingEnabled(true);
			scrList.setViewportView(getXyList());
		}
		return scrList;
	}

	//------------------------------------------------------------------------------
	private JComboBox getXScaleBox() {
		if (xScaleBox == null) {
			xScaleBox = new JComboBox(scaleTypes);
			xScaleBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Comparable id = ((ComboboxItem)xScaleBox.getSelectedItem()).getID();
					properties.setProperty(ChartConstants.X_AXIS_SCALE,id.toString());
				}
			});
		}
		return xScaleBox;
	}

	//------------------------------------------------------------------------------
	private JComboBox getYScaleBox() {
		if (yScaleBox == null) {
			yScaleBox = new JComboBox(scaleTypes);
			yScaleBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Comparable id = ((ComboboxItem)yScaleBox.getSelectedItem()).getID();
					properties.setProperty(ChartConstants.Y_AXIS_SCALE,id.toString());
				}
			});
		}
		return yScaleBox;
	}

	//------------------------------------------------------------------------------
	private JPanel getAppearancePanel() {
		if (appearancePanel == null) {
			jLabel7 = new JLabel();
			jLabel7.setText("  Appearance:  ");
			jLabel6 = new JLabel();
			jLabel6.setText(" ");
			jLabel6.setPreferredSize(new Dimension(125, 16));
			appearancePanel = new JPanel();
			appearancePanel.setLayout(new BoxLayout(getAppearancePanel(), BoxLayout.X_AXIS));
			appearancePanel.add(jLabel6, null);
			appearancePanel.add(getShowLegendBox(), null);
			appearancePanel.add(Box.createRigidArea(new Dimension(10,0)));
			appearancePanel.add(jLabel7, null);
			appearancePanel.add(getAppearanceBox(), null);
			appearancePanel.add(new JLabel("  Renderer:  "), null);
			appearancePanel.add(getRendererBox(), null);
		}
		return appearancePanel;
	}

	//------------------------------------------------------------------------------
	private JCheckBox getShowLegendBox() {
		if (showLegendBox == null) {
			showLegendBox = new JCheckBox();
			showLegendBox.setSelected(true);
			showLegendBox.setText("Show legend");
			showLegendBox.addItemListener(new java.awt.event.ItemListener() {
				public void itemStateChanged(java.awt.event.ItemEvent e) {
					properties.setProperty(ChartConstants.SHOW_LEGEND,String.valueOf(showLegendBox.isSelected()));
				}
			});
		}
		return showLegendBox;
	}

	//------------------------------------------------------------------------------
	private JComboBox getAppearanceBox() {
		if (appearanceBox == null) {
			Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
			appearances.add(new ComboboxItem( "BC", "Basic, colored"));
			appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
			appearances.add(new ComboboxItem( "NC", "Normal, colored"));
			appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
			for (String templateNames : AbstractChart.templates.keySet())
				appearances.add(new ComboboxItem("_" + templateNames,templateNames));
			appearances.add(new ComboboxItem("_NEW","New template..."));
			appearances.add(new ComboboxItem("_EDIT","Edit template..."));
			appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
			appearanceBox = new JComboBox(appearances);
			appearanceBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int index = appearanceBox.getSelectedIndex();
					String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
					if (index >= 0 && index <= 3) {
				 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
				 		if (code[0].equals("B"))
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.BASIC_APP);
				 		else
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.NORMAL_APP);
				 		if (code[1].equals("BW"))
				 			ChartConfigCollection.setColorAppearance(ChartConstants.BLACK_AND_WHITE);
				 		else
				 			ChartConfigCollection.setColorAppearance(ChartConstants.COLORED);
					} else if (appearanceCode.equals("_NEW")) {
						ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.NORMAL);
						int result = dlg.showDialog();
						if (result == ChartPropertiesDialog.OK_OPTION) {
							Element newTemplate = (Element) dlg.getTemplate();
							dlg.dispose();
							String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
							AbstractChart.templates.put(name,newTemplate);
							ChartDialogChangeCenter.fireTemplateChanged();
							appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
						} else 
							appearanceBox.setSelectedIndex(0);
					} else if (appearanceCode.equals("_EDIT")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(XYLineDialog.this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(XYLineDialog.this,"Select a template: ","Edit template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template == null || "".equals(template)) 
							appearanceBox.setSelectedIndex(0);
						else {
							Element templateElement = AbstractChart.templates.get(template);
							ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(),ChartKind.NORMAL);
							int result = dlg.showDialog();
							if (result == ChartPropertiesDialog.OK_OPTION) {
								Element newTemplate = (Element) dlg.getTemplate();
								dlg.dispose();
								String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
								AbstractChart.templates.put(name,newTemplate);
								ChartDialogChangeCenter.fireTemplateChanged();
								appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
							} else 
								appearanceBox.setSelectedIndex(0);
						}
					} else if (appearanceCode.equals("_REMOVE")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(XYLineDialog.this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(XYLineDialog.this,"Select a template: ","Delete template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template != null && !"".equals(template)) { 
							AbstractChart.templates.remove(template);
							File file = new File("Templates/" + template + ".xml");
							file.delete();
							ChartDialogChangeCenter.fireTemplateChanged();
						}
						appearanceBox.setSelectedIndex(0);
					}
				}
			});
		}
		return appearanceBox;
	}
	
	//------------------------------------------------------------------------------
	private List<String> getLegends() {
		List<String> result = new ArrayList<String>(functions.size());
		for (int i = 0;i < functions.size();++i) {
			String str = functions.get(i).getX().toString();
			if (functions.get(i).getY() != null) 
				str = "(" + str + "," + functions.get(i).getY().toString() + ")";
			result.add(str);
		}
		return result;
	}	
	//------------------------------------------------------------------------------
	private JComboBox getRendererBox() {
		if (rendererBox == null) {
			rendererBox = new JComboBox(rendererTypes);
			rendererBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Comparable id = ((ComboboxItem)rendererBox.getSelectedItem()).getID();
					properties.setProperty(ChartConstants.XYLINE_RENDERER,id.toString());
				}
			});
		}
		return rendererBox;
	}
	
	//------------------------------------------------------------------------------
	private JButton getComposeButton() {
		if (composeButton == null) {
			composeButton = new JButton();
			composeButton.setText("Compose...");
			composeButton.setMnemonic(KeyEvent.VK_M);
			composeButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					getComposeMenu().show(composeButton,45,5);
				}
			});
		}
		return composeButton;
	}

	//------------------------------------------------------------------------------
	private JPopupMenu getComposeMenu() {
		if (composeMenu == null) {
			composeMenu = new JPopupMenu();
			composeMenu.add(getMHistogram());
			composeMenu.add(getMScatterPlot());
			composeMenu.add(getMTimeSeries());
			composeMenu.add(getMRealTimeSeries());
		}
		return composeMenu;
	}

	//------------------------------------------------------------------------------
	private JMenuItem getMHistogram() {
		if (mHistogram == null) {
			mHistogram = new JMenuItem();
			mHistogram.setText(ChartConstants.HISTOGRAM_NAME);
			mHistogram.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.HISTOGRAM);
				}
			});
		}
		return mHistogram;
	}

	//------------------------------------------------------------------------------
	private JMenuItem getMRealTimeSeries() {
		if (mRealTimeSeries == null) {
			mRealTimeSeries = new JMenuItem();
			mRealTimeSeries.setText(ChartConstants.REALTIMESERIES_NAME);
			mRealTimeSeries.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.REALTIMESERIES);
				}
			});
		}
		return mRealTimeSeries;
	}

	//------------------------------------------------------------------------------
	private JMenuItem getMScatterPlot() {
		if (mScatterPlot == null) {
			mScatterPlot = new JMenuItem();
			mScatterPlot.setText(ChartConstants.SCATTERPLOT_NAME);
			mScatterPlot.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.SCATTERPLOT);
				}
			});
		}
		return mScatterPlot;
	}
	
	//------------------------------------------------------------------------------
	private JMenuItem getMTimeSeries() {
		if (mTimeSeries == null) {
			mTimeSeries = new JMenuItem();
			mTimeSeries.setText(ChartConstants.TIMESERIES_NAME);
			mTimeSeries.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.TIMESERIES);
				}
			});
		}
		return mTimeSeries;
	}
	
	//===========================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-generated functions                                                //
	////////////////////////////////////////////////////////////////////////////

	@Override
	protected void setWidgetDisabled() {
		if (xParams.getItemCount() == 0) {
			xParams.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			xAdvancedButton.setEnabled(false);
			addButton.setEnabled(false);
			if (cc_collection.getComposeMode()) composeButton.setEnabled(false);
		}
		if (yParams.getItemCount() == 0) {
			yParams.setEnabled(false);
			yAdvancedButton.setEnabled(false);
		}
	}
	
	//------------------------------------------------------------------------------
	/** Returns the displayable names of the data sources.
	 * @return array of data sources
	 */
 	private Object[] getParamsToX() {
 		Object[] res = getParams(IXYSeriesProducer.class);
 		if (res.length != 0) {
 			List<Object> resPlus = new ArrayList<Object>(Arrays.asList(res));
 			resPlus.add(allProducer);
 			return resPlus.toArray();
 		}
 		return res;
 	}
 	
	//------------------------------------------------------------------------------
 	/** Returns the displayable names of the data sources that supports
 	 *  the <code>ISeriesProducer</code> and/or <code>IValueProducer</code> interface.
 	 * @return array of data sources
 	 */
 	private Object[] getParamsToY() {
 		if (forYAll == null) {
 			forYAll = getParams(new Class[] { ISeriesProducer.class, IValueProducer.class });
 			if (forYAll.length != 0) {
 				List<Object> plus = new ArrayList<Object>(Arrays.asList(forYAll));
 				plus.add(allProducer);
 				forYAll = plus.toArray();
 			}
 		}
		return forYAll; 
 	}
 	
 	//------------------------------------------------------------------------------
 	/** Returns the displayable names of data sources that supports only the <code>
 	 *  ISeriesProducer</code>.
 	 * @return array of data sources
 	 */
 	private Object[] getSeriesParamsToY() {
 		if (forYSeries == null) {
 			forYSeries = getParams(ISeriesProducer.class, IValueProducer.class);
 			if (forYSeries.length != 0) {
 				List<Object> plus = new ArrayList<Object>(Arrays.asList(forYSeries));
 				plus.add(allProducer);
 				forYSeries = plus.toArray();
 			}
 		}
 		return forYSeries;
 	}
 	
 	//------------------------------------------------------------------------------
 	/** Returns the displayable names of data sources that supports only the
 	 *  <code>IValueProducer</code>.
 	 * @return array of data sources
 	 */
 	private Object[] getValueParamsToY() {
 		if (forYValue == null) {
 			forYValue = getParams(IValueProducer.class, ISeriesProducer.class);
 			if (forYValue.length != 0) {
 				List<Object> plus = new ArrayList<Object>(Arrays.asList(forYValue));
 				plus.add(allProducer);
 				forYValue = plus.toArray();
 			}
 		}
 		return forYValue;
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	protected void setSettingsFromConfig() {
 		if (config.getChartProperties() instanceof Properties) {
 			// set settings from the config
 			properties = (Properties)config.getChartProperties();
 			String xAxis = properties.getProperty(ChartConstants.X_AXIS);
 			String yAxis = properties.getProperty(ChartConstants.Y_AXIS);
 			
 			String[] curves = properties.getProperty(ChartConstants.DATASOURCE).split(",");
 			IDataSourceProducer xdsp = null ,ydsp = null;
 			for (int i=0;i<curves.length;++i) {
 				int[] ds = Utilities.splitDatasourceAroundSpace(curves[i]);
 				Pair p = null;
 				if (ds.length == 1) {
 					xdsp = config.getDataSource(ds[0]);
 					p = new Pair(xdsp,null);
 					lmodel.addElement(xdsp.toString()+" [(x,y) series from one source]");
 				} else {
 					xdsp = config.getDataSource(ds[0]);
 					ydsp = config.getDataSource(ds[1]);
 					p = new Pair(xdsp,ydsp);
 					lmodel.addElement(xdsp.toString()+" -> "+ydsp.toString());
 				}
 				functions.add(p);
 			}
 			xParams.setSelectedItem(xdsp);
 			if (xdsp.getSupportedIntfs().contains(IXYSeriesProducer.class)) {
 				yParams.setEnabled(false);
 			} else {
 				yParams.setSelectedItem(ydsp);
 			}
 			titleField.setText(properties.getProperty(ChartConstants.TITLE));
 			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
 			xLabelField.setText(xAxis);
 			String scale = properties.getProperty(ChartConstants.X_AXIS_SCALE);
 			if (scale.equals(ChartConstants.LOG)) xScaleBox.setSelectedIndex(1);
 			yLabelField.setText(yAxis);
 			scale = properties.getProperty(ChartConstants.Y_AXIS_SCALE);
 			if (scale.equals(ChartConstants.LOG)) yScaleBox.setSelectedIndex(1);
 			showLegendBox.setSelected(Boolean.parseBoolean(properties.getProperty(ChartConstants.SHOW_LEGEND,"true")));
 			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
 			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
 				String appearanceCode = "";
 				appearanceCode += properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP) ? "N" : "B";
 				appearanceCode += properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE)? "BW" : "C";
 				for (int i = 0;i < appearanceBox.getItemCount();++i) {
 					String id = ((ComboboxItem)appearanceBox.getItemAt(i)).getID().toString();
 					if (id.equals(appearanceCode)) {
 						appearanceBox.setSelectedIndex(i);
 						break;
 					}
 				}
 			}
 			rendererBox.setSelectedIndex(Integer.parseInt(properties.getProperty(ChartConstants.XYLINE_RENDERER,String.valueOf(LineChartMetadata.RENDERER_LINES_ONLY))));
 			if (functions.size()>0) {
 				displayButton.setEnabled(true);
 				saveButton.setEnabled(true);
 				removeButton.setEnabled(true);
 			}
 			if (functions.size()>1) {
 				downButton.setEnabled(true);
 				upButton.setEnabled(true);
 			}
 		} else {
 			// set the initial properties
 			properties.setProperty(ChartConstants.TITLE,ChartConstants.XYLINECHART_NAME);
 			properties.setProperty(ChartConstants.SUBTITLE,"");
 			properties.setProperty(ChartConstants.X_AXIS,"X");
 			properties.setProperty(ChartConstants.X_AXIS_SCALE,ChartConstants.NORMAL);
 			properties.setProperty(ChartConstants.Y_AXIS,"Y");
 			properties.setProperty(ChartConstants.Y_AXIS_SCALE,ChartConstants.NORMAL);
 			properties.setProperty(ChartConstants.SHOW_LEGEND,"true");
 			properties.setProperty(ChartConstants.XYLINE_RENDERER,String.valueOf(LineChartMetadata.RENDERER_LINES_ONLY));
 			int appIndex = 0;
 			appIndex += ChartConfigCollection.getColorAppearance().equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
 			appIndex += ChartConfigCollection.getEnvironmentAppearance().equals(ChartConstants.NORMAL_APP) ? 2 : 0;
 			appearanceBox.setSelectedIndex(appIndex);
			
 			// initial y params
 			if (xParams.getItemCount() > 0)
 				xParams.setSelectedIndex(0);
 		}
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	public void updateChartConfig() {
 		config.clearAllDataSource();
 		Iterator<Pair> it = functions.iterator();
 		boolean use_short_legend = true;
 		IDataSourceProducer xProducer = functions.get(0).getX();
		String ds = "";
 		while (it.hasNext()) {
 			Pair pair = it.next();
 			if (pair.getY() != null) { // two ISeriesProducers or two IValueProducers
 				boolean xIsSeries = pair.getX().getSupportedIntfs().contains(ISeriesProducer.class);
 				boolean yIsSeries = pair.getY().getSupportedIntfs().contains(ISeriesProducer.class);
 				int xKey = -1, yKey = -1;
 				if (xIsSeries && yIsSeries) {
 					xKey = config.addDataSource(pair.getX(),ISeriesProducer.class);
 					yKey = config.addDataSource(pair.getY(),ISeriesProducer.class);
 				} else if (!xIsSeries && !yIsSeries) {
 					xKey = config.addDataSource(pair.getX(),IValueProducer.class);
 					yKey = config.addDataSource(pair.getY(),IValueProducer.class);
 				} else
 					throw new IllegalStateException("Invalid data source combination");
 				ds += String.valueOf(xKey) + " ";
 				ds += String.valueOf(yKey) + ",";
 				if (!pair.getX().equals(xProducer)) use_short_legend = false;
 			} else {
 				int key = config.addDataSource(pair.getX(),IXYSeriesProducer.class);
 				ds += String.valueOf(key) + ",";
 				use_short_legend = false;
 			}
 		}
		properties.setProperty(ChartConstants.DATASOURCE,ds.substring(0,ds.length()-1));
		properties.setProperty(ChartConstants.SHORT_LEGEND_NAMES,String.valueOf(use_short_legend));
		int appearanceIndex = appearanceBox.getSelectedIndex();
		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 3) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
			String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
			if (code[0].equals("B"))
				properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.BASIC_APP);
			else
				properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.NORMAL_APP);
			if (code[1].equals("BW"))
				properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.BLACK_AND_WHITE);
			else
				properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.COLORED);
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
		config.setChartProperties(ChartConstants.XYLINECHART,properties);
		if (config.isMultiLayerChart()) {
			for (int i = 1;i < child_panel.getComponentCount();i += 2) 
				((AbstractChartDialog)child_panel.getComponent(i)).updateChartConfig();
		}
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	public boolean isUpdateable() {
 		if (!config.isMultiLayerChart()) return !functions.isEmpty();
 		boolean update = !functions.isEmpty();
 		for (int i=1;i<child_panel.getComponentCount();i+=2) {
 			if (!update) break;
 			update = update && ((AbstractChartDialog)child_panel.getComponent(i)).isUpdateable();
 		}
 		return update;
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
	public void setChildMode(boolean realTimeSeriesParent) {
		this.remove(buttonPanel);
		jLabel.setEnabled(false);
		titleField.setText("");
		titleField.setEnabled(false);
		jLabel1.setEnabled(false);
		subtitleField.setEnabled(false);
		showLegendBox.setEnabled(false);
		jLabel7.setEnabled(false);
		appearanceBox.setEnabled(false);
		if (!realTimeSeriesParent) {
			jLabel2.setEnabled(false);
			xLabelField.setText("");
			xLabelField.setEnabled(false);
			jLabel4.setEnabled(false);
			xScaleBox.setEnabled(false);
		}
		cap = new ChildAdditionalPanel(this,properties,AbstractChart.find(config.getChartType()).toString());
		add(cap,0);
 	}
	
	//------------------------------------------------------------------------------
 	@Override
	protected void removeChild(AbstractChartDialog who) {
 		config.removeChild(who.config);
 		child_panel.remove(who);
 		int count = child_panel.getComponentCount();
 		for (int i=0;i<count-1;++i) {
 			if (child_panel.getComponent(i) instanceof JSeparator && 
 				child_panel.getComponent(i+1) instanceof JSeparator) {
 				child_panel.remove(i);
 				break;
 			}
		}
 		count = child_panel.getComponentCount();
 		if (child_panel.getComponent(count-1) instanceof JSeparator)
 			child_panel.remove(count-1);
		if (!config.isMultiLayerChart()) {
 			scr.setVisible(false);
 			this.setPreferredSize(new Dimension(609,219));
 			child_panel = null;
 		}
		Utilities.repack(this);
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
	public void setComposeButton(boolean invisibled) {
		composeButton.setVisible(!invisibled);
	}
	
	//------------------------------------------------------------------------------
 	@Override
	protected void setSelectedAxis(AbstractChartDialog who) {
 		for (int i=1;i<child_panel.getComponentCount();i+=2) {
 			if (!child_panel.getComponent(i).equals(who))
 				((AbstractChartDialog)child_panel.getComponent(i)).cap.setAxisDisabled();
 		}
 	}

	//------------------------------------------------------------------------------
	@Override
	protected void displayPreview() throws Exception {
		DataSources ds = new DataSources(new SimpleDSPCollection());
		ChartConfig temp_config = new ChartConfig(ds);
		temp_config.setFireInitialEvent(true);
		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
		Properties temp_prop = (Properties)properties.clone();
		temp_config.addDataSource(dsl.get(0),ISeriesProducer.class);
		temp_config.addDataSource(dsl.get(1),ISeriesProducer.class);
		temp_config.addDataSource(dsl.get(2),ISeriesProducer.class);
		temp_prop.setProperty(ChartConstants.DATASOURCE,"1 2,2 3");
		temp_prop.setProperty(ChartConstants.TITLE,temp_prop.getProperty(ChartConstants.TITLE)+ " (Preview Illustration)");
		temp_config.setChartProperties(ChartConstants.XYLINECHART,temp_prop);
		Utilities.displayPreview(temp_config);
	}
	
	//-----------------------------------------------------------------------------
	/** Updates the labels of the axes with the name of the x and y components of the
	 *  function. If the first function forms from a series of (x,y) pairs, the labels return
	 *  to the default settings. If there isn't any function, the labels return to the
	 *  default settings, too.
	 */ 
	private void updateAxesLabels() {
		if (functions.size()==0) {
			xLabelField.setText("X");
			yLabelField.setText("Y");
		} else {
			Pair p = functions.get(0);
			if (p.getY() != null) {
				xLabelField.setText(p.getX().toString());
				yLabelField.setText(p.getY().toString());
			} else {
				xLabelField.setText("X");
				yLabelField.setText("Y");
			}
		}
		properties.setProperty(ChartConstants.X_AXIS,xLabelField.getText());
		properties.setProperty(ChartConstants.Y_AXIS,yLabelField.getText());
	}
	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem)appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		// reset widgets
		xParams.setEnabled(true);
		xAdvancedButton.setEnabled(true);
		addButton.setEnabled(true);
		if (cc_collection.getComposeMode()) composeButton.setEnabled(true);
		yParams.setEnabled(true);
		yAdvancedButton.setEnabled(true);
		
		Object xObject = xParams.getSelectedIndex() == -1 ? null : xParams.getSelectedItem();
		Object yObject = yParams.getSelectedIndex() == -1 ? null : yParams.getSelectedItem();
		
		forYAll = forYSeries = forYValue = null;
		DefaultComboBoxModel xModel = new DefaultComboBoxModel(getParamsToX());
		xParams.setModel(xModel);
		DefaultComboBoxModel yModel = new DefaultComboBoxModel(getParamsToY());
		yParams.setModel(yModel);
		
		
		if (yObject != null && findInComboBox(yModel,(IDataSourceProducer)yObject) != -1) {
			int idx = findInComboBox(yModel,(IDataSourceProducer)yObject);
			yParams.setSelectedIndex(idx >= 0 ? idx : 0);
		} 
		if (xObject != null && findInComboBox(xModel,(IDataSourceProducer)xObject) != -1) {
			int idx = findInComboBox(xModel,(IDataSourceProducer)xObject);
			xParams.setSelectedIndex(idx >= 0 ? idx : 0);
		} else if (xParams.getItemCount() > 0)
			xParams.setSelectedIndex(0);
		
		List<Pair> newPairs = new ArrayList<Pair>();
		for (Pair prod_pair : functions) {
			if (prod_pair.getY() == null) {
				int idx = findInComboBox(xModel,prod_pair.getX());
				if (idx != -1) 
					newPairs.add(new Pair((IDataSourceProducer)xModel.getElementAt(idx),null));
			} else {
				int idx = findInComboBox(xModel,prod_pair.getX());
				int idx2 = findInComboBox(yModel,prod_pair.getY());
				if (idx != -1 && idx2 != -1)
					newPairs.add(new Pair((IDataSourceProducer)xModel.getElementAt(idx),(IDataSourceProducer)yModel.getElementAt(idx2)));
			}
		}
		functions = newPairs;
		lmodel.clear();
		for (Pair prod_pair : newPairs) {
			if (prod_pair.getY() == null)
				lmodel.addElement(prod_pair.getX() + " [(x,y) series from one source]");
			else
				lmodel.addElement(prod_pair.getX() + " -> " + prod_pair.getY());
		}		
		downButton.setEnabled(functions.size() >= 2);
		upButton.setEnabled(functions.size() >= 2);
		removeButton.setEnabled(functions.size() != 0);
		
		validate();
		setWidgetDisabled();
		
		if (config.isMultiLayerChart()) {
			for (int i = 1;i < child_panel.getComponentCount();i += 2) 
				((AbstractChartDialog)child_panel.getComponent(i)).reloadDataSources();
		}
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
		if (chartDialogParent != null)
			childStatusChanged();
	}
	
	//------------------------------------------------------------------------------
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}

	//-------------------------------------------------------------------------------
	/** This method haldles all released mouse events of the panel. It is public 
	 *  because of implementation side effect. Do not call or override.
	 * @param e event
	 */
	public void mouseReleased(MouseEvent e) {
		if (!SwingUtilities.isRightMouseButton(e))
			return;
		if (e.getComponent().isEnabled()) {
			downAction.setEnabled(xyList.getModel().getSize() > 1);
			upAction.setEnabled(xyList.getModel().getSize() > 1);
			removeAction.setEnabled(xyList.getModel().getSize() != 0);
			if (xyList.getModel().getSize() > 1) {
				downAction.putValue("X",e.getX());
				downAction.putValue("Y",e.getY());
				upAction.putValue("X",e.getX());
				upAction.putValue("Y",e.getY());
			}
			if (xyList.getModel().getSize() != 0) {
				removeAction.putValue("X",e.getX());
				removeAction.putValue("Y",e.getY());
			}
			functionsContextMenu.show(e.getComponent(),e.getX(),e.getY());
		}
	}

 	//-------------------------------------------------------------------------------
 	/** This method handles all ActionEvent-s of the panel. It is public because of
 	 *  implementation side effect. Do not call or override.
 	 * @param event event
 	 */
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if (cmd.equals("DOWN")) {
			move(1);
		} else if (cmd.equals("UP")) {
			move(-1);
		} else if (cmd.equals("REMOVE")) {
			int[] selected = xyList.getSelectedIndices();
			while (selected.length != 0) {
				functions.remove(selected[0]);
				lmodel.remove(selected[0]);
				selected = xyList.getSelectedIndices();
			}
			updateAxesLabels();
			
			// disable the buttons (if need)
			if (functions.size() < 2) {
				downButton.setEnabled(false);
				upButton.setEnabled(false);
			}
			if (functions.size() == 0) {
				removeButton.setEnabled(false);
				displayButton.setEnabled(false);
				ChartDialogChangeCenter.fireSaveDisabled(this);
				if (chartDialogParent != null) childStatusChanged();
			}
		}
	}
	
	//-----------------------------------------------------------------------------
	/** Moves the selected elements in the selected functions list.
	 * @param offset the direction of the move (possible values: -1,1)
	 */
	private void move(int offset) {
		int[] selected = xyList.getSelectedIndices();
		
		List<int[]> intervals = new ArrayList<int[]>();
		int start = selected[0], end = -1, previous = selected[0] - 1;

		for (int i=0;i<selected.length;++i) {
				if (selected[i] == previous + 1) previous = selected[i];
				else {
					end = previous;
					int[] intv = { start, end };
					intervals.add(intv);
					end = -1;
					start = previous = selected[i];
				}
		}
		intervals.add(new int[] { start, selected[selected.length-1] });
		
		xyList.clearSelection();
		for (int[] intv : intervals) {
			int to = intv[0] + offset;
			if (0 <= intv[0] && 0 <= to && intv[1] + offset < lmodel.size()) {
				moveInterval(intv[0],intv[1],to);
				xyList.getSelectionModel().addSelectionInterval(intv[0] + offset,intv[1] + offset);
			} else 
				xyList.getSelectionModel().addSelectionInterval(intv[0],intv[1]);
		}
		updateAxesLabels();
	}
	
	//-------------------------------------------------------------------------------
	/** Moves the elements in the selected functions list. The indices of the moved
	 *  elements are in the interval [<code>start</code>,<code>end</code>]. 
	 * @param to the new index of the first element
	 */
	private void moveInterval(int start, int end, int to) {
		int temp = to;
		String[] path = new String[end - start + 1];
		Pair[] dsps = new Pair[end - start + 1];
		for (int i = start;i <= end; ++i) {
			path[i - start] = (String)lmodel.get(i);
			dsps[i - start] = functions.get(i);
		}
		lmodel.removeRange(start,end);
		functions.removeAll(Arrays.asList(dsps));
		for (int i = 0;i < path.length;++i) {
			lmodel.add(temp,path[i]);
			functions.add(temp++,dsps[i]);
		}
	}
}  //  @jve:decl-index=0:visual-constraint="54,17"