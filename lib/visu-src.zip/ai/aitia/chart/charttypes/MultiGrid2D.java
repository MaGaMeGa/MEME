package ai.aitia.chart.charttypes;

import java.awt.Container;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.jfree.chart.JFreeChart;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.MultiGrid2DDialog;
import ai.aitia.chart.ds.Grid2DDatasetProducer;
import ai.aitia.chart.ds.IGrid2DDatasetProducer;
import ai.aitia.chart.emulator.ProducerEmulator;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLLoadingException;
import ai.aitia.chart.util.XMLLoadingException.TemplateLoadingException;
import ai.aitia.chart.view.ui.AutomaticFigureRenderer;
import ai.aitia.visu.VisualisationException;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDataProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.view.ChartFactory;
import ai.aitia.visu.view.CustomSaveableChartPanel;
import ai.aitia.visu.view.meta.Appearance;
import ai.aitia.visu.view.meta.CustomAppearance;
import ai.aitia.visu.view.meta.MultiGrid2DMetadata;
import ai.aitia.visu.view.ui.ColorMap;
import ai.aitia.visu.view.ui.ColorMapFigureRenderer;
import ai.aitia.visu.view.ui.IFigureRenderer;

public class MultiGrid2D extends AbstractChart {

	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings({ "unchecked", "cast" })
	@Override
	public Container createChart(ChartConfig config) throws DataSourceException, VisualisationException {
		if (config.getChartProperties() instanceof List) { // List<Properties>
			
			List<Properties> properties = (List<Properties>) config.getChartProperties();
			
			Properties common = properties.get(0);
			
	 		MultiGrid2DMetadata meta = new MultiGrid2DMetadata();
			meta.setTitle(common.getProperty(ChartConstants.TITLE));
			meta.setSubtitle(common.getProperty(ChartConstants.SUBTITLE));
			meta.setRowLabel(common.getProperty(ChartConstants.ROW_LABEL));
			meta.setColumnLabel(common.getProperty(ChartConstants.COLUMN_LABEL));

			String templateName = common.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			boolean needDefault = true;
			if (templateName != null && !"".equals(templateName)) {
				Element template = templates.get(templateName);
				if (template != null) {
					try {
						CustomAppearance appearance = createCustomAppearance(template);
						meta.setCustomAppearance(appearance);
						needDefault = false;
					} catch (TemplateLoadingException e) {
						throw new VisualisationException(e);
					}
				}
			}
			if (needDefault) {
				int env = Appearance.BASIC_APP;
				if (common.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP))
					env = Appearance.NORMAL_APP;
				meta.setEnvironmentAppearance(env);
			}
			
			Grid2DDatasetProducer[] datasetProducers = new Grid2DDatasetProducer[properties.size() - 1];
			List<IFigureRenderer> renderers = new ArrayList<IFigureRenderer>(properties.size() - 1);
			
			List<List<IDataProducer>> producers = new ArrayList<List<IDataProducer>>();
			for (int i = 1;i < properties.size();++i) {
				List<IDataProducer> pros = new ArrayList<IDataProducer>(5);
				IDataProducer cp = null, xp = null, yp = null;
				IValueProducer wp = null, hp = null;
				IGrid2DDatasetProducer dp = null;
				Properties prop = properties.get(i);
				
				// renderer
				String colormapStr = prop.getProperty(ChartConstants.COLORMAP,"");
				if (colormapStr != null && !"".equals(colormapStr)) {
					ColorMap colormap = Utilities.createColorMapFromString(colormapStr);
					float globalAlpha = Float.parseFloat(prop.getProperty(ChartConstants.GLOBAL_ALPHA,"-1"));
					renderers.add(new ColorMapFigureRenderer(colormap,globalAlpha));
				} else {
					String rendererStr = prop.getProperty(ChartConstants.SHAPE_RENDERER);
					try {
						renderers.add(Utilities.createShapeRendererFromString(rendererStr));
					} catch (Exception e) {
						renderers.add(new AutomaticFigureRenderer());
					}
				}
				
				// dataset
				int[] sources = Utilities.splitDatasourceAroundCommas(prop.getProperty(ChartConstants.DATASOURCE));
				int width = -2, height = -2;
				boolean user_defined_width = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_WIDTH));
				if (user_defined_width) {
					String str_width = prop.getProperty(ChartConstants.WIDTH);
					width = str_width.equals("") ? -1 : Integer.parseInt(str_width);
				} else {
					int key = Integer.parseInt(prop.getProperty(ChartConstants.WIDTH));
					IDataSourceProducer wdsp = config.getDataSource(key);
					IDataProducer idp = wdsp.createDataProducer(config.getDataSourceType(key),null);
					if (idp instanceof IValueProducer) // wdsp supports IValueProducer
						wp = (IValueProducer) idp;
					else { // wdsp supports only ISeriesProducer
						List<IDataProducer> p = new ArrayList<IDataProducer>();
						p.add(idp);
						wp = (IValueProducer) ProducerEmulator.createProducer(p,IValueProducer.class);
					}
					pros.add(wp);
				}
				boolean user_defined_height = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
				if (user_defined_height) {
					String str_height = prop.getProperty(ChartConstants.HEIGHT);
					height = str_height.equals("") ? -1 : Integer.parseInt(str_height);
				} else {
					int key = Integer.parseInt(prop.getProperty(ChartConstants.HEIGHT));
					IDataSourceProducer hdsp = config.getDataSource(key);
					IDataProducer idp = hdsp.createDataProducer(config.getDataSourceType(key),null);
					if (idp instanceof IValueProducer) // hdsp supports IValueProducer
						hp = (IValueProducer) idp;
					else { // hdsp supports only ISeriesProducer
						List<IDataProducer> p = new ArrayList<IDataProducer>();
						p.add(idp);
						hp = (IValueProducer) ProducerEmulator.createProducer(p,IValueProducer.class);
					}
					pros.add(hp);
				}
				List<Object> params = new ArrayList<Object>();
				if (sources.length == 1) {
					if (config.getDataSourceType(sources[0]).equals(IGrid2DDatasetProducer.class)) { // datasource type is IGrid2DDatasetProducer
						IDataSourceProducer ddsp = config.getDataSource(sources[0]);
						dp = (IGrid2DDatasetProducer) ddsp.createDataProducer(config.getDataSourceType(sources[0]),null);
						pros.add(dp);
						datasetProducers[i - 1] = new Grid2DDatasetProducer(dp);
					} else {
						IDataSourceProducer cdsp = config.getDataSource(sources[0]);
						boolean row_order = Boolean.parseBoolean(prop.getProperty(ChartConstants.ROW_ORDER));
						cp = cdsp.createDataProducer(config.getDataSourceType(sources[0]),null); // values producer
						if (cp instanceof ISeriesProducer)
							params.add(cp); 
						else {
							List<IDataProducer> p = new ArrayList<IDataProducer>(1);
							p.add(cp);
							cp = (ISeriesProducer) ProducerEmulator.createProducer(p,ISeriesProducer.class);
							params.add(cp);
						}
						pros.add(cp);
						if (user_defined_width)
							params.add(new Integer(width)); // fix width
						else
							params.add(wp); // width value producer
						if (user_defined_height)
							params.add(new Integer(height)); // fix height
						else
							params.add(hp); // height value producer
						datasetProducers[i - 1] = new Grid2DDatasetProducer(params,row_order);
					}
				} else {
					IDataSourceProducer xdsp = config.getDataSource(sources[0]);
					xp = xdsp.createDataProducer(config.getDataSourceType(sources[0]),null); // column indices producer
					if (xp instanceof ISeriesProducer)
						params.add(xp);
					else {
						List<IDataProducer> p = new ArrayList<IDataProducer>(1);
						p.add(xp);
						xp = (ISeriesProducer) ProducerEmulator.createProducer(p,ISeriesProducer.class);
						params.add(xp);
					}
					pros.add(xp);
					IDataSourceProducer ydsp = config.getDataSource(sources[1]);
					yp = ydsp.createDataProducer(config.getDataSourceType(sources[1]),null); // row indices producer
					if (yp instanceof ISeriesProducer)
						params.add(yp);
					else {
						List<IDataProducer> p = new ArrayList<IDataProducer>(1);
						p.add(yp);
						yp = (ISeriesProducer)ProducerEmulator.createProducer(p,ISeriesProducer.class);
						params.add(yp);
					}
					pros.add(yp);
					IDataSourceProducer cdsp = config.getDataSource(sources[2]);
					cp = cdsp.createDataProducer(config.getDataSourceType(sources[2]),null); // values producer
					if (cp instanceof ISeriesProducer)
						params.add(cp);
					else {
						List<IDataProducer> p = new ArrayList<IDataProducer>(1);
						p.add(cp);
						cp = (ISeriesProducer)ProducerEmulator.createProducer(p,ISeriesProducer.class);
						params.add(cp);
					}
					pros.add(cp);
					if (user_defined_width)
						params.add(new Integer(width)); // fix width
					else
						params.add(wp); // width value producer
					if (user_defined_height)
						params.add(new Integer(height)); // fix height
					else
						params.add(hp); // height value producer
					datasetProducers[i - 1] = new Grid2DDatasetProducer(params);
				}
				producers.add(pros);
			}
			
			meta.addFigureRenderers(renderers);
			
			JFreeChart chart = null;
		
			if (config.isFireInitialEvent()) {
				for (int i = 0; i < datasetProducers.length;++i) {
					for (IDataProducer p : producers.get(i))
						datasetProducers[i].dataChanged(new DataChangeEvent(p));
				}
			}
			
			chart = ChartFactory.createMultiGrid2DChart(datasetProducers,meta);
			CustomSaveableChartPanel panel = new CustomSaveableChartPanel(chart);
			
			if (meta.getCustomAppearance() != null && meta.getCustomAppearance().getDimension() != null)
				panel.setPreferredSize(meta.getCustomAppearance().getDimension());
			
			return panel;		
		}	
		return null;
	}

	//----------------------------------------------------------------------------------------------------
	@Override
	public Container createDialog(ChartConfig config, ChartConfigCollection collection) {
		return new MultiGrid2DDialog(config,collection);
	}

	//----------------------------------------------------------------------------------------------------
	@Override public String getID() { return ChartConstants.MULTIGRID2D; }
	@Override public String toString() { return ChartConstants.MULTIGRID2D_NAME; }

	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> getDataSourceIDs(ChartConfig config) {
		List<Integer> result = new ArrayList<Integer>();
		if (config.getChartProperties() instanceof List) {
			List<Properties> props = (List<Properties>) config.getChartProperties();
			for (int i = 1;i < props.size();++i) {
				int[] ds = Utilities.splitDatasourceAroundCommas(props.get(i).getProperty(ChartConstants.DATASOURCE));
				for (int j = 0;j < ds.length;++j) 
					result.add(ds[j]);
				boolean user_defined_width = Boolean.parseBoolean(props.get(i).getProperty(ChartConstants.USER_DEFINED_WIDTH));
				if (!user_defined_width) {
					int candidate = Integer.parseInt(props.get(i).getProperty(ChartConstants.WIDTH));
					result.add(candidate);
				}
				boolean user_defined_height = Boolean.parseBoolean(props.get(i).getProperty(ChartConstants.USER_DEFINED_HEIGHT));
				if (!user_defined_height) {
					int candidate = Integer.parseInt(props.get(i).getProperty(ChartConstants.HEIGHT));
					result.add(candidate);
				}
			}
		}
		return result;
	}

	//----------------------------------------------------------------------------------------------------
	@Override
	public String getDescription() {
		return "A composite 2D grid is a visualisation of one or more two-dimensional grids or matrices. Each" +
			   " grid or matrix appears on a different layer and each cell value is represented with a color or a figure.";
	}

	//----------------------------------------------------------------------------------------------------
	@Override
	protected void loadChartProperties(ChartConfig config, Node node) throws XMLLoadingException {
		List<Properties> props = new ArrayList<Properties>();
		props.add(Utilities.readProperties(node)); // common properties
		NodeList nodes = ((Element)node).getElementsByTagName(ChartConstants.GRID_LAYERS);
		if (nodes == null || nodes.getLength() == 0)
			throw new XMLLoadingException("Invalid XML-file, missing tag: " + ChartConstants.GRID_LAYERS);
		Element gridLayersElement = (Element) nodes.item(0);
		nodes = gridLayersElement.getElementsByTagName(ChartConstants.GRID_LAYER);
		if (nodes == null || nodes.getLength() == 0)
			throw new XMLLoadingException("Invalid XML-file, missing tag: " + ChartConstants.GRID_LAYER);
		for (int i = 0;i < nodes.getLength();++i)
			props.add(Utilities.readProperties(nodes.item(i)));
		config.setChartProperties(getID(),props);
	}

	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	@Override
	protected void saveChartProperties(ChartConfig config, Node node) {
		if (config.getChartProperties() instanceof List) { // List<Properties>
			List<Properties> props = (List<Properties>) config.getChartProperties();
			Utilities.writeProperties(node,props.get(0)); // common properties;
			Document document = node.getOwnerDocument();
			
			Element gridLayersElement = document.createElement(ChartConstants.GRID_LAYERS);
			for (int i = 1; i < props.size();++i) {
				Element gridLayer = document.createElement(ChartConstants.GRID_LAYER);
				Utilities.writeProperties(gridLayer,props.get(i)); // properties of the i-th layer
				gridLayersElement.appendChild(gridLayer);
			}
			node.appendChild(gridLayersElement);
		}
	}
}