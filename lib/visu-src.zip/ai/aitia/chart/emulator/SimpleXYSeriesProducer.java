/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.emulator;

import java.util.ArrayList;
import java.util.List;

import ai.aitia.visu.ds.AbstractDataProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.ds.IXYSeriesProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.event.IDataChangeListener;
import org.jfree.data.xy.XYSeries;

/** Simple implementation of the IXYSeriesProducer interface. The 
 *  {@link ProducerEmulator#createProducer(List,Class) ProducerEmulator.createProducer()}
 *   method use this type to emulate IXYSeriesProducer from two ISeriesProducer-s.
 */
public class SimpleXYSeriesProducer extends AbstractDataProducer implements
		IXYSeriesProducer, IDataChangeListener {

	/** Name of the producer. */
	private String name;
	
	/** Time of the last update. */
	private long time;
	
	/** The object that this producer produces. */
	private XYSeries data = null;
	
	// for emulation
	
	/** Value producer for emulation. */
	private IValueProducer xvp = null;
	
	/** Value producer for emulation. */
	private IValueProducer yvp = null;
	
	/** Series producer for emulation. */
	private ISeriesProducer xsp = null;
	
	/** Series producer for emulation. */
	private ISeriesProducer ysp = null;
	
	/** The current produced values by <code>xsp</code> or <code>xvp</code>.
	 */
	private List<Double> xs = null;

	/** The current produced values by <code>ysp</code> or <code>yvp</code>.
	 */
	private List<Double> ys = null;
	
	//===============================================================================
	// methods
	
	/** Constructor.
	 * @param name name of the producer
	 * @param xs array of x values
	 * @param ys array of y values
	 */
	public SimpleXYSeriesProducer(String name, double[] xs, double[] ys) {
		this.time = System.currentTimeMillis();
		this.name = name;
		data = new XYSeries(name);
		for (int i=0;i<Math.min(xs.length,ys.length);++i) data.add(xs[i],ys[i]);
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor. It forms pairs from successive numbers. If the size of
	 *  <code>xys</code> odd, the it discards the last element.
	 * @param name name of the producer
	 * @param xys array of x and y values
	 */
	public SimpleXYSeriesProducer(String name, double[] xys) {
		// forms pairs from the successive numbers (if the size of xys odd, then we 
		// discard the last element
		this.time = System.currentTimeMillis();
		this.name = name;
		data = new XYSeries(name);
		int half = xys.length/2;
		for (int i=0;i<half*2;i+=2) data.add(xys[i],xys[i+1]);
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor.
	 * @param xsp series producr for x values
	 * @param ysp series producer for y values
	 */
	public SimpleXYSeriesProducer(ISeriesProducer xsp, ISeriesProducer ysp) {
		this.time = System.currentTimeMillis();
		this.xsp = xsp;
		this.ysp = ysp;
		this.name = "(" + this.xsp.getName() + "," + this.ysp.getName() + ")";
	}
	
	//-------------------------------------------------------------------------------
	/** Constructor.
	 * @param xvp value producer for x values
	 * @param yvp value producer for y values
	 */
	public SimpleXYSeriesProducer(IValueProducer xvp, IValueProducer yvp) {
		this.time = System.currentTimeMillis();
		this.xvp = xvp;
		this.yvp = yvp;
		this.name = "(" + this.xvp.getName() + "," + this.yvp.getName() + ")";
		this.data = new XYSeries(this.name);
		this.data.add(xvp.produceValue(), yvp.produceValue());
	}
		
	//-------------------------------------------------------------------------------
	/** Produces and returns the series of the (x,y) pairs.
	 * @return series of the (x,y) pairs
	 */
	public XYSeries produceSeries() {
		if (data == null) {
			if (xs == null) xs = xsp.produceSeries();
			if (ys == null) ys = ysp.produceSeries();
			data = new XYSeries(name);
			for (int i=0;i<Math.min(xs.size(),ys.size());++i) data.add(xs.get(i),ys.get(i));
		}
		return data;
	}
	
	//-------------------------------------------------------------------------------
	/** Adds <code>this</code> as listener to the series or value producers. */
	public void registrateListeners() {
		if (xsp != null) xsp.addDataChangeListener(this);
		if (ysp != null) ysp.addDataChangeListener(this);
		if (xvp != null) xvp.addDataChangeListener(this);
		if (yvp != null) yvp.addDataChangeListener(this);
	}

	//-------------------------------------------------------------------------------
	/** Returns the name of the producer.
	 * @return name of the producer
	 */
	public String getName() {
		return name;
	}
	
	//-------------------------------------------------------------------------------
	/** Changes the name of the data source. The new name will be the name of the
	 *  second components. This method can use only with producers.
	 */
	public void changeToShortNames() {
		if (xsp != null && ysp != null)
			this.name = ysp.getName();
		else if (xvp != null && yvp != null)
			this.name = yvp.getName();
		else
			throw new IllegalStateException();
	}

	//-------------------------------------------------------------------------------
	/** Returns the time of the last update.
	 * @return time of the last update
	 */
	public long getTime() {
		return time;
	}
	
	//-------------------------------------------------------------------------------
	/** In the case of series producers this method indicates that one (or both)
	 *  of the series producers has updated. In the case of value producers it
	 *  it produces the new value and if it has a new pair, it adds to the (x,y)
	 *  series. */
	public void dataChanged(DataChangeEvent e) {
		Object o = e.getSource();
		if (o instanceof ISeriesProducer) {
			ISeriesProducer source = (ISeriesProducer)o;
			if (source.equals(xsp)) xs = null;
			if (source.equals(ysp)) ys = null;
			data = null;
		} else if (o instanceof IValueProducer) {
			IValueProducer source = (IValueProducer)o;
			if (source.equals(xvp)) {
				xs = new ArrayList<Double>(1);
				xs.add(new Double(source.produceValue()));
			} else if (source.equals(yvp)) {
				ys = new ArrayList<Double>(1);
				ys.add(new Double(source.produceValue()));
			}
			if (xs != null && ys != null) {
				data.add(xs.get(0),ys.get(0));
				xs = null;
				ys = null;
			}
		}
		fireDataChanged();
	}
}
