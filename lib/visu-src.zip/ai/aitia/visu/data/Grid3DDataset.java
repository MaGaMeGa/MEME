package ai.aitia.visu.data;

import java.util.Collection;

import org.jfree.data.general.Dataset;

public interface Grid3DDataset extends Dataset {
	
	public int getWidth();	
	public int getHeight();
	
	public double getValue(int x, int y, int i);
	public double[][][] getValues();
	public Collection<double[]> getValuesCollection();
	public double getMaximum(int dim);
}