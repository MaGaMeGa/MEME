package ai.aitia.chart.charttypes.dialogs.assisttypes;

import org.w3c.dom.Node;

import ai.aitia.chart.DataSourceProducerAdapter;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.visu.ds.IDataProducer;

/** This class provides the 'All' item of the data source comboboxes on the following
 *  GUI components:<ul>
 *	<li> {@link ai.aitia.chart.charttypes.dialogs.BarChartDialog BarChartDialog} </li>
 *	<li> {@link ai.aitia.chart.charttypes.dialogs.ScatterPlotDialog ScatterPlotDialog} </li>
 *	<li> {@link ai.aitia.chart.charttypes.dialogs.SequenceDialog SequenceDialog} </li>
 *	<li> {@link ai.aitia.chart.charttypes.dialogs.TimeSeriesDialog TimeSeriesDialog} </li>
 *	<li> {@link ai.aitia.chart.charttypes.dialogs.RealTimeSeriesDialog RealTimeSeriesDialog} </li>
 *	<li> {@link ai.aitia.chart.charttypes.dialogs.XYLineDialog XYLineDialog} </li>
 *  </ul>
 */
public class AllDummyDataSourceProducer extends DataSourceProducerAdapter
		implements IDataSourceProducer {
	
	//----------------------------------------------------------------------------------
	@Override
	public IDataProducer createDataProducer(Class intf, IDataSourceProducer grp) {
		throw new IllegalStateException("createDataProducer");
	}

	//----------------------------------------------------------------------------------
	@Override
	public void save(Node node) {
		throw new IllegalStateException("save");
	}

	//----------------------------------------------------------------------------------
	@Override
	public String toString() {
		return "All";
	}
}
