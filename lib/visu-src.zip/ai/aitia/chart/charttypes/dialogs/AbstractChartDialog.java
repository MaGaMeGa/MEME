/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Window;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.swing.BoxLayout;
import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.components.ChildAdditionalPanel;
import ai.aitia.chart.dialogs.CCCollectionDialog;
import ai.aitia.chart.dialogs.ChartDialogChangeListener;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLFileFilter;
import ai.aitia.fobwizard.FOBWizard;
import ai.aitia.fobwizard.IDataSourceEditorGUI;
import ai.aitia.visu.globalhandlers.GlobalHandlers;
import ai.aitia.visu.utils.Utils;

/** Common abstract superclass of the GUI-components of the chart types. */
public abstract class AbstractChartDialog extends JPanel implements ChartDialogChangeListener {

	protected JTextField titleField = null;
	protected JButton saveButton = null;
	protected JButton displayButton = null;
	protected JButton composeButton = null;
	protected JButton editorButton = null;
	
	//===============================================================================
	// additional members

	/** Chart configuration object. */
	protected ChartConfig config = null;
	
	/** The collection that contains the configuration object <code>config</code>. It
	 *  is <code>null</code> if the configuration object is not part of any collection.  
	 */
	protected ChartConfigCollection cc_collection = null;
	
	/** Settings object. The component stores the settings of the chart in this object,
	 *  and sometimes updates the member {@link ai.aitia.chart.ChartConfig#chartProperties
	 *  chartProperties} of the configuration object with this object.
	 */
	protected Properties properties = null;

	//===============================================================================
	// for multilayer charts
	protected AbstractChartDialog chartDialogParent = null;
	protected ChildAdditionalPanel cap = null;
	protected JPanel child_panel = null;
	protected JScrollPane scr = null;

	//===============================================================================
	// methods
	
	/** Constructor.
	 * @param config chart configuration object
	 * @param cc_collection the collection that contains the configuration object <code>
	 * config</code> (<code>null</code> is permitted)
	 */
	public AbstractChartDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super();
		this.config = config;
		this.cc_collection = cc_collection;
		if (this.cc_collection == null || this.cc_collection.getSingleFlag()) ChartDialogChangeCenter.addChartDialogChangeListener(this);
		properties = new Properties();
	}
	
	//-------------------------------------------------------------------------------
	/** It returns whether the dialog's settings is ready for display or save or not. */
	public abstract boolean isUpdateable();
	
	//-------------------------------------------------------------------------------
	/** This function updates the chart configuration from the <code>properties</code>
	 *  and the selected data sources.
 	 */
	public abstract void updateChartConfig();

	//-------------------------------------------------------------------------------
	/** Disable the widgets when necessary because of the empty comboboxes. */
	protected abstract void setWidgetDisabled();

	//-------------------------------------------------------------------------------
	/** This function sets the widgets from the chart configuration object. */
	protected abstract void setSettingsFromConfig();
	
	//-------------------------------------------------------------------------------
	/** The GUI of charts that can be part of a multilayer chart must override this method.
	 *  In these GUIs this method removes the buttons and disables appropriate parts
	 *  of the details panel.
	 * @param realTimeSeriesParent whether the type of the parent chart is 'time series
	 *  with real time' or not. 
	 */
	public void setChildMode(boolean realTimeSeriesParent) {}
	
	//-------------------------------------------------------------------------------
	/** The GUI of charts that can have childs must override this method. In these
	 * GUIs this method sets invisible/visible the 'Compose' button.
	 * @param invisibled whether the 'Compose' button is invisible or not.
	 */
	public void setComposeButton(boolean invisibled) {}
	
	//-------------------------------------------------------------------------------
	/** This method calls the other {@link #removeChild(AbstractChartDialog)
	 *  removeChild()} with <code>this</code> as parameter on his parent (if any).
	 */
	public void removeChild() {
		if (chartDialogParent != null) {
			chartDialogParent.removeChild(this);
		}
	}
	
	//-------------------------------------------------------------------------------
	/** The GUI of charts that can have childs must override this method. In these
	 *  GUIs this method removes child <code>who</code> from the GUI and its
	 *  configuration object.
	 * @param who the removeable GUI-component
	 */
	protected void removeChild(AbstractChartDialog who) {}
	
	//-------------------------------------------------------------------------------
	/** This method calls the other {@link #setSelectedAxis(AbstractChartDialog)
	 *  setSelectedAxis()} with <code>this</code> as parameter on his parent (if any).
	 *
	 */
	public void setSelectedAxis() {
		if (chartDialogParent != null) {
			chartDialogParent.setSelectedAxis(this);
		}
	}
	
	//-------------------------------------------------------------------------------
	/** The GUI of charts that can have childs must override this method. In these
	 *  GUIs this method unselects all '2nd vertical axis' checkbox (except on <code>
	 *  who</code>.
	 * @param who the GUI-component whose checkbox remains selected
	 */ 
	protected void setSelectedAxis(AbstractChartDialog who) {}
	
	//-------------------------------------------------------------------------------
	/** Sets <code>parent</code> as parent component of <code>this</code>.
	 * @param parent parent of <code>this</code>
	 */
	public void setParent(AbstractChartDialog parent) {
		chartDialogParent = parent;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the title of the chart.
	 * @return title of the chart
	 */
	public String getTitle() {
		return titleField.getText();
	}
	
	//-------------------------------------------------------------------------------
	/** Enables/disables the save button of the chart.
	 * @param enabled whether the 'Save' button is enabled or not
	 */
	public void setSaveButtonEnabled(boolean enabled) {
		saveButton.setEnabled(enabled);
	}
	
	//-------------------------------------------------------------------------------
	/** Changes the label of the <code>displayButton</code>. <code>mnemonic</code>
	 *  must be other than M or C.
	 * @param newLabel new label of the button
	 * @param mnemonic new mnemonic of the button 
	 */
	public void changeDisplayButtonLabel(String newLabel, int mnemonic) {
		displayButton.setText(newLabel);
		if (mnemonic != KeyEvent.VK_M || mnemonic != KeyEvent.VK_C) {
			displayButton.setMnemonic(mnemonic);
		}
	}
	
	//-------------------------------------------------------------------------------
	/** Changes the label of the <code>saveButton</code>. <code>mnemonic</code> must
	 *  be other than M or C.
	 * @param newLabel new label of the button
	 * @param mnemonic nem mnemonic of the button 
	 */
	public void changeSaveButtonLabel(String newLabel, int mnemonic) {
		saveButton.setText(newLabel);
		if (mnemonic != KeyEvent.VK_M || mnemonic != KeyEvent.VK_C) {
			saveButton.setMnemonic(mnemonic);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void setEditorButtonVisible(boolean visible) { 
		if (editorButton != null)
			editorButton.setVisible(visible);
	}
	
	//-------------------------------------------------------------------------------
	/** This function displays chart in a new window. In wizard mode it displays only
	 *  an illustration chart (see {@link #displayPreview() displayPreview()}, because
	 *  the datasources for the real chart must be generated after the wizard terminated.
	 *  In normal mode it catches and passes any Throwable to the global exception
	 *  handler.
	 */
	protected void displayChart() {
		updateChartConfig();
		if (cc_collection != null && cc_collection.getWizardMode()) {
			try {
				displayPreview();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(this,"Preview illustration is unavailable","Error",JOptionPane.ERROR_MESSAGE,null);
			}
		} else {
			try {
				Container panel = AbstractChart.display(config);
				JFrame frame = new JFrame(AbstractChart.find(config.getChartType()).toString());
				final JScrollPane sp = new JScrollPane(panel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				sp.setBorder(null);
				frame.setContentPane(sp);
				frame.pack();
				Dimension oldD = frame.getPreferredSize();
				frame.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
						            				 oldD.height + sp.getHorizontalScrollBar().getHeight()));
				sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
				sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				oldD = frame.getPreferredSize();
				final Dimension newD = Utils.getPreferredSize(frame);
				if (!oldD.equals(newD)) 
					frame.setPreferredSize(newD);
				frame.pack();    	
				Component parent = this.getRootPane().getParent();
				while (!(parent instanceof JFrame))
					parent = parent.getParent();
				if (parent != null)
					frame.setIconImage(((JFrame)parent).getIconImage());
				frame.pack();
				if (cc_collection != null && cc_collection.getCloseStrategy()) 
					cc_collection.addDisplay(frame);
				frame.setVisible(true);
			} catch (Throwable t) {
				ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
			}
		}
	}
	
	//-------------------------------------------------------------------------------
	/** This function displays an illustration chart. */
	protected abstract void displayPreview() throws Exception;
	
	//-------------------------------------------------------------------------------
	/** This function notifies the top parent that the component wants to hide. */
	protected void notifyForHide() {
		if (cc_collection != null && cc_collection.getCloseStrategy()) {
			for (JFrame f : cc_collection.getDisplays())
				f.dispose();
			cc_collection.getDisplays().clear();
		}
		// The following code worked with JFrames but crashed with JDialogs. Furthermore, it was   
		// inappropriate when the programmer wants to "close" a JPanel only and not the whole window.  
		// Component top_parent = getRootPane().getParent();
		// top_parent.dispatchEvent(new ComponentEvent(new Label("CANCEL"),ComponentEvent.COMPONENT_HIDDEN));

		// Possible arrangements:
		// <outer world> . CCCollectionDialog . JPanel . AbstractChartDialog
		// <outer world> . AbstractChart  (when CCCollectionDialog is not used)
		
		Component src = this;
		Container outerWorld = src.getParent();
		if (outerWorld instanceof CCCollectionDialog) {
			src = outerWorld;
			outerWorld = src.getParent();
		} else if (outerWorld.getParent() instanceof CCCollectionDialog) {
			src = outerWorld.getParent();
			outerWorld = src.getParent();
		} else if (outerWorld.getParent().getParent() instanceof CCCollectionDialog) {
			src = outerWorld.getParent().getParent();
			outerWorld = src.getParent();
			if (outerWorld instanceof JViewport)
				outerWorld = outerWorld.getParent().getParent();
		}

		if (outerWorld != null) {
			ComponentEvent e;
			if (outerWorld instanceof Window) 
				e = new WindowEvent((Window)outerWorld,WindowEvent.WINDOW_CLOSING);
			else if (outerWorld instanceof JLayeredPane) {
				outerWorld = ((JLayeredPane)outerWorld).getTopLevelAncestor();
				e = new WindowEvent((Window)outerWorld,WindowEvent.WINDOW_CLOSING);
			} else 
				e = new ComponentEvent(src,ComponentEvent.COMPONENT_HIDDEN);
			sendEventLater(outerWorld,e);
		}
		if (FOBWizard.hasValidDataSourceEditor())
			FOBWizard.getDataSourceEditor().shutdown();
		src.setVisible(false);
	}

	//-------------------------------------------------------------------------------
	/** Assistant method for {@link #notifyForHide() notifyForHide()}.
	 * @param target target of the event
	 * @param e event
	 */
	private static void sendEventLater(final java.awt.Container target, final java.awt.event.ComponentEvent e) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() { target.dispatchEvent(e); }
		});
	}
	
	//-------------------------------------------------------------------------------
	/** This function saves the collection into an XML file. In wizard mode,
	 *  the file name comes from the collection object (see 
	 *  {@link ai.aitia.chart.ChartConfigCollection#getModelFileName() getModelFileName()}
	 *  ). During the save, it catches and passes any Exception to the global exception
	 *  handler. After the save, the component closed. <p>
	 *  In normal mode, if the chart configuration object is not part of any collection
	 *  (in wizard mode this case is not permitted), the function creates one. 
	 */
	protected void saveCollection() {
		if (cc_collection != null && cc_collection.getWizardMode()) {
			File file = new File(cc_collection.getModelFileName());
			updateChartConfig();
			Component top_parent = getRootPane().getParent();
			try {
				cc_collection.save(file);
				Window window = new JDialog();
				window.setName("OK");
				top_parent.dispatchEvent(new ComponentEvent(window,ComponentEvent.COMPONENT_HIDDEN));
			} catch (Exception e) {
				ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),e);
				Window window = new JDialog();
				window.setName("CANCEL");
				top_parent.dispatchEvent(new ComponentEvent(window,ComponentEvent.COMPONENT_HIDDEN));
			}  finally {
//				Component top_parent = getRootPane().getParent();
//				top_parent.dispatchEvent(new ComponentEvent(new Label("OK"),ComponentEvent.COMPONENT_HIDDEN));
				if (FOBWizard.hasValidDataSourceEditor())
					FOBWizard.getDataSourceEditor().shutdown();
			} 
		} else {
			JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
			fc.setCurrentDirectory(GlobalHandlers.getLastDirectory());
			fc.setAcceptAllFileFilterUsed(false);
			fc.addChoosableFileFilter(new XMLFileFilter());
			int result = fc.showSaveDialog(getRootPane().getParent());
			if (result == JFileChooser.APPROVE_OPTION) {
				File selectedFile = fc.getSelectedFile();
				File file = Utilities.generateValidFile(selectedFile,"xml");
				GlobalHandlers.setLastDirectory(file);
				updateChartConfig();
				try {
					if (cc_collection == null) {
						cc_collection = new ChartConfigCollection(config.getDataSources(),true);
						cc_collection.addChartConfig(config);
					}
					cc_collection.save(file);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(getRootPane().getParent(),"Save failed.","Failure",JOptionPane.ERROR_MESSAGE,null);
				}
			}
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void openEditor() {
		if (cc_collection != null && cc_collection.getWizardMode() && FOBWizard.hasValidDataSourceEditor()) {
			int result = FOBWizard.getDataSourceEditor().showDialog();
			if (result == IDataSourceEditorGUI.DATASOURCE_LIST_CHANGED_OPTION) 
				ChartDialogChangeCenter.fireDataSourcesChanged();
		}
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that supports the 
	 *  the interface specified by <code>intfs</code>.
	 * @param intfs an interface type
	 * @return array of data sources
	 */
 	protected Object[] getParams(Class intfs) {
 		List<IDataSourceProducer> candidates = config.getDSPCollection().getList();
		List<IDataSourceProducer> accepted = new ArrayList<IDataSourceProducer>();
		Iterator<IDataSourceProducer> it = candidates.iterator();
		while (it.hasNext()) {
			IDataSourceProducer dsp = it.next();
			if (Utilities.canBe(dsp,intfs)) accepted.add(dsp);
		}
		return accepted.toArray();
 	}
	
	//-------------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that supports the 
	 *  at least one of the interfaces specified by <code>intfs</code>.
	 * @param intfs an array of interface types
	 * @return array of data sources
	 */
 	protected Object[] getParams(Class[] intfs) {
 		List<IDataSourceProducer> candidates = config.getDSPCollection().getList();
		List<IDataSourceProducer> accepted = new ArrayList<IDataSourceProducer>();
		Iterator<IDataSourceProducer> it = candidates.iterator();
		while (it.hasNext()) {
			IDataSourceProducer dsp = it.next();
			for (int i=0;i<intfs.length;++i) {
				if (Utilities.canBe(dsp,intfs[i])) {
					accepted.add(dsp);
					break;
				}
			}
		}
		return accepted.toArray();
 	}
 	
 	//-------------------------------------------------------------------------------
 	/** Returns the displayable names of the data sources that supports the interface
 	 *  specified by <code>intfs</code>, but does not support the interface specified
 	 *  by <code>uns_intfs</code>.
 	 * @param intfs an interface type
 	 * @param uns_intfs an interface type
 	 * @return array of data sources 
 	 */
 	protected Object[] getParams(Class intfs, Class uns_intfs) {
 		List<IDataSourceProducer> candidates = config.getDSPCollection().getList();
 		List<IDataSourceProducer> accepted = new ArrayList<IDataSourceProducer>();
 		for (IDataSourceProducer dsp : candidates) {
 			List<Class> dsp_list = dsp.getSupportedIntfs();
 			if (dsp_list.contains(intfs) && !dsp_list.contains(uns_intfs))
 				accepted.add(dsp);
 		}
 		return accepted.toArray();
 	}
	
	//-------------------------------------------------------------------------------
 	/** Add a new child chart to the current chart.
 	 * 
 	 * @param type type of the new child chart
 	 */
 	protected void addNewChild(String type) {
		ChartConfig newConfig = new ChartConfig(config.getDataSources());
		newConfig.setChartProperties(type,null);
		config.addNewChild(newConfig);
		boolean first_child = false;
		if (child_panel == null) {
			child_panel = new JPanel();
			child_panel.setLayout(new BoxLayout(child_panel,BoxLayout.Y_AXIS));
			first_child = true;
		}
		child_panel.add(new JSeparator(JSeparator.HORIZONTAL));
		Container c = AbstractChart.find(type).createDialog(newConfig,cc_collection);
		if (config.getChartType().equals(ChartConstants.REALTIMESERIES)) {
			((AbstractChartDialog)c).setChildMode(true);
		} else {
			((AbstractChartDialog)c).setChildMode(false);
		}
		((AbstractChartDialog)c).setParent(this);
		child_panel.add(c);
		if (first_child) {
			scr = new JScrollPane();
			scr.setViewportView(child_panel);
			this.setPreferredSize(new Dimension(619,484));
			add(scr,1);
			Utilities.repack(this);
		}
		Utilities.repack(scr);
		if (!isUpdateable()) {
			displayButton.setEnabled(false);
			ChartDialogChangeCenter.fireSaveDisabled(this);
		}
 	}
 	
	//-------------------------------------------------------------------------------
 	/** A child chart calls this method when its status changed (from displayable/saveable
 	 *  to non-displayable/non-saveable and vice versa.
 	 */
 	public void childStatusChanged() {
 		if (chartDialogParent == null) return;
 		if (chartDialogParent.isUpdateable()) {
 			chartDialogParent.displayButton.setEnabled(true);
 			ChartDialogChangeCenter.fireSaveEnabled(chartDialogParent);
 		} else {
 			chartDialogParent.displayButton.setEnabled(false);
 			ChartDialogChangeCenter.fireSaveDisabled(chartDialogParent);
 		}
 	}
 	
 	//-------------------------------------------------------------------------------
 	/** Replace standard data source with an advanced data source in <code>combobox
 	 *  </code>. If <code>combobox</code> is empty or doesn't contain data source
 	 *  objects, nothing happens
 	 * @param combobox the combobox that contains the replaceable data source
 	 */
 	protected void advanced(JComboBox combobox) {
 		if (combobox.getItemCount() == 0 ||
 			!(combobox.getItemAt(0) instanceof IDataSourceProducer)) return;
		IDataSourceProducer dsp = (IDataSourceProducer)combobox.getSelectedItem();
		IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(this.getRootPane().getParent());
		if (new_dsp != null) {
			int index = combobox.getSelectedIndex();
			combobox.removeItemAt(index);
			combobox.insertItemAt(new_dsp,index);
			combobox.setSelectedIndex(index);
		}
 	}
 	
 	//-------------------------------------------------------------------------------
 	// Override this method if the concrete dialog allows the custom appearance templates!
 	public void reloadAppearanceTemplates() {}
 	
 	//----------------------------------------------------------------------------------------------------
	// Override this method to update the data source comboboxes
 	public void reloadDataSources() {}
 	
 	//-------------------------------------------------------------------------------
 	protected Frame findActiveFrame() {
		Frame[] frames = JFrame.getFrames();
	    for (int i = 0; i < frames.length; i++) {
	    	if (frames[i].isActive()) 
	    		return frames[i];
	    }
	    return null;
	}
 	
 	//----------------------------------------------------------------------------------------------------
	protected int findInComboBox(final ComboBoxModel model, final Object object) {
		for (int i = 0;i < model.getSize();++i) {
			if (model.getElementAt(i).equals(object))
				return i;
		}
		return -1;
	}

 	//===============================================================================
 	
	//////////////////////////////////////////////////////////////////////////
	// Implementation of ChartDialogChangeListener                          //
	//////////////////////////////////////////////////////////////////////////
	
 	/** If <code>where</code> equals to <code>this</code> then sets the 'Save'
 	 *  button to enabled/disabled depends on the second parameter. Otherwise
 	 *  does nothing.
 	 * @param where the component whose status changed
 	 * @param enabled whether enables or disables the button
 	 */
	public void saveStatusChanged(AbstractChartDialog where, boolean enabled) {
		if (where.equals(this)) saveButton.setEnabled(enabled);
	}

	//-------------------------------------------------------------------------------
	/** It implements this method with empty body. */
	public void titleChanged(AbstractChartDialog where) {}
	
	//-------------------------------------------------------------------------------
	public void templateChanged() {
		reloadAppearanceTemplates();
	}
	
	//----------------------------------------------------------------------------------------------------
	public void dataSourcesChanged() {
		reloadDataSources();
	}
}