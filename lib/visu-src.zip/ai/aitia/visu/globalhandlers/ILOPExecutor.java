package ai.aitia.visu.globalhandlers;

import java.util.concurrent.Callable;

/** Interface for define handlers that execute the long operations. */
public interface ILOPExecutor {

	/** Executes the long operation <code>r</code> named <code>taskName</code>.
	 * @param taskName name of the long operation
	 * @param r task of the long operation
	 * @throws Exception
	 */
	public void execute(String taskName, Runnable r) throws Exception;
	
	//--------------------------------------------------------------------------------
	/** Executes the long operation <code>r</code> named <code>taskName</code>. The
	 *  long operation returns a result and may throw an Exception.
	 * @param taskName name of the long operation
	 * @param r task of the long operation
	 * @return result of the long operation
	 * @throws Exception
	 */
	public Object execute(String taskName, Callable<Object> r) throws Exception;
	
	//--------------------------------------------------------------------------------
	/** Executes a long operation creating a java.beans.Expression from the parameters.
	 * @param taskName name of the long operation
	 * @param target the owner of the method that contains the long operation
	 * @param methodName the name of the method that contains the long operation
	 * @param args the parameters of the method that conatins the long operation
	 * @return result of the long operation
	 * @throws Exception 
	 */
	public Object execute(String taskName, Object target, String methodName, Object... args) throws Exception;
	
	//--------------------------------------------------------------------------------
	/** Executes a the long operation <code>ex</code> named <code>taskName</code>.
	 * @param taskName name of the long operation
	 * @param ex task of the long operation
	 * @return result of the long operation
	 * @throws Exception
	 */
	public Object execute(String taskName, java.beans.Expression ex) throws Exception;
	
	//---------------------------------------------------------------------------------
	/** Returns whether the long operation is cancelled by the user. */
	public boolean isUserBreak();
	
	//---------------------------------------------------------------------------------
	/** Checks whether the long operation is cancelled by the user. 
	 * @throw UserBreakException if the operations is cancelled
	 */
	public void checkUserBreak() throws UserBreakException;
	
	//---------------------------------------------------------------------------------
	/** May be identical to <pre> checkUserBreak(); progress(current, -1); </pre> */
	public void progress(double current) throws UserBreakException;
	
	//---------------------------------------------------------------------------------
	public void progress(double current, double end);
	
	//----------------------------------------------------------------------------------------------------
	public void setAbortable(boolean abortable);
}
