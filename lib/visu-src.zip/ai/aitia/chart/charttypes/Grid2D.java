/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes;

import java.awt.Container;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.jfree.chart.JFreeChart;
import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.Grid2DDialog;
import ai.aitia.chart.ds.Grid2DDatasetProducer;
import ai.aitia.chart.ds.IGrid2DDatasetProducer;
import ai.aitia.chart.emulator.ProducerEmulator;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLLoadingException.TemplateLoadingException;
import ai.aitia.visu.VisualisationException;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDataProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.view.ChartFactory;
import ai.aitia.visu.view.CustomSaveableChartPanel;
import ai.aitia.visu.view.meta.Appearance;
import ai.aitia.visu.view.meta.CustomAppearance;
import ai.aitia.visu.view.meta.Grid2DMetadata;

/** The two-dimensional grid type. A 2D grid is a visualisation of a two-dimensional
 *  grid or matrix. It represents each different cell value with a color.
 */   
public class Grid2D extends AbstractChart {

	@SuppressWarnings("cast")
	@Override
	public Container createChart(ChartConfig config) throws DataSourceException, VisualisationException {
		
		if (config.getChartProperties() instanceof Properties) {
			
			Properties properties = (Properties)config.getChartProperties();
			
	 		Grid2DMetadata meta = new Grid2DMetadata();
			meta.setTitle(properties.getProperty(ChartConstants.TITLE));
			meta.setSubTitle(properties.getProperty(ChartConstants.SUBTITLE));
			meta.setRowLabel(properties.getProperty(ChartConstants.ROW_LABEL));
			meta.setColumnLabel(properties.getProperty(ChartConstants.COLUMN_LABEL));
			meta.setNoSelection(true);
			boolean tooltip = Boolean.parseBoolean(properties.getProperty(ChartConstants.TOOLTIP,"false"));
			meta.setGenerateTooltip(tooltip);
			boolean colorbar = Boolean.parseBoolean(properties.getProperty(ChartConstants.COLORBAR));
			meta.setColorBarVisible(colorbar);
			meta.setColorMap(Utilities.createColorMapFromString(properties.getProperty(ChartConstants.COLORMAP)));

			String templateName = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			boolean needDefault = true;
			if (templateName != null && !"".equals(templateName)) {
				Element template = templates.get(templateName);
				if (template != null) {
					try {
						CustomAppearance appearance = createCustomAppearance(template);
						meta.setCustomAppearance(appearance);
						needDefault = false;
					} catch (TemplateLoadingException e) {
						throw new VisualisationException(e);
					}
				}
			}
			if (needDefault) {
				int env = Appearance.BASIC_APP;
				if (properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP))
					env = Appearance.NORMAL_APP;
				meta.setEnvironmentAppearance(env);
			}
			
			Grid2DDatasetProducer g2ddp = null;
			IDataProducer cp = null, xp = null, yp = null;
			IValueProducer wp = null, hp = null;
			IGrid2DDatasetProducer dp = null;
			int[] sources = Utilities.splitDatasourceAroundCommas(properties.getProperty(ChartConstants.DATASOURCE));
			int width = -2, height = -2;
			boolean user_defined_width = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_WIDTH));
			if (user_defined_width) {
				String str_width = properties.getProperty(ChartConstants.WIDTH);
				width = str_width.equals("") ? -1 : Integer.parseInt(str_width);
			} else {
				int key = Integer.parseInt(properties.getProperty(ChartConstants.WIDTH));
				IDataSourceProducer wdsp = config.getDataSource(key);
				IDataProducer idp = wdsp.createDataProducer(config.getDataSourceType(key),null);
				if (idp instanceof IValueProducer) { // wdsp supports IValueProducer
					wp = (IValueProducer)idp;
				} else { // wdsp supports only ISeriesProducer
					List<IDataProducer> p = new ArrayList<IDataProducer>();
					p.add(idp);
					wp = (IValueProducer)ProducerEmulator.createProducer(p,IValueProducer.class);
				}
			}
			boolean user_defined_height = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
			if (user_defined_height) {
				String str_height = properties.getProperty(ChartConstants.HEIGHT);
				height = str_height.equals("") ? -1 : Integer.parseInt(str_height);
			} else {
				int key = Integer.parseInt(properties.getProperty(ChartConstants.HEIGHT));
				IDataSourceProducer hdsp = config.getDataSource(key);
				IDataProducer idp = hdsp.createDataProducer(config.getDataSourceType(key),null);
				if (idp instanceof IValueProducer) { // hdsp supports IValueProducer
					hp = (IValueProducer)idp;
				} else { // hdsp supports only ISeriesProducer
					List<IDataProducer> p = new ArrayList<IDataProducer>();
					p.add(idp);
					hp = (IValueProducer)ProducerEmulator.createProducer(p,IValueProducer.class);
				}
			}
			List<Object> params = new ArrayList<Object>();
			if (sources.length==1) {
				if (config.getDataSourceType(sources[0]).equals(IGrid2DDatasetProducer.class)) { // datasource type is IGrid2DDatasetProducer
					IDataSourceProducer ddsp = config.getDataSource(sources[0]);
					dp = (IGrid2DDatasetProducer)ddsp.createDataProducer(config.getDataSourceType(sources[0]),null);
					g2ddp = new Grid2DDatasetProducer(dp);
				} else {
					IDataSourceProducer cdsp = config.getDataSource(sources[0]);
					boolean row_order = Boolean.parseBoolean(properties.getProperty(ChartConstants.ROW_ORDER));
					cp = cdsp.createDataProducer(config.getDataSourceType(sources[0]),null); // color values producer
					if (cp instanceof ISeriesProducer) params.add(cp); 
					else {
						List<IDataProducer> p = new ArrayList<IDataProducer>(1);
						p.add(cp);
						cp = (ISeriesProducer) ProducerEmulator.createProducer(p,ISeriesProducer.class);
						params.add(cp);
					}
					if (user_defined_width) params.add(new Integer(width)); // fix width
					else params.add(wp); // width value producer
					if (user_defined_height) params.add(new Integer(height)); // fix height
					else params.add(hp); // height value producer
					g2ddp = new Grid2DDatasetProducer(params,row_order);
				}
			} else {
				IDataSourceProducer xdsp = config.getDataSource(sources[0]);
				xp = xdsp.createDataProducer(config.getDataSourceType(sources[0]),null); // column indices producer
				if (xp instanceof ISeriesProducer) params.add(xp);
				else {
					List<IDataProducer> p = new ArrayList<IDataProducer>(1);
					p.add(xp);
					xp = (ISeriesProducer)ProducerEmulator.createProducer(p,ISeriesProducer.class);
					params.add(xp);
				}
				IDataSourceProducer ydsp = config.getDataSource(sources[1]);
				yp = ydsp.createDataProducer(config.getDataSourceType(sources[1]),null); // row indices producer
				if (yp instanceof ISeriesProducer) params.add(yp);
				else {
					List<IDataProducer> p = new ArrayList<IDataProducer>(1);
					p.add(yp);
					yp = (ISeriesProducer)ProducerEmulator.createProducer(p,ISeriesProducer.class);
					params.add(yp);
				}
				IDataSourceProducer cdsp = config.getDataSource(sources[2]);
				cp = cdsp.createDataProducer(config.getDataSourceType(sources[2]),null); // color values producer
				if (cp instanceof ISeriesProducer) params.add(cp);
				else {
					List<IDataProducer> p = new ArrayList<IDataProducer>(1);
					p.add(cp);
					cp = (ISeriesProducer)ProducerEmulator.createProducer(p,ISeriesProducer.class);
					params.add(cp);
				}
				if (user_defined_width) params.add(new Integer(width)); // fix width
				else params.add(wp); // width value producer
				if (user_defined_height) params.add(new Integer(height)); // fix height
				else params.add(hp); // height value producer
				g2ddp = new Grid2DDatasetProducer(params);
			}
			
			JFreeChart chart = null;
		
			if (config.isFireInitialEvent()) {
				if (wp != null) g2ddp.dataChanged(new DataChangeEvent(wp));
				if (hp != null) g2ddp.dataChanged(new DataChangeEvent(hp));
				if (cp != null) g2ddp.dataChanged(new DataChangeEvent(cp));
				if (xp != null) g2ddp.dataChanged(new DataChangeEvent(xp));
				if (yp != null) g2ddp.dataChanged(new DataChangeEvent(yp));
				if (dp != null) g2ddp.dataChanged(new DataChangeEvent(dp));
			}
			chart = ChartFactory.createGrid2DChart(g2ddp,meta);
			CustomSaveableChartPanel panel = new CustomSaveableChartPanel(chart);
			
			if (meta.getCustomAppearance() != null && meta.getCustomAppearance().getDimension() != null)
				panel.setPreferredSize(meta.getCustomAppearance().getDimension());
			
			return panel;		
		}	
		return null;
	}

	//-------------------------------------------------------------------------------
	@Override
	public Container createDialog(ChartConfig config, ChartConfigCollection collection) {
		return new Grid2DDialog(config,collection);
	}

	//-------------------------------------------------------------------------------
	@Override
	public String getID() {
		return ChartConstants.GRID2D;
	}
	
	//-------------------------------------------------------------------------------
	@Override
	public String toString() {
		return ChartConstants.GRID2D_NAME;
	}

	//-------------------------------------------------------------------------------
	@Override
	public String getDescription() {
		return "A 2D grid is a visualisation of a two-dimensional grid or matrix. It" +
				" represents each different cell value with a color.";
	}

	//-------------------------------------------------------------------------------
	@Override
	public List<Integer> getDataSourceIDs(ChartConfig config) {
		List<Integer> result = super.getDataSourceIDs(config);
		if (config.getChartProperties() instanceof Properties) {
			Properties prop = (Properties)config.getChartProperties();
			boolean user_defined_width = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_WIDTH));
			if (!user_defined_width) {
				int candidate = Integer.parseInt(prop.getProperty(ChartConstants.WIDTH));
				result.add(candidate);
			}
			boolean user_defined_height = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
			if (!user_defined_height) {
				int candidate = Integer.parseInt(prop.getProperty(ChartConstants.HEIGHT));
				result.add(candidate);
			}
		}
		return result;
	}
}
