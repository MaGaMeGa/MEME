/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs.components;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;

import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.IDataSourceProducer.NumberStrPair;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.view.ui.ConstantColorMap;
import ai.aitia.meme.utils.FormsUtils;
import ai.aitia.visu.globalhandlers.GlobalHandlers;
import ai.aitia.visu.globalhandlers.UserBreakException;
import ai.aitia.visu.utils.Interval;
import ai.aitia.visu.utils.Utils;
import ai.aitia.visu.view.ui.BlackAndWhiteColorMap;
import ai.aitia.visu.view.ui.ColorMap;
import ai.aitia.visu.view.ui.ColorMapCollection;
import ai.aitia.visu.view.ui.IntervalTableColorMap;
import ai.aitia.visu.view.ui.RainbowColorMap;
import ai.aitia.visu.view.ui.SimpleColorMap;
import ai.aitia.visu.view.ui.IntervalTableColorMap.EntryNotFoundException;
import ai.aitia.visu.view.ui.IntervalTableColorMap.Pair;

/** GUI component to defines colormaps. It used by 
 *  {@link ai.aitia.chart.charttypes.dialogs.Grid2DDialog Grid2DDialog},
 *  {@link ai.aitia.chart.charttypes.dialogs.CompositeGrid2DDialog CompositeGrid2DDialog},
 *  {@link ai.aitia.chart.charttypes.dialogs.RectangleAreaDialog RectangleAreaDialog}.
 */
public class ColorMapPanel extends JPanel implements ActionListener,
													 FocusListener {
	
	private static HashMap<String,IntervalTableColorMap> definedColorMaps = new HashMap<String,IntervalTableColorMap>();
	private static final String DEFAULT_NAME_PREFIX = "Colormap";
	
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JComboBox colorMap = null;
	private JPanel additionalPanel = null;
	private JPanel scmPanel = null;
	private JButton minColorButton = null;
	private JButton maxColorButton = null;
	private JPanel tcmPanel = null;
	private JButton tcmButton = null;
	private JDialog assignDialog = null;
	private JPanel contentPanel = null;
	private JPanel assignPanel = null;
	private JPanel closePanel = null;
	private JButton closeButton = null;
	private JScrollPane scrList = null;
	private JButton saveButton = null;
	private JButton loadButton = null;
	private JLabel jLabel3 = null;
	private JTextField minField = null;
	private JLabel jLabel4 = null;
	private JTextField maxField = null;
	private JPanel leftPanel = null;
	private JColorChooser colorPanel = null;
	private JPanel sharecmPanel = null;
	private JLabel jLabel1 = null;
	private JTextField shareMinField = null;
	private JLabel jLabel5 = null;
	private JTextField shareMaxField = null; 
	private JTable table = null;
	private JPanel tableButtonsPanel = null;
	private JButton moveUpButton = null;
	private JButton moveDownButton = null;
	private JButton removeButton = null;
	private JButton defaultButton = null;
	private JPanel namePanel = null;
	private JTextField nameField = new JTextField();
	private JPanel editPanel = null;
	private JButton editButton = new JButton("Edit colormap...");
	
	//=============================================================================
	// additional members
	
	/** Table model for the color-value table. */
	private ColorMapTableModel tmodel = null;
	
	/** User GUI-component of <code>this</code>. */
	private IColorMapUser user = null;
	
	/** Color of the minimum value (used only with SimpleColorMap). */
	private Color minColor = Color.GRAY;
	
	/** Color of the maximum value (used only with SimpleColorMap). */
	private Color maxColor = Color.RED;
	
	private Color constantColor = Color.BLUE;
	
	/** The string id of the selected colormap. */
	private String current = ChartConstants.RAINBOW;  
	
	//===============================================================================
	// constants
	private static List<ComboboxItem> predefinedColormaps = new ArrayList<ComboboxItem>(7);
	private static List<ComboboxItem> predefinedBWColormaps = new ArrayList<ComboboxItem>(2);
	private static List<String> reservedNames = new ArrayList<String>(8);
	
	static { 
		predefinedColormaps.add(new ComboboxItem(ChartConstants.RAINBOW,"Rainbow colormap"));
		predefinedColormaps.add(new ComboboxItem(ChartConstants.HEAT,"Heat colormap"));
		predefinedColormaps.add(new ComboboxItem(ChartConstants.REAL,"Real colormap"));
		predefinedColormaps.add(new ComboboxItem(ChartConstants.PASTEL,"Pastel colormap"));
		predefinedColormaps.add(new ComboboxItem(ChartConstants.RANDOM,"Random colormap"));
		predefinedColormaps.add(new ComboboxItem(ChartConstants.SIMPLE,"Simple colormap"));
		predefinedColormaps.add(new ComboboxItem(ChartConstants.TABLE,"Table colormap"));

		predefinedBWColormaps.add(new ComboboxItem(ChartConstants.BLACK_AND_WHITE_COLORMAP,"Greyscale colormap"));
		predefinedBWColormaps.add(new ComboboxItem(ChartConstants.TABLE,"Table colormap"));
		
		reservedNames.add("Rainbow colormap");
		reservedNames.add("Heat colormap");
		reservedNames.add("Real colormap");
		reservedNames.add("Pastel colormap");
		reservedNames.add("Random colormap");
		reservedNames.add("Simple colormap");
		reservedNames.add("Table colormap");
		reservedNames.add("Greyscale colormap");
	}
	
	//=============================================================================
	// nested classes
	
	/** This inner class described the colormap file filter. */
	public class ColorMapFileFilter extends FileFilter {
		
		/** Accepts all directories and all colormap (*.cmf) files.
		 * @param f filename
		 */
		@Override
		public boolean accept(File f) {
			if (f.isDirectory()) return true;
			String extension = null;
			String s = f.getName();
			int i = s.lastIndexOf('.');
			if (i>0 && i<s.length()-1) {
				extension = s.substring(i+1).toLowerCase();
			}
			if (extension != null && extension.equals("cmf")) return true;
			return false;
		}
		
		//-------------------------------------------------------------------------
		/** The description of the filter.
		 * @return the description of the filter
		 */
		@Override
		public String getDescription() {
			return "Colormap files (.cmf)";
		}
	}
	
	//-----------------------------------------------------------------------------
	/** Table model for define TableColorMap. */
	private class ColorMapTableModel extends AbstractTableModel {

		private static final long serialVersionUID = 1L;
		
		/** Array of the column names. */
		private String[] columnNames = new String[] { "Value/Interval", "Name", "Color" };
		
		/** List of rows. Each row is represented by an array of Objects. Each array
		 *  has three elements: the interval of the element, the name of the element,
		 *  and the color of the element.
		 */ 
		private List<Object[]> data = null;
		
		//========================================================================
		// methods
		
		/** Constructor. 
		 * @param init List of interval,name,color tuples that already are in the table
		 * @param colorMap the colormap object
		 */
		public ColorMapTableModel(List<Object[]> init, Color defaultColor ) throws UserBreakException {
			data = new ArrayList<Object[]>();
			data.add(new Object[] {null, "Default color", Utilities.colorText(defaultColor,5) });
			for (Object[] o : init) {
				ChartConfigCollection.getLOPExecutor().checkUserBreak();
				data.add(new Object[] { o[0], o[1], Utilities.colorText((Color)o[2],5) });
			}
			data.add(new Object[] {null, null, Utilities.colorText(null,5) });
		}
		
		//------------------------------------------------------------------------
		@Override
		public String getColumnName(int col) {
			return columnNames[col];
		}

		//------------------------------------------------------------------------
		/** Returns the number of columns.
		 * @return the number of columns
		 */
		public int getColumnCount() {
			return columnNames.length;
		}

		//------------------------------------------------------------------------
		/** Returns the number of rows.
		 * @return the number of rows
		 */
		public int getRowCount() {
			return data.size();
		}
		
		//-------------------------------------------------------------------------
		/** Returns the <code>row</code>-th row of the table. */
		public Object[] getRow(int row) { return row < data.size() ? data.get(row) : null; }

		//-------------------------------------------------------------------------
		// Imported from DefaultTableModel
	    /** Removes the row at <code>row</code> from the model.  Notification
	     *  of the row being removed will be sent to all the listeners.
	     * @param row the row index of the row to be removed
	     * @exception ArrayIndexOutOfBoundsException  if the row was invalid
	     */
		public void removeRow(int row) {
	        data.remove(row);
	        fireTableRowsDeleted(row, row);
	    }
		
		//-------------------------------------------------------------------------
		// Imported from DefaultTableModel
	    /** Moves one or more rows from the inclusive range <code>start</code> to 
	     *  <code>end</code> to the <code>to</code> position in the model. 
	     *  After the move, the row that was at index <code>start</code> 
	     *  will be at index <code>to</code>. 
	     *  This method will send a <code>tableChanged</code> notification
	     *  message to all the listeners. <p>
	     *
	     *  <pre>
	     *  Examples of moves:
	     *  <p>
	     *  1. moveRow(1,3,5);
	     *          a|B|C|D|e|f|g|h|i|j|k   - before
	     *          a|e|f|g|h|B|C|D|i|j|k   - after
	     *  <p>
	     *  2. moveRow(6,7,1);
	     *          a|b|c|d|e|f|G|H|i|j|k   - before
	     *          a|G|H|b|c|d|e|f|i|j|k   - after
	     *  <p> 
	     *  </pre>
	     *
	     * @param   start       the starting row index to be moved
	     * @param   end         the ending row index to be moved
	     * @param   to          the destination of the rows to be moved
	     * @exception  ArrayIndexOutOfBoundsException  if any of the elements 
	     * would be moved out of the table's range 
	     * 
	     */
	    public void moveRow(int start, int end, int to) { 
	    	int shift = to - start; 
	    	int first, last; 
	    	if (shift < 0) { 
	    		first = to; 
		    	last = end; 
	    	} else { 
	    		first = start; 
	    		last = to + end - start;  
	    	}
	        Utilities.rotate(data,first,last + 1,shift); 
	        fireTableRowsUpdated(first, last);
	    }
		
		//-------------------------------------------------------------------------
		/** Returns the value of the cell specified by <code>rowIndex</code> and
		 *  <code>columnIndex</code>.
		 * @param rowIndex row index of the cell
		 * @param columnIndex column index of the cell
		 * @return the value of the appropriate cell
		 */
		public Object getValueAt(int rowIndex, int columnIndex) {
			return data.get(rowIndex)[columnIndex];
		}
		
		//------------------------------------------------------------------------
		@Override
		public Class<?> getColumnClass(int c) {
	        switch (c) {
	        case 0  : return Interval.class;
	        default : return String.class;
	        }
	    }

		//------------------------------------------------------------------------
		@Override
	    public boolean isCellEditable(int row, int col) {
	    	if (col != 0 || row == 0) return false ;
	    	return true;
	    }

		//------------------------------------------------------------------------
		@Override
	    public void setValueAt(Object value, int row, int col) {
	    	if (col == 0) {
	    		if (value == null) return;
	    		if (row == data.size() - 1)
	    			data.add(data.size()-1,new Object[] { value, value.toString(), Utilities.colorText(null,5) });
	    		else 
	    			data.set(row,new Object[] { value, value.toString(), Utilities.colorText(null,5) });
	    	} else if (col == 2) {
	    		Object[] actRow = data.get(row);
	    		actRow[2] = Utilities.colorText((Color)value,5);
	    	}
	        fireTableCellUpdated(row, col);
	    }
	}
	
	//============================================================================
	// methods
	
	/** Constructor.
	 * @param user user GUI component of <code>this</code>
	 */
	public ColorMapPanel(IColorMapUser user) {
		super();
		this.user = user;
		initialize();
	}
	
	//----------------------------------------------------------------------------------------------------
	@Override
	public void setEnabled(boolean enabled) {
		jLabel.setEnabled(enabled);
		colorMap.setEnabled(enabled);
		jLabel1.setEnabled(enabled);
		jLabel5.setEnabled(enabled);
		shareMinField.setEnabled(enabled);
		shareMaxField.setEnabled(enabled);
		jLabel3.setEnabled(enabled);
		jLabel4.setEnabled(enabled);
		minField.setEnabled(enabled);
		maxField.setEnabled(enabled);
		minColorButton.setEnabled(enabled);
		maxColorButton.setEnabled(enabled);
		tcmButton.setEnabled(enabled);
		loadButton.setEnabled(enabled);
		editButton.setEnabled(enabled);
	}
	
	//----------------------------------------------------------------------------------------------------
	@Override public boolean isEnabled() { return colorMap.isEnabled(); }
	
	//----------------------------------------------------------------------------------------------------
	public ColorMap getColormap() {
		if (getColorMapType().equals(ChartConstants.RAINBOW) ||
			getColorMapType().equals(ChartConstants.HEAT) ||
			getColorMapType().equals(ChartConstants.REAL) ||
			getColorMapType().equals(ChartConstants.PASTEL) ||
			getColorMapType().equals(ChartConstants.RANDOM) ||
			getColorMapType().equals(ChartConstants.BLACK_AND_WHITE_COLORMAP)) {
			
			String[] map = { ChartConstants.HEAT, ChartConstants.REAL, ChartConstants.PASTEL, ChartConstants.RANDOM };
			double min = - Double.MAX_VALUE;
			double max = Double.MAX_VALUE;
			Pattern p = Pattern.compile("^[-]?[0-9]+[.]?[0-9]*$"); // pattern for double numbers
			Matcher min_m = p.matcher(shareMinField.getText());
			Matcher max_m = p.matcher(shareMaxField.getText());
			if (min_m.matches()) {
				min = Double.parseDouble(shareMinField.getText());
				if (Double.isInfinite(min) || Double.isNaN(min))
					min = - Double.MAX_VALUE;
			}
			if (max_m.matches()) {
				max = Double.parseDouble(shareMaxField.getText());
				if (Double.isInfinite(max) || Double.isNaN(max))
					max = Double.MAX_VALUE;
			}
			if (ChartConstants.RAINBOW.equals(getColorMapType()))
				return new RainbowColorMap(min,max);
			else if (ChartConstants.BLACK_AND_WHITE_COLORMAP.equals(getColorMapType()))
				return new BlackAndWhiteColorMap(min,max);
			else
				return new ColorMapCollection(min,max,Arrays.asList(map).indexOf(getColorMapType()));
		} else if (getColorMapType().equals(ChartConstants.SIMPLE)) {
			double min = - Double.MAX_VALUE;
			double max = Double.MAX_VALUE;
			Pattern p = Pattern.compile("^[-]?[0-9]+[.]?[0-9]*$"); // pattern for double numbers
			Matcher min_m = p.matcher(minField.getText());
			Matcher max_m = p.matcher(maxField.getText());
			if (min_m.matches()) {
				min = Double.parseDouble(minField.getText());
				if (Double.isInfinite(min) || Double.isNaN(min))
					min = - Double.MAX_VALUE;
			}
			if (max_m.matches()) {
				max = Double.parseDouble(maxField.getText());
				if (Double.isInfinite(max) || Double.isNaN(max))
					max = Double.MAX_VALUE;
			}
			return new SimpleColorMap(min,max,minColor,maxColor);
		} else if (getColorMapType().equals(ChartConstants.CONSTANT))
			return new ConstantColorMap(constantColor); 
		else {
			IntervalTableColorMap colormap = definedColorMaps.get(getColorMapType()); 
			return colormap;
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void setSettings(ColorMap colormap) {
		double min = colormap.getMinLevel();
		double max = colormap.getMaxLevel();
		if (colormap instanceof RainbowColorMap ||
			colormap instanceof ColorMapCollection ||
			colormap instanceof BlackAndWhiteColorMap) {
			if (min != - Double.MAX_VALUE)
				shareMinField.setText(String.valueOf(min));
			if (max != Double.MAX_VALUE)
				shareMaxField.setText(String.valueOf(max));
			CardLayout c1 = (CardLayout) additionalPanel.getLayout();
			c1.show(additionalPanel,"SHARE");
			int index = 0;
			if (colormap instanceof RainbowColorMap)
				current = ChartConstants.RAINBOW;
			else if (colormap instanceof BlackAndWhiteColorMap)  {
				current = ChartConstants.BLACK_AND_WHITE_COLORMAP;
				reloadCombobox(true,current);
			} else {
				ColorMapCollection _colormap = (ColorMapCollection) colormap;
				switch (_colormap.getType()) {
				case ColorMapCollection.HEAT : current = ChartConstants.HEAT;
											   index = 1;
											   break;
				case ColorMapCollection.REAL : current = ChartConstants.REAL;
											   index = 2;
											   break;
				case ColorMapCollection.PASTEL : current = ChartConstants.PASTEL;
												 index = 3;
												 break;
				case ColorMapCollection.RANDOM : current = ChartConstants.RANDOM;
												 index = 4;
				}
			}
			colorMap.setSelectedIndex(index);
		} else if (colormap instanceof SimpleColorMap) {
			colorMap.setSelectedIndex(5);
			CardLayout cl = (CardLayout) additionalPanel.getLayout();
			cl.show(additionalPanel,ChartConstants.SIMPLE);
			current = ChartConstants.SIMPLE;
			if (min != - Double.MAX_VALUE)
				minField.setText(String.valueOf(min));
			if (max != Double.MAX_VALUE)
				maxField.setText(String.valueOf(max));
			SimpleColorMap _colormap = (SimpleColorMap) colormap;
			minColor = _colormap.minColor;
			minColorButton.setText(Utilities.colorText(minColor,5));
			maxColor = new Color(_colormap.maxRed,_colormap.maxGreen,_colormap.maxBlue,_colormap.maxAlpha);
			maxColorButton.setText(Utilities.colorText(maxColor,5));
		} else if (colormap instanceof IntervalTableColorMap) {
			IntervalTableColorMap _colormap = (IntervalTableColorMap) colormap;
			String id = _colormap.getName();
			colorMap.setSelectedItem(new ComboboxItem(id));
			CardLayout cl = (CardLayout) additionalPanel.getLayout();
			cl.show(additionalPanel,"EDIT");
			current = id;
		} else if (colormap instanceof ConstantColorMap) 
			defineConstantColorMap(colormap.getColor(0));
	}

	//----------------------------------------------------------------------------
	/** This method initializes <code>this</code>. */
	private void initialize() {
		jLabel = new JLabel();
		jLabel.setText("  Colormap:  ");
		jLabel.setPreferredSize(new Dimension(100, 16));
		this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		this.setPreferredSize(new Dimension(500, 16));
		this.add(jLabel, null);
		this.add(getColorMap(), null);
		this.add(getAdditionalPanel(), null);
	}

	//----------------------------------------------------------------------------
	private JComboBox getColorMap() {
		if (colorMap == null) {
			List<ComboboxItem> items  = new ArrayList<ComboboxItem>();
			items.addAll(predefinedColormaps);
			for (String key : definedColorMaps.keySet())
				items.add(new ComboboxItem(key));
			colorMap = new JComboBox(items.toArray());
			colorMap.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					CardLayout cl = (CardLayout) additionalPanel.getLayout();
					current = (String) ((ComboboxItem)colorMap.getSelectedItem()).getID();
					if (current.equals(ChartConstants.SIMPLE) || current.equals(ChartConstants.TABLE)) 
						cl.show(additionalPanel,current);
					else if (current.equals(ChartConstants.RAINBOW) || current.equals(ChartConstants.HEAT) ||
							 current.equals(ChartConstants.REAL) || current.equals(ChartConstants.PASTEL) ||
							 current.equals(ChartConstants.RANDOM) || current.equals(ChartConstants.BLACK_AND_WHITE_COLORMAP))
						cl.show(additionalPanel,"SHARE");
					else
						cl.show(additionalPanel,"EDIT");
					user.setUpdateStatus(!current.equals(ChartConstants.TABLE));
				}
			});
		}
		return colorMap;
	}

	//----------------------------------------------------------------------------
	private JPanel getAdditionalPanel() {
		if (additionalPanel == null) {
			additionalPanel = new JPanel();
			additionalPanel.setLayout(new CardLayout());
			additionalPanel.add(getSharecmPanel(), getSharecmPanel().getName());
			additionalPanel.add(getScmPanel(), getScmPanel().getName());
			additionalPanel.add(getTcmPanel(), getTcmPanel().getName());
			editPanel = FormsUtils.build("~ p p:g","|0_",editButton).getPanel();
			editPanel.setName("EDIT");
			editButton.setActionCommand("EDIT_BUTTON");
			editButton.addActionListener(this);
			additionalPanel.add(editPanel,editPanel.getName());
			additionalPanel.add(new JLabel(" "),"EMPTY");
		}
		return additionalPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getScmPanel() {
		if (scmPanel == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("  Max. value:  ");
			jLabel3 = new JLabel();
			jLabel3.setText("  Min. value:  ");
			scmPanel = new JPanel();
			scmPanel.setLayout(new BoxLayout(getScmPanel(), BoxLayout.X_AXIS));
			scmPanel.setName(ChartConstants.SIMPLE);
			scmPanel.add(jLabel3, null);
			scmPanel.add(getMinField(), null);
			scmPanel.add(Box.createRigidArea(new Dimension(3,0)));
			scmPanel.add(getMinColorButton(), null);
			scmPanel.add(jLabel4, null);
			scmPanel.add(getMaxField(), null);
			scmPanel.add(Box.createRigidArea(new Dimension(3,0)));
			scmPanel.add(getMaxColorButton(), null);
		}
		return scmPanel;
	}

	//----------------------------------------------------------------------------
	private JButton getMinColorButton() {
		if (minColorButton == null) {
			minColorButton = new JButton();
			minColorButton.setText(Utilities.colorText(minColor,5));
			final JPanel tthis = this;
			minColorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Color chosen = JColorChooser.showDialog(tthis.getRootPane().getParent(),"Color of the minimum value" , minColor);
					if (chosen != null){
						minColor = chosen;
						minColorButton.setText(Utilities.colorText(minColor,5));
					}
				}
			});
		}
		return minColorButton;
	}

	//----------------------------------------------------------------------------
	private JButton getMaxColorButton() {
		if (maxColorButton == null) {
			maxColorButton = new JButton();
			maxColorButton.setText(Utilities.colorText(maxColor,5));
			final JPanel tthis = this;
			maxColorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Color chosen = JColorChooser.showDialog(tthis.getRootPane().getParent(),"Color of the maximum value" , maxColor);
					if (chosen != null) {
						maxColor = chosen;
						maxColorButton.setText(Utilities.colorText(maxColor,5));
					}
	
				}
			});
		}
		return maxColorButton;
	}

	//----------------------------------------------------------------------------
	private JPanel getTcmPanel() {
		if (tcmPanel == null) {
			tcmPanel = new JPanel();
			tcmPanel.setLayout(new BoxLayout(getTcmPanel(), BoxLayout.X_AXIS));
			tcmPanel.setName(ChartConstants.TABLE);
			tcmPanel.add(Box.createRigidArea(new Dimension(10,0)));
			tcmPanel.add(getTcmButton(), null);
			tcmPanel.add(Box.createRigidArea(new Dimension(10,0)));
			tcmPanel.add(getLoadButton(), null);
		}
		return tcmPanel;
	}

	//----------------------------------------------------------------------------
	private JButton getTcmButton() {
		if (tcmButton == null) {
			tcmButton = new JButton();
			tcmButton.setText("Assign color to value...");
			tcmButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (assignDialog != null) {
						nameField.setText(defaultName());
						setTableElements(new IntervalTableColorMap());
					}
					getAssignDialog().setVisible(true);
				}
			});
		}
		return tcmButton;
	}

	//----------------------------------------------------------------------------
	private JDialog getAssignDialog() {
		if (assignDialog == null) {
			Container c = getTopLevelAncestor();
			if (c instanceof JDialog) 
				assignDialog = new JDialog((JDialog)c, "Assign color to value", true);
			else 
				assignDialog = new JDialog((JFrame)c, "Assign color to value", true);
			
			final JScrollPane sp = new JScrollPane(getContentPanel(),JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			sp.setBorder(null);
			assignDialog.setContentPane(sp);
			setTableElements(new IntervalTableColorMap());
			assignDialog.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
			assignDialog.pack();
			Dimension oldD = assignDialog.getPreferredSize();
			assignDialog.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
											     		oldD.height + sp.getHorizontalScrollBar().getHeight()));
			sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			oldD = assignDialog.getPreferredSize();
			final Dimension newD = Utils.getPreferredSize(assignDialog);
			if (!oldD.equals(newD)) 
				assignDialog.setPreferredSize(newD);
			assignDialog.pack();
			assignDialog.setLocationRelativeTo(c);
		}
		return assignDialog;
	}

	//----------------------------------------------------------------------------
	private JPanel getContentPanel() {
		if (contentPanel == null) {
			contentPanel = new JPanel();
			contentPanel.setLayout(new BoxLayout(getContentPanel(), BoxLayout.Y_AXIS));
			contentPanel.add(getAssignPanel(), null);
			contentPanel.add(new JSeparator(JSeparator.HORIZONTAL));
			contentPanel.add(getClosePanel(), null);
		}
		return contentPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getAssignPanel() {
		if (assignPanel == null) {
			assignPanel = new JPanel();
			assignPanel.setLayout(new BoxLayout(getAssignPanel(), BoxLayout.X_AXIS));
			assignPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			assignPanel.add(getLeftPanel(), null);
			assignPanel.add(Box.createRigidArea(new Dimension(10,0)));
			assignPanel.add(getColorPanel(), null);
		}
		return assignPanel;
	}
	
	//----------------------------------------------------------------------------
	private JPanel getLeftPanel() {
		if (leftPanel == null) {
			leftPanel = new JPanel();
			leftPanel.setLayout(new BoxLayout(getLeftPanel(), BoxLayout.Y_AXIS));
			namePanel = FormsUtils.build("p ~ p:g",
										 "01",
										 "Name: ", nameField).getPanel();
			leftPanel.add(namePanel);
			nameField.setText(defaultName());
			nameField.addFocusListener(this);
			leftPanel.add(getScrTable(), null);
			leftPanel.add(Box.createRigidArea(new Dimension(0,5)));
			leftPanel.add(getTableButtonsPanel(), null);
			JPanel p = new JPanel();
			p.setMaximumSize(new Dimension(32323,24));
			p.add(getSaveButton());
			leftPanel.add(p, null);
		}
		return leftPanel;
	}
	
	//-----------------------------------------------------------------------------
	private JPanel getTableButtonsPanel() {
		if (tableButtonsPanel == null) {
			(moveUpButton = new JButton("Move up")).setActionCommand("UP");
			(moveDownButton = new JButton("Move down")).setActionCommand("DOWN");
			(removeButton = new JButton("Remove")).setActionCommand("REMOVE");
			(defaultButton = new JButton("Reset color")).setActionCommand("DEFAULT");
			tableButtonsPanel = FormsUtils.build("p:g ~ p:g ~ p:g ~ p:g",
												 "_01_||" +
												 "_23_",
												 moveUpButton,removeButton,
												 moveDownButton,defaultButton).getPanel();
			Utilities.addActionListener(this,moveUpButton,moveDownButton,removeButton,defaultButton);
		}
		return tableButtonsPanel;
	}
	
	//----------------------------------------------------------------------------
	private JColorChooser getColorPanel() {
		if (colorPanel == null) {
			colorPanel = new JColorChooser(Color.BLUE);
			colorPanel.getSelectionModel().addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					Color newColor = colorPanel.getColor();
					int[] indices = table.getSelectedRows();
					if (indices.length != 0) {
						for (int i = 0;i < indices.length;++i) {
							if (indices[i] == 0) 
								tmodel.setValueAt(newColor,0,2);
							else if (indices[i] == tmodel.getRowCount() - 1) continue;
							else 
								tmodel.setValueAt(newColor,indices[i],2);
						}
					}
				}
			});
		}
		return colorPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getClosePanel() {
		if (closePanel == null) {
			closePanel = new JPanel();
			closePanel.setLayout(new FlowLayout());
			closePanel.add(getCloseButton(), null);
		}
		return closePanel;
	}

	//----------------------------------------------------------------------------
	private JButton getCloseButton() {
		if (closeButton == null) {
			closeButton = new JButton();
			closeButton.setText("Close");
			closeButton.setMnemonic(KeyEvent.VK_C);
			closeButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if ("".equals(nameField.getText().trim()))
						nameField.setText(defaultName());
					assignDialog.setVisible(false);
					buildTableColorMap(nameField.getText());
				}
			});
		}
		return closeButton;
	}

	//----------------------------------------------------------------------------
	private JScrollPane getScrTable() {
		if (scrList == null) {
			scrList = new JScrollPane();
			scrList.setPreferredSize(new Dimension(300,500));
			scrList.setBorder(BorderFactory.createTitledBorder("Color values"));
			scrList.setViewportView(getTable());
		}
		return scrList;
	}
	
	//----------------------------------------------------------------------------
	private JTable getTable() {
		if (table == null) {
			table = new JTable() {
				private static final long serialVersionUID = 1L;
				{
					tableHeader.setReorderingAllowed(false);
				}
			};
			DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
			renderer.setLocale(Locale.US);
			renderer.setHorizontalAlignment(JTextField.TRAILING);
			renderer.setBackground(getScrTable().getBackground());
			DefaultTableCellRenderer renderer2 = new DefaultTableCellRenderer();
			renderer2.setHorizontalAlignment(JTextField.CENTER);
			renderer2.setBackground(getScrTable().getBackground());
			table.setDefaultRenderer(Interval.class,renderer);
			table.setDefaultRenderer(String.class,renderer2);
		}
		return table;
	}

	//----------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setMaximumSize(new Dimension(153, 26));
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.setPreferredSize(new Dimension(153, 26));
			saveButton.setText("Save colormap...");
			saveButton.setMinimumSize(new Dimension(153, 26));
			saveButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					// get the filename
					JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
					fc.setAcceptAllFileFilterUsed(false);
					fc.addChoosableFileFilter(new ColorMapFileFilter());
					int result = fc.showSaveDialog(getAssignDialog());
					if (result == JFileChooser.APPROVE_OPTION) {
						if ("".equals(nameField.getText().trim()))
							nameField.setText(defaultName());
						IntervalTableColorMap tableColorMap = buildTableColorMap(nameField.getText());
						File file = fc.getSelectedFile();
						File newFile = Utilities.generateValidFile(file,"cmf");
						GlobalHandlers.setLastDirectory(newFile);
						
						// initialize the properties object
						Properties colormap = new Properties();
						String color_string = String.format("#%06x",tableColorMap.getDefaultColor().getRGB() & 0xffffff);
						colormap.setProperty(ChartConstants.DEFAULT_COLOR,color_string);
						colormap.setProperty(ChartConstants.NAME,tableColorMap.getName());
						
						List<Pair<Interval,Color>> map = tableColorMap.getMap();
						for (int i = 0;i < map.size();++i) {
							Pair<Interval,Color> p = map.get(i);
							try {
								Color color = tableColorMap.getColor(p.getKey());
								String index = String.valueOf(i);
								if (colormap.getProperty(p.getKey().toString()) != null) 
									index = colormap.getProperty(p.getKey().toString()).split("\\?")[1];
								color_string = (color == null ? "_" : String.format("#%06x",color.getRGB() & 0xffffff)) + "?" + index;
								colormap.setProperty(p.getKey().toString(),color_string);
							} catch (EntryNotFoundException e1) {}
						}
					
						// open file and save 
						try {
							FileOutputStream os = new FileOutputStream(newFile);
							colormap.store(os,"");
							os.close();
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(getAssignDialog(),"Unable to save the defined colormap.","Saving failure",JOptionPane.ERROR_MESSAGE,null);
						}
					}
				}
			});
		}
		return saveButton;
	}

	//----------------------------------------------------------------------------
	private JButton getLoadButton() {
		if (loadButton == null) {
			loadButton = new JButton();
			loadButton.setText("Load colormap...");
			loadButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					// get the file name
					JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
					fc.setAcceptAllFileFilterUsed(false);
					fc.addChoosableFileFilter(new ColorMapFileFilter());
					int result = fc.showOpenDialog(ColorMapPanel.this);
					if (result == JFileChooser.APPROVE_OPTION) {
						File file = fc.getSelectedFile();
						GlobalHandlers.setLastDirectory(file);
						
						// open the file
						Properties colormap = new Properties();
						try {
							FileInputStream is = new FileInputStream(file);
							colormap.load(is);
							is.close();
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(ColorMapPanel.this,"Unable to load the selected colormap.","Loading failure",JOptionPane.ERROR_MESSAGE,null);
							return;
						}
						// set the colormap
						IntervalTableColorMap tableColorMap = new IntervalTableColorMap();
						tableColorMap.setName(colormap.getProperty(ChartConstants.NAME,""));
						int defColorRGB = Integer.decode(colormap.getProperty(ChartConstants.DEFAULT_COLOR));
						tableColorMap.setDefaultColor(new Color(defColorRGB));
						String[] keys = colormap.keySet().toArray(new String[0]);
						Interval intvs[] = new Interval[keys.length - 2];
						Color colors[] = new Color[keys.length - 2];
						for (int i = 0;i < keys.length;++i) {
							if (!keys[i].equals(ChartConstants.DEFAULT_COLOR) &&
								!keys[i].equals(ChartConstants.NAME)) {
								String[] parts = colormap.getProperty(keys[i]).split("\\?");
								int index = Integer.parseInt(parts[1]);
								intvs[index] = new Interval(keys[i]);
								colors[index] = parts[0].equals("_") ? null : new Color(Integer.decode(parts[0]));
							}
						}
						for (int i = 0;i < intvs.length;++i)
							tableColorMap.addEntry(intvs[i],colors[i]);
						definedColorMaps.put(tableColorMap.getName(),tableColorMap);
						reloadCombobox(false,tableColorMap.getName());
					}
				}
			});
		}
		return loadButton;
	}
	
	//----------------------------------------------------------------------------
	private JPanel getSharecmPanel() {
		if (sharecmPanel == null) {
			jLabel5 = new JLabel();
			jLabel5.setText("  Maximum value:  ");
			jLabel1 = new JLabel();
			jLabel1.setText("  Minimum value:  ");
			sharecmPanel = new JPanel();
			sharecmPanel.setLayout(new BoxLayout(getSharecmPanel(), BoxLayout.X_AXIS));
			sharecmPanel.setName("SHARE");
			sharecmPanel.add(jLabel1, null);
			sharecmPanel.add(getShareMinField(), null);
			sharecmPanel.add(jLabel5, null);
			sharecmPanel.add(getShareMaxField(), null);
		}
		return sharecmPanel;
	}

	//----------------------------------------------------------------------------
	private JTextField getShareMinField() {
		if (shareMinField == null) {
			shareMinField = new JTextField();
			shareMinField.setMaximumSize(new Dimension(2147483647, 20));
			shareMinField.setPreferredSize(new Dimension(40, 20));
			shareMinField.setHorizontalAlignment(JTextField.TRAILING);
			shareMinField.setMinimumSize(new Dimension(40, 20));
		}
		return shareMinField;
	}

	//----------------------------------------------------------------------------
	private JTextField getShareMaxField() {
		if (shareMaxField == null) {
			shareMaxField = new JTextField();
			shareMaxField.setMaximumSize(new Dimension(2147483647, 20));
			shareMaxField.setPreferredSize(new Dimension(40, 20));
			shareMaxField.setHorizontalAlignment(JTextField.TRAILING);
			shareMaxField.setMinimumSize(new Dimension(40, 20));
		}
		return shareMaxField;
	}
	
	//----------------------------------------------------------------------------
	private JTextField getMinField() {
		if (minField == null) {
			minField = new JTextField();
			minField.setMinimumSize(new Dimension(40, 20));
			minField.setMaximumSize(new Dimension(2147483647, 20));
			minField.setHorizontalAlignment(JTextField.TRAILING);
			minField.setPreferredSize(new Dimension(40, 20));
		}
		return minField;
	}

	//----------------------------------------------------------------------------
	private JTextField getMaxField() {
		if (maxField == null) {
			maxField = new JTextField();
			maxField.setMinimumSize(new Dimension(40, 20));
			maxField.setMaximumSize(new Dimension(2147483647, 20));
			maxField.setHorizontalAlignment(JTextField.TRAILING);
			maxField.setPreferredSize(new Dimension(40, 20));
		}
		return maxField;
	}
	
	//============================================================================
	// non-GUI methods
	
	public boolean hasDefinedColormap() { return !current.equals(ChartConstants.TABLE); }
			
	/** Returns the minimum value of the selected colormap in string format.
	 * @return minimum value in string format
	 */
	public String getMinValue() {
		if (current.equals(ChartConstants.SIMPLE))
			return minField.getText();
		else
			return shareMinField.getText();
	}
	
	//----------------------------------------------------------------------------
	/** Sets the minimum value.
	 * @param value minimum value in string format
	 */
	public void setMinValue(String value) {
		shareMinField.setText(value);
		minField.setText(value);
	}
	
	//----------------------------------------------------------------------------
	/** Returns the maximum value of the selected colormap in string format.
	 * @return maximum value in string format
	 */
	public String getMaxValue() {
		if (current.equals(ChartConstants.SIMPLE))
			return maxField.getText();
		else
			return shareMaxField.getText();
	}
	
	//----------------------------------------------------------------------------
	/** Sets the maximum value.
	 * @param value maximum value in string format
	 */
	public void setMaxValue(String value) {
		shareMaxField.setText(value);
		maxField.setText(value);
	}
	
	//----------------------------------------------------------------------------
	/** Returns the IntervalTableColorMap object.
	 * @return the IntervalTableColorMap object
	 */
	public IntervalTableColorMap getTableColorMap() {
		return definedColorMaps.get(current);
	}
	
	//----------------------------------------------------------------------------
	/** Returns the id of the selected colormap type.
	 * @return id of the selected colormap type (a string)
	 */
	public Comparable getColorMapType() {
		return ((ComboboxItem)colorMap.getSelectedItem()).getID();
	}
	
	//----------------------------------------------------------------------------
	/** Selects the default colormap (RainbowColorMap). */
	public void resetColorMapType() {
		colorMap.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------
	/** Creates and returns the string description of the selected colormap.
	 * @return the string description of the selected colormap
	 */
	@SuppressWarnings("unchecked")
	public String settingsToString() {
		String settings = null;
		if (getColorMapType().equals(ChartConstants.RAINBOW) ||
			getColorMapType().equals(ChartConstants.HEAT) ||
			getColorMapType().equals(ChartConstants.REAL) ||
			getColorMapType().equals(ChartConstants.PASTEL) ||
			getColorMapType().equals(ChartConstants.RANDOM) ||
			getColorMapType().equals(ChartConstants.BLACK_AND_WHITE_COLORMAP)) {
			double min = - Double.MAX_VALUE;
			double max = Double.MAX_VALUE;
			Pattern p = Pattern.compile("^[-]?[0-9]+[.]?[0-9]*$"); // pattern for double numbers
			Matcher min_m = p.matcher(shareMinField.getText());
			Matcher max_m = p.matcher(shareMaxField.getText());
			if (min_m.matches()) {
				min = Double.parseDouble(shareMinField.getText());
				if (Double.isInfinite(min) || Double.isNaN(min))
					min = - Double.MAX_VALUE;
			}
			if (max_m.matches()) {
				max = Double.parseDouble(shareMaxField.getText());
				if (Double.isInfinite(max) || Double.isNaN(max))
					max = Double.MAX_VALUE;
			}
			settings = getColorMapType() + "," + String.valueOf(min) + "," + String.valueOf(max);
		} else if (getColorMapType().equals(ChartConstants.SIMPLE)) {
			double min = - Double.MAX_VALUE;
			double max = Double.MAX_VALUE;
			Pattern p = Pattern.compile("^[-]?[0-9]+[.]?[0-9]*$"); // pattern for double numbers
			Matcher min_m = p.matcher(minField.getText());
			Matcher max_m = p.matcher(maxField.getText());
			if (min_m.matches()) {
				min = Double.parseDouble(minField.getText());
				if (Double.isInfinite(min) || Double.isNaN(min))
					min = - Double.MAX_VALUE;
			}
			if (max_m.matches()) {
				max = Double.parseDouble(maxField.getText());
				if (Double.isInfinite(max) || Double.isNaN(max))
					max = Double.MAX_VALUE;
			}
			String min_str = String.format("#%06x", minColor.getRGB() & 0xffffff);
			String max_str = String.format("#%06x", maxColor.getRGB() & 0xffffff);
			settings = ChartConstants.SIMPLE + "," + String.valueOf(min) + "," + String.valueOf(max);
			settings += "," + min_str + "," + max_str;
		} else if (getColorMapType().equals(ChartConstants.CONSTANT)) {
			final String color_str = String.format("#%06x",constantColor.getRGB() & 0xffffff);
			settings = ChartConstants.CONSTANT + "," + String.valueOf(color_str);
		} else {
			String temp = null;
			IntervalTableColorMap tableColorMap = definedColorMaps.get(current);
			temp = ChartConstants.TABLE + "," + tableColorMap.getName() + "," + String.format("#%06x",tableColorMap.getDefaultColor().getRGB() & 0xffffff) + ",";
			List<Pair<Interval,Color>> map = tableColorMap.getMap();
			for (Pair<Interval,Color> p : map) {
				temp += p.getKey().toString() + ":";
				temp += (p.getValue() == null ? "_" : String.format("#%06x",p.getValue().getRGB() & 0xffffff)) + ",";
			}
			settings = temp.substring(0,temp.length() - 1);
		}
		return settings;
	}
	
	//----------------------------------------------------------------------------
	/** Sets the colormap from the string <code>settings</code>.
	 * @param settings string description of a colormap
	 * @param isBlackAndWhite the color environment
	 */
	public void settingsFromString(String settings, boolean isBlackAndWhite) {
		String[] strings = settings.split(",");
		if (strings[0].equals(ChartConstants.RAINBOW) ||
			strings[0].equals(ChartConstants.HEAT) ||
			strings[0].equals(ChartConstants.REAL) ||
			strings[0].equals(ChartConstants.PASTEL) ||
			strings[0].equals(ChartConstants.RANDOM) ||
			strings[0].equals(ChartConstants.BLACK_AND_WHITE_COLORMAP)) {
			if (Double.parseDouble(strings[1]) != - Double.MAX_VALUE) 
				shareMinField.setText(strings[1]);
			if (Double.parseDouble(strings[2]) != Double.MAX_VALUE) 
				shareMaxField.setText(strings[2]);
			CardLayout c1 = (CardLayout) additionalPanel.getLayout();
			c1.show(additionalPanel,"SHARE");
			current = strings[0];
			if (isBlackAndWhite) 
				reloadCombobox(true,current);
			int index = 0;
			if (strings[0].equals(ChartConstants.HEAT)) 
				index = 1;
			if (strings[0].equals(ChartConstants.REAL)) 
				index = 2;
			if (strings[0].equals(ChartConstants.PASTEL)) 
				index = 3;
			if (strings[0].equals(ChartConstants.RANDOM)) 
				index = 4;
			colorMap.setSelectedIndex(index);
		} else if (strings[0].equals(ChartConstants.SIMPLE)) {
			colorMap.setSelectedIndex(5);
			CardLayout cl = (CardLayout) additionalPanel.getLayout();
			cl.show(additionalPanel,ChartConstants.SIMPLE);
			current = ChartConstants.SIMPLE;
			if (Double.parseDouble(strings[1]) != - Double.MAX_VALUE)
				minField.setText(strings[1]);
			if (Double.parseDouble(strings[2]) != Double.MAX_VALUE)
				maxField.setText(strings[2]);
			minColor = new Color(Integer.decode(strings[3]));
			minColorButton.setText(Utilities.colorText(minColor,5));
			maxColor = new Color(Integer.decode(strings[4]));
			maxColorButton.setText(Utilities.colorText(maxColor,5));
		} else if (strings[0].equals(ChartConstants.TABLE)) {
			IntervalTableColorMap tableColorMap = new IntervalTableColorMap();
			CardLayout cl = (CardLayout) additionalPanel.getLayout();
			cl.show(additionalPanel,"EDIT");
			tableColorMap.setName(strings[1]);
			current = strings[1];
			tableColorMap.setDefaultColor(new Color(Integer.decode(strings[2])));
			for (int i = 3;i < strings.length;++i) {
				String[] pair = strings[i].split(":");
				Interval intv = new Interval(pair[0]);
				Color color = pair[1].equals("_") ? null : new Color(Integer.decode(pair[1]));
				tableColorMap.addEntry(intv,color);
			}
			definedColorMaps.put(strings[1],tableColorMap);
			reloadCombobox(isBlackAndWhite,current);
		} else if (strings[0].equals(ChartConstants.CONSTANT)) 
			defineConstantColorMap(new Color(Integer.decode(strings[1])));
	}
	
	//----------------------------------------------------------------------------
	public void reloadCombobox(boolean isBlackAndWhite, String current) {
		List<ComboboxItem> items  = new ArrayList<ComboboxItem>();
		items.addAll(isBlackAndWhite ? predefinedBWColormaps : predefinedColormaps);
		for (String key : definedColorMaps.keySet())
			items.add(new ComboboxItem(key,key));
		colorMap.setModel(new DefaultComboBoxModel(items.toArray()));
		ComboboxItem item = new ComboboxItem(current);
		if (((DefaultComboBoxModel)colorMap.getModel()).getIndexOf(item) > 0) {
			colorMap.setSelectedItem(item);
			this.current = current;
		} else { 
			colorMap.setSelectedIndex(0);
			this.current = ((ComboboxItem)colorMap.getSelectedItem()).getID().toString();
		}
		user.setUpdateStatus(!current.equals(ChartConstants.TABLE));
	}
	
	//----------------------------------------------------------------------------------------------------
	public void defineConstantColorMap(final Color color) {
		final Object[] items = { new ComboboxItem(ChartConstants.CONSTANT,"Constant colormap") };
		colorMap.setModel(new DefaultComboBoxModel(items));
		setEnabled(false);
		CardLayout layout = (CardLayout) additionalPanel.getLayout();
		layout.show(additionalPanel,"EMPTY");
		constantColor = color;
		current = ChartConstants.CONSTANT;
		user.setUpdateStatus(true);
	}
	
	//----------------------------------------------------------------------------------------------------
	public void resetColorMapPanel(final boolean isBlackAndWhite) {
		setEnabled(true);
		final String current = (isBlackAndWhite ? predefinedBWColormaps : predefinedColormaps).get(0).getID().toString();
		reloadCombobox(isBlackAndWhite,current);
	}
	
	//----------------------------------------------------------------------------------------------------
	public Color getConstantColor() { return constantColor; } 
	
	//----------------------------------------------------------------------------
	/** Returns whether the item <code>item</code> contained by <code>list</code> or
	 *  not. Returns a valid index if number value of <code>item</code> equals to number
	 *  value of any element of the list otherwise returns -1.
	 * @param item the element 
	 * @param list the list where the method searches
	 */
	private int isElement(NumberStrPair item, List<Object[]> list) {
		for (int i=0;i<list.size();++i) {
			if (item.getNumber().equals(((Interval)list.get(i)[0]).getLower()) &&
			    item.getNumber().equals(((Interval)list.get(i)[0]).getUpper())) {
				return i;
			}
		}
		return -1;
	}

	//----------------------------------------------------------------------------
	/** Sets the initial elements of the table. */
	@SuppressWarnings("unchecked")
	private void setTableElements(final IntervalTableColorMap tableColorMap) {
		IDataSourceProducer dsp = user.getColorValueProducer();
		if (dsp == null) {
			assignDialog.setVisible(false);
			return;
		}
		
		final List<Object[]> init = new ArrayList<Object[]>();
		
		List<Pair<Interval,Color>> map = tableColorMap.getMap();
		
		if (!map.isEmpty()) {
			for (Pair<Interval,Color> p : map) 
				init.add(new Object[] { p.getFirst(), p.getFirst().toString(), p.getSecond() });
		}

		try {
			final List<NumberStrPair> list = (List<NumberStrPair>)ChartConfigCollection.
			getLOPExecutor().execute("Initializing elements",dsp,"getElements");
			ChartConfigCollection.getLOPExecutor().execute("Initializing table",new Callable<Object>() {
				public Object call() throws Exception {
					if (list != null) {
						for (NumberStrPair p : list) {
							ChartConfigCollection.getLOPExecutor().checkUserBreak();
							int index = -1;
							if ((index = isElement(p,init)) != -1)  
								init.get(index)[1] = p.toString();
							else
								init.add(new Object[] { new Interval(p.getNumber().doubleValue()),p.toString(),null }); 
						}
					}
					tmodel = new ColorMapTableModel(init,tableColorMap.getDefaultColor());
					getTable().setModel(tmodel);
					return null;
				}
			});
		} catch (UserBreakException e) {
			try {
				tmodel = new ColorMapTableModel(init,tableColorMap.getDefaultColor());
				getTable().setModel(tmodel);
			} catch (UserBreakException e1) {}
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
		enableDisableButtons();
	}
	
	//-------------------------------------------------------------------------------
	private IntervalTableColorMap buildTableColorMap(String name) {
		IntervalTableColorMap tableColorMap = new IntervalTableColorMap();
		tableColorMap.setName(name);
		for (int i = 0;i < tmodel.getRowCount() - 1;++i) {
			Object[] row = tmodel.getRow(i);
			String color_str = (String) row[2];
			if (i == 0) {
				Color color = Utilities.toColor(color_str,Color.white);
				tableColorMap.setDefaultColor(color);
			} else {
				Color color = Utilities.toColor(color_str,tableColorMap.getDefaultColor());
				Interval intv = (Interval) row[0];
				tableColorMap.addEntry(intv,color);
			}
		}
		definedColorMaps.put(name,tableColorMap);
		boolean isBlackAndWhite = !((ComboboxItem)colorMap.getItemAt(0)).getID().equals(ChartConstants.RAINBOW);
		reloadCombobox(isBlackAndWhite,name);
		return tableColorMap;
	}

	//-------------------------------------------------------------------------------
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("DOWN".equals(command)) 
			move(1);
		else if ("UP".equals(command)) 
			move(-1);
		else if ("REMOVE".equals(command)) {
			table.getSelectionModel().removeSelectionInterval(0,0);
			table.getSelectionModel().removeSelectionInterval(tmodel.getRowCount() - 1,tmodel.getRowCount() - 1);
			int[] selected = table.getSelectedRows();
			if (selected.length == 0) return;
			String msg[] = new String[2];
			if (selected.length == 1) 
				msg[0] = String.format("The following entry will be deleted: %s", tmodel.getRow(selected[0])[1].toString());
			else 
				msg[0] = String.format("The selected entries (%d) will be deleted.",selected.length);
			msg[1] = "Are you sure?";
			boolean ok = JOptionPane.showConfirmDialog(getAssignDialog(), msg, "Warning", 
													   JOptionPane.YES_NO_OPTION,
													   JOptionPane.WARNING_MESSAGE
													   ) == JOptionPane.YES_OPTION;
			if (ok) {
				while (selected.length != 0) {
					tmodel.removeRow(selected[0]);
					selected = table.getSelectedRows();
				}
				enableDisableButtons();
			}
		} else if ("DEFAULT".equals(command)) {
			int[] indices = table.getSelectedRows();
			if (indices.length != 0) {
				for (int i = 0;i < indices.length;++i) {
					if (indices[i] == 0 || indices[i] == tmodel.getRowCount() - 1) continue;
					else 
						tmodel.setValueAt(null,indices[i],2);
				}
			}
		} else if ("EDIT_BUTTON".equals(command)) {
			String id = ((ComboboxItem)colorMap.getSelectedItem()).getID().toString();
			IntervalTableColorMap tableColorMap = definedColorMaps.get(id);
			getAssignDialog(); // make sure to create the dialog
			nameField.setText(tableColorMap.getName());
			setTableElements(tableColorMap);
			getAssignDialog().setVisible(true); 
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void focusGained(FocusEvent e) {}

	//----------------------------------------------------------------------------------------------------
	public void focusLost(FocusEvent e) {
		String name = nameField.getText().trim();
		if (reservedNames.contains(name)) {
			JOptionPane.showMessageDialog(getAssignDialog(),"This is a reserved name for a predefined colormap.","Please define a new name!",JOptionPane.WARNING_MESSAGE,null);
			nameField.setText(defaultName());
			nameField.grabFocus();
			nameField.selectAll();
		}
	}

	
	//-------------------------------------------------------------------------------
	private void move(int offset) {
		table.getSelectionModel().removeSelectionInterval(0,0);
		table.getSelectionModel().removeSelectionInterval(tmodel.getRowCount() - 1,tmodel.getRowCount() - 1);
		int[] selected = table.getSelectedRows();
		
		List<int[]> intervals = new ArrayList<int[]>();
		int start = selected[0], end = -1, previous = selected[0] - 1;

		for (int i = 0;i < selected.length;++i) {
				if (selected[i] == previous + 1)
					previous = selected[i];
				else {
					end = previous;
					int[] intv = { start, end };
					intervals.add(intv);
					end = -1;
					start = previous = selected[i];
				}
		}
		intervals.add(new int[] { start, selected[selected.length - 1] });
		
		table.getSelectionModel().clearSelection();
		for (int[] intv : intervals) {
			int to = intv[0] + offset;
			if (1 <= intv[0] && 1 <= to && intv[1] + offset < table.getRowCount() - 1) {
				tmodel.moveRow(intv[0],intv[1],to);
				table.getSelectionModel().addSelectionInterval(intv[0] + offset,intv[1] + offset);
			} else 
				table.getSelectionModel().addSelectionInterval(intv[0],intv[1]);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	private String defaultName() {
		return DEFAULT_NAME_PREFIX + String.valueOf(countElementsWithSamePrefix(DEFAULT_NAME_PREFIX));
	}
	
	//----------------------------------------------------------------------------------------------------
	public int countElementsWithSamePrefix(String prefix) {
		int result = 0;
		for (String key : definedColorMaps.keySet()) {
			if (key.startsWith(prefix))
				result++;
		}
		return result;
	}

	//-------------------------------------------------------------------------------
	private void enableDisableButtons() {
		moveUpButton.setEnabled(tmodel.getRowCount() > 3);
		moveDownButton.setEnabled(tmodel.getRowCount() > 3);
		removeButton.setEnabled(tmodel.getRowCount() > 2);
	}
}