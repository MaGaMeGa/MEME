package ai.aitia.fobwizard;

public interface IDataSourceEditorGUI {
	
	public static interface IDataSourceInformator {};

	public static final int CANCEL_OPTION				   = 0;
	public static final int DATASOURCE_LIST_CHANGED_OPTION = 1;
	
	public int showDialog();
	public IDataSourceInformator getDataSourceInformator();
	public void shutdown();
}