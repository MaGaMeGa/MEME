/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;

import org.jfree.ui.ExtensionFileFilter;
import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.ColorMapPanel;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.IColorMapUser;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.ds.IAdjacencyMatrixProducer;
import ai.aitia.chart.ds.IStringListProducer;
import ai.aitia.chart.ds.IStringSeriesProducer;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.view.meta.GraphMetadata;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.ds.IXYSeriesProducer;
import ai.aitia.visu.globalhandlers.GlobalHandlers;
import ai.aitia.visu.globalhandlers.UserBreakException;

/** GUI-components of networks/graphs. */
public class NetworkChartDialog extends AbstractChartDialog implements IColorMapUser {
	
	private static final long serialVersionUID = 1L;
	private JTabbedPane tabbed = null;
	private JPanel mainPanel = null;
	private JPanel firstPanel = null;
	private JPanel edgePanel = null;
	private JComboBox edgeParam = null;
	private JButton edgeAdvancedButton = null;
	private JLabel jLabel = null;
	private JTextField nodesField = null;
	private JPanel nodesPanel = null;
	private JCheckBox hasLabelsBox = null;
	private JPanel labelSourcePanel = null;
	private JComboBox labelParam = null;
	private JButton labelAdvancedButton = null;
	private JComboBox layoutCBox = null;
	private JPanel paramPanel = null;
	private JPanel FRParamPanel = null;
	private JLabel jLabel2 = null;
	private JLabel jLabel3 = null;
	private JLabel jLabel4 = null;
	private JSlider repulsionSlider = null;
	private JSlider attractionSlider = null;
	private JPanel buttonsPanel = null;
	private JButton cancelButton = null;
	private JPanel detailsPanel = null;
	private JPanel titleLine = null;
	private JLabel jLabel8 = null;
	private JPanel subtitleLine = null;
	private JLabel jLabel9 = null;
	private JTextField subtitleField = null;
	private JPanel layoutMainPanel = null;
	private JLabel colorLabel = null;
	private JButton changeButton = null;
	private JPanel additionalPanel = null;
	private JComboBox additionalParam = null;
	private JButton additionalAdvancedButton = null;
	private JPanel typePanel = null;
	private JRadioButton undirectedButton = null;
	private JRadioButton directedButton = null;
	private ButtonGroup typeGroup = null;  
	private JLabel jLabel5 = null;
	private JPanel typeButtonsPanel = null; 
	private JPanel datasourcePanel = null;
	private JPanel pajekPanel = null;
	private JLabel jLabel6 = null;
	private JButton switchPajekButton = null;
	private JPanel switchPajekPanel = null;
	private JPanel filePanel = null;
	private JPanel switchDatasourcePanel = null;
	private JTextField fileField = null;
	private JButton browseButton = null;
	private JPanel numberPanel = null;
	private JPanel fixNumberPanel = null;
	private JButton fixNumberButton = null;
	private JPanel dsNumberPanel = null;
	private JComboBox nrOfNodesParam = null;
	private JButton dsNumberButton = null;
	private JPanel otherPanel = null;
	private JPanel nodesOnePanel = null;
	private JPanel nodesTwoPanel = null;
	private JButton switchDatasourceButton = null;
	private JPanel paramPanel2 = null;
	private JPanel paramPanel1 = null;
	private JPanel maxIterationPanel = null;
	private JTextField maxIterationField = new JTextField("1");
	private JLabel jLabel7 = null; 
	private JComboBox appearanceBox = null;
	
	private JPanel appearanceTab = null;
	private JPanel appearancePanel = null;
	private JPanel colorMainPanel = null;
	private JPanel constantPanel = null;
	private JRadioButton constantRadioButton = null;
	private JPanel dsPanel = null;
	private JRadioButton dsRadioButton = null;
	private JComboBox colorParam = null;
	private JButton colorAdvancedButton = null;
	private JPanel colorMapParentPanel = null;
	private ColorMapPanel colorMapPanel = null;
	private JPanel vertexSizePanel = null;
	@SuppressWarnings("unused")
	private JComboBox vertexSizeParam = null;
	private JPanel vertexSizeLine = null;
	private JLabel vertexLabel = null;
	private JTextField vertexSizeField = null;
	private JLabel emptyLabel = null;
	//  @jve:decl-index=0:
	
	//============================================================================
	// additional members
	
	/** Array of destination combobox: contains all acceptable data sources. */
	private Object[] forDestAll = null;
	
	/** Array of destination combobox: contains only ISeriesProducer supporters. */
	private Object[] forDestSeries = null;
	
	/** Array of destination combobox: contains only IValueProducer supporters. */
	private Object[] forDestValue = null;
	
	/** Flag that determines the source of the data: file (when the value is <code>
	 *  true</code> or data source(s) otherwise.
	 */
	private boolean pajekFile = false;
	
	/** Flag that determines the kind of the number of nodes value: constant when
	 *  the flag is <code>true</code> or producer otherwise.
	 */
	private boolean user_defined_number = false;
	
	//============================================================================
	// methods
	
	/** Constructor. 
 	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public NetworkChartDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
	}
	
	//----------------------------------------------------------------------------
	/** This method initializes <code>this</code>. */
	private void initialize() {
		typeGroup = new ButtonGroup();
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.setPreferredSize(new Dimension(609, 219));
        this.setMinimumSize(new Dimension(609, 219));
        this.add(getTabbed(), null);
        this.add(getButtonsPanel(), null);
	}

	//----------------------------------------------------------------------------
	private JTabbedPane getTabbed() {
		if (tabbed == null) {
			tabbed = new JTabbedPane();
			tabbed.addTab("Main Settings", null, getMainPanel(), null);
			tabbed.addTab("Details", null, getDetailsPanel(), null);
			tabbed.addTab("Appearance",null,getAppearanceTab(),null);
		}
		return tabbed;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JPanel getAppearanceTab() {
		if (appearanceTab == null) {
			appearanceTab = new JPanel();
			appearanceTab.setLayout(new BoxLayout(appearanceTab,BoxLayout.Y_AXIS));
			appearanceTab.add(getAppearancePanel());
			appearanceTab.add(getColorMainPanel());
			appearanceTab.add(getVertexSizePanel());
		}
		return appearanceTab;
	}
	
	private Component getVertexSizePanel() {
		if (vertexSizePanel == null) {
			vertexSizePanel = new JPanel();
			vertexSizePanel.setLayout(new BoxLayout(vertexSizePanel,BoxLayout.X_AXIS));
			vertexSizePanel.setAlignmentX(0f);
			vertexSizePanel.add(new JLabel(" Vertex size:  "));
			vertexSizePanel.add(getVertexSizeLine());
		}
		return vertexSizePanel;
	}

	
	private JPanel getVertexSizeLine() {
		if (vertexSizeLine == null) {
			vertexLabel = new JLabel();
			vertexLabel.setText(" %");
			vertexSizeLine = new JPanel();
			vertexSizeLine.setLayout(new BoxLayout(getVertexSizeLine(), BoxLayout.X_AXIS));
			
			vertexSizeLine.add(getVertexSizeField(), null);
			vertexSizeLine.add(vertexLabel, null);
		}
		return vertexSizeLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getVertexSizeField() {
		if (vertexSizeField == null) {
			vertexSizeField = new JTextField();
			vertexSizeField.setText("100");
			vertexSizeField.setMaximumSize(new Dimension(160, 30));
			vertexSizeField.setHorizontalAlignment(JTextField.TRAILING);
			vertexSizeField.setPreferredSize(new Dimension(75, 30));
			vertexSizeField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					Pattern p = Pattern.compile("^[1-9][0-9]*$");
					Matcher positive = p.matcher(vertexSizeField.getText().trim());
					try {
						if (!positive.matches())
							throw new NumberFormatException();
						Integer.parseInt(vertexSizeField.getText().trim());
					} catch (NumberFormatException ee) {
						JOptionPane.showMessageDialog(NetworkChartDialog.this,"Invalid value in field 'Max. count of displayed items'.","Warning",JOptionPane.WARNING_MESSAGE,null);
						vertexSizeField.setText("100");
						vertexSizeField.grabFocus();
						vertexSizeField.selectAll();
					}
					properties.setProperty(ChartConstants.VERTEX_SIZE_PERCENTAGE,vertexSizeField.getText());
				}
			});
		}
		return vertexSizeField;
	}
	
	
	//----------------------------------------------------------------------------------------------------
	private JPanel getAppearancePanel() {
		if (appearancePanel == null) {
			appearancePanel = new JPanel();
			appearancePanel.setLayout(new BoxLayout(appearancePanel,BoxLayout.X_AXIS));
			appearancePanel.setAlignmentX(0f);
			appearancePanel.add(new JLabel(" Appearance:  "));
			appearancePanel.add(getAppearanceBox());
		}
		return appearancePanel;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JPanel getColorMainPanel() {
		if (colorMainPanel == null) {
			colorMainPanel = new JPanel();
			colorMainPanel.setLayout(new BoxLayout(colorMainPanel,BoxLayout.Y_AXIS));
			colorMainPanel.setBorder(BorderFactory.createTitledBorder("Color of the nodes"));
			colorMainPanel.setAlignmentX(0f);
			colorMainPanel.add(getConstantPanel());
			colorMainPanel.add(getDsPanel());
			colorMainPanel.add(Box.createRigidArea(new Dimension(0,5)));
			colorMainPanel.add(getColorMapParentPanel());
			constantRadioButton.doClick();
		}
		return colorMainPanel;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JPanel getConstantPanel() {
		if (constantPanel == null) {
			constantPanel = new JPanel();
			constantPanel.setLayout(new BoxLayout(constantPanel,BoxLayout.X_AXIS));
			constantPanel.setAlignmentX(0f);
			constantRadioButton = new JRadioButton("Constant color : ");
			constantRadioButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					colorLabel.setEnabled(true);
					changeButton.setEnabled(true);
					CardLayout cl = (CardLayout) colorMapParentPanel.getLayout();
					cl.show(colorMapParentPanel,"EMPTY_CARD");
					colorParam.setEnabled(false);
					colorAdvancedButton.setEnabled(false);
				}
			});
			constantPanel.add(constantRadioButton);
			colorLabel = new JLabel();
			colorLabel.setText("<html><tt><font style=\"background-color:#FF0000\">&nbsp;&nbsp;&nbsp;</font></tt>&nbsp;&nbsp;</html>");
			colorLabel.setHorizontalAlignment(SwingConstants.CENTER);
			colorLabel.setMaximumSize(new Dimension(75, 32));
			colorLabel.setPreferredSize(new Dimension(75, 32));
			constantPanel.add(colorLabel);
			constantPanel.add(getChangeButton());
			
		}
		return constantPanel;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JPanel getDsPanel() {
		if (dsPanel == null) {
			dsPanel = new JPanel();
			dsPanel.setLayout(new BoxLayout(dsPanel,BoxLayout.X_AXIS));
			dsPanel.setAlignmentX(0f);
			dsRadioButton = new JRadioButton("Node color from data source: ");
			ButtonGroup group = new ButtonGroup();
			group.add(constantRadioButton);
			group.add(dsRadioButton);
			dsRadioButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					colorParam.setEnabled(true);
					IDataSourceProducer dsp = (IDataSourceProducer) colorParam.getSelectedItem();
					colorAdvancedButton.setEnabled(dsp != null && dsp.hasAdvancedSettings());
					CardLayout cl = (CardLayout) colorMapParentPanel.getLayout();
					cl.show(colorMapParentPanel,"CMP_CARD");
					colorLabel.setEnabled(false);
					changeButton.setEnabled(false);
				}
			});
			dsPanel.add(dsRadioButton);
			colorParam = new JComboBox(getParamsToColorValues()); 
			colorParam.setRenderer(new DataSourceComboBoxRenderer(colorParam));
			colorParam.setPreferredSize(new Dimension(100,22));
			colorParam.setMaximumSize(new Dimension(200,26));
			if (colorParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)colorParam.getSelectedItem();
				colorParam.setToolTipText(dsp.toString());
			}
			colorParam.addActionListener(new ActionListener() {
				@SuppressWarnings("unchecked")
				public void actionPerformed(ActionEvent event) {
					displayButton.setEnabled(isUpdateable());
					if (isUpdateable()) ChartDialogChangeCenter.fireSaveEnabled(NetworkChartDialog.this);
					else ChartDialogChangeCenter.fireSaveDisabled(NetworkChartDialog.this);
					IDataSourceProducer dsp = (IDataSourceProducer)colorParam.getSelectedItem();
					colorParam.setToolTipText(dsp.toString());
					colorAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
					try {
						List<Double> list = (List<Double>)ChartConfigCollection.getLOPExecutor().execute("Calculating minimum/maximum values",dsp,"getRange");
						setMinMax(list);
					} catch (UserBreakException e1) { 
						setMinMax(null);
					} catch (Throwable t) {
						ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
					}
				}
				
				private void setMinMax(List<Double> minmax) {
					if (minmax != null) {
						colorMapPanel.setMinValue(String.valueOf(minmax.get(0).doubleValue()));
						colorMapPanel.setMaxValue(String.valueOf(minmax.get(1).doubleValue()));
					} else {
						colorMapPanel.setMinValue("");
						colorMapPanel.setMaxValue("");
					}
				}
 			});
			dsPanel.add(Box.createRigidArea(new Dimension(10,0)));
			dsPanel.add(colorParam);
			dsPanel.add(Box.createRigidArea(new Dimension(10,0)));
			colorAdvancedButton = new JButton("Advanced...");
			colorAdvancedButton.setEnabled(false);
			if (colorParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) colorParam.getSelectedItem();
				colorAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
			colorAdvancedButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					IDataSourceProducer dsp = (IDataSourceProducer) colorParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(NetworkChartDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = colorParam.getSelectedIndex();
						colorParam.removeItemAt(index);
						colorParam.insertItemAt(new_dsp,index);
						colorParam.setSelectedIndex(index);
					}
				}
			});
			dsPanel.add(colorAdvancedButton);
		}
		return dsPanel;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JPanel getColorMapParentPanel() {
		if (colorMapParentPanel == null) {
			colorMapParentPanel = new JPanel(new CardLayout());
			colorMapParentPanel.setAlignmentX(0f);
			colorMapParentPanel.setPreferredSize(new Dimension(609,26));
			colorMapParentPanel.setMaximumSize(new Dimension(609,26));
			emptyLabel = new JLabel(" ");
			emptyLabel.setName("EMPTY_CARD");
			colorMapPanel = new ColorMapPanel(this);
			colorMapPanel.setName("CMP_CARD");
			colorMapParentPanel.add(emptyLabel.getName(),emptyLabel);
			colorMapParentPanel.add(colorMapPanel.getName(),colorMapPanel);
		}
		return colorMapParentPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(new CardLayout());
			mainPanel.add(getDatasourcePanel(), getDatasourcePanel().getName());
			mainPanel.add(getPajekPanel(), getPajekPanel().getName());
		}
		return mainPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getFirstPanel() {
		if (firstPanel == null) {
			GridLayout gridLayout = new GridLayout();
			gridLayout.setRows(1);
			firstPanel = new JPanel();
			firstPanel.setLayout(gridLayout);
			firstPanel.add(getEdgePanel(), null);
			firstPanel.add(getAdditionalPanel(), null);
		}
		return firstPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getEdgePanel() {
		if (edgePanel == null) {
			edgePanel = new JPanel();
			edgePanel.setLayout(new BoxLayout(getEdgePanel(), BoxLayout.X_AXIS));
			edgePanel.setBorder(BorderFactory.createTitledBorder(null, "Edges, source nodes or adjacency matrix", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			edgePanel.add(getEdgeParam(), null);
			edgePanel.add(Box.createRigidArea(new Dimension(10,0)));
			edgePanel.add(getEdgeAdvancedButton(), null);
		}
		return edgePanel;
	}

	//----------------------------------------------------------------------------
	private JComboBox getEdgeParam() {
		if (edgeParam == null) {
			edgeParam = new JComboBox(getParamsToEdges());
			edgeParam.setRenderer(new DataSourceComboBoxRenderer(edgeParam));
			edgeParam.setPreferredSize(new Dimension(100,26));
			if (edgeParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
				edgeParam.setToolTipText(dsp.toString());
			}
			edgeParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
					edgeParam.setToolTipText(dsp.toString());
					edgeAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
					List<Class> ds = dsp.getSupportedIntfs();
					if (ds.contains(IXYSeriesProducer.class)) {
						// edges from one data source
						setEnabledAdditionalWidgets(true);
						additionalParam.setEnabled(false);
						additionalAdvancedButton.setEnabled(false);
					} else if (ds.contains(IAdjacencyMatrixProducer.class)) {
						setEnabledAdditionalWidgets(false);
					} else {
						setEnabledAdditionalWidgets(true);
						// edges from two data sources
						IDataSourceProducer old = null;
						if (additionalParam.getItemCount() > 0)
							old = (IDataSourceProducer)additionalParam.getSelectedItem();
						if (!ds.contains(ISeriesProducer.class)) {
							// dsp supports only IValueProducer => get out the
							// just-series-producer-supporters from the other
							// combobox.
							additionalParam.setModel(new DefaultComboBoxModel(getValueParamsToDestNodes()));
						} else if (!ds.contains(IValueProducer.class)) {
							// dsp supports only ISeriesProducer => get out the
							// just-value-producer-supporters from the other
							// combobox.
							additionalParam.setModel(new DefaultComboBoxModel(getSeriesParamsToDestNodes()));
						} else {
							additionalParam.setModel(new DefaultComboBoxModel(getParamsToDestNodes()));
						}
						if (additionalParam.getItemCount()>0)  {
							if (old != null) {
								for (int i=0;i<additionalParam.getItemCount();++i) {
									if (additionalParam.getItemAt(i).equals(old)) {
										additionalParam.setSelectedIndex(i);
										break;
									}
								}
							}
							additionalParam.setEnabled(true);
							IDataSourceProducer adsp = (IDataSourceProducer)additionalParam.getSelectedItem();
							additionalAdvancedButton.setEnabled(adsp.hasAdvancedSettings());
						}
					}
					enabledDisabledButtons();
				}
			});
		}
		return edgeParam;
	}

	//----------------------------------------------------------------------------
	private JButton getEdgeAdvancedButton() {
		if (edgeAdvancedButton == null) {
			edgeAdvancedButton = new JButton();
			edgeAdvancedButton.setText("Advanced...");
			edgeAdvancedButton.setEnabled(false);
			edgeAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(NetworkChartDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = edgeParam.getSelectedIndex();
						edgeParam.removeItemAt(index);
						edgeParam.insertItemAt(new_dsp,index);
						edgeParam.setSelectedIndex(index);
					}
				}
			});
			if (edgeParam.getItemCount()>0) {
				IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
				edgeAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return edgeAdvancedButton;
	}

	//----------------------------------------------------------------------------
	private JTextField getNodesField() {
		if (nodesField == null) {
			nodesField = new JTextField();
			nodesField.setMaximumSize(new Dimension(2147483647, 26));
			nodesField.setText("5");
			nodesField.setHorizontalAlignment(JTextField.TRAILING);
			nodesField.addCaretListener(new javax.swing.event.CaretListener() {
				public void caretUpdate(javax.swing.event.CaretEvent e) {
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(NetworkChartDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(NetworkChartDialog.this);
					}
				}
			});
			nodesField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid_non()) {
						nodesField.setText("");
					}
				}
			});
		}
		return nodesField;
	}

	//----------------------------------------------------------------------------
	private JPanel getNodesPanel() {
		if (nodesPanel == null) {
			nodesPanel = new JPanel();
			nodesPanel.setLayout(new BoxLayout(getNodesPanel(), BoxLayout.Y_AXIS));
			nodesPanel.setBorder(BorderFactory.createTitledBorder(null, "Node informations", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			nodesPanel.add(getNodesOnePanel(), null);
			nodesPanel.add(Box.createRigidArea(new Dimension(0,5)));
			nodesPanel.add(getNodesTwoPanel(), null);
		}
		return nodesPanel;
	}

	//----------------------------------------------------------------------------
	private JCheckBox getHasLabelsBox() {
		if (hasLabelsBox == null) {
			hasLabelsBox = new JCheckBox();
			hasLabelsBox.setText("Labelled nodes  ");
			hasLabelsBox.addItemListener(new java.awt.event.ItemListener() {
				public void itemStateChanged(java.awt.event.ItemEvent e) {
					if (e.getStateChange() == ItemEvent.SELECTED) {
						labelParam.setEnabled(true);
						IDataSourceProducer dsp = (IDataSourceProducer) labelParam.getSelectedItem();
						labelAdvancedButton.setEnabled(dsp != null && dsp.hasAdvancedSettings());
					} else {
						labelParam.setEnabled(false);
						labelAdvancedButton.setEnabled(false);
					}
				}
			});
		}
		return hasLabelsBox;
	}

	//----------------------------------------------------------------------------
	private JPanel getLabelSourcePanel() {
		if (labelSourcePanel == null) {
			labelSourcePanel = new JPanel();
			labelSourcePanel.setLayout(new BoxLayout(getLabelSourcePanel(), BoxLayout.X_AXIS));
			labelSourcePanel.setEnabled(false);
			labelSourcePanel.add(getLabelParam(), null);
			labelSourcePanel.add(Box.createRigidArea(new Dimension(10,0)));
			labelSourcePanel.add(getLabelAdvancedButton(), null);
		}
		return labelSourcePanel;
	}

	//----------------------------------------------------------------------------
	private JComboBox getLabelParam() {
		if (labelParam == null) {
			labelParam = new JComboBox(getParamsToNodeLabels());
			labelParam.setRenderer(new DataSourceComboBoxRenderer(labelParam));
			labelParam.setEnabled(false);
			labelParam.setPreferredSize(new Dimension(200, 26));
			if (labelParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)labelParam.getSelectedItem();
				labelParam.setToolTipText(dsp.toString());
			}
			labelParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)labelParam.getSelectedItem();
					labelParam.setToolTipText(dsp.toString());
					labelAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
				}
			});
		}
		return labelParam;
	}

	//----------------------------------------------------------------------------
	private JButton getLabelAdvancedButton() {
		if (labelAdvancedButton == null) {
			labelAdvancedButton = new JButton();
			labelAdvancedButton.setText("Advanced...");
			labelAdvancedButton.setEnabled(false);
			labelAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)labelParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(NetworkChartDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = labelParam.getSelectedIndex();
						labelParam.removeItemAt(index);
						labelParam.insertItemAt(new_dsp,index);
						labelParam.setSelectedIndex(index);
					}
				}
			});
		}
		return labelAdvancedButton;
	}

	//----------------------------------------------------------------------------
	private JComboBox getLayoutCBox() {
		if (layoutCBox == null) {
			Object[] elements = new Object[] { GraphMetadata.FRUCHTERMAN_REINGOLD, GraphMetadata.KAMADA_KAWAI,
											   GraphMetadata.KAMADA_KAWAI_3D, GraphMetadata.MEYERS, 
											   GraphMetadata.CIRCLE, GraphMetadata.SPRING };
			layoutCBox = new JComboBox(elements);
			layoutCBox.setPreferredSize(new Dimension(200,26));
			layoutCBox.setMaximumSize(new Dimension(200,26));
			layoutCBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int index = layoutCBox.getSelectedIndex();
					CardLayout cl1 = (CardLayout)paramPanel1.getLayout();
					CardLayout cl2 = (CardLayout)paramPanel2.getLayout();
					if (index == 0) {
						cl1.show(paramPanel1,getMaxIterationPanel().getName());
						cl2.show(paramPanel2,getFRParamPanel().getName());
					} else if (index < 3) {
						cl1.show(paramPanel1,getMaxIterationPanel().getName());
						cl2.show(paramPanel2,jLabel2.getName());
					} else {
						cl1.show(paramPanel1,jLabel7.getName());
						cl2.show(paramPanel2,jLabel2.getName());
					}
				}
			});
		}
		return layoutCBox;
	}

	//----------------------------------------------------------------------------
	private JPanel getParamPanel() {
		if (paramPanel == null) {
			jLabel2 = new JLabel();
			jLabel2.setText("");
			jLabel2.setName("EMPTYPARAM");
			paramPanel = new JPanel();
			paramPanel.setLayout(new BoxLayout(paramPanel,BoxLayout.X_AXIS));
			paramPanel.add(getParamPanel2());
		}
		return paramPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getFRParamPanel() {
		if (FRParamPanel == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("  Attraction :  ");
			jLabel3 = new JLabel();
			jLabel3.setText("  Repulsion :  ");
			FRParamPanel = new JPanel();
			FRParamPanel.setName("FRPARAM");
			FRParamPanel.setLayout(new BoxLayout(getFRParamPanel(), BoxLayout.X_AXIS));
			FRParamPanel.add(jLabel3, null);
			FRParamPanel.add(getRepulsionSlider(), null);
			FRParamPanel.add(jLabel4, null);
			FRParamPanel.add(getAttractionSlider(), null);
		}
		return FRParamPanel;
	}
	
	//------------------------------------------------------------------------------
	private JPanel getParamPanel1() {
		if (paramPanel1 == null) {
			jLabel7 = new JLabel();
			jLabel7.setText("");
			jLabel7.setName("EMPTYPARAM2");
			paramPanel1 = new JPanel();
			paramPanel1.setLayout(new CardLayout());
			paramPanel1.add(getMaxIterationPanel(),"ITERPARAM");
			paramPanel1.add(jLabel7,"EMPTYPARAM2");
		}
		return paramPanel1;
	}
	
	//------------------------------------------------------------------------------
	private JPanel getParamPanel2() {
		if (paramPanel2 == null) {
			paramPanel2 = new JPanel();
			paramPanel2.setLayout(new CardLayout());
			paramPanel2.add(getFRParamPanel(),"FRPARAM");
			paramPanel2.add(jLabel2,"EMPTYPARAM");
		}
		return paramPanel2;
	}
	
	//----------------------------------------------------------------------------
	private JPanel getMaxIterationPanel() {
		if (maxIterationPanel == null) {
			maxIterationPanel = new JPanel();
			maxIterationPanel.setName("ITERPARAM");
			maxIterationPanel.setLayout(new BoxLayout(maxIterationPanel,BoxLayout.X_AXIS));
			maxIterationPanel.add(new JLabel("Number of iterations: "));
			maxIterationField.addFocusListener(new FocusAdapter() {
				@Override public void focusLost(FocusEvent e) {
					if (!is_valid())
						maxIterationField.setText("1");
				}
			});
			maxIterationField.setPreferredSize(new Dimension(50,22));
			maxIterationField.setMaximumSize(new Dimension(50,22));
			maxIterationField.setHorizontalAlignment(JTextField.TRAILING);
			maxIterationPanel.add(maxIterationField);
		}
		return maxIterationPanel;
	}

	//----------------------------------------------------------------------------
	private JSlider getRepulsionSlider() {
		if (repulsionSlider == null) {
			repulsionSlider = new JSlider(1,100,75);
			repulsionSlider.setToolTipText("Value: 0.75");
			repulsionSlider.addChangeListener(new javax.swing.event.ChangeListener() {
				public void stateChanged(javax.swing.event.ChangeEvent e) {
					double repulsion = ((double)repulsionSlider.getValue())/100;
					repulsionSlider.setToolTipText("Value: " + repulsion);
				}
			});
		}
		return repulsionSlider;
	}

	//----------------------------------------------------------------------------
	private JSlider getAttractionSlider() {
		if (attractionSlider == null) {
			attractionSlider = new JSlider(1,100,75);
			attractionSlider.setToolTipText("Value: 0.75");
			attractionSlider.addChangeListener(new javax.swing.event.ChangeListener() {
				public void stateChanged(javax.swing.event.ChangeEvent e) {
					double attraction = ((double)attractionSlider.getValue())/100;
					attractionSlider.setToolTipText("Value: " + attraction);
				}
			});
		}
		return attractionSlider;
	}

	//----------------------------------------------------------------------------
	private JPanel getButtonsPanel() {
		if (buttonsPanel == null) {
			buttonsPanel = new JPanel();
			buttonsPanel.setLayout(new FlowLayout());
			buttonsPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
			buttonsPanel.add(getEditorButton(), null);
			buttonsPanel.add(getDisplayButton(), null);
			buttonsPanel.add(getSaveButton(), null);
			buttonsPanel.add(getCancelButton(), null);
		}
		return buttonsPanel;
	}

	//----------------------------------------------------------------------------
	private JButton getDisplayButton() {
		if (displayButton == null) {
			displayButton = new JButton();
			displayButton.setText("Display");
			displayButton.setMnemonic(KeyEvent.VK_D);
			displayButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					displayChart();
				}
			});
		}
		return displayButton;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}

	//----------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setEnabled(false);
			saveButton.setText("Save");
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					saveCollection();
				}
			});
		}
		return saveButton;
	}

	//----------------------------------------------------------------------------
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMnemonic(KeyEvent.VK_C);
			cancelButton.setText("Cancel");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					notifyForHide();
				}
			});
		}
		return cancelButton;
	}

	//----------------------------------------------------------------------------
	private JPanel getDetailsPanel() {
		if (detailsPanel == null) {
			detailsPanel = new JPanel();
			detailsPanel.setLayout(new BoxLayout(getDetailsPanel(), BoxLayout.Y_AXIS));
			detailsPanel.setBorder(BorderFactory.createTitledBorder(null, "Titles, color and layout of the network", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			detailsPanel.add(getTitleLine(), null);
			detailsPanel.add(getSubtitleLine(), null);
			detailsPanel.add(getLayoutMainPanel(), null);
			detailsPanel.add(getParamPanel(),null);
		}
		return detailsPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getTitleLine() {
		if (titleLine == null) {
			jLabel8 = new JLabel();
			jLabel8.setText("  Title:  ");
			jLabel8.setMaximumSize(new Dimension(80, 20));
			jLabel8.setPreferredSize(new Dimension(80, 20));
			titleLine = new JPanel();
			titleLine.setLayout(new BoxLayout(getTitleLine(), BoxLayout.X_AXIS));
			titleLine.setPreferredSize(new Dimension(400, 20));
			titleLine.add(jLabel8, null);
			titleLine.add(getTitleField(), null);
		}
		return titleLine;
	}

	//----------------------------------------------------------------------------
	private JTextField getTitleField() {
		if (titleField == null) {
			titleField = new JTextField();
			titleField.setPreferredSize(new Dimension(300, 20));
			titleField.setMaximumSize(new Dimension(2147483647,30));
			titleField.setText(ChartConstants.NETWORK_NAME);
			titleField.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					subtitleField.grabFocus();
				}
			});
			titleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.TITLE,titleField.getText());
					ChartDialogChangeCenter.fireTitleChanged(NetworkChartDialog.this);
				}
			});
		}
		return titleField;
	}

	//----------------------------------------------------------------------------
	private JPanel getSubtitleLine() {
		if (subtitleLine == null) {
			jLabel9 = new JLabel();
			jLabel9.setText("  Subtitle:  ");
			jLabel9.setMaximumSize(new Dimension(80, 20));
			jLabel9.setPreferredSize(new Dimension(80, 20));
			subtitleLine = new JPanel();
			subtitleLine.setLayout(new BoxLayout(getSubtitleLine(), BoxLayout.X_AXIS));
			subtitleLine.setPreferredSize(new Dimension(400, 20));
			subtitleLine.add(jLabel9, null);
			subtitleLine.add(getSubtitleField(), null);
		}
		return subtitleLine;
	}

	//----------------------------------------------------------------------------
	private JTextField getSubtitleField() {
		if (subtitleField == null) {
			subtitleField = new JTextField();
			subtitleField.setPreferredSize(new Dimension(300, 20));
			subtitleField.setMaximumSize(new Dimension(2147483647, 30));
			subtitleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
				}
			});
		}
		return subtitleField;
	}

	//----------------------------------------------------------------------------
	private JPanel getLayoutMainPanel() {
		if (layoutMainPanel == null) {
			JLabel tmpLabel = new JLabel("  Layout:   ");
			tmpLabel.setMaximumSize(new Dimension(80, 26));
			tmpLabel.setPreferredSize(new Dimension(80, 26));
			layoutMainPanel = new JPanel();
			layoutMainPanel.setLayout(new BoxLayout(getLayoutMainPanel(), BoxLayout.X_AXIS));
			layoutMainPanel.setPreferredSize(new Dimension(400, 26));
			layoutMainPanel.add(tmpLabel, null);
			layoutMainPanel.add(getLayoutCBox(), null);
			layoutMainPanel.add(Box.createRigidArea(new Dimension(10,0)));
			layoutMainPanel.add(getParamPanel1());
		}
		return layoutMainPanel;
	}

	//----------------------------------------------------------------------------
	private JButton getChangeButton() {
		if (changeButton == null) {
			changeButton = new JButton();
			changeButton.setText("Change Color...");
			changeButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int index = colorLabel.getText().indexOf('#');
					Color initial = new Color(Integer.decode(colorLabel.getText().substring(index,index+7)));
					Color chosen = JColorChooser.showDialog(NetworkChartDialog.this,"Color selection",initial);
					if (chosen != null) {
						String color = String.format("#%06x",chosen.getRGB() & 0xffffff);
						colorLabel.setText("<html><tt><font style=\"background-color:" + color + "\">&nbsp;&nbsp;&nbsp;</font></tt>&nbsp;&nbsp;</html>");
					}
				}
			});
		}
		return changeButton;
	}

	//----------------------------------------------------------------------------
	private JPanel getAdditionalPanel() {
		if (additionalPanel == null) {
			additionalPanel = new JPanel();
			additionalPanel.setLayout(new BoxLayout(getAdditionalPanel(), BoxLayout.X_AXIS));
			additionalPanel.setBorder(BorderFactory.createTitledBorder(null, "Destination nodes", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			additionalPanel.add(getAdditionalParam(), null);
			additionalPanel.add(Box.createRigidArea(new Dimension(10,0)));
			additionalPanel.add(getAdditionalAdvancedButton(), null);
		}
		return additionalPanel;
	}

	//----------------------------------------------------------------------------
	private JComboBox getAdditionalParam() {
		if (additionalParam == null) {
			additionalParam = new JComboBox(getParamsToDestNodes());
			additionalParam.setRenderer(new DataSourceComboBoxRenderer(additionalParam));
			additionalParam.setPreferredSize(new Dimension(100,26));
			if (additionalParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)additionalParam.getSelectedItem();
				additionalParam.setToolTipText(dsp.toString());
			}
			if (edgeParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
				List<Class> ds = dsp.getSupportedIntfs();
				if (ds.contains(IXYSeriesProducer.class)) additionalParam.setEnabled(false);
			}
			additionalParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)additionalParam.getSelectedItem();
					additionalParam.setToolTipText(dsp.toString());
					additionalAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
				}
			});
		}
		return additionalParam;
	}

	//----------------------------------------------------------------------------
	private JButton getAdditionalAdvancedButton() {
		if (additionalAdvancedButton == null) {
			additionalAdvancedButton = new JButton();
			additionalAdvancedButton.setEnabled(false);
			additionalAdvancedButton.setText("Advanced...");
			additionalAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)additionalParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(NetworkChartDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = additionalParam.getSelectedIndex();
						additionalParam.removeItemAt(index);
						additionalParam.insertItemAt(new_dsp,index);
						additionalParam.setSelectedIndex(index);
					}
				}
			});
			if (additionalParam.getItemCount() > 0 && additionalParam.isEnabled()) {
				IDataSourceProducer dsp = (IDataSourceProducer)additionalParam.getSelectedItem();
				additionalAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return additionalAdvancedButton;
	}
	
	//----------------------------------------------------------------------------
	private JPanel getTypePanel() {
		if (typePanel == null) {
			jLabel5 = new JLabel();
			jLabel5.setText(" Type of Network:");
			typePanel = new JPanel();
			typePanel.setLayout(new BorderLayout());
			typePanel.setMinimumSize(new Dimension(200, 40));
			typePanel.add(jLabel5, BorderLayout.NORTH);
			typePanel.add(new JLabel("                            "), BorderLayout.WEST);
			typePanel.add(getTypeButtonsPanel(), BorderLayout.CENTER);
			typePanel.add(getSwitchPajekPanel(), BorderLayout.SOUTH);
		}
		return typePanel;
	}

	//----------------------------------------------------------------------------
	private JRadioButton getUndirectedButton() {
		if (undirectedButton == null) {
			undirectedButton = new JRadioButton();
			undirectedButton.setSelected(true);
			undirectedButton.setText("Undirected network");
			undirectedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.UNDIRECTED,"true");
					
				}
			});
			typeGroup.add(undirectedButton);
		}
		return undirectedButton;
	}

	//----------------------------------------------------------------------------
	private JRadioButton getDirectedButton() {
		if (directedButton == null) {
			directedButton = new JRadioButton();
			directedButton.setText("Directed network");
			directedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.UNDIRECTED,"false");
				}
			});
			typeGroup.add(directedButton);
		}
		return directedButton;
	}

	//----------------------------------------------------------------------------
	private JPanel getTypeButtonsPanel() {
		if (typeButtonsPanel == null) {
			typeButtonsPanel = new JPanel();
			typeButtonsPanel.setLayout(new BoxLayout(getTypeButtonsPanel(), BoxLayout.Y_AXIS));
			typeButtonsPanel.add(getUndirectedButton(), null);
			typeButtonsPanel.add(getDirectedButton(), null);
		}
		return typeButtonsPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getDatasourcePanel() {
		if (datasourcePanel == null) {
			datasourcePanel = new JPanel();
			datasourcePanel.setLayout(new BoxLayout(getDatasourcePanel(), BoxLayout.Y_AXIS));
			datasourcePanel.setName("DATASOURCE");
			datasourcePanel.add(getFirstPanel(), null);
			datasourcePanel.add(getOtherPanel(), null);
		}
		return datasourcePanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getPajekPanel() {
		if (pajekPanel == null) {
			jLabel6 = new JLabel();
			jLabel6.setText("  File:  ");
			pajekPanel = new JPanel();
			pajekPanel.setLayout(new BorderLayout());
			pajekPanel.setName("PAJEK");
			pajekPanel.setBorder(BorderFactory.createEmptyBorder(5, 2, 10, 5));
			pajekPanel.add(getFilePanel(), BorderLayout.NORTH);
			pajekPanel.add(getSwitchDatasourcePanel(), BorderLayout.SOUTH);
		}
		return pajekPanel;
	}

	//----------------------------------------------------------------------------
	private JButton getSwitchPajekButton() {
		if (switchPajekButton == null) {
			switchPajekButton = new JButton();
			switchPajekButton.setText("Network from Pajek file");
			switchPajekButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					CardLayout cl = (CardLayout) getMainPanel().getLayout();
					cl.show(getMainPanel(),getPajekPanel().getName());
					pajekFile = true;
					if (getFileField().getText().trim().equals(""))
						selectPajekFile();
					else {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(NetworkChartDialog.this);
					}
				}
			});
		}
		return switchPajekButton;
	}

	//----------------------------------------------------------------------------
	private JPanel getSwitchPajekPanel() {
		if (switchPajekPanel == null) {
			switchPajekPanel = new JPanel();
			switchPajekPanel.setLayout(new BorderLayout());
			switchPajekPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 2, 2));
			switchPajekPanel.add(getSwitchPajekButton(), BorderLayout.EAST);
		}
		return switchPajekPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getFilePanel() {
		if (filePanel == null) {
			filePanel = new JPanel();
			filePanel.setLayout(new BoxLayout(getFilePanel(), BoxLayout.X_AXIS));
			filePanel.add(jLabel6, null);
			filePanel.add(getFileField(), null);
			filePanel.add(Box.createRigidArea(new Dimension(2,0)));
			filePanel.add(getBrowseButton(), null);
		}
		return filePanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getSwitchDatasourcePanel() {
		if (switchDatasourcePanel == null) {
			switchDatasourcePanel = new JPanel();
			switchDatasourcePanel.setLayout(new BorderLayout());
			switchDatasourcePanel.add(getSwitchDatasourceButton(), BorderLayout.EAST);
		}
		return switchDatasourcePanel;
	}

	//----------------------------------------------------------------------------
	private JTextField getFileField() {
		if (fileField == null) {
			fileField = new JTextField();
			fileField.setEditable(false);
		}
		return fileField;
	}

	//----------------------------------------------------------------------------
	private JButton getBrowseButton() {
		if (browseButton == null) {
			browseButton = new JButton();
			browseButton.setText(" Browse...");
			browseButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					selectPajekFile();
				}
			});
		}
		return browseButton;
	}

	//----------------------------------------------------------------------------
	private JButton getSwitchDatasourceButton() {
		if (switchDatasourceButton == null) {
			switchDatasourceButton = new JButton();
			switchDatasourceButton.setText("Network from data sources");
			switchDatasourceButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					CardLayout cl = (CardLayout)getMainPanel().getLayout();
					cl.show(getMainPanel(),getDatasourcePanel().getName());
					pajekFile = false;
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(NetworkChartDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(NetworkChartDialog.this);
					}
				}
			});
		}
		return switchDatasourceButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getNumberPanel() {
		if (numberPanel == null) {
			numberPanel = new JPanel();
			numberPanel.setLayout(new CardLayout());
			numberPanel.add(getDsNumberPanel(), getDsNumberPanel().getName());
			numberPanel.add(getFixNumberPanel(), getFixNumberPanel().getName());
		}
		return numberPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getFixNumberPanel() {
		if (fixNumberPanel == null) {
			fixNumberPanel = new JPanel();
			fixNumberPanel.setLayout(new BoxLayout(getFixNumberPanel(), BoxLayout.X_AXIS));
			fixNumberPanel.setName("FIX_NUMBER_PANEL");
			fixNumberPanel.add(getNodesField(), null);
			fixNumberPanel.add(Box.createRigidArea(new Dimension(5,0)));
			fixNumberPanel.add(getFixNumberButton(), null);
		}
		return fixNumberPanel;
	}

	//-----------------------------------------------------------------------------
	private JButton getFixNumberButton() {
		if (fixNumberButton == null) {
			fixNumberButton = new JButton();
			fixNumberButton.setText("From data source");
			fixNumberButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					user_defined_number = false;
					CardLayout cl = (CardLayout)numberPanel.getLayout();
					cl.show(numberPanel,"DS_NUMBER_PANEL");
//					if (nrOfNodesParam.getItemCount() > 0 && 
//						((dsRadioButton.isSelected() && colorMapPanel.hasDefinedColormap()) ||
//						 !dsRadioButton.isSelected())) {
//						displayButton.setEnabled(true);
//						ChartDialogChangeCenter.fireSaveEnabled(NetworkChartDialog.this);
//					}
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(NetworkChartDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(NetworkChartDialog.this);
					}
				}
			});
		}
		return fixNumberButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getDsNumberPanel() {
		if (dsNumberPanel == null) {
			dsNumberPanel = new JPanel();
			dsNumberPanel.setLayout(new BoxLayout(getDsNumberPanel(), BoxLayout.X_AXIS));
			dsNumberPanel.setName("DS_NUMBER_PANEL");
			dsNumberPanel.add(getNrOfNodesParam(), null);
			dsNumberPanel.add(Box.createRigidArea(new Dimension(5,0)));
			dsNumberPanel.add(getDsNumberButton(), null);
		}
		return dsNumberPanel;
	}

	//-----------------------------------------------------------------------------
	private JComboBox getNrOfNodesParam() {
		if (nrOfNodesParam == null) {
			nrOfNodesParam = new JComboBox(getParamsToNumberOfNodes());
			nrOfNodesParam.setRenderer(new DataSourceComboBoxRenderer(nrOfNodesParam));
			nrOfNodesParam.setPreferredSize(new Dimension(100,26));
			if (nrOfNodesParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)nrOfNodesParam.getSelectedItem();
				nrOfNodesParam.setToolTipText(dsp.toString());
			}
			nrOfNodesParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)nrOfNodesParam.getSelectedItem();
					nrOfNodesParam.setToolTipText(dsp.toString());
				}
			});
		}
		return nrOfNodesParam;
	}

	//-----------------------------------------------------------------------------
	private JButton getDsNumberButton() {
		if (dsNumberButton == null) {
			dsNumberButton = new JButton();
			dsNumberButton.setText("From user input");
			dsNumberButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					user_defined_number = true;
					CardLayout cl = (CardLayout)numberPanel.getLayout();
					cl.show(numberPanel,"FIX_NUMBER_PANEL");
//					if (!isUpdateable()) {
//						displayButton.setEnabled(false);
//						ChartDialogChangeCenter.fireSaveDisabled(NetworkChartDialog.this);
//					}
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(NetworkChartDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(NetworkChartDialog.this);
					}
				}
			});
		}
		return dsNumberButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getOtherPanel() {
		if (otherPanel == null) {
			otherPanel = new JPanel();
			otherPanel.setLayout(new BoxLayout(getOtherPanel(), BoxLayout.X_AXIS));
			otherPanel.add(getNodesPanel(), null);
			otherPanel.add(getTypePanel(), null);
		}
		return otherPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getNodesOnePanel() {
		if (nodesOnePanel == null) {
			jLabel = new JLabel();
			jLabel.setText("  Number of nodes :  ");
			nodesOnePanel = new JPanel();
			nodesOnePanel.setLayout(new BoxLayout(getNodesOnePanel(), BoxLayout.X_AXIS));
			nodesOnePanel.add(jLabel, null);
			nodesOnePanel.add(getNumberPanel(), null);
		}
		return nodesOnePanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getNodesTwoPanel() {
		if (nodesTwoPanel == null) {
			nodesTwoPanel = new JPanel();
			nodesTwoPanel.setLayout(new BoxLayout(getNodesTwoPanel(), BoxLayout.X_AXIS));
			nodesTwoPanel.add(getHasLabelsBox(), null);
			nodesTwoPanel.add(getLabelSourcePanel(), null);
		}
		return nodesTwoPanel;
	}
	
	//-----------------------------------------------------------------------------
	private JComboBox getAppearanceBox() {
		if (appearanceBox == null) {
			Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
			appearances.add(new ComboboxItem("N","Normal"));
			for (String templateNames : AbstractChart.templates.keySet())
				appearances.add(new ComboboxItem("_" + templateNames,templateNames));
			appearances.add(new ComboboxItem("_NEW","New template..."));
			appearances.add(new ComboboxItem("_EDIT","Edit template..."));
			appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
			appearanceBox = new JComboBox(appearances);
			appearanceBox.setPreferredSize(new Dimension(154,25));
			appearanceBox.setMaximumSize(new Dimension(154,25));
			appearanceBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String id = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
					if (id.equals("_NEW")) {
						ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.GRAPH);
						int result = dlg.showDialog();
						if (result == ChartPropertiesDialog.OK_OPTION) {
							Element newTemplate = (Element) dlg.getTemplate();
							dlg.dispose();
							String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
							AbstractChart.templates.put(name,newTemplate);
							ChartDialogChangeCenter.fireTemplateChanged();
							appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
						} else 
							appearanceBox.setSelectedIndex(0);
					} else if (id.equals("_EDIT")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(NetworkChartDialog.this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(NetworkChartDialog.this,"Select a template: ","Edit template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template == null || "".equals(template)) 
							appearanceBox.setSelectedIndex(0);
						else {
							Element templateElement = AbstractChart.templates.get(template);
							ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(),ChartKind.GRAPH);
							int result = dlg.showDialog();
							if (result == ChartPropertiesDialog.OK_OPTION) {
								Element newTemplate = (Element) dlg.getTemplate();
								dlg.dispose();
								String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
								AbstractChart.templates.put(name,newTemplate);
								ChartDialogChangeCenter.fireTemplateChanged();
								appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
							} else 
								appearanceBox.setSelectedIndex(0);
						}
					} else if (id.equals("_REMOVE")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(NetworkChartDialog.this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(NetworkChartDialog.this,"Select a template: ","Delete template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template != null && !"".equals(template)) { 
							AbstractChart.templates.remove(template);
							File file = new File("Templates/" + template + ".xml");
							file.delete();
							ChartDialogChangeCenter.fireTemplateChanged();
						}
						appearanceBox.setSelectedIndex(0);
					}
				}
			});
		}
		return appearanceBox;
	}

	//------------------------------------------------------------------------------
	private List<String> getLegends() {	return new ArrayList<String>(); }
	
	//=============================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-generated functions                                                //
	////////////////////////////////////////////////////////////////////////////
	
	//----------------------------------------------------------------------------------------------------
	@Override
	public boolean isUpdateable() {
		if (pajekFile) return !getFileField().getText().trim().equals("");
		if (dsRadioButton.isSelected() && !colorMapPanel.hasDefinedColormap()) return false;
		if (edgeParam.getItemCount()== 0) return false;
		IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
		if (dsp.getSupportedIntfs().contains(IAdjacencyMatrixProducer.class)) return true;
		if (user_defined_number && !is_valid_non()) return false;
		if (!user_defined_number && nrOfNodesParam.getItemCount() == 0) return false;
		if (dsp.getSupportedIntfs().contains(IXYSeriesProducer.class)) return true;
		if (additionalParam.getItemCount() == 0) return false;
		return true;
	}

	//----------------------------------------------------------------------------
	@Override
	protected void setSettingsFromConfig() {
		if (config.getChartProperties() instanceof Properties) {
			// set settings from config
			properties = (Properties) config.getChartProperties();
			String pajekFile = properties.getProperty(ChartConstants.PAJEK_FILE,"");
			if (!pajekFile.equals("")) {
				this.pajekFile = true;
				CardLayout cl = (CardLayout)getMainPanel().getLayout();
				cl.show(getMainPanel(),getPajekPanel().getName());
				getFileField().setText(pajekFile);
			} else {
				String[] ds = properties.getProperty(ChartConstants.DATASOURCE).split(",");
				int[] gds = Utilities.splitDatasourceAroundSpace(ds[0]);
				IDataSourceProducer dsp = config.getDataSource(gds[0]);
				edgeParam.setSelectedItem(dsp);
				if (gds.length == 1) { //IXYSeriesProducer or IAdjacencyMatrixProducer
					additionalParam.setEnabled(false);
					additionalAdvancedButton.setEnabled(false);
				} else { // two ISeriesProducers or two IValueProducers
					IDataSourceProducer adsp = config.getDataSource(gds[1]);
					additionalParam.setSelectedItem(adsp);
				}
				if (ds.length == 1) { // no labels
					hasLabelsBox.setSelected(false);
					labelParam.setEnabled(false);
					labelAdvancedButton.setEnabled(false);
				} else {
					hasLabelsBox.setSelected(true);
					IDataSourceProducer ldsp = config.getDataSource(Integer.parseInt(ds[1]));
					labelParam.setSelectedItem(ldsp);
				}
				user_defined_number = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_NUMBER,"true"));
				if (user_defined_number) {
					CardLayout cl = (CardLayout)numberPanel.getLayout();
					cl.show(numberPanel,"FIX_NUMBER_PANEL");
					nodesField.setText(properties.getProperty(ChartConstants.NR_OF_NODES));
				} else {
					nodesField.setText("5");
					IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.NR_OF_NODES)));
					nrOfNodesParam.setSelectedItem(vp);
				}
				boolean undirected = Boolean.parseBoolean(properties.getProperty(ChartConstants.UNDIRECTED));
				if (!undirected) directedButton.setSelected(true);
			}
			layoutCBox.setSelectedItem(properties.getProperty(ChartConstants.LAYOUT));
			repulsionSlider.setValue((int)(Double.parseDouble(properties.getProperty(ChartConstants.REPULSION))*100));
			attractionSlider.setValue((int)(Double.parseDouble(properties.getProperty(ChartConstants.ATTRACTION))*100));
			titleField.setText(properties.getProperty(ChartConstants.TITLE));
			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
			maxIterationField.setText(properties.getProperty(ChartConstants.NR_OF_ITERATIONS,"1"));
			vertexSizeField.setText(properties.getProperty(ChartConstants.VERTEX_SIZE_PERCENTAGE));
			
			boolean dynamic_node_color = Boolean.parseBoolean(properties.getProperty(ChartConstants.DYNAMIC_NODE_COLOR,"false"));
			if (dynamic_node_color) {
				dsRadioButton.setSelected(true);
				colorParam.setEnabled(true);
				int cds_id = Integer.parseInt(properties.getProperty(ChartConstants.NODE_COLOR));
				IDataSourceProducer dsp = config.getDataSource(cds_id);
				colorParam.setSelectedItem(dsp);
				colorAdvancedButton.setEnabled(dsp != null && dsp.hasAdvancedSettings());
				CardLayout cl = (CardLayout) colorMapParentPanel.getLayout();
				cl.show(colorMapParentPanel,"CMP_CARD");
				colorMapPanel.settingsFromString(properties.getProperty(ChartConstants.COLORMAP),false);
				colorLabel.setEnabled(false);
				changeButton.setEnabled(false);
				colorLabel.setText("<html><tt><font style=\"background-color: #FF0000 \">&nbsp;&nbsp;&nbsp;</font></tt>&nbsp;&nbsp;</html>");
			} else 
				colorLabel.setText("<html><tt><font style=\"background-color:" + properties.getProperty(ChartConstants.NODE_COLOR) + "\">&nbsp;&nbsp;&nbsp;</font></tt>&nbsp;&nbsp;</html>");
			saveButton.setEnabled(true);
			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
		} else {
			//set the initial properties
			properties.setProperty(ChartConstants.UNDIRECTED,"true");
			properties.setProperty(ChartConstants.USER_DEFINED_NUMBER,"false");
			properties.setProperty(ChartConstants.REPULSION,"0.75");
			properties.setProperty(ChartConstants.ATTRACTION,"0.75");
			properties.setProperty(ChartConstants.TITLE,ChartConstants.NETWORK_NAME);
			properties.setProperty(ChartConstants.SUBTITLE,"");
			properties.setProperty(ChartConstants.NR_OF_ITERATIONS,"1");
			properties.setProperty(ChartConstants.VERTEX_SIZE_PERCENTAGE,"100");
 			// initial dest params
 			if (edgeParam.getItemCount() > 0)
 				edgeParam.setSelectedIndex(0);
		}
	}

	//----------------------------------------------------------------------------
	@Override
	protected void setWidgetDisabled() {
		if (edgeParam.getItemCount() == 0) {
			edgeParam.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			edgeAdvancedButton.setEnabled(false);
			hasLabelsBox.setEnabled(false);
			fixNumberButton.setEnabled(false);
			dsNumberButton.setEnabled(false);
		}
		if (additionalParam.getItemCount() == 0) {
			additionalParam.setEnabled(false);
			additionalAdvancedButton.setEnabled(false);
		}
		if (labelParam.getItemCount() == 0) {
			labelParam.setEnabled(false);
			labelAdvancedButton.setEnabled(false);
			hasLabelsBox.setEnabled(false);
		}
		if (nrOfNodesParam.getItemCount() == 0) {
			nrOfNodesParam.setEnabled(false);
			fixNumberButton.setEnabled(false);
		}
		if (colorParam.getItemCount() == 0) 
			dsRadioButton.setEnabled(false);
	}
	
	//----------------------------------------------------------------------------
	private void setEnabledAdditionalWidgets(boolean enabled) {
		if (additionalParam.getItemCount() != 0) {
			additionalParam.setEnabled(enabled);
		}
		additionalAdvancedButton.setEnabled(enabled);
		jLabel.setEnabled(enabled);
		nodesField.setEnabled(enabled);
		fixNumberButton.setEnabled(enabled);
		nrOfNodesParam.setEnabled(enabled && nrOfNodesParam.getItemCount() > 0);
		dsNumberButton.setEnabled(enabled);
		hasLabelsBox.setEnabled(enabled && labelParam.getItemCount() > 0);
		hasLabelsBox.setSelected(false);
	}
	
	//----------------------------------------------------------------------------
	private void enabledDisabledButtons() {
		if (isUpdateable()) {
			displayButton.setEnabled(true);
			ChartDialogChangeCenter.fireSaveEnabled(this);
		} else {
			displayButton.setEnabled(false);
			ChartDialogChangeCenter.fireSaveDisabled(this);
		}
	}

	//----------------------------------------------------------------------------
	@Override
	public void updateChartConfig() {
		config.clearAllDataSource();
		if (pajekFile) {
			properties.setProperty(ChartConstants.PAJEK_FILE,getFileField().getText().trim());
			properties.setProperty(ChartConstants.DATASOURCE,"");
		} else {
			String ds = "";
			IDataSourceProducer dsp = (IDataSourceProducer)edgeParam.getSelectedItem();
			int key = -1;
			if (dsp.getSupportedIntfs().contains(IXYSeriesProducer.class)) {
				key = config.addDataSource(dsp,IXYSeriesProducer.class);
				ds += String.valueOf(key) + ",";
			} else if (dsp.getSupportedIntfs().contains(IAdjacencyMatrixProducer.class)) {
				key = config.addDataSource(dsp,IAdjacencyMatrixProducer.class);
				ds += String.valueOf(key) + ",";
			} else {
				IDataSourceProducer ddsp = (IDataSourceProducer)additionalParam.getSelectedItem();
				boolean edgeIsSeries = dsp.getSupportedIntfs().contains(ISeriesProducer.class);
				boolean destIsSeries = ddsp.getSupportedIntfs().contains(ISeriesProducer.class);
				int eKey = -1, dKey = -1;
				if (edgeIsSeries && destIsSeries) {
					eKey = config.addDataSource(dsp,ISeriesProducer.class);
					dKey = config.addDataSource(ddsp,ISeriesProducer.class);
				} else if (!edgeIsSeries && !destIsSeries) {
					eKey = config.addDataSource(dsp,IValueProducer.class);
					dKey = config.addDataSource(ddsp,IValueProducer.class);
				}
				ds += String.valueOf(eKey) + " ";
				ds += String.valueOf(dKey) + ",";
			}
			properties.setProperty(ChartConstants.USER_DEFINED_NUMBER,String.valueOf(user_defined_number));
			if (dsp.getSupportedIntfs().contains(IAdjacencyMatrixProducer.class)) {
				properties.setProperty(ChartConstants.NR_OF_NODES,"5");
				properties.setProperty(ChartConstants.USER_DEFINED_NUMBER,"true");
			} else if (user_defined_number)
				properties.setProperty(ChartConstants.NR_OF_NODES,nodesField.getText());
			else {
				dsp = (IDataSourceProducer)nrOfNodesParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IValueProducer.class))
					key = config.addDataSource(dsp,IValueProducer.class);
				else { // need emulation
					key = config.addDataSource(dsp,ISeriesProducer.class);
				}
				properties.setProperty(ChartConstants.NR_OF_NODES,String.valueOf(key));
			}
			if (hasLabelsBox.isSelected()) {
				dsp = (IDataSourceProducer)labelParam.getSelectedItem();
				if (dsp.getSupportedIntfs().contains(IStringListProducer.class)) {
					key = config.addDataSource(dsp,IStringListProducer.class);
				} else {
					key = config.addDataSource(dsp, IStringSeriesProducer.class);
				}
				ds += String.valueOf(key) + ",";
			}
			properties.setProperty(ChartConstants.DATASOURCE,ds.substring(0,ds.length()-1));
			properties.setProperty(ChartConstants.PAJEK_FILE,"");
		}
		String selectedItem = (String)layoutCBox.getSelectedItem();
		properties.setProperty(ChartConstants.LAYOUT,selectedItem);
		if (selectedItem.equals(GraphMetadata.FRUCHTERMAN_REINGOLD) ||
			selectedItem.equals(GraphMetadata.KAMADA_KAWAI) ||
			selectedItem.equals(GraphMetadata.KAMADA_KAWAI_3D)) {
			int number = is_valid() ? Integer.parseInt(maxIterationField.getText()) : 1;
			properties.setProperty(ChartConstants.NR_OF_ITERATIONS,String.valueOf(number));
		} else
			properties.setProperty(ChartConstants.NR_OF_ITERATIONS,"-1");
		double repulsion = ((double)repulsionSlider.getValue())/100;
		properties.setProperty(ChartConstants.REPULSION,String.valueOf(repulsion));
		double attraction = ((double)attractionSlider.getValue())/100;
		properties.setProperty(ChartConstants.ATTRACTION,String.valueOf(attraction));
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex == 0) 
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
		else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
		properties.setProperty(ChartConstants.DYNAMIC_NODE_COLOR,String.valueOf(dsRadioButton.isSelected()));
		if (dsRadioButton.isSelected()) {
			IDataSourceProducer dsp = (IDataSourceProducer) colorParam.getSelectedItem();
			int key = -1;
			if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
	 			key = config.addDataSource(dsp,ISeriesProducer.class);
	 		else key = config.addDataSource(dsp,IValueProducer.class);
			properties.setProperty(ChartConstants.NODE_COLOR,String.valueOf(key));
	 		properties.setProperty(ChartConstants.COLORMAP,colorMapPanel.settingsToString());
		} else {
			int index = colorLabel.getText().indexOf('#');
			String color_str = colorLabel.getText().substring(index,index+7);
			properties.setProperty(ChartConstants.NODE_COLOR,color_str);
			properties.setProperty(ChartConstants.COLORMAP,"");
		}
		
		config.setChartProperties(ChartConstants.NETWORK,properties);
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that support <code>
	 *  ISeriesProducer</code>, <code>IValueProducer</code>, <code>
	 *  IXYSeriesProducer</code> or <code>IAdjacencyMatrixProducer</code> interfaces.
	 * @return array of data sources
	 */
	private Object[] getParamsToEdges() {
		return getParams(new Class[] { IXYSeriesProducer.class, IAdjacencyMatrixProducer.class });
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data soruces that support the 
	 *  <code>ISeriesProducer</code> and/or <code>IValueProducer<code> interfaces.
	 * @return array of data sources
	 */
	private Object[] getParamsToDestNodes() {
		if (forDestAll == null) {
			forDestAll = getParams(new Class[] { ISeriesProducer.class, IValueProducer.class });
		}
		return forDestAll;
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that support only the
	 *  <code>ISeriesProducer</code> interface.
	 * @return array of data sources
	 */
	private Object[] getSeriesParamsToDestNodes() {
		if (forDestSeries == null) {
			forDestSeries = getParams(ISeriesProducer.class,IValueProducer.class);
		}
		return forDestSeries;
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that support only the
	 *  <code>IValueProducer</code> interface.
	 * @return array of data sources
	 */
	private Object[] getValueParamsToDestNodes() {
		if (forDestValue == null) {
			forDestValue = getParams(IValueProducer.class,ISeriesProducer.class);
		}
		return forDestValue;
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that supports the
	 * {@link ai.aitia.chart.ds.IStringListProducer IStringListProducer }.
	 * 
	 * @return array of data sources.
	 */
	private Object[] getParamsToNodeLabels() {
		return getParams(IStringListProducer.class);
	}
	
	//----------------------------------------------------------------------------------------------------
	private Object[] getParamsToColorValues() {
		return getParams(ISeriesProducer.class);
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources that support the <code>
	 *  IValueProducer</code> and <code>ISeriesProducer</code> interfaces.
	 */
	private Object[] getParamsToNumberOfNodes() {
		return getParams(IValueProducer.class);
	}
	
	//----------------------------------------------------------------------------
	/** Returns whether the <code>nodesField</code> contains a valid integer that
	 *  greater than 0 or not.
	 */
	private boolean is_valid_non() {
		Pattern p = Pattern.compile("^[1-9][0-9]*$"); // pattern for number of nodes
		Matcher m = p.matcher(nodesField.getText().trim());
		if (m.matches()) {
			try {
				Integer.parseInt(nodesField.getText().trim());
				return true;
			} catch (NumberFormatException e) {}
		}
		return false;
	}

	//----------------------------------------------------------------------------
	@Override
	protected void displayPreview() throws Exception {
		DataSources ds = new DataSources(new SimpleDSPCollection());
		ChartConfig temp_config = new ChartConfig(ds);
		temp_config.setFireInitialEvent(true);
		Properties temp_prop = (Properties)properties.clone();
		if (!pajekFile) {
			List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
			temp_config.addDataSource(dsl.get(0),ISeriesProducer.class);
			temp_config.addDataSource(dsl.get(1),ISeriesProducer.class);
			temp_config.addDataSource(dsl.get(3),IStringSeriesProducer.class);
			temp_prop.setProperty(ChartConstants.DATASOURCE,"1 2,3");
			temp_prop.setProperty(ChartConstants.TITLE,temp_prop.getProperty(ChartConstants.TITLE) + " (Preview Illustration)");
			if (!user_defined_number) {
				temp_prop.setProperty(ChartConstants.USER_DEFINED_NUMBER,"true");
				temp_prop.setProperty(ChartConstants.NR_OF_NODES,"5");
			}
			if (dsRadioButton.isSelected()) {
				temp_prop.setProperty(ChartConstants.DYNAMIC_NODE_COLOR,"true");
				temp_prop.setProperty(ChartConstants.NODE_COLOR,"1");
			}
		}
		temp_config.setChartProperties(ChartConstants.NETWORK,temp_prop);
		Utilities.displayPreview(temp_config);
	}
	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "N",  "Normal"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem)appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		// reset widgets
		edgeParam.setEnabled(true);
		edgeAdvancedButton.setEnabled(true);
		hasLabelsBox.setEnabled(true);
		fixNumberButton.setEnabled(true);
		dsNumberButton.setEnabled(true);
		additionalParam.setEnabled(true);
		additionalAdvancedButton.setEnabled(true);
		labelParam.setEnabled(true);
		labelAdvancedButton.setEnabled(true);
		nrOfNodesParam.setEnabled(true);
		fixNumberButton.setEnabled(true);
		dsRadioButton.setEnabled(true);
		
		Object edgeObject = edgeParam.getSelectedIndex() == -1 ? null : edgeParam.getSelectedItem();
		Object additionalObject = additionalParam.getSelectedIndex() == -1 ? null : additionalParam.getSelectedItem();
		Object labelObject = labelParam.getSelectedIndex() == -1 ? null : labelParam.getSelectedItem();
		Object nrObject = nrOfNodesParam.getSelectedIndex() == -1 ? null : nrOfNodesParam.getSelectedItem();
		Object colorObject = colorParam.getSelectedIndex() == -1 ? null : colorParam.getSelectedItem();
		
		DefaultComboBoxModel edgeModel = new DefaultComboBoxModel(getParamsToEdges());
		edgeParam.setModel(edgeModel);
		forDestAll = forDestSeries = forDestValue = null;
		DefaultComboBoxModel additionalModel = new DefaultComboBoxModel(getParamsToDestNodes());
		additionalParam.setModel(additionalModel);
		DefaultComboBoxModel labelModel = new DefaultComboBoxModel(getParamsToNodeLabels());
		labelParam.setModel(labelModel);
		DefaultComboBoxModel nrModel = new DefaultComboBoxModel(getParamsToNumberOfNodes());
		nrOfNodesParam.setModel(nrModel);
		DefaultComboBoxModel colorModel = new DefaultComboBoxModel(getParamsToColorValues());
		colorParam.setModel(colorModel);
		
		if (additionalObject != null && findInComboBox(additionalModel,(IDataSourceProducer)additionalObject) != -1)  {
			int idx = findInComboBox(additionalModel,(IDataSourceProducer)additionalObject);
			additionalParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (edgeObject != null && findInComboBox(edgeModel,(IDataSourceProducer)edgeObject) != -1) {
			int idx = findInComboBox(edgeModel,(IDataSourceProducer)edgeObject);
			edgeParam.setSelectedIndex(idx >= 0 ? idx : 0);
		} else if (edgeParam.getItemCount() > 0)
			edgeParam.setSelectedIndex(0);
		if (labelObject != null && findInComboBox(labelModel,(IDataSourceProducer)labelObject) != -1)  {
			int idx = findInComboBox(labelModel,(IDataSourceProducer)labelObject);
			labelParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (nrObject != null && findInComboBox(nrModel,(IDataSourceProducer)nrObject) != -1) {
			int idx = findInComboBox(nrModel,(IDataSourceProducer)nrObject);
			nrOfNodesParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (colorObject != null && findInComboBox(colorModel,(IDataSourceProducer)colorObject) != -1) {
			int idx = findInComboBox(colorModel,(IDataSourceProducer)colorObject);
			colorParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		
		validate();
		setWidgetDisabled();
		
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}
	
	//-----------------------------------------------------------------------------
	/** Opens a file dialog to select a Pajek file, the updates (if need) the 'File'
	 *  textfield with the name and path of the selected file. It also sets the display
	 *  and save statuses (if need).
	 */ 
	private void selectPajekFile() {
		JFileChooser chooser = new JFileChooser(GlobalHandlers.getLastDirectory());
		chooser.addChoosableFileFilter(new ExtensionFileFilter("Pajek files (*.net)",".net"));
		int returnVal = chooser.showOpenDialog(this);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			getFileField().setText(chooser.getSelectedFile().getPath());
			getFileField().setToolTipText(chooser.getSelectedFile().getPath());
		}
		if (!getFileField().getText().trim().equals("")) {
			displayButton.setEnabled(true);
			ChartDialogChangeCenter.fireSaveEnabled(this);
		} else {
			displayButton.setEnabled(false);
			ChartDialogChangeCenter.fireSaveDisabled(this);
		}
	}
	
	//-------------------------------------------------------------------------------
	/** Returns whether the input string contains a valid integer that greater than
	 *  or equal to 0 or not;
	 */
	private boolean is_valid() {
		Pattern p = Pattern.compile("^[0-9]|[1-9][0-9]+$"); // pattern for number of intervals
		Matcher m = p.matcher(maxIterationField.getText().trim());
		if (m.matches()) {
			try {
				Integer.parseInt(maxIterationField.getText().trim());
				return true;
			} catch (NumberFormatException e) {}
		}
		return false;
	}

	//----------------------------------------------------------------------------------------------------
	public IDataSourceProducer getColorValueProducer() {
		return (IDataSourceProducer) colorParam.getSelectedItem();
	}

	//----------------------------------------------------------------------------------------------------
	public void setUpdateStatus(boolean status) {
		boolean paramAvailable = edgeParam.getItemCount() > 0;
		displayButton.setEnabled(paramAvailable && status);
		if (paramAvailable && status)
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}
}	