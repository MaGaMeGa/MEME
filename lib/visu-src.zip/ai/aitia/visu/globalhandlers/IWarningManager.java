package ai.aitia.visu.globalhandlers;

public interface IWarningManager {
	public boolean shouldDumpWarnings();
}
