package ai.aitia.chart.charttypes;

import java.awt.Container;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.JPanel;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.Grid3DDialog;
import ai.aitia.chart.ds.Grid3DDatasetProducer;
import ai.aitia.chart.ds.Grid3DDatasetProducer_DiagramLayer;
import ai.aitia.chart.ds.Grid3DDatasetProducer_ObjectLayer;
import ai.aitia.chart.ds.Grid3DDatasetProducer_SurfaceLayer;
import ai.aitia.chart.ds.IGrid3DDatasetProducer;
import ai.aitia.chart.emulator.ProducerEmulator;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLLoadingException;
import ai.aitia.chart.view.ui.AutomaticFigureRenderer;
import ai.aitia.visu.VisualisationException;
import ai.aitia.visu.ds.DataSourceException;
import ai.aitia.visu.ds.IDataProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.view.ChartFactory;
import ai.aitia.visu.view.meta.Grid3DMetadata;
import ai.aitia.visu.view.ui.ColorMap;
import ai.aitia.visu.view.ui.ColorMapFigureRenderer;
import ai.aitia.visu.view.ui.IFigureRenderer;

public class Grid3D extends AbstractChart {

	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings({ "unchecked", "cast" })
	@Override
	public JPanel createChart(ChartConfig config) throws DataSourceException, VisualisationException {
		if (config.getChartProperties() instanceof List) { // List<Properties>
			
			List<Properties> properties = (List<Properties>) config.getChartProperties();
			
			Properties common = properties.get(0);
			
	 		Grid3DMetadata[] metas = new Grid3DMetadata[properties.size()];
	 		
	 		metas[0] = new Grid3DMetadata();
	 	
			metas[0].setTitle(common.getProperty(ChartConstants.TITLE));
			metas[0].setSubTitle(common.getProperty(ChartConstants.SUBTITLE));
			metas[0].setRowLabel(common.getProperty(ChartConstants.ROW_LABEL));
			metas[0].setColumnLabel(common.getProperty(ChartConstants.COLUMN_LABEL));
			metas[0].setBackgroundFile(common.getProperty(ChartConstants.BACKGROUND_FILE));
			/*
			String templateName = common.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			boolean needDefault = true;
			if (templateName != null && !"".equals(templateName)) {
				Element template = templates.get(templateName);
				if (template != null) {
					try {
						CustomAppearance appearance = createCustomAppearance(template);
						meta.setCustomAppearance(appearance);
						needDefault = false;
					} catch (TemplateLoadingException e) {
						throw new VisualisationException(e);
					}
				}
			}
			if (needDefault) {
				int env = Appearance.BASIC_APP;
				if (common.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP))
					env = Appearance.NORMAL_APP;
				meta.setEnvironmentAppearance(env);
			}
			*/
			Grid3DDatasetProducer[] datasetProducers = new Grid3DDatasetProducer[properties.size() - 1];
			List<IFigureRenderer> renderers = new ArrayList<IFigureRenderer>(properties.size() - 1);
			
			List<List<IDataProducer>> producers = new ArrayList<List<IDataProducer>>();
			for (int i = 1;i < properties.size();++i) {

				List<IDataProducer> pros = new ArrayList<IDataProducer>(5);
				/** Color, X, Y, Shape, Z value, Radius (only at object layer)*/
				IDataProducer cp = null, xp = null, yp = null, sp = null, zp = null, rp = null;
				IValueProducer wp = null, hp = null;
				IGrid3DDatasetProducer dp = null;
				Properties prop = properties.get(i);
				
				// renderer
				String colormapStr = prop.getProperty(ChartConstants.COLORMAP,"");
				if (colormapStr != null && !"".equals(colormapStr)) {
					ColorMap colormap = Utilities.createColorMapFromString(colormapStr);
					float globalAlpha = Float.parseFloat(prop.getProperty(ChartConstants.GLOBAL_ALPHA,"-1"));
					renderers.add(new ColorMapFigureRenderer(colormap,globalAlpha));
					metas[i] = new Grid3DMetadata();
					metas[i].setColorMap(colormap);
				} else {
					String rendererStr = prop.getProperty(ChartConstants.SHAPE_RENDERER);
					try {
						renderers.add(Utilities.createShapeRendererFromString(rendererStr));
					} catch (Exception e) {
						renderers.add(new AutomaticFigureRenderer());
					}
				}

				
				//set the layer preferences
				metas[i].setRadius(Float.valueOf(prop.getProperty(ChartConstants.RADIUS)));
				metas[i].setPadding(Float.valueOf(prop.getProperty(ChartConstants.PADDING)));
				metas[i].setTranslate(Float.valueOf(prop.getProperty(ChartConstants.TRANSLATE)));
				/*if (prop.getProperty(ChartConstants.SHOW_BASE) == "true")
				{
					metas[i].setShowBase(true);//(Boolean.valueOf(prop.getProperty(ChartConstants.SHOW_BASE)).booleanValue());
				}
				else
				{
					metas[i].setShowBase(false);
				}*/
				metas[i].setShowBase(Boolean.parseBoolean(prop.getProperty(ChartConstants.SHOW_BASE)));
				metas[i].setTitle(prop.getProperty(ChartConstants.TITLE));
				metas[i].setSubTitle(prop.getProperty(ChartConstants.SUBTITLE));
				metas[i].setRowLabel(prop.getProperty(ChartConstants.ROW_LABEL));
				metas[i].setColumnLabel(prop.getProperty(ChartConstants.COLUMN_LABEL));
				metas[i].setColorBarVisible(Boolean.parseBoolean(prop.getProperty(ChartConstants.SHOW_COLORBAR)));
				metas[i].setAxisVisible(Boolean.parseBoolean(prop.getProperty(ChartConstants.SHOW_AXIS)));
				

				// dataset
				int[] sources = Utilities.splitDatasourceAroundCommas(prop.getProperty(ChartConstants.DATASOURCE));
				int width = -2, height = -2;
				boolean user_defined_width = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_WIDTH));
				if (user_defined_width) {
					String str_width = prop.getProperty(ChartConstants.WIDTH);
					width = str_width.equals("") ? -1 : Integer.parseInt(str_width);
				} else {
					int key = Integer.parseInt(prop.getProperty(ChartConstants.WIDTH));
					IDataSourceProducer wdsp = config.getDataSource(key);
					IDataProducer idp = wdsp.createDataProducer(config.getDataSourceType(key),null);
					if (idp instanceof IValueProducer) // wdsp supports IValueProducer
						wp = (IValueProducer) idp;
					else { // wdsp supports only ISeriesProducer
						List<IDataProducer> p = new ArrayList<IDataProducer>();
						p.add(idp);
						wp = (IValueProducer) ProducerEmulator.createProducer(p,IValueProducer.class);
					}
					pros.add(wp);
				}
				boolean user_defined_height = Boolean.parseBoolean(prop.getProperty(ChartConstants.USER_DEFINED_HEIGHT));
				if (user_defined_height) {
					String str_height = prop.getProperty(ChartConstants.HEIGHT);
					height = str_height.equals("") ? -1 : Integer.parseInt(str_height);
				} else {
					int key = Integer.parseInt(prop.getProperty(ChartConstants.HEIGHT));
					IDataSourceProducer hdsp = config.getDataSource(key);
					IDataProducer idp = hdsp.createDataProducer(config.getDataSourceType(key),null);
					if (idp instanceof IValueProducer) // hdsp supports IValueProducer
						hp = (IValueProducer) idp;
					else { // hdsp supports only ISeriesProducer
						List<IDataProducer> p = new ArrayList<IDataProducer>();
						p.add(idp);
						hp = (IValueProducer) ProducerEmulator.createProducer(p,IValueProducer.class);
					}
					pros.add(hp);
				}
				List<Object> params = new ArrayList<Object>();
				//2 - surface, 3 - diagram, 4 - object
	
				if (sources.length == 2 || sources.length == 3 || (sources.length == 4 && !prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.SURFACE_LAYER))) { //mivel ha 4 a length, az lehet surface partial is, de ha 4 a hossz, �s surface, az tuti partial!!
					if (config.getDataSourceType(sources[0]).equals(IGrid3DDatasetProducer.class)) { // datasource type is IGrid3DDatasetProducer
						IDataSourceProducer ddsp = config.getDataSource(sources[0]);
						dp = (IGrid3DDatasetProducer) ddsp.createDataProducer(config.getDataSourceType(sources[0]),null);
						pros.add(dp);
						
						if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.DIAGRAM_LAYER))
						{
							datasetProducers[i - 1] = new Grid3DDatasetProducer_DiagramLayer(dp);
						}
						else if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.SURFACE_LAYER))
						{
							datasetProducers[i - 1] = new Grid3DDatasetProducer_SurfaceLayer(dp);
						}
						else if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.OBJECT_LAYER))
						{
							datasetProducers[i - 1] = new Grid3DDatasetProducer_ObjectLayer(dp);
						}
					} else {
						boolean row_order = Boolean.parseBoolean(prop.getProperty(ChartConstants.ROW_ORDER));
						
						IDataSourceProducer zdsp = config.getDataSource(sources[0]);
						zp = zdsp.createDataProducer(config.getDataSourceType(sources[0]),null); // values producer
						if (zp instanceof ISeriesProducer)
							params.add(zp); 
						else {
							List<IDataProducer> p = new ArrayList<IDataProducer>(1);
							p.add(zp);
							zp = (ISeriesProducer) ProducerEmulator.createProducer(p,ISeriesProducer.class);
							params.add(zp);
						}
						pros.add(zp);
						
						IDataSourceProducer cdsp = config.getDataSource(sources[1]);
						cp = cdsp.createDataProducer(config.getDataSourceType(sources[1]),null); // values producer
						if (cp instanceof ISeriesProducer)
							params.add(cp); 
						else {
							List<IDataProducer> p = new ArrayList<IDataProducer>(1);
							p.add(cp);
							cp = (ISeriesProducer) ProducerEmulator.createProducer(p,ISeriesProducer.class);
							params.add(cp);
						}
						pros.add(cp);
						
						if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.DIAGRAM_LAYER) || prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.OBJECT_LAYER))
						{
							if (sources.length < 3) throw new DataSourceException("Missing input parameters!");
							IDataSourceProducer sdsp = config.getDataSource(sources[2]);
							sp = sdsp.createDataProducer(config.getDataSourceType(sources[2]),null); // values producer
							if (sp instanceof ISeriesProducer)
								params.add(sp); 
							else {
								List<IDataProducer> p = new ArrayList<IDataProducer>(1);
								p.add(cp);
								sp = (ISeriesProducer) ProducerEmulator.createProducer(p,ISeriesProducer.class);
								params.add(sp);
							}
							pros.add(sp);
						}
						
						if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.OBJECT_LAYER))
						{
							if (sources.length < 4) throw new DataSourceException("Missing input parameters!");
							IDataSourceProducer rdsp = config.getDataSource(sources[3]);
							rp = rdsp.createDataProducer(config.getDataSourceType(sources[3]),null); // values producer
							if (rp instanceof ISeriesProducer)
								params.add(rp); 
							else {
								List<IDataProducer> p = new ArrayList<IDataProducer>(1);
								p.add(rp);
								rp = (ISeriesProducer) ProducerEmulator.createProducer(p,ISeriesProducer.class);
								params.add(rp);
							}
							pros.add(rp);
						}
						if (user_defined_width)
							params.add(new Integer(width)); // fix width
						else
							params.add(wp); // width value producer
						if (user_defined_height)
							params.add(new Integer(height)); // fix height
						else
							params.add(hp); // height value producer
						
						if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.DIAGRAM_LAYER))
						{
							datasetProducers[i - 1] = new Grid3DDatasetProducer_DiagramLayer(params,row_order);
						}
						else if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.SURFACE_LAYER))
						{
							datasetProducers[i - 1] = new Grid3DDatasetProducer_SurfaceLayer(params,row_order);
						}
						else if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.OBJECT_LAYER))
						{
							datasetProducers[i - 1] = new Grid3DDatasetProducer_ObjectLayer(params,row_order);
						}
						//datasetProducers[i - 1] = new Grid3DDatasetProducer_SurfaceLayer(params,row_order);
					}
				} else {
					IDataSourceProducer xdsp = config.getDataSource(sources[0]);
					xp = xdsp.createDataProducer(config.getDataSourceType(sources[0]),null); // column indices producer
					if (xp instanceof ISeriesProducer)
						params.add(xp);
					else {
						List<IDataProducer> p = new ArrayList<IDataProducer>(1);
						p.add(xp);
						xp = (ISeriesProducer) ProducerEmulator.createProducer(p,ISeriesProducer.class);
						params.add(xp);
					}
					pros.add(xp);
					IDataSourceProducer ydsp = config.getDataSource(sources[1]);
					yp = ydsp.createDataProducer(config.getDataSourceType(sources[1]),null); // row indices producer
					if (yp instanceof ISeriesProducer)
						params.add(yp);
					else {
						List<IDataProducer> p = new ArrayList<IDataProducer>(1);
						p.add(yp);
						yp = (ISeriesProducer)ProducerEmulator.createProducer(p,ISeriesProducer.class);
						params.add(yp);
					}
					pros.add(yp);
					
					IDataSourceProducer zdsp = config.getDataSource(sources[2]);
					zp = zdsp.createDataProducer(config.getDataSourceType(sources[2]),null); // values producer
					if (zp instanceof ISeriesProducer)
						params.add(zp);
					else {
						List<IDataProducer> p = new ArrayList<IDataProducer>(1);
						p.add(zp);
						zp = (ISeriesProducer)ProducerEmulator.createProducer(p,ISeriesProducer.class);
						params.add(zp);
					}
					pros.add(zp);
					
					IDataSourceProducer cdsp = config.getDataSource(sources[3]);
					cp = cdsp.createDataProducer(config.getDataSourceType(sources[3]),null); // values producer
					if (cp instanceof ISeriesProducer)
						params.add(cp);
					else {
						List<IDataProducer> p = new ArrayList<IDataProducer>(1);
						p.add(cp);
						cp = (ISeriesProducer)ProducerEmulator.createProducer(p,ISeriesProducer.class);
						params.add(cp);
					}
					pros.add(cp);
					
					//Need shape only, if it's a diagram layer or an object layer
					if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.DIAGRAM_LAYER) || prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.OBJECT_LAYER))
					{
						if (sources.length < 5) throw new DataSourceException("Missing input parameters!");
						IDataSourceProducer sdsp = config.getDataSource(sources[4]);
						sp = sdsp.createDataProducer(config.getDataSourceType(sources[4]),null); // values producer
						if (sp instanceof ISeriesProducer)
							params.add(sp);
						else {
							List<IDataProducer> p = new ArrayList<IDataProducer>(1);
							p.add(sp);
							sp = (ISeriesProducer)ProducerEmulator.createProducer(p,ISeriesProducer.class);
							params.add(sp);
						}
						pros.add(sp);
					}

					//Need Radius only, if it's an object layer
					if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.OBJECT_LAYER))
					{
						if (sources.length < 6) throw new DataSourceException("Missing input parameters!");
						IDataSourceProducer rdsp = config.getDataSource(sources[5]);
						rp = rdsp.createDataProducer(config.getDataSourceType(sources[5]),null); // values producer
						if (rp instanceof ISeriesProducer)
							params.add(rp);
						else {
							List<IDataProducer> p = new ArrayList<IDataProducer>(1);
							p.add(rp);
							rp = (ISeriesProducer)ProducerEmulator.createProducer(p,ISeriesProducer.class);
							params.add(rp);
						}
						pros.add(rp);
					}
					
					if (user_defined_width)
						params.add(new Integer(width)); // fix width
					else
						params.add(wp); // width value producer
					if (user_defined_height)
						params.add(new Integer(height)); // fix height
					else
						params.add(hp); // height value producer
					
					if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.DIAGRAM_LAYER))
					{
						datasetProducers[i - 1] = new Grid3DDatasetProducer_DiagramLayer(params);
					}
					else if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.SURFACE_LAYER))
					{
						datasetProducers[i - 1] = new Grid3DDatasetProducer_SurfaceLayer(params);
					}
					else if (prop.getProperty(ChartConstants.TYPE).equals(ChartConstants.OBJECT_LAYER))
					{
						datasetProducers[i - 1] = new Grid3DDatasetProducer_ObjectLayer(params);
					}
				}
				producers.add(pros);
				
				metas[i].addFigureRenderers(renderers);
			}
			
			
			
			//JFreeChart chart = null;
			JPanel chart = null;
			if (config.isFireInitialEvent()) {
				for (int i = 0; i < datasetProducers.length;++i) {
					for (IDataProducer p : producers.get(i))
						datasetProducers[i].dataChanged(new DataChangeEvent(p));
				}
			}
			
			
			
			//meta.setColorMap(colorMap);
			chart = ChartFactory.createGrid3DChart(datasetProducers,metas);
			//CustomSaveableChartPanel panel = new CustomSaveableChartPanel(chart);
			
			//if (meta.getCustomAppearance() != null && meta.getCustomAppearance().getDimension() != null)
			//	panel.setPreferredSize(meta.getCustomAppearance().getDimension());
			
			//return panel;
			return chart;		
		}	
		return null;
	}

	//----------------------------------------------------------------------------------------------------
	@Override
	public Container createDialog(ChartConfig config, ChartConfigCollection collection) {
		return new Grid3DDialog(config,collection);
	}

	//----------------------------------------------------------------------------------------------------
	@Override public String getID() { return ChartConstants.GRID3D; }
	@Override public String toString() { return ChartConstants.GRID3D_NAME; }

	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> getDataSourceIDs(ChartConfig config) {
		List<Integer> result = new ArrayList<Integer>();
		if (config.getChartProperties() instanceof List) {
			List<Properties> props = (List<Properties>) config.getChartProperties();
			for (int i = 1;i < props.size();++i) {
				int[] ds = Utilities.splitDatasourceAroundCommas(props.get(i).getProperty(ChartConstants.DATASOURCE));
				for (int j = 0;j < ds.length;++j) 
					result.add(ds[j]);
				boolean user_defined_width = Boolean.parseBoolean(props.get(i).getProperty(ChartConstants.USER_DEFINED_WIDTH));
				if (!user_defined_width) {
					int candidate = Integer.parseInt(props.get(i).getProperty(ChartConstants.WIDTH));
					result.add(candidate);
				}
				boolean user_defined_height = Boolean.parseBoolean(props.get(i).getProperty(ChartConstants.USER_DEFINED_HEIGHT));
				if (!user_defined_height) {
					int candidate = Integer.parseInt(props.get(i).getProperty(ChartConstants.HEIGHT));
					result.add(candidate);
				}
			}
		}
		return result;
	}

	//----------------------------------------------------------------------------------------------------
	@Override
	public String getDescription() {
		return "The 3D Grid is a visualisation of one or more three-dimensional grids or matrices. Each" +
			   " grid or matrix appears on a different layer. It supports three visualisation modes:\n\nIn Surface mode" +
			   " a surface is drawn using interpolation on the given values.\nIn Diagram mode columns are drawn in each cell.\nAnd in Object mode a " +
			   "well-defined object (shape, size and colour can be specified) is appeared at the appropriate (x,y,z) coordinates." ;
	}

	//----------------------------------------------------------------------------------------------------
	@Override
	protected void loadChartProperties(ChartConfig config, Node node) throws XMLLoadingException {
		List<Properties> props = new ArrayList<Properties>();
		props.add(Utilities.readProperties(node)); // common properties
		NodeList nodes = ((Element)node).getElementsByTagName(ChartConstants.GRID_LAYERS);
		if (nodes == null || nodes.getLength() == 0)
			throw new XMLLoadingException("Invalid XML-file, missing tag: " + ChartConstants.GRID_LAYERS);
		Element gridLayersElement = (Element) nodes.item(0);
		nodes = gridLayersElement.getElementsByTagName(ChartConstants.GRID_LAYER);
		if (nodes == null || nodes.getLength() == 0)
			throw new XMLLoadingException("Invalid XML-file, missing tag: " + ChartConstants.GRID_LAYER);
		for (int i = 0;i < nodes.getLength();++i)
			props.add(Utilities.readProperties(nodes.item(i)));
		config.setChartProperties(getID(),props);
	}

	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	@Override
	protected void saveChartProperties(ChartConfig config, Node node) {
		if (config.getChartProperties() instanceof List) { // List<Properties>
			List<Properties> props = (List<Properties>) config.getChartProperties();
			Utilities.writeProperties(node,props.get(0)); // common properties;
			Document document = node.getOwnerDocument();
			
			Element gridLayersElement = document.createElement(ChartConstants.GRID_LAYERS);
			for (int i = 1; i < props.size();++i) {
				Element gridLayer = document.createElement(ChartConstants.GRID_LAYER);
				Utilities.writeProperties(gridLayer,props.get(i)); // properties of the i-th layer
				gridLayersElement.appendChild(gridLayer);
			}
			node.appendChild(gridLayersElement);
		}
	}
}
