/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart; 

import java.util.List;

import javax.swing.Icon;

import org.w3c.dom.Node;

import ai.aitia.visu.ds.IDataProducer;

/** Interface that represents a data source. */
public interface IDataSourceProducer {
	
	
	//public String getDisplayName();
	
	/** Get the display-name for the data source.
	 * @return display-name of the data source
	 */
	public String toString(); 
	
	//-------------------------------------------------------------------------------
	/** Returns the icon of the data source. <code>null</code> is permitted.
	 * @return icon of the data source 
	 */
	Icon getDisplayableIcon();
	
	//-------------------------------------------------------------------------------
	/** Get the list of data types that are directly supported by this data source.
	 * @return List of Java class-objects of IDataProducer-descendant interfaces.
	 */
	public List<Class> getSupportedIntfs();

	//-------------------------------------------------------------------------------
	/** Get the list of disallowed types for the data source. This list can be used
	 *  to disallow the otherwise automatic emulation of some interfaces 
	 *  for this data source.
	 * @return List of Java class-objects of IDataProducer-descendant interfaces.
	 */
	public List<Class> getDisabledIntfs();

	//-------------------------------------------------------------------------------
	/** Returns the smallest and largest possible values for the data source, or
	 *  <code>null</code> if these are nonsensical or unknown for the data source.
	 * @return A two-element List that contains the required values or <code>null</code>
	 */
	public List<Double> getRange();

	//-------------------------------------------------------------------------------
	/** Returns the possible values for the data source, or <code>null</code> if the
	 *  values cannot be enumerated. A number data source must return NumberStrPair
	 *  objects containing the number and the string representation of the possible values.    
	 *  A string data source must enumerate the text-number value pairs. <br>
	 *  If it returns <code>null</code>, those parts of the GUI in which the user can
	 *  assign things (like colors, shapes) to the different values of this data source
	 *  will be less useful, since the program cannot show the list of possible values.
	 *  In these cases the user can manually define possible values.<br>
	 * @return a List of NumberStrPair objects.
	 */
	public List<NumberStrPair> getElements();

	//-------------------------------------------------------------------------------
	/** Returns whether the data source has custom settings possibilites or not. */ 
	public boolean hasAdvancedSettings();

	//-------------------------------------------------------------------------------
	/** If {@link #hasAdvancedSettings() hasAdvancedSettings()} returns 
	 * <code>true</code>, this function should create a modal dialog in which the
	 *  user can modify the custom settings of <code>this</code> datasource. It should
	 *  return <code>null</code> if there're no advanced settings or the user has
	 *  canceled the dialog.  
	 * @param parent parent of the dialog
	 * @return A new data source containing the custom settings (it may be the same
	 *  as <code>this</code>).
	 */
	public IDataSourceProducer advancedSettingsDialog(java.awt.Component parent);

	//-------------------------------------------------------------------------------
	/** Save the access information of a data source into an XML node. The access
	 *  informations are implementation-dependent.
	 * @param node destination XML node
	 */
	public void save(Node node);

	//-------------------------------------------------------------------------------
	/** Creates an IDataProducer object that actually reads the real data from the
	 *  data source. This object must implement the <code>intf</code> interface and
	 *  must belong to the group represented by <code>grp</code>.
	 * @param intf an IDataProducer-descendant interface, one of those returned by   
	 *  {@link #getSupportedIntfs() getSupportedIntfs()}.
	 * @param grp a data source which controls the group (<code>null</code> means no grouping).
	 */
	public IDataProducer createDataProducer(Class intf, IDataSourceProducer grp);


	//===============================================================================
	/** An assistant class for the IDataSourceProducer interface to enumerate the
	 *  different possible elements of a data source. With this type a string data
	 *  source can enumerate the text-number value pairs. A number data source returns pairs
	 *  containing the number value and the string representation of the number. 
	 */
	public static class NumberStrPair implements Comparable<NumberStrPair> {

		private Number number;
		private String string;

		public NumberStrPair(Number number)					{ this(number, number.toString()); }
		public NumberStrPair(Number number, String string)	{ this.number = number; this.string = string; }

		@Override
		public String	toString()							{ return string; }
		public void	setString(String string)			{ this.string = string; }
		public Number	getNumber() 						{ return number; }
		@Override
		public int hashCode()								{ return number.hashCode() + string.hashCode(); }
		@Override
		public boolean	equals(Object o) {
			if (o instanceof NumberStrPair)
				return compareTo((NumberStrPair)o) == 0;
			return super.equals(o);
		}
		public int compareTo(NumberStrPair o) {
			double diff = number.doubleValue() - o.number.doubleValue();
			return (diff < 0) ? -1 : (diff == 0 ? string.compareTo(o.string) : 1);
		}
	}
}