package ai.aitia.visu.view.plot;

/** It describes the operations of a drawing supplier that can be used in basic
 *  appearance.
 */
public interface IBasicSupplier {
	public void setThinLines();
}
