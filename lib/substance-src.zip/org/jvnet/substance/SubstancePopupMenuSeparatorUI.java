/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;

import javax.swing.JComponent;
import javax.swing.JSeparator;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicPopupMenuSeparatorUI;

import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.utils.SubstanceCoreUtilities;
import org.jvnet.substance.utils.SubstanceConstants.MenuGutterFillKind;
import org.jvnet.substance.utils.menu.MenuUtilities;

/**
 * UI for popup menu separators in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstancePopupMenuSeparatorUI extends BasicPopupMenuSeparatorUI {
	/**
	 * Delegate for painting fill background.
	 */
	private SubstanceFillBackgroundDelegate fillBackgroundDelegate;

	public static ComponentUI createUI(JComponent c) {
		return new SubstancePopupMenuSeparatorUI();
	}

	/**
	 * Creates a new UI delegate.
	 */
	public SubstancePopupMenuSeparatorUI() {
		super();
		this.fillBackgroundDelegate = new SubstanceFillBackgroundDelegate();
	}

	@Override
	public void paint(Graphics g, JComponent c) {
		Graphics2D graphics = (Graphics2D) g.create();
		try {
			JSeparator sep = (JSeparator) c;

			this.fillBackgroundDelegate.update(graphics, c);
			int xOffset = MenuUtilities
					.getTextOffset(graphics, sep.getParent());

			Dimension s = c.getSize();
			if (c.getComponentOrientation().isLeftToRight()) {
				MenuGutterFillKind fillKind = SubstanceCoreUtilities
						.getMenuGutterFillKind();
				if (fillKind != MenuGutterFillKind.NONE) {
					ColorScheme scheme = SubstanceCoreUtilities
							.getActiveScheme(sep);
					Color leftColor = ((fillKind == MenuGutterFillKind.SOFT_FILL) || (fillKind == MenuGutterFillKind.HARD)) ? scheme
							.getUltraLightColor()
							: scheme.getLightColor();
					Color rightColor = ((fillKind == MenuGutterFillKind.SOFT_FILL) || (fillKind == MenuGutterFillKind.SOFT)) ? scheme
							.getUltraLightColor()
							: scheme.getLightColor();
					GradientPaint gp = new GradientPaint(0, 0, leftColor,
							xOffset, 0, rightColor);

					graphics.setComposite(TransitionLayout.getAlphaComposite(
							sep, 0.7f));
					graphics.setPaint(gp);
					graphics.fillRect(0, 0, xOffset - 2, c.getHeight());
				}

				graphics.setComposite(TransitionLayout.getAlphaComposite(sep));
				graphics.setColor(c.getForeground());
				graphics.drawLine(xOffset, 1, s.width, 1);
				graphics.setColor(c.getBackground());
				graphics.drawLine(xOffset, 2, s.width, 2);
				graphics.drawLine(xOffset, 0, xOffset, 0);
				graphics.drawLine(xOffset, 3, xOffset, 3);
			} else {
				// fix for defect 125 - support of RTL menus
				MenuGutterFillKind fillKind = SubstanceCoreUtilities
						.getMenuGutterFillKind();
				if (fillKind != MenuGutterFillKind.NONE) {
					ColorScheme scheme = SubstanceCoreUtilities
							.getActiveScheme(sep);
					Color leftColor = ((fillKind == MenuGutterFillKind.HARD_FILL) || (fillKind == MenuGutterFillKind.HARD)) ? scheme
							.getLightColor()
							: scheme.getUltraLightColor();
					Color rightColor = ((fillKind == MenuGutterFillKind.HARD_FILL) || (fillKind == MenuGutterFillKind.SOFT)) ? scheme
							.getLightColor()
							: scheme.getUltraLightColor();
					GradientPaint gp = new GradientPaint(s.width - xOffset, 0,
							leftColor, s.width, 0, rightColor);

					graphics.setComposite(TransitionLayout.getAlphaComposite(
							sep, 0.7f));
					graphics.setPaint(gp);
					graphics.fillRect(s.width - xOffset - 2, 0, s.width, c
							.getHeight());
				}
				graphics.setComposite(TransitionLayout.getAlphaComposite(sep));
				graphics.setColor(c.getForeground());
				graphics.drawLine(0, 1, s.width - xOffset - 4, 1);
				graphics.setColor(c.getBackground());
				graphics.drawLine(0, 2, s.width - xOffset - 4, 2);
				graphics.drawLine(0, 0, 0, 0);
				graphics.drawLine(0, 3, 0, 3);
			}
		} finally {
			graphics.dispose();
		}
	}
}
