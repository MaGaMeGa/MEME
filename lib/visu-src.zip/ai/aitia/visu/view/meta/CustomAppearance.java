package ai.aitia.visu.view.meta;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.jfree.chart.plot.DefaultDrawingSupplier;
import org.jfree.chart.plot.DrawingSupplier;
import org.jfree.chart.plot.SeriesRenderingOrder;

import ai.aitia.visu.view.ui.UnfilledShape;

public class CustomAppearance {

	//=======================================================================================
	// members
	
	private Font titleFont = null;
	private Color titleColor = null;
	private boolean showTitle = true;
	
	private Font subtitleFont = null;
	private Color subtitleColor = null;
	private boolean showSubtitle = true;
	
	private Font domainAxisFont = null;
	private Color domainAxisColor = null;
	private boolean domainAxisTickLabels = true;
	private boolean domainAxisTickMarks = true;
	private Font domainAxisTickFont = null;
	private boolean domainAutoRange = true;
	private double domainRangeMin, domainRangeMax;
	
	private Font rangeAxisFont = null;
	private Color rangeAxisColor = null;
	private boolean rangeAxisTickLabels = true;
	private boolean rangeAxisTickMarks = true;
	private Font rangeAxisTickFont = null;
	private boolean rangeAutoRange = true;
	private double rangeRangeMin, rangeRangeMax;
	
	private Paint backgroundPaint = null;
	private Dimension dimension = null; 
	
	private List<DrawingSupplierItem> items = null;
	
	//=======================================================================================
	// constructors
	
	//--------------------------------------------------------------------------------------
	public CustomAppearance() {}
	
	//--------------------------------------------------------------------------------------
	public CustomAppearance(List<DrawingSupplierItem> items) {
		if (items == null)
			throw new IllegalArgumentException();
		this.items = items;
	}
	
	//--------------------------------------------------------------------------------------
	public CustomAppearance(Font titleFont, Color titleColor, boolean showTitle, 
							Font subtitleFont, Color subtitleColor, boolean showSubtitle,
							Font domainAxisFont, Color domainAxisColor,
							boolean domainAxisTickLabels, boolean domainAxisTickMarks, Font domainAxisTickFont,
							boolean domainAutoRange, double domainRangeMin, double domainRangeMax,
							Font rangeAxisFont, Color rangeAxisColor,
							boolean rangeAxisTickLabels, boolean rangeAxisTickMarks, Font rangeAxisTickFont,
							boolean rangeAutoRange, double rangeRangeMin, double rangeRangeMax,
							Paint backgroundPaint, Dimension dimension, List<DrawingSupplierItem> items) {
		this(items);
		this.titleFont = titleFont;
		this.titleColor = titleColor;
		this.showTitle = showTitle;
		this.subtitleFont = subtitleFont;
		this.subtitleColor = subtitleColor;
		this.showSubtitle = showSubtitle;
		this.domainAxisFont = domainAxisFont;
		this.domainAxisColor = domainAxisColor;
		this.domainAxisTickLabels = domainAxisTickLabels;
		this.domainAxisTickMarks = domainAxisTickMarks;
		this.domainAxisTickFont = domainAxisTickFont;
		this.domainAutoRange = domainAutoRange;
		this.domainRangeMin = domainRangeMin;
		this.domainRangeMax = domainRangeMax;
		this.rangeAxisFont = rangeAxisFont;
		this.rangeAxisColor = rangeAxisColor;
		this.rangeAxisTickLabels = rangeAxisTickLabels;
		this.rangeAxisTickMarks = rangeAxisTickMarks;
		this.rangeAxisTickFont = rangeAxisTickFont;
		this.rangeAutoRange = rangeAutoRange;
		this.rangeRangeMin = rangeRangeMin;
		this.rangeRangeMax = rangeRangeMax;
		this.backgroundPaint = backgroundPaint;
		this.dimension = dimension;
	}
	
	//=======================================================================================
	// getters/setters
	
	//--------------------------------------------------------------------------------------
	public boolean isShowTitle() { return showTitle; }
	public Font getTitleFont() { return titleFont; }
	public Color getTitleColor() { return titleColor; }
	
	//----------------------------------------------------------------------------------------------------
	public boolean isShowSubtitle() { return showSubtitle; }
	public Font getSubtitleFont() {	return subtitleFont; }
	public Color getSubtitleColor() { return subtitleColor;	}
	
	//----------------------------------------------------------------------------------------------------
	public Font getDomainAxisFont() { return domainAxisFont; }
	public Color getDomainAxisColor() { return domainAxisColor;	}
	public Font getDomainAxisTickFont() { return domainAxisTickFont; }
	public boolean isDomainAxisTickLabels() { return domainAxisTickLabels; }
	public boolean isDomainAxisTickMarks() { return domainAxisTickMarks; }
	public boolean isDomainAutoRange() { return domainAutoRange; }
	public double getDomainRangeMin() { return domainRangeMin; }
	public double getDomainRangeMax() { return domainRangeMax; }
	
	//----------------------------------------------------------------------------------------------------
	public Font getRangeAxisFont() { return rangeAxisFont; }
	public Color getRangeAxisColor() { return rangeAxisColor; }
	public Font getRangeAxisTickFont() { return rangeAxisTickFont; }
	public boolean isRangeAxisTickLabels() { return rangeAxisTickLabels; }
	public boolean isRangeAxisTickMarks() { return rangeAxisTickMarks; }
	public boolean isRangeAutoRange() { return rangeAutoRange; }
	public double getRangeRangeMin() { return rangeRangeMin; }
	public double getRangeRangeMax() { return rangeRangeMax; }
	
	//----------------------------------------------------------------------------------------------------
	public Paint getBackgroundPaint() { return backgroundPaint;	}
	public Dimension getDimension() { return dimension; }
	
	//----------------------------------------------------------------------------------------------------
	public DrawingSupplier getDrawingSupplier() { return items == null ? null : new CustomDrawingSupplier(items); }
	
	//----------------------------------------------------------------------------------------------------
	public DrawingSupplier getDrawingSupplier(final int noOfSeries, final SeriesRenderingOrder renderingOrder) {
		if (this.items == null)	return null;
		
		final List<DrawingSupplierItem> items = new ArrayList<DrawingSupplierItem>(noOfSeries);
		for (int i = 0;i < noOfSeries;++i)
			items.add(this.items.get(i % this.items.size()));
		if (renderingOrder == SeriesRenderingOrder.REVERSE)
			Collections.reverse(items);
		return new CustomDrawingSupplier(items);
	}
	
	//----------------------------------------------------------------------------------------------------
	public List<Boolean> getFilledShapeInfo(int noOfSeries) {
		if (items == null) return null;
		DrawingSupplier temp = new CustomDrawingSupplier(items);
		List<Boolean> result = new ArrayList<Boolean>(noOfSeries);
		for (int i = 0;i < noOfSeries;++i) {
			Shape shape = temp.getNextShape();
			result.add(!(shape instanceof UnfilledShape));
		}
		return result;
	}
	
	//--------------------------------------------------------------------------------------
	public void setShowTitle(boolean showTitle) { this.showTitle = showTitle; }
	public void setTitleFont(Font titleFont) { this.titleFont = titleFont; }
	public void setTitleColor(Color titleColor) { this.titleColor = titleColor; }
	
	//----------------------------------------------------------------------------------------------------
	public void setShowSubtitle(boolean showSubtitle) {	this.showSubtitle = showSubtitle; }
	public void setSubtitleFont(Font subtitleFont) { this.subtitleFont = subtitleFont; }
	public void setSubtitleColor(Color subtitleColor) {	this.subtitleColor = subtitleColor; }
	
	//----------------------------------------------------------------------------------------------------
	public void setDomainAxisFont(Font domainAxisFont) { this.domainAxisFont = domainAxisFont; }
	public void setDomainAxisColor(Color domainAxisColor) {	this.domainAxisColor = domainAxisColor;	}
	public void setDomainAxisTickFont(Font domainAxisTickFont) { this.domainAxisTickFont = domainAxisTickFont; }
	public void setDomainAxisTickLabels(boolean domainAxisTickLabels) { this.domainAxisTickLabels = domainAxisTickLabels; }
	public void setDomainAxisTickMarks(boolean domainAxisTickMarks) { this.domainAxisTickMarks = domainAxisTickMarks; }
	public void setDomainAutoRange(boolean domainAutoRange) { this.domainAutoRange = domainAutoRange; }
	public void setDomainRangeMin(double domainRangeMin) { this.domainRangeMin = domainRangeMin; }
	public void setDomainRangeMax(double domainRangeMax) { this.domainRangeMax = domainRangeMax; }
	
	//----------------------------------------------------------------------------------------------------
	public void setRangeAxisFont(Font rangeAxisFont) { this.rangeAxisFont = rangeAxisFont; }
	public void setRangeAxisColor(Color rangeAxisColor) { this.rangeAxisColor = rangeAxisColor; }
	public void setRangeAxisTickFont(Font rangeAxisTickFont) { this.rangeAxisTickFont = rangeAxisTickFont; }
	public void setRangeAxisTickLabels(boolean rangeAxisTickLabels) { this.rangeAxisTickLabels = rangeAxisTickLabels; }
	public void setRangeAxisTickMarks(boolean rangeAxisTickMarks) {	this.rangeAxisTickMarks = rangeAxisTickMarks; }
	public void setRangeAutoRange(boolean rageAutoRange) { this.rangeAutoRange = rageAutoRange; }
	public void setRangeRangeMin(double rangeRangeMin) { this.rangeRangeMin = rangeRangeMin; }
	public void setRangeRangeMax(double rangeRangeMax) { this.rangeRangeMax = rangeRangeMax; }
	
	//----------------------------------------------------------------------------------------------------
	public void setItems(List<DrawingSupplierItem> items) { this.items = items; }
	
	//----------------------------------------------------------------------------------------------------
	public void setBackgroundPaint(Paint backgroundPaint) {	this.backgroundPaint = backgroundPaint;	}
	public void setDimension(Dimension dimension) { this.dimension = dimension; }
	
	//=======================================================================================
	// nested classes
	
	//---------------------------------------------------------------------------------------
	public static class DrawingSupplierItem {
		
		//===================================================================================
		// members
		
		private Color color = null;
		private Shape shape = null;
		private Stroke stroke = null;
		
		//===================================================================================
		// constructors
		
		//-----------------------------------------------------------------------------------
		public DrawingSupplierItem(Color color, Shape shape, Stroke stroke) {
			this.color = color;
			this.shape = shape;
			this.stroke = stroke;
		}
		
		//-----------------------------------------------------------------------------------
		public DrawingSupplierItem(Color color, Class shapeClass, Stroke stroke) throws InstantiationException, IllegalAccessException {
			this(color,(Shape)null,stroke);
			this.shape = (Shape)shapeClass.newInstance();
		}
		
		//===================================================================================
		// getters/setters
		
		//-----------------------------------------------------------------------------------
		public Color getColor() { return color; }
		public Shape getShape() { return shape; }
		public Stroke getStroke() { return stroke; }
	}
	
	//---------------------------------------------------------------------------------------
	public static class CustomDrawingSupplier extends DefaultDrawingSupplier {
		
		//===================================================================================
		// members

		private static final long serialVersionUID = 1L;
		private List<DrawingSupplierItem> items = null;
		private int colorIndex = 0;
		private int shapeIndex = 0;
		private int strokeIndex = 0;
		
		//===================================================================================
		// methods
		
		//-----------------------------------------------------------------------------------
		public CustomDrawingSupplier(List<DrawingSupplierItem> items) {
			super();
			this.items = new ArrayList<DrawingSupplierItem>(items);
		}
		
		//----------------------------------------------------------------------------------
		@Override
		public Paint getNextPaint() {
			Paint result = items.get(colorIndex % items.size()).getColor();
			colorIndex++;
			return result;
		}
		
		//----------------------------------------------------------------------------------
		@Override
		public Shape getNextShape() {
			Shape result = items.get(shapeIndex % items.size()).getShape();
			shapeIndex++;
			return result;
		}
		
		//----------------------------------------------------------------------------------
		@Override
		public Stroke getNextStroke() {
			Stroke result = items.get(strokeIndex % items.size()).getStroke();
			strokeIndex++;
			return result;
		}
	}
}