/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
/* ===========================================================
 * JFreeChart : a free chart library for the Java(tm) platform
 * ===========================================================
 *
 * (C) Copyright 2000-2005, by Object Refinery Limited and Contributors.
 *
 * Project Info:  http://www.jfree.org/jfreechart/index.html
 *
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License as published by 
 * the Free Software Foundation; either version 2.1 of the License, or 
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public 
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License 
 * along with this library; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 *
 * ----------------
 * ContourPlot.java
 * ----------------
 * (C) Copyright 2002-2005, by David M. O'Donnell and Contributors.
 *
 * Original Author:  David M. O'Donnell;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *                   Arnaud Lelievre;
 *                   Nicolas Brodu;
 *
 * $Id: RectangleAreaPlot.java,v 1.13 2009/11/13 08:41:25 rbocsi Exp $
 *
 * Changes
 * -------
 * 26-Nov-2002 : Version 1 contributed by David M. O'Donnell (DG);
 * 14-Jan-2003 : Added crosshair attributes (DG);
 * 23-Jan-2003 : Removed two constructors (DG);
 * 21-Mar-2003 : Bug fix 701744 (DG);
 * 26-Mar-2003 : Implemented Serializable (DG);
 * 09-Jul-2003 : Changed ColorBar from extending axis classes to enclosing 
 *               them (DG);
 * 05-Aug-2003 : Applied changes in bug report 780298 (DG);
 * 08-Sep-2003 : Added internationalization via use of properties 
 *               resourceBundle (RFE 690236) (AL);
 * 11-Sep-2003 : Cloning support (NB); 
 * 16-Sep-2003 : Changed ChartRenderingInfo --> PlotRenderingInfo (DG);
 * 17-Jan-2004 : Removed references to DefaultContourDataset class, replaced 
 *               with ContourDataset interface (with changes to the interface). 
 *               See bug 741048 (DG);
 * 21-Jan-2004 : Update for renamed method in ValueAxis (DG);
 * 25-Feb-2004 : Replaced CrosshairInfo with CrosshairState (DG);
 * 06-Oct-2004 : Updated for changes in DatasetUtilities class (DG);
 * 11-Nov-2004 : Renamed zoom methods to match ValueAxisPlot interface (DG);
 * 25-Nov-2004 : Small update to clone() implementation (DG);
 * 11-Jan-2005 : Removed deprecated code in preparation for 1.0.0 release (DG);
 * 05-May-2005 : Updated draw() method parameters (DG);
 * 
 */

package ai.aitia.visu.view.plot;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.font.FontRenderContext;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RectangularShape;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.data.Range;
import org.jfree.data.contour.ContourDataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;

import ai.aitia.visu.data.RectangleAreaDataset;
import ai.aitia.visu.data.RectangleAreaEntry;
import ai.aitia.visu.view.entity.AreaEntity;
import ai.aitia.visu.view.labels.DefaultRectangleAreaTooltipGenerator;
import ai.aitia.visu.view.labels.RectangleAreaTooltipGenerator;
import ai.aitia.visu.view.ui.BlackAndWhiteColorMap;
import ai.aitia.visu.view.ui.ColorBar;
import ai.aitia.visu.view.ui.ColorMap;
import ai.aitia.visu.view.ui.ColorMapCollection;
import ai.aitia.visu.view.ui.RainbowColorMap;
import ai.aitia.visu.view.ui.SimpleColorMap;

/**
 * A class for creating grid2d plots.
 *
 * @author Robert Szalai
 */
public class RectangleAreaPlot extends DefaultInteractivePlot implements  /*ValueAxisPlot,*/
                                                 PropertyChangeListener,
                                                 Serializable,
                                                 Cloneable {
    
	/** For serialization */
	private static final long serialVersionUID = -1695516149041277900L;

	protected static final int MAXIMUM_ENTRIES_SIZE = 20000;
	
	/** The default insets. */
    protected static final RectangleInsets DEFAULT_INSETS 
        = new RectangleInsets(2.0, 2.0, 100.0, 10.0);

    /** The dataset. */
    private RectangleAreaDataset dataset;

    /** The color bar location. */
    private RectangleEdge colorBarLocation;

    /** A list of annotations (optional) for the plot. */
    private List annotations;

    /** The tool tip generator. */
    private RectangleAreaTooltipGenerator toolTipGenerator;

    /** Set to Paint to represent missing values. */
    private transient Paint missingPaint = null;

    /** The resourceBundle for the localization. */
    protected static ResourceBundle localizationResources = 
        ResourceBundle.getBundle("org.jfree.chart.plot.LocalizationBundle");
    
    
    protected ColorBar colorBar = new ColorBar("Colors");
    
    protected ColorMap colorMap = null;
    protected ColorMapUpdateOption updateOption = ColorMapUpdateOption.NONE;
    
    protected Font labelFont = new Font("SansSerif", Font.BOLD, 12);
    
    protected boolean noSelection = false;
    protected String tooMany = "Sorry, the number of areas exceeds the drawing limit.";

    /**
     * Constructs a contour plot with the specified axes (other attributes take
     * default values).
     *
     * @param dataset  The dataset.
     * @param domainAxis  The domain axis.
     * @param rangeAxis  The range axis.
     * @param colorBar  The z-axis axis.
    */
    public RectangleAreaPlot(RectangleAreaDataset dataset,
                       ColorMap colorMap, boolean noSelection) {

        super();

        this.dataset = dataset;
        
        if (dataset != null) {
            dataset.addChangeListener(this);
        }
        
        this.colorMap = colorMap;
        updateOption = ColorMapUpdateOption.getOption(colorMap.getMinLevel(),colorMap.getMaxLevel());
        if (updateOption != ColorMapUpdateOption.NONE)
        	datasetChanged(new DatasetChangeEvent(dataset,dataset));
        
        this.colorBar.configure(colorMap);
                
        this.colorBarLocation = RectangleEdge.LEFT;        
        
        this.toolTipGenerator = new DefaultRectangleAreaTooltipGenerator();
        
        this.noSelection = noSelection;
        
    }
    
    public RectangleAreaPlot(RectangleAreaDataset dataset,
            ColorMap colorMap, boolean noSelection, String tooMany) {
    	this(dataset,colorMap,noSelection);
    	this.tooMany = tooMany;
    }

    /**
     * Returns the color bar location.
     * 
     * @return The color bar location.
     */
    public RectangleEdge getColorBarLocation() {
        return this.colorBarLocation;
    }
    
    /**
     * Sets the color bar location and sends a {@link PlotChangeEvent} to all 
     * registered listeners.
     * 
     * @param edge  the location.
     */
    public void setColorBarLocation(RectangleEdge edge) {
        this.colorBarLocation = edge;
        notifyListeners(new PlotChangeEvent(this));    
    }
    
    public void setColorBar(ColorBar colorBar) { 
    	this.colorBar = colorBar;
    	notifyListeners(new PlotChangeEvent(this));    	   
    }
    
    /**
     * Returns the primary dataset for the plot.
     * 
     * @return The primary dataset (possibly <code>null</code>).
     */
    public RectangleAreaDataset getDataset() {
        return this.dataset;
    }
    
    /**
     * Sets the dataset for the plot, replacing the existing dataset if there
     * is one.
     * 
     * @param dataset  the dataset (<code>null</code> permitted).
     */
    public void setDataset(RectangleAreaDataset dataset) {
        
        // if there is an existing dataset, remove the plot from the list of 
        // change listeners...
        RectangleAreaDataset existing = this.dataset;
        
        if (existing != null) {
            existing.removeChangeListener(this);
        }

        // set the new dataset, and register the chart as a change listener...
        this.dataset = dataset;
        if (dataset != null) {
            setDatasetGroup(dataset.getGroup());
            dataset.addChangeListener(this);
        }

        // send a dataset change event to self...
        DatasetChangeEvent event = new DatasetChangeEvent(this, dataset);
        datasetChanged(event);
        
    }

    /**
     * Adds an annotation to the plot.
     *
     * @param annotation  the annotation.
     */
    @SuppressWarnings("unchecked")
	public void addAnnotation(XYAnnotation annotation) {

        if (this.annotations == null) {
            this.annotations = new java.util.ArrayList();
        }
        this.annotations.add(annotation);
        notifyListeners(new PlotChangeEvent(this));

    }

    /**
     * Clears all the annotations.
     */
    public void clearAnnotations() {
        if (this.annotations != null) {
            this.annotations.clear();
            notifyListeners(new PlotChangeEvent(this));
        }
    }

    /**
     * Checks the compatibility of a domain axis, returning true if the axis is
     * compatible with the plot, and false otherwise.
     *
     * @param axis The proposed axis.
     *
     * @return <code>true</code> if the axis is compatible with the plot.
     */
    public boolean isCompatibleDomainAxis(ValueAxis axis) {

        return true;

    }

    /**
     * Draws the plot on a Java 2D graphics device (such as the screen or a 
     * printer).
     * <P>
     * The optional <code>info</code> argument collects information about the 
     * rendering of the plot (dimensions, tooltip information etc).  Just pass
     * in <code>null</code> if you do not need this information.
     *
     * @param g2  the graphics device.
     * @param area  the area within which the plot (including axis labels)
     *              should be drawn.
     * @param anchor  the anchor point (<code>null</code> permitted).
     * @param parentState  the state from the parent plot, if there is one.
     * @param info  collects chart drawing information (<code>null</code> 
     *              permitted).
     */
    public void draw(Graphics2D g2, Rectangle2D area, Point2D anchor,
                     PlotState parentState,
                     PlotRenderingInfo info) {

    	// if the plot area is too small, just return...
        boolean b1 = (area.getWidth() <= MINIMUM_WIDTH_TO_DRAW);
        boolean b2 = (area.getHeight() <= MINIMUM_HEIGHT_TO_DRAW);
        
        if (b1 || b2) {
            return;
        }
        
        //added code
        if (dataset.getEntries().size() > MAXIMUM_ENTRIES_SIZE) {
        	Font font = g2.getFont().deriveFont(20.0f);
        	g2.setFont(font);
        	FontMetrics fm = g2.getFontMetrics();
       		g2.setPaint(Color.BLACK);
        	g2.drawString(tooMany,(int)(area.getX() + ((area.getWidth()- fm.stringWidth(tooMany)) /2)),(int)(area.getY() + area.getHeight() /2 + fm.getAscent()/2));
        	return;
        }
    	//for datasets filled with 0
    	if (dataset.getTotalArea() == 0) return;
    	//added code end
        
        // record the plot area...
        if (info != null) {
            info.setPlotArea(area);
        }
        
        // adjust the drawing area for plot insets (if any)...
        RectangleInsets insets = getInsets();
        insets.trim(area);
        
        AxisSpace space = new AxisSpace();
        // in this case the next line is unneccessary because the space is filled with 0
        //Rectangle2D estimatedDataArea = space.shrink(area, null);
        Rectangle2D estimatedDataArea = area;
        
        AxisSpace space2 = new AxisSpace();
        
        if (colorBar != null) {
        	space2 = this.colorBar.reserveSpace(
        		g2, this, area, estimatedDataArea, this.colorBarLocation, 
            	space2
        	);        
        }
        
        Rectangle2D adjustedPlotArea = space2.shrink(area, null);
        
        Rectangle2D dataArea = space.shrink(adjustedPlotArea, null);

        Rectangle2D colorBarArea = space2.reserved(
            area, this.colorBarLocation
        );    

        double ratio = 1;
        Rectangle2D tmpDataArea = (Rectangle2D) dataArea.clone();
        double h = tmpDataArea.getHeight();
        double w = tmpDataArea.getWidth();

//        if (ratio > 0) { // ratio represents pixels (ratio is constant 1)
        if (w * ratio <= h) {
              h = ratio * w;
        } else {
              w = h / ratio;
        }
//        }
//        else {  // ratio represents axis units
//            ratio *= -1.0;
//            
//            double unitRatio = 1;
//
//            ratio = unitRatio * ratio;
//
//            if (w * ratio <= h) {
//                h = ratio * w;
//            }
//            else {
//                w = h / ratio;
//            }
//        }

        dataArea.setRect(
            tmpDataArea.getX() + tmpDataArea.getWidth() / 2 - w / 2,
            tmpDataArea.getY(), w, h
        );
        
        if (info != null) {
            info.setDataArea(dataArea);
        }

        CrosshairState crosshairState = new CrosshairState();
        crosshairState.setCrosshairDistance(Double.POSITIVE_INFINITY);

        // draw the plot background...
        drawBackground(g2, dataArea);
        
        double cursor = dataArea.getMaxY();
        
        if (this.colorBar != null) {
            cursor = 0.0;
            cursor = this.colorBar.draw(
                g2, cursor, adjustedPlotArea, dataArea, colorBarArea, 
                this.colorBarLocation
            );
        }        
        
        Shape originalClip = g2.getClip();
        Composite originalComposite = g2.getComposite();

        g2.clip(dataArea);
        g2.setComposite(AlphaComposite.getInstance(
            AlphaComposite.SRC_OVER, getForegroundAlpha())
        );
        
        render(g2, dataArea, info, crosshairState);

        g2.setClip(originalClip);
        g2.setComposite(originalComposite);
        drawOutline(g2, dataArea);
    }
    
    static final float MIN_GROWTH_TO_APPLY = 1.2F;
	static final float MAX_SHRINK_TO_APPLY = 0.9F;
    
    public static float changeFontSize (Rectangle2D componentSpace, Rectangle2D textSpace) {
		double widthChange = componentSpace.getWidth() / textSpace.getWidth();
		double heightChange = componentSpace.getHeight() / textSpace.getHeight();
 
		// Always work to make the font as large as you can so EVERYTHING still fits.  That
		// means to make it the smallest necessary size.
		float result = (float)Math.min(widthChange, heightChange);
		
		if ((result < 1F) && (result > MAX_SHRINK_TO_APPLY)) {
			result = MAX_SHRINK_TO_APPLY;
		}
		
		return result;
	}
    
    public void renderText(Graphics2D g2, Rectangle2D.Double area, String text) {
    	
    	area.x += area.width * 0.1;
    	area.width *= 0.8;
    	
    	if (text == null || "".equals(text.trim()))
    		return;
    	
    	Font baseFont = labelFont;
    	g2.setFont(labelFont);
    	
    	FontRenderContext renderContext = g2.getFontRenderContext();
    	
    	Rectangle2D textSize = baseFont.getStringBounds(text, renderContext);
    	
    	// modify condition
    	if (textSize.getWidth() > area.getWidth() || textSize.getHeight() > area.getHeight()) {
    	
    		float sizeChange = changeFontSize(area, textSize);
    		float originalSize = baseFont.getSize2D();
    	
    	//if ((sizeChange >= MIN_GROWTH_TO_APPLY) || (sizeChange <= MAX_SHRINK_TO_APPLY)) {    		
			Font newFont = baseFont.deriveFont(originalSize * sizeChange);
			g2.setFont(newFont);
			
			//added code
			textSize = newFont.getStringBounds(text,renderContext);
	    	if (textSize.getHeight() > area.getHeight() || textSize.getWidth() > area.getWidth()) {
	    		return;
	    	}
	    	//added code end
		//}    	
    	}
    	
    	FontMetrics fm = g2.getFontMetrics();
    	
    	int width = fm.stringWidth(text);
    	
    	g2.drawString(text, (int)(area.x + ((area.width - width) / 2)) , (int)(area.y + area.height / 2 + fm.getAscent()/2));
    }

    /**
     * Draws a representation of the data within the dataArea region, using the
     * current renderer.
     * <P>
     * The <code>info</code> and <code>crosshairState</code> arguments may be 
     * <code>null</code>.
     *
     * @param g2  the graphics device.
     * @param dataArea  the region in which the data is to be drawn.
     * @param info  an optional object for collection dimension information.
     * @param crosshairState  an optional object for collecting crosshair info.
     */
    @SuppressWarnings("unchecked")
	public void render(Graphics2D g2, Rectangle2D dataArea,
                       PlotRenderingInfo info, CrosshairState crosshairState) {
  
    	
        EntityCollection entities = null;
        if (info != null) {
            entities = info.getOwner().getEntityCollection();
        }    	
    	
    	RectangleAreaDataset dataset = getDataset();    	    	
    	
    	double totalArea = dataset.getTotalArea();
    	
    	double length = Math.sqrt(totalArea);
    	
    	double widthRatio = dataArea.getWidth() / length;
    	double heightRatio = dataArea.getHeight() / length;
    	    	
    	List<RectangleAreaEntry> entries = new ArrayList<RectangleAreaEntry>();
    	double remainsArea = 0.0;
    	double bound = totalArea / 100.;
    	for (Object obj : dataset.getEntries()) {
    		RectangleAreaEntry entry = (RectangleAreaEntry)obj; 
    		if (entry.getAreaValue() < bound) remainsArea += entry.getAreaValue();
    		else entries.add(entry);
    	}
    	if (remainsArea != 0.0) entries.add(new RectangleAreaEntry("Remains",remainsArea,colorMap.defaultValue()));
    	
    	Rectangle2D.Double area = new Rectangle2D.Double(0, 0, length, length);
    	
    	Iterator<RectangleAreaEntry> it = entries.iterator();
    	
    	List<RectangleAreaEntry> entriesToPlace = new ArrayList<RectangleAreaEntry>();
    	
    	int direction = 0;
        	
    	while (it.hasNext()) {
    				
    		double mustFillArea = area.width * area.height * 0.33;
    		
    		double entriesArea = 0;
    		
    		entriesToPlace.clear(); 
    		
    		while (entriesArea < mustFillArea) {
    			RectangleAreaEntry entry = it.next();
    			entriesArea += entry.getAreaValue();
    			entriesToPlace.add(entry);
    		}

    		Rectangle2D.Double[] rects = placeEntry(area, entriesToPlace, entriesArea, direction%2 == 0 ? FILL_HEIGHT : FILL_WIDTH);
    		
    		for (int i=0; i<rects.length; i++) {
    		
    			Rectangle2D.Double rect = rects[i];
    			RectangleAreaEntry entry = entriesToPlace.get(i);
    			
    			rect.x = dataArea.getX() + (rect.x * widthRatio);		  
    			rect.y = dataArea.getY() + (rect.y * heightRatio);
    		
    			rect.width *= widthRatio;
    			rect.height *= heightRatio;
    		
    			Color paintColor = colorMap.getColor(entry.getColorValue()); 
    			
    			g2.setPaint(paintColor);    		
    			g2.fill(rect);
   
    			//g2.setColor(new Color(paintColor.getRed() ^ 255, paintColor.getGreen() ^ 255, paintColor.getBlue() ^ 255));
    			g2.setColor(invertColor(paintColor));  
    			
    			g2.draw(rect);    			    			
    			
    			boolean bool = rect.getHeight()>2 && rect.getWidth()>2;
    			
    			// BEGIN Add entity
    			//added code
    			String tip = "";
    			if (bool) {
    				tip = this.toolTipGenerator.generateToolTip(entry, totalArea);
    			}
    			if (entities != null && bool) {
    				//added code end
    			
    				AreaEntity entity = new AreaEntity(
    						(RectangularShape) rect.clone(), tip, entry);
    				entities.add(entity);
    				
    				if (!noSelection) areaInfo.put(entry, rect.clone());
                                
    			}
    			// END Add entity
    			
    			renderText(g2, rect, entry.getName());
    		}
    		
    		direction++;
    		
    	}
    	
    	if (!noSelection) renderSelection(g2);
    }
    
    
    private Color invertColor(Color c) {
    	
    	final int newRed = 255 - c.getRed();
    	final int newGreen = 255 - c.getGreen();
    	final int newBlue = 255 - c.getBlue();
    	
    	return new Color(newRed, newGreen, newBlue);
    }
            
    private static final int FILL_HEIGHT = 1;
    private static final int FILL_WIDTH = 2;

    public Rectangle2D.Double[] placeEntry(Rectangle2D.Double area, List entries, double entriesArea, int direction) {
    	
    	if (direction == FILL_HEIGHT) {
    		
    		double height = area.height;    		
    		double width = entriesArea / height;
    		    		
    		double areaY = area.y; 
    		
    		Rectangle2D.Double[] rects = new Rectangle2D.Double[entries.size()];
    		
    		final int size = entries.size();
    		
    		for (int i=0; i<size; i++) {
    			RectangleAreaEntry entry = (RectangleAreaEntry) entries.get(i);
    			
    			double areaHeight = entry.getAreaValue() / width;
    			
    			rects[i] = new Rectangle2D.Double(area.x, areaY, width, areaHeight);
    						
    			areaY += areaHeight;
    		}
    		    		    		    		
    		
    		area.x += width;
    		area.width -= width;
    		
    		return rects;
    		    		
    	} else {
    		double width = area.width;    		
    		double height = entriesArea / width;
    		
    		double areaX = area.x;
    		
    		Rectangle2D.Double[] rects = new Rectangle2D.Double[entries.size()];
    		
    		final int size = entries.size();
    		
    		for (int i=0; i<size; i++) {
    			RectangleAreaEntry entry = (RectangleAreaEntry) entries.get(i);
    			
    			double areaWidth = entry.getAreaValue() / height;
    			
    			rects[i] = new Rectangle2D.Double(areaX, area.y, areaWidth, height);			
    			
    			areaX += areaWidth;
    		}    		
    		
    		area.y += height;
    		area.height -= height;
    		
    		return rects;    		  		
    	}    		
    }      

    /**
     * Handles a 'click' on the plot by updating the anchor values...
     *
     * @param x  x-coordinate, where the click occured.
     * @param y  y-coordinate, where the click occured.
     * @param info  An object for collection dimension information.
     */
    public void handleClick(int x, int y, PlotRenderingInfo info) {

/*        // set the anchor value for the horizontal axis...
        ValueAxis hva = getDomainAxis();
        if (hva != null) {
            double hvalue = hva.translateJava2DtoValue(
                (float) x, info.getDataArea()
            );

            hva.setAnchorValue(hvalue);
            setDomainCrosshairValue(hvalue);
        }

        // set the anchor value for the vertical axis...
        ValueAxis vva = getRangeAxis();
        if (vva != null) {
            double vvalue = vva.translateJava2DtoValue(
                (float) y, info.getDataArea()
            );
            vva.setAnchorValue(vvalue);
            setRangeCrosshairValue(vvalue);
        }
*/
    }

    /**
     * Zooms the axis ranges by the specified percentage about the anchor point.
     *
     * @param percent  The amount of the zoom.
     */
    public void zoom(double percent) {
/*
        if (percent > 0) {
          //  double range = this.domainAxis.getRange().getLength();
          //  double scaledRange = range * percent;
          //  domainAxis.setAnchoredRange(scaledRange);

          //  range = this.rangeAxis.getRange().getLength();
         //  scaledRange = range * percent;
         //   rangeAxis.setAnchoredRange(scaledRange);
        }
        else {
            getRangeAxis().setAutoRange(true);
            getDomainAxis().setAutoRange(true);
        }
*/
    }

    /**
     * Returns the plot type as a string.
     *
     * @return A short string describing the type of plot.
     */
    public String getPlotType() {
        return localizationResources.getString("Contour_Plot");
    }

    /**
     * Returns the range for an axis.
     *
     * @param axis  the axis.
     *
     * @return The range for an axis.
     */
    /*
    public Range getDataRange(ValueAxis axis) {

        if (this.dataset == null) {
            return null;
        }

        Range result = null;

        if (axis == getDomainAxis()) {
            result = DatasetUtilities.findDomainBounds(this.dataset);
        }
        else if (axis == getRangeAxis()) {
            result = DatasetUtilities.findRangeBounds(this.dataset);
        }

        return result;

    }*/

    /**
     * Notifies all registered listeners of a property change.
     * <P>
     * One source of property change events is the plot's renderer.
     *
     * @param event  Information about the property change.
     */
    public void propertyChange(PropertyChangeEvent event) {
        notifyListeners(new PlotChangeEvent(this));
    }

    /**
     * Receives notification of a change to the plot's dataset.
     * <P>
     * The chart reacts by passing on a chart change event to all registered
     * listeners.
     *
     * @param event  Information about the event (not used here).
     */
    @SuppressWarnings("unchecked")
	public void datasetChanged(final DatasetChangeEvent event) {
    	if (updateOption != ColorMapUpdateOption.NONE) {
    		final List<RectangleAreaEntry> entries = dataset.getEntries();
    		double min = Double.MAX_VALUE;
    		double max = - Double.MAX_VALUE;
    		for (final RectangleAreaEntry e : entries) {
    			if (e.getColorValue() != - Double.MAX_VALUE && e.getColorValue() < min)
    				min = e.getColorValue();
    			if (e.getColorValue() > max)
    				max = e.getColorValue();
    		}
    		if (colorMap instanceof RainbowColorMap) {
    			final RainbowColorMap cm = (RainbowColorMap) colorMap;
    			if (updateOption.contains(ColorMapUpdateOption.MIN))
    				cm.setMinLevel(min);
    			if (updateOption.contains(ColorMapUpdateOption.MAX))
    				cm.setMaxLevel(max);
				if (colorBar != null)
					colorBar.configure(cm);
    		} else if (colorMap instanceof BlackAndWhiteColorMap) {
    			final BlackAndWhiteColorMap cm = (BlackAndWhiteColorMap) colorMap;
    			if (updateOption.contains(ColorMapUpdateOption.MIN))
    				cm.setMinLevel(min);
    			if (updateOption.contains(ColorMapUpdateOption.MAX))
    				cm.setMaxLevel(max);
    			if (colorBar != null)
    				colorBar.configure(cm);
    		} else if (colorMap instanceof SimpleColorMap) {
    			final SimpleColorMap cm = (SimpleColorMap) colorMap;
    			if (!updateOption.contains(ColorMapUpdateOption.MIN))
    				min = cm.getMinLevel();
    			if (!updateOption.contains(ColorMapUpdateOption.MAX))
    				max = cm.getMaxLevel();
    			if (max >= min)
    				cm.setLevels(min,max,cm.minColor,new Color(cm.maxRed,cm.maxGreen,cm.maxBlue));
    			if (colorBar != null)
    				colorBar.configure(cm);
    		} else if (colorMap instanceof ColorMapCollection) {
    			final ColorMapCollection cm = (ColorMapCollection) colorMap;
    			if (updateOption.contains(ColorMapUpdateOption.MIN))
    				cm.setMinLevel(min);
    			if (updateOption.contains(ColorMapUpdateOption.MAX))
    				cm.setMaxLevel(max);
    			if (colorBar != null)
    				colorBar.configure(cm);
    		}
    	} 
        super.datasetChanged(event);
    }

    /**
     * Returns the colorbar.
     *
     * @return The colorbar.
     */
    public ColorBar getColorBar() {
        return this.colorBar;
    }

    /**
     * Returns the tool tip generator.
     *
     * @return The tool tip generator (possibly null).
     */
    public RectangleAreaTooltipGenerator getTooltipGenerator() {
        return this.toolTipGenerator;
    }

    /**
     * Sets the tool tip generator.
     *
     * @param generator  the tool tip generator (null permitted).
     */
    public void setToolTipGenerator(RectangleAreaTooltipGenerator generator) {

        //Object oldValue = this.toolTipGenerator;
        this.toolTipGenerator = generator;

    }


    /**
     * Draws a vertical line on the chart to represent a 'range marker'.
     *
     * @param g2  the graphics device.
     * @param plot  the plot.
     * @param domainAxis  the domain axis.
     * @param marker  the marker line.
     * @param dataArea  the axis data area.
     */
    public void drawDomainMarker(Graphics2D g2,
                                 RectangleAreaPlot plot,
                                 ValueAxis domainAxis,
                                 Marker marker,
                                 Rectangle2D dataArea) {

        if (marker instanceof ValueMarker) {
            ValueMarker vm = (ValueMarker) marker;
            double value = vm.getValue();
            Range range = domainAxis.getRange();
            if (!range.contains(value)) {
                return;
            }
  
            double x = domainAxis.valueToJava2D(
                value, dataArea, RectangleEdge.BOTTOM
            );
            Line2D line = new Line2D.Double(
                x, dataArea.getMinY(), x, dataArea.getMaxY()
            );
            Paint paint = marker.getOutlinePaint();
            Stroke stroke = marker.getOutlineStroke();
            g2.setPaint(paint != null ? paint : Plot.DEFAULT_OUTLINE_PAINT);
            g2.setStroke(stroke != null ? stroke : Plot.DEFAULT_OUTLINE_STROKE);
            g2.draw(line);
        }

    }

    /**
     * Draws a horizontal line across the chart to represent a 'range marker'.
     *
     * @param g2  the graphics device.
     * @param plot  the plot.
     * @param rangeAxis  the range axis.
     * @param marker  the marker line.
     * @param dataArea  the axis data area.
     */
    public void drawRangeMarker(Graphics2D g2,
                                RectangleAreaPlot plot,
                                ValueAxis rangeAxis,
                                Marker marker,
                                Rectangle2D dataArea) {

        if (marker instanceof ValueMarker) {
            ValueMarker vm = (ValueMarker) marker;
            double value = vm.getValue();
            Range range = rangeAxis.getRange();
            if (!range.contains(value)) {
                return;
            }

            double y = rangeAxis.valueToJava2D(
                value, dataArea, RectangleEdge.LEFT
            );
            Line2D line = new Line2D.Double(
                dataArea.getMinX(), y, dataArea.getMaxX(), y
            );
            Paint paint = marker.getOutlinePaint();
            Stroke stroke = marker.getOutlineStroke();
            g2.setPaint(paint != null ? paint : Plot.DEFAULT_OUTLINE_PAINT);
            g2.setStroke(stroke != null ? stroke : Plot.DEFAULT_OUTLINE_STROKE);
            g2.draw(line);
        }

    }

    /**
     * Returns the visible z-range.
     *
     * @param data  the dataset.
     * @param x  the x range.
     * @param y  the y range.
     *
     * @return The range.
     */
    public Range visibleRange(ContourDataset data, Range x, Range y) {
        Range range = null;
        range = data.getZValueRange(x, y);
        return range;
    }

    /**
     * Returns the missingPaint.
     * @return Paint
     */
    public Paint getMissingPaint() {
        return this.missingPaint;
    }

    /**
     * Sets the missingPaint.
     * 
     * @param paint  the missingPaint to set.
     */
    public void setMissingPaint(Paint paint) {
        this.missingPaint = paint;
    }
    
    /**
     * Multiplies the range on the domain axis/axes by the specified factor 
     * (to be implemented).
     * 
     * @param x  the x-coordinate (in Java2D space).
     * @param y  the y-coordinate (in Java2D space).
     * @param factor  the zoom factor.
     */
    public void zoomDomainAxes(double x, double y, double factor) {
        // TODO: to be implemented
    }
    
    /**
     * Zooms the domain axes (not yet implemented).
     * 
     * @param x  the x-coordinate (in Java2D space).
     * @param y  the y-coordinate (in Java2D space).
     * @param lowerPercent  the new lower bound.
     * @param upperPercent  the new upper bound.
     */
    public void zoomDomainAxes(double x, double y, double lowerPercent, 
                               double upperPercent) {
        // TODO: to be implemented
    }
    
    /**
     * Multiplies the range on the range axis/axes by the specified factor.
     * 
     * @param x  the x-coordinate (in Java2D space).
     * @param y  the y-coordinate (in Java2D space).
     * @param factor  the zoom factor.
     */
    public void zoomRangeAxes(double x, double y, double factor) {
        // TODO: to be implemented
    }

    /**
     * Zooms the range axes (not yet implemented).
     * 
     * @param x  the x-coordinate (in Java2D space).
     * @param y  the y-coordinate (in Java2D space).
     * @param lowerPercent  the new lower bound.
     * @param upperPercent  the new upper bound.
     */
    public void zoomRangeAxes(double x, double y, double lowerPercent, 
                              double upperPercent) {
        // TODO: to be implemented
    }

    /**
     * Returns <code>false</code>.
     * 
     * @return A boolean.
     */
    public boolean isDomainZoomable() {
        return false;
    }
    
    /**
     * Returns <code>false</code>.
     * 
     * @return A boolean.
     */
    public boolean isRangeZoomable() {
        return false;
    }

	public ColorMap getColorMap() {
		return colorMap;
	}


	public void selectEntity(ChartEntity entity) {
		if (entity instanceof AreaEntity) {
			
			RectangleAreaEntry entry = ((AreaEntity)entity).getEntry();
			if (!selectionModel.getSelectedObjects().contains(entry))			
				selectionModel.addObject(entry);
		}		
	}

}
