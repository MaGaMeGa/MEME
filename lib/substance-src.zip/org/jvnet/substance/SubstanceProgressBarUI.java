/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicProgressBarUI;

import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * UI for progress bars in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceProgressBarUI extends BasicProgressBarUI {
	/**
	 * Hash for computed stripe images.
	 */
	private static Map<String, BufferedImage> stripeMap = new HashMap<String, BufferedImage>();

	/**
	 * Resets image maps (used when setting new theme).
	 * 
	 * @see SubstanceLookAndFeel#setCurrentTheme(String)
	 * @see SubstanceLookAndFeel#setCurrentTheme(SubstanceTheme)
	 */
	public static synchronized void reset() {
		SubstanceProgressBarUI.stripeMap.clear();
	}

	/**
	 * The current state of the indeterminate animation's cycle. 0, the initial
	 * value, means paint the first frame. When the progress bar is
	 * indeterminate and showing, the default animation thread updates this
	 * variable by invoking incrementAnimationIndex() every repaintInterval
	 * milliseconds.
	 */
	private int animationIndex;

	/**
	 * Value change listener on the associated progress bar.
	 */
	protected ChangeListener substanceValueChangeListener;

	/**
	 * Fade kind for the progress bar value change.
	 */
	public static final FadeKind PROGRESS_BAR_VALUE_CHANGED = new FadeKind(
			"substancelaf.progressBarValueChanged");

//	static {
//		FadeConfigurationManager.getInstance().allowFades(PROGRESS_BAR_VALUE_CHANGED);
//	}

	/**
	 * Property name for storing the <code>from</code> value on progress bar
	 * value animation. Is for internal use only.
	 */
	private static final String PROGRESS_BAR_FROM = "substancelaf.internal.from";

	/**
	 * Property name for storing the <code>to</code> value on progress bar
	 * value animation. Is for internal use only.
	 */
	private static final String PROGRESS_BAR_TO = "substancelaf.internal.to";

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new SubstanceProgressBarUI();
	}

	@Override
	protected void installDefaults() {
		super.installDefaults();

		this.progressBar.putClientProperty(PROGRESS_BAR_TO, this.progressBar
				.getValue());
	}

	@Override
	protected void installListeners() {
		super.installListeners();

		final BoundedRangeModel model = this.progressBar.getModel();
		if (model instanceof DefaultBoundedRangeModel) {
			this.substanceValueChangeListener = new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					FadeTracker fadeTracker = FadeTracker.getInstance();
					if (!fadeTracker.isTracked(progressBar,
							PROGRESS_BAR_VALUE_CHANGED)) {
						progressBar.putClientProperty(PROGRESS_BAR_FROM,
								progressBar.getClientProperty(PROGRESS_BAR_TO));
					}
					progressBar.putClientProperty(PROGRESS_BAR_TO, progressBar
							.getValue());
					FadeTracker.getInstance().trackFadeIn(
							PROGRESS_BAR_VALUE_CHANGED, progressBar, false,
							null);
				}
			};
			((DefaultBoundedRangeModel) model)
					.addChangeListener(this.substanceValueChangeListener);
		}
	}

	@Override
	protected void uninstallListeners() {
		BoundedRangeModel model = this.progressBar.getModel();
		if (model instanceof DefaultBoundedRangeModel) {
			((DefaultBoundedRangeModel) model)
					.removeChangeListener(this.substanceValueChangeListener);
		}

		super.uninstallListeners();
	}

	/**
	 * Retrieves stripe image.
	 * 
	 * @param baseSize
	 *            Stripe base in pixels.
	 * @param isRotated
	 *            if <code>true</code>, the resulting stripe image will be
	 *            rotated.
	 * @param colorScheme
	 *            Color scheme to paint the stripe image.
	 * @return Stripe image.
	 */
	private static synchronized BufferedImage getStripe(int baseSize,
			boolean isRotated, ColorScheme colorScheme) {
		String key = "" + baseSize + ":" + isRotated + ":"
				+ SubstanceCoreUtilities.getSchemeId(colorScheme);
		BufferedImage result = SubstanceProgressBarUI.stripeMap.get(key);
		if (result == null) {
			result = SubstanceImageCreator.getStripe(baseSize, colorScheme
					.getUltraLightColor());
			if (isRotated) {
				result = SubstanceImageCreator.getRotated(result, 1);
			}
			SubstanceProgressBarUI.stripeMap.put(key, result);
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicProgressBarUI#paintDeterminate(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void paintDeterminate(Graphics g, JComponent c) {
		if (!(g instanceof Graphics2D)) {
			return;
		}

		Insets b = this.progressBar.getInsets(); // area for border
		int barRectWidth = this.progressBar.getWidth() - (b.right + b.left);
		int barRectHeight = this.progressBar.getHeight() - (b.top + b.bottom);

		// amount of progress to draw
		int amountFull = this.getAmountFull(b, barRectWidth, barRectHeight);

		Graphics2D graphics = (Graphics2D) g;

		// background
		if (this.progressBar.getOrientation() == SwingConstants.HORIZONTAL) {
			SubstanceImageCreator.paintRectangularStripedBackground(graphics,
					b.left, b.top, barRectWidth, barRectHeight + 1,
					SubstanceCoreUtilities.getDisabledScheme(this.progressBar),
					null, 0, false);
		} else { // VERTICAL
			SubstanceImageCreator.paintRectangularStripedBackground(graphics,
					b.left, b.top, barRectWidth + 1, barRectHeight,
					SubstanceCoreUtilities.getDisabledScheme(this.progressBar),
					null, 0, true);
		}

		if (amountFull > 0) {

			ColorScheme fillColorScheme = this.progressBar.isEnabled() ? SubstanceCoreUtilities
					.getActiveScheme(this.progressBar)
					: SubstanceCoreUtilities.getDefaultScheme(this.progressBar);
			if (this.progressBar.getOrientation() == SwingConstants.HORIZONTAL) {
				int barWidth = amountFull;
				int barHeight = barRectHeight;
				if ((barWidth > 0) && (barHeight > 0)) {
					if (c.getComponentOrientation().isLeftToRight()) {
						SubstanceImageCreator.paintProgressBar(g, b.left,
								b.top, barWidth, barHeight, fillColorScheme,
								false);
					} else {
						// fix for RTL determinate horizontal progress bar in
						// 2.3
						SubstanceImageCreator.paintProgressBar(g, b.left
								+ barRectWidth - amountFull, b.top, barWidth,
								barHeight, fillColorScheme, false);
					}
				}
			} else { // VERTICAL
				int barWidth = this.progressBar.getHeight() - b.bottom
						- amountFull;
				int barHeight = barRectWidth;
				if ((barWidth > 0) && (barHeight > 0)) {
					// fix for issue 95. Vertical bar is growing from the bottom
					SubstanceImageCreator.paintProgressBar(g, b.left, barWidth,
							barHeight, amountFull, fillColorScheme, true);
				}
			}
		}

		// Deal with possible text painting
		if (this.progressBar.isStringPainted()) {
			this.paintString(g, b.left, b.top, barRectWidth, barRectHeight,
					amountFull, b);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicProgressBarUI#paintIndeterminate(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void paintIndeterminate(Graphics g, JComponent c) {
		if (!(g instanceof Graphics2D)) {
			return;
		}

		Insets b = this.progressBar.getInsets(); // area for border
		int barRectWidth = this.progressBar.getWidth() - (b.right + b.left);
		int barRectHeight = this.progressBar.getHeight() - (b.top + b.bottom);

		int valComplete = this.animationIndex;// int)
		// (progressBar.getPercentComplete()
		// * barRectWidth);
		Graphics2D graphics = (Graphics2D) g;

		// background
		if (this.progressBar.getOrientation() == SwingConstants.HORIZONTAL) {
			SubstanceImageCreator.paintRectangularStripedBackground(graphics,
					b.left, b.top, barRectWidth, barRectHeight + 1,
					SubstanceCoreUtilities.getDisabledScheme(this.progressBar),
					null, 0, false);
		} else { // VERTICAL
			SubstanceImageCreator.paintRectangularStripedBackground(graphics,
					b.left, b.top, barRectWidth + 1, barRectHeight,
					SubstanceCoreUtilities.getDisabledScheme(this.progressBar),
					null, 0, true);
		}

		ColorScheme fillColorScheme = this.progressBar.isEnabled() ? SubstanceCoreUtilities
				.getActiveScheme(this.progressBar)
				: SubstanceCoreUtilities.getDefaultScheme(this.progressBar);
		if (this.progressBar.getOrientation() == SwingConstants.HORIZONTAL) {
			SubstanceImageCreator.paintRectangularStripedBackground(graphics,
					b.left, b.top, barRectWidth, barRectHeight + 1,
					fillColorScheme, SubstanceProgressBarUI.getStripe(
							barRectHeight + 1, false, fillColorScheme),
					valComplete, false);
		} else { // VERTICAL
			// fix for issue 95. Vertical progress bar rises from the bottom.
			SubstanceImageCreator.paintRectangularStripedBackground(graphics,
					b.left, b.top, barRectWidth + 1, barRectHeight,
					fillColorScheme, SubstanceProgressBarUI.getStripe(
							barRectWidth + 1, true, fillColorScheme), 2
							* barRectWidth + 1 - valComplete, true);
		}

		// Deal with possible text painting
		if (this.progressBar.isStringPainted()) {
			this.paintString(g, b.left, b.top, barRectWidth, barRectHeight,
					barRectWidth, b);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicProgressBarUI#incrementAnimationIndex()
	 */
	@Override
	protected void incrementAnimationIndex() {
		int newValue = this.animationIndex + 1;

		Insets b = this.progressBar.getInsets(); // area for border
		int barRectHeight = this.progressBar.getHeight() - (b.top + b.bottom);
		int barRectWidth = this.progressBar.getWidth() - (b.right + b.left);
		int threshold = 0;
		if (this.progressBar.getOrientation() == SwingConstants.HORIZONTAL) {
			threshold = 2 * barRectHeight + 1;
		} else {
			threshold = 2 * barRectWidth + 1;
		}
		this.animationIndex = newValue % threshold;
		this.progressBar.repaint();
	}

	/**
	 * Returns the memory usage string.
	 * 
	 * @return The memory usage string.
	 */
	public static String getMemoryUsage() {
		StringBuffer sb = new StringBuffer();
		sb.append("SubstanceProgressBarUI: \n");
		sb.append("\t" + SubstanceProgressBarUI.stripeMap.size() + " stripes");
		return sb.toString();
	}

	protected int getAmountFull(Insets b, int width, int height) {
		int amountFull = 0;
		BoundedRangeModel model = progressBar.getModel();

		long span = model.getMaximum() - model.getMinimum();
		double currentValue = model.getValue();
		FadeTracker fadeTracker = FadeTracker.getInstance();
		if (fadeTracker.isTracked(this.progressBar, PROGRESS_BAR_VALUE_CHANGED)) {
			double fade10 = fadeTracker.getFade10(this.progressBar,
					PROGRESS_BAR_VALUE_CHANGED);
			int from = (Integer) progressBar
					.getClientProperty(PROGRESS_BAR_FROM);
			int to = (Integer) progressBar.getClientProperty(PROGRESS_BAR_TO);
			currentValue = from + (int) (fade10 * (to - from) / 10.0);
		}

		double percentComplete = (currentValue - model.getMinimum()) / span;

		if ((model.getMaximum() - model.getMinimum()) != 0) {
			if (progressBar.getOrientation() == JProgressBar.HORIZONTAL) {
				amountFull = (int) Math.round(width * percentComplete);
			} else {
				amountFull = (int) Math.round(height * percentComplete);
			}
		}
		return amountFull;
	}

}
