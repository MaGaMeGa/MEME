/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;

import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.AllDummyDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.ChildAdditionalPanel;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.globalhandlers.UserBreakException;

/** GUI-component for histograms. */
public class MultiHistogramDialog extends AbstractChartDialog implements MouseListener,
																		ActionListener{

	private static final long serialVersionUID = 1L;
	private JTabbedPane tabbed = null;
	private JPanel buttonPanel = null;
	private JButton cancelButton = null;
	private JPanel mainPanel = null;
	private JPanel detailsPanel = null;
	private JPanel titleLine = null;
	private JPanel subtitleLine = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	private JTextField subtitleField = null;
	private JPanel intervalLine = null;
	private JLabel jLabel2 = null;
	private JTextField minField = null;
	private JLabel jLabel3 = null;
	private JTextField maxField = null;
	private JPanel sourcePanel = null;
	private JPanel binLine = null;
	private JComboBox sourceParam = null;
	private JButton advancedButton = null;
	private JLabel jLabel4 = null;
	private JTextField nIntervalField = null;
	private JPanel outOfBoundsPanel = null;
	private JRadioButton putRadioButton = null;
	private JRadioButton ignoreRadioButton = null;
	private JRadioButton writeRadioButton = null;
	private JTextField outliersField = null;
	private ButtonGroup outOfBoundsGroup = null;
	private JPanel modePanel = null;
	private JLabel jLabel8 = null;
	private JComboBox modeBox = null;
	private JPanel appearancePanel = null;
	private JLabel jLabel5 = null;
	private JCheckBox showLegendBox = null;
	private JLabel jLabel6 = null;
	private JComboBox appearanceBox = null;
	private JPopupMenu ComposeMenu = null;
	private JMenuItem mHistogram = null;
	private JMenuItem mRealTimeSeries = null;
	private JMenuItem mScatterPlot = null;
	private JMenuItem mTimeSeries = null;
	private JMenuItem mXYLineChart = null;
	private JPanel rangeAxisPanel = null;
	private JTextField rangeMin = new JTextField();
	private JTextField rangeMax = new JTextField();
	
	private JPanel binPanel = null;
	private JComboBox binParam = null;
	private JButton binButton = null;
	
	private JPanel minPanel = null;
	private JComboBox minParam = null;
	private JButton minButton = null;
	
	private JPanel maxPanel = null;
	private JComboBox maxParam = null;
	private JButton maxButton = null;
	
	private JPanel rangeMinPanel = null;
	private JComboBox rangeMinParam = null;
	private JButton rangeMinButton = null;
	
	private JPanel rangeMaxPanel = null;
	private JComboBox rangeMaxParam = null;
	private JButton rangeMaxButton = null;
	
	private JPopupMenu sourcesContextMenu = new JPopupMenu();
	private AbstractAction removeAction = null;
	private AbstractAction upAction = null;
	private AbstractAction downAction = null;
	private JList sourceList = null;
	private JPanel sortPanel = null;
	private JButton downButton = null;
	private JButton upButton = null;
	private JButton removeButton = null;
	private JScrollPane scrList = null;
	private JPanel selectedPanel = null;
	private JPanel addButtonPanel = null;
	private JButton addButton = null;
	
	//  @jve:decl-index=0:
	
	//============================================================================
	// additional members
	
	/** Internal constant for setting default values. */
	private final static int SETALL = 0;
	
	/** Internal constant for setting default values. */
	private final static int SETMIN = 1;
	
	/** Internal constant for setting default values. */
	private final static int SETMAX = 2;
	
	/** Internal constant for setting default values. */
	private final static int SETINT = 3;
	
	/** Model of the list of selected sources. */
	private DefaultListModel lmodel = null;
	
	/** List of the selected data source producers. */
	private List<IDataSourceProducer> sources = null;
	
	/** Special producer for 'All' combobox item. */
	private AllDummyDataSourceProducer allProducer = new AllDummyDataSourceProducer(); //  @jve:decl-index=0:
	
	private boolean user_defined_lower_bound = true;
	private boolean user_defined_upper_bound = true;
	private boolean user_defined_nr_of_intervals = true;
	private boolean user_defined_range_lower_bound = true;
	private boolean user_defined_range_upper_bound = true;
	
	//============================================================================
	// methods
		
	/** Constructor. 
 	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public MultiHistogramDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		lmodel = new DefaultListModel();
		sources = new LinkedList<IDataSourceProducer>();
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
	}
	
	//----------------------------------------------------------------------------
	/** Constructor.
 	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 * @param child_panel panel that contains the GUI of the other charts in a multi-layered
	 *  chart. 
	 */
	public MultiHistogramDialog(ChartConfig config, ChartConfigCollection cc_collection, JPanel child_panel) {
		super(config,cc_collection);
		lmodel = new DefaultListModel();
		sources = new LinkedList<IDataSourceProducer>();
		this.child_panel = child_panel;
		initialize();
		this.scr = new JScrollPane();
		scr.setViewportView(this.child_panel);
		this.setPreferredSize(new Dimension(619,484));
		this.add(this.scr,1);
		setWidgetDisabled();
		setSettingsFromConfig();
	}

	//----------------------------------------------------------------------------
	/** This method initializes <code>this</code>.*/
	private void initialize() {
		outOfBoundsGroup = new ButtonGroup();
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.setMinimumSize(new Dimension(609, 219));
		this.add(getTabbed(), null);
		this.add(getButtonPanel(), null);
		initializeContextMenu();
	}

	//----------------------------------------------------------------------------
	private JTabbedPane getTabbed() {
		if (tabbed == null) {
			tabbed = new JTabbedPane();
			tabbed.setPreferredSize(new Dimension(609, 168));
			tabbed.addTab("Main Settings",Utilities.icons.get(ChartConstants.MULTI_HISTOGRAM), getMainPanel(), null);
			tabbed.addTab("Details", null, getDetailsPanel(), null);
		}
		return tabbed;
	}

	//----------------------------------------------------------------------------
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = new JPanel();
			buttonPanel.setLayout(new FlowLayout());
			buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
			buttonPanel.add(getEditorButton(), null);
			buttonPanel.add(getComposeButton(), null);
			buttonPanel.add(getDisplayButton(), null);
			buttonPanel.add(getSaveButton(), null);
			buttonPanel.add(getCancelButton(), null);
		}
		return buttonPanel;
	}

	//----------------------------------------------------------------------------
	private JButton getDisplayButton() {
		if (displayButton == null) {
			displayButton = new JButton();
			displayButton.setText("Display");
			displayButton.setMnemonic(KeyEvent.VK_D);
			displayButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					displayChart();
				}
			});
		}
		return displayButton;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}

	//----------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setEnabled(true);
			saveButton.setText("Save");
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.addActionListener(new java.awt.event.ActionListener() {   
				public void actionPerformed(java.awt.event.ActionEvent e) {
					saveCollection();
				}
			
			});
			
			// this is the place where all of the referenced widgets in the default
			// values are not null.
			IDataSourceProducer dsp = (IDataSourceProducer)sourceParam.getSelectedItem();
			defaultValues(dsp,SETALL);
		}
		return saveButton;
	}

	//----------------------------------------------------------------------------
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMnemonic(KeyEvent.VK_C);
			cancelButton.setText("Cancel");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					notifyForHide();
				}
			});
		}
		return cancelButton;
	}

	//----------------------------------------------------------------------------
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(new BoxLayout(getMainPanel(), BoxLayout.Y_AXIS));
			mainPanel.add(getSourcePanel(), null);
			mainPanel.add(getSelectedPanel(), null);
			mainPanel.add(getBinLine(), null);
			mainPanel.add(getIntervalLine(), null);
			mainPanel.add(getRangeAxisPanel());
		}
		return mainPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getDetailsPanel() {
		if (detailsPanel == null) {
			detailsPanel = new JPanel();
			detailsPanel.setLayout(new BoxLayout(getDetailsPanel(), BoxLayout.Y_AXIS));
			detailsPanel.add(getTitleLine(), null);
			detailsPanel.add(getSubtitleLine(), null);
			detailsPanel.add(getAppearancePanel(), null);
			detailsPanel.add(getOutOfBoundsPanel(), null);
		}
		return detailsPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getTitleLine() {
		if (titleLine == null) {
			jLabel = new JLabel();
			jLabel.setText("  Title:  ");
			jLabel.setMinimumSize(new Dimension(125, 16));
			jLabel.setPreferredSize(new Dimension(125, 16));
			titleLine = new JPanel();
			titleLine.setLayout(new BoxLayout(getTitleLine(), BoxLayout.X_AXIS));
			titleLine.setPreferredSize(new Dimension(400, 26));
			titleLine.add(jLabel, null);
			titleLine.add(getTitleField(), null);
		}
		return titleLine;
	}

	//----------------------------------------------------------------------------
	private JPanel getSubtitleLine() {
		if (subtitleLine == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("  Subtitle:  ");
			jLabel1.setPreferredSize(new Dimension(125, 16));
			jLabel1.setMinimumSize(new Dimension(125, 16));
			subtitleLine = new JPanel();
			subtitleLine.setLayout(new BoxLayout(getSubtitleLine(), BoxLayout.X_AXIS));
			subtitleLine.setPreferredSize(new Dimension(400, 26));
			subtitleLine.add(jLabel1, null);
			subtitleLine.add(getSubtitleField(), null);
		}
		return subtitleLine;
	}

	//----------------------------------------------------------------------------
	private JTextField getTitleField() {
		if (titleField == null) {
			titleField = new JTextField();
			titleField.setMaximumSize(new Dimension(2147483647, 30));
			titleField.setText(ChartConstants.MULTI_HISTOGRAM_NAME);
			titleField.setPreferredSize(new Dimension(300, 20));
			titleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.TITLE,titleField.getText());
					ChartDialogChangeCenter.fireTitleChanged(MultiHistogramDialog.this);
				}
			});
			titleField.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					subtitleField.grabFocus();
				}
			});
		}
		return titleField;
	}

	//----------------------------------------------------------------------------
	private JTextField getSubtitleField() {
		if (subtitleField == null) {
			subtitleField = new JTextField();
			subtitleField.setMaximumSize(new Dimension(2147483647, 30));
			subtitleField.setPreferredSize(new Dimension(300, 20));
			subtitleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText()); 
				}
			});
		}
		return subtitleField;
	}

	//----------------------------------------------------------------------------
	private JPanel getIntervalLine() {
		if (intervalLine == null) {
			Dimension gap = new Dimension(5,0);
			jLabel3 = new JLabel();
			jLabel3.setText("Upper domain limit:  ");
			jLabel2 = new JLabel();
			jLabel2.setText("Lower domain limit:  ");
			intervalLine = new JPanel();
			intervalLine.setLayout(new BoxLayout(getIntervalLine(), BoxLayout.X_AXIS));
			intervalLine.setPreferredSize(new Dimension(400, 20));
			intervalLine.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
			intervalLine.add(jLabel2, null);
			intervalLine.add(getMinPanel(), null);
			intervalLine.add(Box.createRigidArea(gap));
			intervalLine.add(minButton);
			intervalLine.add(Box.createRigidArea(gap));
			intervalLine.add(jLabel3, null);
			intervalLine.add(getMaxPanel(), null);
			intervalLine.add(Box.createRigidArea(gap));
			intervalLine.add(maxButton);
		}
		return intervalLine;
	}
	
	//----------------------------------------------------------------------------------------------------
	public JPanel getMinPanel() {
		if (minPanel == null) {
			minPanel = new JPanel(new CardLayout());
			minParam = new JComboBox(getValueParams());
			minParam.setRenderer(new DataSourceComboBoxRenderer(minParam));
			minParam.setPreferredSize(new Dimension(100,26));
			if (minParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) minParam.getSelectedItem();
				minParam.setToolTipText(dsp.toString());
			}
			minParam.setName("MIN_PARAM");
			minParam.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					tooltip(minParam);
				}
			});
			minButton = new JButton("From data source");
			minButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					minButton.setText(user_defined_lower_bound ? "From user input" : "From data source");
					user_defined_lower_bound ^= true; // negating
					CardLayout cl = (CardLayout) minPanel.getLayout();
					cl.show(minPanel,user_defined_lower_bound ? "MIN_FIELD" : "MIN_PARAM");
					displayButton.setEnabled(isUpdateable());
					if (isUpdateable())
						ChartDialogChangeCenter.fireSaveEnabled(MultiHistogramDialog.this);
					else
						ChartDialogChangeCenter.fireSaveDisabled(MultiHistogramDialog.this);
					if (chartDialogParent != null) childStatusChanged();
				}
			});
			getMinField().setName("MIN_FIELD");
			minPanel.add(minField,minField.getName());
			minPanel.add(minParam,minParam.getName());
		}
		return minPanel;
	}
	
	//----------------------------------------------------------------------------------------------------
	public JPanel getMaxPanel() {
		if (maxPanel == null) {
			maxPanel = new JPanel(new CardLayout());
			maxParam = new JComboBox(getValueParams());
			maxParam.setRenderer(new DataSourceComboBoxRenderer(maxParam));
			maxParam.setPreferredSize(new Dimension(100,26));
			if (maxParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) maxParam.getSelectedItem();
				maxParam.setToolTipText(dsp.toString());
			}
			maxParam.setName("MAX_PARAM");
			maxParam.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					tooltip(maxParam);
				}
			});
			maxButton = new JButton("From data source");
			maxButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					maxButton.setText(user_defined_upper_bound ? "From user input" : "From data source");
					user_defined_upper_bound ^= true; // negating
					CardLayout cl = (CardLayout) maxPanel.getLayout();
					cl.show(maxPanel,user_defined_upper_bound ? "MAX_FIELD" : "MAX_PARAM");
					displayButton.setEnabled(isUpdateable());
					if (isUpdateable())
						ChartDialogChangeCenter.fireSaveEnabled(MultiHistogramDialog.this);
					else
						ChartDialogChangeCenter.fireSaveDisabled(MultiHistogramDialog.this);
					if (chartDialogParent != null) childStatusChanged();
				}
			});
			getMaxField().setName("MAX_FIELD");
			maxPanel.add(maxField,maxField.getName());
			maxPanel.add(maxParam,maxParam.getName());
			
		}
		return maxPanel;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JPanel getRangeAxisPanel() {
		if (rangeAxisPanel == null) {
			Dimension d = new Dimension(5,0);
			rangeAxisPanel = new JPanel();
			rangeAxisPanel.setLayout(new BoxLayout(getRangeAxisPanel(),BoxLayout.X_AXIS));
			rangeAxisPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
			rangeAxisPanel.add(new JLabel("Lower range limit:    "));
			rangeAxisPanel.add(getRangeMinPanel());
			rangeAxisPanel.add(Box.createRigidArea(d));
			rangeAxisPanel.add(rangeMinButton);
			rangeAxisPanel.add(Box.createRigidArea(d));
			rangeAxisPanel.add(new JLabel("Upper range limit:    "));
			rangeAxisPanel.add(getRangeMaxPanel());
			rangeAxisPanel.add(Box.createRigidArea(d));
			rangeAxisPanel.add(rangeMaxButton);
		}
		return rangeAxisPanel;
	}
	
	//----------------------------------------------------------------------------------------------------
	public JPanel getRangeMinPanel() {
		if (rangeMinPanel == null) {
			rangeMinPanel = new JPanel(new CardLayout());
			rangeMinParam = new JComboBox(getValueParams());
			rangeMinParam.setRenderer(new DataSourceComboBoxRenderer(rangeMinParam));
			rangeMinParam.setPreferredSize(new Dimension(100,26));
			if (rangeMinParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) rangeMinParam.getSelectedItem();
				rangeMinParam.setToolTipText(dsp.toString());
			}
			rangeMinParam.setName("RANGE_MIN_PARAM");
			rangeMinParam.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					tooltip(rangeMinParam);
				}
			});
			rangeMinButton = new JButton("From data source");
			rangeMinButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					rangeMinButton.setText(user_defined_range_lower_bound ? "From user input" : "From data source");
					user_defined_range_lower_bound ^= true; // negating
					CardLayout cl = (CardLayout) rangeMinPanel.getLayout();
					cl.show(rangeMinPanel,user_defined_range_lower_bound ? "RANGE_MIN_FIELD" : "RANGE_MIN_PARAM");
					displayButton.setEnabled(isUpdateable());
					if (isUpdateable())
						ChartDialogChangeCenter.fireSaveEnabled(MultiHistogramDialog.this);
					else
						ChartDialogChangeCenter.fireSaveDisabled(MultiHistogramDialog.this);
					if (chartDialogParent != null) childStatusChanged();
				}
			});
			rangeMin.setHorizontalAlignment(JTextField.TRAILING);
			rangeMin.setMaximumSize(new Dimension(2147483647, 30));
			rangeMin.setPreferredSize(new Dimension(100, 20));
			rangeMin.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid(rangeMin.getText())) 
						rangeMin.setText("");
				}
			});
			rangeMin.setName("RANGE_MIN_FIELD");
			rangeMinPanel.add(rangeMin,rangeMin.getName());
			rangeMinPanel.add(rangeMinParam,rangeMinParam.getName());
		}
		return rangeMinPanel;
	}

	//----------------------------------------------------------------------------------------------------
	public JPanel getRangeMaxPanel() {
		if (rangeMaxPanel == null) {
			rangeMaxPanel = new JPanel(new CardLayout());
			rangeMaxParam = new JComboBox(getValueParams());
			rangeMaxParam.setRenderer(new DataSourceComboBoxRenderer(rangeMaxParam));
			rangeMaxParam.setPreferredSize(new Dimension(100,26));
			if (rangeMaxParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) rangeMaxParam.getSelectedItem();
				rangeMaxParam.setToolTipText(dsp.toString());
			}
			rangeMaxParam.setName("RANGE_MAX_PARAM");
			rangeMaxParam.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					tooltip(rangeMaxParam);
				}
			});
			rangeMaxButton = new JButton("From data source");
			rangeMaxButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					rangeMaxButton.setText(user_defined_range_upper_bound ? "From user input" : "From data source");
					user_defined_range_upper_bound ^= true; // negating
					CardLayout cl = (CardLayout) rangeMaxPanel.getLayout();
					cl.show(rangeMaxPanel,user_defined_range_upper_bound ? "RANGE_MAX_FIELD" : "RANGE_MAX_PARAM");
					displayButton.setEnabled(isUpdateable());
					if (isUpdateable())
						ChartDialogChangeCenter.fireSaveEnabled(MultiHistogramDialog.this);
					else
						ChartDialogChangeCenter.fireSaveDisabled(MultiHistogramDialog.this);
					if (chartDialogParent != null) childStatusChanged();
				}
			});
			rangeMax.setHorizontalAlignment(JTextField.TRAILING);
			rangeMax.setMaximumSize(new Dimension(2147483647, 30));
			rangeMax.setPreferredSize(new Dimension(100, 20));
			rangeMax.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid(rangeMax.getText())) 
						rangeMax.setText("");
				}
			});
			rangeMax.setName("RANGE_MAX_FIELD");
			rangeMaxPanel.add(rangeMax,rangeMax.getName());
			rangeMaxPanel.add(rangeMaxParam,rangeMaxParam.getName());
		}
		return rangeMaxPanel;
	}

	//----------------------------------------------------------------------------
	private JTextField getMinField() {
		if (minField == null) {
			minField = new JTextField();
			minField.setMaximumSize(new Dimension(2147483647, 30));
			minField.setHorizontalAlignment(JTextField.TRAILING);
			minField.setPreferredSize(new Dimension(100, 20));
			minField.addCaretListener(new javax.swing.event.CaretListener() {
				public void caretUpdate(javax.swing.event.CaretEvent e) {
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(MultiHistogramDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(MultiHistogramDialog.this);
					}
					if (chartDialogParent != null) childStatusChanged();
				}
			});
			minField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid(minField.getText())) {
						minField.setText("");
					}
				}
			});
			
		}
		return minField;
	}

	//----------------------------------------------------------------------------
	private JTextField getMaxField() {
		if (maxField == null) {
			maxField = new JTextField();
			maxField.setMaximumSize(new Dimension(2147483647, 30));
			maxField.setHorizontalAlignment(JTextField.TRAILING);
			maxField.setPreferredSize(new Dimension(100, 20));
			maxField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid(maxField.getText())) {
						maxField.setText("");
					}
				}
			});
			maxField.addCaretListener(new javax.swing.event.CaretListener() {
				public void caretUpdate(javax.swing.event.CaretEvent e) {
					if (isUpdateable()) {
						displayButton.setEnabled(true); 
						ChartDialogChangeCenter.fireSaveEnabled(MultiHistogramDialog.this);
					} else {
						displayButton.setEnabled(false); 
						ChartDialogChangeCenter.fireSaveDisabled(MultiHistogramDialog.this);
					}
					if (chartDialogParent != null) childStatusChanged();
				}
			});
		}
		return maxField;
	}

	//----------------------------------------------------------------------------
	private JPanel getSourcePanel() {
		if (sourcePanel == null) {
			sourcePanel = new JPanel();
			sourcePanel.setLayout(new BoxLayout(getSourcePanel(), BoxLayout.X_AXIS));
			sourcePanel.setBorder(BorderFactory.createTitledBorder(null, "Source", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			sourcePanel.add(getSourceParam(), null);
			sourcePanel.add(Box.createRigidArea(new Dimension(10,0)));
			sourcePanel.add(getAdvancedButton(), null);
			sourcePanel.add(getAddButtonPanel(), null);
			
		}
		return sourcePanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getBinLine() {
		if (binLine == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("Number of intervals/bins:  ");
			binLine = new JPanel();
			binLine.setLayout(new BoxLayout(getBinLine(), BoxLayout.X_AXIS));
			binLine.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
			binLine.add(jLabel4, null);
			binLine.add(getBinPanel(), null);
			binLine.add(Box.createRigidArea(new Dimension(5,0)));
			binLine.add(binButton);
			binLine.add(getModePanel());
		}
		return binLine;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JPanel getBinPanel() {
		if (binPanel == null) {
			binPanel = new JPanel(new CardLayout());
			binParam = new JComboBox(getValueParams());
			binParam.setRenderer(new DataSourceComboBoxRenderer(binParam));
			binParam.setPreferredSize(new Dimension(100,26));
			if (binParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) binParam.getSelectedItem();
				binParam.setToolTipText(dsp.toString());
			}
			binParam.setName("BIN_PARAM");
			binParam.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					tooltip(binParam);
				}
			});
			binButton = new JButton("From data source");
			binButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					binButton.setText(user_defined_nr_of_intervals ? "From user input" : "From data source");
					user_defined_nr_of_intervals ^= true; // negating
					CardLayout cl = (CardLayout) binPanel.getLayout();
					cl.show(binPanel,user_defined_nr_of_intervals ? "BIN_FIELD" : "BIN_PARAM");
					displayButton.setEnabled(isUpdateable());
					if (isUpdateable())
						ChartDialogChangeCenter.fireSaveEnabled(MultiHistogramDialog.this);
					else
						ChartDialogChangeCenter.fireSaveDisabled(MultiHistogramDialog.this);
					if (chartDialogParent != null) childStatusChanged();
				}
			});
			getNIntervalField().setName("BIN_FIELD");
			binPanel.add(nIntervalField,nIntervalField.getName());
			binPanel.add(binParam,binParam.getName());
		}
		return binPanel;
	}

	//----------------------------------------------------------------------------
	private JComboBox getSourceParam() {
		if (sourceParam == null) {
			sourceParam = new JComboBox(getParams());
			sourceParam.setRenderer(new DataSourceComboBoxRenderer(sourceParam));
			sourceParam.setMaximumSize(new Dimension(32767, 30));
			sourceParam.setMinimumSize(new Dimension(100,26));
			if (sourceParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) sourceParam.getSelectedItem();
				sourceParam.setToolTipText(dsp.toString());
			}
			sourceParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) sourceParam.getSelectedItem();
					sourceParam.setToolTipText(dsp.toString());
					advancedButton.setEnabled(dsp.hasAdvancedSettings());
					defaultValues(dsp,SETALL);
					if (nIntervalField.getText().equals("")) nIntervalField.setText("10");
 				}
			});
		}
		return sourceParam;
	}

	//----------------------------------------------------------------------------
	private JButton getAdvancedButton() {
		if (advancedButton == null) {
			advancedButton = new JButton();
			advancedButton.setEnabled(false);
			advancedButton.setText("Advanced...");
			advancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)sourceParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(MultiHistogramDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = sourceParam.getSelectedIndex();
						sourceParam.removeItemAt(index);
						sourceParam.insertItemAt(new_dsp,index);
						sourceParam.setSelectedIndex(index);
					}
				}
			});
			if (sourceParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) sourceParam.getSelectedItem();
				advancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return advancedButton;
	}

	//----------------------------------------------------------------------------
	private JTextField getNIntervalField() {
		if (nIntervalField == null) {
			nIntervalField = new JTextField();
			nIntervalField.setPreferredSize(new Dimension(100, 20));
			nIntervalField.setMaximumSize(new Dimension(2147483647, 20));
			nIntervalField.setText("10");
			nIntervalField.setHorizontalAlignment(JTextField.TRAILING);
			nIntervalField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					if (!is_valid_nri()) {
						nIntervalField.setText("");
						IDataSourceProducer dsp = (IDataSourceProducer)sourceParam.getSelectedItem();
						defaultValues(dsp,SETINT);
						if (nIntervalField.getText().equals("")) nIntervalField.setText("10");
					}
				}
			});
			nIntervalField.addCaretListener(new javax.swing.event.CaretListener() {
				public void caretUpdate(javax.swing.event.CaretEvent e) {
					if (isUpdateable()) {
						displayButton.setEnabled(true);
						ChartDialogChangeCenter.fireSaveEnabled(MultiHistogramDialog.this);
					} else {
						displayButton.setEnabled(false);
						ChartDialogChangeCenter.fireSaveDisabled(MultiHistogramDialog.this);
					}
					if (chartDialogParent != null) childStatusChanged();
				}
			});
		}
		return nIntervalField;
	}

	//----------------------------------------------------------------------------
	private JButton getComposeButton() {
		if (composeButton == null) {
			composeButton = new JButton();
			composeButton.setText("Compose...");
			composeButton.setMnemonic(KeyEvent.VK_M);
			composeButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					getComposeMenu().show(composeButton,45,5);
				}
			});
		}
		return composeButton;
	}

	//----------------------------------------------------------------------------
	private JPopupMenu getComposeMenu() {
		if (ComposeMenu == null) {
			ComposeMenu = new JPopupMenu();
			ComposeMenu.add(getMHistogram());
			ComposeMenu.add(getMScatterPlot());
			ComposeMenu.add(getMTimeSeries());
			ComposeMenu.add(getMRealTimeSeries());
			ComposeMenu.add(getMXYLineChart());
		}
		return ComposeMenu;
	}

	//----------------------------------------------------------------------------
	private JMenuItem getMHistogram() {
		if (mHistogram == null) {
			mHistogram = new JMenuItem();
			mHistogram.setText(ChartConstants.MULTI_HISTOGRAM_NAME);
			mHistogram.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.MULTI_HISTOGRAM);
				}
			});
		}
		return mHistogram;
	}

	//----------------------------------------------------------------------------
	private JMenuItem getMRealTimeSeries() {
		if (mRealTimeSeries == null) {
			mRealTimeSeries = new JMenuItem();
			mRealTimeSeries.setText(ChartConstants.REALTIMESERIES_NAME);
			mRealTimeSeries.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.REALTIMESERIES);
				}
			});
		}
		return mRealTimeSeries;
	}

	//----------------------------------------------------------------------------
	private JMenuItem getMScatterPlot() {
		if (mScatterPlot == null) {
			mScatterPlot = new JMenuItem();
			mScatterPlot.setText(ChartConstants.SCATTERPLOT_NAME);
			mScatterPlot.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.SCATTERPLOT);
				}
			});
		}
		return mScatterPlot;
	}

	//----------------------------------------------------------------------------
	private JMenuItem getMXYLineChart() {
		if (mXYLineChart == null) {
			mXYLineChart = new JMenuItem();
			mXYLineChart.setText(ChartConstants.XYLINECHART_NAME);
			mXYLineChart.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.XYLINECHART);
				}
			});
		}
		return mXYLineChart;
	}

	//----------------------------------------------------------------------------
	private JMenuItem getMTimeSeries() {
		if (mTimeSeries == null) {
			mTimeSeries = new JMenuItem();
			mTimeSeries.setText(ChartConstants.TIMESERIES_NAME);
			mTimeSeries.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addNewChild(ChartConstants.TIMESERIES);
				}
			});
		}
		return mTimeSeries;
	}
	
	//----------------------------------------------------------------------------
	private JPanel getOutOfBoundsPanel() {
		if (outOfBoundsPanel == null) {
			GridLayout gridLayout = new GridLayout(2,0);
			gridLayout.setRows(2);
			outOfBoundsPanel = new JPanel();
			outOfBoundsPanel.setLayout(gridLayout);
			outOfBoundsPanel.setBorder(BorderFactory.createTitledBorder(null, "Handling values outside the interval", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			outOfBoundsPanel.add(getWriteRadioButton(), null);
			outOfBoundsPanel.add(getOutliersField(), null);
			outOfBoundsPanel.add(getPutRadioButton(), null);
			outOfBoundsPanel.add(getIgnoreRadioButton(), null);
		}
		return outOfBoundsPanel;
	}

	//----------------------------------------------------------------------------
	private JRadioButton getPutRadioButton() {
		if (putRadioButton == null) {
			putRadioButton = new JRadioButton();
			putRadioButton.setText("Put them to the first and last bins");
			putRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.OUT_OF_BOUNDS_STRATEGY,ChartConstants.USE_STRATEGY);
					outliersField.setEnabled(false);
				}
			});
			outOfBoundsGroup.add(putRadioButton);
		}
		return putRadioButton;
	}

	//----------------------------------------------------------------------------
	private JRadioButton getIgnoreRadioButton() {
		if (ignoreRadioButton == null) {
			ignoreRadioButton = new JRadioButton();
			ignoreRadioButton.setText("Ignore them");
			ignoreRadioButton.setSelected(true);
			ignoreRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.OUT_OF_BOUNDS_STRATEGY,ChartConstants.IGNORE_STRATEGY);
					outliersField.setEnabled(false);
				}
			});
			outOfBoundsGroup.add(ignoreRadioButton);
		}
		return ignoreRadioButton;
	}

	//----------------------------------------------------------------------------
	private JRadioButton getWriteRadioButton() {
		if (writeRadioButton == null) {
			writeRadioButton = new JRadioButton();
			writeRadioButton.setText("Write them separately in a list named ");
			writeRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.OUT_OF_BOUNDS_STRATEGY,ChartConstants.OUTLIERS_STRATEGY);
					outliersField.setEnabled(true);
				}
			});
			outOfBoundsGroup.add(writeRadioButton);
		}
		return writeRadioButton;
	}
	
	//----------------------------------------------------------------------------
	private JTextField getOutliersField() {
		if (outliersField == null) {
			outliersField = new JTextField();
			outliersField.setText("Outliers");
			outliersField.setEnabled(false);
			outliersField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.OUTLIERS_TITLE,outliersField.getText());
				}
			});
		}
		return outliersField;
	}
	
	//----------------------------------------------------------------------------
	private JPanel getModePanel() {
		if (modePanel == null) {
			jLabel8 = new JLabel();
			jLabel8.setText("  Bin mode:   ");
			modePanel = new JPanel();
			modePanel.setLayout(new BoxLayout(getModePanel(), BoxLayout.X_AXIS));
			modePanel.setEnabled(false);
			modePanel.add(jLabel8, null);
			modePanel.add(getModeBox());
		}
		return modePanel;
	}

	//----------------------------------------------------------------------------
	private JComboBox getModeBox() {
		if (modeBox == null) {
			String[] modes = new String[] { "Frequency", "Sum", "Mean" };
			modeBox = new JComboBox(modes);
			modeBox.setMaximumSize(new Dimension(32323,30));
			modeBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.BIN_MODE,String.valueOf(modeBox.getSelectedIndex()));
				}
			});
		}
		return modeBox;
	}

	//----------------------------------------------------------------------------
	private JPanel getAppearancePanel() {
		if (appearancePanel == null) {
			jLabel6 = new JLabel();
			jLabel6.setText("  Appearance:  ");
			jLabel5 = new JLabel();
			jLabel5.setText("  ");
			jLabel5.setPreferredSize(new Dimension(125, 16));
			appearancePanel = new JPanel();
			appearancePanel.setLayout(new BoxLayout(getAppearancePanel(), BoxLayout.X_AXIS));
			appearancePanel.add(jLabel5, null);
			appearancePanel.add(getShowLegendBox(), null);
			appearancePanel.add(Box.createRigidArea(new Dimension(10,0)));
			appearancePanel.add(jLabel6, null);
			appearancePanel.add(getAppearanceBox(), null);
		}
		return appearancePanel;
	}

	//----------------------------------------------------------------------------
	private JCheckBox getShowLegendBox() {
		if (showLegendBox == null) {
			showLegendBox = new JCheckBox();
			showLegendBox.setSelected(true);
			showLegendBox.setText("Show legend");
			showLegendBox.addItemListener(new java.awt.event.ItemListener() {
				public void itemStateChanged(java.awt.event.ItemEvent e) {
					properties.setProperty(ChartConstants.SHOW_LEGEND,String.valueOf(showLegendBox.isSelected()));
				}
			});
		}
		return showLegendBox;
	}

	//----------------------------------------------------------------------------
	private JComboBox getAppearanceBox() {
		if (appearanceBox == null) {
			Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
			appearances.add(new ComboboxItem( "BC", "Basic, colored"));
			appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
			appearances.add(new ComboboxItem( "NC", "Normal, colored"));
			appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
			for (String templateNames : AbstractChart.templates.keySet())
				appearances.add(new ComboboxItem("_" + templateNames,templateNames));
			appearances.add(new ComboboxItem("_NEW","New template..."));
			appearances.add(new ComboboxItem("_EDIT","Edit template..."));
			appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
			appearanceBox = new JComboBox(appearances);
			appearanceBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int index = appearanceBox.getSelectedIndex();
			 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
					if (index >= 0 && index <= 3) {
				 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
				 		if (code[0].equals("B"))
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.BASIC_APP);
				 		else
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.NORMAL_APP);
				 		if (code[1].equals("BW"))
				 			ChartConfigCollection.setColorAppearance(ChartConstants.BLACK_AND_WHITE);
				 		else
				 			ChartConfigCollection.setColorAppearance(ChartConstants.COLORED);
					}  else if (appearanceCode.equals("_NEW")) {
						ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.NORMAL);
						int result = dlg.showDialog();
						if (result == ChartPropertiesDialog.OK_OPTION) {
							Element newTemplate = (Element) dlg.getTemplate();
							dlg.dispose();
							String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
							AbstractChart.templates.put(name,newTemplate);
							ChartDialogChangeCenter.fireTemplateChanged();
							appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
						} else 
							appearanceBox.setSelectedIndex(0);
					} else if (appearanceCode.equals("_EDIT")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(MultiHistogramDialog.this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(MultiHistogramDialog.this,"Select a template: ","Edit template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template == null || "".equals(template)) 
							appearanceBox.setSelectedIndex(0);
						else {
							Element templateElement = AbstractChart.templates.get(template);
							ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(),ChartKind.NORMAL);
							int result = dlg.showDialog();
							if (result == ChartPropertiesDialog.OK_OPTION) {
								Element newTemplate = (Element) dlg.getTemplate();
								dlg.dispose();
								String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
								AbstractChart.templates.put(name,newTemplate);
								ChartDialogChangeCenter.fireTemplateChanged();
								appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
							} else 
								appearanceBox.setSelectedIndex(0);
						}
					} else if (appearanceCode.equals("_REMOVE")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(MultiHistogramDialog.this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(MultiHistogramDialog.this,"Select a template: ","Delete template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template != null && !"".equals(template)) { 
							AbstractChart.templates.remove(template);
							File file = new File("Templates/" + template + ".xml");
							file.delete();
							ChartDialogChangeCenter.fireTemplateChanged();
						}
						appearanceBox.setSelectedIndex(0);
					}
				}
			});
		}
		return appearanceBox;
	}
	
	//------------------------------------------------------------------------------
	private List<String> getLegends() {
		List<String> result = new ArrayList<String>(1);
		if (sourceParam.isEnabled())
			result.add(sourceParam.getSelectedItem().toString());
		return result;
	}
	
	//=============================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-generated functions                                                //
	////////////////////////////////////////////////////////////////////////////
	
	@Override
	protected void setWidgetDisabled() {
		if (sourceParam.getItemCount() == 0) {
			sourceParam.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			advancedButton.setEnabled(false);
			if (cc_collection.getComposeMode())
				composeButton.setEnabled(false);
		}
		if (binParam.getItemCount() == 0) {
			binParam.setEnabled(false);
			binButton.setEnabled(false);
			minParam.setEnabled(false);
			minButton.setEnabled(false);
			maxParam.setEnabled(false);
			maxButton.setEnabled(false);
			rangeMinParam.setEnabled(false);
			rangeMinButton.setEnabled(false);
			rangeMaxParam.setEnabled(false);
			rangeMaxButton.setEnabled(false);
		}
	}
	
	/** Calculates the default values of lower and upper bounds and the number
	 *  of intervals.
	 * @param dsp the selected data source
	 * @param option where must set the default value
	 * @see #SETALL SETALL
	 * @see #SETMIN SETMIN
	 * @see #SETMAX SETMAX
	 * @see #SETINT SETINT
	 */
	@SuppressWarnings("unchecked")
	private void defaultValues(IDataSourceProducer dsp, int option) {
		if (dsp != null) {
			//minmax = dsp.getRange();
			// Begins a long operations
			try {
				List<Double> minmax = (List<Double>)ChartConfigCollection.
				getLOPExecutor().execute("Calculating lower/upper domain bounds",
										 dsp,"getRange");
				if (minmax != null) {
					Double min = minmax.get(0);
					Double max = minmax.get(1);
					if (option==SETALL || option==SETMIN) 
						minField.setText(min.toString());
					if (option==SETALL || option==SETMAX) 
						maxField.setText(max.toString());
					if (option==SETALL || option==SETINT) {
						int bin = (int) (max.doubleValue() - min.doubleValue() + 1);
						nIntervalField.setText(String.valueOf(bin));
					}
				}
			} catch (UserBreakException e) { return;
			} catch (Throwable t) {
				ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
			}
			
		}
	}
	
	//----------------------------------------------------------------------------
	/** Returns whether the input bound contains a valid real number and less/greater than the other
	 *  bound or not.
	 * @param text the input bound
	 */
	private boolean is_valid(String text) {
		if (text.trim().equals("")) return true;
		try {
			Pattern p = Pattern.compile("^[-]?[0-9]+[.]?[0-9]*$"); // pattern for double numbers 
			Matcher m = p.matcher(text);
			if (text.equals(minField.getText())) {
				double dText = Double.parseDouble(text);
				if (Double.isInfinite(dText) || Double.isNaN(dText)) return false;
				String max = maxField.getText();
				Matcher mm = p.matcher(max);
				if (!mm.matches()) 
					return m.matches();
				double dMax = Double.parseDouble(max);
				if (Double.isInfinite(dMax) || Double.isNaN(dMax)) return false;
				return m.matches() &&  dText < dMax;
			} else if (text.equals(maxField.getText())) {
				double dText = Double.parseDouble(text);
				if (Double.isInfinite(dText) || Double.isNaN(dText)) return false;
				String min = minField.getText();
				Matcher mm = p.matcher(min);
				if (!mm.matches()) 
					return m.matches();
				double dMin = Double.parseDouble(min);
				if (Double.isInfinite(dMin) || Double.isNaN(dMin)) return false;
				return m.matches() && dText > dMin;
			} else if (text.equals(rangeMin.getText())) {
				double dText = Double.parseDouble(text);
				if (Double.isInfinite(dText) || Double.isNaN(dText)) return false;
				String max = rangeMax.getText();
				Matcher mm = p.matcher(max);
				if (!mm.matches()) 
					return m.matches();
				double dMax = Double.parseDouble(max);
				if (Double.isInfinite(dMax) || Double.isNaN(dMax)) return false;
				return m.matches() &&  dText < dMax;
			} else if (text.equals(rangeMax.getText())) {
				double dText = Double.parseDouble(text);
				if (Double.isInfinite(dText) || Double.isNaN(dText)) return false;
				String min = rangeMin.getText();
				Matcher mm = p.matcher(min);
				if (!mm.matches()) 
					return m.matches();
				double dMin = Double.parseDouble(min);
				if (Double.isInfinite(dMin) || Double.isNaN(dMin)) return false;
				return m.matches() && dText > dMin;
			}
		} catch (NumberFormatException e) {}
		return false; 
	}
	
	//----------------------------------------------------------------------------
	/** Returns whether the input string contains a valid integer that greater than
	 *  1 or not;
	 */
	private boolean is_valid_nri() {
		Pattern p = Pattern.compile("^[1-9]|[1-9][0-9]+$"); // pattern for number of intervals
		Matcher m = p.matcher(nIntervalField.getText());
		if (m.matches()) {
			try {
				Integer.parseInt(nIntervalField.getText().trim());
				return true;
			} catch (NumberFormatException e) {}
		}
		return false;
	}
	
	//----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources.
	 * @return array of data sources
	 */
 	private Object[] getParams() {
		return getParams(new Class[] { ISeriesProducer.class, IValueProducer.class });
 	}
 	
 	//----------------------------------------------------------------------------------------------------
 	private Object[] getValueParams() {
 		return getParams(IValueProducer.class);
 	}
 	
	//----------------------------------------------------------------------------
 	@SuppressWarnings("unchecked")
	@Override
 	protected void setSettingsFromConfig() {
 		if (config.getChartProperties() instanceof Properties) {
 			// set settings from the config
 			properties = (Properties) config.getChartProperties();
 			
 			int[] ds = Utilities.splitDatasourceAroundCommas(properties.getProperty(ChartConstants.DATASOURCE));
 			for (int i=0;i<ds.length;++i) {
 				IDataSourceProducer dsp = config.getDataSource(ds[i]);
 	 			sources.add(dsp);
 	 			lmodel.addElement(dsp.toString());
 			}
 			IDataSourceProducer dsp = config.getDataSource(ds[ds.length-1]);
 			
 			//IDataSourceProducer dsp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.DATASOURCE)));
 			sourceParam.setSelectedItem(dsp);
 			user_defined_nr_of_intervals = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_NR_OF_INTERVALS,"true"));
 			if (user_defined_nr_of_intervals) 
 				nIntervalField.setText(properties.getProperty(ChartConstants.NR_OF_INTERVALS));
 			else {
 				CardLayout cl = (CardLayout) binPanel.getLayout();
 				cl.show(binPanel,binParam.getName());
 				IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.NR_OF_INTERVALS)));
 				binParam.setSelectedItem(vp);
 			}
 			user_defined_lower_bound = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_LOWER_BOUND,"true"));
 			if (user_defined_lower_bound) 
 				minField.setText(properties.getProperty(ChartConstants.LOWER_BOUND));
 			else {
 				CardLayout cl = (CardLayout) minPanel.getLayout();
 				cl.show(minPanel,minParam.getName());
 				IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.LOWER_BOUND)));
 				minParam.setSelectedItem(vp);
 			}
 			user_defined_upper_bound = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_UPPER_BOUND,"true"));
 			if (user_defined_upper_bound)
 				maxField.setText(properties.getProperty(ChartConstants.UPPER_BOUND));
 			else {
 				CardLayout cl = (CardLayout) maxPanel.getLayout();
 				cl.show(maxPanel,maxParam.getName());
 				IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.UPPER_BOUND)));
 				maxParam.setSelectedItem(vp);
 			}
 			user_defined_range_lower_bound = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_RANGE_LOWER_BOUND,"true"));
 			if (user_defined_range_lower_bound)
 				rangeMin.setText(properties.getProperty(ChartConstants.RANGE_LOWER_BOUND,""));
 			else {
 				CardLayout cl = (CardLayout) rangeMinPanel.getLayout();
 				cl.show(rangeMinPanel,rangeMinParam.getName());
 				IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.RANGE_LOWER_BOUND)));
 				rangeMinParam.setSelectedItem(vp);
 			}
 			user_defined_range_upper_bound = Boolean.parseBoolean(properties.getProperty(ChartConstants.USER_DEFINED_RANGE_UPPER_BOUND,"true"));
 			if (user_defined_range_upper_bound)
 				rangeMax.setText(properties.getProperty(ChartConstants.RANGE_UPPER_BOUND,""));
 			else {
 				CardLayout cl = (CardLayout) rangeMaxPanel.getLayout();
 				cl.show(rangeMaxPanel,rangeMaxParam.getName());
 				IDataSourceProducer vp = config.getDataSource(Integer.parseInt(properties.getProperty(ChartConstants.RANGE_UPPER_BOUND)));
 				rangeMaxParam.setSelectedItem(vp);
 			}
 			modeBox.setSelectedIndex(Integer.parseInt(properties.getProperty(ChartConstants.BIN_MODE)));
 			titleField.setText(properties.getProperty(ChartConstants.TITLE));
 			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
 			showLegendBox.setSelected(Boolean.parseBoolean(properties.getProperty(ChartConstants.SHOW_LEGEND,"true")));
 			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
 			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
 				String appearanceCode = "";
 				appearanceCode += properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP) ? "N" : "B";
 				appearanceCode += properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE) ? "BW" : "C";
 				for (int i = 0;i < appearanceBox.getItemCount();++i) {
 					String id = ((ComboboxItem)appearanceBox.getItemAt(i)).getID().toString();
 					if (id.equals(appearanceCode)) {
 						appearanceBox.setSelectedIndex(i);
 						break;
 					}
 				}
 			}
 			String strategy = properties.getProperty(ChartConstants.OUT_OF_BOUNDS_STRATEGY);
 			if (strategy.equals(ChartConstants.USE_STRATEGY)) {
 				putRadioButton.setSelected(true);
 				outliersField.setEnabled(false);
 			} else if (strategy.equals(ChartConstants.OUTLIERS_STRATEGY))  {
 				writeRadioButton.setSelected(true);
 				outliersField.setEnabled(true);
 			} 
 			
 			if (sources.size() > 0) {
 				displayButton.setEnabled(true);
 				saveButton.setEnabled(true);
 				removeButton.setEnabled(true);
 			}
 			if (sources.size() > 1) {
 				downButton.setEnabled(true);
 				upButton.setEnabled(true);
 			}
 			
 		} else {
 			// set the initial properties
 			properties.setProperty(ChartConstants.TITLE,ChartConstants.MULTI_HISTOGRAM_NAME);
 			properties.setProperty(ChartConstants.SUBTITLE,"");
 			properties.setProperty(ChartConstants.SHOW_LEGEND,"true");
 			properties.setProperty(ChartConstants.BIN_MODE,String.valueOf(0));
			//properties.setProperty(ChartConstants.OUT_OF_BOUNDS_STRATEGY,ChartConstants.OUTLIERS_STRATEGY);
 			//properties.setProperty(ChartConstants.OUT_OF_BOUNDS_STRATEGY,ChartConstants.USE_STRATEGY);
 			properties.setProperty(ChartConstants.OUT_OF_BOUNDS_STRATEGY,ChartConstants.IGNORE_STRATEGY);
			properties.setProperty(ChartConstants.OUTLIERS_TITLE,"Outliers");
			properties.setProperty(ChartConstants.RANGE_LOWER_BOUND,"");
			properties.setProperty(ChartConstants.RANGE_UPPER_BOUND,"");
 			int appIndex = 0;
 			appIndex += ChartConfigCollection.getColorAppearance().equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
 			appIndex += ChartConfigCollection.getEnvironmentAppearance().equals(ChartConstants.NORMAL_APP) ? 2 : 0;
 			appearanceBox.setSelectedIndex(appIndex);
 			if (sourceParam.getItemCount() > 0) {
 				IDataSourceProducer dsp = (IDataSourceProducer) sourceParam.getSelectedItem();
				String intv = "10";
 				try  {
 					//List<Double> minmax = dsp.getRange();
 					// Begins a long operation
 					List<Double> minmax = (List<Double>)ChartConfigCollection.
 					getLOPExecutor().execute("Calculating domain lower/upper bounds",
											 dsp,"getRange");
 					Double min,max;
 					if (minmax != null) {
 						min = minmax.get(0);
 						max = minmax.get(1);
 						int bin = (int)(max.doubleValue() - min.doubleValue() + 1);
 						intv = String.valueOf(bin);
 						properties.setProperty(ChartConstants.LOWER_BOUND,min.toString());
 						properties.setProperty(ChartConstants.UPPER_BOUND,max.toString());
 					}
 				} catch (UserBreakException e) {
 				} catch (Throwable t) {
 					ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
 				} finally {
 					properties.setProperty(ChartConstants.NR_OF_INTERVALS,intv);
 				}
 			}
 		}
 	}
 	
	//----------------------------------------------------------------------------
 	@Override
 	public void updateChartConfig() {
 		
 		config.clearAllDataSource();
 		Iterator<IDataSourceProducer> it = sources.iterator();
 		String ds = "";
 		while (it.hasNext()) {
 			IDataSourceProducer dsp = it.next();
 			if (dsp.getSupportedIntfs().contains(IValueProducer.class)) { // source supports the IValueProducer
 				int key = config.addDataSource(dsp,IValueProducer.class);
 				ds += String.valueOf(key) + ",";
 			} else { // source supports ISeriesProducer
 				int key = config.addDataSource(dsp,ISeriesProducer.class);
 				ds += String.valueOf(key) + ",";
 			}
 		}
 		
 		properties.setProperty(ChartConstants.DATASOURCE,ds.substring(0,ds.length()-1));
 		properties.setProperty(ChartConstants.USER_DEFINED_LOWER_BOUND,String.valueOf(user_defined_lower_bound));
 		IDataSourceProducer dsp;
 		int key = -1;
 		
 		if (user_defined_lower_bound)
 			properties.setProperty(ChartConstants.LOWER_BOUND,minField.getText());
 		else {
 			dsp = (IDataSourceProducer) minParam.getSelectedItem();
 			if (dsp == null) {
 				properties.setProperty(ChartConstants.USER_DEFINED_LOWER_BOUND,"true");
 				properties.setProperty(ChartConstants.LOWER_BOUND,"");
 			} else {
 				if (dsp.getSupportedIntfs().contains(IValueProducer.class))
 					key = config.addDataSource(dsp,IValueProducer.class);
 				else // need emulation
 					key = config.addDataSource(dsp,ISeriesProducer.class);
 				properties.setProperty(ChartConstants.LOWER_BOUND,String.valueOf(key));
 			}
 		}
 		properties.setProperty(ChartConstants.USER_DEFINED_UPPER_BOUND,String.valueOf(user_defined_upper_bound));
 		if (user_defined_upper_bound)
 			properties.setProperty(ChartConstants.UPPER_BOUND,maxField.getText());
 		else {
 			dsp = (IDataSourceProducer) maxParam.getSelectedItem();
 			if (dsp == null) {
 				properties.setProperty(ChartConstants.USER_DEFINED_UPPER_BOUND,"true");
 				properties.setProperty(ChartConstants.UPPER_BOUND,"");
 			} else {
 				if (dsp.getSupportedIntfs().contains(IValueProducer.class))
 					key = config.addDataSource(dsp,IValueProducer.class);
 				else // need emulation
 					key = config.addDataSource(dsp,ISeriesProducer.class);
 				properties.setProperty(ChartConstants.UPPER_BOUND,String.valueOf(key));
 			}
 		}
 		properties.setProperty(ChartConstants.USER_DEFINED_RANGE_LOWER_BOUND,String.valueOf(user_defined_range_lower_bound));
 		if (user_defined_range_lower_bound)
 			properties.setProperty(ChartConstants.RANGE_LOWER_BOUND,rangeMin.getText());
 		else {
 			dsp = (IDataSourceProducer) rangeMinParam.getSelectedItem();
 			if (dsp == null) {
 				properties.setProperty(ChartConstants.USER_DEFINED_RANGE_LOWER_BOUND,"true");
 				properties.setProperty(ChartConstants.RANGE_LOWER_BOUND,"");
 			} else {
 				if (dsp.getSupportedIntfs().contains(IValueProducer.class))
 					key = config.addDataSource(dsp,IValueProducer.class);
 				else // need emulation
 					key = config.addDataSource(dsp,ISeriesProducer.class);
 				properties.setProperty(ChartConstants.RANGE_LOWER_BOUND,String.valueOf(key));
 			}
 		}
 		properties.setProperty(ChartConstants.USER_DEFINED_RANGE_UPPER_BOUND,String.valueOf(user_defined_range_upper_bound));
 		if (user_defined_range_upper_bound)
 			properties.setProperty(ChartConstants.RANGE_UPPER_BOUND,rangeMax.getText());
 		else {
 			dsp = (IDataSourceProducer) rangeMaxParam.getSelectedItem();
 			if (dsp == null) {
 				properties.setProperty(ChartConstants.USER_DEFINED_RANGE_UPPER_BOUND,"true");
 				properties.setProperty(ChartConstants.RANGE_UPPER_BOUND,"");
 			} else {
 				if (dsp.getSupportedIntfs().contains(IValueProducer.class))
 					key = config.addDataSource(dsp,IValueProducer.class);
 				else // need emulation
 					key = config.addDataSource(dsp,ISeriesProducer.class);
 				properties.setProperty(ChartConstants.RANGE_UPPER_BOUND,String.valueOf(key));
 			}
 		}
 		properties.setProperty(ChartConstants.USER_DEFINED_NR_OF_INTERVALS,String.valueOf(user_defined_nr_of_intervals));
 		if (user_defined_nr_of_intervals)
 			properties.setProperty(ChartConstants.NR_OF_INTERVALS,nIntervalField.getText());
 		else {
 			dsp = (IDataSourceProducer) binParam.getSelectedItem();
 			if (dsp == null) {
 				properties.setProperty(ChartConstants.USER_DEFINED_NR_OF_INTERVALS,"true");
 				properties.setProperty(ChartConstants.NR_OF_INTERVALS,"10");
 			} else {
 				if (dsp.getSupportedIntfs().contains(IValueProducer.class))
 					key = config.addDataSource(dsp,IValueProducer.class);
 				else // need emulation
 					key = config.addDataSource(dsp,ISeriesProducer.class);
 				properties.setProperty(ChartConstants.NR_OF_INTERVALS,String.valueOf(key));
 			}
 		}
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 3) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
			String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
	 		if (code[0].equals("B"))
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.BASIC_APP);
	 		else
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.NORMAL_APP);
	 		if (code[1].equals("BW"))
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.BLACK_AND_WHITE);
	 		else
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.COLORED);
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
 		config.setChartProperties(ChartConstants.MULTI_HISTOGRAM,properties);
 		if (config.isMultiLayerChart()) {
 			for (int i = 1;i < child_panel.getComponentCount();i += 2) {
 				((AbstractChartDialog)child_panel.getComponent(i)).updateChartConfig();
 			}
 		}
 	}
 	
	//----------------------------------------------------------------------------
 	@Override
 	public boolean isUpdateable() {
 		boolean lb_valid = (user_defined_lower_bound && is_valid(minField.getText())) || !user_defined_lower_bound;
 		boolean ub_valid = (user_defined_upper_bound && is_valid(maxField.getText())) || !user_defined_upper_bound;
 		boolean bin_valid = (user_defined_nr_of_intervals && is_valid_nri()) || (!user_defined_nr_of_intervals && binParam.getItemCount() > 0);
 		boolean rlb_valid = (user_defined_range_lower_bound && is_valid(rangeMin.getText())) || !user_defined_range_lower_bound;
 		boolean rub_valid = (user_defined_range_upper_bound && is_valid(rangeMax.getText())) || !user_defined_range_upper_bound;
 		
 		boolean own_update = sourceParam.getItemCount() > 0 && lb_valid && ub_valid &&
 							 rlb_valid && rub_valid && bin_valid;
 		
 		if (!config.isMultiLayerChart()) return !sources.isEmpty();
 		

 		
 		if (!config.isMultiLayerChart()) return own_update ;
 		boolean update = own_update;
 		for (int i = 1;i < child_panel.getComponentCount();i += 2) {
 			if (!update) break;
 			update = update && ((AbstractChartDialog)child_panel.getComponent(i)).isUpdateable();
 		}	
 		return update;
 	}
 	
	//----------------------------------------------------------------------------
 	@Override
 	public void setChildMode(boolean realTimeSeriesParent) {
 		this.remove(buttonPanel);
 		jLabel.setEnabled(false);
 		titleField.setText("");
 		titleField.setEnabled(false);
 		jLabel1.setEnabled(false);
 		subtitleField.setEnabled(false);
 		showLegendBox.setEnabled(false);
 		jLabel6.setEnabled(false);
 		appearanceBox.setEnabled(false);
 		rangeMinButton.setEnabled(false);
 		rangeMaxButton.setEnabled(false);
 		cap = new ChildAdditionalPanel(this,properties,AbstractChart.find(config.getChartType()).toString());
 		add(cap,0);
  	}
 	
	//----------------------------------------------------------------------------
 	@Override
 	public void setComposeButton(boolean invisibled) {
		composeButton.setVisible(!invisibled);
	}
 	
	//----------------------------------------------------------------------------
 	@Override
 	protected void removeChild(AbstractChartDialog who) {
 		config.removeChild(who.config);
 		child_panel.remove(who);
 		int count = child_panel.getComponentCount();
 		for (int i = 0;i < count - 1; ++i) {
 			if (child_panel.getComponent(i) instanceof JSeparator && 
 				child_panel.getComponent(i + 1) instanceof JSeparator) {
 				child_panel.remove(i);
 				break;
 			}
		}
 		count = child_panel.getComponentCount();
 		if (child_panel.getComponent(count - 1) instanceof JSeparator)
 			child_panel.remove(count - 1);
		if (!config.isMultiLayerChart()) {
			scr.setVisible(false);
			this.setPreferredSize(new Dimension(609,219));
 			child_panel = null;
 		}
		Utilities.repack(this);
 	}
 	
	//----------------------------------------------------------------------------
 	@Override
 	protected void setSelectedAxis(AbstractChartDialog who) {
 		for (int i = 1;i < child_panel.getComponentCount();i += 2) {
 			if (!child_panel.getComponent(i).equals(who))
 				((AbstractChartDialog)child_panel.getComponent(i)).cap.setAxisDisabled();
 		}
 	}

	//----------------------------------------------------------------------------
 	@Override
	protected void displayPreview()throws Exception {
		DataSources ds = new DataSources(new SimpleDSPCollection());
		ChartConfig temp_config = new ChartConfig(ds);
		temp_config.setFireInitialEvent(true);
		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
		Properties temp_prop = (Properties) properties.clone();
		temp_config.addDataSource(dsl.get(1),ISeriesProducer.class);
		temp_config.addDataSource(dsl.get(2),ISeriesProducer.class);
		temp_prop.setProperty(ChartConstants.DATASOURCE,"1,2");
		if (!user_defined_lower_bound) {
			temp_prop.setProperty(ChartConstants.USER_DEFINED_LOWER_BOUND,"true");
			temp_prop.setProperty(ChartConstants.LOWER_BOUND,"");
		}
		if (!user_defined_upper_bound) {
			temp_prop.setProperty(ChartConstants.USER_DEFINED_UPPER_BOUND,"true");
			temp_prop.setProperty(ChartConstants.UPPER_BOUND,"");
		}
		if (!user_defined_range_lower_bound) {
			temp_prop.setProperty(ChartConstants.USER_DEFINED_RANGE_LOWER_BOUND,"true");
			temp_prop.setProperty(ChartConstants.RANGE_LOWER_BOUND,"");
		}
		if (!user_defined_range_upper_bound) {
			temp_prop.setProperty(ChartConstants.USER_DEFINED_RANGE_UPPER_BOUND,"true");
			temp_prop.setProperty(ChartConstants.RANGE_UPPER_BOUND,"");
		}
		if (!user_defined_nr_of_intervals) {
			temp_prop.setProperty(ChartConstants.USER_DEFINED_NR_OF_INTERVALS,"true");
			temp_prop.setProperty(ChartConstants.NR_OF_INTERVALS,"10");
		}
		temp_prop.setProperty(ChartConstants.TITLE,temp_prop.getProperty(ChartConstants.TITLE) + " (Preview illustration)");
		temp_config.setChartProperties(ChartConstants.MULTI_HISTOGRAM,temp_prop);
		Utilities.displayPreview(temp_config);
	}
 	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem) appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		// reset widgets
		sourceParam.setEnabled(true);
		advancedButton.setEnabled(true);
		if (cc_collection.getComposeMode())
			composeButton.setEnabled(true);
		binParam.setEnabled(true);
		binButton.setEnabled(true);
		minParam.setEnabled(true);
		minButton.setEnabled(true);
		maxParam.setEnabled(true);
		maxButton.setEnabled(true);
		rangeMinParam.setEnabled(true);
		rangeMaxParam.setEnabled(true);
		if (chartDialogParent == null) {
			rangeMinButton.setEnabled(true);
			rangeMaxButton.setEnabled(true);
		}
		
		Object sourceObject = sourceParam.getSelectedIndex() == -1 ? null : sourceParam.getSelectedItem();
		Object binObject = binParam.getSelectedIndex() == -1 ? null : binParam.getSelectedItem();
		Object minObject = minParam.getSelectedIndex() == -1 ? null : minParam.getSelectedItem();
		Object maxObject = maxParam.getSelectedIndex() == -1 ? null : maxParam.getSelectedItem();
		Object rangeMinObject = rangeMinParam.getSelectedIndex() == -1 ? null : rangeMinParam.getSelectedItem();
		Object rangeMaxObject = rangeMaxParam.getSelectedIndex() == -1 ? null : rangeMaxParam.getSelectedItem();
		
		DefaultComboBoxModel sourceModel = new DefaultComboBoxModel(getParams());
		sourceParam.setModel(sourceModel);
		DefaultComboBoxModel binModel = new DefaultComboBoxModel(getValueParams());
		binParam.setModel(binModel);
		DefaultComboBoxModel minModel = new DefaultComboBoxModel(getValueParams());
		minParam.setModel(minModel);
		DefaultComboBoxModel maxModel = new DefaultComboBoxModel(getValueParams());
		maxParam.setModel(maxModel);
		DefaultComboBoxModel rangeMinModel = new DefaultComboBoxModel(getValueParams());
		rangeMinParam.setModel(rangeMinModel);
		DefaultComboBoxModel rangeMaxModel = new DefaultComboBoxModel(getValueParams());
		rangeMaxParam.setModel(rangeMaxModel);
		
		if (sourceObject != null && findInComboBox(sourceModel,(IDataSourceProducer)sourceObject) != -1) {
			int idx = findInComboBox(sourceModel,(IDataSourceProducer)sourceObject);
			sourceParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (binObject != null && findInComboBox(binModel,(IDataSourceProducer)binObject) != -1) {
			int idx = findInComboBox(binModel,(IDataSourceProducer)binObject);
			binParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (minObject != null && findInComboBox(minModel,(IDataSourceProducer)minObject) != -1) {
			int idx = findInComboBox(minModel,(IDataSourceProducer)minObject);
			minParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (maxObject != null && findInComboBox(maxModel,(IDataSourceProducer)maxObject) != -1) {
			int idx = findInComboBox(maxModel,(IDataSourceProducer)maxObject);
			maxParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (rangeMinObject != null && findInComboBox(rangeMinModel,(IDataSourceProducer)rangeMinObject) != -1) {
			int idx = findInComboBox(rangeMinModel,(IDataSourceProducer)rangeMinObject);
			rangeMinParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (rangeMaxObject != null && findInComboBox(rangeMaxModel,(IDataSourceProducer)rangeMaxObject) != -1) {
			int idx = findInComboBox(rangeMaxModel,(IDataSourceProducer)rangeMaxObject);
			rangeMaxParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		
		List<IDataSourceProducer> newSources = new ArrayList<IDataSourceProducer>();
		for (IDataSourceProducer prod : sources) {
			int idx = findInComboBox(sourceModel,prod);
			if (idx != -1) 
				newSources.add((IDataSourceProducer)sourceModel.getElementAt(idx));
		}
		sources = newSources;
		lmodel.clear();
		for (IDataSourceProducer prod : newSources) 
			lmodel.addElement(prod.toString());
		downButton.setEnabled(sources.size() >= 2);
		upButton.setEnabled(sources.size() >= 2);
		removeButton.setEnabled(sources.size() != 0);
		
		validate();
		setWidgetDisabled();
		
		for (int i = 1;i < child_panel.getComponentCount();i += 2) 
			((AbstractChartDialog)child_panel.getComponent(i)).reloadDataSources();

		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
		if (chartDialogParent != null)
			childStatusChanged();
	}
	
	//----------------------------------------------------------------------------------------------------
	private void tooltip(JComboBox param) {
		IDataSourceProducer dsp = (IDataSourceProducer) param.getSelectedItem();
		if (dsp != null)
			param.setToolTipText(dsp.toString());	
	}
	
	//-------------------------------------------------------------------------------
	/** This method initializes the context menu of the selected sources list.*/
	@SuppressWarnings("serial")
	private void initializeContextMenu() {
		downAction = new AbstractAction() {
			{
				putValue(NAME,"Down");
				putValue(ACTION_COMMAND_KEY,"DOWN");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		sourcesContextMenu.add(downAction);
		upAction = new AbstractAction() {
			{
				putValue(NAME,"Up");
				putValue(ACTION_COMMAND_KEY,"UP");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		sourcesContextMenu.add(upAction);
		removeAction = new AbstractAction() {
			{
				putValue(NAME,"Remove");
				putValue(ACTION_COMMAND_KEY,"REMOVE");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		sourcesContextMenu.add(removeAction);
	}

	//-------------------------------------------------------------------------------
	/** Forwards the ActionEvent <code>e</code> to the general handler.
	 * @param action the action object 
	 * @param e the event
	 */
	private void contextEvent(AbstractAction action, ActionEvent e) {
		if (sourceList.getSelectedIndex() == -1) {
			int x = ((Integer)action.getValue("X")).intValue();
			int y = ((Integer)action.getValue("Y")).intValue();
			int index = sourceList.locationToIndex(new Point(x,y));
			sourceList.setSelectedIndex(index);
		}
		MultiHistogramDialog.this.actionPerformed(e);
	}
	
	//------------------------------------------------------------------------------
	private JScrollPane getScrList() {
		if (scrList == null) {
			scrList = new JScrollPane();
			scrList.setAutoscrolls(true);
			scrList.setViewportView(getSourceList());
			scrList.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			scrList.setWheelScrollingEnabled(true);
		}
		return scrList;
	}

	//------------------------------------------------------------------------------
	private JList getSourceList() {
		if (sourceList == null) {
			sourceList = new JList(lmodel);
			sourceList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			sourceList.setAutoscrolls(true);
			sourceList.addMouseListener(this);
		}
		return sourceList;
	}
	
	//-------------------------------------------------------------------------------
 	/** This method handles all ActionEvent-s of the panel. It is public because of
 	 *  implementation side effect. Do not call or override.
 	 * @param event event
 	 */
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if (cmd.equals("DOWN")) {
			move(1);
		} else if (cmd.equals("UP")) {
			move(-1);
		} else if (cmd.equals("REMOVE")) {
			int[] selected = sourceList.getSelectedIndices();
			while (selected.length != 0) {
				sources.remove(selected[0]);
				lmodel.remove(selected[0]);
				selected = sourceList.getSelectedIndices();
			}
			//updateValueAxisLabel();

			// disable the buttons (if need)
			if (sources.size() < 2) {
				downButton.setEnabled(false);
				upButton.setEnabled(false);
			}
			if (sources.size() == 0) {
				removeButton.setEnabled(false);
				displayButton.setEnabled(false);
				ChartDialogChangeCenter.fireSaveDisabled(this);
				if (chartDialogParent != null) childStatusChanged();
			}
		}
	}
	
	//-----------------------------------------------------------------------------
	/** Moves the selected elements in the selected sources list.
	 * @param offset the direction of the move (possible values: -1,1)
	 */
	private void move(int offset) {
		int[] selected = sourceList.getSelectedIndices();
		
		List<int[]> intervals = new ArrayList<int[]>();
		int start = selected[0], end = -1, previous = selected[0] - 1;

		for (int i=0;i<selected.length;++i) {
				if (selected[i] == previous + 1) previous = selected[i];
				else {
					end = previous;
					int[] intv = { start, end };
					intervals.add(intv);
					end = -1;
					start = previous = selected[i];
				}
		}
		intervals.add(new int[] { start, selected[selected.length-1] });
		
		sourceList.clearSelection();
		for (int[] intv : intervals) {
			int to = intv[0] + offset;
			if (0 <= intv[0] && 0 <= to && intv[1] + offset < lmodel.size()) {
				moveInterval(intv[0],intv[1],to);
				sourceList.getSelectionModel().addSelectionInterval(intv[0] + offset,intv[1] + offset);
			} else 
				sourceList.getSelectionModel().addSelectionInterval(intv[0],intv[1]);
		}
		//updateValueAxisLabel();
	}
	
	//-------------------------------------------------------------------------------
	/** Moves the elements in the selected sources list. The indices of the moved
	 *  elements are in the interval [<code>start</code>,<code>end</code>]. 
	 * @param to the new index of the first element
	 */
	private void moveInterval(int start, int end, int to) {
		int temp = to;
		String[] path = new String[end - start + 1];
		IDataSourceProducer[] dsps = new IDataSourceProducer[end - start + 1];
		for (int i = start;i <= end; ++i) {
			path[i - start] = (String)lmodel.get(i);
			dsps[i - start] = sources.get(i);
		}
		lmodel.removeRange(start,end);
		sources.removeAll(Arrays.asList(dsps));
		for (int i = 0;i < path.length;++i) {
			lmodel.add(temp,path[i]);
			sources.add(temp++,dsps[i]);
		}
	}
	//------------------------------------------------------------------------------
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	
	//-------------------------------------------------------------------------------
	/** This method haldles all released mouse events of the panel. It is public 
	 *  because of implementation side effect. Do not call or override.
	 * @param e event
	 */
	public void mouseReleased(MouseEvent e) {
		if (!SwingUtilities.isRightMouseButton(e))
			return;
		if (e.getComponent().isEnabled()) {
			downAction.setEnabled(sourceList.getModel().getSize() > 1);
			upAction.setEnabled(sourceList.getModel().getSize() > 1);
			removeAction.setEnabled(sourceList.getModel().getSize() != 0);
			if (sourceList.getModel().getSize() > 1) {
				downAction.putValue("X",e.getX());
				downAction.putValue("Y",e.getY());
				upAction.putValue("X",e.getX());
				upAction.putValue("Y",e.getY());
			}
			if (sourceList.getModel().getSize() != 0) {
				removeAction.putValue("X",e.getX());
				removeAction.putValue("Y",e.getY());
			}
			sourcesContextMenu.show(e.getComponent(),e.getX(),e.getY());
		}
	}
	
	//------------------------------------------------------------------------------
	private JPanel getSelectedPanel() {
		if (selectedPanel == null) {
			selectedPanel = new JPanel();
			selectedPanel.setLayout(new BoxLayout(getSelectedPanel(), BoxLayout.Y_AXIS));
			selectedPanel.setBorder(BorderFactory.createTitledBorder(null, "Selected sources", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			selectedPanel.setPreferredSize(new Dimension(150, 100));
			selectedPanel.setMinimumSize(new Dimension(150, 100));
			selectedPanel.add(getScrList(), null);
			selectedPanel.add(getSortPanel(), null);
		}
		return selectedPanel;
	}
	
	//------------------------------------------------------------------------------
	private JPanel getSortPanel() {
		if (sortPanel == null) {
			sortPanel = new JPanel();
			sortPanel.setLayout(new FlowLayout());
			sortPanel.setPreferredSize(new Dimension(150, 36));
			sortPanel.setMinimumSize(new Dimension(150, 36));
			sortPanel.add(getDownButton(), null);
			sortPanel.add(getUpButton(), null);
			sortPanel.add(getRemoveButton(), null);
		}
		return sortPanel;
	}
	
	//------------------------------------------------------------------------------
	private JButton getDownButton() {
		if (downButton == null) {
			downButton = new JButton();
			downButton.setEnabled(false);
			downButton.setText("Down");
			downButton.setMnemonic(KeyEvent.VK_DOWN);
			downButton.setActionCommand("DOWN");
			downButton.addActionListener(this);
		}
		return downButton;
	}

	//------------------------------------------------------------------------------
	private JButton getUpButton() {
		if (upButton == null) {
			upButton = new JButton();
			upButton.setEnabled(false);
			upButton.setMnemonic(KeyEvent.VK_UP);
			upButton.setText("Up");
			upButton.setActionCommand("UP");
			upButton.setMaximumSize(new Dimension(66, 26));
			upButton.addActionListener(this);
		}
		return upButton;
	}

	//------------------------------------------------------------------------------
	private JButton getRemoveButton() {
		if (removeButton == null) {
			removeButton = new JButton();
			removeButton.setMnemonic(KeyEvent.VK_R);
			removeButton.setEnabled(false);
			removeButton.setText("Remove");
			removeButton.setActionCommand("REMOVE");
			removeButton.addActionListener(this);
		}
		return removeButton;
	}
	
	//------------------------------------------------------------------------------
	private JPanel getAddButtonPanel() {
		if (addButtonPanel == null) {
			addButtonPanel = new JPanel();
			addButtonPanel.setLayout(new FlowLayout());
			addButtonPanel.add(getAddButton(), null);
		}
		return addButtonPanel;
	}
	
	//------------------------------------------------------------------------------
	private JButton getAddButton() {
		if (addButton == null) {
			addButton = new JButton();
			addButton.setMnemonic(KeyEvent.VK_A);
			addButton.setText("Add");
			addButton.setIcon(Utilities.getIcon("RIGHT ARROW"));
			addButton.setIconTextGap(2);
			addButton.setHorizontalTextPosition(JButton.LEADING);
			final MultiHistogramDialog tthis = this;
			addButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)sourceParam.getSelectedItem();
					if (dsp.equals(allProducer)) {
						// special data source
						for (int i=0;i<sourceParam.getItemCount();++i) {
							IDataSourceProducer p = (IDataSourceProducer)sourceParam.getItemAt(i);
							if (p.equals(allProducer) || sources.contains(p)) continue;
							sources.add(p);
							lmodel.addElement(p.toString());
						}
					} else {
						if (sources.contains(dsp)) return; //repeated source
						sources.add(dsp); // add new source
						lmodel.addElement(dsp.toString()); // display it in the list
					}
					if (sources.size()>0) {
						removeButton.setEnabled(true);
						if (isUpdateable()) {
							displayButton.setEnabled(true);
							ChartDialogChangeCenter.fireSaveEnabled(tthis);
						}
						if (chartDialogParent != null) childStatusChanged();
					}
					if (sources.size()>1) {
						downButton.setEnabled(true);
						upButton.setEnabled(true);
					}
				}
			});
		}
		return addButton;
	}
	
	@SuppressWarnings("unused")
	private Object[] getSources() {
 		Object[] res = getParams(IValueProducer.class);
 		if (res.length != 0) {
 			List<Object> resPlus = new ArrayList<Object>(Arrays.asList(res));
 			resPlus.add(allProducer);
 			return resPlus.toArray();
 		}
 		return res;
 	}
	
}