/** This is the main package of the CHARTING PACKAGE (CP). It contains the most important
  * classes  and interfaces that you must know to use the CP. The CP uses the
  * ai.aitia.visualization package so you should read the documentation of that package,
  * too. */
package ai.aitia.chart;