/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;

import javax.swing.JComponent;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.plaf.UIResource;
import javax.swing.text.JTextComponent;

import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * Gradient border for the <b>Substance</b> look and feel. This class is <b>for
 * internal use only</b>.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceBorder implements Border, UIResource {
	/**
	 * Insets of <code>this</code> border.
	 */
	protected Insets myInsets;

	/**
	 * Background delegate.
	 */
	private static SubstanceFillBackgroundDelegate bgDelegate = new SubstanceFillBackgroundDelegate(
			0.6f);

	/**
	 * Creates a new border with the insets of the specified size.
	 * 
	 * @param insetSize
	 *            Inset size.
	 */
	public SubstanceBorder(int insetSize) {
		super();
		this.myInsets = new Insets(insetSize, insetSize, insetSize, insetSize);
	}

	/**
	 * Creates a new border with the specified insets.
	 * 
	 * @param insets
	 *            Insets.
	 */
	public SubstanceBorder(Insets insets) {
		super();
		this.myInsets = new Insets(insets.top, insets.left, insets.bottom,
				insets.right);
	}

	/**
	 * Creates a new border with default insets (2 pixels).
	 */
	public SubstanceBorder() {
		this(2);
	}

	/**
	 * Paints border instance for the specified component.
	 * 
	 * @param c
	 *            The component.
	 * @param g
	 *            Graphics context.
	 * @param x
	 *            Component left X (in graphics context).
	 * @param y
	 *            Component top Y (in graphics context).
	 * @param width
	 *            Component width.
	 * @param height
	 *            Component height.
	 * @param isEnabled
	 *            Component enabled status.
	 * @param hasFocus
	 *            Component focus ownership status.
	 */
	private static void paintBorder(Component c, Graphics g, int x, int y,
			int width, int height, boolean isEnabled, boolean hasFocus) {
		// failsafe for LAF change
		if (!(UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel)) {
			return;
		}

		Graphics2D graphics = (Graphics2D) g.create();
		graphics.setComposite(TransitionLayout.getAlphaComposite(c));

		if (SubstanceCoreUtilities.toBleedWatermark(c)) {
			if (c instanceof JComponent) {
				Border b = ((JComponent) c).getBorder();
				if (b != null) {
					Graphics2D graphics2 = (Graphics2D) graphics.create();
					Shape clip = graphics2.getClip();
					Insets ins = b.getBorderInsets(c);
					graphics2.clipRect(x, y, ins.left, height);
					bgDelegate.update(graphics2, c);
					graphics2.setClip(clip);
					graphics2.clipRect(x, y, width, ins.top);
					bgDelegate.update(graphics2, c);
					graphics2.setClip(clip);
					graphics2.clipRect(x + width - ins.right, y, ins.right,
							height);
					bgDelegate.update(graphics2, c);
					graphics2.setClip(clip);
					graphics2.clipRect(x, y + height - ins.bottom, width,
							ins.bottom);
					bgDelegate.update(graphics2, c);

					graphics2.dispose();
				}
			}
		}

		// boolean isFocused = FocusBorderListener.isFocused(c);
		//
		SubstanceTheme theme1 = null;
		SubstanceTheme theme2 = null;
		float cyclePos = 1.0f;

		FadeTracker fadeTracker = FadeTracker.getInstance();
		boolean isFocusAnimated = fadeTracker.isTracked(c, FadeKind.FOCUS);
		boolean isBorderAnimated = fadeTracker.isTracked(c,
				SubstanceLookAndFeel.BORDER_ANIMATION_KIND);

		if (isFocusAnimated || isBorderAnimated) {
			SubstanceTheme controlActiveTheme = SubstanceCoreUtilities
					.getActiveTheme((JComponent) c, true);
			SubstanceTheme controlDefaultTheme = SubstanceCoreUtilities
					.getDefaultTheme((JComponent) c, true);
			theme1 = controlDefaultTheme;
			theme2 = controlActiveTheme;
			if (isFocusAnimated) {
				cyclePos = fadeTracker.getFade10(c, FadeKind.FOCUS) / 10.f;
			} else {
				// theme1 = controlActiveTheme;
				// theme2 = controlDefaultTheme;
				cyclePos = /* Math.abs(1.0f - 2.0f * */fadeTracker.getFade10(
						c, SubstanceLookAndFeel.BORDER_ANIMATION_KIND) / 10.f;
				// System.out.println(controlDefaultTheme);
				// System.out.println(cyclePos);
				// System.out.println(controlActiveTheme);
			}

			SubstanceImageCreator.paintBorder(c, graphics, x, y, width, height,
					theme1);
			// System.out.println(graphics.getClip());
			graphics.setComposite(TransitionLayout.getAlphaComposite(c,
					cyclePos));
			SubstanceImageCreator.paintBorder(c, graphics, x, y, width, height,
					theme2);
		} else {
			if (isEnabled) {
				// theme1 = controlDefaultTheme;
				// theme2 = controlDefaultTheme;
				// if (isFocusAnimated) {
				// theme2 = controlActiveTheme;
				// cyclePos = fadeTracker.getFade10(c, FadeKind.FOCUS) / 10.f;
				// }
				SubstanceImageCreator.paintBorder(c, graphics, x, y, width,
						height, SubstanceCoreUtilities.getDefaultTheme(
								(JComponent) c, true));
				// graphics.setComposite(AlphaComposite.getInstance(
				// AlphaComposite.SRC_OVER, cyclePos));
				// SubstanceImageCreator.paintBorder(c, graphics, x, y, width,
				// height, theme2);
			} else {
				SubstanceTheme controlDisabledTheme = SubstanceCoreUtilities
						.getDisabledTheme((JComponent) c, true);
				SubstanceImageCreator.paintBorder(c, graphics, x, y, width,
						height, controlDisabledTheme);
			}
		}
		graphics.dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.border.Border#paintBorder(java.awt.Component,
	 *      java.awt.Graphics, int, int, int, int)
	 */
	public void paintBorder(Component c, Graphics g, int x, int y, int width,
			int height) {
		// if (c instanceof JComponent) {
		// ((JComponent)c).setOpaque(false);
		// }
		SubstanceBorder.paintBorder(c, g, x, y, width, height, c.isEnabled(), c
				.hasFocus());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.border.Border#getBorderInsets(java.awt.Component)
	 */
	public Insets getBorderInsets(Component c) {
		// fix for defect 102 - respect margin on text component
		if (c instanceof JTextComponent) {
			JTextComponent textComp = (JTextComponent) c;
			Insets margin = textComp.getMargin();
			if (margin != null) {
				return new Insets(this.myInsets.top + margin.top,
						this.myInsets.left + margin.left, this.myInsets.bottom
								+ margin.bottom, this.myInsets.right
								+ margin.right);
			}
		}
		return this.myInsets;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.border.Border#isBorderOpaque()
	 */
	public boolean isBorderOpaque() {
		return false;
	}
}
