/** This package extends the ai.aitia.visu.view.ui with new IFigureRenderer and
 * IElementRenderer implementations. */
package ai.aitia.chart.view.ui;