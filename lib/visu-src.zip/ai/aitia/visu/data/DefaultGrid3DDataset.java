package ai.aitia.visu.data;

import java.util.Collection;

import org.jfree.data.general.AbstractDataset;

public class DefaultGrid3DDataset extends AbstractDataset implements Grid3DDataset{
	
	private static final long serialVersionUID = -9112650756469456308L;
	
	protected int width;
	protected int height;
	protected int length;
	
	protected double[][][] data;
	
	//protected double defaultValue;
	
	public DefaultGrid3DDataset(int column, int row, int z_height) {
		this.width = column;
		this.height = row;
		this.length = z_height;
		
		data = new double[width][height][length];	//length adat a z-ben, ez layerenk�nt v�ltozik
													//pl.: diagram_layer( magass�g, alakzat, sz�n )
		
		for (int i=0; i<width; i++) {
			for (int j=0; j<height; j++) {
				for (int k = 0; k<length; k++) {
					data[i][j][k] = 0;
				}
			}
		}
	}
	
	public DefaultGrid3DDataset(double[][][] data) {
		setValues(data);
	}
	
	/*public void setDefaultValue(double defaultValue) {
		this.defaultValue = defaultValue;
	}*/
	
	public void setWidth(int width) {
		this.height = width;
	//	autoWidth = false;
	}	
	
	public int getWidth() {
		return width;
	}
	
	public void setHeight(int height) {
		this.height = height;
	//	autoHeight = false;
	}	

	public int getHeight() {
		return height;
	}
	
	public int getLength() {
		return length;
	}

	public double getValue(int x, int y, int i) {		
		return data[x][y][i];
	}

	public void setValue(int x, int y, int i, double value) {
		data[x][y][i] = value;
	}
	
	//ez nem ok �gy most!!!!!!
	public void setValues(double[][][] data) { 
		this.data = data;
		
		this.width = data.length;
		
		if (width > 0) 
			this.height = data[0].length;		
	}
	
	public double[][][] getValues() {
		return data;
	}
	
	//TODO: ez �gy nem ok itt!
	//ez se ok �gy!!!!!!
	public Collection<double[]> getValuesCollection() {
		return new java.util.AbstractList<double[]>() {
			@Override public int size() {
				return width * height;
			}
			
			@Override public double[] get(int index) {
				int i = index / height;
				int j = index % height;
				return new double[] { i, j, data[i][j][0] };
			}
		};
	}
	
	public double getMaximum(int dim)
	{
		double max = -Double.MAX_VALUE;
		
		for (int i=0; i<width; i++) 
		{
			for (int j=0; j<height; j++) 
			{
				for (int k = 0; k<length; k++) 
				{
					if (data[i][j][dim] > max)
					{
						max = data[i][j][dim];
					}
				}
			}
		}
		
		return max;
	}
	
	public void fireDatasetChanged() {
		super.fireDatasetChanged();
	}

}

