/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs.components;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.concurrent.Callable;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

import org.jfree.ui.ExtensionFileFilter;

import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.IDataSourceProducer.NumberStrPair;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.ImageFileFilter;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.view.ui.AutomaticFigureRenderer;
import ai.aitia.chart.view.ui.UserDefinedFigureRenderer;
import ai.aitia.chart.view.ui.UserDefinedFigureRenderer.Triplet;
import ai.aitia.meme.utils.FormsUtils;
import ai.aitia.visu.globalhandlers.GlobalHandlers;
import ai.aitia.visu.globalhandlers.UserBreakException;
import ai.aitia.visu.utils.Interval;
import ai.aitia.visu.utils.Utils;
import ai.aitia.visu.view.ui.IFigureRenderer;

/** GUI component to defines shape renderers. It used by
 *  {@link ai.aitia.chart.charttypes.dialogs.ShapeGrid2DDialog ShapeGrid2DDialog}
 *  {@link ai.aitia.chart.charttypes.dialogs.CompositeGrid2DDialog CompositeGrid2DDialog}.
 */
public class ShapeRendererPanel extends JPanel implements ActionListener, 
														  FocusListener {
	
	private static final HashMap<String,UserDefinedFigureRenderer> definedRenderers = new HashMap<String,UserDefinedFigureRenderer>();
	private static final String DEFAULT_NAME_PREFIX = "Renderer";

	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JPanel defPanel = null;
	private JButton defineButton = null;
	private JButton loadButton = null;
	private JDialog assignDialog = null;
	private JPanel contentPane = null;
	private JPanel shapesPanel = null;
	private JButton circleButton = null;
	private JButton rectangleButton = null;
	private JButton triangleButton = null;
	private JButton noneButton = null;
	private JPanel assignPanel = null;
	private JComboBox shapeRenderer = null;
	private JPanel additionalPanel = null;
	private JLabel jLabel1 = null;
	private JScrollPane scrTable = null;
	private JButton saveButton = null;
	private JPanel closePanel = null;
	private JButton closeButton = null;
	private JPanel leftPanel = null;
	private JColorChooser colorPanel = null;
	private JTable table = null;
	private JButton iconButton = null;
	private JPanel firstLine = null;
	private JPanel secondLine = null;
	private JLabel jLabel2 = null;
	private JPanel customPanel = null;
	private JLabel jLabel3 = null;
	private JTextField rendererClassField = null;
	private JButton browseButton = null;
	private JButton settingsButton = null;
	private JLabel jLabel4 = null;
	private JPanel tableButtonsPanel = null;
	private JButton moveDownButton = null;
	private JButton moveUpButton = null;
	private JButton removeButton = null;
	private JButton defaultButton = null; 
	private JPanel namePanel = null;
	private JTextField nameField = new JTextField();
	private JPanel editPanel = null;
	private JButton editButton = new JButton("Edit renderer...");

	//============================================================================
	// additional members
	
	/** Table model for the value-figure/icon table. */ 
	private ShapeRendererTableModel tmodel = null; 
	
	/** User GUI-component of <code>this</code>. */
	private IShapeRendererUser user = null;
	
	/** Cache for icon paths. */
	private List<String> iconCache = null;
	
	/** Class of the custom shape renderer (if any). */
	private Class elementRendererClass = null;
	
	/** Settings of the custom shape renderer (if any). */
	private Properties elementRendererSettings = null;
	
	private String current = ChartConstants.AUTO;
	
	private static List<ComboboxItem> predefinedRenderers = new ArrayList<ComboboxItem>(3);
	private static List<String> reservedNames = new ArrayList<String>(3);
	
	static {
		predefinedRenderers.add(new ComboboxItem(ChartConstants.AUTO,"Automatic renderer"));
		predefinedRenderers.add(new ComboboxItem(ChartConstants.DEFINED,"User defined renderer"));
		predefinedRenderers.add(new ComboboxItem(ChartConstants.CUSTOM,"Custom renderer"));
		
		reservedNames.add("Automatic renderer");
		reservedNames.add("User defined renderer");
		reservedNames.add("Custom renderer");
	}
	

	//============================================================================
	// nested classes
	
	/** This inner class described the shaperenderer file filter. */
	public class ShapeRendererFileFilter extends FileFilter {
		
		/** Accepts all directories and all shape renderer (*.srf) files.
		 * @param f filename
		 */
		@Override
		public boolean accept(File f) {
			if (f.isDirectory()) return true;
			String extension = null;
			String s = f.getName();
			int i = s.lastIndexOf('.');
			if (i>0 && i<s.length()-1) {
				extension = s.substring(i+1).toLowerCase();
			}
			if (extension != null && extension.equals("srf")) return true;
			return false;
		}
		
		/** The description of the filter.
		 * @return description of the filter
		 */
		@Override
		public String getDescription() {
			return "Shape renderer files (.srf)";
		}
	}
	
	//----------------------------------------------------------------------------
	/** Table model for define user defined shape renderer. */
	private class ShapeRendererTableModel extends AbstractTableModel {
		
		private static final long serialVersionUID = 1L;
		
		/** Array of the column names. */
		private String[] columnNames = new String[] { "Value/Interval", "Name", "Figure/Icon", "Color of figure" };
		
		/** List of rows. Each row is represented by an array of Objects. Each array
		 *  has four elements: the interval of the element, the name of the element,
		 *  the figure/icon of the element and the color of the element (last one used only
		 *  if the third object is a figure).
		 */ 
		private List<Object[]> data = null;

		//========================================================================
		// methods
		
		/** Constructor. 
		 * @param init List of interval,name,figure,color tuples that already are in the table
		 * @param renderer the shape renderer object
		 */
		public ShapeRendererTableModel(List<Object[]> init, Color defaultColor) throws UserBreakException {
			data = new ArrayList<Object[]>();
			data.add(new Object[] {null, "Default color", null, Utilities.colorText(defaultColor,5) });
			for (Object[] o : init) {
				ChartConfigCollection.getLOPExecutor().checkUserBreak();
				data.add(new Object[] {o[0],o[1],getImageIcon((String)o[2]),Utilities.colorText((Color)o[3],5) });
			}
			data.add(new Object[] {null,"",null,Utilities.colorText(null,5) });
		}
		
		//------------------------------------------------------------------------
		@Override
		public String getColumnName(int col) {
			return columnNames[col];
		}

		//------------------------------------------------------------------------
		/** Returns the number of columns.
		 * @return the number of columns
		 */
		public int getColumnCount() {
			return columnNames.length;
		}

		//------------------------------------------------------------------------
		/** Returns the number of rows.
		 * @return the number of rows
		 */
		public int getRowCount() {
			return data.size();
		}
		
		//-------------------------------------------------------------------------
		/** Returns the <code>row</code>-th row of the table. */
		public Object[] getRow(int row) { return row < data.size() ? data.get(row) : null; }

		//-------------------------------------------------------------------------
		// Imported from DefaultTableModel
	    /** Removes the row at <code>row</code> from the model.  Notification
	     *  of the row being removed will be sent to all the listeners.
	     * @param row the row index of the row to be removed
	     * @exception ArrayIndexOutOfBoundsException  if the row was invalid
	     */
		public void removeRow(int row) {
	        data.remove(row);
	        fireTableRowsDeleted(row, row);
	    }
		
		//-------------------------------------------------------------------------
		// Imported from DefaultTableModel
	    /** Moves one or more rows from the inclusive range <code>start</code> to 
	     *  <code>end</code> to the <code>to</code> position in the model. 
	     *  After the move, the row that was at index <code>start</code> 
	     *  will be at index <code>to</code>. 
	     *  This method will send a <code>tableChanged</code> notification
	     *  message to all the listeners. <p>
	     *
	     *  <pre>
	     *  Examples of moves:
	     *  <p>
	     *  1. moveRow(1,3,5);
	     *          a|B|C|D|e|f|g|h|i|j|k   - before
	     *          a|e|f|g|h|B|C|D|i|j|k   - after
	     *  <p>
	     *  2. moveRow(6,7,1);
	     *          a|b|c|d|e|f|G|H|i|j|k   - before
	     *          a|G|H|b|c|d|e|f|i|j|k   - after
	     *  <p> 
	     *  </pre>
	     *
	     * @param   start       the starting row index to be moved
	     * @param   end         the ending row index to be moved
	     * @param   to          the destination of the rows to be moved
	     * @exception  ArrayIndexOutOfBoundsException  if any of the elements 
	     * would be moved out of the table's range 
	     * 
	     */
	    public void moveRow(int start, int end, int to) { 
	    	int shift = to - start; 
	    	int first, last; 
	    	if (shift < 0) { 
	    		first = to; 
		    	last = end; 
	    	} else { 
	    		first = start; 
	    		last = to + end - start;  
	    	}
	        Utilities.rotate(data,first,last + 1,shift); 
	        fireTableRowsUpdated(first, last);
	    }

		//------------------------------------------------------------------------
		/** Returns the value of the cell specified by <code>rowIndex</code> and
		 *  <code>columnIndex</code>.
		 * @param rowIndex row index of the cell
		 * @param columnIndex column index of the cell
		 * @return the value of the appropriate cell
		 */
		public Object getValueAt(int rowIndex, int columnIndex) {
			return data.get(rowIndex)[columnIndex];
		}
		
		//------------------------------------------------------------------------
		@Override
		public Class<?> getColumnClass(int c) {
			switch (c) {
			case 0  : return Interval.class;
			case 2  : return ImageIcon.class;
			default : return String.class;
			}
		}
		
		//------------------------------------------------------------------------
		@Override
		public boolean isCellEditable(int row, int col) {
	    	if (col != 0 || row == 0) return false ;
			return true;
		}
		
		//------------------------------------------------------------------------
		@Override
		public void setValueAt(Object value, int row, int col) {
			if (col == 0) {
				if (value == null) return;
				data.add(data.size()-1,new Object[] {value,value.toString(),null,Utilities.colorText(null,5)} );
			} else if (col == 2) {
				Object[] actRow = data.get(row);
				actRow[2] = value;
			} else if (col == 3) {
				Object[] actRow = data.get(row);
				actRow[3] = Utilities.colorText((Color)value,5);
			}
			fireTableCellUpdated(row,col);
		}
	}
	
	//---------------------------------------------------------------------------
	/** Renderer class that displays icons in the table. */
	private class ImageIconRenderer extends JLabel implements TableCellRenderer {
		
		private static final long serialVersionUID = 1L;

		//========================================================================
		// method
		
		/** Constructor. */
		public ImageIconRenderer() {
			super();
			setOpaque(true);
		}
		
		//------------------------------------------------------------------------
		/** Returns a component that contains an icon.
		 * @param table the table that use this renderer
		 * @param value the value of the cell
		 * @param isSelected whether the cell is selected or not
		 * @param hasFocus whether the cell has focus or not
		 * @param row row index of the cell
		 * @param column column index of the cell
		 * @return a rendered component
		 */
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			if (isSelected) {
				setBackground(table.getSelectionBackground());
				setForeground(table.getSelectionForeground());
			} else {
				setBackground(getScrTable().getBackground());
				setForeground(table.getForeground());
			}
			setHorizontalAlignment(JLabel.CENTER);
			setIcon((ImageIcon)value);
			return this;
		}
	}

	//============================================================================
	// methods
	
	/** Constructor.
	 * @param user user GUI component of <code>this</code>
	 */
	public ShapeRendererPanel(IShapeRendererUser user) {
		super();
		this.user = user;
		initialize();
	}
	
	//----------------------------------------------------------------------------------------------------
	@Override
	public void setEnabled(boolean enabled) {
		jLabel.setEnabled(enabled);
		shapeRenderer.setEnabled(enabled);
		defineButton.setEnabled(enabled);
		loadButton.setEnabled(enabled);
		jLabel3.setEnabled(enabled);
		rendererClassField.setEnabled(enabled);
		browseButton.setEnabled(enabled);
		if (enabled && !"".equals(rendererClassField.getText().trim()))
			settingsButton.setEnabled(true);
		else 
			settingsButton.setEnabled(false);
		editButton.setEnabled(enabled);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	public IFigureRenderer getRenderer() {
		if (getShapeRendererType().equals(ChartConstants.AUTO)) 
			return new AutomaticFigureRenderer();
		else if (getShapeRendererType().equals("CUSTOM")) {
			boolean valid = true;
			Constructor constructor = null;
			if (elementRendererClass == null) valid = false;
			if (valid && elementRendererSettings == null) {
				try {
					constructor = elementRendererClass.getConstructor(new Class[] {});
				} catch (NoSuchMethodException e) {
					valid = false;
				}
			} else if (valid && elementRendererSettings != null) {
				try {
					constructor = elementRendererClass.getConstructor(new Class[] { Properties.class });
				} catch (NoSuchMethodException e) {
					valid = false;
				}
			}
			if (valid) {
				try {
					if (elementRendererSettings == null)
						return (IFigureRenderer) constructor.newInstance((Object[])null);
					else
						return (IFigureRenderer) constructor.newInstance(elementRendererSettings);
					} catch (Exception e) {
						return new AutomaticFigureRenderer();
					}
			} else
				return new AutomaticFigureRenderer();
		} else {
			UserDefinedFigureRenderer renderer = definedRenderers.get(getShapeRendererType());
			return renderer;
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void setSettings(IFigureRenderer renderer, Properties optionalProps) {
		if (renderer instanceof AutomaticFigureRenderer) 
			current = ChartConstants.AUTO; 
		else if (renderer instanceof UserDefinedFigureRenderer) {
			UserDefinedFigureRenderer _renderer = (UserDefinedFigureRenderer) renderer;
			String id = _renderer.getName();
			shapeRenderer.setSelectedItem(new ComboboxItem(id));
			current = id;
			CardLayout cl = (CardLayout) additionalPanel.getLayout();
			cl.show(additionalPanel,"EDIT");
		} else {
			elementRendererClass = renderer.getClass();
			elementRendererSettings = optionalProps; 
			shapeRenderer.setSelectedIndex(2);
			current = ChartConstants.CUSTOM;
			CardLayout cl = (CardLayout) additionalPanel.getLayout();
			cl.show(additionalPanel,"CUSTOM");
			cl = (CardLayout) secondLine.getLayout();
			cl.show(secondLine,"CUSTOM_P");
			rendererClassField.setText(elementRendererClass.getName());
			settingsButton.setEnabled(true);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public Properties getCustomProperties() { return elementRendererSettings; }
	
	//----------------------------------------------------------------------------
	/** This method initializes <code>this</code> */
	private void initialize() {
		jLabel = new JLabel();
		jLabel.setText("  Shape Renderer:  ");
		jLabel.setPreferredSize(new Dimension(125, 16));
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.setPreferredSize(new Dimension(609, 60));
		this.add(getFirstLine(), null);
		this.add(getSecondLine(), null);
	}

	//----------------------------------------------------------------------------
	private JPanel getDefPanel() {
		if (defPanel == null) {
			defPanel = new JPanel();
			defPanel.setLayout(new BoxLayout(getDefPanel(), BoxLayout.X_AXIS));
			defPanel.setName(ChartConstants.DEFINED);
			defPanel.add(Box.createRigidArea(new Dimension(10,0)));
			defPanel.add(getDefineButton(), null);
			defPanel.add(Box.createRigidArea(new Dimension(10,0)));
			defPanel.add(getLoadButton(), null);
		}
		return defPanel;
	}

	//----------------------------------------------------------------------------
	private JButton getDefineButton() {
		if (defineButton == null) {
			defineButton = new JButton();
			defineButton.setText("Assign shape to value...");
			defineButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (assignDialog != null) {
						nameField.setText(defaultName());
						setTableElements(new UserDefinedFigureRenderer());
					}
					getAssignDialog().setVisible(true);
				}
			});
		}
		return defineButton;
	}

	//----------------------------------------------------------------------------
	private JButton getLoadButton() {
		if (loadButton == null) {
			loadButton = new JButton();
			loadButton.setText("Load shape renderer...");
			loadButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					// get the file name
					JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
					fc.setAcceptAllFileFilterUsed(false);
					fc.addChoosableFileFilter(new ShapeRendererFileFilter());
					int result = fc.showOpenDialog(ShapeRendererPanel.this);
					if (result == JFileChooser.APPROVE_OPTION) {
						File file = fc.getSelectedFile();
						GlobalHandlers.setLastDirectory(file);
						
						// open the file
						Properties shapeRenderer = new Properties();
						try {
							FileInputStream is = new FileInputStream(file);
							shapeRenderer.load(is);
							is.close();
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(ShapeRendererPanel.this,"Unable to load the selected shape renderer.","Loading failure",JOptionPane.ERROR_MESSAGE,null);
							return;
						}
						// set the shaperenderer
						UserDefinedFigureRenderer userDefRenderer = new UserDefinedFigureRenderer();
						userDefRenderer.setName(shapeRenderer.getProperty(ChartConstants.NAME,""));
						int color = Integer.decode(shapeRenderer.getProperty(ChartConstants.DEFAULT_COLOR));
						userDefRenderer.setDefaultColor(new Color(color));
						
						String[] keys = shapeRenderer.keySet().toArray(new String[0]);
						Interval[] intvs = new Interval[keys.length - 2];
						String[] figures = new String[keys.length - 2];
						Color[] colors = new Color[keys.length - 2];
						for (int i = 0;i < keys.length;++i) {
							if (!keys[i].equals(ChartConstants.DEFAULT_COLOR) &&
								!keys[i].equals(ChartConstants.NAME)) {
								String parts[] = shapeRenderer.getProperty(keys[i]).split("\\?");
								int index = Integer.parseInt(parts[2]);
								intvs[index] = new Interval(keys[i]);
								figures[index] = parts[0].equals("_") ? null : parts[0].trim();
								colors[index] = parts[1].equals("_") ? null : new Color(Integer.decode(parts[1]));
							}
						}
						if (iconCache == null)
							iconCache = new ArrayList<String>();
						for (int i = 0;i < intvs.length;++i) {
							userDefRenderer.addEntry(intvs[i],figures[i],colors[i]);
							if (figures[i] != null &&
								!figures[i].equals(UserDefinedFigureRenderer.CIRCLE) &&
								!figures[i].equals(UserDefinedFigureRenderer.RECTANGLE) &&
								!figures[i].equals(UserDefinedFigureRenderer.TRIANGLE)) {
									ImageIcon tryIcon = getImageIcon(figures[i]);
									if (!tryIcon.equals(userDefRenderer.getDefaultIcon()) && !iconCache.contains(figures[i])) {
										iconCache.add(figures[i]);
										if (iconCache.size() > 10)
											iconCache.remove(0);
									}
							}
						}
						definedRenderers.put(userDefRenderer.getName(),userDefRenderer);
						reloadCombobox(userDefRenderer.getName());
					}
				}
			});
		}
		return loadButton;
	}

	//----------------------------------------------------------------------------
	private JDialog getAssignDialog() {
		if (assignDialog == null) {
			java.awt.Container c = getTopLevelAncestor();
			if (c instanceof javax.swing.JDialog)
				assignDialog = new JDialog((javax.swing.JDialog)c, "Assign shape to value", true);
			else
				assignDialog = new JDialog((javax.swing.JFrame)c, "Assign shape to value", true);
			
			final JScrollPane sp = new JScrollPane(getContentPane(),JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			sp.setBorder(null);
			assignDialog.setContentPane(sp);
			assignDialog.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
			setTableElements(new UserDefinedFigureRenderer());
			assignDialog.pack();
			Dimension oldD = assignDialog.getPreferredSize();
			assignDialog.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
											     		oldD.height + sp.getHorizontalScrollBar().getHeight()));
			sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			oldD = assignDialog.getPreferredSize();
			final Dimension newD = Utils.getPreferredSize(assignDialog);
			if (!oldD.equals(newD)) 
				assignDialog.setPreferredSize(newD);
			assignDialog.pack();
			assignDialog.setLocationRelativeTo(c);
		}
		return assignDialog;
	}

	//----------------------------------------------------------------------------
	private JPanel getContentPane() {
		if (contentPane == null) {
			contentPane = new JPanel();
			contentPane.setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
			contentPane.add(getShapesPanel(), null);
			contentPane.add(new JSeparator(JSeparator.HORIZONTAL));
			contentPane.add(getAssignPanel(), null);
			contentPane.add(new JSeparator(JSeparator.HORIZONTAL));
			contentPane.add(getClosePanel(), null);
		}
		return contentPane;
	}

	//----------------------------------------------------------------------------
	private JPanel getShapesPanel() {
		if (shapesPanel == null) {
			shapesPanel = new JPanel();
			shapesPanel.setLayout(new FlowLayout());
			shapesPanel.add(getCircleButton(), null);
			shapesPanel.add(getRectangleButton(), null);
			shapesPanel.add(getTriangleButton(), null);
			shapesPanel.add(getNoneButton(), null);
			shapesPanel.add(getIconButton(), null);
		}
		return shapesPanel;
	}

	//----------------------------------------------------------------------------
	private JButton getCircleButton() {
		if (circleButton == null) {
			circleButton = new JButton();
			circleButton.setIcon(Utilities.getIcon("CIRCLE"));
			circleButton.setPreferredSize(new Dimension(100, 26));
			circleButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addFigure(UserDefinedFigureRenderer.CIRCLE);
				}
			});
		}
		return circleButton;
	}

	//----------------------------------------------------------------------------
	private JButton getRectangleButton() {
		if (rectangleButton == null) {
			rectangleButton = new JButton();
			rectangleButton.setIcon(Utilities.getIcon("RECTANGLE"));
			rectangleButton.setPreferredSize(new Dimension(100, 26));
			rectangleButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addFigure(UserDefinedFigureRenderer.RECTANGLE);
				}
			});
		}
		return rectangleButton;
	}

	//----------------------------------------------------------------------------
	private JButton getTriangleButton() {
		if (triangleButton == null) {
			triangleButton = new JButton();
			triangleButton.setIcon(Utilities.getIcon("TRIANGLE"));
			triangleButton.setPreferredSize(new Dimension(100, 26));
			triangleButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addFigure(UserDefinedFigureRenderer.TRIANGLE);
				}
			});
		}
		return triangleButton;
	}

	//----------------------------------------------------------------------------
	private JButton getNoneButton() {
		if (noneButton == null) {
			noneButton = new JButton();
			noneButton.setText("<none>");
			noneButton.setPreferredSize(new Dimension(100, 26));
			noneButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addFigure(UserDefinedFigureRenderer.DEFAULT);
				}
			});
		}
		return noneButton;
	}
	
	//----------------------------------------------------------------------------
	private JButton getIconButton() {
		if (iconButton == null) {
			iconButton = new JButton();
			iconButton.setText("Icon...");
			iconButton.setPreferredSize(new Dimension(100,26));
			iconButton.setActionCommand("ICON");
			iconCache = new ArrayList<String>();
			iconButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String command = e.getActionCommand();
					if (command.equals("ICON")) {
						if (iconCache.size() == 0)
							openFileDialog();
						else {
							JPopupMenu menu = new JPopupMenu();
							for (String s : iconCache) {
								JMenuItem item = new JMenuItem(s);
								item.setActionCommand(s);
								item.addActionListener(this);
								menu.add(item);
							}
							menu.addSeparator();
							JMenuItem browse = new JMenuItem("Browse...");
							browse.setActionCommand("BROWSE");
							browse.addActionListener(this);
							menu.add(browse);
							menu.show(iconButton,45,5);
						}
					} else if (command.equals("BROWSE"))
						openFileDialog();
					else addFigure(command);
				}
			});
		}
		return iconButton;
	}

	//----------------------------------------------------------------------------
	private JPanel getAssignPanel() {
		if (assignPanel == null) {
			assignPanel = new JPanel();
			assignPanel.setLayout(new BoxLayout(getAssignPanel(), BoxLayout.X_AXIS));
			assignPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			assignPanel.add(getLeftPanel(), null);
			assignPanel.add(Box.createRigidArea(new Dimension(10,0)));
			assignPanel.add(getColorPanel(), null);
		}
		return assignPanel;
	}

	//----------------------------------------------------------------------------
	private JPanel getLeftPanel() {
		if (leftPanel == null) {
			leftPanel = new JPanel();
			leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
			namePanel = FormsUtils.build("p ~ p:g",
										 "01",
										 "Name: ",nameField).getPanel();
			leftPanel.add(namePanel);
			nameField.setText(defaultName());
			nameField.addFocusListener(this);
			leftPanel.add(getScrTable(), null);
			leftPanel.add(Box.createRigidArea(new Dimension(0,5)));
			leftPanel.add(getTableButtonsPanel(), null);
			JPanel p = new JPanel();
			p.setMaximumSize(new Dimension(32323,24));
			p.add(getSaveButton());
			leftPanel.add(p, null);
		}
		return leftPanel;
	}
	
	//----------------------------------------------------------------------------
	private JPanel getTableButtonsPanel() {
		if (tableButtonsPanel == null) {
			(moveUpButton = new JButton("Move up")).setActionCommand("UP");
			(moveDownButton = new JButton("Move down")).setActionCommand("DOWN");
			(removeButton = new JButton("Remove")).setActionCommand("REMOVE");
			(defaultButton = new JButton("Reset color")).setActionCommand("DEFAULT");
			tableButtonsPanel = FormsUtils.build("p:g ~ p:g ~ p:g ~ p:g",
												 "_01_||" +
												 "_23_",
												 moveUpButton,removeButton,
												 moveDownButton,defaultButton).getPanel();
			Utilities.addActionListener(this,moveUpButton,removeButton,moveDownButton,defaultButton);
		}
		return tableButtonsPanel;
	}
	
	//----------------------------------------------------------------------------
	private JColorChooser getColorPanel() {
		if (colorPanel == null) {
			colorPanel = new JColorChooser(Color.BLUE);
			colorPanel.getSelectionModel().addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					Color newColor = colorPanel.getColor();
					int[] indices = table.getSelectedRows();
					if (indices.length != 0) {
						for (int i = 0;i < indices.length;++i) {
							if (indices[i] == 0) 
								tmodel.setValueAt(newColor,0,3);
							else if (indices[i] == tmodel.getRowCount() - 1) continue;
							else 
								tmodel.setValueAt(newColor,indices[i],3);
						}
					}
				}
			});
		}
		return colorPanel;
	}
	
	//----------------------------------------------------------------------------
	private JComboBox getShapeRenderer() {
		if (shapeRenderer == null) {
			List<ComboboxItem> items = new ArrayList<ComboboxItem>(predefinedRenderers);
			for (String key : definedRenderers.keySet())
				items.add(new ComboboxItem(key));
			shapeRenderer = new JComboBox(items.toArray());
			shapeRenderer.setPreferredSize(new Dimension(154, 30));
			shapeRenderer.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					CardLayout cl = (CardLayout) additionalPanel.getLayout();
					String id = (String)((ComboboxItem)shapeRenderer.getSelectedItem()).getID();
					current = id;
					if (ChartConstants.AUTO.equals(id) || ChartConstants.DEFINED.equals(id) || ChartConstants.CUSTOM.equals(id))
						cl.show(additionalPanel,id);
					else
						cl.show(additionalPanel,"EDIT");
					cl = (CardLayout) secondLine.getLayout();
					if (id.equals(ChartConstants.CUSTOM))
						cl.show(secondLine,"CUSTOM_P");
					else
						cl.show(secondLine,"NONE");
					boolean notDefinedRenderer = current.equals(ChartConstants.DEFINED) || (current.equals(ChartConstants.CUSTOM) && elementRendererClass == null); 
					user.setUpdateStatus(!notDefinedRenderer);
				}
			});
		}
		return shapeRenderer;
	}

	//----------------------------------------------------------------------------
	private JPanel getAdditionalPanel() {
		if (additionalPanel == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("");
			jLabel4.setName("CUSTOM");
			jLabel1 = new JLabel();
			jLabel1.setText("");
			jLabel1.setName(ChartConstants.AUTO);
			additionalPanel = new JPanel();
			additionalPanel.setLayout(new CardLayout());
			additionalPanel.add(jLabel1, jLabel1.getName());
			additionalPanel.add(getDefPanel(), getDefPanel().getName());
			additionalPanel.add(jLabel4, jLabel4.getName());
			editPanel = FormsUtils.build("~ p p:g","|0_",editButton).getPanel();
			editPanel.setName("EDIT");
			editButton.setActionCommand("EDIT_BUTTON");
			editButton.addActionListener(this);
			additionalPanel.add(editPanel,editPanel.getName());
		}
		return additionalPanel;
	}

	//----------------------------------------------------------------------------
	private JScrollPane getScrTable() {
		if (scrTable == null) {
			scrTable = new JScrollPane();
			scrTable.setBorder(BorderFactory.createTitledBorder("Shape values"));
			scrTable.setViewportView(getTable());
		}
		return scrTable;
	}
	
	//----------------------------------------------------------------------------
	private JTable getTable() {
		if (table == null) {
			table = new JTable() {
				private static final long serialVersionUID = 1L;
				{
					tableHeader.setReorderingAllowed(false);
				}
			};
			DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
			renderer.setLocale(Locale.US);
			renderer.setHorizontalAlignment(JTextField.TRAILING);
			renderer.setBackground(getScrTable().getBackground());
			DefaultTableCellRenderer renderer2 = new DefaultTableCellRenderer();
			renderer2.setHorizontalAlignment(JTextField.CENTER);
			renderer2.setBackground(getScrTable().getBackground());
			ImageIconRenderer renderer3 = new ImageIconRenderer();
			table.setDefaultRenderer(Interval.class,renderer);
			table.setDefaultRenderer(String.class,renderer2);
			table.setDefaultRenderer(ImageIcon.class,renderer3);
		}
		return table;
	}

	//----------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.setMaximumSize(new Dimension(162, 26));
			saveButton.setMinimumSize(new Dimension(162, 26));
			saveButton.setPreferredSize(new Dimension(162, 26));
			saveButton.setText("Save shape renderer...");
			saveButton.addActionListener(new java.awt.event.ActionListener() {
				@SuppressWarnings("unchecked")
				public void actionPerformed(java.awt.event.ActionEvent e) {
					// get the filename
					JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
					fc.setAcceptAllFileFilterUsed(false);
					fc.addChoosableFileFilter(new ShapeRendererFileFilter());
					int result = fc.showSaveDialog(getAssignDialog());
					if (result == JFileChooser.APPROVE_OPTION) {
						if ("".equals(nameField.getText().trim()))
							nameField.setText(defaultName());
						UserDefinedFigureRenderer userDefRenderer = buildUserDefinedRenderer(nameField.getText());
						File file = fc.getSelectedFile();
						File newFile = Utilities.generateValidFile(file,"srf");
						GlobalHandlers.setLastDirectory(newFile);
						
						//initialize the Properties object
						Properties shapeRenderer = new Properties();
						
						String defColor = String.format("#%06x",userDefRenderer.getDefaultColor().getRGB() & 0xffffff);
						shapeRenderer.setProperty(ChartConstants.DEFAULT_COLOR,defColor);
						shapeRenderer.setProperty(ChartConstants.NAME,userDefRenderer.getName());
						
						List<Triplet<Interval,String,Color>> map = userDefRenderer.getMap();
						for (int i = 0;i < map.size();++i) {
							Triplet<Interval,String,Color> t = map.get(i);
							Object[] FAC = userDefRenderer.getFigureAndColor(t.getFirst());
							if (FAC == null) continue;
							String index = String.valueOf(i);
							if (shapeRenderer.getProperty(t.getFirst().toString()) != null)
								index = shapeRenderer.getProperty(t.getFirst().toString()).split("\\?")[2];
							Color color = (Color) FAC[1];
							String figure = FAC[0] == null ? "_" : FAC[0].toString();
							String entry_string = figure + "?" + (color == null ? "_" : String.format("#%06x",color.getRGB() & 0xffffff)) + "?" + index;
							shapeRenderer.setProperty(t.getKey().toString(),entry_string);
						}
						
						// open file and save
						try {
							FileOutputStream os = new FileOutputStream(newFile);
							shapeRenderer.store(os,"");
							os.close();
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(getAssignDialog(),"Unable to save the defined shape renderer.","Saving failure",JOptionPane.ERROR_MESSAGE,null);
						}
					}
				}
			});
			saveButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		}
		return saveButton;
	}

	//----------------------------------------------------------------------------
	private JPanel getClosePanel() {
		if (closePanel == null) {
			closePanel = new JPanel();
			closePanel.setLayout(new FlowLayout());
			closePanel.add(getCloseButton(), null);
		}
		return closePanel;
	}

	//----------------------------------------------------------------------------
	private JButton getCloseButton() {
		if (closeButton == null) {
			closeButton = new JButton();
			closeButton.setText("Close");
			closeButton.setMnemonic(KeyEvent.VK_C);
			closeButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if ("".equals(nameField.getText().trim()))
						nameField.setText(defaultName());
					assignDialog.setVisible(false);
					buildUserDefinedRenderer(nameField.getText());
				}
			});
		}
		return closeButton;
	}
	
	//----------------------------------------------------------------------------
	private JPanel getFirstLine() {
		if (firstLine == null) {
			firstLine = new JPanel();
			firstLine.setLayout(new BoxLayout(getFirstLine(), BoxLayout.X_AXIS));
			firstLine.add(jLabel, null);
			firstLine.add(getShapeRenderer(), null);
			firstLine.add(getAdditionalPanel(), null);
		}
		return firstLine;
	}

	//----------------------------------------------------------------------------
	private JPanel getSecondLine() {
		if (secondLine == null) {
			jLabel2 = new JLabel();
			jLabel2.setText(" ");
			jLabel2.setName("NONE");
			secondLine = new JPanel();
			secondLine.setLayout(new CardLayout());
			secondLine.add(jLabel2, jLabel2.getName());
			secondLine.add(getCustomPanel(), getCustomPanel().getName());
		}
		return secondLine;
	}

	//----------------------------------------------------------------------------
	private JPanel getCustomPanel() {
		if (customPanel == null) {
			jLabel3 = new JLabel();
			jLabel3.setPreferredSize(new Dimension(125, 16));
			jLabel3.setText("  Renderer class:  ");
			customPanel = new JPanel();
			customPanel.setLayout(new BoxLayout(getCustomPanel(), BoxLayout.X_AXIS));
			customPanel.setName("CUSTOM_P");
			customPanel.add(jLabel3, null);
			customPanel.add(getRendererClassField(), null);
			customPanel.add(Box.createRigidArea(new Dimension(5,0)));
			customPanel.add(getBrowseButton(), null);
			customPanel.add(Box.createRigidArea(new Dimension(5,0)));
			customPanel.add(getSettingsButton(), null);
		}
		return customPanel;
	}

	//----------------------------------------------------------------------------
	private JTextField getRendererClassField() {
		if (rendererClassField == null) {
			rendererClassField = new JTextField();
			rendererClassField.setMaximumSize(new Dimension(2147483647, 20));
			rendererClassField.setEditable(false);
		}
		return rendererClassField;
	}

	//----------------------------------------------------------------------------
	private JButton getBrowseButton() {
		if (browseButton == null) {
			browseButton = new JButton();
			browseButton.setMnemonic(KeyEvent.VK_B);
			browseButton.setText("Browse...");
			browseButton.addActionListener(new java.awt.event.ActionListener() {
				@SuppressWarnings("unchecked")
				public void actionPerformed(java.awt.event.ActionEvent e) {
					JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
					fc.setAcceptAllFileFilterUsed(false);
					fc.setFileFilter(new ExtensionFileFilter("Java class files (.class)","class"));
					int result = fc.showOpenDialog(ShapeRendererPanel.this);
					if (result == JFileChooser.APPROVE_OPTION) {
						File file = fc.getSelectedFile();
						GlobalHandlers.setLastDirectory(file);
						String name = file.getPath();
						String osName = System.getProperty("os.name").toLowerCase();
						name = name.substring(osName.indexOf("windows") >= 0 ? 3 : 1,name.lastIndexOf(".class"));
						String swap = null;
						if (File.separator.equals("\\")) 
							swap="\\";
						else 
							swap = "";
						name = name.replaceAll(swap + File.separator,".");
						String candidate = name;
						Class c = null;
						int index = 0;
						while (c == null) {
							try {
//								System.out.println(candidate);
								c = Class.forName(candidate);
							} catch (ClassNotFoundException e1) {
								int oldIndex = index;
								index = name.indexOf(".",oldIndex + 1);
								if (index == -1) {
									JOptionPane.showMessageDialog(ShapeRendererPanel.this,"Unable to load class!", "Error", JOptionPane.ERROR_MESSAGE, null);
									elementRendererClass = null;
									elementRendererSettings = null;
									rendererClassField.setText("");
									settingsButton.setEnabled(false);
									user.setUpdateStatus(elementRendererClass != null);
									return;
								}
								candidate = name.substring(index + 1);
								continue;
							}
							break;
						}
						if (!IFigureRenderer.class.isAssignableFrom(c)) {
							JOptionPane.showMessageDialog(ShapeRendererPanel.this,"This class has not implemented the IFigureRenderer interface!", "Warning", JOptionPane.WARNING_MESSAGE, null);
							elementRendererClass = null;
							elementRendererSettings = null;
							rendererClassField.setText("");
							settingsButton.setEnabled(false);
							user.setUpdateStatus(elementRendererClass != null);
							return;
						}
						boolean validConstructor = true;
						try {
							c.getConstructor(new Class[] {});
						} catch (Exception e1) {
							validConstructor = false;
						}
						if (!validConstructor) {
							try {
								validConstructor = true;
								c.getConstructor(new Class[] { Properties.class });
							} catch (Exception e1) {
								validConstructor = false;
							}
						}
						if (!validConstructor) {
							JOptionPane.showMessageDialog(ShapeRendererPanel.this,"This class has not appropriate constructor!", "Warning", JOptionPane.WARNING_MESSAGE, null);
							elementRendererClass = null;
							elementRendererSettings = null;
							rendererClassField.setText("");
							settingsButton.setEnabled(false);
							user.setUpdateStatus(elementRendererClass != null);
							return;
						}
						rendererClassField.setText(c.getName());
						settingsButton.setEnabled(true);
						elementRendererClass = c;
						elementRendererSettings = null;
					}
					user.setUpdateStatus(elementRendererClass != null);
				}
			});
		}
		return browseButton;
	}

	//----------------------------------------------------------------------------
	private JButton getSettingsButton() {
		if (settingsButton == null) {
			settingsButton = new JButton();
			settingsButton.setEnabled(false);
			settingsButton.setText("Settings...");
			settingsButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					java.awt.Container c = getTopLevelAncestor();
					SettingsEditor editor;
					if (c instanceof JDialog)
						editor = new SettingsEditor((JDialog)c, elementRendererSettings);
					else
						editor = new SettingsEditor((JFrame)c, elementRendererSettings);
					editor.setLocationRelativeTo(c);
					editor.setModal(true);
					editor.setVisible(true);
					elementRendererSettings = editor.getSettings();
					editor.dispose();
				}
			});
		}
		return settingsButton;
	}

	//============================================================================
	// non-GUI methods
	
	//----------------------------------------------------------------------------
	/** Returns the user defined renderer object.
	 * @return the user defined renderer object
	 */
	public UserDefinedFigureRenderer getDefRenderer() {
		return definedRenderers.get(current);
	}
	
	//----------------------------------------------------------------------------
	/** Returns the id of the selected renderer type.
	 * @return id of the selected renderer type (a string)
	 */
	public Comparable getShapeRendererType() {
		return ((ComboboxItem)shapeRenderer.getSelectedItem()).getID();
	}
	
	//----------------------------------------------------------------------------
	/** Selects the default shape rendererer (
	 *  {@link ai.aitia.chart.view.ui.AutomaticFigureRenderer AutomaticFigureRenderer}).
	 */
	public void resetShapeRendererType() {
		shapeRenderer.setSelectedIndex(0);
	}
	
	//-----------------------------------------------------------------------------
	/** Creates and returns the string description of the selected renderer.
	 * @return string description of the the selected renderer
	 */
	@SuppressWarnings("unchecked")
	public String settingsToString() {
		String settings = null;
		if (getShapeRendererType().equals(ChartConstants.AUTO)) {
			settings = ChartConstants.AUTO;
		} else if (getShapeRendererType().equals("CUSTOM")) {
			boolean valid = true;
			if (elementRendererClass == null) valid = false;
			if (valid && elementRendererSettings == null) {
				try {
					elementRendererClass.getConstructor(new Class[] {});
				} catch (NoSuchMethodException e) {
					valid = false;
				}
			}
			if (valid) {
				settings = "CUSTOM," + elementRendererClass.getName() + ",";
				if (elementRendererSettings == null) return settings.substring(0,settings.length() - 1);
				for (Entry<Object,Object> e : elementRendererSettings.entrySet()) {
					settings += e.getKey().toString() + ":" + e.getValue().toString() + ",";
				}
				settings = settings.substring(0,settings.length() - 1);
			} else settings = ChartConstants.AUTO;
		} else {
			String temp = null;
			UserDefinedFigureRenderer userDefRenderer = definedRenderers.get(current);
			temp = ChartConstants.DEFINED + "," + userDefRenderer.getName() + "," + String.format("#%06x",userDefRenderer.getDefaultColor().getRGB() & 0xffffff) + ","; // default color first
			List<Triplet<Interval,String,Color>> map = userDefRenderer.getMap();
			for (Triplet<Interval,String,Color> t : map) {
				temp += t.getKey().toString() + ";";
				temp += (t.getSecond() == null ? "_" : t.getSecond()) + "?";
				String color = t.getThird() == null ? "_" : String.format("#%06x",t.getThird().getRGB() & 0xffffff);
				temp += color + ","; 
			}
			settings = temp.substring(0,temp.length() - 1);
		}
		return settings;
	}
	
	//-----------------------------------------------------------------------------
	/** Sets the shape renderer from the string <code>settings</code>.
	 * @param settings string description of an shape renderer
	 */
	public void settingsFromString(String settings) {
		String[] strings = settings.split(",");
		// AUTO mode => do nothing
		if (strings[0].equals(ChartConstants.DEFINED)) {
			UserDefinedFigureRenderer userDefRenderer = new UserDefinedFigureRenderer();
			CardLayout cl = (CardLayout) additionalPanel.getLayout();
			cl.show(additionalPanel,"EDIT");
			userDefRenderer.setName(strings[1]);
			current = strings[1];
			userDefRenderer.setDefaultColor(new Color(Integer.decode(strings[2])));
			for (int i = 3;i < strings.length;++i) {
				String[] pair = strings[i].split(";");
				Interval intv = new Interval(pair[0]);
				String[] parts = pair[1].split("\\?");
				String figure = parts[0].equals("_") ? null : parts[0];
				Color color = parts[1].equals("_") ? null : new Color(Integer.decode(parts[1]));
				userDefRenderer.addEntry(intv,figure,color);
			}
			definedRenderers.put(strings[1],userDefRenderer);
			reloadCombobox(current);
		} else if (strings[0].equals("CUSTOM")) {
			try {
				elementRendererClass = Class.forName(strings[1]);
			} catch (ClassNotFoundException e) {
				// wrong custom renderer => use automatic renderer => do nothing
				return;
			}
			Properties temp = new Properties();
			for (int i = 2;i < strings.length;++i) {
				String[] pair = strings[i].split(":");
				temp.setProperty(pair[0],pair[1]);
			}
			if (!temp.isEmpty())
				elementRendererSettings = temp;
			shapeRenderer.setSelectedIndex(2);
			CardLayout cl = (CardLayout) additionalPanel.getLayout();
			cl.show(additionalPanel,"CUSTOM");
			cl = (CardLayout) secondLine.getLayout();
			cl.show(secondLine,"CUSTOM_P");
			rendererClassField.setText(elementRendererClass.getName());
			settingsButton.setEnabled(true);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void reloadCombobox(String current) {
		List<ComboboxItem> items = new ArrayList<ComboboxItem>(predefinedRenderers);
		for (String key : definedRenderers.keySet())
			items.add(new ComboboxItem(key));
		shapeRenderer.setModel(new DefaultComboBoxModel(items.toArray()));
		ComboboxItem item = new ComboboxItem(current);
		if (((DefaultComboBoxModel)shapeRenderer.getModel()).getIndexOf(item) > 0) {
			shapeRenderer.setSelectedItem(item);
			this.current = current;
		} else {
			shapeRenderer.setSelectedIndex(0);
			this.current = ChartConstants.AUTO;
		}
		user.setUpdateStatus(hasDefinedRenderer());
		
	}
	
	//----------------------------------------------------------------------------
	/** Returns whether the item <code>item</code> contained by <code>list</code> or
	 *  not. Returns a valid index if number value of <code>item</code> equals to number
	 *  value of any element of the list otherwise returns -1.
	 * @param item the element 
	 * @param list the list where the method searches
	 */
	private int isElement(NumberStrPair item, List<Object[]> list) {
		for (int i = 0;i < list.size();++i) {
			if (item.getNumber().equals(((Interval)list.get(i)[0]).getLower()) &&
				item.getNumber().equals(((Interval)list.get(i)[0]).getUpper())) {
					return i;
				}
			}
			return -1;
	}
	
	//----------------------------------------------------------------------------
	/** Sets the initial elements of the table. */
	@SuppressWarnings("unchecked")
	private void setTableElements(final UserDefinedFigureRenderer userDefRenderer) {
		IDataSourceProducer dsp = user.getShapeValueProducer();
		if (dsp == null) {
			assignDialog.setVisible(false);
			return;
		}
		
		final List<Object[]> init = new ArrayList<Object[]>();
		
		List<Triplet<Interval,String,Color>> map = userDefRenderer.getMap();
		
		if (!map.isEmpty()) {
			for (Triplet<Interval,String,Color> t : map) 
				init.add(new Object[] { t.getFirst(), t.getFirst().toString(), t.getSecond(), t.getThird() });
		}

		try {
			final List<NumberStrPair> list = (List<NumberStrPair>)ChartConfigCollection.
			getLOPExecutor().execute("Initializing elements",dsp,"getElements");
			ChartConfigCollection.getLOPExecutor().execute("Initializing table",new Callable<Object>() {
				public Object call() throws Exception {
					if (list != null) {
						for (NumberStrPair p : list) {
							ChartConfigCollection.getLOPExecutor().checkUserBreak();
							int index = -1;
							if ((index = isElement(p,init)) != -1) 
								init.get(index)[1] = p.toString();
							else
								init.add(new Object[] { new Interval(p.getNumber().doubleValue()), p.toString(), null, null });
						}
					}
					tmodel = new ShapeRendererTableModel(init,userDefRenderer.getDefaultColor());
					getTable().setModel(tmodel);
					return null;
				}
			});
		} catch (UserBreakException e) {
			try {
				tmodel = new ShapeRendererTableModel(init,userDefRenderer.getDefaultColor());
				getTable().setModel(tmodel);
			} catch (UserBreakException e1) {}
		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
		enableDisableButtons();
	}
	
	//----------------------------------------------------------------------------
	private UserDefinedFigureRenderer buildUserDefinedRenderer(String name) {
		UserDefinedFigureRenderer userDefRenderer = new UserDefinedFigureRenderer();
		userDefRenderer.setName(name);
		for (int i = 0; i < tmodel.getRowCount() - 1;++i) {
			Object[] row = tmodel.getRow(i);
			String color_str = (String) row[3];
			if (i == 0) {
				Color color = Utilities.toColor(color_str,Color.white);
				userDefRenderer.setDefaultColor(color);
			} else {
				Color color = Utilities.toColor(color_str,userDefRenderer.getDefaultColor());
				Interval intv = (Interval) row[0];
				String figure = null;
				if (row[2] != null) {
					figure = ((ImageIcon)row[2]).getDescription();
				}
				userDefRenderer.addEntry(intv,figure,color);
			}
		}
		definedRenderers.put(name,userDefRenderer);
		reloadCombobox(name);
		return userDefRenderer;
	}
	
	//----------------------------------------------------------------------------
	/** Adds a figure or icon specified by <code>figure</code> to the table.
	 * @param figure String id of a figure or path of an image
	 */
	private void addFigure(String figure) {
		int[] indices = getTable().getSelectedRows();
		if (indices.length == 0) return;
		for (int i = 0;i < indices.length;++i) {
			if (indices[i] == 0 || indices[i] == tmodel.getRowCount() - 1) continue;
			else {
				if (figure.equals(UserDefinedFigureRenderer.DEFAULT)) 
					tmodel.setValueAt(null,indices[i],2);
				else
					tmodel.setValueAt(getImageIcon(figure),indices[i],2);
			}
		}
	}
	
	//----------------------------------------------------------------------------
	/** Returns an icon specified by <code>figure</code>. If any problems occure,
	 *  it returns the default icon of the shape renderer.
	 * @param figure String id of a figure or path of an image
	 * @return an icon
	 * @see ai.aitia.chart.view.ui.UserDefinedFigureRenderer UserDefinedFigureRenderer
	 */
	private ImageIcon getImageIcon(String figure) {
		if (figure == null || figure.equals("")) return null;
		if (figure.equals(UserDefinedFigureRenderer.CIRCLE) ||
			figure.equals(UserDefinedFigureRenderer.RECTANGLE) ||
			figure.equals(UserDefinedFigureRenderer.TRIANGLE)) 
			return Utilities.getIcon(figure);
		ImageIcon icon = new ImageIcon(figure);
		if (icon != null && icon.getIconWidth() != -1) {
			Image img = icon.getImage();
			img = img.getScaledInstance(16,16,Image.SCALE_FAST);
			return new ImageIcon(img,figure);
		} else 
			return new UserDefinedFigureRenderer().getDefaultIcon();
	}
	
	//----------------------------------------------------------------------------
	/** Opens a file dialog to select an icon. Then adds the selected icon to the
	 *  table. It uses {@link #addFigure(String) addFigure()}.
	 */ 
	private void openFileDialog() {
		// get the file name
		JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
		fc.setAcceptAllFileFilterUsed(false);
		fc.addChoosableFileFilter(new ImageFileFilter());
		int result = fc.showOpenDialog(getAssignDialog());
		if (result == JFileChooser.APPROVE_OPTION) {
			File file = fc.getSelectedFile();
			GlobalHandlers.setLastDirectory(file);
			String filename = file.getPath();
			if (!iconCache.contains(filename)) {
				iconCache.add(filename);
				if (iconCache.size() > 10)
					iconCache.remove(0);
			}
			addFigure(filename);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public boolean hasDefinedRenderer() {
		boolean notDefinedRenderer = current.equals(ChartConstants.DEFINED) || (current.equals(ChartConstants.CUSTOM) && elementRendererClass == null); 
		return !notDefinedRenderer;
	}

	//-------------------------------------------------------------------------------
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("DOWN".equals(command)) 
			move(1);
		else if ("UP".equals(command)) 
			move(-1);
		else if ("REMOVE".equals(command)) {
			table.getSelectionModel().removeSelectionInterval(0,0);
			table.getSelectionModel().removeSelectionInterval(tmodel.getRowCount()-1,tmodel.getRowCount() - 1);
			int[] selected = table.getSelectedRows();
			if (selected.length == 0) return;
			String msg[] = new String[2];
			if (selected.length == 1) 
				msg[0] = String.format("The following entry will be deleted: %s", tmodel.getRow(selected[0])[1].toString());
			else 
				msg[0] = String.format("The selected entries (%d) will be deleted.",selected.length);
			msg[1] = "Are you sure?";
			boolean ok = JOptionPane.showConfirmDialog(getAssignDialog(), msg, "Warning", 
													   JOptionPane.YES_NO_OPTION,
													   JOptionPane.WARNING_MESSAGE
													   ) == JOptionPane.YES_OPTION;
			if (ok) {
				while (selected.length != 0) {
					tmodel.removeRow(selected[0]);
					selected = table.getSelectedRows();
				}
				enableDisableButtons();
			}
		} else if ("DEFAULT".equals(command)) {
			int[] indices = table.getSelectedRows();
			if (indices.length != 0) {
				for (int i = 0;i < indices.length;++i) {
					if (indices[i] == 0 || indices[i] == tmodel.getRowCount() - 1) continue;
					else 
						tmodel.setValueAt(null,indices[i],3);
				}
			}
		} else if ("EDIT_BUTTON".equals(command)) {
			String id = ((ComboboxItem)shapeRenderer.getSelectedItem()).getID().toString();
			UserDefinedFigureRenderer renderer = definedRenderers.get(id);
			getAssignDialog(); // make sure to create the dialog
			nameField.setText(renderer.getName());
			setTableElements(renderer);
			getAssignDialog().setVisible(true);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void focusGained(FocusEvent e) {}
	
	//----------------------------------------------------------------------------------------------------
	public void focusLost(FocusEvent e) {
		String name = nameField.getText().trim();
		if (reservedNames.contains(name)) {
			JOptionPane.showMessageDialog(getAssignDialog(),"This is a reserved name for a predefined renderer.","Please define a new name!",JOptionPane.WARNING_MESSAGE,null);
			nameField.setText(defaultName());
			nameField.grabFocus();
			nameField.selectAll();
		}
	}
	
	//-------------------------------------------------------------------------------
	private void move(int offset) {
		table.getSelectionModel().removeSelectionInterval(0,0);
		table.getSelectionModel().removeSelectionInterval(tmodel.getRowCount() - 1,tmodel.getRowCount() - 1);
		int[] selected = table.getSelectedRows();
		
		List<int[]> intervals = new ArrayList<int[]>();
		int start = selected[0], end = -1, previous = selected[0] - 1;

		for (int i = 0;i < selected.length;++i) {
				if (selected[i] == previous + 1)
					previous = selected[i];
				else {
					end = previous;
					int[] intv = { start, end };
					intervals.add(intv);
					end = -1;
					start = previous = selected[i];
				}
		}
		intervals.add(new int[] { start, selected[selected.length - 1] });
		
		table.getSelectionModel().clearSelection();
		for (int[] intv : intervals) {
			int to = intv[0] + offset;
			if (1 <= intv[0] && 1 <= to && intv[1] + offset < table.getRowCount() - 1) {
				tmodel.moveRow(intv[0],intv[1],to);
				table.getSelectionModel().addSelectionInterval(intv[0] + offset,intv[1] + offset);
			} else 
				table.getSelectionModel().addSelectionInterval(intv[0],intv[1]);
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	private String defaultName() {
		return DEFAULT_NAME_PREFIX + String.valueOf(countElementsWithSamePrefix(DEFAULT_NAME_PREFIX));
	}
	
	//----------------------------------------------------------------------------------------------------
	public int countElementsWithSamePrefix(String prefix) {
		int result = 0;
		for (String key : definedRenderers.keySet()) {
			if (key.startsWith(prefix))
				result++;
		}
		return result;
	}

	//-------------------------------------------------------------------------------
	private void enableDisableButtons() {
		moveUpButton.setEnabled(tmodel.getRowCount() > 3);
		moveDownButton.setEnabled(tmodel.getRowCount() > 3);
		removeButton.setEnabled(tmodel.getRowCount() > 2);
	}
}