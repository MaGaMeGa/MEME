package ai.aitia.visu.data;

public class DefaultGrid3DDataset_ObjLayer extends DefaultGrid3DDataset{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2658558143608246306L;

	public DefaultGrid3DDataset_ObjLayer(int column, int row) {
		super(column, row, 4);
	}
	

}
