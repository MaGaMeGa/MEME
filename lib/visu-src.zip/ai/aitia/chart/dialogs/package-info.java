/** This package contains the main graphical user-interface (GUI) where the user can
    create a collection of charts. It also contains a listener class used for listening
    title and save status changing. */
package ai.aitia.chart.dialogs;