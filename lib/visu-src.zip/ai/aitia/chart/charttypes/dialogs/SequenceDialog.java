/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Vector;
import java.util.Map.Entry;
import java.util.concurrent.Callable;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

import org.jfree.ui.ExtensionFileFilter;
import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.IDataSourceProducer.NumberStrPair;
import ai.aitia.chart.charttypes.dialogs.assisttypes.AllDummyDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.SettingsEditor;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.ds.IElementListProducer;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.ImageFileFilter;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.view.ui.UserDefinedFigureRenderer;
import ai.aitia.chart.view.ui.UserDefinedFigureRenderer.Triplet;
import ai.aitia.meme.utils.FormsUtils;
import ai.aitia.visu.globalhandlers.GlobalHandlers;
import ai.aitia.visu.globalhandlers.UserBreakException;
import ai.aitia.visu.utils.Interval;
import ai.aitia.visu.utils.Utils;
import ai.aitia.visu.view.ui.IElementRenderer;

/** GUI component of the sequence charts. */
public class SequenceDialog extends AbstractChartDialog implements MouseListener,
																   ActionListener {
	
	private static final long serialVersionUID = 1L;
	private JTabbedPane tabbed = null;
	private JPanel mainPanel = null;
	private JPanel paramPanel = null;
	private JPanel valuesPanel = null;
	private JComboBox params = null;
	private JButton advancedButton = null;
	private JPanel addButtonPanel = null;
	private JButton addButton = null;
	private JPanel selectedPanel = null;
	private JScrollPane scrList = null;
	private JList setList = null;
	private JPanel sortPanel = null;
	private JButton downButton = null;
	private JButton upButton = null;
	private JButton removeButton = null;
	private JPanel detailsPanel = null;
	private JPanel titleLine = null;
	private JLabel jLabel = null;
	private JPanel subtitleLine = null;
	private JLabel jLabel1 = null;
	private JTextField subtitleField = null;
	private JPanel rendererLine = null;
	private JLabel jLabel2 = null;
	private JComboBox rendererComboBox = null;
	private JPanel rendererParamPanel = null;
	private JPanel defaultPanel = null;
	private JLabel jLabel3 = null;
	private JButton elementColorButton = null;
	private JLabel jLabel4 = null;
	private JButton contourColorButton = null;
	private JPanel customPanel = null;
	private JLabel jLabel5 = null;
	private JTextField rendererClassField = null;
	private JButton browseButton = null;
	private JButton settingsButton = null;
	private JPanel buttonsPanel = null;
	private JButton cancelButton = null;
	private JLabel jLabel8 = null;
	private JPanel userDefinedPanel = null;
	private JButton defineButton = null;
	private JButton loadButton = null;
	private JDialog assignDialog = null;
	private JPanel contentPane = null;
	private JPanel shapesPanel = null;
	private JButton circleButton = null;
	private JButton rectangleButton = null;
	private JButton triangleButton = null;
	private JButton noneButton = null;
	private JButton iconButton = null;
	private JPanel assignPanel = null;
	private JPanel leftPanel = null;
	private JColorChooser colorPanel = null;
	private JButton saveRendererButton = null;
	private JTable table = null;
	private JScrollPane scrTable = null;
	private JPanel closePanel = null;
	private JButton closeButton = null;
	private JComboBox appearanceBox = null;
	private JPanel tableButtonsPanel = null;
	private JButton tMoveUpButton = null;
	private JButton tMoveDownButton = null;
	private JButton tRemoveButton = null;
	private JButton tDefaultButton = null;
	
	private JPopupMenu setsContextMenu = new JPopupMenu();
	private AbstractAction removeAction = null;
	private AbstractAction upAction = null;
	private AbstractAction downAction = null;
	
	//=============================================================================
	// additional members
	
	/** Model of the list of selected sets. */	
	private DefaultListModel lmodel = null;
	
	/** Model of the table. */
	private ElementRendererTableModel tmodel = null;
	
	/** List of the selected data source producers. */
	private List<IDataSourceProducer> sets = null;
	
	/** Color of the elements (used only with default renderer).*/
	private Color elementColor = Color.BLUE;
	
	/** Color of the contour (used only with default renderer). */
	private Color contourColor = Color.BLACK;
	
	/** Class of the custom element renderer (if any). */
	private Class elementRendererClass = null;
	
	/** Settings of the custom element renderer (if any. */
	private Properties elementRendererSettings = null;

	/** User defined renderer instance. */
	private UserDefinedFigureRenderer userDefRenderer = null;
	
	/** Cache for icon paths. */
	private List<String> iconCache = null;
	
	/** Special producer for 'All' combobox item. */
	private AllDummyDataSourceProducer allProducer = new AllDummyDataSourceProducer(); //  @jve:decl-index=0:
	
	//=============================================================================
	// nested classes
	
	/** Table model for define user defined renderer. */
	private class ElementRendererTableModel extends AbstractTableModel {
		
		private static final long serialVersionUID = 1L;
		
		/** Array of the column names. */
		private String[] columnNames = new String[] { "Element interval/value", "Element name", "Figure/Icon", "Color of figure" };
		
		/** List of rows. Each row is represented by an array of Objects. Each array
		 *  has four elements: the interval of the element, the name of the element, the 
		 *  figure/icon of the element and the color of the element (last one used only
		 *  if the third object is a figure).
		 */ 
		private List<Object[]> data = null;
		
		/** The element renderer object. */
		private UserDefinedFigureRenderer renderer = null;
		
		//========================================================================
		// methods

		/** Constructor. 
		 * @param init List of interval,name,figure,color tuples that already are in the table
		 * @param renderer the element renderer object
		 */
		public ElementRendererTableModel(List<Object[]> init, UserDefinedFigureRenderer renderer) throws UserBreakException {
			this.renderer = renderer;
			data = new ArrayList<Object[]>();
			data.add(new Object[] {null, "Default color", null, Utilities.colorText(this.renderer.getDefaultColor(),5) });
			for (Object[] o : init) {
				ChartConfigCollection.getLOPExecutor().checkUserBreak();
				data.add(new Object[] {o[0],o[1],getImageIcon((String)o[2]),Utilities.colorText((Color)o[3],5) });
			}
			data.add(new Object[] {null,"",null,Utilities.colorText(null,5) });
		}
		
		//------------------------------------------------------------------------
		@Override
		public String getColumnName(int col) {
			return columnNames[col];
		}
		
		//------------------------------------------------------------------------
		/** Returns the number of columns.
		 * @return the number of columns
		 */
		public int getColumnCount() {
			return columnNames.length;
		}

		//------------------------------------------------------------------------
		/** Returns the number of rows.
		 * @return the number of rows
		 */
		public int getRowCount() {
			return data.size();
		}

		//-------------------------------------------------------------------------
		/** Returns the <code>row</code>-th row of the table. */
		public Object[] getRow(int row) { return row < data.size() ? data.get(row) : null; }

		//-------------------------------------------------------------------------
		// Imported from DefaultTableModel
	    /** Removes the row at <code>row</code> from the model.  Notification
	     *  of the row being removed will be sent to all the listeners.
	     * @param row the row index of the row to be removed
	     * @exception ArrayIndexOutOfBoundsException  if the row was invalid
	     */
		public void removeRow(int row) {
	        data.remove(row);
	        fireTableRowsDeleted(row, row);
	    }
		
		//-------------------------------------------------------------------------
		// Imported from DefaultTableModel
	    /** Moves one or more rows from the inclusive range <code>start</code> to 
	     *  <code>end</code> to the <code>to</code> position in the model. 
	     *  After the move, the row that was at index <code>start</code> 
	     *  will be at index <code>to</code>. 
	     *  This method will send a <code>tableChanged</code> notification
	     *  message to all the listeners. <p>
	     *
	     *  <pre>
	     *  Examples of moves:
	     *  <p>
	     *  1. moveRow(1,3,5);
	     *          a|B|C|D|e|f|g|h|i|j|k   - before
	     *          a|e|f|g|h|B|C|D|i|j|k   - after
	     *  <p>
	     *  2. moveRow(6,7,1);
	     *          a|b|c|d|e|f|G|H|i|j|k   - before
	     *          a|G|H|b|c|d|e|f|i|j|k   - after
	     *  <p> 
	     *  </pre>
	     *
	     * @param   start       the starting row index to be moved
	     * @param   end         the ending row index to be moved
	     * @param   to          the destination of the rows to be moved
	     * @exception  ArrayIndexOutOfBoundsException  if any of the elements 
	     * would be moved out of the table's range 
	     * 
	     */
	    public void moveRow(int start, int end, int to) { 
	    	int shift = to - start; 
	    	int first, last; 
	    	if (shift < 0) { 
	    		first = to; 
		    	last = end; 
	    	} else { 
	    		first = start; 
	    		last = to + end - start;  
	    	}
	        Utilities.rotate(data,first,last + 1,shift); 
	        fireTableRowsUpdated(first, last);
	    }
	    
		//------------------------------------------------------------------------
		/** Returns the value of the cell specified by <code>rowIndex</code> and
		 *  <code>columnIndex</code>.
		 * @param rowIndex row index of the cell
		 * @param columnIndex column index of the cell
		 * @return the value of the appropriate cell
		 */
		public Object getValueAt(int rowIndex, int columnIndex) {
			return data.get(rowIndex)[columnIndex];
		}
		
		//------------------------------------------------------------------------
		@SuppressWarnings("unchecked")
		@Override
		public Class getColumnClass(int c) {
			switch (c) {
			case 0  : return Interval.class;
			case 2  : return ImageIcon.class;
			default : return String.class;
			}
		}
		
		//------------------------------------------------------------------------
		@Override
		public boolean isCellEditable(int row, int col) {
	    	if (col != 0 || row == 0) return false ;
			return true;
		}
		
		//------------------------------------------------------------------------
		@Override
		public void setValueAt(Object value, int row, int col) {
			if (col == 0) {
				if (value == null) return;
				data.add(data.size()-1,new Object[] {value,value.toString(),null,Utilities.colorText(null,5)} );
			} else if (col == 2) {
				Object[] actRow = data.get(row);
				actRow[2] = value;
			} else if (col == 3) {
				Object[] actRow = data.get(row);
				actRow[3] = Utilities.colorText((Color)value,5);
			}
			fireTableCellUpdated(row,col);
		}
	}
	
	//---------------------------------------------------------------------------
	/** Renderer class that displays icons in the table. */
	private class ImageIconRenderer extends JLabel implements TableCellRenderer {
		
		private static final long serialVersionUID = 1L;

		//========================================================================
		// method
		
		/** Constructor. */
		public ImageIconRenderer() {
			super();
			setOpaque(true);
		}
		
		//------------------------------------------------------------------------
		/** Returns a component that contains an icon.
		 * @param table the table that use this renderer
		 * @param value the value of the cell
		 * @param isSelected whether the cell is selected or not
		 * @param hasFocus whether the cell has focus or not
		 * @param row row index of the cell
		 * @param column column index of the cell
		 * @return a rendered component
		 */
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			if (isSelected) {
				setBackground(table.getSelectionBackground());
				setForeground(table.getSelectionForeground());
			} else {
				setBackground(getScrTable().getBackground());
				setForeground(table.getForeground());
			}
			setHorizontalAlignment(JLabel.CENTER);
			setIcon((ImageIcon)value);
			return this;
		}
	}
	
	//=============================================================================
	// methods
	
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public SequenceDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		lmodel = new DefaultListModel();
		sets = new LinkedList<IDataSourceProducer>();
		userDefRenderer = new UserDefinedFigureRenderer();
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
	}
	
	//-----------------------------------------------------------------------------
	/** This method initializes <code>this</code>. */
	private void initialize() {
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.setMinimumSize(new Dimension(609, 219));
        this.add(getTabbed(), null);
        this.add(getButtonsPanel(), null);
		initializeContextMenu();
	}
	
	//-------------------------------------------------------------------------------
	/** This method initializes the context menu of the selected sets list.*/
	@SuppressWarnings("serial")
	private void initializeContextMenu() {
		downAction = new AbstractAction() {
			{
				putValue(NAME,"Down");
				putValue(ACTION_COMMAND_KEY,"DOWN");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		setsContextMenu.add(downAction);
		upAction = new AbstractAction() {
			{
				putValue(NAME,"Up");
				putValue(ACTION_COMMAND_KEY,"UP");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		setsContextMenu.add(upAction);
		removeAction = new AbstractAction() {
			{
				putValue(NAME,"Remove");
				putValue(ACTION_COMMAND_KEY,"REMOVE");
			}
			public void actionPerformed(ActionEvent e) { contextEvent(this,e); }
		};
		setsContextMenu.add(removeAction);
	}

	//-------------------------------------------------------------------------------
	/** Forwards the ActionEvent <code>e</code> to the general handler.
	 * @param action the action object 
	 * @param e the event
	 */
	private void contextEvent(AbstractAction action, ActionEvent e) {
		if (setList.getSelectedIndex() == -1) {
			int x = ((Integer)action.getValue("X")).intValue();
			int y = ((Integer)action.getValue("Y")).intValue();
			int index = setList.locationToIndex(new Point(x,y));
			setList.setSelectedIndex(index);
		}
		SequenceDialog.this.actionPerformed(e);
	}
	
	//-----------------------------------------------------------------------------
	private JTabbedPane getTabbed() {
		if (tabbed == null) {
			tabbed = new JTabbedPane();
			tabbed.setPreferredSize(new Dimension(609, 168));
			tabbed.addTab("Main Settings", Utilities.icons.get(ChartConstants.SEQUENCE), getMainPanel(), null);
			tabbed.addTab("Details", null, getDetailsPanel(), null);
		}
		return tabbed;
	}

	//-----------------------------------------------------------------------------
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(new BoxLayout(getMainPanel(), BoxLayout.X_AXIS));
			mainPanel.add(getParamPanel(), null);
			mainPanel.add(getSelectedPanel(), null);
		}
		return mainPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getParamPanel() {
		if (paramPanel == null) {
			paramPanel = new JPanel();
			paramPanel.setLayout(new BoxLayout(getParamPanel(), BoxLayout.Y_AXIS));
			paramPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
			paramPanel.add(getValuesPanel(), null);
			paramPanel.add(Box.createRigidArea(new Dimension(0,10)));
			paramPanel.add(getAddButtonPanel(), null);
		}
		return paramPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getValuesPanel() {
		if (valuesPanel == null) {
			valuesPanel = new JPanel();
			valuesPanel.setLayout(new BoxLayout(getValuesPanel(), BoxLayout.X_AXIS));
			valuesPanel.setBorder(BorderFactory.createTitledBorder(null, "Sets", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			valuesPanel.setPreferredSize(new Dimension(140, 35));
			valuesPanel.setMinimumSize(new Dimension(140, 35));
			valuesPanel.add(getParams(), null);
			valuesPanel.add(Box.createRigidArea(new Dimension(5,0)));
			valuesPanel.add(getAdvancedButton(), null);
		}
		return valuesPanel;
	}

	//-----------------------------------------------------------------------------
	private JComboBox getParams() {
		if (params == null) {
			params = new JComboBox(getSets());
			params.setRenderer(new DataSourceComboBoxRenderer(params));
			params.setPreferredSize(new Dimension(100,26));
			if (params.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)params.getSelectedItem();
				params.setToolTipText(dsp.toString());
			}
			params.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)params.getSelectedItem();
					params.setToolTipText(dsp.toString());
					advancedButton.setEnabled(dsp.hasAdvancedSettings());
				}
			});
		}
		return params;
	}

	//-----------------------------------------------------------------------------
	private JButton getAdvancedButton() {
		if (advancedButton == null) {
			advancedButton = new JButton();
			advancedButton.setEnabled(false);
			advancedButton.setText("Advanced...");
			final SequenceDialog tthis = this;
			advancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)params.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(tthis.getRootPane().getParent());
					if (new_dsp != null) {
						int index = params.getSelectedIndex();
						params.removeItemAt(index);
						params.insertItemAt(new_dsp,index);
						params.setSelectedIndex(index);
					}
				}
			});
			if (params.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer)params.getSelectedItem();
				advancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return advancedButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getAddButtonPanel() {
		if (addButtonPanel == null) {
			addButtonPanel = new JPanel();
			addButtonPanel.setLayout(new FlowLayout());
			addButtonPanel.add(getAddButton(), null);
		}
		return addButtonPanel;
	}

	//-----------------------------------------------------------------------------
	private JButton getAddButton() {
		if (addButton == null) {
			addButton = new JButton();
			addButton.setMnemonic(KeyEvent.VK_A);
			addButton.setText("Add");
			addButton.setIcon(Utilities.getIcon("RIGHT ARROW"));
			addButton.setIconTextGap(2);
			addButton.setHorizontalTextPosition(JButton.LEADING);
			final SequenceDialog tthis = this;
			addButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)params.getSelectedItem();
					if (dsp.equals(allProducer)) {
						// special data source
						for (int i=0;i<params.getItemCount();++i) {
							IDataSourceProducer p = (IDataSourceProducer)params.getItemAt(i);
							if (p.equals(allProducer)) continue;
							sets.add(p);
							lmodel.addElement(p.toString());
						}
					} else {
						sets.add(dsp);
						lmodel.addElement(dsp.toString());
					}
					
					// enable the buttons (if need)
					if (sets.size() > 0) {
						removeButton.setEnabled(true);
						if (isUpdateable()) {
							displayButton.setEnabled(true);
							ChartDialogChangeCenter.fireSaveEnabled(tthis);
							defineButton.setEnabled(true);
							loadButton.setEnabled(true);
						}
					}
					if (sets.size() > 1) {
						downButton.setEnabled(true);
						upButton.setEnabled(true);
					}
				}
			});
		}
		return addButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getSelectedPanel() {
		if (selectedPanel == null) {
			selectedPanel = new JPanel();
			selectedPanel.setLayout(new BoxLayout(getSelectedPanel(), BoxLayout.Y_AXIS));
			selectedPanel.setMinimumSize(new Dimension(150, 100));
			selectedPanel.setBorder(BorderFactory.createTitledBorder(null, "Selected sets", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			selectedPanel.setPreferredSize(new Dimension(150, 100));
			selectedPanel.add(getScrList(), null);
			selectedPanel.add(getSortPanel(), null);
		}
		return selectedPanel;
	}

	//-----------------------------------------------------------------------------
	private JScrollPane getScrList() {
		if (scrList == null) {
			scrList = new JScrollPane();
			scrList.setAutoscrolls(true);
			scrList.setViewportView(getSetList());
			scrList.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			scrList.setWheelScrollingEnabled(true);
		}
		return scrList;
	}

	//-----------------------------------------------------------------------------
	private JList getSetList() {
		if (setList == null) {
			setList = new JList(lmodel);
			setList.setAutoscrolls(true);
			setList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			setList.addMouseListener(this);
		}
		return setList;
	}

	//-----------------------------------------------------------------------------
	private JPanel getSortPanel() {
		if (sortPanel == null) {
			sortPanel = new JPanel();
			sortPanel.setLayout(new FlowLayout());
			sortPanel.setMinimumSize(new Dimension(150, 36));
			sortPanel.setPreferredSize(new Dimension(150, 36));
			sortPanel.add(getDownButton(), null);
			sortPanel.add(getUpButton(), null);
			sortPanel.add(getRemoveButton(), null);
		}
		return sortPanel;
	}

	//-----------------------------------------------------------------------------
	private JButton getDownButton() {
		if (downButton == null) {
			downButton = new JButton();
			downButton.setEnabled(false);
			downButton.setText("Down");
			downButton.setMnemonic(KeyEvent.VK_DOWN);
			downButton.setActionCommand("DOWN");
			downButton.addActionListener(this);
		}
		return downButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getUpButton() {
		if (upButton == null) {
			upButton = new JButton();
			upButton.setEnabled(false);
			upButton.setMnemonic(KeyEvent.VK_UP);
			upButton.setText("Up");
			upButton.setMaximumSize(new Dimension(66, 26));
			upButton.setActionCommand("UP");
			upButton.addActionListener(this);
		}
		return upButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getRemoveButton() {
		if (removeButton == null) {
			removeButton = new JButton();
			removeButton.setEnabled(false);
			removeButton.setText("Remove");
			removeButton.setMnemonic(KeyEvent.VK_R);
			removeButton.setActionCommand("REMOVE");
			removeButton.addActionListener(this);
		}
		return removeButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getDetailsPanel() {
		if (detailsPanel == null) {
			detailsPanel = new JPanel();
			detailsPanel.setLayout(new BoxLayout(getDetailsPanel(), BoxLayout.Y_AXIS));
			detailsPanel.setBorder(BorderFactory.createTitledBorder(null, "Titles and element renderer of the chart", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			detailsPanel.add(getTitleLine(), null);
			detailsPanel.add(getSubtitleLine(), null);
			detailsPanel.add(getRendererLine(), null);
			detailsPanel.add(Box.createRigidArea(new Dimension(0,5)));
			detailsPanel.add(getRendererParamPanel(), null);
		}
		return detailsPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getTitleLine() {
		if (titleLine == null) {
			jLabel = new JLabel();
			jLabel.setText("  Title:  ");
			jLabel.setPreferredSize(new Dimension(125, 16));
			titleLine = new JPanel();
			titleLine.setLayout(new BoxLayout(getTitleLine(), BoxLayout.X_AXIS));
			titleLine.setPreferredSize(new Dimension(400, 30));
			titleLine.add(jLabel, null);
			titleLine.add(getTitleField(), null);
		}
		return titleLine;
	}

	//-----------------------------------------------------------------------------
	private JTextField getTitleField() {
		if (titleField == null) {
			titleField = new JTextField();
			titleField.setMaximumSize(new Dimension(2147483647, 30));
			titleField.setPreferredSize(new Dimension(275,20));
			titleField.setText(ChartConstants.SEQUENCE_NAME);
			final SequenceDialog tthis = this;
			titleField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					properties.setProperty(ChartConstants.TITLE,titleField.getText());
					ChartDialogChangeCenter.fireTitleChanged(tthis);
				}
			});
			titleField.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					subtitleField.grabFocus();
				}
			});
		}
		return titleField;
	}

	//-----------------------------------------------------------------------------
	private JPanel getSubtitleLine() {
		if (subtitleLine == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("  Subtitle:  ");
			jLabel1.setPreferredSize(new Dimension(125, 16));
			subtitleLine = new JPanel();
			subtitleLine.setLayout(new BoxLayout(getSubtitleLine(), BoxLayout.X_AXIS));
			subtitleLine.setPreferredSize(new Dimension(400, 30));
			subtitleLine.add(jLabel1, null);
			subtitleLine.add(getSubtitleField(), null);
		}
		return subtitleLine;
	}

	//-----------------------------------------------------------------------------
	private JTextField getSubtitleField() {
		if (subtitleField == null) {
			subtitleField = new JTextField();
			subtitleField.setMaximumSize(new Dimension(2147483647, 30));
			subtitleField.setPreferredSize(new Dimension(275, 20));
			subtitleField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
				}
			});
		}
		return subtitleField;
	}

	//-----------------------------------------------------------------------------
	private JPanel getRendererLine() {
		if (rendererLine == null) {
			jLabel8 = new JLabel();
			jLabel8.setText(" Appearance:  ");
			jLabel2 = new JLabel();
			jLabel2.setText("  Element renderer:  ");
			jLabel2.setPreferredSize(new Dimension(125, 16));
			rendererLine = new JPanel();
			rendererLine.setLayout(new BoxLayout(getRendererLine(), BoxLayout.X_AXIS));
			rendererLine.add(jLabel2, null);
			rendererLine.add(getRendererComboBox(), null);
			rendererLine.add(Box.createRigidArea(new Dimension(10,0)));
			rendererLine.add(jLabel8, null);
			rendererLine.add(getAppearanceBox(), null);
		}
		return rendererLine;
	}

	//-----------------------------------------------------------------------------
	private JComboBox getRendererComboBox() {
		if (rendererComboBox == null) {
			ComboboxItem[] renderers = new ComboboxItem[] {
					new ComboboxItem("DEFAULT", "Default renderer"),
					new ComboboxItem("DEFINED", "User defined renderer"),
					new ComboboxItem("CUSTOM", "Custom renderer")
			};
			rendererComboBox = new JComboBox(renderers);
			rendererComboBox.setPreferredSize(new Dimension(200, 40));
			rendererComboBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					CardLayout cl = (CardLayout)rendererParamPanel.getLayout();
					cl.show(rendererParamPanel,(String)((ComboboxItem)rendererComboBox.getSelectedItem()).getID());
				}
			});
		}
		return rendererComboBox;
	}

	//-----------------------------------------------------------------------------
	private JPanel getRendererParamPanel() {
		if (rendererParamPanel == null) {
			rendererParamPanel = new JPanel();
			rendererParamPanel.setLayout(new CardLayout());
			rendererParamPanel.add(getDefaultPanel(), getDefaultPanel().getName());
			rendererParamPanel.add(getUserDefinedPanel(), getUserDefinedPanel().getName());
			rendererParamPanel.add(getCustomPanel(), getCustomPanel().getName());
		}
		return rendererParamPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getDefaultPanel() {
		if (defaultPanel == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("  Contour color:  ");
			jLabel4.setPreferredSize(new Dimension(125,16));
			jLabel4.setMinimumSize(new Dimension(125,16));
			jLabel3 = new JLabel();
			jLabel3.setText("  Element color:  ");
			jLabel3.setPreferredSize(new Dimension(125,16));
			jLabel3.setMinimumSize(new Dimension(125,16));
			defaultPanel = new JPanel();
			defaultPanel.setLayout(new BoxLayout(getDefaultPanel(), BoxLayout.X_AXIS));
			defaultPanel.setName("DEFAULT");
			defaultPanel.add(jLabel3, null);
			defaultPanel.add(getElementColorButton(), null);
			defaultPanel.add(Box.createRigidArea(new Dimension(20,0)));
			defaultPanel.add(jLabel4, null);
			defaultPanel.add(getContourColorButton(), null);
		}
		return defaultPanel;
	}

	//-----------------------------------------------------------------------------
	private JButton getElementColorButton() {
		if (elementColorButton == null) {
			elementColorButton = new JButton(Utilities.colorText(elementColor,5));
			elementColorButton.setPreferredSize(new Dimension(100,26));
			final SequenceDialog tthis = this;
			elementColorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Color new_color = JColorChooser.showDialog(tthis, "Color of the elements",elementColor);
					if (new_color != null) {
						elementColor = new_color;
						elementColorButton.setText(Utilities.colorText(elementColor,5));
					}
				}
			});
		}
		return elementColorButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getContourColorButton() {
		if (contourColorButton == null) {
			contourColorButton = new JButton(Utilities.colorText(Color.BLACK,5));
			contourColorButton.setPreferredSize(new Dimension(100,26));
			final SequenceDialog tthis = this;
			contourColorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Color new_color = JColorChooser.showDialog(tthis,"Color of the contour",contourColor);
					if (new_color != null) {
						contourColor = new_color;
						contourColorButton.setText(Utilities.colorText(contourColor,5));
					}
				}
			});
		}
		return contourColorButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getCustomPanel() {
		if (customPanel == null) {
			jLabel5 = new JLabel();
			jLabel5.setPreferredSize(new Dimension(125, 16));
			jLabel5.setText("  Renderer class:  ");
			customPanel = new JPanel();
			customPanel.setLayout(new BoxLayout(getCustomPanel(), BoxLayout.X_AXIS));
			customPanel.setName("CUSTOM");
			customPanel.add(jLabel5, null);
			customPanel.add(getRendererClassField(), null);
			customPanel.add(Box.createRigidArea(new Dimension(5,0)));
			customPanel.add(getBrowseButton(), null);
			customPanel.add(Box.createRigidArea(new Dimension(5,0)));
			customPanel.add(getSettingsButton(), null);
		}
		return customPanel;
	}

	//-----------------------------------------------------------------------------
	private JTextField getRendererClassField() {
		if (rendererClassField == null) {
			rendererClassField = new JTextField();
			rendererClassField.setMaximumSize(new Dimension(2147483647, 20));
			rendererClassField.setEditable(false);
		}
		return rendererClassField;
	}

	//-----------------------------------------------------------------------------
	private JButton getBrowseButton() {
		if (browseButton == null) {
			browseButton = new JButton();
			browseButton.setText("Browse...");
			browseButton.setMnemonic(KeyEvent.VK_B);
			final SequenceDialog tthis = this;
			browseButton.addActionListener(new java.awt.event.ActionListener() {
				@SuppressWarnings("unchecked")
				public void actionPerformed(java.awt.event.ActionEvent e) {
					JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
					fc.setAcceptAllFileFilterUsed(false);
					fc.setFileFilter(new ExtensionFileFilter("Java class files (.class)","class"));
					fc.setAcceptAllFileFilterUsed(false);
					fc.addChoosableFileFilter(new ExtensionFileFilter("Java class files",".class"));
					int result = fc.showOpenDialog(tthis);
					if (result == JFileChooser.APPROVE_OPTION) {
						File file = fc.getSelectedFile();
						GlobalHandlers.setLastDirectory(file);
						String name = file.getPath();
						String osName = System.getProperty("os.name").toLowerCase();
						name = name.substring(osName.indexOf("windows") >= 0 ? 3 : 1,name.lastIndexOf(".class"));
						String swap = null;
						if (File.separator.equals("\\")) swap="\\";
						else swap="";
						name = name.replaceAll(swap+File.separator,".");
						String candidate = name;
						Class c = null;
						int index = 0;
						while (c == null) {
							try {
//								System.out.println(candidate);
								c = Class.forName(candidate);
							} catch (ClassNotFoundException e1) {
								int oldIndex = index;
								index = name.indexOf(".",oldIndex+1);
								if (index == -1) {
									JOptionPane.showMessageDialog(tthis,"Unable to load class!", "Error", JOptionPane.ERROR_MESSAGE, null);
									return;
								}
								candidate = name.substring(index+1);
								continue;
							}
							break;
						}
						Class[] intfs = c.getInterfaces();
						boolean implemented = false;
						for (int i=0;i<intfs.length;++i) {
							if (intfs[i].equals(IElementRenderer.class)) {
								implemented = true;
								break;
							}
						}
						if (!implemented) {
							JOptionPane.showMessageDialog(tthis,"This class has not implemented the IElementRenderer interface!", "Warning", JOptionPane.WARNING_MESSAGE, null);
							return;
						}
						boolean validConstructor = true;
						try {
							c.getConstructor(new Class[] {});
						} catch (Exception e1) {
							validConstructor = false;
						}
						if (!validConstructor) {
							try {
								validConstructor = true;
								c.getConstructor(new Class[] { Properties.class });
							} catch (Exception e1) {
								validConstructor = false;
							}
						}
						if (!validConstructor) {
							JOptionPane.showMessageDialog(tthis,"This class has not appropriate constructor!", "Warning", JOptionPane.WARNING_MESSAGE, null);
							return;
						}
						rendererClassField.setText(c.getName());
						settingsButton.setEnabled(true);
						elementRendererClass = c;
						elementRendererSettings = null;
					}
				}
			});
		}
		return browseButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getSettingsButton() {
		if (settingsButton == null) {
			settingsButton = new JButton();
			settingsButton.setEnabled(false);
			settingsButton.setText("Settings...");
			settingsButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					java.awt.Container c = getTopLevelAncestor();
					SettingsEditor editor;
					if (c instanceof JDialog)
						editor = new SettingsEditor((javax.swing.JDialog)c, elementRendererSettings);
					else
						editor = new SettingsEditor((javax.swing.JFrame)c, elementRendererSettings);
					editor.setLocationRelativeTo(c);
					editor.setModal(true);
					editor.setVisible(true);
					elementRendererSettings = editor.getSettings();
					editor.dispose();
				}
			});
		}
		return settingsButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getButtonsPanel() {
		if (buttonsPanel == null) {
			buttonsPanel = new JPanel();
			buttonsPanel.setLayout(new FlowLayout());
			buttonsPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
			buttonsPanel.add(getEditorButton(), null);
			buttonsPanel.add(getDisplayButton(), null);
			buttonsPanel.add(getSaveButton(), null);
			buttonsPanel.add(getCancelButton(), null);
		}
		return buttonsPanel;
	}
	
	//-----------------------------------------------------------------------------
	private JButton getDisplayButton() {
		if (displayButton == null) {
			displayButton = new JButton();
			displayButton.setText("Display");
			displayButton.setEnabled(false);
			displayButton.setMnemonic(KeyEvent.VK_D);
			displayButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					displayChart();
				}
			});
		}
		return displayButton;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}
	
	//-----------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setText("Save");
			saveButton.setEnabled(false);
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					saveCollection();
				}
			});
		}
		return saveButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMnemonic(KeyEvent.VK_C);
			cancelButton.setText("Cancel");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					notifyForHide();
				}
			});
		}
		return cancelButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getUserDefinedPanel() {
		if (userDefinedPanel == null) {
			userDefinedPanel = new JPanel();
			userDefinedPanel.setLayout(new BoxLayout(getUserDefinedPanel(), BoxLayout.X_AXIS));
			userDefinedPanel.setName("DEFINED");
			userDefinedPanel.add(Box.createRigidArea(new Dimension(125,0)));
			userDefinedPanel.add(getDefineButton(), null);
			userDefinedPanel.add(Box.createRigidArea(new Dimension(10,0)));
			userDefinedPanel.add(getLoadButton(), null);
		}
		return userDefinedPanel;
	}

	//-----------------------------------------------------------------------------
	private JButton getDefineButton() {
		if (defineButton == null) {
			defineButton = new JButton();
			defineButton.setText("Assign figure to element...");
			defineButton.setEnabled(false);
			defineButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (assignDialog != null) {
						setTableElements();
					}
					getAssignDialog().setVisible(true);
				}
			});
		}
		return defineButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getLoadButton() {
		if (loadButton == null) {
			loadButton = new JButton();
			loadButton.setText("Load element renderer...");
			loadButton.setEnabled(false);
			final SequenceDialog tthis = this;
			loadButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					// get the file name
					JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
					fc.setAcceptAllFileFilterUsed(false);
					fc.addChoosableFileFilter(new ExtensionFileFilter("Element Renderer files (.erf)","erf"));
					int result = fc.showOpenDialog(tthis);
					if (result == JFileChooser.APPROVE_OPTION) {
						File file = fc.getSelectedFile();
						GlobalHandlers.setLastDirectory(file);
						
						// open the file
						Properties shapeRenderer = new Properties();
						try {
							FileInputStream is = new FileInputStream(file);
							shapeRenderer.load(is);
							is.close();
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(tthis,"Unable to load the selected element renderer.","Loading failure",JOptionPane.ERROR_MESSAGE,null);
							return;
						}
						// set the shaperenderer
						userDefRenderer = new UserDefinedFigureRenderer();
						int color = Integer.decode(shapeRenderer.getProperty(ChartConstants.DEFAULT_COLOR));
						userDefRenderer.setDefaultColor(new Color(color));
						String[] keys = shapeRenderer.keySet().toArray(new String[0]);
						Interval[] intvs = new Interval[keys.length-1];
						String[] figures = new String[keys.length-1];
						Color[] colors = new Color[keys.length-1];
						for (int i = 0;i < keys.length;++i) {
							if (!keys[i].equals(ChartConstants.DEFAULT_COLOR)) {
								String parts[] = shapeRenderer.getProperty(keys[i]).split("\\?");
								int index = Integer.parseInt(parts[2]);
								intvs[index] = new Interval(keys[i]);
								figures[index] = parts[0].equals("_") ? null : parts[0].trim();
								colors[index] = parts[1].equals("_") ? null : new Color(Integer.decode(parts[1]));
							}
						}
						if (iconCache == null)
							iconCache = new ArrayList<String>();
						for (int i = 0;i < intvs.length;++i) {
							userDefRenderer.addEntry(intvs[i],figures[i],colors[i]);
							if (figures[i] != null &&
								!figures[i].equals(UserDefinedFigureRenderer.CIRCLE) &&
								!figures[i].equals(UserDefinedFigureRenderer.RECTANGLE) &&
								!figures[i].equals(UserDefinedFigureRenderer.TRIANGLE)) {
									ImageIcon tryIcon = getImageIcon(figures[i]);
									if (!tryIcon.equals(userDefRenderer.getDefaultIcon()) && !iconCache.contains(figures[i])) {
										iconCache.add(figures[i]);
										if (iconCache.size()>10) iconCache.remove(0);
									}
							}
						}
					}
				}
			});
		}
		return loadButton;
	}
	
	//-----------------------------------------------------------------------------
	private JDialog getAssignDialog() {
		if (assignDialog == null) {
			Container c = getTopLevelAncestor();
			if (c instanceof JDialog)
				assignDialog = new JDialog((JDialog)c, "Assign figure to element value", true);
			else
				assignDialog = new JDialog((JFrame)c, "Assign figure to element value", true);
			final JScrollPane sp = new JScrollPane(getContentPane(),JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			sp.setBorder(null);
			assignDialog.setContentPane(sp);
			assignDialog.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
			setTableElements();
			assignDialog.pack();
			Dimension oldD = assignDialog.getPreferredSize();
			assignDialog.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
											     		oldD.height + sp.getHorizontalScrollBar().getHeight()));
			sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			oldD = assignDialog.getPreferredSize();
			final Dimension newD = Utils.getPreferredSize(assignDialog);
			if (!oldD.equals(newD)) 
				assignDialog.setPreferredSize(newD);
			assignDialog.pack();
			assignDialog.setLocationRelativeTo(c);
		}
		return assignDialog;
	}

	//-----------------------------------------------------------------------------
	private JPanel getContentPane() {
		if (contentPane == null) {
			contentPane = new JPanel();
			contentPane.setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
			contentPane.add(getShapesPanel(), null);
			contentPane.add(new JSeparator(JSeparator.HORIZONTAL));
			contentPane.add(getAssignPanel(), null);
			contentPane.add(new JSeparator(JSeparator.HORIZONTAL));
			contentPane.add(getClosePanel(), null);
		}
		return contentPane;
	}

	//-----------------------------------------------------------------------------
	private JPanel getShapesPanel() {
		if (shapesPanel == null) {
			shapesPanel = new JPanel();
			shapesPanel.setLayout(new FlowLayout());
			shapesPanel.add(getCircleButton(), null);
			shapesPanel.add(getRectangleButton(), null);
			shapesPanel.add(getTriangleButton(), null);
			shapesPanel.add(getNoneButton(), null);
			shapesPanel.add(getIconButton(), null);
		}
		return shapesPanel;
	}

	//-----------------------------------------------------------------------------
	private JButton getCircleButton() {
		if (circleButton == null) {
			circleButton = new JButton();
			circleButton.setIcon(Utilities.getIcon("CIRCLE"));
			circleButton.setPreferredSize(new Dimension(100, 26));
			circleButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addFigure(UserDefinedFigureRenderer.CIRCLE);
				}
			});
		}
		return circleButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getRectangleButton() {
		if (rectangleButton == null) {
			rectangleButton = new JButton();
			rectangleButton.setIcon(Utilities.getIcon("RECTANGLE"));
			rectangleButton.setPreferredSize(new Dimension(100, 26));
			rectangleButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addFigure(UserDefinedFigureRenderer.RECTANGLE);
				}
			});
		}
		return rectangleButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getTriangleButton() {
		if (triangleButton == null) {
			triangleButton = new JButton();
			triangleButton.setIcon(Utilities.getIcon("TRIANGLE"));
			triangleButton.setPreferredSize(new Dimension(100, 26));
			triangleButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addFigure(UserDefinedFigureRenderer.TRIANGLE);
				}
			});
		}
		return triangleButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getNoneButton() {
		if (noneButton == null) {
			noneButton = new JButton();
			noneButton.setText("<none>");
			noneButton.setPreferredSize(new Dimension(100, 26));
			noneButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addFigure(UserDefinedFigureRenderer.DEFAULT);
				}
			});
		}
		return noneButton;
	}
	
	//-----------------------------------------------------------------------------
	private JButton getIconButton() {
		if (iconButton == null) {
			iconButton = new JButton();
			iconButton.setText("Icon...");
			iconButton.setPreferredSize(new Dimension(100,26));
			iconButton.setActionCommand("ICON");
			iconCache = new ArrayList<String>();
			iconButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String command = e.getActionCommand();
					if (command.equals("ICON")) {
						if (iconCache.size() == 0) openFileDialog();
						else {
							JPopupMenu menu = new JPopupMenu();
							for (String s : iconCache) {
								JMenuItem item = new JMenuItem(s);
								item.setActionCommand(s);
								item.addActionListener(this);
								menu.add(item);
							}
							menu.addSeparator();
							JMenuItem browse = new JMenuItem("Browse...");
							browse.setActionCommand("BROWSE");
							browse.addActionListener(this);
							menu.add(browse);
							menu.show(iconButton,45,5);
						}
					} else if (command.equals("BROWSE")) openFileDialog();
					else addFigure(command);
				}
			});
		}
		return iconButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getAssignPanel() {
		if (assignPanel == null) {
			assignPanel = new JPanel();
			assignPanel.setLayout(new BoxLayout(getAssignPanel(), BoxLayout.X_AXIS));
			assignPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			assignPanel.add(getLeftPanel(), null);
			assignPanel.add(Box.createRigidArea(new Dimension(10,0)));
			assignPanel.add(getColorPanel(), null);
		}
		return assignPanel;
	}

	//-----------------------------------------------------------------------------
	private JPanel getLeftPanel() {
		if (leftPanel == null) {
			leftPanel = new JPanel();
			leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
			leftPanel.add(getScrTable(), null);
			leftPanel.add(Box.createRigidArea(new Dimension(0,5)));
			leftPanel.add(getTableButtonsPanel(),null);
			JPanel p = new JPanel();
			p.setMaximumSize(new Dimension(32323,24));
			p.add(getSaveRendererButton());
			leftPanel.add(p, null);
		}
		return leftPanel;
	}
	
	//----------------------------------------------------------------------------
	private JPanel getTableButtonsPanel() {
		if (tableButtonsPanel == null) {
			(tMoveUpButton = new JButton("Move up")).setActionCommand("T_UP");
			(tMoveDownButton = new JButton("Move down")).setActionCommand("T_DOWN");
			(tRemoveButton = new JButton("Remove")).setActionCommand("T_REMOVE");
			(tDefaultButton = new JButton("Reset color")).setActionCommand("T_DEFAULT");
			tableButtonsPanel = FormsUtils.build("p:g ~ p:g ~ p:g ~ p:g",
												 "_01_||" +
												 "_23_",
												 tMoveUpButton,tRemoveButton,
												 tMoveDownButton,tDefaultButton).getPanel();
			Utilities.addActionListener(this,tMoveUpButton,tRemoveButton,tMoveDownButton,tDefaultButton);
		}
		return tableButtonsPanel;
	}
	
	//-----------------------------------------------------------------------------
	private JColorChooser getColorPanel() {
		if (colorPanel == null) {
			colorPanel = new JColorChooser(Color.BLUE);
			colorPanel.getSelectionModel().addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					Color newColor = colorPanel.getColor();
					int[] indices = table.getSelectedRows();
					if (indices.length != 0) {
						for (int i=0;i<indices.length;++i) {
							if (indices[i]==0) 
								tmodel.setValueAt(newColor,0,3);
							else if (indices[i] == tmodel.getRowCount()-1) continue;
							else tmodel.setValueAt(newColor,indices[i],3);
						}
					}
				}
			});
		}
		return colorPanel;
	}

	//-----------------------------------------------------------------------------
	private JScrollPane getScrTable() {
		if (scrTable == null) {
			scrTable = new JScrollPane();
			scrTable.setBorder(BorderFactory.createTitledBorder(null, "Figure values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			scrTable.setViewportView(getTable());
		}
		return scrTable;
	}
	
	//-----------------------------------------------------------------------------
	private JTable getTable() {
		if (table == null) {
			table = new JTable() {
				private static final long serialVersionUID = 1L;
				{
					tableHeader.setReorderingAllowed(false);
				}
			};
			DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
			renderer.setLocale(Locale.US);
			renderer.setHorizontalAlignment(JTextField.TRAILING);
			renderer.setBackground(getScrTable().getBackground());
			DefaultTableCellRenderer renderer2 = new DefaultTableCellRenderer();
			renderer2.setHorizontalAlignment(JTextField.CENTER);
			renderer2.setBackground(getScrTable().getBackground());
			ImageIconRenderer renderer3 = new ImageIconRenderer();
			table.setDefaultRenderer(Interval.class,renderer);
			table.setDefaultRenderer(String.class,renderer2);
			table.setDefaultRenderer(ImageIcon.class,renderer3);

		}
		return table;
	}

	//-----------------------------------------------------------------------------
	private JButton getSaveRendererButton() {
		if (saveRendererButton == null) {
			saveRendererButton = new JButton();
			saveRendererButton.setMnemonic(KeyEvent.VK_S);
			saveRendererButton.setMaximumSize(new Dimension(162, 26));
			saveRendererButton.setMinimumSize(new Dimension(162, 26));
			saveRendererButton.setPreferredSize(new Dimension(162, 26));
			saveRendererButton.setText("Save element renderer...");
			saveRendererButton.addActionListener(new java.awt.event.ActionListener() {
				@SuppressWarnings("unchecked")
				public void actionPerformed(java.awt.event.ActionEvent e) {
					// get the filename
					JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
					fc.setAcceptAllFileFilterUsed(false);
					fc.addChoosableFileFilter(new ExtensionFileFilter("Element renderer files (.erf)","erf"));
					int result = fc.showSaveDialog(getAssignDialog());
					if (result == JFileChooser.APPROVE_OPTION) {
						buildUserDefinedRenderer();
						File file = fc.getSelectedFile();
						File newFile = Utilities.generateValidFile(file,"erf");
						GlobalHandlers.setLastDirectory(newFile);
						
						//initialize the Properties object
						Properties shapeRenderer = new Properties();
						String defColor = String.format("#%06x",userDefRenderer.getDefaultColor().getRGB() & 0xffffff);
						shapeRenderer.setProperty(ChartConstants.DEFAULT_COLOR,defColor);
						List<Triplet<Interval,String,Color>> map = userDefRenderer.getMap();
						for (int i = 0;i < map.size();++i) {
							Triplet<Interval,String,Color> t = map.get(i);
							Object[] FAC = userDefRenderer.getFigureAndColor(t.getFirst());
							if (FAC == null) continue;
							String index = String.valueOf(i);
							if (shapeRenderer.getProperty(t.getFirst().toString()) != null)
								index = shapeRenderer.getProperty(t.getFirst().toString()).split("\\?")[2];
							Color color = (Color)FAC[1];
							String figure = FAC[0] == null ? "_" : FAC[0].toString();
							String entry_string = figure + "?" + (color == null ? "_" : String.format("#%06x",color.getRGB() & 0xffffff)) + "?" + index;
							shapeRenderer.setProperty(t.getKey().toString(),entry_string);
						}
						
						// open file and save
						try {
							FileOutputStream os = new FileOutputStream(newFile);
							shapeRenderer.store(os,"");
							os.close();
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(getAssignDialog(),"Unable to save the defined element renderer.","Saving failure",JOptionPane.ERROR_MESSAGE,null);
						}
					}
				}
			});
			saveRendererButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		}
		return saveRendererButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getClosePanel() {
		if (closePanel == null) {
			closePanel = new JPanel();
			closePanel.setLayout(new FlowLayout());
			closePanel.add(getCloseButton(), null);
		}
		return closePanel;
	}

	//-----------------------------------------------------------------------------
	private JButton getCloseButton() {
		if (closeButton == null) {
			closeButton = new JButton();
			closeButton.setText("Close");
			closeButton.setMnemonic(KeyEvent.VK_C);
			closeButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					assignDialog.setVisible(false);
					buildUserDefinedRenderer();
				}
			});
		}
		return closeButton;
	}
	
	//-----------------------------------------------------------------------------
	private JComboBox getAppearanceBox() {
		if (appearanceBox == null) {
			Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
			appearances.add(new ComboboxItem( "BC", "Basic, colored"));
			appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
			appearances.add(new ComboboxItem( "NC", "Normal, colored"));
			for (String templateNames : AbstractChart.templates.keySet())
				appearances.add(new ComboboxItem("_" + templateNames,templateNames));
			appearances.add(new ComboboxItem("_NEW","New template..."));
			appearances.add(new ComboboxItem("_EDIT","Edit template..."));
			appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
			appearanceBox = new JComboBox(appearances);
			appearanceBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (appearanceBox.getSelectedIndex() == 2) {
						contourColor = elementColor = Color.BLACK;
						elementColorButton.setText(Utilities.colorText(elementColor,5));
						contourColorButton.setText(Utilities.colorText(contourColor,5));
					} else if (appearanceBox.getSelectedIndex() != -1) {
						elementColor = Color.BLUE;
						elementColorButton.setText(Utilities.colorText(elementColor,5));
					}
					int index = appearanceBox.getSelectedIndex();
			 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
					if (index >= 0 && index <= 2) {
				 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
				 		if (code[0].equals("B"))
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.BASIC_APP);
				 		else
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.NORMAL_APP);
				 		if (code[1].equals("BW"))
				 			ChartConfigCollection.setColorAppearance(ChartConstants.BLACK_AND_WHITE);
				 		else
				 			ChartConfigCollection.setColorAppearance(ChartConstants.COLORED);
					}  else if (appearanceCode.equals("_NEW")) {
						ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.NORMAL);
						int result = dlg.showDialog();
						if (result == ChartPropertiesDialog.OK_OPTION) {
							Element newTemplate = (Element) dlg.getTemplate();
							dlg.dispose();
							String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
							AbstractChart.templates.put(name,newTemplate);
							ChartDialogChangeCenter.fireTemplateChanged();
							appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
						} else 
							appearanceBox.setSelectedIndex(0);
					} else if (appearanceCode.equals("_EDIT")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(SequenceDialog.this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(SequenceDialog.this,"Select a template: ","Edit template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template == null || "".equals(template)) 
							appearanceBox.setSelectedIndex(0);
						else {
							Element templateElement = AbstractChart.templates.get(template);
							ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(),ChartKind.NORMAL);
							int result = dlg.showDialog();
							if (result == ChartPropertiesDialog.OK_OPTION) {
								Element newTemplate = (Element) dlg.getTemplate();
								dlg.dispose();
								String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
								AbstractChart.templates.put(name,newTemplate);
								ChartDialogChangeCenter.fireTemplateChanged();
								appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
							} else 
								appearanceBox.setSelectedIndex(0);
						}
					} else if (appearanceCode.equals("_REMOVE")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(SequenceDialog.this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(SequenceDialog.this,"Select a template: ","Delete template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template != null && !"".equals(template)) { 
							AbstractChart.templates.remove(template);
							File file = new File("Templates/" + template + ".xml");
							file.delete();
							ChartDialogChangeCenter.fireTemplateChanged();
						}
						appearanceBox.setSelectedIndex(0);
					}
				}
			});
		}
		return appearanceBox;
	}
	
	//------------------------------------------------------------------------------
	private List<String> getLegends() {
		List<String> result = new ArrayList<String>(lmodel.size());
		for (int i = 0;i < lmodel.size();++i)
			result.add(lmodel.get(i).toString());
		return result;
	}
	
	//============================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-generated functions                                                //
	////////////////////////////////////////////////////////////////////////////

	//-----------------------------------------------------------------------------
	/** Returns the displayable names of the data sources.
	 * @return array of data sources
	 */
	private Object[] getSets() {
		Object[] res = getParams(IElementListProducer.class);
		if (res.length != 0) {
			List<Object> resPlus = new ArrayList<Object>(Arrays.asList(res));
			resPlus.add(allProducer);
			return resPlus.toArray();
		}
		return res;
	}

	//-----------------------------------------------------------------------------
	@Override
	protected void displayPreview() throws Exception {
		DataSources ds = new DataSources(new SimpleDSPCollection());
		ChartConfig temp_config = new ChartConfig(ds);
		temp_config.setFireInitialEvent(true);
		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
		Properties temp_prop = (Properties)properties.clone();
		temp_config.addDataSource(dsl.get(0),IElementListProducer.class);
		temp_config.addDataSource(dsl.get(1),IElementListProducer.class);
		temp_config.addDataSource(dsl.get(2),IElementListProducer.class);
		temp_config.addDataSource(dsl.get(6),IElementListProducer.class);
		temp_prop.setProperty(ChartConstants.DATASOURCE,"1,2,3,4");
		temp_prop.setProperty(ChartConstants.TITLE,temp_prop.getProperty(ChartConstants.TITLE) + " (Preview Illustration)");
		temp_config.setChartProperties(ChartConstants.SEQUENCE,temp_prop);
		Utilities.displayPreview(temp_config);
	}

	//-----------------------------------------------------------------------------
	@Override
 	public boolean isUpdateable() {
		return !sets.isEmpty();
	}

	//-----------------------------------------------------------------------------
	@Override
	protected void setSettingsFromConfig() {
		if (config.getChartProperties() instanceof Properties) {
			// set settings from config
			properties = (Properties)config.getChartProperties();
			int[] ds = Utilities.splitDatasourceAroundCommas(properties.getProperty(ChartConstants.DATASOURCE));
			for (int i=0;i<ds.length;++i) {
				IDataSourceProducer dsp = config.getDataSource(ds[i]);
				sets.add(dsp);
				lmodel.addElement(dsp.toString());
			}
			IDataSourceProducer dsp = config.getDataSource(ds[ds.length-1]);
			params.setSelectedItem(dsp);
			titleField.setText(properties.getProperty(ChartConstants.TITLE));
			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
 			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
 			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
				String appearanceCode = "";
				appearanceCode += properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP) ? "N" : "B";
				appearanceCode += properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE) ? "BW" : "C";
				for (int i = 0;i < appearanceBox.getItemCount();++i) {
					String id = ((ComboboxItem)appearanceBox.getItemAt(i)).getID().toString();
					if (id.equals(appearanceCode)) {
						appearanceBox.setSelectedIndex(i);
						break;
					}
				}
 			}
			rendererFromString(properties.getProperty(ChartConstants.ELEMENT_RENDERER));
			if (sets.size() > 0) {
 				displayButton.setEnabled(true);
 				saveButton.setEnabled(true);
 				removeButton.setEnabled(true);
 				defineButton.setEnabled(true);
 				loadButton.setEnabled(true);
 			}
 			if (sets.size() > 1) {
 				downButton.setEnabled(true);
 				upButton.setEnabled(true);
 			}
 		} else {
 			// set the initial properties
 			properties.setProperty(ChartConstants.TITLE,ChartConstants.SEQUENCE_NAME);
 			properties.setProperty(ChartConstants.SUBTITLE,"");
 			
 			String colorApp = ChartConfigCollection.getColorAppearance();
 			String envApp = ChartConfigCollection.getEnvironmentAppearance();
 			int appIndex = 0; 
 			if (colorApp.equals(ChartConstants.COLORED) && envApp.equals(ChartConstants.NORMAL_APP))
 				appIndex = 2;
 			else {
 				appIndex += colorApp.equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
 				appIndex += envApp.equals(ChartConstants.NORMAL_APP) ? 1 : 0;
 			}
 			appearanceBox.setSelectedIndex(appIndex);
 		}
	}

	//-----------------------------------------------------------------------------
	@Override
	protected void setWidgetDisabled() {
		if (params.getItemCount() == 0) {
			params.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			advancedButton.setEnabled(false);
			addButton.setEnabled(false);
			defineButton.setEnabled(false);
			loadButton.setEnabled(false);
		}
	}

	//-----------------------------------------------------------------------------
	@Override
	public void updateChartConfig() {
		config.clearAllDataSource();
 		Iterator<IDataSourceProducer> it = sets.iterator();
 		String ds = "";
 		while (it.hasNext()) {
 			IDataSourceProducer dsp = it.next();
			int key = config.addDataSource(dsp,IElementListProducer.class);
 			ds += String.valueOf(key) + ",";
 		}
 		properties.setProperty(ChartConstants.DATASOURCE,ds.substring(0,ds.length()-1));
 		properties.setProperty(ChartConstants.ELEMENT_RENDERER,rendererToString());
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 2) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
	 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
	 		if (code[0].equals("B"))
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.BASIC_APP);
	 		else
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.NORMAL_APP);
	 		if (code[1].equals("BW"))
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.BLACK_AND_WHITE);
	 		else
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.COLORED);
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
 		config.setChartProperties(ChartConstants.SEQUENCE,properties);
 	}
	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem)appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		// reset widgets
		params.setEnabled(true);
		advancedButton.setEnabled(true);
		addButton.setEnabled(true);
		defineButton.setEnabled(true);
		loadButton.setEnabled(true);

		Object setObject = params.getSelectedIndex() == -1 ? null : params.getSelectedItem();
		
		DefaultComboBoxModel paramsModel = new DefaultComboBoxModel(getSets());
		params.setModel(paramsModel);
		
		if (setObject != null && findInComboBox(paramsModel,(IDataSourceProducer)setObject) != -1)  {
			int idx = findInComboBox(paramsModel,(IDataSourceProducer)setObject);
			params.setSelectedIndex(idx >= 0 ? idx : 0);
		} 
		
		List<IDataSourceProducer> newSets = new ArrayList<IDataSourceProducer>();
		for (IDataSourceProducer prod : sets) {
			int idx = findInComboBox(paramsModel,prod);
			if (idx != -1) 
				newSets.add((IDataSourceProducer)paramsModel.getElementAt(idx));
		}
		sets = newSets;
		lmodel.clear();
		for (IDataSourceProducer prod : newSets) 
			lmodel.addElement(prod.toString());
		downButton.setEnabled(sets.size() >= 2);
		upButton.setEnabled(sets.size() >= 2);
		removeButton.setEnabled(sets.size() != 0);
		
		validate();
		setWidgetDisabled();
		
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}
	
	//-----------------------------------------------------------------------------
	/** Returns the id of the selected renderer type.
	 * @return id of the selected renderer type (a string)
	 */
	private Comparable getRendererType() {
		return ((ComboboxItem)rendererComboBox.getSelectedItem()).getID();
	}
	
	//-----------------------------------------------------------------------------
	/** Creates and returns the string description of the selected renderer.
	 * @return string description of the the selected renderer
	 */
	@SuppressWarnings("unchecked")
	private String rendererToString() {
		String str = null;
		if (getRendererType().equals("DEFAULT")) {
			String ec_str = String.format("#%06x",elementColor.getRGB() & 0xffffff);
			String cc_str = String.format("#%06x",contourColor.getRGB() & 0xffffff);
			str = "DEFAULT," + ec_str + "," + cc_str;
		} else if (getRendererType().equals("CUSTOM")) {
			boolean valid = true;
			if (elementRendererClass == null) valid = false;
			if (valid && elementRendererSettings == null) {
				try {
					elementRendererClass.getConstructor(new Class[] {});
				} catch (NoSuchMethodException e) {
					valid = false;
				}
			}
			if (valid) {
				str = "CUSTOM," + elementRendererClass.getName() + ",";
				if (elementRendererSettings == null) return str.substring(0,str.length()-1);
				for (Entry<Object,Object> e : elementRendererSettings.entrySet()) {
					str += e.getKey().toString() + ":" + e.getValue().toString() + ",";
				}
				str = str.substring(0,str.length()-1);
			} else {
				String ec_str = String.format("#%06x",elementColor.getRGB() & 0xffffff);
				String cc_str = String.format("#%06x",contourColor.getRGB() & 0xffffff);
				str = "DEFAULT," + ec_str + "," + cc_str;
			}
		} else if (getRendererType().equals("DEFINED")) {
			String temp = null;
			temp = "DEFINED," + String.format("#%06x",userDefRenderer.getDefaultColor().getRGB() & 0xffffff) + ","; // default color first
			List<Triplet<Interval,String,Color>> map = userDefRenderer.getMap();
			for (Triplet<Interval,String,Color> t : map) {
				temp += t.getKey().toString() + ";";
				temp += (t.getSecond() == null ? "_" : t.getSecond()) + "?";
				String color = t.getThird() == null ? "_" : String.format("#%06x",t.getThird().getRGB() & 0xffffff);
				temp += color + ","; 
			}
			str = temp.substring(0,temp.length()-1);
		}
		return str;
	}
	
	//-----------------------------------------------------------------------------
	/** Sets the element renderer from the string <code>settings</code>.
	 * @param settings string description of an element renderer
	 */
	private void rendererFromString(String settings) {
		String[] strings = settings.split(",");
		if (strings[0].equals("DEFAULT")) {
			elementColor = new Color(Integer.decode(strings[1]));
			elementColorButton.setText(Utilities.colorText(elementColor,5));
			contourColor = new Color(Integer.decode(strings[2]));
			contourColorButton.setText(Utilities.colorText(contourColor,5));
		} else if (strings[0].equals("CUSTOM")) {
			try {
				elementRendererClass = Class.forName(strings[1]);
			} catch (ClassNotFoundException e) {
				// wrong custom element renderer => use default renderer
				elementColor = Color.BLUE;
				elementColorButton.setText(Utilities.colorText(elementColor,5));
				contourColor = Color.BLACK;
				contourColorButton.setText(Utilities.colorText(contourColor,5));
				return;
			}
			Properties temp = new Properties();
			for (int i=2;i<strings.length;++i) {
				String[] pair = strings[i].split(":");
				temp.setProperty(pair[0],pair[1]);
			}
			if (!temp.isEmpty()) elementRendererSettings = temp;
			rendererComboBox.setSelectedIndex(2);
			CardLayout cl = (CardLayout)rendererParamPanel.getLayout();
			cl.show(rendererParamPanel,"CUSTOM");
			rendererClassField.setText(elementRendererClass.getName());
			settingsButton.setEnabled(true);
		} else if (strings[0].equals("DEFINED")) {
			rendererComboBox.setSelectedIndex(1);
			CardLayout cl = (CardLayout)rendererParamPanel.getLayout();
			cl.show(rendererParamPanel,"DEFINED");
			userDefRenderer.setDefaultColor(new Color(Integer.decode(strings[1])));
			for (int i=2;i<strings.length;++i) {
				String[] pair = strings[i].split(";");
				Interval intv = new Interval(pair[0]);
				String[] parts = pair[1].split("\\?");
				String figure = parts[0].equals("_") ? null : parts[0];
				Color color = parts[1].equals("_") ? null : new Color(Integer.decode(parts[1]));
				userDefRenderer.addEntry(intv,figure,color);
			}
		}
	}
	
	//----------------------------------------------------------------------------
	/** Returns whether the item <code>item</code> contained by <code>list</code> or
	 *  not. Returns a valid index if number value of <code>item</code> equals to number
	 *  value of any element of the list otherwise returns -1.
	 * @param item the element 
	 * @param list the list where the method searches
	 */
	private int indexOfElement(NumberStrPair item, List<Object[]> list) {
		for (int i=0;i<list.size();++i) {
			if (item.getNumber().equals(((Interval)list.get(i)[0]).getLower()) &&
				item.getNumber().equals(((Interval)list.get(i)[0]).getUpper())) {
					return i;
				}
			}
			return -1;
	}
	
	//----------------------------------------------------------------------------
	/** Returns whether the item <code>item</code> containd by <code>list</code> or
	 *  not. Returns true if number value of <code>item</code> equals to number
	 *  value of any element of the list.
	 * @param item the element 
	 * @param list the list where the method searches
	 */
	@SuppressWarnings("cast")
	private boolean isElement(NumberStrPair item, List<NumberStrPair> list) {
		for (int i=0;i<list.size();++i) {
			if (item.getNumber().equals(((NumberStrPair)list.get(i)).getNumber())) {
				return true;
			}
		}
		return false;
	}
	
	//----------------------------------------------------------------------------
	/** Sets the initial elements of the table. */
	@SuppressWarnings("unchecked")
	private void setTableElements() {
		
		final List<Object[]> init = new ArrayList<Object[]>();

		List<Triplet<Interval,String,Color>> map = userDefRenderer.getMap();

		if (!map.isEmpty()) {
			for (Triplet<Interval,String,Color> t : map) 
				init.add(new Object[] {t.getFirst(), t.getFirst().toString(), t.getSecond(), t.getThird() });
		}
		
		try {
			// Begins a long operation
			final List<NumberStrPair> res = (List<NumberStrPair>)ChartConfigCollection.
			getLOPExecutor().execute("Initializing elements",new Callable<Object>() {
				public Object call() throws Exception {
					List<IDataSourceProducer> done = new ArrayList<IDataSourceProducer>();
					List<NumberStrPair> res = new ArrayList<NumberStrPair>();
					for (IDataSourceProducer dsp : sets) {
						if (done.contains(dsp)) continue;
						List<NumberStrPair> l = dsp.getElements();
						if (l != null) {
							for (NumberStrPair p : l) {
								ChartConfigCollection.getLOPExecutor().checkUserBreak();
								if (isElement(p,res)) continue;
								res.add(p);
							}
						}
						done.add(dsp);							
					}
					return res;
				}
			});
			ChartConfigCollection.getLOPExecutor().execute("Initializing table",new Callable<Object>() {
				public Object call() throws Exception {
					for (NumberStrPair p : res) {
						ChartConfigCollection.getLOPExecutor().checkUserBreak();
						int index = -1;
						if ((index = indexOfElement(p,init)) != -1) 
							init.get(index)[1] = p.toString();
						else
							init.add(new Object[] { new Interval(p.getNumber().doubleValue()), p.toString(), null, null});
					}
					tmodel = new ElementRendererTableModel(init,userDefRenderer);
					getTable().setModel(tmodel);
					return null;
				}
			});
		} catch (UserBreakException e) {
			try {
				tmodel = new ElementRendererTableModel(init,userDefRenderer);
				getTable().setModel(tmodel);
			} catch (UserBreakException e1) {}

		} catch (Throwable t) {
			ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
		}
		enableDisableButtons();
	}
	
	//----------------------------------------------------------------------------
	private void buildUserDefinedRenderer() {
		if (userDefRenderer == null) 
			userDefRenderer = new UserDefinedFigureRenderer();
		for (int i = 0; i < tmodel.getRowCount() - 1;++i) {
			Object[] row = tmodel.getRow(i);
			String color_str = (String)row[3];
			if (i == 0) {
				Color color = Utilities.toColor(color_str,Color.white);
				userDefRenderer.setDefaultColor(color);
			} else {
				Color color = Utilities.toColor(color_str,userDefRenderer.getDefaultColor());
				Interval intv = (Interval)row[0];
				String figure = null;
				if (row[2] != null) {
					figure = ((ImageIcon)row[2]).getDescription();
				}
				userDefRenderer.addEntry(intv,figure,color);
			}
		}
	}
	
	//----------------------------------------------------------------------------
	/** Adds a figure or icon specified by <code>figure</code> to the table.
	 * @param figure String id of a figure or path of an image
	 */
	private void addFigure(String figure) {
		int[] indices = getTable().getSelectedRows();
		if (indices.length == 0) return;
		for (int i=0;i<indices.length;++i) {
			if (indices[i]==0 || indices[i]==tmodel.getRowCount()-1) continue;
			else {
				if (figure.equals(UserDefinedFigureRenderer.DEFAULT)) 
					tmodel.setValueAt(null,indices[i],2);
				else
					tmodel.setValueAt(getImageIcon(figure),indices[i],2);
			}

		}
	}
	
	//----------------------------------------------------------------------------
	/** Returns an icon specified by <code>figure</code>. If any problems occure,
	 *  it returns the default icon of the element renderer.
	 * @param figure String id of a figure or path of an image
	 * @return an icon
	 * @see ai.aitia.chart.view.ui.UserDefinedFigureRenderer UserDefinedFigureRenderer
	 */
	private ImageIcon getImageIcon(String figure) {
		if (figure == null || figure.equals("")) return null;
		if (figure.equals(UserDefinedFigureRenderer.CIRCLE) ||
			figure.equals(UserDefinedFigureRenderer.RECTANGLE) ||
			figure.equals(UserDefinedFigureRenderer.TRIANGLE)) {
			return Utilities.getIcon(figure);
		} 
		ImageIcon icon = new ImageIcon(figure);
		if (icon != null && icon.getIconWidth() != -1) {
			Image img = icon.getImage();
			img = img.getScaledInstance(16,16,Image.SCALE_FAST);
			return new ImageIcon(img,figure);
		}
		else return userDefRenderer.getDefaultIcon();
	}
	
	//----------------------------------------------------------------------------
	/** Opens a file dialog to select an icon. Then adds the selected icon to the
	 *  table. It uses {@link #addFigure(String) addFigure()}.
	 */ 
	private void openFileDialog() {
		// get the file name
		JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
		fc.setAcceptAllFileFilterUsed(false);
		fc.addChoosableFileFilter(new ImageFileFilter());
		int result = fc.showOpenDialog(getAssignDialog());
		if (result == JFileChooser.APPROVE_OPTION) {
			File file = fc.getSelectedFile();
			GlobalHandlers.setLastDirectory(file);
			String filename = file.getPath();
			if (!iconCache.contains(filename)) {
				iconCache.add(filename);
				if (iconCache.size()>10) iconCache.remove(0);
			}
			addFigure(filename);
		}
	}
	//------------------------------------------------------------------------------
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}

	//-------------------------------------------------------------------------------
	/** This method haldles all released mouse events of the panel. It is public 
	 *  because of implementation side effect. Do not call or override.
	 * @param e event
	 */
	public void mouseReleased(MouseEvent e) {
		if (!SwingUtilities.isRightMouseButton(e))
			return;
		if (e.getComponent().isEnabled()) {
			downAction.setEnabled(setList.getModel().getSize() > 1);
			upAction.setEnabled(setList.getModel().getSize() > 1);
			removeAction.setEnabled(setList.getModel().getSize() != 0);
			if (setList.getModel().getSize() > 1) {
				downAction.putValue("X",e.getX());
				downAction.putValue("Y",e.getY());
				upAction.putValue("X",e.getX());
				upAction.putValue("Y",e.getY());
			}
			if (setList.getModel().getSize() != 0) {
				removeAction.putValue("X",e.getX());
				removeAction.putValue("Y",e.getY());
			}
			setsContextMenu.show(e.getComponent(),e.getX(),e.getY());
		}
	}

 	//-------------------------------------------------------------------------------
 	/** This method handles all ActionEvent-s of the panel. It is public because of
 	 *  implementation side effect. Do not call or override.
 	 * @param event event
 	 */
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if (cmd.equals("DOWN")) {
			move(1);
		} else if (cmd.equals("UP")) {
			move(-1);
		} else if (cmd.equals("REMOVE")) {
			int[] selected = setList.getSelectedIndices();
			while (selected.length != 0) {
				sets.remove(selected[0]);
				lmodel.remove(selected[0]);
				selected = setList.getSelectedIndices();
			}
			// disable the buttons (if need)
			if (sets.size() < 2) {
				downButton.setEnabled(false);
				upButton.setEnabled(false);
			}
			if (sets.size() == 0) {
				removeButton.setEnabled(false);
				displayButton.setEnabled(false);
				ChartDialogChangeCenter.fireSaveDisabled(this);
				defineButton.setEnabled(false);
				loadButton.setEnabled(false);
			}
		} else if ("T_DOWN".equals(cmd)) 
			moveRow(1);
		else if ("T_UP".equals(cmd)) 
			moveRow(-1);
		else if ("T_REMOVE".equals(cmd)) {
			table.getSelectionModel().removeSelectionInterval(0,0);
			table.getSelectionModel().removeSelectionInterval(tmodel.getRowCount()-1,tmodel.getRowCount()-1);
			int[] selected = table.getSelectedRows();
			if (selected.length == 0) return;
			String msg[] = new String[2];
			if (selected.length == 1) 
				msg[0] = String.format("The following entry will be deleted: %s", tmodel.getRow(selected[0])[1].toString());
			else 
				msg[0] = String.format("The selected entries (%d) will be deleted.",selected.length);
			msg[1] = "Are you sure?";
			boolean ok = JOptionPane.showConfirmDialog(getAssignDialog(), msg, "Warning", 
													   JOptionPane.YES_NO_OPTION,
													   JOptionPane.WARNING_MESSAGE
													   ) == JOptionPane.YES_OPTION;
			if (ok) {
				while (selected.length != 0) {
					tmodel.removeRow(selected[0]);
					selected = table.getSelectedRows();
				}
				enableDisableButtons();
			}
		} else if ("T_DEFAULT".equals(cmd)) {
			int[] indices = table.getSelectedRows();
			if (indices.length != 0) {
				for (int i=0;i<indices.length;++i) {
					if (indices[i]==0 || indices[i] == tmodel.getRowCount()-1) continue;
					else tmodel.setValueAt(null,indices[i],3);
				}
			}
		}

	}
	
	//-----------------------------------------------------------------------------
	/** Moves the selected elements in the selected sets list.
	 * @param offset the direction of the move (possible values: -1,1)
	 */
	private void move(int offset) {
		int[] selected = setList.getSelectedIndices();
		
		List<int[]> intervals = new ArrayList<int[]>();
		int start = selected[0], end = -1, previous = selected[0] - 1;

		for (int i=0;i<selected.length;++i) {
				if (selected[i] == previous + 1) previous = selected[i];
				else {
					end = previous;
					int[] intv = { start, end };
					intervals.add(intv);
					end = -1;
					start = previous = selected[i];
				}
		}
		intervals.add(new int[] { start, selected[selected.length-1] });
		
		setList.clearSelection();
		for (int[] intv : intervals) {
			int to = intv[0] + offset;
			if (0 <= intv[0] && 0 <= to && intv[1] + offset < lmodel.size()) {
				moveInterval(intv[0],intv[1],to);
				setList.getSelectionModel().addSelectionInterval(intv[0] + offset,intv[1] + offset);
			} else 
				setList.getSelectionModel().addSelectionInterval(intv[0],intv[1]);
		}
	}
	
	//-------------------------------------------------------------------------------
	/** Moves the elements in the selected sets list. The indices of the moved
	 *  elements are in the interval [<code>start</code>,<code>end</code>]. 
	 * @param to the new index of the first element
	 */
	private void moveInterval(int start, int end, int to) {
		int temp = to;
		String[] path = new String[end - start + 1];
		IDataSourceProducer[] dsps = new IDataSourceProducer[end - start + 1];
		for (int i = start;i <= end; ++i) {
			path[i - start] = (String)lmodel.get(i);
			dsps[i - start] = sets.get(i);
		}
		lmodel.removeRange(start,end);
		sets.removeAll(Arrays.asList(dsps));
		for (int i = 0;i < path.length;++i) {
			lmodel.add(temp,path[i]);
			sets.add(temp++,dsps[i]);
		}
	}
	
	//-------------------------------------------------------------------------------
	private void moveRow(int offset) {
		table.getSelectionModel().removeSelectionInterval(0,0);
		table.getSelectionModel().removeSelectionInterval(tmodel.getRowCount()-1,tmodel.getRowCount()-1);
		int[] selected = table.getSelectedRows();
		
		List<int[]> intervals = new ArrayList<int[]>();
		int start = selected[0], end = -1, previous = selected[0] - 1;

		for (int i=0;i<selected.length;++i) {
				if (selected[i] == previous + 1) previous = selected[i];
				else {
					end = previous;
					int[] intv = { start, end };
					intervals.add(intv);
					end = -1;
					start = previous = selected[i];
				}
		}
		intervals.add(new int[] { start, selected[selected.length-1] });
		
		table.getSelectionModel().clearSelection();
		for (int[] intv : intervals) {
			int to = intv[0] + offset;
			if (1 <= intv[0] && 1 <= to && intv[1] + offset < table.getRowCount() - 1) {
				tmodel.moveRow(intv[0],intv[1],to);
				table.getSelectionModel().addSelectionInterval(intv[0] + offset,intv[1] + offset);
			} else 
				table.getSelectionModel().addSelectionInterval(intv[0],intv[1]);
		}
	}

	//-------------------------------------------------------------------------------
	private void enableDisableButtons() {
		tMoveUpButton.setEnabled(tmodel.getRowCount() > 3);
		tMoveDownButton.setEnabled(tmodel.getRowCount() > 3);
		tRemoveButton.setEnabled(tmodel.getRowCount() > 2);
	}
}