package ai.aitia.chart.networkpanel;

import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.visualization.contrib.CircleLayout;

public class DefinedCircleLayout extends CircleLayout {

	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public DefinedCircleLayout(Graph g) {
		super(g);
	}

	@Override
	public void orderVertices(Vertex[] vertices) {}
}