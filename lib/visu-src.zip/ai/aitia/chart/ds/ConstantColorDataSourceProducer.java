package ai.aitia.chart.ds;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import javax.swing.Icon;

import org.w3c.dom.Node;

import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.util.ConstantList;
import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.ds.IDataProducer;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.event.IDataChangeListener;

public class ConstantColorDataSourceProducer implements IDataSourceProducer {

	//====================================================================================================
	// members
	
	private final double CONSTANT_VALUE = 42.;
	private final Color color;
	
	private Icon icon = null;
	private ISeriesProducer producer = null;

	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public ConstantColorDataSourceProducer(final Color color) {
		if (color == null)
			throw new IllegalArgumentException("'color' is null.");
		this.color = color;
	}
	
	//----------------------------------------------------------------------------------------------------
	public Color getColor() { return color; }
	
	//----------------------------------------------------------------------------------------------------
	@Override public boolean equals(final Object o) {
		if (o instanceof ConstantColorDataSourceProducer) {
			ConstantColorDataSourceProducer that = (ConstantColorDataSourceProducer) o;
			return this.color.equals(that.color);
		}
		return false;
	}
	
	//----------------------------------------------------------------------------------------------------
	@Override public int hashCode() { return color.hashCode(); }

	//====================================================================================================
	// implemented interfaces

	//----------------------------------------------------------------------------------------------------
	@Override public String toString() { return "Constant color"; }
	public List<Class> getSupportedIntfs() { return Arrays.asList(new Class[] { ISeriesProducer.class }); }
	public List<Class> getDisabledIntfs() {	return new ArrayList<Class>(0); }
	public boolean hasAdvancedSettings() { return false; }
	public IDataSourceProducer advancedSettingsDialog(final Component parent) { return null; }
	public List<NumberStrPair> getElements() { return null; }
	public List<Double> getRange() { return null; }

	//----------------------------------------------------------------------------------------------------
	public IDataProducer createDataProducer(final Class intf, final IDataSourceProducer _) {
		if (ISeriesProducer.class.equals(intf)) {
			if (producer == null) {
				producer = new ISeriesProducer() {
					private long time;

					//----------------------------------------------------------------------------------------------------
					public List<Double> produceSeries() {
						time = System.currentTimeMillis();
						return new ConstantList<Double>(CONSTANT_VALUE);
					}

					//----------------------------------------------------------------------------------------------------
					public void addDataChangeListener(IDataChangeListener listener) {
						// it never changes because it's constant
					}

					public void removeDataChangeListener(IDataChangeListener listener) {
						// it never changes because it's constant
					}
					
					//----------------------------------------------------------------------------------------------------
					public String getName() { return "Constant color: " + String.format("#%06x",color.getRGB() & 0xffffff); }
					public long getTime() { return time; }
				};
			}
			return producer;
		}
		return null;
	}

	//----------------------------------------------------------------------------------------------------
	public Icon getDisplayableIcon() {
		if (icon == null) {
			 new Icon() {
				//----------------------------------------------------------------------------------------------------
				public int getIconHeight() { return 16; }
				public int getIconWidth() { return 16; }
				public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
				    final Color oldColor = g.getColor();
				    g.setColor(color);
				    g.fillRect(x,y,getIconWidth(),getIconHeight());
				    g.setColor(oldColor);
				}
			 };
		}
		return icon;
	}

	//----------------------------------------------------------------------------------------------------
	public void save(final Node node) {
		final Properties prop = new Properties();
		prop.setProperty("CONSTANT_COLOR_PRODUCER",String.valueOf(true));
		prop.setProperty("COLOR",String.format("#%06x",color.getRGB() & 0xffffff));
		Utilities.writeProperties(node,prop);
	}
}