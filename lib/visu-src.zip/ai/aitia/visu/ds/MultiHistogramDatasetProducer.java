package ai.aitia.visu.ds;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.jfree.data.general.Dataset;

import ai.aitia.visu.data.MultiHistogramDataset;
import ai.aitia.visu.event.DataChangeEvent;
import ai.aitia.visu.event.IDataChangeListener;

public class MultiHistogramDatasetProducer implements IDataChangeListener,
														 IDatasetProducer {

	private MultiHistogramDataset dataset = null;

	@SuppressWarnings("unused")
	private HashMap<Comparable,IDataProducer> sources;
	
	private int bins = 1;
	private IValueProducer binProducer = null;
	
	private double minValue = - Double.MAX_VALUE;
	private IValueProducer minValueProducer = null;
	
	private double maxValue = Double.MAX_VALUE;
	private IValueProducer maxValueProducer = null;
	private ArrayList sourceNames;
	
	private long time;
	boolean first = true;
	
	
	/** Constructor.
	 * 
	 *  The content of the list parameter must be the follow:<br>
	 *    - a value or series producer for the data of the histogram<br>
	 *    - an Integer value or a value producer for the number of bins<br>
	 *    - a Double value or a value producer for the min value of the histogram.
	 *      - Double.MAX_VALUE indicates this information is unknown<br>
	 *    - a Double value or a value producer for the max value of the histogram.
	 *      Double.MAX_VALUE indicates this information is unknown.<p>
	 */
	public MultiHistogramDatasetProducer(int type, int strategy, List<Object> data) throws DataSourceException {
		if (data.size() < 4)
			throw new DataSourceException("Missing input parameters.");
		
		dataset = new MultiHistogramDataset(type,strategy);
		sources = new HashMap<Comparable, IDataProducer>();
		
		if(data.get(0) instanceof ArrayList){
			ArrayList s= (ArrayList) data.get(0);
			sourceNames=s;
			ArrayList <Comparable> keys= new ArrayList<Comparable>();
			for(int i=0; i<s.size(); i++){
				IDataProducer ivp = (IDataProducer)s.get(i);
				//ISeriesProducer ivp = (ISeriesProducer)s.get(i);
				ivp.addDataChangeListener(this);
				keys.add(ivp.getName());
				
				
			}
			dataset.setKeyList(keys);
			 
		}else 
			throw new DataSourceException("Invalid histogram data.");
		if (data.get(1) instanceof Integer) {
			bins = (Integer) data.get(1);
			if (bins <= 0)
				throw new DataSourceException("Invalid value: number of bins.");
		} else if (data.get(1) instanceof IValueProducer) {
			binProducer = (IValueProducer) data.get(1);
			binProducer.addDataChangeListener(this);
		} else
			throw new DataSourceException("Invalid number of bins parameter.");
		if (data.get(2) instanceof Double)
			minValue = (Double) data.get(2);
		else if (data.get(2) instanceof IValueProducer) {
			minValueProducer = (IValueProducer) data.get(2);
			minValueProducer.addDataChangeListener(this);
		} else 
			throw new DataSourceException("Invalid minimum value parameter.");
		if (data.get(3) instanceof Double) 
			maxValue = (Double) data.get(3);
		else if (data.get(3) instanceof IValueProducer) {
			maxValueProducer = (IValueProducer) data.get(3);
			maxValueProducer.addDataChangeListener(this);
		} else
			throw new DataSourceException("Invalid maximum value parameter.");
		
	}
		
	public void dataChanged(DataChangeEvent event) {
		
		Object source = event.getSource();
		if (source.equals(binProducer)) {
			int tempBins = Math.max(1,(int)binProducer.produceValue());
			
			if (tempBins != bins) {
				bins = tempBins;
				time = binProducer.getTime();
				first = true;
			}
		} else if (source.equals(minValueProducer)) {
			double tempMinValue = minValueProducer.produceValue();
			if (tempMinValue != minValue) {
				minValue = tempMinValue;
				time = minValueProducer.getTime();
				first = true;
			}
		} else if (source.equals(maxValueProducer)) {
			double tempMaxValue = maxValueProducer.produceValue();
			if (tempMaxValue != maxValue) {
				maxValue = tempMaxValue;
				time = maxValueProducer.getTime();
				first = true;
			}
		} else if (source instanceof IDataProducer) {
			
			@SuppressWarnings("unused")
			String name = ((IDataProducer)source).getName();
			
			if (first) {
				if (minValue > maxValue) {
					double temp = minValue;
					minValue = maxValue;
					maxValue = temp;
				}
				
				
				
				for(int i=0; i<sourceNames.size(); i++){
					ISeriesProducer ivp = (ISeriesProducer)sourceNames.get(i);
					
					ivp.addDataChangeListener(this);
					dataset.addSeries(ivp.getName(), new ArrayList<Double>(0), bins, minValue, maxValue);
				}
					first = false;	
			}
			if (source instanceof ISeriesProducer) {
				ISeriesProducer p = (ISeriesProducer) source;
				
				dataset.replaceValues(p.getName(), p.produceSeries());
				@SuppressWarnings("unused")
				ArrayList<Double> l=new ArrayList<Double>();
				time = p.getTime();
			}
		}
	}

	public Dataset produceDataset(Properties queryProperties) throws DataSourceException {
		return dataset;
	}

	public long getTime() {
		return time;
	}
}
