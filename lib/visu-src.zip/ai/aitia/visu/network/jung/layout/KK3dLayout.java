/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.network.jung.layout;

import java.awt.Dimension;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.Iterator;

import cern.jet.random.engine.DRand;
import cern.jet.random.engine.RandomEngine;

import edu.uci.ics.jung.algorithms.shortestpath.Distance;
import edu.uci.ics.jung.algorithms.shortestpath.UnweightedShortestPath;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.statistics.GraphStatistics;
import edu.uci.ics.jung.visualization.AbstractLayout;
import edu.uci.ics.jung.visualization.Coordinates;

/**
 * Implements the Kamada-Kawai algorithm for node layout.
 * Does not respect filter calls, and sometimes crashes when the view changes to it.
 *
 * @see "Tomihisa Kamada and Satoru Kawai: An algorithm for drawing general indirect graphs. Information Processing Letters 31(1):7-15, 1989" 
 * @see "Tomihisa Kamada: On visualization of abstract objects and relations. Ph.D. dissertation, Dept. of Information Science, Univ. of Tokyo, Dec. 1988."
 *
 * @author Masanori Harada
 */
public class KK3dLayout extends AbstractLayout {

	private double EPSILON = 0.1d;

	private int currentIteration;
    private int maxIterations = 2000;
	private String status = "KKLayout";

	private double L;			// the ideal length of an edge
	private double K = 1;		// arbitrary const number
	private double[][] dm;     // distance matrix

	private boolean adjustForGravity = true;
	private boolean exchangeVertices = true;

	private Vertex[] vertices;
	private Coordinates3d[] xyzdata;

    /**
     * Retrieves graph distances between vertices of the visible graph
     */
    protected Distance distance;

    /**
     * The diameter of the visible graph. In other words, the maximum over all pairs
     * of vertices of the length of the shortest path between a and bf the visible graph.
     */
	protected double diameter;

    /**
     * A multiplicative factor which partly specifies the "preferred" length of an edge (L).
     */
    private double length_factor = 0.9;

    /**
     * A multiplicative factor which specifies the fraction of the graph's diameter to be 
     * used as the inter-vertex distance between disconnected vertices.
     */
    private double disconnected_multiplier = 0.5;
    
    RandomEngine rand;
    
	public KK3dLayout(Graph g) 
    {
        this(g, new UnweightedShortestPath(g));
	}

    public KK3dLayout(Graph g, Distance distance)
    {
        super(g);
        this.rand = new DRand((int)(new Date().getTime()));
        this.distance = distance;
    }

    /**
     * Sets a multiplicative factor which 
     * partly specifies the "preferred" length of an edge (L).
     */
    public void setLengthFactor(double length_factor)
    {
        this.length_factor = length_factor;
    }
    
    /**
     * Sets a multiplicative factor that specifies the fraction of the graph's diameter to be 
     * used as the inter-vertex distance between disconnected vertices.
     */
    public void setDisconnectedDistanceMultiplier(double disconnected_multiplier)
    {
        this.disconnected_multiplier = disconnected_multiplier;
    }
    
	public String getStatus() {
		return status + this.getCurrentSize();
	}

    public void setMaxIterations(int maxIterations) {
        this.maxIterations = maxIterations;
    }

	/**
	 * This one is an incremental visualization.
	 */
	public boolean isIncremental() {
		return true;
	}

	/**
	 * Returns true once the current iteration has passed the maximum count.
	 */
	public boolean incrementsAreDone() {
		if (currentIteration > maxIterations) {
			return true;
		}
		return false;
	}

    protected void initialize_local() {
        currentIteration = 0;
	}

    protected void initializeLocations() {
		super.initializeLocations();

		Dimension d = getCurrentSize();
		double height = d.getHeight();
		double width = d.getWidth();

        int n = getGraph().getVertices().size();
        dm = new double[n][n];
		vertices = new Vertex[n];
		xyzdata = new Coordinates3d[n];

		// assign IDs to all visible vertices
		while(true) {
		    try {
		        int index = 0;
		        for (Iterator iter = getGraph().getVertices().iterator();
		        iter.hasNext(); ) {
		            Vertex v = (Vertex) iter.next();
		            Coordinates xyd = getCoordinates(v);
		            vertices[index] = v;
		            
		            xyzdata[index] = new Coordinates3d(xyd, rand.nextDouble() * width);
		            
		            index++;
		        }
		        break;
		    } catch(ConcurrentModificationException cme) {}
		}

        diameter = GraphStatistics.diameter(getGraph(), distance, true);
            
        double L0 = Math.min(height, width);
        L = (L0 / diameter) * length_factor;  // length_factor used to be hardcoded to 0.9
		//L = 0.75 * Math.sqrt(height * width / n);

		for (int i = 0; i < n - 1; i++) 
        {
			for (int j = i + 1; j < n; j++) 
            {
                Number d_ij = distance.getDistance(vertices[i], vertices[j]);
                Number d_ji = distance.getDistance(vertices[j], vertices[i]);
                double dist = diameter * disconnected_multiplier;
                if (d_ij != null)
                   dist = Math.min(d_ij.doubleValue(), dist);
                if (d_ji != null)
                    dist = Math.min(d_ji.doubleValue(), dist);
                dm[i][j] = dm[j][i] = dist;
			}
		}
	}

	protected void initialize_local_vertex(Vertex v) {
	}

    @SuppressWarnings("deprecation")
	public void advancePositions() {
		currentIteration++;
		double energy = calcEnergy();
		status = "Kamada-Kawai V=" + getVisibleVertices().size()
            + "(" + getGraph().numVertices() + ")"
			+ " IT: " + currentIteration
			+ " E=" + energy
			;

		int n = getVisibleGraph().numVertices();
        if (n == 0)
            return;

		double maxDeltaM = 0;
		int pm = -1;            // the node having max deltaM
		for (int i = 0; i < n; i++) {
            if (dontMove(vertices[i]))
                continue;
			double deltam = calcDeltaM(i);
			//System.out.println("* i=" + i + " deltaM=" + deltam);
			if (maxDeltaM < deltam) {
				maxDeltaM = deltam;
				pm = i;
			}
		}
		if (pm == -1)
            return;

        for (int i = 0; i < 100; i++) {
			double[] dxyz = calcDeltaXYZ(pm);
			xyzdata[pm].add(dxyz[0], dxyz[1], dxyz[2]);
			double deltam = calcDeltaM(pm);
            if (deltam < EPSILON)
                break;
            //if (dxy[0] > 1 || dxy[1] > 1 || dxy[0] < -1 || dxy[1] < -1)
            //    break;
		}

		if (adjustForGravity)
			adjustForGravity();

		if (exchangeVertices && maxDeltaM < EPSILON) {
            energy = calcEnergy();
			for (int i = 0; i < n - 1; i++) {
                if (dontMove(vertices[i]))
                    continue;
				for (int j = i + 1; j < n; j++) {
                    if (dontMove(vertices[j]))
                        continue;
					double xenergy = calcEnergyIfExchanged(i, j);
					if (energy > xenergy) {
						
						double sx = xyzdata[i].getX();
						double sy = xyzdata[i].getY();
						double sz = xyzdata[i].getZ();
						
						xyzdata[i].setX(xyzdata[j].getX());
						xyzdata[i].setY(xyzdata[j].getY());
						xyzdata[i].setZ(xyzdata[j].getY());
						
						xyzdata[j].setX(sx);
						xyzdata[j].setY(sy);
						xyzdata[j].setZ(sz);
						
						//System.out.println("SWAP " + i + " with " + j +
						//				   " maxDeltaM=" + maxDeltaM);
						return;
					}
				}
			}
		}
	}

	/**
	 * Shift all vertices so that the center of gravity is located at
	 * the center of the screen.
	 */
	public void adjustForGravity() {
		Dimension d = getCurrentSize();
		double height = d.getHeight();
		double width = d.getWidth();
		double gx = 0;
		double gy = 0;
		double gz = 0;
		for (int i = 0; i < xyzdata.length; i++) {
			gx += xyzdata[i].getX();
			gy += xyzdata[i].getY();
			gz += xyzdata[i].getZ();
		}
		
		gx /= xyzdata.length;
		gy /= xyzdata.length;
		gz /= xyzdata.length;
		
		double diffx = width / 2 - gx;
		double diffy = height / 2 - gy;
		
		//TODO what to do with z coordinates?
		double diffz = width / 2 - gz;
		
		for (int i = 0; i < xyzdata.length; i++) {
			xyzdata[i].add(diffx, diffy, diffz);
		}
	}

	/**
	 * Enable or disable gravity point adjusting.
	 */
	public void setAdjustForGravity(boolean on) {
		adjustForGravity = on;
	}

	/**
	 * Returns true if gravity point adjusting is enabled.
	 */
	public boolean getAdjustForGravity() {
		return adjustForGravity;
	}

	/**
	 * Enable or disable the local minimum escape technique by
	 * exchanging vertices.
	 */
	public void setExchangeVertices(boolean on) {
		exchangeVertices = on;
	}

	/**
	 * Returns true if the local minimum escape technique by
	 * exchanging vertices is enabled.
	 */
	public boolean getExchangeVertices() {
		return exchangeVertices;
	}

	/**
	 * Determines a step to new position of the vertex m.
	 */
	private double[] calcDeltaXYZ(int m) {
		double dE_dxm = 0;
		double dE_dym = 0;
		double dE_dzm = 0;
		
		double d2E_d2xm = 0;
		double d2E_dxmdym = 0;
		double d2E_dymdxm = 0;
		double d2E_d2ym = 0;
		
		double d2E_dxmdzm = 0;
		double d2E_dymdzm = 0;
		double d2E_d2zm = 0;
		
		double d2E_dzmdxm = 0;
		double d2E_dzmdym = 0;

		for (int i = 0; i < vertices.length; i++) {
			if (i != m) {
                
                double dist = dm[m][i];
				double l_mi = L * dist;
				double k_mi = K / (dist * dist);
				
				double dx = xyzdata[m].getX() - xyzdata[i].getX();
				double dy = xyzdata[m].getY() - xyzdata[i].getY();
				double dz = xyzdata[m].getZ() - xyzdata[i].getZ();
				
				double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
				double ddd = d * d * d;

				dE_dxm += k_mi * (1 - l_mi / d) * dx;
				dE_dym += k_mi * (1 - l_mi / d) * dy;
				dE_dzm += k_mi * (1 - l_mi / d) * dz;
								
				d2E_d2xm += k_mi * (1 - l_mi * (dy * dy + dz * dz)  / ddd); //ok
				
				d2E_dxmdym += k_mi * l_mi * dx * dy / ddd; // ok
				
				d2E_d2ym += k_mi * (1 - l_mi * (dx * dx + dz * dz)  / ddd);	//ok
				
				d2E_d2zm += k_mi * (1 - l_mi * (dx * dx + dy * dy)  / ddd); //ok
				
				d2E_dxmdzm += k_mi * l_mi * dx * dz / ddd;
				
				d2E_dymdzm += k_mi *l_mi * dy * dz / ddd;
			}
		}
		// d2E_dymdxm equals to d2E_dxmdym.
		d2E_dymdxm = d2E_dxmdym;
		d2E_dzmdxm = d2E_dxmdzm;
		d2E_dzmdym = d2E_dymdzm;

		double denomi =   d2E_d2xm * d2E_d2ym * d2E_d2zm  
						- d2E_d2xm * d2E_dymdzm * d2E_dzmdym 
						- d2E_dxmdym * d2E_dymdxm * d2E_d2zm
						+ d2E_dxmdym * d2E_dymdzm * d2E_dzmdxm
						+ d2E_dxmdzm * d2E_dymdxm * d2E_dzmdym
						- d2E_dxmdzm * d2E_d2ym * d2E_dzmdxm;
		
		double xnomi =   dE_dxm * d2E_d2ym * d2E_d2zm  
		- dE_dxm * d2E_dymdzm * d2E_dzmdym 
		- d2E_dxmdym * dE_dym * d2E_d2zm
		+ d2E_dxmdym * d2E_dymdzm * dE_dzm
		+ d2E_dxmdzm * dE_dym * d2E_dzmdym
		- d2E_dxmdzm * d2E_d2ym * dE_dzm;
		
		double ynomi =   d2E_d2xm * dE_dym * d2E_d2zm  
		- d2E_d2xm * d2E_dymdzm * dE_dzm 
		- dE_dxm * d2E_dymdxm * d2E_d2zm
		+ dE_dxm * d2E_dymdzm * d2E_dzmdxm
		+ d2E_dxmdzm * d2E_dymdxm * dE_dzm
		- d2E_dxmdzm * dE_dym * d2E_dzmdxm;
		
		double znomi =   d2E_d2xm * d2E_d2ym * dE_dzm  
		- d2E_d2xm * dE_dym * d2E_dzmdym 
		- d2E_dxmdym * d2E_dymdxm * dE_dzm
		+ d2E_dxmdym * dE_dym * d2E_dzmdxm
		+ dE_dxm * d2E_dymdxm * d2E_dzmdym
		- dE_dxm * d2E_d2ym * d2E_dzmdxm;		
		
		
		double deltaX =  -xnomi / denomi;
		double deltaY =  -ynomi / denomi;
		double deltaZ =  -znomi / denomi;
		
		return new double[]{deltaX, deltaY, deltaZ};
	}

	/**
	 * Calculates the gradient of energy function at the vertex m.
	 */
	private double calcDeltaM(int m) {
		double dEdxm = 0;
		double dEdym = 0;
		double dEdzm = 0;
		for (int i = 0; i < vertices.length; i++) {
			if (i != m) {
                double dist = dm[m][i];
				double l_mi = L * dist;
				double k_mi = K / (dist * dist);

				double dx = xyzdata[m].getX() - xyzdata[i].getX();
				double dy = xyzdata[m].getY() - xyzdata[i].getY();
				double dz = xyzdata[m].getZ() - xyzdata[i].getZ();
				
				double d = Math.sqrt(dx * dx + dy * dy + dz * dz);

				double common = k_mi * (1 - l_mi / d);
				dEdxm += common * dx;
				dEdym += common * dy;
				dEdzm += common * dz;
			}
		}
		return Math.sqrt(dEdxm * dEdxm + dEdym * dEdym + dEdzm * dEdzm);
	}

	/**
	 * Calculates the energy function E.
	 */
	private double calcEnergy() {
		double energy = 0;
		for (int i = 0; i < vertices.length - 1; i++) {
			for (int j = i + 1; j < vertices.length; j++) {
                double dist = dm[i][j];
				double l_ij = L * dist;
				double k_ij = K / (dist * dist);
				
				double dx = xyzdata[i].getX() - xyzdata[j].getX();
				double dy = xyzdata[i].getY() - xyzdata[j].getY();
				double dz = xyzdata[i].getZ() - xyzdata[j].getZ();
				
				double d = Math.sqrt(dx * dx + dy * dy + dz * dz);


				energy += k_ij / 2 * (dx * dx + dy * dy + dz * dz + l_ij * l_ij -
									  2 * l_ij * d);
			}
		}
		return energy;
	}

	/**
	 * Calculates the energy function E as if positions of the
	 * specified vertices are exchanged.
	 */
	private double calcEnergyIfExchanged(int p, int q) {
		if (p >= q)
			throw new RuntimeException("p should be < q");
		double energy = 0;		// < 0
		for (int i = 0; i < vertices.length - 1; i++) {
			for (int j = i + 1; j < vertices.length; j++) {
				int ii = i;
				int jj = j;
				if (i == p) ii = q;
				if (j == q) jj = p;

                double dist = dm[i][j];
				double l_ij = L * dist;
				double k_ij = K / (dist * dist);
				double dx = xyzdata[ii].getX() - xyzdata[jj].getX();
				double dy = xyzdata[ii].getY() - xyzdata[jj].getY();
				double dz = xyzdata[ii].getZ() - xyzdata[jj].getZ();
				double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
				
				energy += k_ij / 2 * (dx * dx + dy * dy + dz * dz + l_ij * l_ij -
									  2 * l_ij * d);
			}
		}
		return energy;
	}
}
