package ai.aitia.visu.view.plot;

import org.jfree.chart.entity.ChartEntity;

import ai.aitia.visu.view.selection.ISelectionListener;
import ai.aitia.visu.view.selection.ISelectionModel;

public interface InteractivePlot {
	public void selectEntity(ChartEntity entity);
	public ISelectionModel getSelectionModel();
	public void fireSelectionChanged();
	public void addSelectionListener(ISelectionListener listener);
	public void removeSelectionListener(ISelectionListener listener);	
}
