/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.test;

import java.util.Properties;

import ai.aitia.chart.ds.IAdjacencyMatrixProducer;
import ai.aitia.chart.ds.IGrid2DDatasetProducer;
import ai.aitia.visu.data.DefaultGrid2DDataset;
import ai.aitia.visu.data.Grid2DDataset;
import ai.aitia.visu.ds.AbstractDataProducer;
import ai.aitia.visu.ds.DataSourceException;

/** A test implementation of the IGrid2DDatasetProducer interface. */
public class TestGrid2DDatasetProducer extends AbstractDataProducer implements
		IGrid2DDatasetProducer, IAdjacencyMatrixProducer {

	/** Name of the producer. */
	private String name;
	
	/** Time of the last update. */
	private long time;
	
	/** Values of the grid in row-major order. */
	private double[] data;
	
	/** Width of the grid. */
	private int width;
	
	//===============================================================================
	// methods
	
	/** Constructor.
	 * @param name name of the producer
	 * @param data values of the grid in row-major order.
	 * @param width width of the grid	
	 */
	public TestGrid2DDatasetProducer(String name, double[] data, int width) {
		this.name = name;
		this.time = System.currentTimeMillis();
		this.data = data;
		this.width = width;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the time of the last update. 
	 * @return time of the last update
	 */
	public long getTime() {
		return time;
	}

	//-------------------------------------------------------------------------------
	/** Produces the grid dataset. This implementation of the method does not use the
	 *  <code>queryProperties</code> parameter and does not throw exception.
	 */  
	public Grid2DDataset produceDataset(Properties queryProperties)
			throws DataSourceException {
		int height = data.length%width==0 ? data.length/width : data.length/width+1;
		double[][] ds = new double[width][height];
		for (int i=0;i<height;++i) {
			for (int j=0;j<width;++j) {
				ds[j][i] = (i*width+j<data.length ? data[i*width+j] : - Double.MAX_VALUE);
			}
		}
		return new DefaultGrid2DDataset(ds);
	}

	//-------------------------------------------------------------------------------
	/** Returns the name of the producer. 
	 * @return name of the producer
	 */
	public String getName() {
		return name;
	}
}