/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.view.ui;

import java.util.Hashtable;

import ai.aitia.visu.view.ui.DefaultFigureRenderer;
import ai.aitia.visu.view.ui.IFigureRenderer;

/** Figure renderer class for automatic shape renderers. */
public class AutomaticFigureRenderer extends DefaultFigureRenderer implements IFigureRenderer {

	//====================================================================================================
	// members
	
	/** Storage of value-figure pairs where figures are represented by integers. */ 
	private Hashtable<Double,Integer> map = null;
	
	/** The integer id of the next figure. */
	private int nextFigure = CIRCLE;
	
	//================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	/** Constructor. */
	public AutomaticFigureRenderer() {
		map = new Hashtable<Double,Integer>();
	}
	
	//-------------------------------------------------------------------------------
	/** Adds a new pair to the storage. 
	 * @param value value component
	 * @param figure integer id of the figure component
	 */
	@Override
	public void addFigure(double value, int figure) {
		map.put(value,figure);
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the integer id of the figure binded to the <code>value</code>. If isn't
	 *  bind any figure to the <code>value</code>, it binds the <code>nextFigure</code>
	 *  to the <code>value</code> and returns this id.
	 * @param value value
	 * @return id of the appropriate figure
	 */
	@Override
	protected int getFigure(double value) {
		Integer figure = map.get(new Double(value));
		if (figure != null) {
			return figure.intValue();
		} else {
			if (value == - Double.MAX_VALUE) return DEFAULT;
			addFigure(value, nextFigure);
			int result = nextFigure;
			nextFigure = (nextFigure==3 ? 1 : nextFigure+1);
			return result;
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	@Override public String getName() { return "Automatic renderer"; }
}