/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.awt.image.BufferedImage;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicPanelUI;

import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * UI for panels in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstancePanelUI extends BasicPanelUI {
	/**
	 * Background delegate.
	 */
	private SubstanceFillBackgroundDelegate bgDelegate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent b) {
		return new SubstancePanelUI();
	}

	/**
	 * Simple constructor.
	 */
	private SubstancePanelUI() {
		this.bgDelegate = new SubstanceFillBackgroundDelegate();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void update(Graphics g, JComponent c) {
		// if (!c.isShowing()) {
		// return;
		// }
		if (TransitionLayout.isOpaque(c)) {
			this.bgDelegate.update(g, c);
		}
		super.paint(g, c);
		for (int i = 0; i < c.getComponentCount(); i++) {
			Component child = c.getComponent(i);
			FadeTracker fadeTracker = FadeTracker.getInstance();
			if (fadeTracker.isTracked(child, null,
					FadeKind.GHOSTING_BUTTON_PRESS, true)) {
				Graphics2D graphics = (Graphics2D) g.create();
				float fade10 = fadeTracker.getFade10(child, null,
						FadeKind.GHOSTING_BUTTON_PRESS);
				// 0.0 --> 0.3
				// 10.0 --> 0.0
				float opFactor = 0.3f * (1.0f - fade10 / 10.0f);
				graphics.setComposite(TransitionLayout.getAlphaComposite(c,
						opFactor));

				Rectangle bounds = child.getBounds();

				double iFactor = 1.0 + fade10 / 10.0;
				double iWidth = bounds.width * iFactor;
				double iHeight = bounds.height * iFactor;
				BufferedImage iImage = SubstanceCoreUtilities.getBlankImage(
						(int) iWidth, (int) iHeight);
				Graphics2D iGraphics = (Graphics2D) iImage.createGraphics();
				iGraphics.scale(iFactor, iFactor);
				child.paint(iGraphics);
				iGraphics.dispose();
				int dx = (int) ((iWidth - bounds.width) / 2);
				int dy = (int) ((iHeight - bounds.height) / 2);
				graphics.drawImage(iImage, bounds.x - dx, bounds.y - dy, null);
				graphics.dispose();
			}

			if (fadeTracker.isTracked(child, null,
					FadeKind.GHOSTING_ICON_ROLLOVER, true)) {
				Graphics2D graphics = (Graphics2D) g.create();
				float fade10 = fadeTracker.getFade10(child, null,
						FadeKind.GHOSTING_ICON_ROLLOVER);
				// 0.0 --> 0.5
				// 10.0 --> 0.0
				float opFactor = 0.5f * (1.0f - fade10 / 10.0f);
				graphics.setComposite(TransitionLayout.getAlphaComposite(c,
						opFactor));

				Rectangle bounds = child.getBounds();
				Icon icon = null;
				Rectangle iconRect = null;
				if (child instanceof AbstractButton) {
					AbstractButton button = (AbstractButton) child;
					icon = SubstanceCoreUtilities.getIcon(button);
					iconRect = (Rectangle) button
							.getClientProperty(SubstanceButtonUI.ICON_RECT);
				}

				if ((icon != null) && (iconRect != null)) {
					double iFactor = 1.0 + fade10 / 10.0;
					double iWidth = icon.getIconWidth() * iFactor;
					double iHeight = icon.getIconHeight() * iFactor;
					BufferedImage iImage = SubstanceCoreUtilities
							.getBlankImage((int) iWidth, (int) iHeight);
					Graphics2D iGraphics = (Graphics2D) iImage.createGraphics();
					iGraphics.scale(iFactor, iFactor);
					icon.paintIcon(child, iGraphics, 0, 0);
					iGraphics.dispose();
					int dx = (int) ((iWidth - icon.getIconWidth()) / 2);
					int dy = (int) ((iHeight - icon.getIconHeight()) / 2);
					graphics.drawImage(iImage, bounds.x + iconRect.x - dx,
							bounds.y + iconRect.y - dy, null);
				}
				graphics.dispose();
			}
		}
	}
}
