/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart;

import java.awt.Container;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.lang.Thread.UncaughtExceptionHandler;
import java.net.URI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JFrame;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import ai.aitia.chart.charttypes.dialogs.AbstractChartDialog;
import ai.aitia.chart.dialogs.CCCollectionDialog;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.chart.util.XMLLoadingException;
import ai.aitia.visu.globalhandlers.GlobalHandlers;
import ai.aitia.visu.globalhandlers.ILOPExecutor;
import ai.aitia.visu.view.CustomSaveableChartPanel;

/** Collection of chart configuration objects. */
public class ChartConfigCollection implements Iterable<ChartConfig> {
	
	/** Global initial color appearance. */
	private static String colorAppearance = ChartConstants.COLORED;
	
	/** Global intial environment appearance. */
	private static String environmentAppearance = ChartConstants.BASIC_APP;
	
	//===============================================================================
	// members
	
	/** Storage of the chart configuration objects. */
	private LinkedList<ChartConfig> chartconfigs = null;
	
	/** Storage of the data sources. The collection is valid only if all of the
	 *  contained configuration object use this DataSources object.
	 */
	private DataSources dataSources = null;
	
	/** Whether this collection stores only one configuration object or more. */
	private boolean singleFlag = false;
	
	/** Default <code>fireInitialEvent</code> for chart configuration object that
	 *  created direct to this collection by the {@link ai.aitia.chart.dialogs.CCCollectionDialog 
	 *  CCCollectionDialog } class.
	 */
	private boolean defaultFireInitialEvent = false;
	
	/** Wizard or default mode? In wizard-mode, the GUI and the behavior of the
	 *  collection is different than in default mode. */ 
	private boolean wizardMode = false;
	
	/** If this flag is <code>true</code> then all chart display window is closed
	 *  when the GUI component of the collection is closed.
	 */
	private boolean closeStrategy = true;
	
	/** Storage of the chart display windows. */
	private LinkedList<JFrame> displays = null;
	
	/** In wizard mode this member defines the the save path of the collection. */ 
	private String modelFileName = null;
	
	/** In wizard mode this member defines the path and name of the help documentation. */
	private String helpFile = null;
	
	/** Whether the multi-layerd charts is allowed or not. */
	private boolean composeMode = true;
	
	static {
		CustomSaveableChartPanel.NEED_MOVIE = false;
	}
	
	//===============================================================================
	// methods
	
	/** Constructor.
	 * @param dataSources storage of the data sources
	 * @param singleFlag allow to contain only one chart configuration object?
	 */
	public ChartConfigCollection(DataSources dataSources, boolean singleFlag) {
		chartconfigs = new LinkedList<ChartConfig>();
		this.dataSources = dataSources;
		this.singleFlag = singleFlag;
		this.displays = new LinkedList<JFrame>();
	}
	
	//-------------------------------------------------------------------------------
	/** Returns an iterator of the collection.
	 * @return iterator object
	 */
	public Iterator<ChartConfig> iterator() {
		return chartconfigs.iterator();
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the count of the chart configuration objects contained by the
	 *  collection.
	 * @return size of the collection
	 */
	public int getChartConfigCount() {
		return chartconfigs.size();
	}
	
	//-------------------------------------------------------------------------------
	/** It adds <code>config</code> to the collection. If the collection can store
	 *  only one chart configuration object and it's not empty, then the method
	 *  does nothing.
	 * @param config a chart configuration object
	 */
	public void addChartConfig(ChartConfig config) {
		if (singleFlag && chartconfigs.size()>0) return;
		chartconfigs.add(config);
	}
	
	//-------------------------------------------------------------------------------
	/** It removes <code>config</code> from the collection.
	 * @param config a chart configuration object
	 */
	public void removeChartConfig(ChartConfig config) {
		chartconfigs.remove(config);
	}
	
	//-------------------------------------------------------------------------------
	public void moveChartConfig(ChartConfig config, int dir) {
		if (config == null || dir == 0) 
			throw new IllegalArgumentException();
		int index = chartconfigs.indexOf(config);
		if (index == -1 || (dir > 0 && index == chartconfigs.size() - 1) ||
			(dir < 0 && index == 0))
			return;
		if (dir < 0) index--;
		ChartConfig temp = chartconfigs.remove(index);
		chartconfigs.add(index+1,temp);
	}

	//-------------------------------------------------------------------------------
	/** Creates and returns a container that displays this collection of charts
	 *  in a tree, and allows the user to add new configuration and edit and display
	 *  each configuration If this collection is allowed to store only one chart
	 *  configuration object, the collection tree isn't displayed.<br>
	 *
	 *  Note: the returned container contains a "Cancel" button. When it is clicked,
	 *  the container makes itself invisible and sends an event:<br>
	 *  - WindowEvent.WINDOW_CLOSING if the parent is a java.awt.Window,  
	 *    or a Window's JLayeredPane. The event is sent to the window with 
	 *    event.getSource() == the window.<br>
	 *  - ComponentEvent.COMPONENT_HIDDEN otherwise. The event is sent to the immediate
	 *    parent of this Container, with event.getSource() == this Container (not its parent).
	 *    In this case the parent should process the ComponentListener.componentHidden() 
	 *    message (which is only triggered when this dialog should be closed).<br>
	 *  <p>
	 *  For details, see {@link ai.aitia.chart.charttypes.dialogs.AbstractChartDialog#notifyForHide()
	 *   notifyForHide()}.
	 *
	 * @return a dialog
	 */
	public Container createDialog() {
		if (singleFlag && chartconfigs.size() != 0) {
			ChartConfig single = chartconfigs.getFirst();
			String id = single.getChartType();
			AbstractChartDialog dialog = (AbstractChartDialog) AbstractChart.find(id).createDialog(single,this);
			if (!composeMode) dialog.setComposeButton(true);
			return dialog;
		}
		return new CCCollectionDialog(this);
	}

	//-------------------------------------------------------------------------------
	/** This method saves the collection into an XML-file <code>file</code>. It uses
	 *  the save() method of {@link DataSources#save(org.w3c.dom.Node) DataSource} and
	 *  {@link ChartConfig#save(org.w3c.dom.Node) ChartConfig} classes.
	 * @param file destination file
	 * @throws Exception if any problems occure during the save
	 */
	public void save(File file) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder parser = factory.newDocumentBuilder();
		Document document = parser.newDocument();
		
		Element chart = document.createElement("chart");
		chart.setAttribute("singleFlag",String.valueOf(singleFlag));
		dataSources.save(chart);
		
		List<String> usedTemplates = new ArrayList<String>();
		Element templates = document.createElement(ChartConstants.TEMPLATES);
		for (ChartConfig cc : chartconfigs) 
			cc.saveTemplate(templates,usedTemplates);
		if (!usedTemplates.isEmpty())
			chart.appendChild(templates);
		
		for (ChartConfig cc : chartconfigs) 
			cc.save(chart);
		document.appendChild(chart);
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		transformerFactory.setAttribute("indent-number",4);
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty( OutputKeys.INDENT, "yes" );
		Source source = new DOMSource(document);
		FileOutputStream os = new FileOutputStream(file);
		Result result = new StreamResult(new OutputStreamWriter(os,"utf-8"));
		transformer.transform(source,result);
	}
	
	//-------------------------------------------------------------------------------
	/** This factory-method creates a ChartConfigCollection object from from the
	 *  XML-file specified by <code>uri</code> and an IDSPCollection object. It uses
	 *  the load() method of {@link DataSources#load(org.w3c.dom.Node,IDSPCollection)
	 *   DataSource} and {@link ChartConfig#load(org.w3c.dom.Node,DataSources)
	 *   ChartConfig} classes. 
	 * @param uri URI is a more general type than File. With this type the method can
	 * 	      loads an XML-file contained by a JAR.
	 * @param dsp_collection collection of the available data sources
	 * @return a ChartConfigCollection object
	 * @throws XMLLoadingException if any problems occure during the process of the XML document
	 * @throws Exception if any problems occure during the load 
	 */
	public static ChartConfigCollection load(URI uri, IDSPCollection dsp_collection)
			throws XMLLoadingException, Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder parser = factory.newDocumentBuilder();
		Document document = parser.parse(uri.toString());
		
		Element chart = document.getDocumentElement();
		String flag_string = chart.getAttribute("singleFlag");
		if (flag_string.equals("")) {
			throw new XMLLoadingException("Invalid XML-file. There is no 'singleFlag' attribute.");
			
		}
		boolean sf = Boolean.parseBoolean(flag_string);
		DataSources ds = DataSources.load(chart,dsp_collection);
		ChartConfigCollection collection = new ChartConfigCollection(ds,sf);
		
		NodeList nodes = chart.getElementsByTagName(ChartConstants.TEMPLATES);
		if (nodes != null && nodes.getLength() > 0) {
			Element templates = (Element) nodes.item(0);
			nodes = templates.getElementsByTagName(ChartConstants.TEMPLATE);
			if (nodes == null || nodes.getLength() == 0) 
				throw new XMLLoadingException("Invalid XML-file: missing <" + ChartConstants.TEMPLATE + "> tag");
			for (int i = 0;i < nodes.getLength();++i) {
				Element template = (Element) nodes.item(i);
				String name = template.getAttribute(ChartConstants.REF_ID_ATTR);
				if (name == null || "".equals(name))
					throw new XMLLoadingException("Invalid XML-file: missing '" + ChartConstants.REF_ID_ATTR + "' attribute");
				if (AbstractChart.templates.get(name) == null) {
					DocumentBuilder saveParser = factory.newDocumentBuilder();
					Document newDocument = saveParser.newDocument();
					
					Element root = Utilities.cloneAndChangeOwner(template,newDocument);
					newDocument.appendChild(root);
					
					File templatesDir = new File("Templates");
					if (!templatesDir.exists()) templatesDir.mkdir();
					File newTemplate = new File(templatesDir,name + ".xml");
					
					Transformer transformer = TransformerFactory.newInstance().newTransformer();
					Source source = new DOMSource(newDocument);
					FileOutputStream os = new FileOutputStream(newTemplate);
					Result result = new StreamResult(os);
					transformer.transform(source,result);
					AbstractChart.templates.put(name,root);
				}
			}
		}
		
		nodes = chart.getElementsByTagName("chartconfig");

		if (nodes == null || nodes.getLength() == 0) {
			throw new XMLLoadingException("Invalid XML-file: missing <chartconfig> tag");
		}
		for (int i=0;i<nodes.getLength();++i) {
			Element chartconfig = null;
			try {
				chartconfig = (Element)nodes.item(i);
			} catch (ClassCastException e ) {
				throw new XMLLoadingException("Invalid XML-file: missing <chartconfig> tag");
			}
			if (chartconfig.getParentNode().equals(chart))
				collection.addChartConfig(ChartConfig.load(chartconfig,ds));
		}
		return collection;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the value of <code>defaultFireInitialEvent</code> flag. */ 
	public boolean getDefaultFireInitialEvent() {
		return defaultFireInitialEvent;
	}

	//-------------------------------------------------------------------------------
	/** Sets the <code>defaultFireIntialEvent</code> flag.
	 * @param defaultFireInitialEvent the new value of the flag */
	public void setDefaultFireInitialEvent(boolean defaultFireInitialEvent) {
		this.defaultFireInitialEvent = defaultFireInitialEvent;
	}

	//-------------------------------------------------------------------------------
	/** Returns the storage of the data sources.
	 * @return data sources storage
	 */
	public DataSources getDataSources() {
		return dataSources;
	}

	//-------------------------------------------------------------------------------
	/** Returns whether the collection can contain only one chart configuration object
	 *  or more.
	 */
	public boolean getSingleFlag() {
		return singleFlag;
	}
	
	//-------------------------------------------------------------------------------
	/** Sets the <code>composeMode</code> flag.
	 * @param composeMode the new value of the flag
	 */
	public void setComposeMode(boolean composeMode) {
		this.composeMode = composeMode;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns whether the collection can contain multi-layeres charts or not. */
	public boolean getComposeMode() {
		return composeMode;
	}

	//-------------------------------------------------------------------------------
	/** Sets the <code>wizardMode</code> flag.
	 * @param wizardMode the new value of the flag 
	 */
	public void setWizardMode(boolean wizardMode) {
		CustomSaveableChartPanel.NEED_MOVIE = wizardMode;
		this.wizardMode = wizardMode;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns whether the collection is in wizard mode or not. */
	public boolean getWizardMode() {
		return wizardMode;
	}

	//-------------------------------------------------------------------------------
	/** Returns the save path of the collection (used only in wizard mode).
	 * @return the save path of the collection 
	 */
	public String getModelFileName() {
		return modelFileName;
	}

	//-------------------------------------------------------------------------------
	/** Sets the save path of the collection (used only in wizard mode).
	 * @param modelFileName the save path of the collection 
	 */
	public void setModelFileName(String modelFileName) {
		this.modelFileName = modelFileName;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the path of the help documentation (used only in wizard mode).
	 * @return the path of the help documentation 
	 */
	public String getHelpFile() {
		return helpFile;
	}
	
	//-------------------------------------------------------------------------------
	/** Sets the path of the help documentation (used only in wizard mode).
	 * @param helpFile the path of the help documentation
	 */
	public void setHelpFile(String helpFile) {
		this.helpFile = helpFile;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the value of <code>closeStategy</code> flag. */
	public boolean getCloseStrategy() {
		return closeStrategy;
	}
	
	//-------------------------------------------------------------------------------
	/** Sets the <code>closeStrategy</code> flag.
	 * @param closeStrategy the new value of the flag
	 */
	public void setCloseStrategy(boolean closeStrategy) {
		this.closeStrategy = closeStrategy;
	}
	
	//-------------------------------------------------------------------------------
	/** Adds the frame <code>display</code> to the storage of chart display windows.
	 * @param display display object
	 */  
	public void addDisplay(JFrame display) {
		displays.add(display);
	}

	//-------------------------------------------------------------------------------
	/** Returns the list of chart display windows.
	 * @return list of frames that contains the chart displays
	 */
	public LinkedList<JFrame> getDisplays() {
		return displays;
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the global exception handler object. The default handler displays
	 * any uncaught exceptions in a message window.
	 * @return the global exception handler object
	 */
	public static UncaughtExceptionHandler getExceptionHandler() {
		return GlobalHandlers.getExceptionHandler();
	}
	
	//-------------------------------------------------------------------------------
	/** Sets the global exception handler. 
	 * @param handler the new global exception handler
	 */
	public static void setExceptionHandler(UncaughtExceptionHandler handler) {
		GlobalHandlers.setExceptionHandler(handler);
	}
	
	//-------------------------------------------------------------------------------
	/** Returns the global long operation executor object. The default executor
	 *  executes the long operations in the current thread. 
	 * @return the global long operation executor object
	 */
	public static ILOPExecutor getLOPExecutor() {
		return GlobalHandlers.getLOPExecutor();
	}
	
	//-------------------------------------------------------------------------------
	/** Sets the global long operation executor object.
	 * @param e the new long operation executor 
	 * @return the old long operation executor
	 */
	public static ILOPExecutor setLOPExecutor(ILOPExecutor e) {
		return GlobalHandlers.setLOPExecutor(e);
	}

	//--------------------------------------------------------------------------------
	/** Returns the global initial color appearance.
	 * @return the global initial color appearance
	 */
	public static String getColorAppearance() {
		return colorAppearance;
	}

	//--------------------------------------------------------------------------------
	/** Sets the global initial color appearance.
	 * @param colorAppearance the new global initial color appearance
	 */
	public static void setColorAppearance(String colorAppearance) {
		ChartConfigCollection.colorAppearance = colorAppearance;
	}

	//--------------------------------------------------------------------------------
	/** Returns the global initial environment appearance.
	 * @return the global initial environment appearance
	 */
	public static String getEnvironmentAppearance() {
		return environmentAppearance;
	}

	//--------------------------------------------------------------------------------
	/** Sets the global initial environment appearance.
	 * @param environmentAppearance the new global initial environment appearance
	 */
	public static void setEnvironmentAppearance(String environmentAppearance) {
		ChartConfigCollection.environmentAppearance = environmentAppearance;
	}
}
