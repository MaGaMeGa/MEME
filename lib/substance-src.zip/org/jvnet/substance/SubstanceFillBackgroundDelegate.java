/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;

import javax.swing.*;

import org.jvnet.lafwidget.LafWidgetUtilities;
import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * Delegate for painting filled backgrounds.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceFillBackgroundDelegate {
	/**
	 * Alpha composite of <code>this</code> delegate. The default value is 1.0
	 * which results in completely opaque background. However, in some cases, we
	 * need to draw partially translucent background, as in menus.
	 */
	private float alphaComposite;

	/**
	 * Creates a new opaque fill background delegate.
	 */
	public SubstanceFillBackgroundDelegate() {
		this(1.0f);
	}

	/**
	 * Creates a new translucent fill background delegate.
	 * 
	 * @param alphaComposite
	 *            Alpha composite of <code>this</code> delegate. The default
	 *            value is 1.0 which results in completely opaque background.
	 *            However, in some cases, we need to draw partially translucent
	 *            background, as in menus.
	 */
	public SubstanceFillBackgroundDelegate(float alphaComposite) {
		this.alphaComposite = alphaComposite;
	}

	/**
	 * Updates the background of the specified component on the specified
	 * graphic context.
	 * 
	 * @param g
	 *            Graphic context.
	 * @param c
	 *            Component.
	 */
	public void update(Graphics g, Component c) {
		// failsafe for LAF change
		if (!(UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel)) {
			return;
		}

		boolean isInCellRenderer = (c.getParent() instanceof CellRendererPane);
		boolean isPreviewMode = false;
		if (c instanceof JComponent) {
			isPreviewMode = (Boolean.TRUE.equals(((JComponent) c)
					.getClientProperty(LafWidgetUtilities.PREVIEW_MODE)));
		}
		if ((!isPreviewMode) && (!c.isShowing()) && (!isInCellRenderer)) {
			return;
		}

		Graphics2D graphics = (Graphics2D) g.create();
		synchronized (c) {
			if (TransitionLayout.isOpaque(c)) {
				// fill background
				graphics.setComposite(TransitionLayout.getAlphaComposite(c));
				graphics.setColor(c.getBackground());
				graphics.fillRect(0, 0, c.getWidth(), c.getHeight());
				// if (c.getClass().getName().contains("DesktopPanel"))
				// System.out.println("Painting DesktopPanel with color "
				// + c.getBackground()
				// + "["
				// + c.isOpaque()
				// + "]"
				// + " on "
				// + ((AlphaComposite) graphics.getComposite())
				// .getAlpha());
				// if (c instanceof JDesktopPane)
				// System.out.println("Painting JDesktopPane with color "
				// + c.getBackground()
				// + "["
				// + c.isOpaque()
				// + "]"
				// + " on "
				// + ((AlphaComposite) graphics.getComposite())
				// .getAlpha());
				// if (c.getClass().getName().contains("TextFieldsPanel"))
				// System.out.println("Painting TextFieldsPanel with color "
				// + c.getBackground()
				// + "["
				// + c.isOpaque()
				// + "]"
				// + " on "
				// + ((AlphaComposite) graphics.getComposite())
				// .getAlpha());

				graphics.setComposite(TransitionLayout.getAlphaComposite(c,
						this.alphaComposite));
				// graphics.setComposite(AlphaComposite.getInstance(
				// AlphaComposite.SRC_OVER, this.alphaComposite));
				// stamp watermark
				if (!isPreviewMode && !isInCellRenderer && c.isShowing()
						&& SubstanceCoreUtilities.toDrawWatermark(c)) {
					SubstanceLookAndFeel.getCurrentWatermark()
							.drawWatermarkImage(graphics, c, 0, 0,
									c.getWidth(), c.getHeight());
				}
			}
		}
		graphics.dispose();
	}

	/**
	 * Updates the background of the specified component on the specified
	 * graphic context in the specified rectangle.
	 * 
	 * @param g
	 *            Graphic context.
	 * @param c
	 *            Component.
	 * @param rect
	 *            The rectangle to fill.
	 */
	public void update(Graphics g, JComponent c, Rectangle rect) {
		// failsafe for LAF change
		if (!(UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel)) {
			return;
		}

		boolean isInCellRenderer = (c.getParent() instanceof CellRendererPane);
		if ((!c.isShowing()) && (!isInCellRenderer)) {
			return;
		}

		Graphics2D graphics = (Graphics2D) g.create();
		synchronized (c) {
			if (TransitionLayout.isOpaque(c)) {
				// fill background
				graphics.setComposite(TransitionLayout.getAlphaComposite(c));
				graphics.setColor(c.getBackground());
				graphics.fillRect(rect.x, rect.y, rect.width, rect.height);
				graphics.setComposite(TransitionLayout.getAlphaComposite(c,
						this.alphaComposite));
				// graphics.setComposite(AlphaComposite.getInstance(
				// AlphaComposite.SRC_OVER, this.alphaComposite));
				// stamp watermark
				if (!isInCellRenderer && c.isShowing()
						&& SubstanceCoreUtilities.toDrawWatermark(c))
					SubstanceLookAndFeel.getCurrentWatermark()
							.drawWatermarkImage(graphics, c, rect.x, rect.y,
									rect.width, rect.height);
			}
		}
		graphics.dispose();
	}

	/**
	 * Sets the alpha (translucency) attribute for this delegate.
	 * 
	 * @param alphaComposite
	 *            Alpha (translucency) attribute for this delegate.
	 */
	public void setAlphaComposite(float alphaComposite) {
		this.alphaComposite = alphaComposite;
	}
}
