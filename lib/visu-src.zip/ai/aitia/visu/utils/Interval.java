package ai.aitia.visu.utils;

import java.io.Serializable;

public class Interval implements Comparable<Interval>, Serializable, Cloneable {

	//==================================================================================
	// members
	
	private static final long serialVersionUID = 5779981728081486710L;
	private double lower, upper;
	
	//==================================================================================
	// methods
	
	//----------------------------------------------------------------------------------
	public Interval(double lower, double upper) {
		if (lower > upper)
			throw new IllegalArgumentException("Empty interval is not supported.");
		this.lower = lower; this.upper = upper;
	}
	
	//----------------------------------------------------------------------------------
	public Interval(String intv) {
		if (intv == null || "".equals(intv.trim()))
			throw new IllegalArgumentException("Invalid interval string.");
		String parts[] = intv.split("\\.\\.");
		if (parts.length == 1) {
			Double d = Double.parseDouble(parts[0]);
			this.lower = this.upper = d; 
		} else if (parts.length == 2) {
			Double lower = Double.parseDouble(parts[0]);
			Double upper = Double.parseDouble(parts[1]);
			if (lower > upper)
				throw new IllegalArgumentException("Empty interval is not supported.");
			this.lower = lower; this.upper = upper;
		} else throw new IllegalArgumentException("Invalid interval string.");
	}
	
	//----------------------------------------------------------------------------------
	public Interval(double value) { this(value,value); }
	public Interval(int lower, int upper) { this((double)lower,(double)upper); }
	public Interval(int value) { this((double)value); }
	public Interval(int lower, double upper) { this((double)lower,upper); }
	public Interval(double lower, int upper) { this(lower,(double)upper); }

	//----------------------------------------------------------------------------------
	public double getLower() { return lower; }
	public double getUpper() { return upper; }
	
	//----------------------------------------------------------------------------------
	public boolean contains(double value) { return lower <= value && value <= upper; }
	public boolean contains(int value) { return contains((double)value); }
	
	//----------------------------------------------------------------------------------
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Interval) {
			Interval that = (Interval) obj;
			return this.lower == that.lower && this.upper == that.upper;
		}
		return false;
	}
	
	//----------------------------------------------------------------------------------
	@Override
	public String toString() {
		if (lower == upper) return String.valueOf(lower);
		else return lower + ".." + upper;
	}
	
	//==================================================================================
	// implemented interfaces
	
	//----------------------------------------------------------------------------------
	@Override public Object clone() { return new Interval(this.lower,this.upper); }

	//----------------------------------------------------------------------------------
	public int compareTo(Interval that) {
		if (equals(that)) return 0;
		if (this.lower < that.lower) return -1;
		else if (this.lower == that.lower && this.upper < that.upper) return -1;
		return 1;
	}
}