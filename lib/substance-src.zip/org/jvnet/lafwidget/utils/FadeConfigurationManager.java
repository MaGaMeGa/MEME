/*
 * Copyright (c) 2005-2007 Laf-Widget Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Laf-Widget Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.lafwidget.utils;

import java.awt.Component;
import java.util.*;

import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;

/**
 * Fade configuration manager.
 * 
 * @author Kirill Grouchnikov
 * @since 2.1
 */
public class FadeConfigurationManager {
	/**
	 * Singleton instance.
	 */
	private static FadeConfigurationManager instance;

	/**
	 * Contains {@link FadeKind} instances.
	 */
	private Set globalAllowed;

	/**
	 * Key - {@link FadeKind}, value - set of {@link Class} instances.
	 */
	private Map classAllowed;

	/**
	 * Returns the configuration manager instance.
	 * 
	 * @return Configuration manager instance.
	 */
	public static synchronized FadeConfigurationManager getInstance() {
		if (instance == null) {
			instance = new FadeConfigurationManager();
		}
		return instance;
	}

	/**
	 * Creates a new instance.
	 */
	private FadeConfigurationManager() {
		this.globalAllowed = new HashSet();
		this.classAllowed = new HashMap();
	}

	/**
	 * Allows fade of the specified kind on all controls.
	 * 
	 * @param fadeKind
	 *            Fade kind to allow.
	 */
	public synchronized void allowFades(FadeKind fadeKind) {
		this.globalAllowed.add(fadeKind);
	}

	/**
	 * Allows fade of the specified kind on all controls of specified class.
	 * 
	 * @param fadeKind
	 *            Fade kind to allow.
	 * @param clazz
	 *            Control class for allowing the fade kind.
	 */
	public synchronized void allowFades(FadeKind fadeKind, Class clazz) {
		Set existing = (Set) this.classAllowed.get(fadeKind);
		if (existing == null) {
			existing = new HashSet();
			this.classAllowed.put(fadeKind, existing);
		}
		existing.add(clazz);
	}

	/**
	 * Allows fade of the specified kind on all controls of specified classes.
	 * 
	 * @param fadeKind
	 *            Fade kind to allow.
	 * @param clazz
	 *            Control classes for allowing the fade kind.
	 */
	public synchronized void allowFades(FadeKind fadeKind, Class[] clazz) {
		for (int i = 0; i < clazz.length; i++) {
			allowFades(fadeKind, clazz[i]);
		}
	}

	/**
	 * Disallows fade of the specified kind on all controls.
	 * 
	 * @param fadeKind
	 *            Fade kind to disallow.
	 */
	public synchronized void disallowFades(FadeKind fadeKind) {
		this.globalAllowed.remove(fadeKind);
	}

	/**
	 * Disallows fade of the specified kind on all controls of specified class.
	 * 
	 * @param fadeKind
	 *            Fade kind to disallow.
	 * @param clazz
	 *            Control class for disallowing the fade kind.
	 */
	public synchronized void disallowFades(FadeKind fadeKind, Class clazz) {
		Set existing = (Set) this.classAllowed.get(fadeKind);
		if (existing == null)
			return;

		existing.remove(clazz);
		if (existing.size() == 0)
			this.classAllowed.remove(fadeKind);
	}

	/**
	 * Disallows fade of the specified kind on all controls of specified
	 * classes.
	 * 
	 * @param fadeKind
	 *            Fade kind to disallow.
	 * @param clazz
	 *            Control classes for disallowing the fade kind.
	 */
	public synchronized void disallowFades(FadeKind fadeKind, Class[] clazz) {
		for (int i = 0; i < clazz.length; i++) {
			disallowFades(fadeKind, clazz[i]);
		}
	}

	/**
	 * Checks whether the specified fade kind is allowed on the specified
	 * component.
	 * 
	 * @param fadeKind
	 *            Fade kind.
	 * @param comp
	 *            Component.
	 * @return <code>true</code> if the specified fade kind is allowed on the
	 *         specified component, <code>false</code> otherwise.
	 */
	public synchronized boolean fadeAllowed(FadeKind fadeKind, Component comp) {
		if (this.globalAllowed.contains(fadeKind))
			return true;
		Set specific = (Set) this.classAllowed.get(fadeKind);
		if (specific == null)
			return false;
		Class clazz = comp.getClass();
		for (Iterator it = specific.iterator(); it.hasNext();) {
			Class specClazz = (Class) it.next();
			if (specClazz.isAssignableFrom(clazz))
				return true;
		}
		return false;
	}
}
