package ai.aitia.visu.view.plot;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.entity.XYItemEntity;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.SeriesRenderingOrder;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.XYDataset;

import ai.aitia.visu.view.selection.ISelectionListener;
import ai.aitia.visu.view.selection.SelectionEvent;
import ai.aitia.visu.view.selection.XYItem;

@SuppressWarnings("serial")
public class XYPlot extends InteractiveXYPlot {
	
	private List listeners;
	
    public XYPlot(XYDataset dataset,
            ValueAxis domainAxis,
            ValueAxis rangeAxis,
            XYItemRenderer renderer) {
    	super(dataset, domainAxis, rangeAxis, renderer);
    	this.listeners = new ArrayList();
    }

	public void selectEntity(ChartEntity entity) {
		
		//System.out.println("SelectEntity: " + entity);
		
		if (entity instanceof XYItemEntity) {
			
			XYItemEntity xyEntity = (XYItemEntity) entity;
			
			selectionModel.addObject(new XYItem(xyEntity.getDataset(), 
					xyEntity.getSeriesIndex(), 
					xyEntity.getItem()));
		}		
	}
	
    public boolean render(Graphics2D g2, Rectangle2D dataArea, int index,
			PlotRenderingInfo info, CrosshairState crosshairState) {

		boolean foundData = false;
		XYDataset dataset = getDataset(index);
		if (!DatasetUtilities.isEmptyOrNull(dataset)) {
			foundData = true;
			ValueAxis xAxis = getDomainAxisForDataset(index);
			ValueAxis yAxis = getRangeAxisForDataset(index);
			XYItemRenderer renderer = getRenderer(index);
			if (renderer == null) {
				renderer = getRenderer();
			}

			XYItemRendererState state = renderer.initialise(g2, dataArea, this,
					dataset, info);
			int passCount = renderer.getPassCount();

			SeriesRenderingOrder seriesOrder = getSeriesRenderingOrder();
			if (seriesOrder == SeriesRenderingOrder.REVERSE) {
				//render series in reverse order
				for (int pass = 0; pass < passCount; pass++) {
					int seriesCount = dataset.getSeriesCount();
					for (int series = seriesCount - 1; series >= 0; series--) {
						int itemCount = dataset.getItemCount(series);
						for (int item = 0; item < itemCount; item++) {
							renderer.drawItem(g2, state, dataArea, info, this,
									xAxis, yAxis, dataset, series, item,
									crosshairState, pass);
						}
					}
				}
			} else {
				//render series in forward order
				for (int pass = 0; pass < passCount; pass++) {
					int seriesCount = dataset.getSeriesCount();
					for (int series = 0; series < seriesCount; series++) {
						int itemCount = dataset.getItemCount(series);
						for (int item = 0; item < itemCount; item++) {
							renderer.drawItem(g2, state, dataArea, info, this,
									xAxis, yAxis, dataset, series, item,
									crosshairState, pass);
						}
					}
				}
			}
		}
		
		renderSelection(g2);
		
		return foundData;
	}	
    
    public void fireSelectionChanged() {
    	notifyListeners(new SelectionEvent(selectionModel));
    }
    
    protected void notifyListeners(SelectionEvent e) {
    	
    	final int length = listeners.size();
    	
    	for (int i=0; i<length; i++) {
    		ISelectionListener l = (ISelectionListener) listeners.get(i);
    		l.selectionChanged(e);
    	}
    }
    
	@SuppressWarnings("unchecked")
	public void addSelectionListener(ISelectionListener listener) {
		listeners.add(listener);
	}
	
	public void removeSelectionListener(ISelectionListener listener) {
		listeners.remove(listener);
	}    
}
