/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.dialogs;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.JViewport;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.charttypes.dialogs.AbstractChartDialog;
import ai.aitia.chart.charttypes.dialogs.ChartDialogChangeCenter;
import ai.aitia.chart.util.Utilities;
import ai.aitia.fobwizard.FOBWizard;
import ai.aitia.meme.utils.FormsUtils;

/** The main GUI-component of the charting package. */
public class CCCollectionDialog extends JPanel implements ChartDialogChangeListener,
														  ActionListener,
														  MouseListener,
														  ListSelectionListener,
														  TreeSelectionListener {

	//===============================================================================
	// nested classes
	
	/** Nested class that represents an element of the tree that displays the chart
	 *  collection. It encapsulates a configuration object and an appropriate GUI
	 *  component.
	 */
	private class TreeNodeElement {
		
		/** Displayable name of the chart (same as the title of the chart). */
		private String name = null;
		
		/** Configuration object of the chart. */
		private ChartConfig config = null;
		
		/** GUI component of the chart. */
		private AbstractChartDialog dialog = null;
		
		//=========================================================================
		// methods
		
		/** Constructor. <code>dialog</code> must be set in separated method.
		 * @param name name of the chart.
		 * @param config configuration object of the chart.
		 */
		public TreeNodeElement(String name, ChartConfig config) {
			this.name = name;
			this.config = config;
		}
		
		//-------------------------------------------------------------------------
		@Override public String toString() { return name; }
		
		//-------------------------------------------------------------------------
		/** Sets the name of the chart.
		 * @param name the new name of the chart
		 */
		public void setName(String name) { this.name = name; }
		
		//-------------------------------------------------------------------------
		/** Returns the configuration object of the chart.
		 * @return the configuration object of the chart
		 */
		public ChartConfig getConfig() { return config; }

		//-------------------------------------------------------------------------
		/** Returns the GUI component of the chart.
		 * @return the GUI component of the chart
		 */
		public AbstractChartDialog getDialog() { return dialog;	}

		//-------------------------------------------------------------------------
		/** Sets the GUI component of the chart.
		 * @param dialog the GUI component of the chart
		 */ 
		public void setDialog(AbstractChartDialog dialog) {	this.dialog = dialog; }
	}
	
	//-----------------------------------------------------------------------------
	/** Nested class that defines the renderer of the element of the chart collection
	 *  tree. Each element has a name and an icon. 
	 */
	private class ChartTreeCellRenderer extends DefaultTreeCellRenderer {
		
		/** Default icon. If the appropriate icon is missing, this will appear. */
		private ImageIcon defaultIcon = null;
		
		private static final long serialVersionUID = 1L; 
		
		//=========================================================================
		// methods
		
		/** Constructor. */
		public ChartTreeCellRenderer() {
			defaultIcon = Utilities.createImageIcon("/icons/Forward16.gif");
		}
		
		//-------------------------------------------------------------------------
		@Override
		public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel,
													  boolean expanded, boolean leaf, int row,
													  boolean hasFocus) {
			super.getTreeCellRendererComponent(tree,value,sel,expanded,leaf,row,hasFocus);
			if (leaf) 
				setIcon(getChartIcon(value));
			return this;
		}
		
		//-------------------------------------------------------------------------
		/** Returns the appropriate icon.
		 * @param value an DefaultMutableTreeNode object. It's user object is a
		 * {@link TreeNodeElement TreeNodeElement} described above.
		 * @return an icon
		 */
		protected ImageIcon getChartIcon(Object value) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
			if (node.getUserObject() instanceof TreeNodeElement) {
				TreeNodeElement element = (TreeNodeElement) node.getUserObject();
				ImageIcon icon = null;
				if (element.getConfig().isMultiLayerChart()) 
					icon = Utilities.icons.get("ComposeChart");
				else
					icon = Utilities.icons.get(element.getConfig().getChartType());
				return (icon == null ? defaultIcon : icon);
			} else return null;
		}
	}
	
	//-----------------------------------------------------------------------------
	/** Nested class that defines the renderer of the elements of the available chart
	 *  types. Each element has a name and an icon.
	 */
	private class ChartTypesCellRenderer extends JLabel implements ListCellRenderer {

		private static final long serialVersionUID = 1L;

		/** Constructor. */
		public ChartTypesCellRenderer() {
			super();
			setOpaque(true);
		}
		
		//-------------------------------------------------------------------------------
		/** Returns a component that contains an icon and a name.
		 * @param list the list that use this renderer
		 * @param value the list element
		 * @param index the row index of the list element
		 * @param isSelected whether the row is selected or not
		 * @param cellHasFocus whether the list has focus or not
		 * @return the rendered component 
		 */
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
			if (isSelected) {
				setBackground(list.getSelectionBackground());
				setForeground(list.getSelectionForeground());
			} else {
				setBackground(list.getBackground());
				setForeground(list.getForeground());
			}
			if (value == null) return this;
			
			AbstractChart chart = (AbstractChart)value;
			
			ImageIcon icon = Utilities.icons.get(chart.getID());
			setIcon(icon);
			setText(chart.toString());
			setFont(list.getFont());
			return this;
		}
	}

	//=============================================================================
	// members
	
	private static final long serialVersionUID = 1L;
	private JPanel content = null;
	private JButton helpButton = new JButton("Help");
	private JTree chartTree = new JTree();
	private JScrollPane scrTree = new JScrollPane(chartTree);
	private JPopupMenu chartContextMenu = new JPopupMenu();
	private JButton newButton = new JButton("New chart");
	private JPanel newChartPanel = null;
	private JButton removeButton = new JButton("Remove chart");
	private JPanel chartPanel = new JPanel();
	private JList chartTypesList = new JList();
	private JScrollPane scrChartTypes = new JScrollPane(chartTypesList);
	private JPopupMenu chartTypesContextMenu = new JPopupMenu();
	private JTextArea descriptionArea = new JTextArea();
	private JScrollPane scrDescription = new JScrollPane(descriptionArea,
														 JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
														 JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	private JButton createButton = new JButton("Create");
	private JButton cancelButton = new JButton("Cancel");
	
	private AbstractAction createAction = null;
	private AbstractAction newAction = null;
	private AbstractAction removeAction = null;
	private AbstractAction moveUpAction = null;
	private AbstractAction moveDownAction = null;
	
	private JButton moveUpButton = new JButton("Move up");
	private JButton moveDownButton = new JButton("Move down");
	
	//=============================================================================
	// additional members
	
	/** Model of chart collection tree. */ 
	private DefaultTreeModel treemodel = null;
	
	/** Model of the list of available chart types. */
	private DefaultListModel listmodel = null;
	
	/** Root element of the chart collection tree. (Not displayed.) */
	private DefaultMutableTreeNode root = null;
	
	/** Last selected element of the chart collection tree. */
	private DefaultMutableTreeNode lastNode = null; 
	
	/** The chart collection object. */
	private ChartConfigCollection cc_collection = null;
	
	/** The count of clicks to change between the charts. */
	private int clickCount = 1;
	
	//=============================================================================
	// methods
	
	/** Constructor.
	 * @param cc_collection the chart collection object. (Empty collection is permitted.)
	 */
	public CCCollectionDialog(ChartConfigCollection cc_collection) {
		super();
		this.cc_collection = cc_collection;
		initialize();
		setSettingsFromCollection();
		ChartDialogChangeCenter.addChartDialogChangeListener(this);
	}
	
	//-----------------------------------------------------------------------------
	/** Updates all charts contained by the its chart config collection object. Returns
	 *  false if any of the charts is not updateable.
	 */
	public boolean updateAll() {
		for (int i = 0;i < root.getChildCount();++i) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) root.getChildAt(i);
			TreeNodeElement nodeElement = (TreeNodeElement) node.getUserObject();
			if (nodeElement == null || !nodeElement.getDialog().isUpdateable())
				return false;
			nodeElement.getDialog().updateChartConfig();
		}
		return true;
	}

	//-----------------------------------------------------------------------------
	/** This method initializes the GUI. */
	private void initialize() {
		root = new DefaultMutableTreeNode("Charts");
		lastNode = root;
		treemodel = new DefaultTreeModel(root);
		initializeChartTypes();
		
		// Chart tree
		chartTree.setModel(treemodel);
		chartTree.setRootVisible(false);
		chartTree.setShowsRootHandles(false);
		chartTree.putClientProperty("JTree.lineStyle","None");
		chartTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		ChartTreeCellRenderer renderer = new ChartTreeCellRenderer();
		chartTree.setCellRenderer(renderer);
		chartTree.addMouseListener(this);
		chartTree.addTreeSelectionListener(this);
		
		// Scroll tree
		scrTree.setPreferredSize(new Dimension(150, 175));
		
		// Chart context menu
		initializeChartContextMenu();
		
		// New button
		newButton.setActionCommand("NEW");
		
		// Remove button
		removeButton.setEnabled(false);
		removeButton.setActionCommand("REMOVE");
		
		// Move buttons
		moveUpButton.setEnabled(false);
		moveUpButton.setActionCommand("MOVE_UP");
		moveDownButton.setEnabled(false);
		moveDownButton.setActionCommand("MOVE_DOWN");
		
		// Chart types list
		chartTypesList.setModel(listmodel);
		chartTypesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		chartTypesList.setCellRenderer(new ChartTypesCellRenderer());
		chartTypesList.addListSelectionListener(this);
		chartTypesList.addMouseListener(this);
		
		// Scroll chart types
		scrChartTypes.setMinimumSize(new Dimension(160,200));
		scrChartTypes.setPreferredSize(new Dimension(165,235));
		
		// Chart types context menu
		initializeChartTypesContextMenu();
		
		// Description area
		descriptionArea.setOpaque(false);
		descriptionArea.setLineWrap(true);
		descriptionArea.setWrapStyleWord(true);
		descriptionArea.setEditable(false);
		descriptionArea.setColumns(30);
		descriptionArea.setBackground(this.getBackground());
		descriptionArea.setMargin(new Insets(0,2,0,2));
		descriptionArea.setFocusable(false);
		
		// Scroll description
		scrDescription.setBorder(null);
		scrDescription.setPreferredSize(new Dimension(430,180)); //TODO: ideiglenes
		
		// Create button
		createButton.setEnabled(false);
		createButton.setMnemonic(KeyEvent.VK_R);
		createButton.setActionCommand("CREATE");
		
		// Cancel button
		cancelButton.setMnemonic(KeyEvent.VK_C);
		cancelButton.setActionCommand("CANCEL");
		
		//Help button
		helpButton.setMnemonic(KeyEvent.VK_H);
		helpButton.setActionCommand("HELP");
		helpButton.setVisible(cc_collection.getWizardMode());

		// New chart panel
		newChartPanel = FormsUtils.build("min(250;p) ~ p:grow d - d - d p:grow",
									  "011111 fill:pref:grow|-|" +
									  "0_234_ pref|" +
									  "0_____",
									  FormsUtils.titledBorder("Avalilable chart types",scrChartTypes),
									  FormsUtils.titledBorder("Description",scrDescription),
									  createButton,
									  cancelButton,
									  helpButton).getPanel();
		
		// Chart Panel
		chartPanel.setLayout(new BoxLayout(chartPanel, BoxLayout.X_AXIS));
		chartPanel.add(newChartPanel);
		
		// Content
		this.content = FormsUtils.build("d - d % p:grow",
					                    "[DialogBorder]001 fill:pref:grow|-|" +
	                                                  "231 pref||" +
	                                                  "451",
	                                    FormsUtils.titledBorder("Chart collection",scrTree),chartPanel,
	                                    newButton,removeButton,
	                                    moveDownButton,moveUpButton).getPanel(); 
		this.setLayout(new BorderLayout());
		this.add(content, BorderLayout.CENTER);
		
		Utilities.addActionListener(this,helpButton,newButton,removeButton,
									createButton,cancelButton,moveUpButton,
									moveDownButton);
	}
	
	//-----------------------------------------------------------------------------
	/** This method initializes the context menu of the chart tree. */
	@SuppressWarnings("serial")
	private void initializeChartContextMenu() {
		newAction = new AbstractAction() {
			{ 
				putValue(NAME,"New chart");
				putValue(ACTION_COMMAND_KEY,"NEW");
			}
			public void actionPerformed(ActionEvent e) { CCCollectionDialog.this.actionPerformed(e); }
		};
		chartContextMenu.add(newAction);
		removeAction = new AbstractAction() {
			{
				putValue(NAME,"Remove chart");
				putValue(ACTION_COMMAND_KEY,"REMOVE");
			}
			public void actionPerformed(ActionEvent e) { selectPathAndExecute(this,e); }
		};
		chartContextMenu.add(removeAction);
		moveUpAction = new AbstractAction() {
			{
				putValue(NAME,"Move up");
				putValue(ACTION_COMMAND_KEY,"MOVE_UP");
			}
			public void actionPerformed(ActionEvent e) { selectPathAndExecute(this,e); }
		};
		chartContextMenu.add(moveUpAction);
		moveDownAction = new AbstractAction() {
			{
				putValue(NAME,"Move down");
				putValue(ACTION_COMMAND_KEY,"MOVE_DOWN");
			}
			public void actionPerformed(ActionEvent e) { selectPathAndExecute(this,e); }
		};
		chartContextMenu.add(moveDownAction);
	}
	
	//-----------------------------------------------------------------------------
	private void selectPathAndExecute(AbstractAction action, ActionEvent e) {
		int x = ((Integer)action.getValue("X")).intValue();
		int y = ((Integer)action.getValue("Y")).intValue();
		TreePath path = chartTree.getPathForLocation(x,y);
		if (path != null) chartTree.setSelectionPath(path);
		this.actionPerformed(e);
	}
	
	//-----------------------------------------------------------------------------
	/** This method initializes the context menu of the chart types list. */
	@SuppressWarnings("serial")
	private void initializeChartTypesContextMenu() {
		final CCCollectionDialog tthis = this;
		createAction = new AbstractAction() {
			{ 
				putValue(NAME, "Create");
				putValue(ACTION_COMMAND_KEY, "CREATE");
			}
			public void actionPerformed(ActionEvent e) {
				int x = ((Integer)getValue("X")).intValue();
				int y = ((Integer)getValue("Y")).intValue();
				int index = chartTypesList.locationToIndex(new Point(x,y));
				chartTypesList.setSelectedIndex(index);
				tthis.actionPerformed(e);
			}
		};
		chartTypesContextMenu.add(createAction);
	}

	//=============================================================================
	
	///////////////////////////////////////////////////////////
	// non-GUI methods                                       //
	///////////////////////////////////////////////////////////

	/** Sets the count of clicks to single. */
	public void changeSingleClick() { clickCount = 1; }
	
	//------------------------------------------------------------------------------
	
	/** Sets the count of clicks to double. */
	public void changeDoubleClick() { clickCount = 2; }
	
	//----------------------------------------------------------------------------------------------------
	public String getSelectedChartType() {
		if (lastNode != null) {
			TreeNodeElement node = (TreeNodeElement) lastNode.getUserObject();
			if (node != null) 
				return node.getConfig().getChartType();
		}
		return null;
	}
	
	//------------------------------------------------------------------------------
	
	/** Add a new chart to the collection. 
	 * @param type the type of the new chart in string format.
	 * @see ai.aitia.chart.util.ChartConstants ChartConstants
	 */
	private void addNewChart(String type) {
		try {
			if (!lastNode.equals(root)) {
				TreeNodeElement last = (TreeNodeElement) lastNode.getUserObject();
				if (last.getDialog().isUpdateable()) last.getDialog().updateChartConfig();
			}
		} catch (ClassCastException ex) {}
		
		ChartConfig newConfig = new ChartConfig(cc_collection.getDataSources());
		newConfig.setChartProperties(type,null);
		newConfig.setFireInitialEvent(cc_collection.getDefaultFireInitialEvent());
		cc_collection.addChartConfig(newConfig);
		TreeNodeElement node = new TreeNodeElement(AbstractChart.find(type).toString(),newConfig);
		DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(node);
		treemodel.insertNodeInto(newNode,root,root.getChildCount());
		chartTree.scrollPathToVisible(new TreePath(newNode.getPath()));
		chartTree.setSelectionPath(new TreePath(newNode.getPath()));
		if (chartPanel.getComponents().length != 0)	chartPanel.remove(0);
		AbstractChartDialog dialog = (AbstractChartDialog) AbstractChart.find(type).createDialog(newConfig,cc_collection);
		dialog.setEditorButtonVisible(FOBWizard.hasValidDataSourceEditor());
		if (cc_collection.getWizardMode()) 
			changeButtons(dialog);
		if (!cc_collection.getComposeMode()) dialog.setComposeButton(true);
		node.setDialog(dialog);
		lastNode = newNode;
		if (dialog.isUpdateable()) dialog.updateChartConfig();
		else changeStatus(node,false);
		changeSaveButton();
		chartPanel.add(dialog,0);
		removeButton.setEnabled(true);
		moveUpButton.setEnabled(root.getChildCount() > 1);
		moveDownButton.setEnabled(root.getChildCount() > 1);
		Utilities.repack(this);
	}
	
	//-----------------------------------------------------------------------------
	/** Sets the GUI from the chart collection <code>cc_collection</code>. */
	private void setSettingsFromCollection() {
		if (cc_collection != null) {
			TreeNodeElement node = null;
			DefaultMutableTreeNode newNode = null;
			for (Object cc : cc_collection) {
				ChartConfig config = (ChartConfig) cc;
				node = new TreeNodeElement("",config);
				newNode = new DefaultMutableTreeNode(node);
				treemodel.insertNodeInto(newNode,root,root.getChildCount());
				AbstractChartDialog dialog = (AbstractChartDialog) AbstractChart.find(config.getChartType()).createDialog(config,cc_collection);
				dialog.setEditorButtonVisible(FOBWizard.hasValidDataSourceEditor());
				if (cc_collection.getWizardMode()) 
					changeButtons(dialog);
				if (!cc_collection.getComposeMode()) dialog.setComposeButton(true);
				node.setName(dialog.getTitle());
				node.setDialog(dialog);
			}
			if (cc_collection.getChartConfigCount() != 0) {
				chartTree.scrollPathToVisible(new TreePath(newNode.getPath()));
				chartTree.setSelectionPath(new TreePath(newNode.getPath()));
				lastNode = newNode;
				changeSaveButton();
				removeButton.setEnabled(true);
				moveUpButton.setEnabled(cc_collection.getChartConfigCount() > 1);
				moveDownButton.setEnabled(cc_collection.getChartConfigCount() > 1);
				chartPanel.remove(0);
				chartPanel.add(node.getDialog(),0);
			}
		}
	}
	
	//-----------------------------------------------------------------------------
	/** Changes the appearance of the tree element <code>node</code>.
	 * @param node element of the tree on the left
	 * @param enabled direction of the change. If <code>enabled</code> is false, the text
	 *  of the element will be grey and italic. 
	 */
	private void changeStatus(TreeNodeElement node, boolean enabled) {
		String str = node.toString();
		if (!str.contains("<html>")) {
			if (enabled) return;
			String new_str = "<html><i><font color=\"#999999\">"+str+"</font></i></html>";
			node.setName(new_str);
		} else {
			if (!enabled) return;
			int from = str.lastIndexOf("\">");
			int to = str.lastIndexOf("</font>");
			node.setName(str.substring(from+2,to));
		}
	}
	
	//-----------------------------------------------------------------------------
	/** This method runs when the save status (saveable or unsaveable) of the chart in
	 *  component <code>where</code> has changed. If all of the elements in the
	 *  collection is saveable then it enables the save button. If all of the elements
	 *  in the collection was saveable and <code>enabled</code> is false then it disables
	 *  the save button.
	 * @param where the component whose save status has changed
	 * @param enabled direction of the change
	 */
	public void saveStatusChanged(AbstractChartDialog where, boolean enabled) {
		int index = -1;
		boolean saveEnabled = true;
		for (int i = 0;i < treemodel.getChildCount(root);++i) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) treemodel.getChild(root,i);
			TreeNodeElement element = (TreeNodeElement) node.getUserObject();
			if (element.getDialog() == null) continue;
			if (element.getDialog().equals(where)) {
				index = i;
				if (enabled) {
					changeStatus(element,true);
				} else {
					changeStatus(element,false);
					changeSaveButton(false);
				}
			} else {
				saveEnabled = saveEnabled && element.getDialog().isUpdateable();
			}
		}
		if (index != -1) {
			treemodel.reload();
			chartTree.setSelectionPath(new TreePath(treemodel.getChild(root,index)));
			chartTree.setSelectionRow(index);
			if (enabled && saveEnabled) changeSaveButton(true);
		}
	}
	
	//-------------------------------------------------------------------------------
	public void templateChanged() {
		for (int i = 0;i < treemodel.getChildCount(root);++i ) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) treemodel.getChild(root,i);
			TreeNodeElement element = (TreeNodeElement) node.getUserObject();
			if (element.getDialog() == null) continue;
			element.getDialog().reloadAppearanceTemplates();
		}
	}
	
	//----------------------------------------------------------------------------------------------------
	public void dataSourcesChanged() {
		for (int i = 0;i < treemodel.getChildCount(root);++i) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) treemodel.getChild(root,i);
			TreeNodeElement element = (TreeNodeElement) node.getUserObject();
			if (element.getDialog() == null) continue;
			element.getDialog().reloadDataSources();
		}
	}
	
	//-------------------------------------------------------------------------------
	/** This method runs when the title of the chart in the component <code>where</code>
	 *  has changed.
	 * @param where the component whose title has changed 
	 */
	public void titleChanged(AbstractChartDialog where) {
		int index = -1;
		for (int i = 0;i < treemodel.getChildCount(root);++i) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) treemodel.getChild(root,i);
			TreeNodeElement element = (TreeNodeElement) node.getUserObject();
			if (element.getDialog().equals(where)) {
				element.setName(element.getDialog().getTitle());
				index = i;
				if (!element.getDialog().isUpdateable()) changeStatus(element,false);
				break;
			}
		}
		if (index != -1) {
			treemodel.reload();
			chartTree.setSelectionPath(new TreePath(treemodel.getChild(root,index)));
			chartTree.setSelectionRow(index);
		}
	}
	
	//-----------------------------------------------------------------------------
	/** Assistant method that enables/disables the save button by the parameter value. */
	private void changeSaveButton(boolean enabled) {
		for (int i = 0;i < treemodel.getChildCount(root);++i) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) treemodel.getChild(root,i);
			TreeNodeElement element = (TreeNodeElement) node.getUserObject();
			element.getDialog().setSaveButtonEnabled(enabled);
		}
	}
	
	//-----------------------------------------------------------------------------
	/** Assistant method that enables/disables the save button by the state of the 
	 *  elements of the collection.
	 */
	private void changeSaveButton() {
		  boolean saveEnabled = true;
		  for (int i = 0;i < treemodel.getChildCount(root);++i) {
			  DefaultMutableTreeNode node = (DefaultMutableTreeNode) treemodel.getChild(root,i);
			  TreeNodeElement element = (TreeNodeElement) node.getUserObject();
			  saveEnabled = saveEnabled && element.getDialog().isUpdateable();
		  }
		  changeSaveButton(saveEnabled);
	}
	
	//-----------------------------------------------------------------------------
	/** Changes the texts of the buttons of the component <code>target</code>. It calls 
	 *  when the GUI is in wizard mode.
	 * @param target the owner of the buttons
	 */
	private void changeButtons(AbstractChartDialog target) {
		target.changeDisplayButtonLabel("Preview", KeyEvent.VK_P);
		target.changeSaveButtonLabel("Generate charts", KeyEvent.VK_G);
	}
	
	//-----------------------------------------------------------------------------
	/** This method fills the list of the available chart types by the static chart
	 *  storage of the class {@link ai.aitia.chart.AbstractChart#charts AbstractChart}.
	 */
	private void initializeChartTypes() {
		listmodel = new DefaultListModel();
		List<AbstractChart> elements = new ArrayList<AbstractChart>(AbstractChart.getChartStorage().values());
		Collections.sort(elements,new Comparator<AbstractChart>() {
			public int compare(AbstractChart o1, AbstractChart o2) {
				return o1.toString().compareTo(o2.toString());
			}
			
		});
		for (AbstractChart chartType : elements)
			listmodel.addElement(chartType);
	}
	
	//-------------------------------------------------------------------------------
	/** This method handles all ActionEvent-s of the panel. It is public because of
	 *  implementation sideeffect. Do not call or override.
	 * @param event event
	 */
	public void actionPerformed(ActionEvent event) {
		String command = event.getActionCommand();
		if (command.equals("HELP")) { // Help button
			if (cc_collection.getHelpFile() == null || cc_collection.getHelpFile().equals("")) 
				JOptionPane.showMessageDialog(this,"Help is unavailable!","Error",JOptionPane.ERROR_MESSAGE,null);
			else {
				try {
					Runtime.getRuntime().exec("cmd.exe start /k \"" + cc_collection.getHelpFile() + "\"");
				} catch (IOException e) {
					JOptionPane.showMessageDialog(this,"Help is unavailable!","Error",JOptionPane.ERROR_MESSAGE,null);
				}
			}
		} else if (command.equals("NEW")) { // New chart button
			chartPanel.remove(0);
			chartPanel.add(newChartPanel,0);
			chartPanel.repaint();
			Utilities.repack(this);
		} else if (command.equals("REMOVE")) { // Remove chart button
			TreePath currentSelection = chartTree.getSelectionPath();
			if (currentSelection == null ||
				currentSelection.equals(new TreePath(root.getPath()))) return;
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) currentSelection.getLastPathComponent();
			int index = treemodel.getIndexOfChild(root,node);
			if (index == -1) return;
			TreeNodeElement selected = (TreeNodeElement) node.getUserObject();
			int result = JOptionPane.showConfirmDialog(this,"Are you sure to delete \"" + htmlRemover(selected.name) + "\"?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null);
			if (result == JOptionPane.YES_OPTION) {
				selected.getConfig().clearAllDataSource();
				cc_collection.removeChartConfig(selected.getConfig());
				treemodel.removeNodeFromParent(node);
				lastNode = root;
				chartPanel.remove(0);
				if (root.getChildCount() != 0) {
					moveUpButton.setEnabled(root.getChildCount() > 1);
					moveDownButton.setEnabled(root.getChildCount() > 1);
					int new_index = (index == root.getChildCount() ? index-1 : index);
					chartTree.setSelectionPath(new TreePath(treemodel.getChild(root,new_index)));
					chartTree.setSelectionRow(new_index);
					node = (DefaultMutableTreeNode) chartTree.getLastSelectedPathComponent();
					lastNode = node;
					changeSaveButton();
					selected = (TreeNodeElement) node.getUserObject();
					chartPanel.add(selected.getDialog(),0);
					chartPanel.repaint();
				} else { 
					removeButton.setEnabled(false);
					chartPanel.add(newChartPanel);
					chartPanel.repaint();
				}
				Utilities.repack(this);
			}
		} else if (command.equals("CREATE")) // Create button
			addNewChart(((AbstractChart)chartTypesList.getSelectedValue()).getID());
		else if (command.equals("CANCEL")) { // Cancel button
			if (root.getChildCount() != 0) { 
				chartPanel.remove(0);
				TreeNodeElement selected = (TreeNodeElement) lastNode.getUserObject();
				chartPanel.add(selected.getDialog(),0);
				chartPanel.repaint();
				Utilities.repack(this);
			} else {
				this.setVisible(false);
				java.awt.event.ComponentEvent cEvent;
				java.awt.Container outerWorld = this.getParent();
				if (outerWorld instanceof JViewport)
					outerWorld = outerWorld.getParent().getParent();
				if (outerWorld instanceof java.awt.Window) {
					cEvent = new WindowEvent((java.awt.Window)outerWorld, WindowEvent.WINDOW_CLOSING);
				} else if (outerWorld instanceof javax.swing.JLayeredPane) {
					outerWorld = ((javax.swing.JLayeredPane)outerWorld).getTopLevelAncestor();
					cEvent = new WindowEvent((java.awt.Window)outerWorld, WindowEvent.WINDOW_CLOSING);
				} else {
					cEvent = new ComponentEvent(this, ComponentEvent.COMPONENT_HIDDEN);
				}
				outerWorld.dispatchEvent(cEvent);
			}
		} else if ("MOVE_UP".equals(command))
			move(-1);
		else if ("MOVE_DOWN".equals(command))
			move(1);
	}
	
	private void move(int offset) {
		TreePath currentSelection = chartTree.getSelectionPath();
		if (currentSelection == null ||
			currentSelection.equals(new TreePath(root.getPath()))) return;
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) currentSelection.getLastPathComponent();
		int index = treemodel.getIndexOfChild(root,node);
		if (index == -1 || (index == 0 && offset < 0) ||
		   (index == root.getChildCount() - 1 && offset > 0)) return;
		TreeNodeElement selected = (TreeNodeElement) node.getUserObject();
		ChartConfig cc = selected.getConfig();
		cc_collection.moveChartConfig(cc,offset);
		treemodel.removeNodeFromParent(node);
		treemodel.insertNodeInto(node,root,index+offset);
		chartTree.setSelectionPath(new TreePath(node.getPath()));
	}

	//------------------------------------------------------------------------------
	/** This method handles all ListSelectionEvent-s of the panel. It is public
	 *  because of implementation side effect. Do not call or override.
	 * @param e event
	 */
	public void valueChanged(ListSelectionEvent e) {
		if (!e.getValueIsAdjusting()) {
			if (chartTypesList.getSelectedIndex() == -1) createButton.setEnabled(false);
			else  {
				createButton.setEnabled(true);
				descriptionArea.setText(AbstractChart.find(((AbstractChart)chartTypesList.getSelectedValue()).getID()).getDescription());
				descriptionArea.setCaretPosition(0);
			}
		}
	}
	
	//------------------------------------------------------------------------------
	/** This method handles all TreeSelectionEvent-s of the panel. It is public 
	 *  because of implementation side effect. Do not call or override.
	 * @param e event
	 */
	public void valueChanged(TreeSelectionEvent e) {
		TreePath currentSelection = chartTree.getSelectionPath();
		if ((currentSelection == null ||
			currentSelection.equals(new TreePath(root.getPath()))) && root.getChildCount() != 0) 
			chartTree.setSelectionPath(e.getOldLeadSelectionPath());
	}
	
	//------------------------------------------------------------------------------
	/** This method handles all pressed mouse events of the panel. It is public
	 *  because of implementation side effect. Do not call or override.
	 * @param e event
	 */
	public void mousePressed(MouseEvent e) {
		if (e.getSource() instanceof JTree) {
			int selRow = chartTree.getRowForLocation(e.getX(),e.getY());
			TreePath selPath = chartTree.getPathForLocation(e.getX(),e.getY());
			if (selRow != -1 && e.getClickCount() == clickCount) {
				DefaultMutableTreeNode node = null;
				try {
					if (!lastNode.equals(root)) {
						TreeNodeElement last = (TreeNodeElement) lastNode.getUserObject();
						if (last.getDialog().isUpdateable()) last.getDialog().updateChartConfig();
					}
					node = (DefaultMutableTreeNode) selPath.getLastPathComponent();
					lastNode = node;
					TreeNodeElement sel = (TreeNodeElement) node.getUserObject();
					chartPanel.remove(0);
					chartPanel.add(sel.getDialog(),0);
					chartPanel.repaint();
					Utilities.repack(this);
				} catch (ClassCastException ex) {}
			}
		} else if (e.getSource() instanceof JList) {
			int index = chartTypesList.getSelectedIndex();
			if (index != -1 && e.getClickCount() == 2) 
				addNewChart(((AbstractChart)chartTypesList.getSelectedValue()).getID());
		}
	}
	
	//-------------------------------------------------------------------------------
	/** This method haldles all released mouse events of the panel. It is public 
	 *  because of implementation side effect. Do not call or override.
	 * @param e event
	 */
	public void mouseReleased(MouseEvent e) {
		if (!SwingUtilities.isRightMouseButton(e))
			return;
		if (e.getComponent().isEnabled()) {
			if (e.getSource() instanceof JList) {
				createAction.putValue("X",new Integer(e.getX()));
				createAction.putValue("Y",new Integer(e.getY()));
				chartTypesContextMenu.show(e.getComponent(),e.getX(),e.getY());
			} else if (e.getSource() instanceof JTree) {
				removeAction.setEnabled(root.getChildCount() != 0);
				moveDownAction.setEnabled(root.getChildCount() > 1);
				moveUpAction.setEnabled(root.getChildCount() > 1);
				removeAction.putValue("X",new Integer(e.getX()));
				removeAction.putValue("Y",new Integer(e.getY()));
				moveUpAction.putValue("X",new Integer(e.getX()));
				moveUpAction.putValue("Y",new Integer(e.getY()));
				moveDownAction.putValue("X",new Integer(e.getX()));
				moveDownAction.putValue("Y",new Integer(e.getY()));

				chartContextMenu.show(e.getComponent(),e.getX(),e.getY());
			}
		}
	}
	
	//-------------------------------------------------------------------------------
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	
	//-------------------------------------------------------------------------------
	/** Removes html code from the parameter string if contains.
	 * @param text text
	 * @return the text without html code
	 */
	private String htmlRemover(String text) {
		if (text == null || !text.startsWith("<html>")) return text;
		int index = text.indexOf("</font>");
		return text.substring(31,index);
	}
}