/** This package contains the representations of the concrete chart type. All of them
  * derived from {@link ai.aitia.chart.AbstractChart AbstractChart}. 
  */
package ai.aitia.chart.charttypes;