/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.data;

import java.io.Serializable;
import java.util.List;

import org.jfree.data.DefaultKeyedValues2D;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.AbstractDataset;
import org.jfree.data.general.DatasetChangeEvent;

/**
 * A default implementation of the {@link CategoryDataset} interface.
 */
public class DefaultCategoryDataset extends AbstractDataset
                                    implements CategoryDataset, Serializable {

    /** For serialization. */
    private static final long serialVersionUID = -8168173757291644622L;
    
    /** A storage structure for the data. */
    private DefaultKeyedValues2D data;

    /**
     * Creates a new (empty) dataset.
     */
    public DefaultCategoryDataset() {
        this.data = new DefaultKeyedValues2D();
    }

    /**
     * Returns the number of rows in the table.
     *
     * @return The row count.
     */
    public int getRowCount() {
        return this.data.getRowCount();
    }

    /**
     * Returns the number of columns in the table.
     *
     * @return The column count.
     */
    public int getColumnCount() {
        return this.data.getColumnCount();
    }

    /**
     * Returns a value from the table.
     *
     * @param row  the row index (zero-based).
     * @param column  the column index (zero-based).
     *
     * @return The value (possibly <code>null</code>).
     */
    public Number getValue(int row, int column) {
        return this.data.getValue(row, column);
    }

    /**
     * Returns a row key.
     *
     * @param row  the row index (zero-based).
     *
     * @return The row key.
     */
    public Comparable getRowKey(int row) {
        return this.data.getRowKey(row);
    }

    /**
     * Returns the row index for a given key.
     *
     * @param key  the row key.
     *
     * @return The row index.
     */
    public int getRowIndex(Comparable key) {
        return this.data.getRowIndex(key);
    }

    /**
     * Returns the row keys.
     *
     * @return The keys.
     */
    public List getRowKeys() {
        return this.data.getRowKeys();
    }

    /**
     * Returns a column key.
     *
     * @param column  the column index (zero-based).
     *
     * @return The column key.
     */
    public Comparable getColumnKey(int column) {
        return this.data.getColumnKey(column);
    }

    /**
     * Returns the column index for a given key.
     *
     * @param key  the column key.
     *
     * @return The column index.
     */
    public int getColumnIndex(Comparable key) {
        return this.data.getColumnIndex(key);
    }

    /**
     * Returns the column keys.
     *
     * @return The keys.
     */
    public List getColumnKeys() {
        return this.data.getColumnKeys();
    }

    /**
     * Returns the value for a pair of keys.  This method should return 
     * <code>null</code> if either of the keys is not found.
     *
     * @param rowKey  the row key.
     * @param columnKey  the column key.
     *
     * @return The value.
     */
    public Number getValue(Comparable rowKey, Comparable columnKey) {
        return this.data.getValue(rowKey, columnKey);
    }

    /**
     * Adds a value to the table.  Performs the same function as setValue().
     *
     * @param value  the value.
     * @param rowKey  the row key.
     * @param columnKey  the column key.
     */
    public void addValue(Number value, Comparable rowKey, 
                         Comparable columnKey) {
        this.data.addValue(value, rowKey, columnKey);
    }

    /**
     * Adds a value to the table.
     *
     * @param value  the value.
     * @param rowKey  the row key.
     * @param columnKey  the column key.
     */
    public void addValue(double value, Comparable rowKey, 
                         Comparable columnKey) {
        addValue(new Double(value), rowKey, columnKey);
    }

    /**
     * Adds or updates a value in the table.
     *
     * @param value  the value (<code>null</code> permitted).
     * @param rowKey  the row key (<code>null</code> not permitted).
     * @param columnKey  the column key (<code>null</code> not permitted).
     */
    public void setValue(Number value, Comparable rowKey, 
                         Comparable columnKey) {
        this.data.setValue(value, rowKey, columnKey);
    }

    /**
     * Adds or updates a value in the table.
     *
     * @param value  the value.
     * @param rowKey  the row key (<code>null</code> not permitted).
     * @param columnKey  the column key (<code>null</code> not permitted).
     */
    public void setValue(double value, Comparable rowKey, 
                         Comparable columnKey) {
        setValue(new Double(value), rowKey, columnKey);
    }

    /**
     * Adds the specified value to an existing value in the dataset (if the 
     * existing value is <code>null</code>, it is treated as if it were 0.0).
     * 
     * @param value  the value.
     * @param rowKey  the row key.
     * @param columnKey  the column key.
     */
    public void incrementValue(double value, 
                               Comparable rowKey, 
                               Comparable columnKey) {
        double existing = 0.0;
        Number n = getValue(rowKey, columnKey);
        if (n != null) {
            existing = n.doubleValue();
        }
        setValue(existing + value, rowKey, columnKey);
    }
    
    /**
     * Removes a value from the dataset.
     *
     * @param rowKey  the row key.
     * @param columnKey  the column key.
     */
    public void removeValue(Comparable rowKey, Comparable columnKey) {
        this.data.removeValue(rowKey, columnKey);
    }

    /**
     * Removes a row from the dataset.
     *
     * @param rowIndex  the row index.
     */
    public void removeRow(int rowIndex) {
        this.data.removeRow(rowIndex);
    }

    /**
     * Removes a row from the dataset.
     *
     * @param rowKey  the row key.
     */
    public void removeRow(Comparable rowKey) {
        this.data.removeRow(rowKey);
    }

    /**
     * Removes a column from the dataset.
     *
     * @param columnIndex  the column index.
     */
    public void removeColumn(int columnIndex) {
        this.data.removeColumn(columnIndex);
    }

    /**
     * Removes a column from the dataset.
     *
     * @param columnKey  the column key.
     */
    public void removeColumn(Comparable columnKey) {
        this.data.removeColumn(columnKey);
    }

    /**
     * Clears all data from the dataset and sends a {@link DatasetChangeEvent} 
     * to all registered listeners.
     */
    public void clear() {
        this.data.clear();
    }
    
    /**
     * Tests if this object is equal to another.
     *
     * @param obj  the other object.
     *
     * @return A boolean.
     */
    public boolean equals(Object obj) {

        if (obj == this) {
            return true;
        }

        if (!(obj instanceof CategoryDataset)) {
            return false;
        }

        CategoryDataset that = (CategoryDataset) obj;
        if (!getRowKeys().equals(that.getRowKeys())) {
            return false;
        }

        if (!getColumnKeys().equals(that.getColumnKeys())) {
            return false;
        }

        int rowCount = getRowCount();
        int colCount = getColumnCount();
        for (int r = 0; r < rowCount; r++) {
            for (int c = 0; c < colCount; c++) {
                Number v1 = getValue(r, c);
                Number v2 = that.getValue(r, c);
                if (v1 == null) {
                    if (v2 != null) {
                        return false;
                    }
                }
                else if (!v1.equals(v2)) {
                    return false;
                }
            }
        }
        return true;
    }
    
	public void fireDatasetChanged() {
		super.fireDatasetChanged();
	}    

    /**
     * Returns a hash code for the dataset.
     * 
     * @return A hash code.
     */
    public int hashCode() {
        return this.data.hashCode();
    }
    
}
