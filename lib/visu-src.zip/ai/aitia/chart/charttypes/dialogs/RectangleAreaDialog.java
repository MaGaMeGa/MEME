/* Copyright notice � 2006 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import org.w3c.dom.Element;

import ai.aitia.chart.AbstractChart;
import ai.aitia.chart.ChartConfig;
import ai.aitia.chart.ChartConfigCollection;
import ai.aitia.chart.DataSources;
import ai.aitia.chart.IDataSourceProducer;
import ai.aitia.chart.charttypes.dialogs.assisttypes.ComboboxItem;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog;
import ai.aitia.chart.charttypes.dialogs.components.ColorMapPanel;
import ai.aitia.chart.charttypes.dialogs.components.DataSourceComboBoxRenderer;
import ai.aitia.chart.charttypes.dialogs.components.IColorMapUser;
import ai.aitia.chart.charttypes.dialogs.components.ChartPropertiesDialog.ChartKind;
import ai.aitia.chart.ds.IStringListProducer;
import ai.aitia.chart.ds.IStringSeriesProducer;
import ai.aitia.chart.test.SimpleDSPCollection;
import ai.aitia.chart.util.ChartConstants;
import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.ds.ISeriesProducer;
import ai.aitia.visu.ds.IValueProducer;
import ai.aitia.visu.globalhandlers.UserBreakException;

/** GUI component of the rectangle area charts. */
public class RectangleAreaDialog extends AbstractChartDialog implements IColorMapUser {

	private static final long serialVersionUID = 1L;
	private JTabbedPane tabbed = null;
	private JPanel buttonPanel = null;
	private JButton cancelButton = null;
	private JPanel mainPanel = null;
	private JPanel detailsPanel = null;
	private JPanel reqParamPanel = null;
	private JPanel areaPanel = null;
	private JComboBox areaParam = null;
	private JButton areaAdvancedButton = null;
	private JPanel colorPanel = null;
	private JComboBox colorParam = null;
	private JButton colorAdvancedButton = null;
	private JPanel req2ParamPanel = null;
	private JPanel namePanel = null;
	private JComboBox nameParam = null;
	private JButton nameAdvancedButton = null;
	private JPanel titleLine = null;
	private JPanel subtitleLine = null;
	private JPanel colorbarLine = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	private JTextField subtitleField = null;
	private JLabel jLabel4 = null;
	private ColorMapPanel cmp = null;
	private JPanel radioButtonPanel = null;
	private JRadioButton showRadioButton = null;
	private JRadioButton hideRadioButton = null;
	private ButtonGroup colorButtonGroup = null; 
	private JPanel appearancePanel = null;
	private JLabel jLabel2 = null;
	private JComboBox appearanceBox = null;
	private JCheckBox nameFlag = null; //  @jve:decl-index=0:
	
	//=============================================================================
	// methods
	
	/** Constructor.
	 * @param config configuration object of the chart
	 * @param cc_collection collection of the <code>config</code> (<code>null</code> is
	 * permitted) 
	 */
	public RectangleAreaDialog(ChartConfig config, ChartConfigCollection cc_collection) {
		super(config,cc_collection);
		initialize();
		setWidgetDisabled();
		setSettingsFromConfig();
	}

	//------------------------------------------------------------------------------
	/** This method initializes <code>this</code>. */
	private void initialize() {
		colorButtonGroup = new ButtonGroup();
		this.setSize(609, 219);
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.setPreferredSize(new Dimension(609, 219));
		this.setMinimumSize(new Dimension(609, 219));
		this.add(getTabbed(), null);
		this.add(getButtonPanel(), null);
	}

	//------------------------------------------------------------------------------
	private JTabbedPane getTabbed() {
		if (tabbed == null) {
			tabbed = new JTabbedPane();
			tabbed.addTab("Main Settings",Utilities.icons.get(ChartConstants.RECTANGLEAREACHART), getMainPanel(), null);
			tabbed.addTab("Details", null, getDetailsPanel(), null);
		}
		return tabbed;
	}

	//------------------------------------------------------------------------------
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = new JPanel();
			buttonPanel.setLayout(new FlowLayout());
			buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
			buttonPanel.add(getEditorButton(), null);
			buttonPanel.add(getDisplayButton(), null);
			buttonPanel.add(getSaveButton(), null);
			buttonPanel.add(getCancelButton(), null);
		}
		return buttonPanel;
	}

	//------------------------------------------------------------------------------
	private JButton getDisplayButton() {
		if (displayButton == null) {
			displayButton = new JButton();
			displayButton.setMnemonic(KeyEvent.VK_D);
			displayButton.setEnabled(false);
			displayButton.setText("Display");
			displayButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					displayChart();
				}
			});
		}
		return displayButton;
	}
	
	//----------------------------------------------------------------------------------------------------
	private JButton getEditorButton() {
		if (editorButton == null) {
			editorButton = new JButton("Create data sources...");
			editorButton.setMnemonic(KeyEvent.VK_R);
			editorButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					openEditor();
				}
			});
		}
		return editorButton;
	}

	//------------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setEnabled(false);
			saveButton.setText("Save");
			saveButton.setMnemonic(KeyEvent.VK_S);
			displayButton.setEnabled(isUpdateable());
			saveButton.setEnabled(isUpdateable());
			saveButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					saveCollection();
				}
			});
		}
		return saveButton;
	}

	//------------------------------------------------------------------------------
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMnemonic(KeyEvent.VK_C);
			cancelButton.setText("Cancel");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					notifyForHide();
				}
			});
		}
		return cancelButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			GridLayout gridLayout = new GridLayout();
			gridLayout.setRows(3);
			mainPanel = new JPanel();
			mainPanel.setLayout(gridLayout);
			mainPanel.add(getReqParamPanel(), null);
			mainPanel.add(getReq2ParamPanel(), null);
		}
		return mainPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getDetailsPanel() {
		if (detailsPanel == null) {
			detailsPanel = new JPanel();
			detailsPanel.setLayout(new BoxLayout(getDetailsPanel(), BoxLayout.Y_AXIS));
			detailsPanel.setBorder(BorderFactory.createTitledBorder(null, "Titles and color settings", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			detailsPanel.add(getTitleLine(), null);
			detailsPanel.add(getSubtitleLine(), null);
			detailsPanel.add(getAppearancePanel(),null);
			cmp = new ColorMapPanel(this);
			cmp.setPreferredSize(new Dimension(609,28));
			detailsPanel.add(cmp, null);
			detailsPanel.add(getColorbarLine(), null);
		}
		return detailsPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getReqParamPanel() {
		if (reqParamPanel == null) {
			reqParamPanel = new JPanel();
			reqParamPanel.setLayout(new BoxLayout(getReqParamPanel(), BoxLayout.X_AXIS));
			reqParamPanel.add(getAreaPanel(), null);
			reqParamPanel.add(getColorPanel(), null);
		}
		return reqParamPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getAreaPanel() {
		if (areaPanel == null) {
			areaPanel = new JPanel();
			areaPanel.setLayout(new BoxLayout(getAreaPanel(), BoxLayout.X_AXIS));
			areaPanel.setBorder(BorderFactory.createTitledBorder(null, "Area values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			areaPanel.add(getAreaParam(), null);
			areaPanel.add(Box.createRigidArea(new Dimension(5,0)));
			areaPanel.add(getAreaAdvancedButton(), null);
		}
		return areaPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getAreaParam() {
		if (areaParam == null) {
			areaParam = new JComboBox(getParamsToAreaAndColor());
			areaParam.setRenderer(new DataSourceComboBoxRenderer(areaParam));
			areaParam.setPreferredSize(new Dimension(100,26));
			areaParam.setMaximumSize(new Dimension(250,30));
			if (areaParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) areaParam.getSelectedItem();
				areaParam.setToolTipText(dsp.toString());
			}
			areaParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) areaParam.getSelectedItem();
					areaParam.setToolTipText(dsp.toString());
					areaAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
				}
			});
		}
		return areaParam;
	}

	//------------------------------------------------------------------------------
	private JButton getAreaAdvancedButton() {
		if (areaAdvancedButton == null) {
			areaAdvancedButton = new JButton();
			areaAdvancedButton.setEnabled(false);
			areaAdvancedButton.setText("Advanced...");
			areaAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) areaParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(RectangleAreaDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = areaParam.getSelectedIndex();
						areaParam.removeItemAt(index);
						areaParam.insertItemAt(new_dsp,index);
						areaParam.setSelectedIndex(index);
					}
				}
			});
			if (areaParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) areaParam.getSelectedItem();
				areaAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return areaAdvancedButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getColorPanel() {
		if (colorPanel == null) {
			colorPanel = new JPanel();
			colorPanel.setLayout(new BoxLayout(getColorPanel(), BoxLayout.X_AXIS));
			colorPanel.setBorder(BorderFactory.createTitledBorder(null, "Color values", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			colorPanel.add(getColorParam(), null);
			colorPanel.add(Box.createRigidArea(new Dimension(5,0)));
			colorPanel.add(getColorAdvancedButton(), null);
		}
		return colorPanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getColorParam() {
		if (colorParam == null) {
			colorParam = new JComboBox(getParamsToAreaAndColor());
			colorParam.setRenderer(new DataSourceComboBoxRenderer(colorParam));
			colorParam.setPreferredSize(new Dimension(100,26));
			colorParam.setMaximumSize(new Dimension(250,30));
			if (colorParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) colorParam.getSelectedItem();
				colorParam.setToolTipText(dsp.toString());
			}
			colorParam.addActionListener(new java.awt.event.ActionListener() {
				@SuppressWarnings("unchecked")
				public void actionPerformed(java.awt.event.ActionEvent e) {
					displayButton.setEnabled(isUpdateable());
					if (isUpdateable())
						ChartDialogChangeCenter.fireSaveEnabled(RectangleAreaDialog.this);
					else
						ChartDialogChangeCenter.fireSaveDisabled(RectangleAreaDialog.this);
					IDataSourceProducer dsp = (IDataSourceProducer) colorParam.getSelectedItem();
					colorParam.setToolTipText(dsp.toString());
					colorAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
					try {
						// Begins a long operations
						List<Double> list = (List<Double>)ChartConfigCollection.
						getLOPExecutor().execute("Calculating minimum/maximum values",
												 dsp,"getRange");
						setMinMax(list);
					} catch (UserBreakException e1) { 
						setMinMax(null);
					} catch (Throwable t) {
						ChartConfigCollection.getExceptionHandler().uncaughtException(Thread.currentThread(),t);
					}
				}
				
				private void setMinMax(List<Double> minmax) {
					if (minmax != null) {
						cmp.setMinValue(String.valueOf(minmax.get(0).doubleValue()));
						cmp.setMaxValue(String.valueOf(minmax.get(1).doubleValue()));
					} else {
						cmp.setMinValue("");
						cmp.setMaxValue("");
					}
				}
 			});
		}
		return colorParam;
	}
	
	//------------------------------------------------------------------------------
	private JButton getColorAdvancedButton() {
		if (colorAdvancedButton == null) {
			colorAdvancedButton = new JButton();
			colorAdvancedButton.setEnabled(false);
			colorAdvancedButton.setText("Advanced...");
			colorAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer)colorParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(RectangleAreaDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = colorParam.getSelectedIndex();
						colorParam.removeItemAt(index);
						colorParam.insertItemAt(new_dsp,index);
						colorParam.setSelectedIndex(index);
					}
				}
			});
			if (colorParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) colorParam.getSelectedItem();
				colorAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
			}
		}
		return colorAdvancedButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getReq2ParamPanel() {
		if (req2ParamPanel == null) {
			req2ParamPanel = new JPanel();
			req2ParamPanel.setLayout(new BoxLayout(getReq2ParamPanel(), BoxLayout.Y_AXIS));
			req2ParamPanel.add(getNamePanel(), null);
		}
		return req2ParamPanel;
	}

	//------------------------------------------------------------------------------
	private JPanel getNamePanel() {
		if (namePanel == null) {
			namePanel = new JPanel();
			namePanel.setLayout(new BoxLayout(getNamePanel(), BoxLayout.X_AXIS));
			namePanel.setBorder(BorderFactory.createTitledBorder(null, "Names", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, new Font("Dialog", Font.BOLD, 12), new Color(51, 51, 51)));
			namePanel.setPreferredSize(new Dimension(200, 40));
			namePanel.setMaximumSize(new Dimension(32876, 60));
			nameFlag = new JCheckBox("Labelled areas");
			nameFlag.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					if (e.getStateChange() == ItemEvent.SELECTED) {
						nameParam.setEnabled(true);
						IDataSourceProducer dsp = (IDataSourceProducer) nameParam.getSelectedItem();
						nameAdvancedButton.setEnabled(dsp != null && dsp.hasAdvancedSettings());
					} else {
						nameParam.setEnabled(false);
						nameAdvancedButton.setEnabled(false);
					}
				}
			});
			namePanel.add(nameFlag);
			namePanel.add(Box.createRigidArea(new Dimension(10,0)));
			namePanel.add(getNameParam(), null);
			namePanel.add(Box.createRigidArea(new Dimension(5,0)));
			namePanel.add(getNameAdvancedButton(), null);
		}
		return namePanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getNameParam() {
		if (nameParam == null) {
			nameParam = new JComboBox(getParamsToNames());
			nameParam.setRenderer(new DataSourceComboBoxRenderer(nameParam));
			nameParam.setPreferredSize(new Dimension(100,26));
			nameParam.setMaximumSize(new Dimension(200,30));
			nameParam.setEnabled(false);
			if (nameParam.getItemCount() > 0) {
				IDataSourceProducer dsp = (IDataSourceProducer) nameParam.getSelectedItem();
				nameParam.setToolTipText(dsp.toString());
			}
			nameParam.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) nameParam.getSelectedItem();
					nameParam.setToolTipText(dsp.toString());
					nameAdvancedButton.setEnabled(dsp.hasAdvancedSettings());
				}				
			});
		}
		return nameParam;
	}

	//------------------------------------------------------------------------------
	private JButton getNameAdvancedButton() {
		if (nameAdvancedButton == null) {
			nameAdvancedButton = new JButton();
			nameAdvancedButton.setEnabled(false);
			nameAdvancedButton.setText("Advanced...");
			nameAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					IDataSourceProducer dsp = (IDataSourceProducer) nameParam.getSelectedItem();
					IDataSourceProducer new_dsp = dsp.advancedSettingsDialog(RectangleAreaDialog.this.getRootPane().getParent());
					if (new_dsp != null) {
						int index = nameParam.getSelectedIndex();
						nameParam.removeItemAt(index);
						nameParam.insertItemAt(new_dsp,index);
						nameParam.setSelectedIndex(index);
					}
				}
			});
			nameAdvancedButton.setEnabled(false);

		}
		return nameAdvancedButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getTitleLine() {
		if (titleLine == null) {
			jLabel = new JLabel();
			jLabel.setText("  Title:  ");
			jLabel.setPreferredSize(new Dimension(100, 16));
			titleLine = new JPanel();
			titleLine.setLayout(new BoxLayout(getTitleLine(), BoxLayout.X_AXIS));
			titleLine.setPreferredSize(new Dimension(400, 16));
			titleLine.add(jLabel, null);
			titleLine.add(getTitleField(), null);
		}
		return titleLine;
	}

	//------------------------------------------------------------------------------
	private JPanel getSubtitleLine() {
		if (subtitleLine == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("  Subtitle:  ");
			jLabel1.setPreferredSize(new Dimension(100, 16));
			subtitleLine = new JPanel();
			subtitleLine.setLayout(new BoxLayout(getSubtitleLine(), BoxLayout.X_AXIS));
			subtitleLine.setPreferredSize(new Dimension(400, 16));
			subtitleLine.add(jLabel1, null);
			subtitleLine.add(getSubtitleField(), null);
		}
		return subtitleLine;
	}

	//------------------------------------------------------------------------------
	private JPanel getColorbarLine() {
		if (colorbarLine == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("  Colorbar:  ");
			jLabel4.setPreferredSize(new Dimension(100, 16));
			colorbarLine = new JPanel();
			colorbarLine.setLayout(new BoxLayout(getColorbarLine(), BoxLayout.X_AXIS));
			colorbarLine.setPreferredSize(new Dimension(609, 28));
			colorbarLine.setMaximumSize(new Dimension(32831, 28));
			colorbarLine.add(jLabel4, null);
			colorbarLine.add(Box.createRigidArea(new Dimension(35,0)));
			colorbarLine.add(getRadioButtonPanel(), null);
		}
		return colorbarLine;
	}

	//------------------------------------------------------------------------------
	private JTextField getTitleField() {
		if (titleField == null) {
			titleField = new JTextField();
			titleField.setPreferredSize(new Dimension(300, 16));
			titleField.setText(ChartConstants.RECTANGLEAREACHART_NAME);
			titleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.TITLE,titleField.getText());
					ChartDialogChangeCenter.fireTitleChanged(RectangleAreaDialog.this);
				}
			});
			titleField.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					subtitleField.grabFocus();
				}
			});
		}
		return titleField;
	}

	//------------------------------------------------------------------------------
	private JTextField getSubtitleField() {
		if (subtitleField == null) {
			subtitleField = new JTextField();
			subtitleField.setPreferredSize(new Dimension(300, 16));
			subtitleField.addFocusListener(new java.awt.event.FocusAdapter() {
				@Override
				public void focusLost(java.awt.event.FocusEvent e) {
					properties.setProperty(ChartConstants.SUBTITLE,subtitleField.getText());
				}
			});
		}
		return subtitleField;
	}

	//------------------------------------------------------------------------------
	private JPanel getRadioButtonPanel() {
		if (radioButtonPanel == null) {
			radioButtonPanel = new JPanel();
			radioButtonPanel.setLayout(new BoxLayout(getRadioButtonPanel(), BoxLayout.X_AXIS));
			radioButtonPanel.add(getShowRadioButton(), null);
			radioButtonPanel.add(getHideRadioButton(), null);
		}
		return radioButtonPanel;
	}

	//------------------------------------------------------------------------------
	private JRadioButton getShowRadioButton() {
		if (showRadioButton == null) {
			showRadioButton = new JRadioButton();
			showRadioButton.setSelected(true);
			showRadioButton.setText("Show colorbar");
			showRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.COLORBAR,"true");
				}
			});
			colorButtonGroup.add(showRadioButton);
		}
		return showRadioButton;
	}

	//------------------------------------------------------------------------------
	private JRadioButton getHideRadioButton() {
		if (hideRadioButton == null) {
			hideRadioButton = new JRadioButton();
			hideRadioButton.setText("Hide colorbar");
			hideRadioButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					properties.setProperty(ChartConstants.COLORBAR,"false");
				}
			});
			colorButtonGroup.add(hideRadioButton);
		}
		return hideRadioButton;
	}

	//------------------------------------------------------------------------------
	private JPanel getAppearancePanel() {
		if (appearancePanel == null) {
			jLabel2 = new JLabel();
			jLabel2.setText("  Appearance:  ");
			appearancePanel = new JPanel();
			appearancePanel.setLayout(new BoxLayout(getAppearancePanel(), BoxLayout.X_AXIS));
			appearancePanel.setMaximumSize(new Dimension(Integer.MAX_VALUE,25));
			appearancePanel.add(jLabel2, null);
			appearancePanel.add(Box.createRigidArea(new Dimension(26,0)));
			appearancePanel.add(getAppearanceBox(), null);
		}
		return appearancePanel;
	}

	//------------------------------------------------------------------------------
	private JComboBox getAppearanceBox() {
		if (appearanceBox == null) {
			Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
			appearances.add(new ComboboxItem( "BC", "Basic, colored"));
			appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
			appearances.add(new ComboboxItem( "NC", "Normal, colored"));
			appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
			for (String templateNames : AbstractChart.templates.keySet())
				appearances.add(new ComboboxItem("_" + templateNames,templateNames));
			appearances.add(new ComboboxItem("_NEW","New template..."));
			appearances.add(new ComboboxItem("_EDIT","Edit template..."));
			appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
			appearanceBox = new JComboBox(appearances);
			appearanceBox.setPreferredSize(new Dimension(154,25));
			appearanceBox.setMaximumSize(new Dimension(154,25));
			appearanceBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int index = appearanceBox.getSelectedIndex();
					String id = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
					if (index >= 0 && index <= 3) {
				 		String[] code = new String[] { id.substring(0,1), id.substring(1) };
				 		if (code[0].equals("B"))
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.BASIC_APP);
				 		else
				 			ChartConfigCollection.setEnvironmentAppearance(ChartConstants.NORMAL_APP);
				 		if (code[1].equals("BW")) {
				 			ChartConfigCollection.setColorAppearance(ChartConstants.BLACK_AND_WHITE);
				 			cmp.reloadCombobox(true,cmp.getColorMapType().toString());
				 		} else {
				 			ChartConfigCollection.setColorAppearance(ChartConstants.COLORED);
				 			cmp.reloadCombobox(false,cmp.getColorMapType().toString());
				 		}
					} else if (id.equals("_NEW")) {
						ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),null,getLegends(),ChartKind.NORMAL);
						int result = dlg.showDialog();
						if (result == ChartPropertiesDialog.OK_OPTION) {
							Element newTemplate = (Element) dlg.getTemplate();
							dlg.dispose();
							String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
							AbstractChart.templates.put(name,newTemplate);
							ChartDialogChangeCenter.fireTemplateChanged();
							appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
						} else 
							appearanceBox.setSelectedIndex(0);
					} else if (id.equals("_EDIT")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(RectangleAreaDialog.this,"There is no any editable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(RectangleAreaDialog.this,"Select a template: ","Edit template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template == null || "".equals(template)) 
							appearanceBox.setSelectedIndex(0);
						else {
							Element templateElement = AbstractChart.templates.get(template);
							ChartPropertiesDialog dlg = new ChartPropertiesDialog(findActiveFrame(),AbstractChart.templates.keySet(),templateElement,getLegends(),ChartKind.NORMAL);
							int result = dlg.showDialog();
							if (result == ChartPropertiesDialog.OK_OPTION) {
								Element newTemplate = (Element) dlg.getTemplate();
								dlg.dispose();
								String name = newTemplate.getAttribute(ChartConstants.REF_ID_ATTR);
								AbstractChart.templates.put(name,newTemplate);
								ChartDialogChangeCenter.fireTemplateChanged();
								appearanceBox.setSelectedItem(new ComboboxItem("_" + name,name));
							} else 
								appearanceBox.setSelectedIndex(0);
						}
					} else if (id.equals("_REMOVE")) {
						String[] templates = AbstractChart.templates.keySet().toArray(new String[0]);
						if (templates.length == 0) {
							JOptionPane.showMessageDialog(RectangleAreaDialog.this,"There is no any deletable template.","Message",JOptionPane.PLAIN_MESSAGE,null);
							appearanceBox.setSelectedIndex(0);
							return;
						} 
						String template = (String)JOptionPane.showInputDialog(RectangleAreaDialog.this,"Select a template: ","Delete template",
																	  		  JOptionPane.PLAIN_MESSAGE,null,templates,templates[0]);
						if (template != null && !"".equals(template)) { 
							AbstractChart.templates.remove(template);
							File file = new File("Templates/" + template + ".xml");
							file.delete();
							ChartDialogChangeCenter.fireTemplateChanged();
						}
						appearanceBox.setSelectedIndex(0);
					}
				}
			});
		}
		return appearanceBox;
	}
	
	//------------------------------------------------------------------------------
	private List<String> getLegends() {	return new ArrayList<String>(); }

	//=============================================================================
	
	////////////////////////////////////////////////////////////////////////////
	// non-generated functions                                                //
	////////////////////////////////////////////////////////////////////////////
	
	//----------------------------------------------------------------------------------------------------
	/** Returns the current data source of the color values.
	 * @return the current data source of the color values
	 */ 
	public IDataSourceProducer getColorValueProducer() {
		IDataSourceProducer selected = (IDataSourceProducer) colorParam.getSelectedItem();
		return selected;
	}
	
	//----------------------------------------------------------------------------------------------------
	public void setUpdateStatus(boolean status) {
		boolean paramsAvailable = areaParam.getItemCount() > 0 && colorParam.getItemCount() > 0 && (!nameFlag.isSelected() || nameParam.getItemCount() > 0);
		displayButton.setEnabled(paramsAvailable && status);
		if (paramsAvailable && status)
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else 
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}

	
	//------------------------------------------------------------------------------
	@Override
	protected void setWidgetDisabled() {
		if (areaParam.getItemCount() == 0) {
			areaParam.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			areaAdvancedButton.setEnabled(false);
		}
		if (colorParam.getItemCount() == 0) {
			colorParam.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
			colorAdvancedButton.setEnabled(false);
		}
		if (nameParam.getItemCount() == 0) {
			nameFlag.setEnabled(false);
			nameParam.setEnabled(false);
			nameAdvancedButton.setEnabled(false);
			displayButton.setEnabled(false);
			saveButton.setEnabled(false);
		}
	}
		
	//------------------------------------------------------------------------------
	/** Returns the displayable names of the data sources for area and color values.
	 * @return array of data sources
	 */
 	private Object[] getParamsToAreaAndColor() {
 		return getParams(new Class[] { ISeriesProducer.class, IValueProducer.class });
 	}
 	
	//------------------------------------------------------------------------------
 	/** Returns the displayable names of the data sources for names.
 	 * @return array of data sources
 	 */
 	private Object[] getParamsToNames() {
 		return getParams(IStringListProducer.class);
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	protected void setSettingsFromConfig() {
 		if (config.getChartProperties() instanceof Properties) {
 			// set settings from config
 			properties = (Properties) config.getChartProperties();
 			int[] ds = Utilities.splitDatasourceAroundCommas(properties.getProperty(ChartConstants.DATASOURCE));
 			IDataSourceProducer dsp = config.getDataSource(ds[0]);
 			areaParam.setSelectedItem(dsp);
 			dsp = config.getDataSource(ds[1]);
 			colorParam.setSelectedItem(dsp);
 			if (ds.length > 2) {
 				nameFlag.setSelected(true);
 				dsp = config.getDataSource(ds[2]);
 				nameParam.setSelectedItem(dsp);
 			}
 			titleField.setText(properties.getProperty(ChartConstants.TITLE));
 			subtitleField.setText(properties.getProperty(ChartConstants.SUBTITLE));
			String templateRefId = properties.getProperty(ChartConstants.CUSTOM_APPEARANCE);
			boolean isBlackAndWhite = false;
 			if (templateRefId != null) 
 				appearanceBox.setSelectedItem(new ComboboxItem("_" + templateRefId,templateRefId));
 			else {
	 			String appearanceCode = "";
	 			appearanceCode += properties.getProperty(ChartConstants.ENV_APPEARANCE,"").equals(ChartConstants.NORMAL_APP) ? "N" : "B";
	 			isBlackAndWhite = properties.getProperty(ChartConstants.COLOR_APPEARANCE,"").equals(ChartConstants.BLACK_AND_WHITE);
	 			appearanceCode += isBlackAndWhite ? "BW" : "C";
	 			for (int i = 0;i < appearanceBox.getItemCount();++i) {
	 				String id = ((ComboboxItem)appearanceBox.getItemAt(i)).getID().toString();
	 				if (id.equals(appearanceCode)) {
	 					appearanceBox.setSelectedIndex(i);
	 					break;
	 				}
	 			}
 			}
 			cmp.settingsFromString(properties.getProperty(ChartConstants.COLORMAP),isBlackAndWhite);
 			boolean colorbar = Boolean.parseBoolean(properties.getProperty(ChartConstants.COLORBAR));
 			if (!colorbar)
 				hideRadioButton.setSelected(true);
 			saveButton.setEnabled(true);
 		} else {
 			// set initial properties
 			properties.setProperty(ChartConstants.TITLE,ChartConstants.RECTANGLEAREACHART_NAME);
 			properties.setProperty(ChartConstants.SUBTITLE,"");
 			properties.setProperty(ChartConstants.COLORBAR,"true");
 			int appIndex = 0;
 			appIndex += ChartConfigCollection.getColorAppearance().equals(ChartConstants.BLACK_AND_WHITE) ? 1 : 0;
 			appIndex += ChartConfigCollection.getEnvironmentAppearance().equals(ChartConstants.NORMAL_APP) ? 2 : 0;
 			appearanceBox.setSelectedIndex(appIndex);
 		}
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	public void updateChartConfig() {
 		config.clearAllDataSource();
 		IDataSourceProducer dsp = (IDataSourceProducer) areaParam.getSelectedItem();
 		int key = -1;
 		if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
 			key = config.addDataSource(dsp,ISeriesProducer.class);
 		else
 			key = config.addDataSource(dsp,IValueProducer.class);
 		String ds = String.valueOf(key) + ",";
 		dsp = (IDataSourceProducer) colorParam.getSelectedItem();
 		if (dsp.getSupportedIntfs().contains(ISeriesProducer.class))
 			key = config.addDataSource(dsp,ISeriesProducer.class);
 		else
 			key = config.addDataSource(dsp,IValueProducer.class);
 		ds += String.valueOf(key);
 		if (nameFlag.isSelected()) {
 			ds +=  ",";
 			dsp = (IDataSourceProducer) nameParam.getSelectedItem();
 			if (dsp.getSupportedIntfs().contains(IStringListProducer.class)) { // source supports IStringListProducer
 				key = config.addDataSource(dsp,IStringListProducer.class);
 				ds += String.valueOf(key);
 			} else { // source supports IStringSeriesProducer
 				key = config.addDataSource(dsp,IStringSeriesProducer.class);
 				ds += String.valueOf(key);
 			}
 		}
 		properties.setProperty(ChartConstants.DATASOURCE,ds);
		int appearanceIndex = appearanceBox.getSelectedIndex();
 		String appearanceCode = ((ComboboxItem)appearanceBox.getSelectedItem()).getID().toString();
		if (appearanceIndex >= 0 && appearanceIndex <= 3) {
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,"");
	 		String[] code = new String[] { appearanceCode.substring(0,1), appearanceCode.substring(1) };
	 		if (code[0].equals("B"))
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.BASIC_APP);
	 		else
	 			properties.setProperty(ChartConstants.ENV_APPEARANCE,ChartConstants.NORMAL_APP);
	 		if (code[1].equals("BW"))
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.BLACK_AND_WHITE);
	 		else
	 			properties.setProperty(ChartConstants.COLOR_APPEARANCE,ChartConstants.COLORED);
		} else {
			appearanceCode = appearanceCode.substring(1);
			properties.setProperty(ChartConstants.CUSTOM_APPEARANCE,appearanceCode);
		}
 		properties.setProperty(ChartConstants.COLORMAP,cmp.settingsToString());
 		config.setChartProperties(ChartConstants.RECTANGLEAREACHART,properties);
 	}
 	
	//------------------------------------------------------------------------------
 	@Override
 	public boolean isUpdateable() {
 		if (areaParam.getItemCount() == 0 || colorParam.getItemCount() == 0 ||
 			(nameParam.getItemCount() == 0 && nameFlag.isSelected()) || !cmp.hasDefinedColormap()) return false;
 		return true;
 	}

	//------------------------------------------------------------------------------
	@Override
	protected void displayPreview() throws Exception {
		DataSources ds = new DataSources(new SimpleDSPCollection());
		ChartConfig temp_config = new ChartConfig(ds);
		temp_config.setFireInitialEvent(true);
		List<IDataSourceProducer> dsl = ds.getDSPCollection().getList();
		Properties temp_prop = (Properties) properties.clone();
		temp_config.addDataSource(dsl.get(0),ISeriesProducer.class);
		temp_config.addDataSource(dsl.get(3),IStringSeriesProducer.class);
		temp_prop.setProperty(ChartConstants.DATASOURCE,"1,2,2");
		temp_prop.setProperty(ChartConstants.TITLE,temp_prop.getProperty(ChartConstants.TITLE) + " (Preview illustration)");
		temp_config.setChartProperties(ChartConstants.RECTANGLEAREACHART,temp_prop);
		Utilities.displayPreview(temp_config);
	}
	
	//------------------------------------------------------------------------------
	@Override
	public void reloadAppearanceTemplates() {
		ComboboxItem selected = (ComboboxItem) appearanceBox.getSelectedItem();
		Vector<ComboboxItem> appearances = new Vector<ComboboxItem>();
		appearances.add(new ComboboxItem( "NC", "Normal, colored"));
		appearances.add(new ComboboxItem( "BC", "Basic, colored"));
		appearances.add(new ComboboxItem("BBW", "Basic, black-and-white"));
		appearances.add(new ComboboxItem("NBW", "Normal, black-and-white"));
		for (String templateNames : AbstractChart.templates.keySet())
			appearances.add(new ComboboxItem("_" + templateNames,templateNames));
		appearances.add(new ComboboxItem("_NEW","New template..."));
		appearances.add(new ComboboxItem("_EDIT","Edit template..."));
		appearances.add(new ComboboxItem("_REMOVE","Remove template..."));
		appearanceBox.setModel(new DefaultComboBoxModel(appearances));
		for (int i = 0;i < appearanceBox.getItemCount();++i) {
			ComboboxItem item = (ComboboxItem)appearanceBox.getItemAt(i);
			if (item.equals(selected)) {
				appearanceBox.setSelectedIndex(i);
				return;
			}
		}
		appearanceBox.setSelectedIndex(0);
	}
	
	//----------------------------------------------------------------------------------------------------
	@SuppressWarnings("cast")
	@Override
	public void reloadDataSources() {
		boolean nFlag = nameFlag.isSelected();
		
		// reset widgets
		areaParam.setEnabled(true);
		areaAdvancedButton.setEnabled(true);
		colorParam.setEnabled(true);
		colorAdvancedButton.setEnabled(true);
		nameParam.setEnabled(true);
		nameAdvancedButton.setEnabled(true);
		nameFlag.setSelected(true);
		
		Object areaObject = areaParam.getSelectedIndex() == -1 ? null : areaParam.getSelectedItem();
		Object colorObject = colorParam.getSelectedIndex() == -1 ? null : colorParam.getSelectedItem();
		Object nameObject = nameParam.getSelectedIndex() == -1 ? null : nameParam.getSelectedItem();

		
		DefaultComboBoxModel areaModel = new DefaultComboBoxModel(getParamsToAreaAndColor());
		areaParam.setModel(areaModel);
		DefaultComboBoxModel colorModel = new DefaultComboBoxModel(getParamsToAreaAndColor());
		colorParam.setModel(colorModel);
		DefaultComboBoxModel nameModel = new DefaultComboBoxModel(getParamsToNames());
		nameParam.setModel(nameModel);
		
		if (areaObject != null && findInComboBox(areaModel,(IDataSourceProducer)areaObject) != -1) {
			int idx = findInComboBox(areaModel,(IDataSourceProducer)areaObject);
			areaParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (colorObject != null && findInComboBox(colorModel,(IDataSourceProducer)colorObject) != -1) {
			int idx = findInComboBox(colorModel,(IDataSourceProducer)colorObject);
			colorParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		if (nameObject != null && findInComboBox(nameModel,(IDataSourceProducer)nameObject) != -1) {
			int idx = findInComboBox(nameModel,(IDataSourceProducer)nameObject);
			nameParam.setSelectedIndex(idx >= 0 ? idx : 0);
		}
		
		if (nameParam.getItemCount() > 0)
			nameFlag.setEnabled(true);
		
		validate();
		setWidgetDisabled();
		nameFlag.setSelected(nameFlag.isEnabled() && nFlag);
		displayButton.setEnabled(isUpdateable());
		if (isUpdateable()) 
			ChartDialogChangeCenter.fireSaveEnabled(this);
		else
			ChartDialogChangeCenter.fireSaveDisabled(this);
	}
}