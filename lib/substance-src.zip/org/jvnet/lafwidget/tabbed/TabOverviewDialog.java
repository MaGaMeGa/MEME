/*
 * Copyright (c) 2005-2007 Laf-Widget Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Laf-Widget Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.lafwidget.tabbed;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.text.MessageFormat;

import javax.swing.*;
import javax.swing.border.*;

import org.jvnet.lafwidget.*;
import org.jvnet.lafwidget.layout.TransitionLayoutManager;
import org.jvnet.lafwidget.tabbed.TabPreviewThread.TabPreviewInfo;
import org.jvnet.lafwidget.utils.LafConstants.AnimationKind;

/**
 * Tab overview dialog.
 * 
 * @author Kirill Grouchnikov
 */
public class TabOverviewDialog extends JDialog {
	/**
	 * The associated tabbed pane.
	 */
	protected JTabbedPane tabPane;

	/**
	 * The overview panel (with all thumbnails).
	 */
	protected JPanel overviewPanel;

	/**
	 * The associated preview callback.
	 */
	protected TabPreviewThread.TabPreviewCallback previewCallback;

	/**
	 * Handles mouse events on the tab overview dialog (such as highlighting the
	 * currently rolled-over tab preview, closing the overview when a tab
	 * preview is clicked, tooltips etc.)
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class TabPreviewMouseHandler extends MouseAdapter {
		/**
		 * Tab index.
		 */
		private int index;

		/**
		 * Tab preview control.
		 */
		private TabPreviewControl previewControl;

		/**
		 * Creates the mouse handler for a single tab preview control.
		 * 
		 * @param index
		 *            Tab index.
		 * @param previewControl
		 *            Tab preview control.
		 */
		public TabPreviewMouseHandler(int index,
				TabPreviewControl previewControl) {
			this.index = index;
			this.previewControl = previewControl;
		}

		public void mouseClicked(MouseEvent e) {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					TabOverviewDialog.this.dispose();
					TabOverviewDialog.this.tabPane
							.setSelectedIndex(TabPreviewMouseHandler.this.index);
				}
			});
		}

		public void mouseEntered(MouseEvent e) {
			boolean isSelected = (TabOverviewDialog.this.tabPane
					.getSelectedIndex() == this.index);
			if (isSelected)
				this.previewControl.setBorder(new LineBorder(Color.blue, 2));
			else
				this.previewControl.setBorder(new CompoundBorder(
						new EmptyBorder(1, 1, 1, 1), new LineBorder(
								Color.black, 1)));
		}

		public void mouseExited(MouseEvent e) {
			boolean isSelected = (TabOverviewDialog.this.tabPane
					.getSelectedIndex() == this.index);
			if (isSelected)
				this.previewControl.setBorder(new LineBorder(Color.black, 2));
			else
				this.previewControl.setBorder(new CompoundBorder(
						new EmptyBorder(1, 1, 1, 1), new LineBorder(
								Color.black, 1)));
		}
	}

	/**
	 * Tab overview panel. Contains a grid of tab preview widgets. The widgets
	 * are created in a separate thread ({@link TabPreviewThread}) and offered
	 * to the tab overview dialog via the registered implementation of
	 * {@link TabPreviewThread.TabPreviewCallback}. This way the application
	 * stays interactive while the tab overview dialog is being populated.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class TabOverviewPanel extends JPanel {
		/**
		 * Tab preview controls.
		 */
		protected TabPreviewControl[] previewControls;

		/**
		 * Width of a single tab preview control.
		 */
		protected int pWidth;

		/**
		 * Height of a single tab preview control.
		 */
		protected int pHeight;

		/**
		 * Number of overview grid columns.
		 */
		protected int colCount;

		/**
		 * Creates a tab overview panel.
		 * 
		 * @param dialogWidth
		 *            The width of the parent dialog.
		 * @param dialogHeight
		 *            The height of the parent dialog.
		 */
		public TabOverviewPanel(final int dialogWidth, final int dialogHeight) {
			// int tabCount = TabOverviewDialog.this.tabPane.getTabCount();

			TabPreviewThread.TabPreviewCallback previewCallback = new TabPreviewThread.TabPreviewCallback() {
				/*
				 * (non-Javadoc)
				 * 
				 * @see org.jvnet.lafwidget.tabbed.TabPreviewThread.TabPreviewCallback#start(javax.swing.JTabbedPane,
				 *      int,
				 *      org.jvnet.lafwidget.tabbed.TabPreviewThread.TabPreviewInfo)
				 */
				public void start(JTabbedPane tabPane, int tabCount,
						TabPreviewInfo tabPreviewInfo) {
					// Check if need to reallocate the preview controls.
					boolean isSame = (previewControls != null)
							&& (previewControls.length == tabCount);
					if (isSame)
						return;

					if (previewControls != null) {
						for (int i = 0; i < previewControls.length; i++) {
							remove(previewControls[i]);
						}
					}

					colCount = (int) Math.sqrt(tabCount);
					if (colCount * colCount < tabCount)
						colCount++;

					pWidth = (dialogWidth - 8) / colCount;
					pHeight = (dialogHeight - 32) / colCount;

					tabPreviewInfo.previewWidth = pWidth - 4;
					tabPreviewInfo.previewHeight = pHeight - 20;

					previewControls = new TabPreviewControl[tabCount];
					TabPreviewPainter tpp = LafWidgetUtilities
							.getTabPreviewPainter(TabOverviewDialog.this.tabPane);
					for (int i = 0; i < tabCount; i++) {
						TabPreviewControl previewControl = new TabPreviewControl(
								TabOverviewDialog.this.tabPane, i);
						// fix for issue 177 in Substance (disallowing selection
						// of disabled tabs).
						if (tpp.isSensitiveToEvents(
								TabOverviewDialog.this.tabPane, i)) {
							previewControl
									.addMouseListener(new TabPreviewMouseHandler(
											i, previewControl));
							previewControl
									.setToolTipText(LafWidgetRepository
											.getLabelBundle()
											.getString(
													"TabbedPane.overviewWidgetTooltip"));
						}
						previewControls[i] = previewControl;
						add(previewControl);
					}

					doLayout();
					for (int i = 0; i < tabCount; i++) {
						previewControls[i].revalidate();
					}
					repaint();
				}

				/*
				 * (non-Javadoc)
				 * 
				 * @see org.jvnet.lafwidget.tabbed.TabPreviewThread.TabPreviewCallback#offer(javax.swing.JTabbedPane,
				 *      int, java.awt.image.BufferedImage)
				 */
				public void offer(JTabbedPane tabPane, int tabIndex,
						BufferedImage componentSnap) {
					TabOverviewPanel.this.previewControls[tabIndex]
							.setPreviewImage(componentSnap);
				}
			};

			this.setLayout(new TabOverviewPanelLayout());
			this
					.putClientProperty(LafWidget.ANIMATION_KIND,
							AnimationKind.SLOW);
			TransitionLayoutManager.getInstance().track(this, true);

			// this.pWidth = (dialogWidth - 8) / this.colCount;
			// this.pHeight = (dialogHeight - 32) / this.colCount;
			//
			TabPreviewInfo previewInfo = new TabPreviewInfo();
			previewInfo.tabPane = TabOverviewDialog.this.tabPane;
			previewInfo.previewCallback = previewCallback;
			// previewInfo.previewWidth = this.pWidth - 4;
			// previewInfo.previewHeight = this.pHeight - 20;
			previewInfo.toPreviewAllTabs = true;
			previewInfo.initiator = TabOverviewDialog.this;

			TabPreviewThread.getInstance().queueTabPreviewRequest(previewInfo);
		}

		/**
		 * Layout manager for the tab overview panel.
		 * 
		 * @author Kirill Grouchnikov
		 */
		private class TabOverviewPanelLayout implements LayoutManager {
			/*
			 * (non-Javadoc)
			 * 
			 * @see java.awt.LayoutManager#addLayoutComponent(java.lang.String,
			 *      java.awt.Component)
			 */
			public void addLayoutComponent(String name, Component comp) {
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.awt.LayoutManager#removeLayoutComponent(java.awt.Component)
			 */
			public void removeLayoutComponent(Component comp) {
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
			 */
			public void layoutContainer(Container parent) {
				// int width = parent.getWidth();
				// int height = parent.getHeight();
				//
				if (TabOverviewPanel.this.previewControls == null)
					return;

				for (int i = 0; i < TabOverviewPanel.this.previewControls.length; i++) {
					TabPreviewControl previewControl = TabOverviewPanel.this.previewControls[i];
					if (previewControl == null)
						continue;
					int rowIndex = i / TabOverviewPanel.this.colCount;
					int colIndex = i % TabOverviewPanel.this.colCount;

					previewControl.setBounds(colIndex
							* TabOverviewPanel.this.pWidth, rowIndex
							* TabOverviewPanel.this.pHeight,
							TabOverviewPanel.this.pWidth,
							TabOverviewPanel.this.pHeight);
				}
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.awt.LayoutManager#minimumLayoutSize(java.awt.Container)
			 */
			public Dimension minimumLayoutSize(Container parent) {
				return parent.getSize();
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.awt.LayoutManager#preferredLayoutSize(java.awt.Container)
			 */
			public Dimension preferredLayoutSize(Container parent) {
				return this.minimumLayoutSize(parent);
			}
		}
	}

	/**
	 * Creates a new tab overview dialog. Declared private to enforce usage of
	 * {@link #getOverviewDialog(JTabbedPane)}.
	 * 
	 * @param tabPane
	 *            Tabbed pane.
	 * @param owner
	 *            Optional owner for the tab overview dialog.
	 * @param modal
	 *            Modality indication.
	 * @param dialogWidth
	 *            Tab overview dialog width.
	 * @param dialogHeight
	 *            Tab overview dialog height.
	 * @throws HeadlessException
	 * @see #getOverviewDialog(JTabbedPane)
	 */
	private TabOverviewDialog(final JTabbedPane tabPane, Frame owner,
			boolean modal, int dialogWidth, int dialogHeight)
			throws HeadlessException {
		super(owner, modal);
		this.tabPane = tabPane;
		this.setLayout(new BorderLayout());
		this.overviewPanel = new TabOverviewPanel(dialogWidth, dialogHeight);
		this.add(this.overviewPanel, BorderLayout.CENTER);

		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.setResizable(false);

		// Cancel all pending preview requests issued by this overview
		// dialog when it closes.
		this.addWindowListener(new WindowAdapter() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see java.awt.event.WindowAdapter#windowClosing(java.awt.event.WindowEvent)
			 */
			public void windowClosing(WindowEvent e) {
				this.cancelRequests();
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.awt.event.WindowAdapter#windowClosed(java.awt.event.WindowEvent)
			 */
			public void windowClosed(WindowEvent e) {
				this.cancelRequests();
			}

			/**
			 * Cancels preview requests issued by <code>this</code> overview
			 * dialog.
			 */
			private void cancelRequests() {
				if (TabPreviewThread.instanceRunning()) {
					TabPreviewThread.getInstance().cancelTabPreviewRequests(
							TabOverviewDialog.this);
				}
			}
		});
	}

	/**
	 * Returns a new instance of a tab overview dialog.
	 * 
	 * @param tabPane
	 *            Tabbed pane.
	 * @return Tab overview dialog for the specified tabbed pane.
	 */
	public static TabOverviewDialog getOverviewDialog(JTabbedPane tabPane) {
		TabPreviewPainter previewPainter = LafWidgetUtilities
				.getTabPreviewPainter(tabPane);
		String title = previewPainter.toUpdatePeriodically(tabPane) ? MessageFormat
				.format(LafWidgetRepository.getLabelBundle().getString(
						"TabbedPane.overviewDialogTitleRefresh"),
						new Object[] { new Integer(previewPainter
								.getUpdateCycle(tabPane) / 1000) })
				: LafWidgetRepository.getLabelBundle().getString(
						"TabbedPane.overviewDialogTitle");
		JFrame frameForModality = previewPainter.getModalOwner(tabPane);
		boolean isModal = (frameForModality != null);
		Rectangle dialogScreenBounds = previewPainter
				.getPreviewDialogScreenBounds(tabPane);
		TabOverviewDialog overviewDialog = new TabOverviewDialog(tabPane,
				frameForModality, isModal, dialogScreenBounds.width,
				dialogScreenBounds.height);
		overviewDialog.setTitle(title);

		overviewDialog.setLocation(dialogScreenBounds.x, dialogScreenBounds.y);
		overviewDialog.setSize(dialogScreenBounds.width,
				dialogScreenBounds.height);

		return overviewDialog;
	}
}
