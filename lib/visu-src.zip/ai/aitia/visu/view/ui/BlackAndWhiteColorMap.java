package ai.aitia.visu.view.ui;

import java.awt.Color;

public class BlackAndWhiteColorMap implements ColorMap {

	//====================================================================================================
	// members
	
	private static final float UNIT = 0.00390625f;
	private double minLevel, maxLevel;
	private Color defaultColor = Color.BLACK;
	
	//====================================================================================================
	// methods
	
	//----------------------------------------------------------------------------------------------------
	public BlackAndWhiteColorMap(double minLevel, double maxLevel) {
		this.minLevel = minLevel;
		this.maxLevel = maxLevel;
	}
	
	//----------------------------------------------------------------------------------------------------
	public void setMaxLevel(double maxLevel) { this.maxLevel = maxLevel; }
	public void setMinLevel(double minLevel) { this.minLevel = minLevel; }
	
	//====================================================================================================
	// implemented interfaces
	
	//----------------------------------------------------------------------------------------------------
	public double defaultValue() { return minLevel; }
	public int getAlpha(double value) {	return getColor(value).getAlpha(); }
	public Color getDefaultColor() { return defaultColor; }
	public double getMaxLevel() { return maxLevel; }
	public double getMinLevel() { return minLevel; }
	public int getRGB(double value) { return getColor(value).getRGB(); }
	
	//----------------------------------------------------------------------------------------------------
	public Color getColor(double value) {
		int izV = (int) (253 * (value - this.minLevel)
				/ (this.maxLevel - this.minLevel)) + 2;
		
		if (izV < 0 || izV > 255) return defaultColor;
		float f = izV * UNIT;
		return new Color(f,f,f);
	}

	//----------------------------------------------------------------------------------------------------
	public boolean validLevel(double level) {
		return (minLevel <= level && level <= maxLevel);
	}

	//----------------------------------------------------------------------------------------------------
	public String getName() {
		StringBuilder result = new StringBuilder("Black-and-white colormap");
		if (minLevel != - Double.MAX_VALUE || maxLevel != Double.MAX_VALUE) {
			result.append(" [");
			result.append(minLevel == - Double.MAX_VALUE ? "" : String.valueOf(minLevel));
			result.append("..");
			result.append(maxLevel == Double.MAX_VALUE ? "" : String.valueOf(maxLevel));
			result.append("]");
		}
		return result.toString();
	}
}