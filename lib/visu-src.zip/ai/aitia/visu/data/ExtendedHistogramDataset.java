package ai.aitia.visu.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.xy.AbstractIntervalXYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.util.ObjectUtilities;
import org.jfree.util.PublicCloneable;

public class ExtendedHistogramDataset extends AbstractIntervalXYDataset
		implements IntervalXYDataset, Serializable, PublicCloneable, Cloneable {

	private static final long serialVersionUID = -2845493267084776277L;
	
	public static final int FREQUENCY = 0;
	public static final int SUM = 1;
	public static final int MEAN = 2;

    /** List of bins */
	List<ExtendedBin> binList = null;
	
	List<Double> values = null;
	
	/** Type of the histogram. */
	private int type = 0;
	
	/** Dataset id. */
	private Comparable key = null;

    /** An integer field that says what we do with the values out of bounds (min, max). */
    private int strategy;
    
    /** A hashmap for the outlier values. */
    private TreeMap<Double,Integer> outliers;
    
    private boolean automaticMinValue = false;
    private boolean automaticMaxValue = false;
    
    private double actMinValue;
    private double actMaxValue;

    public ExtendedHistogramDataset(int type, int strategy) {
    	this.binList = new ArrayList<ExtendedBin>();
    	this.values = new ArrayList<Double>();
    	this.type = type;
    	this.strategy = strategy;
    	this.outliers = new TreeMap<Double,Integer>();
    	this.actMinValue =  - Double.MAX_VALUE;
    	this.actMaxValue = Double.MAX_VALUE;
    }
    
    public ExtendedHistogramDataset(int type) {
    	this(type,1);
    }
    
    public ExtendedHistogramDataset() {
    	this(FREQUENCY,1);
    }
    
    public TreeMap<Double,Integer> getOutliers() {
    	return outliers;
    }

    public int getType() { 
    	return type;
    }
    
    public void setType(int type) {
    	if (type < 0 || type > 2) throw new IllegalArgumentException("Illegal 'type' argument.");
    	this.type = type;
    	notifyListeners(new DatasetChangeEvent(this,this));
    }
	
    /**
     * Adds a series to the dataset. Any data value falling on a bin boundary 
     * will be assigned to the lower value bin, with the exception of the lower 
     * bound of the bin range which is always assigned to the first bin.
     * 
     * @param key  the series key (<code>null</code> not permitted).
     * @param values  the raw observations.
     * @param bins  the number of bins.
     * @param minimum  the lower bound of the bin range.
     * @param maximum  the upper bound of the bin range.
     */
    public void addSeries(Comparable key, 
                          List<Double> values, 
                          int bins, 
                          double minimum, 
                          double maximum) {
        
        if (key == null) {
            throw new IllegalArgumentException("Null 'key' argument.");   
        }
        if (values == null) {
            throw new IllegalArgumentException("Null 'values' argument.");
        }
        else if (bins < 1) {
            throw new IllegalArgumentException(
                "The 'bins' value must be at least 1."
            );
        }
        this.key = key;
        this.values.clear();
        this.outliers.clear();
        double actMin, actMax;
        if (minimum == - Double.MAX_VALUE)  { // automatic min value 
        	automaticMinValue = true;
        	actMin = Double.MAX_VALUE;
        	for (int i=0;i<values.size();++i) 
        		if (actMin > values.get(i).doubleValue()) actMin = values.get(i).doubleValue();
        } else actMin = minimum;
        if (maximum == Double.MAX_VALUE) { // automatic max value
        	automaticMaxValue = true;
        	actMax = - Double.MAX_VALUE;
        	for (int i=0;i<values.size();++i)
        		if (actMax < values.get(i).doubleValue()) actMax = values.get(i).doubleValue();
        } else actMax = maximum;
        if (actMin != Double.MAX_VALUE) actMinValue = actMin;
        if (actMax != - Double.MAX_VALUE) actMaxValue = actMax;

        
        double binWidth = (actMax - actMin) / bins;

        double tmp = actMin;
        binList = new ArrayList<ExtendedBin>(bins);
        for (int i = 0; i < bins; i++) {
            ExtendedBin bin;
            // make sure bins[bins.length]'s upper boundary ends at maximum
            // to avoid the rounding issue. the bins[0] lower boundary is
            // guaranteed start from min
            if (i == bins - 1) {
                bin = new ExtendedBin(tmp,actMax);
            }
            else {
                bin = new ExtendedBin(tmp,tmp+binWidth);
            }
            tmp = tmp + binWidth;
            binList.add(bin);
        }     
        
        // fill the bins
        for (int i = 0; i < values.size(); i++) {
        	if ((values.get(i).doubleValue() < actMin || values.get(i).doubleValue() > actMax)) {
        		if (strategy == 0) {
        			Integer count = outliers.get(values.get(i));
        			if (count == null) {
        				outliers.put(values.get(i),new Integer(1));
        			} else {
        				outliers.put(values.get(i), count+1);
        			}
        		}
        		if (strategy != 1) continue;
        	}
            int binIndex = bins - 1;
            if (values.get(i).doubleValue() < actMin) {
            	binIndex = 0;
            } else if (values.get(i).doubleValue() < actMax) {
                double fraction = (values.get(i).doubleValue() - actMin) / (actMax - actMin);
                binIndex = (int) (fraction * bins);
            }
            ExtendedBin bin = binList.get(binIndex);
            bin.incrementValue(values.get(i).doubleValue());
            this.values.add(values.get(i));
        }
    }
    
    public void addValue(double value) {
    	
    	final int bins = binList.size();
    	
    	int binIndex = bins - 1;
    	boolean boundChange = false;
    	
    	double min, max;
    	min = actMinValue == - Double.MAX_VALUE ? Double.MAX_VALUE : actMinValue;
    	max = actMaxValue == Double.MAX_VALUE ? - Double.MAX_VALUE : actMaxValue; 
    	if (automaticMinValue && value < min) {
    		min = value;
    		boundChange = true;
    	}
    	if (automaticMaxValue && value > max) {
    		max = value;
    		boundChange = true;
    	}
    	if (boundChange) {
    		// recalculate the bins
    		addSeries(this.key,this.values,bins,min,max);
    		actMinValue = min;
    		actMaxValue = max;
    	}
    	
    	if ((value < min || value > max)) {
    		if (strategy == 0) {
    			Integer count = outliers.get(new Double(value));
    			if (count == null) {
    				outliers.put(new Double(value),new Integer(1));
    			} else {
    				outliers.put(new Double(value), count+1);
    			}
    		}
    		if (strategy != 1) return;
    	}

    	if (value < min) {
        	binIndex = 0;
        } else if (value < max) {
    		double fraction = (value - min) / (max - min);
    		binIndex = (int) (fraction * bins);
    	}
    	
        ExtendedBin bin = binList.get(binIndex);
        bin.incrementValue(value);
        values.add(new Double(value));
        
        notifyListeners(new DatasetChangeEvent(this, this));
    }
    
   public void replaceValues(List<Double> values) {
	   if (automaticMinValue) this.actMinValue = - Double.MAX_VALUE;
	   if (automaticMaxValue) this.actMaxValue = Double.MAX_VALUE;
	    addSeries(this.key,values,binList.size(),actMinValue,actMaxValue);
        notifyListeners(new DatasetChangeEvent(this, this));
    }
   
   public List<ExtendedBin> getBins() {
	   return binList;
   }
    
   
	@Override
	public int getSeriesCount() {
		return 1;
	}

	@Override
	public Comparable getSeriesKey(int series) {
		return key;
	}
	
	public int getItemCount(int series) {
		return binList.size();
	}

	public Number getEndX(int series, int item) {
	   	ExtendedBin bin = binList.get(item);
    	return new Double(bin.getEndBoundary());
 	}

	public Number getEndY(int series, int item) {
        return getY(series, item);
    }

	public Number getStartX(int series, int item) {
    	ExtendedBin bin = binList.get(item);
    	return new Double(bin.getStartBoundary());
 	}

	public Number getStartY(int series, int item) {
        return getY(series, item);
    }

	public Number getX(int series, int item) {
	   	ExtendedBin bin = binList.get(item);
    	double x = (bin.getStartBoundary() + bin.getEndBoundary()) / 2.;
    	return new Double(x);
 	}

	public Number getY(int series, int item) {
	   	ExtendedBin bin = binList.get(item);
    	if (type == SUM) return new Double(bin.getValue());
    	else if (type == FREQUENCY) return new Double(bin.getCounter());
    	else if (type == MEAN) return new Double(bin.getMeanValue());
    	else throw new IllegalStateException();
 	}
	
   @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;   
        }
        if (!(obj instanceof ExtendedHistogramDataset)) {
            return false;
        }
        ExtendedHistogramDataset that = (ExtendedHistogramDataset) obj;
        if (this.strategy != that.strategy) return false;
        if (this.automaticMinValue != that.automaticMinValue) return false;
        if (this.automaticMaxValue != that.automaticMaxValue) return false;
        if (this.actMinValue != that.actMinValue) return false;
        if (this.actMaxValue != that.actMaxValue) return false;
        if (!ObjectUtilities.equal(this.type, that.type)) {
            return false;
        }
        if (!ObjectUtilities.equal(this.key, that.key)) {
        	return false;
        }
        if (!ObjectUtilities.equal(this.binList, that.binList)) {
            return false;
        }
        if (!ObjectUtilities.equal(this.values,that.values)) {
        	return false;
        }
        if (!ObjectUtilities.equal(this.outliers,that.outliers)) {
        	return false;
        }

        return true;   
    }
	
    public class ExtendedBin {
    	
    	private double startBoundary;
    	private double endBoundary;
    	
    	private double value;
    	private int counter;
    	
    	public ExtendedBin(double startBoundary, double endBoundary) {
    		this.startBoundary = startBoundary;
    		this.endBoundary = endBoundary;
    		this.counter = 0;
    		this.value = 0; 
    	}

    	public int getCounter() {
			return counter;
		}

    	public double getEndBoundary() {
			return endBoundary;
		}

		public double getStartBoundary() {
			return startBoundary;
		}

		public double getValue() {
			return value;
		}

		public double getMeanValue() {
			if (counter == 0) return 0;
			else return value/counter;
		}
		
		public void incrementValue(double value) {
			this.value += value;
			counter++;
		}
    }
    
    public Object clone() throws CloneNotSupportedException {
        return super.clone();   
    }
}
