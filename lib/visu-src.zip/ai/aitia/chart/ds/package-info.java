/** This package completes the visualisation package with new data source- and dataset
 *  producer classes and interfaces. */
package ai.aitia.chart.ds;