package ai.aitia.visu.view.meta;

import org.jfree.chart.axis.CategoryLabelPositions;

public class BoxPlotMetadata {
	public static final int ONE_BAR_PER_DATAROW = 0;
	public static final int ONE_BAR_PER_CATEGORY = 1;
	public static final int ONE_BAR_PER_CATEGORY_PERCENTAGE = 2;
	
	private String title;
	private String subTitle;
	
	private boolean showLegend = true;
	private int colorAppearance = Appearance.COLORED;
	private int environmentAppearance = Appearance.BASIC_APP;
	private int barRenderer = ONE_BAR_PER_CATEGORY;
	private CategoryLabelPositions categoryLabelAngle = CategoryLabelPositions.STANDARD;
	private CustomAppearance customAppearance = null;
	public boolean showLabels = true;
	
	public BoxPlotMetadata() {}
	
	public String getTitle() { return title; }
	public String getSubTitle() { return subTitle; }
	public int getColorAppearance() { return colorAppearance; }
	public int getEnvironmentAppearance() {	return environmentAppearance; }
	public boolean isShowLegend() { return showLegend; }
	public boolean isShowLabels() { return showLabels; }
	public int getBarRenderer() { return barRenderer; }
	public CategoryLabelPositions getCategoryLabelAngle() { return categoryLabelAngle; }
	public boolean hasCustomAppearance() { return customAppearance != null; }
	public CustomAppearance getCustomAppearance() { return customAppearance; }

	public void setTitle(String title) { this.title = title;  }
	public void setSubTitle(String subTitle) { this.subTitle = subTitle; }
	public void setColorAppearance(int colorAppearance) { this.colorAppearance = colorAppearance; }
	public void setEnvironmentAppearance(int environmentAppearance) { this.environmentAppearance = environmentAppearance; }
	public void setShowLegend(boolean showLegend) {	this.showLegend = showLegend; }
	public void setShowLabels(boolean showLabels) {	this.showLabels = showLabels; }
	public void setBarRenderer(int barRenderer) { this.barRenderer = barRenderer; }
	public void setCategoryLabelAngle(CategoryLabelPositions categoryLabelAngle) { this.categoryLabelAngle = categoryLabelAngle; }
	public void setCustomAppearance(CustomAppearance customAppearance) { this.customAppearance = customAppearance; }
}
