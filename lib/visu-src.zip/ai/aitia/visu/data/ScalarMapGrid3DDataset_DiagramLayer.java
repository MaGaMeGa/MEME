/*
 * Copyright notice � 2006 AITIA International Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is 
 * intellectual property owned by AITIA International Inc. and is copyright of 
 * AITIA International Inc. in all countries in the world, and ownership remains 
 * with AITIA International Inc..
 * 
 * Permission to use, copy, modify, and distribute this software is not granted 
 * without the written consent of AITIA International Inc.! For licensing issues 
 * please contact the company at 
 * Czetz J�nos u. 48-50. Budapest, 1039, Hungary, Phone: +36 1 453 8080, 
 * E-mail: info@aitia.ai, Web: http://www.aitia.ai.
 * 
 * The software is delivered 'as is' without warranty and without any support 
 * services. AITIA International Inc. makes no warranties, either expressed or 
 * implied, as to the software and its derivatives.
 * 
 * It is understood that AITIA International Inc. shall not be liable for any loss or 
 * damage that may arise, including any indirect special or consequential loss
 *  or damage in connection with or arising from the performance or use of the 
 * software, including fitness for any particular purpose.
 * 
 * 
 * Szerz�i jogok � 2006 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l, 
 * tov�bbiakban Szoftver) az AITIA International Rt. a vil�g minden orsz�g�ban 
 * szerz�i jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az 
 * AITIA International Rt. minden esetben fenntart.
 * 
 * A Szoftver haszn�lata, m�sol�sa, m�dos�t�sa, vagy b�rmely m�s jelleg� 
 * felhaszn�l�sa a jogtulajdonos �r�sos beleegyez�se n�lk�l nem megengedett!
 *  K�rj�k l�pjen kapcsolatba az AITIA International Rt-vel, melynek c�me 
 * 1039 Budapest, Czetcz J�nos u. 48-50, telefonsz�ma (1) 453 8080, 
 * e-mail c�me info@aitia.ai, illetve honlapja http://www.aitia.ai.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. 
 * Az AITIA International Rt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 *  felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * 
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett 
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 *  ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 */
package ai.aitia.visu.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.jfree.data.general.AbstractDataset;

import ai.aitia.visu.globalhandlers.GlobalHandlers;

public class ScalarMapGrid3DDataset_DiagramLayer extends AbstractDataset implements Grid3DDataset {
	
	private static final long serialVersionUID = -731408905483101237L;
	
	private boolean autoWidth = true;
	private boolean autoHeight = true;
	
	private int width = 10;
	private int height = 10;
	
	private int maxWidth = 0;
	private int maxHeight = 0;
	
	private double defaultValue = 0;
	
	private List<Item> items; 

	public ScalarMapGrid3DDataset_DiagramLayer() {
		this.items = new ArrayList<Item>();
	}
	
	public void addItem(int x, int y, double[] value) {
		if (x > (maxWidth - 1))
			maxWidth = x + 1;
		
		if (y > (maxHeight - 1))
			maxHeight = y + 1;		
		
		items.add(new Item(x,y,value));		
	}
	
	public void addItem(int x, int y, double z_value, double color_value, double shape_value) {
		if (x > (maxWidth - 1))
			maxWidth = x + 1;
		
		if (y > (maxHeight - 1))
			maxHeight = y + 1;		
		
		items.add(new Item(x, y, z_value, color_value, shape_value));		
	}
	
	public void setWidth(int width) {
		this.width = width;
		autoWidth = false;
	}

	public int getWidth() {
		return autoWidth ? (maxWidth > 0 ? maxWidth : width) : width;
	}

	public void setHeight(int height) {
		this.height = height;
		autoHeight = false;
	}	
	
	public int getHeight() {
		return autoHeight ? (maxHeight > 0 ? maxHeight : height) : height;
	}

	public synchronized double getValue(int x, int y, int k) {
		final int size = items.size();
		
		for (int i=0; i<size; i++) {
			
			Item item = (Item)items.get(i);
			
			if (item != null) {
			
				final int cx = item.getX();
				final int cy = item.getY();
			
				if ((cx == x) && (cy == y))
				return item.getValue()[k];
			}
		}		
		
		return defaultValue;
	}
	
	private double[][][] createDefaultValues(final int width, final int height) {
		double[][][] values = new double[width][height][3];
		for (int i=0; i<width; i++) {
			for (int j=0; j<height; j++) {
				for (int k = 0; k < 3; k++) {
					values[i][j][k] = defaultValue;
				}
			}
		}
		
		return values;
	}
	
	public synchronized void clear() {
		items.clear();
	}
	
	public void fireDatasetChanged() {
		super.fireDatasetChanged();
	}
	
	public Collection<double[]> getValuesCollection() {
		List<double[]> res = new ArrayList<double[]>();
		final int width = getWidth();
		final int height = getHeight();

		for (Item i : items) {
			final int x = i.getX();
			final int y = i.getY();
			if (x < width && y < height && x > -1 && y > -1) 
				res.add(i.getItemVector());
			else if (GlobalHandlers.getWarningManager().shouldDumpWarnings())
				System.out.println("WARNING: " + i + " is out of display area");
		}
		return res;
	}

	public synchronized double[][][] getValues() {
		
		final int width = getWidth();
		final int height = getHeight();
		
		double[][][] values = createDefaultValues(width, height);
		
		final int size = items.size();
		
		for (int i=0; i<size; i++) {
			Item item = items.get(i);
			final int x = item.getX();
			final int y = item.getY();
			
			if ((x<width) && (y<height) && (x>-1) && (y>-1))
			{
				values[x][y][0] = item.getValue()[0];
				values[x][y][1] = item.getValue()[1];
				values[x][y][2] = item.getValue()[2];
			}
			else if (GlobalHandlers.getWarningManager().shouldDumpWarnings())
				System.out.println("WARNING: " + item + " is out of display area");
		}
		
		return values;
	}

	public double getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(double defaultValue) {
		this.defaultValue = defaultValue;
	}
	
	public double getMaximum(int dim)
	{
		double max = -Double.MAX_VALUE;
		
		for (int i=0; i<items.size(); i++) 
		{
			if (items.get(i).getValue()[dim] > max)
			{
				max = items.get(i).getValue()[dim];
			}
		}
		
		return max;
	}
	
	public class Item {
		private int x;
		private int y;
		
		private double[] value = new double[3];
		
		public Item(int x, int y, double[] value) {
			this.x = x;
			this.y = y;
			this.value[0] = value[0];
			this.value[1] = value[1];
			this.value[2] = value[2];
		}
		
		public Item(int x, int y, double z_value, double color_value, double shape_value) {
			this.x = x;
			this.y = y;
			this.value[0] = z_value;
			this.value[1] = color_value;
			this.value[2] = shape_value;
		}

		public double[] getValue() {
			return value;
		}

		public void setValue(double[] value) {
			this.value[0] = value[0];
			this.value[1] = value[1];
			this.value[2] = value[2];
		}

		public int getX() {
			return x;
		}

		public void setX(int x) {
			this.x = x;
		}

		public int getY() {
			return y;
		}

		public void setY(int y) {
			this.y = y;
		}
		
		public double[] getItemVector() {
			return new double[] { x, y, value[0], value[1], value[2] };
		}
		
		public boolean equals(Object obj) {
			if (obj instanceof Item) {
				Item other = (Item) obj;
				
				if ((x == other.getX()) && (y == other.getY()))
					return true;
			}
			
			return false;
		}
		
		@Override
		public String toString() {
			return "(" + x + "," + y + "," + value + ")";
		}
	}
}
