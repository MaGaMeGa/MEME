/* Copyright notice � 2007 AITIA International, Inc.
 * 
 * This software [Both binary and source (if released)] (hereafter, Software) is
 * intellectual property owned by AITIA International Inc. and is copyright of
 * AITIA International Inc. in all countries in the world, and ownership remains with
 * AITIA International, Inc..
 * 
 * Permission to use, copy, modify, and distribute this software for educational,
 * research, and not-for-profit purposes, without fee and without a signed licensing
 * agreement, is hereby granted, provided that the above copyright notice, this
 * paragraph and the following two paragraphs appear in all copies, modifications, and
 * distributions.
 * 
 * The software is delivered 'as is' without warranty and without any support services.
 * AITIA International, Inc. makes no warranties, either expressed or implied, as to
 * the software and its derivatives. It is understood that AITIA International, Inc.
 * shall not be liable for any loss or damage that may arise, including any indirect
 * special or consequential loss or damage in connection with or arising from the
 * performance or use of the software, including fitness for any particular purpose.
 * 
 * Szerz�i jogok � 2007 AITIA International Zrt.
 * 
 * Ez a szoftver (mind a bin�ris �llom�nyok, mind a forr�sk�d, ha kiad�sra ker�l,
 * tov�bbiakban Szoftver) az AITIA International Zrt. a vil�g minden orsz�g�ban szerz�i
 * jogokkal v�dett szellemi tulajdona, amely tulajdonjogot az AITIA International Zrt.
 * minden esetben fenntart.
 * 
 * A Szoftver oktat�si, kutat�si �s m�s nem profit-orient�lt felhaszn�l�sa d�j �s a
 * jogtulajdonos �r�sos beleegyez�se n�lk�l is megengedett, amennyiben ezek a szerz�i
 * jogokr�l sz�l� paragrafusok bele ker�lnek minden m�solatba �s m�dos�tott v�ltozatba.
 * 
 * A Szoftver b�rminem� garancia, vagy t�mogat� szolg�ltat�s n�lk�l �rtend�. Az
 * AITIA International Zrt. elh�r�t minden nem�, ak�r k�zvetett, ak�r k�zvetlen
 * felel�ss�gv�llal�st mind a Szoftverrel, mind lesz�rmazottaival kapcsolatban.
 * Az AITIA International Zrt. nem tehet� felel�ss� sem k�zvetlen, sem k�zvetett
 * k�r�rt vagy vesztes�g�rt, amely a Szoftver teljes�tm�ny�b�l, vagy haszn�lat�b�l
 * ad�dik, �s nem v�llal felel�ss�get a Szoftver b�rmilyen c�l� haszn�lhat�s�g�ra.
 * 
 */
package ai.aitia.chart.charttypes.dialogs.components;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Map.Entry;

import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.KeyEvent;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;

import org.jfree.ui.ExtensionFileFilter;

import ai.aitia.chart.util.Utilities;
import ai.aitia.visu.globalhandlers.GlobalHandlers;
import ai.aitia.visu.utils.Utils;

/** Properties editor dialog for parameterize custom element and figure renderers.
 * @see ai.aitia.chart.charttypes.dialogs.SequenceDialog SequenceDialog
 * @see ShapeRendererPanel ShapeRendererPanel
 */
public class SettingsEditor extends JDialog {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;
	private JScrollPane scrTable = null;
	private JTable table = null;
	private JButton closeButton = null;
	private JPanel buttonPanel = null;
	private JButton saveButton = null;
	private JButton loadButton = null;

	//=============================================================================
	// additional members
	
	/** Table model of the settings table. */
	private SettingsTableModel model = null;
	
	//=============================================================================
	// methods
	
	/** Constructor.
	 * @param owner owner of the dialog
	 * @param settings predefined settings 
	 */
	public SettingsEditor(Frame owner, Properties settings) {
		super(owner);
		model = new SettingsTableModel(settings);
		initialize();
	}
	
	//-----------------------------------------------------------------------------
	/** Constructor.
	 * @param owner owner of the dialog
	 * @param settings predefined settings
	 */
	public SettingsEditor(Dialog owner, Properties settings) {
		super(owner);
		model = new SettingsTableModel(settings);
		initialize();
	}

	//-----------------------------------------------------------------------------
	/** This method initializes <code>this</code>. */
	private void initialize() {
		this.setTitle("Renderer properties");
		final JScrollPane sp = new JScrollPane(getJContentPane(),JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		sp.setBorder(null);
		this.setContentPane(sp);
		this.pack();
		Dimension oldD = this.getPreferredSize();
		this.setPreferredSize(new Dimension(oldD.width + sp.getVerticalScrollBar().getWidth(), 
								     		oldD.height + sp.getHorizontalScrollBar().getHeight()));
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		oldD = this.getPreferredSize();
		final Dimension newD = Utils.getPreferredSize(this);
		if (!oldD.equals(newD)) 
			this.setPreferredSize(newD);
		this.pack();
	}

	//-----------------------------------------------------------------------------
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getScrTable(), BorderLayout.CENTER);
			jContentPane.add(getButtonPanel(), BorderLayout.SOUTH);
		}
		return jContentPane;
	}

	//-----------------------------------------------------------------------------
	private JScrollPane getScrTable() {
		if (scrTable == null) {
			scrTable = new JScrollPane();
			scrTable.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
			scrTable.setViewportView(getTable());
		}
		return scrTable;
	}

	//-----------------------------------------------------------------------------
	private JTable getTable() {
		if (table == null) {
			table = new JTable(model);
		}
		return table;
	}

	//-----------------------------------------------------------------------------
	private JButton getCloseButton() {
		if (closeButton == null) {
			closeButton = new JButton();
			closeButton.setText("Close");
			closeButton.setMnemonic(KeyEvent.VK_C);
			closeButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					setVisible(false);
				}
			});
		}
		return closeButton;
	}

	//-----------------------------------------------------------------------------
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = new JPanel();
			buttonPanel.setLayout(new FlowLayout());
			buttonPanel.add(getSaveButton(), null);
			buttonPanel.add(getLoadButton(), null);
			buttonPanel.add(getCloseButton(), null);
		}
		return buttonPanel;
	}

	//-----------------------------------------------------------------------------
	private JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = new JButton();
			saveButton.setMnemonic(KeyEvent.VK_S);
			saveButton.setText("Save settings...");
			final SettingsEditor tthis = this;
			saveButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					// get the filename
					JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
					fc.setAcceptAllFileFilterUsed(false);
					fc.addChoosableFileFilter(new ExtensionFileFilter("Settings files", ".settings"));
					int result = fc.showSaveDialog(tthis);
					if (result == JFileChooser.APPROVE_OPTION) {
						File file = fc.getSelectedFile();
						File newFile = Utilities.generateValidFile(file,"settings");
						GlobalHandlers.setLastDirectory(newFile);
						
						// initialize the properties object
						Properties prop = model.createProperties();
						// open file and save 
						try {
							FileOutputStream os = new FileOutputStream(newFile);
							prop.store(os, "");
							os.close();
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(tthis,"Unable to save the defined settings.","Saving failure",JOptionPane.ERROR_MESSAGE,null);
						}
					}
				}
			});
		}
		return saveButton;
	}

	//-----------------------------------------------------------------------------
	private JButton getLoadButton() {
		if (loadButton == null) {
			loadButton = new JButton();
			loadButton.setMnemonic(KeyEvent.VK_L);
			loadButton.setText("Load settings...");
			final SettingsEditor tthis = this;
			loadButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					// get the file name
					JFileChooser fc = new JFileChooser(GlobalHandlers.getLastDirectory());
					fc.setAcceptAllFileFilterUsed(false);
					fc.addChoosableFileFilter(new ExtensionFileFilter("Settings files",".settings"));
					int result = fc.showOpenDialog(tthis);
					if (result == JFileChooser.APPROVE_OPTION) {
						File file = fc.getSelectedFile();
						GlobalHandlers.setLastDirectory(file);
						
						// open the file
						Properties prop = new Properties();
						try {
							FileInputStream is = new FileInputStream(file);
							prop.load(is);
							is.close();
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(tthis,"Unable to load the selected settings.","Loading failure",JOptionPane.ERROR_MESSAGE,null);
							return;
						}
						// set the settings
						model = new SettingsTableModel(prop);
						table.setModel(model);
					}
				}
			});
		}
		return loadButton;
	}
	
	//=============================================================================
	// non-GUI methods
	
	//-----------------------------------------------------------------------------
	/** Returns the defined properties object.
	 * @return the defined properties object
	 */
	public Properties getSettings() {
		return model.createProperties();
	}
	
	//=============================================================================
	// nested classes

	/** Table model for settings table. */
	private class SettingsTableModel extends AbstractTableModel {

		//=========================================================================
		// nested classes
		
		/** Class that represents one row in the table, a key-value pair. */
		private class KeyValuePair {
			
			/** Key. */
			private String key;
			
			/** String value. */
			private String value;
			
			//=====================================================================
			// methods
			
			/** Constructor.
			 * @param key key
			 * @param value value
			 */			
			public KeyValuePair(String key, String value) {
				this.key = key;
				this.value = value;
			}

			//---------------------------------------------------------------------
			/** Returns the key.
			 * @return the key
			 */
			public String getKey() {
				return key;
			}

			//---------------------------------------------------------------------
			/** Returns the value.
			 * @return the value
			 */
			public String getValue() {
				return value;
			}

			//---------------------------------------------------------------------
			/** Sets the key.
			 * @param key the new key
			 */
			public void setKey(String key) {
				this.key = key;
			}

			//---------------------------------------------------------------------
			/** Sets the value.
			 * @param value the new value
			 */
			public void setValue(String value) {
				this.value = value;
			}
			
			//---------------------------------------------------------------------
			/** Returns true if the two keys are equal. */
			@Override
			public boolean equals(Object obj) {
				if (obj instanceof KeyValuePair) {
					KeyValuePair that = (KeyValuePair)obj;
					return this.key.equals(that.key);
				}
				return false;
			}
		}
		
		//=========================================================================
		// members
		
		private static final long serialVersionUID = 1L;
		
		/** List of rows. Each row is a key-value pair. */
		private List<KeyValuePair> elements = null;
		
		//=========================================================================
		// methods
		
		/** Constructor.
		 * @param prop the initial properties in the table
		 */
		public SettingsTableModel(Properties prop) {
			elements = new ArrayList<KeyValuePair>();
			elements.add(new KeyValuePair(" "," "));
			if (prop != null) {
				for (Entry<Object,Object> e : prop.entrySet()) {
					elements.add(elements.size()-1,new KeyValuePair(e.getKey().toString(),
																	e.getValue().toString()));
				}
			}
		}
		
		//-----------------------------------------------------------------------------
		/** Returns the number of columns.
		 * @return the number of columns
		 */
		public int getColumnCount() {
			return 2;
		}

		//------------------------------------------------------------------------
		/** Returns the number of rows.
		 * @return the number of rows
		 */
		public int getRowCount() {
			return elements.size();
		}

		//------------------------------------------------------------------------
		/** Returns the value of the cell specified by <code>rowIndex</code> and
		 *  <code>columnIndex</code>.
		 * @param rowIndex row index of the cell
		 * @param columnIndex column index of the cell
		 * @return the value of the appropriate cell
		 */
		public Object getValueAt(int rowIndex, int columnIndex) {
			if (columnIndex == 0) return elements.get(rowIndex).getKey();
			else return elements.get(rowIndex).getValue();
		}
		
		//------------------------------------------------------------------------
		@Override
	    public void setValueAt(Object value, int row, int col) {
	    	if (value.toString().equals(" ")) return;
	    	if (col == 0) {
	    		if (elements.contains(new KeyValuePair(value.toString()," "))) return;
	    		elements.get(row).setKey(value.toString());
	    		elements.add(new KeyValuePair(" "," "));
	    	} else {
	    		if (!elements.get(row).getKey().equals(" ")) 
	    			elements.get(row).setValue(value.toString());
	    	}
	        fireTableCellUpdated(row, col);
	    }
	    
		//------------------------------------------------------------------------
		@Override
		public String getColumnName(int col) {
			return col == 0 ? "Property" : "Value";
		}
		
		//------------------------------------------------------------------------
		@Override
		public boolean isCellEditable(int row, int col) {
			return true;
		}
		
		//------------------------------------------------------------------------
		/** Returns a Properties object created from the rows of the table.
		 * @return the defined Properties object
		 */
		public Properties createProperties() {
			Properties result = new Properties();
			for (int i=0;i<elements.size()-1;++i) result.setProperty(elements.get(i).getKey().trim(),
																	 elements.get(i).getValue().trim());
			return result;
		}
	}
}
